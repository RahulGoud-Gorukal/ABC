var flc=/^(\d)[A-Z]$/;
var fln=/^\d{3,5}$/;
var paxn=/^[0-9]+$/;

var nam=/^[A-Z a-z]+$/;
var phone=/^[\+\-()\d]+$/;
var postcode = /^[0-9]+$/;
var country = /^[A-Z a-z]+$/;
var branchcode = /^[A-Z a-z 0-9]+$/;
var telephone=/^[0-9 \+\-\(\)]+$/;



function validatePAXNumber(paxvar)
{
	var vpaxn=paxn.exec(paxvar.value);

	if(!vpaxn)
	{
		window.alert("E-5101: PAX number can only contain numbers.");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	if(!checklength(paxvar,10,"PAX Number","digits","y"))
		return(false);
	
	if(paxvar.value == "0000000000")
	{
		alert("E-5102: Enter a valid PAX number.");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	return(true);

}


function isBlank(str1,label,prompt)
{
	if(str1.value=="")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-5103: " + label + " cannot be empty.");
			str1.select();
			str1.focus();
		}
		return(true);		
	}
	return(false);
}


function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-5104: " + label + " should have " + len + " " + type+".");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}


function maintainGroup()
{
	if (!generalCheck())
		return(false);
		
	groupForm.action = "groupAction.do?subaction=maintainGroup";
	groupForm.submit();
}

function addGroup()
{
	if (!generalCheck())
		return(false);

	groupForm.action = "groupAction.do?subaction=addGroup";
	groupForm.submit();
}

function generalCheck()
{
	 
  //Added by selvam for Ticket # 283759  starts
	
	if(groupForm.nationality.value!="-1")
	
	groupForm.nationalityValue.value =groupForm.nationality.options[groupForm.nationality.selectedIndex].text;
		
		
		else
	{
		alert("E-2152 Please select a valid Nationality");
		groupForm.nationality.value = "-1";
		groupForm.nationality.focus();
		return(false);
		}
//Added by selvam for Ticket # 283759  ends
//Added by David for ticket # 309369 starts here
	if(isBlank(groupForm.startingPaxNumber,"Starting Pax Number","y"))
		return(false); 
//Added by David for ticket # 309369 ends here
	if (groupForm.startingPaxNumber != null)
	{
	if(!isBlank(groupForm.startingPaxNumber,"",""))
	{
		if(!validatePAXNumber(groupForm.startingPaxNumber))
			return(false);
	}

	if(isBlank(groupForm.numberOfPax,"Number of passengers","y"))
		return(false);

	var vpaxn=paxn.exec(groupForm.numberOfPax.value);

	if(!vpaxn)
	{
		window.alert("E-5105: Number of PAX can contain only numbers.");
		groupForm.numberOfPax.select();
		groupForm.numberOfPax.focus();
		return(false);
	}

	if(groupForm.numberOfPax.value == "0000")
	{
		alert("E-5106: Enter a valid number of pax.");
		groupForm.numberOfPax.select();
		groupForm.numberOfPax.focus();
		return(false);
	}
	}
	if(groupForm.arrivalAirlineCode.value!="-1" || !isBlank(groupForm.arrivalFlightNumber," ","n"))
	{
		if(groupForm.arrivalAirlineCode.value=="-1")  
		{
			alert("E-5107: Select a valid arrival airline code.");
			groupForm.arrivalAirlineCode.focus();
			return(false);
		}
		
		if(isBlank(groupForm.arrivalFlightNumber,"Arrival flight number", "y"))
			return(false);
			
		vfln=fln.exec(groupForm.arrivalFlightNumber.value);
	
		if(!vfln)
		{
			window.alert("E-5108: Arrival flight number has to be in the correct format.");
			groupForm.arrivalFlightNumber.select();
			groupForm.arrivalFlightNumber.focus();
			return(false);
		}
		
		if(isBlank(groupForm.arrivalFlightDate,"Arrival Flight Date","y"))
			return(false);
	}

	if(groupForm.departureAirlineCode.value!="-1" || !isBlank(groupForm.departureFlightNumber," ","n"))
	{
		if(groupForm.departureAirlineCode.value=="-1")
		{
			alert("E-5109: Select a valid departure airline code.");
			groupForm.departureAirlineCode.focus();	
			return(false);
		}
		
		if(isBlank(groupForm.departureFlightNumber,"Departure flight number", "y"))
			return(false);
			
		var vfln=fln.exec(groupForm.departureFlightNumber.value);
	
		if(!vfln)
		{
			window.alert("E-5110: Departure flight number has to be in the correct format.");
			groupForm.departureFlightNumber.select();
			groupForm.departureFlightNumber.focus();
			return(false);
		}

		if(isBlank(groupForm.departureFlightDate,"Departure Flight Date","y"))
			return(false);
	}
	
	if(!isBlank(groupForm.arrivalFlightDate," ","n"))
	{
		if(!validateDate(groupForm.arrivalFlightDate,"yyyy/mm/dd","Arrival flight date","y"))		
			return(false);

		if(groupForm.arrivalAirlineCode.value=="-1")  
		{
			alert("E-5107: Select a valid arrival airline code.");
			groupForm.arrivalAirlineCode.focus();
			return(false);
		}
	}
	
	if(!isBlank(groupForm.departureFlightDate," ","n"))
	{
		if(!validateDate(groupForm.departureFlightDate,"yyyy/mm/dd","Departure flight date","y"))		
			return(false);

		var today = new Date();
		var day   = today.getDate();
		var month = today.getMonth();
		month = month + 1;
		var year  = today.getYear();
	
		if(day<10)
			day = "0" + day;
	
		if(month<10)
			month = "0" + month;
		
		if(year<1000)
			year + 1900;	
		
		var todayString = year + "/" + month + "/" + day;
		
		if(groupForm.departureFlightDate.value<todayString)
		{
			alert("E-5111: Departure flight date cannot be a past date.");
			groupForm.departureFlightDate.select();
			groupForm.departureFlightDate.focus();
			return(false);
		}
			
		if(groupForm.departureFlightDate.value<groupForm.arrivalFlightDate.value)
		{
		       alert("E-5112: Departure flight date should be greater than or equal to arrival flight date.");
		       return(false);
		}
		
		if(groupForm.departureAirlineCode.value=="-1")
		{
			alert("E-5109: Select a valid departure airline code.");
			groupForm.departureAirlineCode.focus();	
			return(false);
		}
	}
 
	if(groupForm.departureAirlineCode.value!="-1")
		groupForm.depAirlineCodeValue.value = groupForm.departureAirlineCode.options[groupForm.departureAirlineCode.selectedIndex].text;
	else
		groupForm.depAirlineCodeValue.value = "";

	if(groupForm.arrivalAirlineCode.value!="-1")
		groupForm.arrAirlineCodeValue.value = groupForm.arrivalAirlineCode.options[groupForm.arrivalAirlineCode.selectedIndex].text;
	else
		groupForm.arrAirlineCodeValue.value = "";
 
	return(true);
		
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-5113: " + label + " is invalid. Expected date format is " + dateformat+".");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}

//Functions for TA and Branch

function clearPage()
{
	document.commForm.reset();
}

function submitPage()
{
	var taCodeForm = document.commForm['commBean.taCode'].value;
	var agencyNameForm = document.commForm['commBean.agencyName'].value;
	var agencyOwnerForm = document.commForm['commBean.agencyOwner'].value;

	
	document.commForm['commBean.taCode'].value = trim(document.commForm['commBean.taCode'].value);
	document.commForm['commBean.agencyName'].value = trim(document.commForm['commBean.agencyName'].value);
	document.commForm['commBean.agencyOwner'].value = trim(document.commForm['commBean.agencyOwner'].value);
	

	var blankTaCode = isBlankValue(document.commForm['commBean.taCode'].value, "TA Code");

	
	if (!blankTaCode)
	{
		document.commForm['commBean.taCode'].focus();
		return false;
	}

	else
	{
		var vTaCode = postcode.exec(document.commForm['commBean.taCode'].value);
		if(!vTaCode)
		{
			alert("E-5114: TA Code can only contain numbers.");
			document.commForm['commBean.taCode'].select();
			document.commForm['commBean.taCode'].focus();
		    return false;
		}
		
		/* Commented on 20-12-2006 
		if (document.commForm['commBean.taCode'].value.length != 3)
		{
			alert("E-5115: TA Code should have 3 digits");
			document.commForm['commBean.taCode'].select();
			document.commForm['commBean.taCode'].focus();
			return false;
		}
		*/
		//Modified on 20-12-2006 for 5digit TA code
		
		if (!(document.commForm['commBean.taCode'].value.length == 3 || document.commForm['commBean.taCode'].value.length == 5))
		{
			alert("E-5115: TA Code should have 3 or 5 digits");
			document.commForm['commBean.taCode'].select();
			document.commForm['commBean.taCode'].focus();
			return false;
		}
		//If it's 5-digit Tacode then valid entries are 01000 to 99999 
		
		if(document.commForm['commBean.taCode'].value.length == 5){
		var beginDigits=document.commForm['commBean.taCode'].value.substring(0,2);
		if (beginDigits=="00"){
		alert("E-5118: 5-DigitTA Code Range should be 01000 to 99999");
		document.commForm['commBean.taCode'].select();
		document.commForm['commBean.taCode'].focus();
		return false;
		}
		}
		

	}


		var blankAgencyName = isBlankValue(document.commForm['commBean.agencyName'].value, "Agency Name");
	
	
	
		if(!blankAgencyName)
		{
			document.commForm['commBean.agencyName'].focus();
			return false;
		}	
		
		var splBlankAgencyName = branchcode.exec(document.commForm['commBean.agencyName'].value);
	
		if (!splBlankAgencyName)
		{
			alert("E-5116: Agency Name cannot contain special characters");
			document.commForm['commBean.agencyName'].select();
			document.commForm['commBean.agencyName'].focus();
			return false;
		}



			
	
	/*
	var splBlankAgencyName = isSplCharsPresent(document.commForm['commBean.agencyName'].value);
	if (!splBlankAgencyName)
	{
		alert("E-5115: Agency Name cannot contain special characters");
		document.commForm['commBean.agencyName'].select();
		document.commForm['commBean.agencyName'].focus();
		return false;
	}
	*/	

	document.commForm.action="commAction.do?subaction=confirmTravelAgent&fromConfirmPage=Yes";
	document.commForm.submit();
}


function searchTA()
{
	document.searchTAForm.action="searchTAAction.do?subaction=searchTravelAgent";
	document.searchTAForm.submit();
}


function modifyTARecord()
{
	var blankAgencyName = isBlankValue(document.commForm['commBean.agencyName'].value, "Agency Name");		
	if(!blankAgencyName)
	{
		document.commForm['commBean.agencyName'].focus();
		return false;
	}
	
	
	var splBlankAgencyName = nam.exec(document.commForm['commBean.agencyName'].value);
	if (!splBlankAgencyName)
	{
		alert("E-5117: Agency Name cannot contain special characters");
		document.commForm['commBean.agencyName'].select();
		document.commForm['commBean.agencyName'].focus();
		return false;
	}	
	
	
	document.commForm.action="commAction.do?subaction=confirmTravelAgent&mode=Modify";
	document.commForm.submit();
}

function deleteTARecord()
{
	if(window.confirm("Do you want to delete ?"))
	{
		document.commForm.action="commAction.do?subaction=deleteTravelAgent";
		document.commForm.submit();
	}
}


function createBranch(param)
{
	
	//Validation for BranchCode
	
	if(param=='fromCreate')
	{


		var taName = document.branchForm['branchBean.taName'].value;
		
		if (taName == -1)
		{
			alert('E-5119: TA Name Cannot be empty');
			document.branchForm['branchBean.taName'].focus();
			return false;
		}


		var branchCodeValue = document.branchForm['branchBean.branchCode'].value;
		var blankBranchCode = isBlankValue(document.branchForm['branchBean.branchCode'].value, "Branch Code");


		if (!blankBranchCode)
		{
			document.branchForm['branchBean.branchCode'].focus();
			return false;
		}
		else
		{
			var branch = /^\w+$/;
			var vbranchCode = branch.exec(document.branchForm['branchBean.branchCode'].value);
			if(!vbranchCode)
			{
				alert("E-5120: Branch code cannot contain special characters.");
				document.branchForm['branchBean.branchCode'].select();
				document.branchForm['branchBean.branchCode'].focus();
			    	return false;
			}

			if (document.branchForm['branchBean.branchCode'].value.length != 4)
			{
				alert("E-5121: TA Branch Code should have 4 characters.");
				document.branchForm['branchBean.branchCode'].select();
				document.branchForm['branchBean.branchCode'].focus();
				return false;
			}
		}
	}

	//Validation for BranchName
	var branchNameValue = document.branchForm['branchBean.branchName'].value;
	var blankBranchName = isBlankValue(document.branchForm['branchBean.branchName'].value, "Branch Name");
	
	if(!blankBranchName)
	{
		document.branchForm['branchBean.branchName'].focus();
		return false;
	}
	else
	{
		var vbranchName = nam.exec(document.branchForm['branchBean.branchName'].value);
		if(!vbranchName)
		{
			alert("E-5122: Branch Name should contain alphanumeric characters only.");
			document.branchForm['branchBean.branchName'].select();
			document.branchForm['branchBean.branchName'].focus();
		    return false;
		}
	}
	
	//Validation for Contact Person
	var contactPerson = document.branchForm['branchBean.contactPerson'].value;
	if (!isBlank(document.branchForm['branchBean.contactPerson'],"","n"))
	{
		var vContactPerson = nam.exec(document.branchForm['branchBean.contactPerson'].value);
		if(!vContactPerson)
		{
			alert("E-5123: Contact Person should contain alphanumeric characters only.");
			document.branchForm['branchBean.contactPerson'].select();
			document.branchForm['branchBean.contactPerson'].focus();
		    return false;
		}
	}
	
	//Validation for city
	var city = document.branchForm['branchBean.city'].value;
	
	if(!isBlank(document.branchForm['branchBean.city'],"","n"))
	{
		var vCity = nam.exec(document.branchForm['branchBean.city'].value);
		if(!vCity)
		{
			alert("E-5124: City should contain alphanumeric characters only.");
			document.branchForm['branchBean.city'].select();
			document.branchForm['branchBean.city'].focus();
		    return false;
		}
	}	
	
	
	//Validation for country
	var country = document.branchForm['branchBean.country'].value;
	
	if(!isBlank(document.branchForm['branchBean.country'],"","n"))
	{
		var vCountry = nam.exec(document.branchForm['branchBean.country'].value);
		if(!vCountry)
		{
			alert("E-5125: Country should contain alphanumeric characters only.");
			document.branchForm['branchBean.country'].select();
			document.branchForm['branchBean.country'].focus();
		    return false;
		}
	}

	
	//Validation for phone
	
	var phone = document.branchForm['branchBean.phone'].value;
	
	if(!isBlank(document.branchForm['branchBean.phone'],"","n"))
	{
		var vPhone = telephone.exec(document.branchForm['branchBean.phone'].value);
		if(!vPhone)
		{
			alert("E-5126: Telephone numbers should not contain characters other than digits and + - ( )");
			document.branchForm['branchBean.phone'].select();
			document.branchForm['branchBean.phone'].focus();
		    return false;
		}
	}
	
	
	//Validation for email
	var email = document.branchForm['branchBean.email'].value;
	
	if(!isBlank(document.branchForm['branchBean.email'],"","n"))
	{
		if(!emailCheck(email))
		{
			document.branchForm['branchBean.email'].select();			
			document.branchForm['branchBean.email'].focus();
			return false ;
		}
	}	
	
	
	//Validation for fax
	var fax = document.branchForm['branchBean.fax'].value;
	
	if(!isBlank(document.branchForm['branchBean.fax'],"","n"))
	{
		var vFax = telephone.exec(document.branchForm['branchBean.fax'].value);
		if(!vFax)
		{
			alert("E-5127: Fax should not contain characters other than digits and + - ( )");
			document.branchForm['branchBean.fax'].select();
			document.branchForm['branchBean.fax'].focus();
		    return false;
		}
	}

	
	//Validation for pocode-prefix
	var postCode1 = document.branchForm['branchBean.postCode1'].value;
	
	if(!isBlank(document.branchForm['branchBean.postCode1'],"","n"))
	{
		var vPostCode1 = postcode.exec(document.branchForm['branchBean.postCode1'].value);
		if(!vPostCode1)
		{
			alert("E-5128: Postcode should be numeric.");
			document.branchForm['branchBean.postCode1'].select();
			document.branchForm['branchBean.postCode1'].focus();
		    return false;
		}
	}	
	
	//Validation for pocode-suffix
	var postCode2 = document.branchForm['branchBean.postCode2'].value;
	
	if(!isBlank(document.branchForm['branchBean.postCode2'],"","n"))
	{
		var vPostCode2 = postcode.exec(document.branchForm['branchBean.postCode2'].value);
		if(!vPostCode2)
		{
			alert("E-5129: Postcode should be numeric.");
			document.branchForm['branchBean.postCode2'].select();
			document.branchForm['branchBean.postCode2'].focus();
		    return false;
		}
	}	
	
	if(param=='fromCreate')
	{
		document.branchForm.action="branchAction.do?subaction=confirmBranch";
		document.branchForm.submit();
	}
	
	return true;
}

function searchBranch()
{
	document.branchForm.action="searchBranchAction.do?subaction=searchBranch";
	document.branchForm.submit();
}

function clearBranch()
{
	//document.branchForm.reset();
	document.branchForm['branchBean.taName'].value = -1  ;
	document.branchForm['branchBean.branchCode'].value = "";
	document.branchForm['branchBean.branchName'].value = "";
	document.branchForm['branchBean.contactPerson'].value = "";
	document.branchForm['branchBean.city'].value = "";	
	document.branchForm['branchBean.country'].value = "";
	document.branchForm['branchBean.phone'].value = "";
	document.branchForm['branchBean.email'].value ="";
	document.branchForm['branchBean.fax'].value = "";
	document.branchForm['branchBean.postCode1'].value = "";
	document.branchForm['branchBean.postCode2'].value = "";
	document.branchForm['branchBean.segmentCode'].options.length = 0;
	document.branchForm['branchBean.segmentCode'].options[0] = new Option('--Select--','-1');
	document.branchForm.taCode.focus();
	
	return;
}


function saveBranchDetails()
{
	var retValue = createBranch("fromModify");
	if(retValue)
	{
		document.branchForm.action="branchAction.do?subaction=confirmModifyBranch";
		document.branchForm.submit();
	}
}

function getBranchDetails()
{
	document.searchBranchForm.action="searchBranchAction.do?subaction=searchBranch";
	document.searchBranchForm.submit();
}

function deleteBranch()
{
	if(window.confirm("Do you want to delete ?"))
	{
		document.branchForm.action="branchAction.do?subaction=deleteBranch";
		document.branchForm.submit();
	}
}


function isBlankValue(value, label)
{
	if (value=="" || value.length <= 0)
	{
		alert("E-5131: "+label+" cannot be empty.");
		return false;
	}
	else
	{
		return true;
	}
}	





function startVisit()
{
	if (!isBlank(visitForm.expVisitDate,"","n"))
	{
		if(!validateDate(visitForm.expVisitDate,"yyyy/mm/dd","Expected date of visit","y"))		
			return;
	}
	if (!isBlank(visitForm.visitCode," ","n"))
	{
		var v = /^\d+$/;
		var ev = v.exec(visitForm.visitCode.value);
		if (!ev)
		{
			alert("E-5131: Visit Code can accept only numbers");
			visitForm.visitCode.select();
			visitForm.visitCode.focus();
			return;
		}
	}
	
	visitForm.action = "visitAction.do?subaction=performStartVisit";
	visitForm.submit();
}

function confirmStartVisit(serialno,index,pageNumber,access)
{
	var actPax = /^\d+$/;
	var len = visitForm.actualNoOfPax.length;
	var a = eval(document.all("actualPax"+index));
	var b =document.all("actVT"+index).value;
	var avt;
	
	
	if (len == null)
	{
	 //added for CR695 on 06-oct 2008 begin
	 
		if(access=="Y" && visitForm.actVisitTime.value == "")
			{
				alert("E-2212: Actual Visit Time cannot be blank");
				visitForm.actVisitTime.focus();
				return;
			}
	 //added for CR695 on 06-oct 2008 end 
	
		if (isBlank(visitForm.actualNoOfPax,"Actual Number of pax","y"))
			return;
			
		var act = actPax.exec(visitForm.actualNoOfPax.value);
		if (!act)
		{
			alert("E-5132: Actual Number of pax can only be numeric");
			visitForm.actualNoOfPax.select();
			visitForm.actualNoOfPax.focus();
			return;
		}		
		
		if (visitForm.actualNoOfPax.value > parseInt(a.value))
		{
			alert("E-5133: Actual Number of pax should be less than or equal to expected number of pax.");
			visitForm.actualNoOfPax.select();
			visitForm.actualNoOfPax.focus();
			return;
		}
		var f = visitForm.actualNoOfPax.value;
		 //added for CR695 on 06-oct 2008 begin
		if(access=="Y")
		avt= visitForm.actVisitTime.value;		
		else
		avt=b;
		 //added for CR695 on 06-oct 2008 end 	
	}
	else
	{
	 //added for CR695 on 06-oct 2008 begin
		if(access=="Y" && visitForm.actVisitTime[index].value == "")
			{
				alert("E-2212: Actual Visit Time cannot be blank");
				visitForm.actVisitTime[index].focus();
				return;
			}
	 //added for CR695 on 06-oct 2008 end
			
		if (isBlank(visitForm.actualNoOfPax[index],"Actual Number of pax","y"))
			return;
		
	
		var act = actPax.exec(visitForm.actualNoOfPax[index].value);
		if (!act)
		{
			alert("E-5132: Actual Number of pax can only be numeric");
			visitForm.actualNoOfPax[index].select();
			visitForm.actualNoOfPax[index].focus();
			return;
		}		

		if (visitForm.actualNoOfPax[index].value > parseInt(a.value))
		{
			alert("E-5133: Actual Number of pax should be less than or equal to expected number of pax.");
			visitForm.actualNoOfPax[index].select();
			visitForm.actualNoOfPax[index].focus();
			return;
		}
		var f = visitForm.actualNoOfPax[index].value;
		 //added for CR695 on 06-oct 2008 begin
		if(access=="Y") 
		avt= visitForm.actVisitTime[index].value;	
		else
		avt=b;
		 //added for CR695 on 06-oct 2008 end 	
	
	}
	 //modified for CR695 on 06-oct 2008
	visitForm.action = "visitAction.do?subaction=updateStartVisit&index="+serialno+"&actualPax="+f+"&pageNumber="+pageNumber+"&actualVisitTime="+avt;
	visitForm.submit();

}


function emailCheck(emailStr)
{
	/* The following pattern is used to check if the entered e-mail address
	   fits the user@domain format.  It also is used to separate the username
	   from the domain. */
	var emailPat=/^(.+)@(.+)$/

	/* The following string represents the pattern for matching all special
	   characters.  We don't want to allow special characters in the address.
	   These characters include ( ) < > @ , ; : \ " . [ ]    */
	var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]"

	/* The following string represents the range of characters allowed in a
	   username or domainname.  It really states which chars aren't allowed. */
	var validChars="\[^\\s" + specialChars + "\]"

	/* The following pattern applies if the "user" is a quoted string (in
	   which case, there are no rules about which characters are allowed
	   and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
	   is a legal e-mail address. */
	var quotedUser="(\"[^\"]*\")"

	/* The following pattern applies for domains that are IP addresses,
	   rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
	   e-mail address. NOTE: The square brackets are required. */
	var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/

	/* The following string represents an atom (basically a series of
	   non-special characters.) */
	var atom=validChars + '+'

	/* The following string represents one word in the typical username.
	   For example, in john.doe@somewhere.com, john and doe are words.
	   Basically, a word is either an atom or quoted string. */
	var word="(" + atom + "|" + quotedUser + ")"

	// The following pattern describes the structure of the user
	var userPat=new RegExp("^" + word + "(\\." + word + ")*$")

	/* The following pattern describes the structure of a normal symbolic
	   domain, as opposed to ipDomainPat, shown above. */
	var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$")

	var matchArray=emailStr.match(emailPat)
	if (matchArray==null)
	{
		alert("E-5134: Email address is invalid.")
		return false
	}
	var user=matchArray[1]
	var domain=matchArray[2]

	// See if "user" is valid
	if (user.match(userPat)==null)
	{
		// user is not valid
		alert("E-5134: Email address is invalid.")
		return false
	}

	/* if the e-mail address is at an IP address (as opposed to a symbolic
	   host name) make sure the IP address is valid. */
	var IPArray=domain.match(ipDomainPat)
	if (IPArray!=null)
	{
		// this is an IP address
		  for (var i=1;i<=4;i++)
		  {
			if (IPArray[i]>255)
			{
				alert("E-5103: Email address is invalid.")
				return false
			}
		  }

		  return true
	}

	// Domain is symbolic name
	var domainArray=domain.match(domainPat)
	if (domainArray==null)
	{
		alert("E-5134: Email address is invalid.")
		return false
	}

	/* domain name seems valid, but now make sure that it ends in a
	   three-letter word (like com, edu, gov) or a two-letter word,
	   representing country (uk, nl), and that there's a hostname preceding
	   the domain or country. */

	/* Now we need to break up the domain to get a count of how many atoms
	   it consists of. */
	var atomPat=new RegExp(atom,"g")
	var domArr=domain.match(atomPat)
	var len=domArr.length
	if (domArr[domArr.length-1].length<2 || domArr[domArr.length-1].length>3)
	{
	   // the address must end in a two letter or three letter word.
	   alert("E-5134: Email address is invalid.")
	   return false
	}

	// Make sure there's a host name preceding the domain.
	if (len<2)
	{
	   alert("E-5134: Email address is invalid.")
	   return false
	}

	// If we've gotten this far, everything's valid!
	return true;
}

	function searchMaintainVisit() 
		{
			
			
			//Added by David for CR#3563 modified for description below Expected visit from date,Actual visit from date
			//Also shifted the position of the below two if condition code snippet
			if(!isBlank(visitForm.expVisitDate," ","n"))
			{
				if(!validateDate(visitForm.expVisitDate,"yyyy/mm/dd","Expected visit from date","y"))		
					return;
			}
			
			if(!isBlank(visitForm.actVisitDate," ","n"))
			{
				if(!validateDate(visitForm.actVisitDate,"yyyy/mm/dd","Actual visit from date","y"))		
					return;
			}
			//Added by David for CR#3563 starts here
			if(!isBlank(visitForm.expVisitDateTo," ","n"))
			{
				if(!validateDate(visitForm.expVisitDateTo,"yyyy/mm/dd","Expected visit to date ","y"))		
					return;
			}
			
			if(!isBlank(visitForm.actVisitDateTo," ","n"))
			{
				if(!validateDate(visitForm.actVisitDateTo,"yyyy/mm/dd","Actual visit to date","y"))		
					return;
			}
			//Added by David for CR#3563 ends here
			if (!isBlank(visitForm.visitName,"","n"))		
			{
				var c = /^[\w\s]+$/;
				var vc = c.exec(visitForm.visitName.value);
				if (!vc)
				{
					alert("E-5136: Visit Name can accept only alphanumeric characters");
					visitForm.visitName.select();
					visitForm.visitName.focus();
					return;
				}
			}
			if (!isBlank(visitForm.visitCode," ","n"))
			{
				
				var v = /^\d+$/;
				var ev = v.exec(visitForm.visitCode.value);
				if (!ev)
				{
					alert("E-5135: Visit Code can accept only numbers");
					visitForm.visitCode.select();
					visitForm.visitCode.focus();
					return;
				}
				
			}
			//Added by David for CR#3563 starts here
			else
			{
					
				
			if(visitForm.expVisitDate.value == "" && visitForm.actVisitDate.value == "" )
			{
				var expvisit11 = isBlankValue(visitForm.expVisitDate.value, "Expected visit from date");
				if (!expvisit11)
				{
					visitForm.expVisitDate.select();
					visitForm.expVisitDate.focus();
					return;
				}
			}
			
			if(visitForm.expVisitDate.value != "" && visitForm.expVisitDateTo.value == "")
			{
				var expvisit12 = isBlankValue(visitForm.expVisitDateTo.value, "Expected visit to date");
				if (!expvisit12)
				{
					visitForm.expVisitDateTo.select();
					visitForm.expVisitDateTo.focus();
					return;
				}
			}
			if(visitForm.actVisitDate.value != "" )
			{
				var expvisit13 = isBlankValue(visitForm.actVisitDateTo.value, "Actual visit to date");
				if (!expvisit13)
				{
					visitForm.actVisitDateTo.select();
					visitForm.actVisitDateTo.focus();
					return;
				}
			}	
			
			}
			
			
		var count = checkLeapYear(visitForm.expVisitDate.value,visitForm.expVisitDateTo.value);
		var days = countDays(visitForm.expVisitDate.value,visitForm.expVisitDateTo.value);
		
		days = (days - count)+1;
	 
		
 	 	if(days>31)
		{
		  alert("E-1013: The report can be generated for a maximum of one month only.");
	      visitForm.expVisitDateTo.select();
	      visitForm.expVisitDateTo.focus();
	      return ;
		}   
		
		var count = checkLeapYear(visitForm.actVisitDate.value,visitForm.actVisitDate.value);
		var days = countDays(visitForm.actVisitDate.value,visitForm.actVisitDateTo.value);
		
		days = (days - count)+1;
	 
		
 	 	if(days>31)
		{
		  alert("E-1013: The report can be generated for a maximum of one month only.");
	      visitForm.actVisitDateTo.select();
	      visitForm.actVisitDateTo.focus();
	      return ;
		} 			
		//Added by David for CR#3563  ends here

			visitForm.subaction.value="searchMaintainPage";
			visitForm.submit();
		}

//Added by David for CR#3563 starts here

function countDays (str1,str2)

      {

            var temp1 = str1.split("/");

            var temp2 = str2.split("/");

            //Set the two dates

            var date1=new Date(temp1[0],temp1[1]-1,temp1[2]); //Month is 0-11 in JavaScript

            var date2=new Date(temp2[0],temp2[1]-1,temp2[2]); //Month is 0-11 in JavaScript

            

            //Set 1 day in milliseconds

            var one_day=1000*60*60*24;

             

            //Calculate difference btw the two dates, and convert to days

            var days = Math.ceil((date2.getTime()-date1.getTime())/(one_day));

            //alert(days);

            return (days);

      }
      
function checkLeapYear(str1,str2)
{
	var count = 0;
	var temp1 = str1.split("/");
    var temp2 = str2.split("/");
    var year1 = temp1[0];
    var year2 = temp2[0];
    
    if(temp1[1]==1 || (temp1[1]==2 && temp1[2]!=29))
    {
		if(( ( year1%4 == 0 ) && ( year1 % 100 != 0)) ||( year1 %400 == 0)) //leap year checking
		{
		    count++;
		}
	}
	if(temp2[1]>2 || (temp2[1]==2 && temp2[2]==29))
    {
		if(( ( year2%4 == 0 ) && ( year2 % 100 != 0)) ||( year2 %400 == 0)) //leap year checking
		{
		    count++;
		}
	}
    
    return (count);
}

//Added by David for CR#3563 ends here

function checkIsDigit(str1)
{
	var num=/^([0-9]+|\d+.\d{1,2})$/;
	var vnum = "a";
	
	var num1=/^(\d.\d{3})$/;
	var vnum1 = "a";
	
	

		
	if(str1.value != ""){
	vnum = num.exec(str1.value);
	vnum1 = num1.exec(str1.value);
	}
	if(!vnum)
	{
		if(vnum1)
		{
			alert("E-5139: Commission Percentage can contain only 2 digits after decimal");
			str1.select();
			str1.focus();
			return(false);
		}
		else
		{
			alert("E-5137: Commission Percentage can contain only numbers .");
			str1.select();
			str1.focus();
			return(false);
		}
		
	}
	else
		return(true);
}

function checkValue(str1)
{
	if (str1.value > 99.99)
	{
		alert("E-5138: Commission percentage should less than 100");
		str1.select();
		str1.focus();
		return(false);
	}
	else
		return(true);
}

// To validate segment details

function submitSegmentPage()
{
		
		//Validation for TACode
		
		var taCode = document.commForm['commBean.taCode'].value;
		
		if (taCode == -1)
		{
			alert('E-6802: Select a valid TA Code');
			document.commForm['commBean.taCode'].focus();
			return false;
		}

		//Validation for SegmentCode
		
		var segmentCodeValue = document.commForm['commBean.segmentCode'].value;
		var blankSegmentCode = isBlankValue(document.commForm['commBean.segmentCode'].value, "Segment Code");


		if (!blankSegmentCode)
		{
			document.commForm['commBean.segmentCode'].focus();
			return false;
		}
		else
		{
			var segment = /^\w+$/;
			var vsegmentCode = segment.exec(document.commForm['commBean.segmentCode'].value);
			if(!vsegmentCode)
			{
				alert("E-6803: Segment code cannot contain special characters.");
				document.commForm['commBean.segmentCode'].select();
				document.commForm['commBean.segmentCode'].focus();
			    	return false;
			}
			document.commForm['commBean.segmentCode'].value = document.commForm['commBean.segmentCode'].value.toUpperCase();
			
		}


	//Validation for Segment Name
	
	var segmentName = document.commForm['commBean.segmentName'].value;
	if (!isBlank(document.commForm['commBean.segmentName'],"","n"))
	{
		var vSegmentName = nam.exec(document.commForm['commBean.segmentName'].value);
		if(!vSegmentName)
		{
			alert("E-6805: Segment Name should contain alphabets only.");
			document.commForm['commBean.segmentName'].select();
			document.commForm['commBean.segmentName'].focus();
		    return false;
		}
	}
	
	
		document.commForm.action="segment.do?subaction=createSegmentConfirm";
		document.commForm.submit();
	
	return true;

}	

// To clear segment details

function clearSegment()
{
	//document.commForm.reset();
	document.commForm['commBean.taCode'].value = -1  ;
	document.commForm['commBean.segmentCode'].value = "";
	document.commForm['commBean.segmentName'].value = "";
	document.commForm['commBean.taCode'].focus();
	return;
}
function getSegmentCodes()
{	
		document.branchForm.action="branchAction.do?subaction=createBranch&from=select";
		document.branchForm.submit();
		
}

// To update a segment 
function updateSegment() {
		var segmentCode = trim(document.all['modifiedSegmentCode'].value);
		var prevSegmentCode = trim(document.all['prevSegmentCode'].value);
		var modifiedSegmentCode = trim(document.all['modifiedSegmentCode'].value);
		
			
		//Validation for Segment Name
			
		var segmentName = document.commForm['commBean.segmentName'].value;
		if (!isBlank(document.commForm['commBean.segmentName'],"","n"))
		{
			var vSegmentName = nam.exec(document.commForm['commBean.segmentName'].value);
			if(!vSegmentName)
			{
				alert("E-6805: Segment Name should contain alphabets only.");
				document.commForm['commBean.segmentName'].select();
				document.commForm['commBean.segmentName'].focus();
			   	return false;
			}
		}
	
		
		commForm.action="segment.do?subaction=updateSegment&modify=true&prevSegmentCode="+prevSegmentCode+"&modifiedSegmentCode="+modifiedSegmentCode;
		commForm.submit();
		return true;
	
	}
// To delete a segment
	function deleteSegment() {
		if(window.confirm("Do you want to delete ?"))
		{
			commForm.action="segment.do?subaction=updateSegment&delete=true";
			commForm.submit();
		}
	}