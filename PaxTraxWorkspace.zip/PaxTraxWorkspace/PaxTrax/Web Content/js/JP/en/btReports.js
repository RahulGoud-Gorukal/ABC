var printItem = null;

function deliverySubmit(form)
{
	if(form.truckNumber.value=="-1")	
	{
		alert("E-4199:Select a valid truck.");
		return;
	}
	deliveryManifestForm.action = "deliveryManifest.do?subaction=getDeliveryManifest";
	deliveryManifestForm.submit();
}

var printDelivery = null;

function deliveryManifestPrint()
{
	if (confirm("E-4200: Truck status will be changed to InTransit.Do you want to continue?"))
	{
	printDelivery = window.open('deliveryManifest.do?subaction=printDeliveryManifest',"deliveryManifest","width=1000,height=650,toolbar=no,scrollbars=yes,status=no,titlebar=no,menubar=no,resizable=yes,top=1,left=1");
	}
}



function ltrim(s)
{
	return s.replace( /^\s*/, "" )
}

function rtrim(s)
{
	return s.replace( /\s*$/, "" );
}

function trim(s)
{
	return rtrim(ltrim(s));
}


function isNotEmpty(str1,label,prompt)
{
	var returnValue = true;
	var checkString = trim(str1.value);
	
	if(checkString == "")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-4201: " + label + " cannot be empty");
			str1.select();
			str1.focus();
			returnValue = false;
		}
				
	}
	
return(returnValue);
}

function trimObject(obj)
{
	obj.value=trim(obj.value);
	return true;
}

function itemEnquiryGo(form)
{
	var returnVal = false;

	if(isNotEmpty(form.itemNumber,'Item Number','Y'))
	{
		var itemNum = /^\d*$/;
		if(itemNum.exec(form.itemNumber.value))
		{
			returnVal = true;
			form.action.value="itemTrackingInquiryAction.do";
			form.subaction.value="getItemTrackingInquiry";
			form.submit();	
		}
		else
		{
			alert("E-4202: Item Number can only be numeric");
			form.itemNumber.select();
			form.itemNumber.focus();
			returnVal = false;
		}
				
	 }
	return returnVal;
	
}

var stockPrint;
function stockAtPickupSubmit()
{
	stockAtPickupLocation.action = "stockAtPickupLocation.do?subaction=getStockAtPickupLocationInquiry";
	stockAtPickupLocation.submit();
}

function stockAtPickupPrint()
{
	stockPrint = window.open('stockAtPickupLocation.do?subaction=printStockAtPickupLocationInquiry','stock','scrollbars=yes');		
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}

function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function bagStatusByFlightSubmit()
{
	if(bagStatusByFlight.airlineCode.value == "-1")
	{
		alert("E-1300: Select an airline code.");
		bagStatusByFlight.airlineCode.value='-1';
		bagStatusByFlight.airlineCode.focus();
		return;
	}

	if (isBlank(bagStatusByFlight.flightNumber,"Flight Number","y"))
		return;
		
	var flight = /^\d+$/;
	var vflight = flight.exec(bagStatusByFlight.flightNumber.value);
	if (!vflight)
	{
		alert("E-4203: Flight Number should be numeric.");
		bagStatusByFlight.flightNumber.select();
		bagStatusByFlight.flightNumber.focus();
		return;
	}

	if (bagStatusByFlight.flightNumber.value.length < 3)		
	{
		alert("E-4204: Flight Number length should be between 3 and 5");		
		bagStatusByFlight.flightNumber.select();
		bagStatusByFlight.flightNumber.focus();
		return;
	}
	
	if (isBlank(bagStatusByFlight.departureDate,"Departure Date","y"))
		return;

	if(!validateDate(bagStatusByFlight.departureDate,"yyyy/mm/dd","Departure Date","y"))		
		return;
		
	bagStatusByFlight.action = "bagStatusByFlight.do?subaction=getBagStatusByFlightInquiry";
	bagStatusByFlight.submit();
}


function isBlank(str1,label,prompt)
{
	if(str1.value == "")
	{
		if(prompt == "y" || prompt == "Y")
		{
			alert("E-4205: "+ label + " cannot be empty.");
			str1.focus();
		}

		return(true);		
	}

	return(false);
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat == "yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag = true;
		}
		
		if(!flag)
		{
			if(prompt == "y")
			{
				alert("E-4206: " + label + " is invalid. Expected date format is " + dateformat+".");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <= 0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <= 0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon == 1 || mon == 3 || mon == 5 || mon == 7 || mon == 8 || mon == 10 || mon == 12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag == true && mon != 2 && day1 == 31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon == 2)  //If February
	{
		if(( ( year1%4 == 0 ) && ( year1 % 100 != 0)) ||( year1 %400 == 0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}


function bagNotReadySubmit(form)
{

if(form.airlineCode.value == "-1")
	{
	alert("E-1300: Select an airline code.");
	form.airlineCode.value='-1';
	form.airlineCode.focus();
	return;
	}
	if (isBlank(bagNotReadyForPickup.flightNumber,"Flight Number","y"))
		return;
		
	var flight = /^\d+$/;
	var vflight = flight.exec(bagNotReadyForPickup.flightNumber.value);
	if (!vflight)
	{
		alert("E-4207: Flight Number should be numeric.");
		bagNotReadyForPickup.flightNumber.select();
		bagNotReadyForPickup.flightNumber.focus();
		return;
	}

	if (bagNotReadyForPickup.flightNumber.value.length < 3)		
	{
		alert("E-4208: Flight Number length should be between 3 and 5");		
		bagNotReadyForPickup.flightNumber.select();
		bagNotReadyForPickup.flightNumber.focus();
		return;
	}
	
	if (isBlank(bagNotReadyForPickup.departureDate,"Departure Date","y"))
		return;

	if(!validateDate(bagNotReadyForPickup.departureDate,"yyyy/mm/dd","Departure Date","y"))		
		return;
		
	bagNotReadyForPickup.action = "bagNotReadyForPickup.do?subaction=getBagNotReadyForPickup";
	bagNotReadyForPickup.submit();
}

var cancellation = null;
function bagNotReadyCancel(bag)
{
	if(cancellation != null)
	{
		cancellation.close();
		cancellation=null;
	}
	cancellation = window.open('bagNotReadyForPickup.do?subaction=bagCancel&bagNumber='+bag,'bagcancel','width=400,height=250');
}

function bagCancellationSave(form)
{
document.forms[0].action="bagNotReadyForPickup.do?subaction=bagCancelSave";
document.forms[0].submit();

}

function bagCancellationOK()
{

opener.document.forms[0].action = "bagNotReadyForPickup.do?subaction=getBagNotReadyForPickup";
opener.document.forms[0].submit();
window.close();
}


function getCageReport(form)
{
		var cageNo=form.cageNo.value;
		var cageNumber=/^[\d]{3,3}$/;
		if(cageNo == "")
		{
			alert("E-4132: Cage number cannot be empty.");
			form.cageNo.focus();
			return ;
		}
		else  if(!cageNumber.exec(cageNo))
		{
			alert("E-4134: Cage number should be 3 digit numeric.");
			form.cageNo.select();
			form.cageNo.focus();
			return;
		}
		else
		{
			form.action = "cageReport.do";
			form.subaction.value ="getCageTrackingReport";
			form.submit();
		}
}

 function displayCarton() {

 if(document.forms[0].carton.value == "-1")
{
	alert("Select a valid carton.");
	return;
}
        var cartonNumber = document.all('cartonBean.cartonNumber').value;        
        document.forms[0].action = "cartonTrackingAction.do?subaction=displayCartonDetails&cartonNumber="+cartonNumber;
        document.forms[0].submit();
    }
    
  
  
  
  function validateField(object, label, prompt, regularExpr, msg)
{
	
	var returnValue = true;
	returnValue=isNotEmpty(object,label,prompt);
	if(returnValue)
	{	
		
		var validated=regularExpr.exec(object.value);
		
		if(!validated)
		{
			alert(msg);
			object.select();
			object.focus();
			returnValue = false;
		}
	}
	return(returnValue)	;
}
  
    
function missingBagEnquiry(form)
{

	
	if((validateDate(form.fromDate,"yyyy/mm/dd","From Departure Date","y")) && (validateDate(form.toDate,"yyyy/mm/dd","To Departure Date","y") ))
	{
		form.action="missingBagsEnquiry.do?subaction=getMissingBagDetails";
		form.submit();
	}
}   

function saveMissingBagEnquiry(form, remarks, bagFound, position)
{
	var valid = false;
	
	if (document.all(bagFound).checked) {
		valid = true;
	}
	
	if (!valid && trim(document.all(remarks).value).length == 0) {
		valid = false;
	} else {
		valid = true;
	}
	
	
	if((validateDate(form.fromDate,"yyyy/mm/dd","From Departure Date","y")) && (validateDate(form.toDate,"yyyy/mm/dd","To Departure Date","y") ))
	{
		if (!valid) {
			alert('Please enter remarks or select bag found');
			return;
		} else {
			if (trim(document.all(remarks).value).length > 100) {
				alert('Remarks can be of 100 characters only');
				return;
			}
		}
		
		form.action="missingBagsEnquiry.do?subaction=saveMissingBagDetails&index="+position;
		form.submit();
	}
}  


function submitPage(myForm, formAction) {

	if (myForm.skuTransferDate.value.length == 0) {
		
		alert('E:4200: Please give a valid date');
		return;
	}
	
	if(myForm.skuTransferDate.value!="")
	{
		if(!validateDate(myForm.skuTransferDate,"yyyy/mm/dd","Date","y"))
		{
			myForm.skuTransferDate.focus();
			return(false);
		}		
	}

	
	var todaysdate = new Date();
    	var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	
	var transferdate = strconvert(myForm.skuTransferDate.value);
	if (transferdate > todaydate) {
		alert("E-3125: Transfer date should be less than or equal to current date.");
		return (false);
	}

	myForm.action=formAction;
	myForm.submit();
}


function openPrintPage(url, windowName)
{

	if(printItem ==null)
	{
		printItem = window.open(url,windowName,"width=1000,height=650,toolbar=no,scrollbars=yes,status=no,titlebar=no,menubar=no,resizable=yes,top=1,left=1");
	}
	else
	{
		printItem.close();
		printItem = null;
		printItem = window.open(url,windowName,"width=1000,height=650,toolbar=no,scrollbars=yes,status=no,titlebar=no,menubar=no,resizable=yes,top=1,left=1");
	}
	return;

}

function formatDateOnBlur(date1)
{

	if(date1.value!="")
	{
		if(validateDate(date1,"yyyy/mm/dd"," ","n"))
			date1.value = strconvert(date1.value);
	}
}

function strconvert(str1)
{
	var temp = str1.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}

/* Added on June 06, 2007 for CR 251-260 changes Begin*/
function bagByBagStatusSubmit()
{
	if(bagByBagStatusForm.bagCode.value == "-1")
	{
		alert("E-4209: Select a bag status.");
		bagByBagStatusForm.bagCode.value='-1';
		bagByBagStatusForm.bagCode.focus();
		return;
	}
	
	if (isBlank(bagByBagStatusForm.departureDate,"Departure Date","y"))
		return;
		
	if(!validateDate(bagByBagStatusForm.departureDate,"yyyy/mm/dd","Departure Date","y"))		
		return;		

	bagByBagStatusForm.action = "bagByBagStatusAction.do?subaction=getBagByBagStatusReport";
	bagByBagStatusForm.submit();
}

function bagStatusByLocationSubmit()
{
	if (isBlank(bagStatusByLocationForm.departureDate,"Departure Date","y"))
		return;
		
	if(!validateDate(bagStatusByLocationForm.departureDate,"yyyy/mm/dd","Departure Date","y"))		
		return;		

	bagStatusByLocationForm.action = "bagStatusByLocation.do?subaction=getBagStatusByLocation";
	bagStatusByLocationForm.submit();
}

/* Added on June 06, 2007 for CR 251-260 changes End*/

/* Added on July 30, 2007 for CR 261 changes Begin*/
function submitRefundedBagPage()
{
	if(isBlank(tracingRefundedBagForm.refundedDate,"Refunded Date","y"))
		return;
		
	if(!validateDate(tracingRefundedBagForm.refundedDate,"yyyy/mm/dd","Refunded Date","y"))		
		return;	
		
	if(tracingRefundedBagForm.intl.checked)
	{
		tracingRefundedBagForm.intlChk.value="Y";
	}
	else
	{
		tracingRefundedBagForm.intlChk.value="N";		
	}
	if(tracingRefundedBagForm.preorder.checked)
	{
		tracingRefundedBagForm.preorderChk.value="Y";
	}
	else
	{
		tracingRefundedBagForm.preorderChk.value="N";		
	}		
				
	tracingRefundedBagForm.action = "tracingRefundedBagsAction.do?subaction=getRefundedBagsDetails";
	tracingRefundedBagForm.submit();
}

function receiveBagsAtGalleria()
{
	var c = false;
	var len = tracingRefundedBagForm.chkBox.length;
	if (len == null)
	{
		if (tracingRefundedBagForm.chkBox.checked)
			c = true;
	}
	else
	{
		for (var i = 0;i < len;i++)
		{
			if (tracingRefundedBagForm.chkBox[i].checked)
			{
				c= true;
				break;
			}
				
		}
	}
	
	if (!c)
	{
		alert("E-2144: Select a bag to be received in Galleria.");
		return;
	}
	if(tracingRefundedBagForm.intl.checked)
	{
		tracingRefundedBagForm.intlChk.value="Y";
	}
	else
	{
		tracingRefundedBagForm.intlChk.value="N";		
	}
	if(tracingRefundedBagForm.preorder.checked)
	{
		tracingRefundedBagForm.preorderChk.value="Y";
	}
	else
	{
		tracingRefundedBagForm.preorderChk.value="N";		
	}	
	tracingRefundedBagForm.action = "tracingRefundedBagsAction.do?subaction=receiveBagsInGalleria";
	tracingRefundedBagForm.submit();	
}
/* Added on July 30, 2007 for CR 261 changes End*/
