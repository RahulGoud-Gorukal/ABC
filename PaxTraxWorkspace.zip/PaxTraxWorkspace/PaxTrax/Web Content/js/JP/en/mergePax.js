function validateMergePaxSubmit() {
	var fromPax = trim(document.all('naccsSearchBean.fromPAXNo').value);
	var toPax = trim(document.all('naccsSearchBean.toPAXNo').value);
	if (fromPax.length == 0) {
		alert("From PAX cannot be empty");
		document.all('naccsSearchBean.fromPAXNo').focus();
		return false;
	}
	if (toPax.length == 0) {
		alert("To PAX cannot be empty");
		document.all('naccsSearchBean.toPAXNo').focus();
		return false;
	}
	
	if (fromPax == toPax) {
		alert("From PAX cannot be equal to To PAX");
		return false;
	}
	naccsDuplicatePaxReportForm.action="naccsDuplicatePaxReportAction.do?subaction=naccsMergePaxReport";
	naccsDuplicatePaxReportForm.submit();
}

function trim(inputString)
{
	if (typeof inputString != "string")
	{ 
		return inputString;
	}
	var retValue = inputString;
	var ch = retValue.substring(0, 1);
	while (ch == " ")
	{
	      retValue = retValue.substring(1, retValue.length);
	      ch = retValue.substring(0, 1);
	}
	ch = retValue.substring(retValue.length-1, retValue.length);
	while (ch == " ")
	{
     		retValue = retValue.substring(0, retValue.length-1);
		 ch = retValue.substring(retValue.length-1, retValue.length);
	}
   	while (retValue.indexOf("  ") != -1)
	{
	      retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ")+1, retValue.length);
	      
	}
	return retValue; 
}

function languageToggle(url)
{
	naccsDuplicatePaxReportForm.action = url;
	naccsDuplicatePaxReportForm.submit();
}