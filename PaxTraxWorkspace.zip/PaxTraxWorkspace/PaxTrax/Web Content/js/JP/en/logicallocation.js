function assignLocation() 
{	
	var selected = false;
	var sourceLength = locationForm.availableLocations.length;
	var destinationLength = locationForm.addedLocations.length;
	var source = eval(locationForm.availableLocations);
	var destination = eval(locationForm.addedLocations);

	if((sourceLength == null) || (sourceLength == 0))
	{
		alert("E-1208: All the available locations are assigned.");
		return;
	}

	for(var i = 0; i < sourceLength; i++)
	{
		if ((source.options[i] != null) && (source.options[i].selected))
		{
			selected = true;
			destination.options[destinationLength] = new Option(source.options[i].text,source.options[i].value);
			destinationLength++;
		}
	}

	if(selected == false)
	{
		alert("E-1209: Select the location from the available location list.");
		return;
	}

	for(var i = (sourceLength-1); i >= 0; i--)
	{
		if ((source.options[i] != null) && (source.options[i].selected == true))
		{
			source.options[i] = null;
		}
	}
}

function assignAllLocations()
{
	var sourceLength = locationForm.availableLocations.length;
	var destinationLength = locationForm.addedLocations.length;
	var source = eval(locationForm.availableLocations);
	var destination = eval(locationForm.addedLocations);

	if((sourceLength == null) || (sourceLength == 0))
	{
		alert("E-1208: All the available locations are assigned.");
		return;
	}

	for(var i = 0; i < sourceLength; i++)
	{
		if (source.options[i] != null) 
		{
			destination.options[destinationLength] = new Option(source.options[i].text,source.options[i].value);
			destinationLength++;
		}
	}

	for(var i=0; i < sourceLength; i++)
	{
		source.options[0] = null;
	}
}

function unassignLocation() 
{	
	var selected = false;
	var sourceLength = locationForm.availableLocations.length;
	var destinationLength = locationForm.addedLocations.length;
	var source = eval(locationForm.availableLocations);
	var destination = eval(locationForm.addedLocations);

	if((destinationLength == null) || (destinationLength == 0))
	{
		alert("E-1210: All the added locations are removed.");
		return;
	}

	for(var i = 0; i < destinationLength; i++)
	{
		if ((destination.options[i] != null) && (destination.options[i].selected))
		{
			selected = true;
			source.options[sourceLength] = new Option(destination.options[i].text,destination.options[i].value);
			sourceLength++;
		}
	}

	if(selected == false)
	{
		alert("E-1211: Select the location from the added location list.");
		return;
	}

	for(var i = (destinationLength-1); i >= 0; i--)
	{
		if ((destination.options[i] != null) && (destination.options[i].selected == true))
		{
			destination.options[i] = null;
		}
	}
}

function unassignAllLocations()
{
	var sourceLength = locationForm.availableLocations.length;
	var destinationLength = locationForm.addedLocations.length;
	var source = eval(locationForm.availableLocations);
	var destination = eval(locationForm.addedLocations);

	if((destinationLength == null) || (destinationLength == 0))
	{
		alert("E-1210: All the added locations are removed.");
		return;
	}

	for(var i = 0; i < destinationLength; i++)
	{
		if (destination.options[i] != null) 
		{
			source.options[sourceLength] = new Option(destination.options[i].text,destination.options[i].value);
			sourceLength++;
		}
	}

	for(var i=0; i < destinationLength; i++)
	{
		destination.options[0] = null;
	}
}

function startup()
{
var len = locationForm.availableLocations.length;
for (var i = 0;i < len;i++)
{
	locationForm.availableLocations.options[i].selected = false;
}
var len = locationForm.addedLocations.length;
for (var i = 0;i < len;i++)
{
	locationForm.addedLocations.options[i].selected = false;
}
}

function selectAvailableAddLocations()
{
	var length = locationForm.availableLocations.length;
	if(length != null)
	{
		for(var i = 0; i < length; i++)
		{
			if (locationForm.availableLocations.options[i] != null) 
			{
				locationForm.availableLocations.options[i].selected = true;				
			}
		}	
	}

	var length = locationForm.addedLocations.length;
	if(length != null)
	{
		for(var i = 0; i < length; i++)
		{
			if (locationForm.addedLocations.options[i] != null) 
			{
				locationForm.addedLocations.options[i].selected = true;				
			}
		}	
	}
}

function saveLogicalLocation()
{
	if(!(validateLocation() && validateLocationDesc()))
	{
		return ;
	}
	
	var length = locationForm.addedLocations.length;
	if (length == 0 || length == null)
	{
		alert("E-1212: Select location from the available list");
		locationForm.availableLocations.focus();
		return;
	}
	selectAvailableAddLocations();
	locationForm.action = "locationAction.do?subaction=saveLogicalLocation";	
	locationForm.submit();
}

function getLogLocation()
{
	if (window.event.keyCode == 9)
	{
		locationForm.location.value=trim(locationForm.location.value);
		if (!isBlank(locationForm.location,"","n"))
		{
			if(!validateLocation())
			{
				locationForm.locationCheck.value = "y";
				return;
			}
			locationForm.action = "locationAction.do?subaction=getLogicalLocation";
			locationForm.submit();		
		}
	}
}

function locBlur()
{
	if (locationForm.locationCheck.value == "y")
	{
		locationForm.location.select();
		locationForm.location.focus();
		locationForm.locationCheck.value = "";
	}
}

function logicalLocationEnable()
{
	locationForm.location.disabled = true;
	locationForm.locationDesc.disabled = false;
	locationForm.availableLocations.disabled = false;
	locationForm.addedLocations.disabled = false;
	locationForm.all("navend").disabled = false;
	locationForm.all("navnext").disabled = false;
	locationForm.all("navprev").disabled = false;
	locationForm.all("navstart").disabled = false;
	locationForm.all("save").style.display = "";
	locationForm.all("delete").style.display = "";
	locationForm.locationDesc.focus();
}

function updateLogicalLocation()
{
	if(!validateLocationDesc())
	{
		return ;
	}
	
	var length = locationForm.addedLocations.length;
	if (length == 0 || length == null)
	{
		alert("E-1212: Select location from the available list");
		locationForm.availableLocations.focus();
		return;
	}
	selectAvailableAddLocations();
	locationForm.action = "locationAction.do?subaction=updateLogicalLocation";	
	locationForm.submit();
}

function deletePrompt()
{
	if(confirm("Do you want to delete"))
	{
		document.locationForm.action="locationAction.do?subaction=removeLogicalLocation";
		selectAvailableAddLocations();
		document.locationForm.submit();
	}
	else
	{
		return ;
	}
}

function logicalLocationCancel()
{
	if ((locationForm.fromPage.value == "null") || (locationForm.fromPage.value == "maintainLogicalLocation"))
		locationForm.action="home.do?subaction=adminHomePage";

	if (locationForm.fromPage.value == "searchLogicalLocation")
	{
		var frompageno = locationForm.fromPageNumber.value;
		locationForm.action="searchLocation.do?subaction=searchLogicalLocation&pageNumber="+frompageno;
	}
	selectAvailableAddLocations();
	locationForm.submit();
}


function logicalLocationConfirm()
{
	if (locationForm.fromPage.value == "null")
		locationForm.action="home.do?subaction=adminHomePage";
	if (locationForm.fromPage.value == "maintainLogicalLocation")
		locationForm.action="locationAction.do?subaction=maintainLogicalLocationPage";
	if (locationForm.fromPage.value == "searchLogicalLocation")
	{
		var frompageno = locationForm.fromPageNumber.value;
		locationForm.action="searchLocation.do?subaction=searchLogicalLocation&pageNumber="+frompageno;
	}
	locationForm.submit();
}