function languageToggle(url)
{
	bagOverrideForm.action = url;
	bagOverrideForm.submit();
}

function assignAirportSubmit() {
	var bagnumber = document.all('bagBean.bagNumber');
	var binlocation = document.all('bagBean.apBinLocation');
	if (validate()) {
		if(confirm("Bagnumber "+ bagnumber.value +" will be associated to Ap Bin "+binlocation.value +".\nDo you want to continue ?"))
		bagOverrideForm.submit();
		else
		{
			document.forms[0].bagNumber.select();		
			document.forms[0].bagNumber.focus();
			return;
		}
		
	}
}

	function validate()
	{
		var bagnumber = document.all('bagBean.bagNumber');
		var binlocation = document.all('bagBean.apBinLocation');
		if (trim(bagnumber.value).length == 0)
		{
			alert('E-5205: BagNumber cannot be empty');
			
			document.forms[0].bagNumber.focus();
			return false;
		}
		else
		{
			
			if (!validatebagNumber(bagnumber)) 
			{
			
				document.forms[0].bagNumber.select();		
				document.forms[0].bagNumber.focus();
				return false;
			} 
			else 
			{
			
				if (trim(binlocation.value).length == 0)
				{
					alert('E-5205: Ap binlocation cannot be empty');
			
					document.forms[0].apBin.focus();
					return false;
				}
				else
				{
			
					if (validateBinLocation(binlocation)) 
					{
						return true;
					}
					else
					{
						document.forms[0].apBin.select();		
						document.forms[0].apBin.focus();
						return false;
					}
				}
			}
			
		}
	}

function cancel() {
	bagOverrideForm.action="home.do?subaction=bagtrackingHomePage";
	bagOverrideForm.submit();
}

function trim(inputString)
{
	if (typeof inputString != "string")
	{ 
		return inputString;
	}
	var retValue = inputString;
	var ch = retValue.substring(0, 1);
	while (ch == " ")
	{
	      retValue = retValue.substring(1, retValue.length);
	      ch = retValue.substring(0, 1);
	}
	ch = retValue.substring(retValue.length-1, retValue.length);
	while (ch == " ")
	{
     		retValue = retValue.substring(0, retValue.length-1);
		 ch = retValue.substring(retValue.length-1, retValue.length);
	}
   	while (retValue.indexOf("  ") != -1)
	{
	      retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ")+1, retValue.length);
	      
	}
	return retValue; 
}

function validatebagNumber(bagNumber)
{
	var bag =/^\d{12,12}$/;
	var vbag = bag.exec(bagNumber.value);
	
	if(!vbag)
	{
		alert("E-5205: Bag number should be 12 digit numeric.");
		bagNumber.select();
		bagNumber.focus();
		return(false);
	}		

	return(true);
}

function validateBinLocation(binLocation) {
	var bin = /^[A-Z a-z]{2}\d{2}$/;
	alert(binLocation);
	var vbin = bin.exec(binLocation.value);
	if (!vbin) {
		alert("E-4100: Bin location format should be AL93");
		return false;
	} else {
		return true;
	}
}

function assignWareHouseSubmit() {
    
   var bagnumber = document.all('bagBean.bagNumber')
   	if (trim(bagnumber.value).length == 0)
	{
			alert('E-5205: BagNumber cannot be empty');
			document.forms[0].bagNumber.focus();
			return;
	}
	if (!validatebagNumber(bagnumber)) 
	{
			
		document.forms[0].bagNumber.select();		
		document.forms[0].bagNumber.focus();
		return ;
	} 
	
    var checkbox = document.all('bagBean.truck');
    var truckNo = checkbox.options[checkbox.selectedIndex].text;
    if (checkbox.selectedIndex > 0) 
    {
    	if(confirm("Bagnumber "+ bagnumber.value +" will be associated to Truck number "+truckNo +".\nDo you want to continue ?"))
    		bagOverrideForm.submit();
    	else
    	{
	    	document.forms[0].bagNumber.select();		
			document.forms[0].bagNumber.focus();
					return;
    	}	
    }
    else
    {
    	alert('Please select a truck');
    	document.forms[0].truck.focus();
    	return;
    }
    
    
}

function validatebagNumberforChangeStatus()
{

	var bag =/^\d{12,12}$/;	
	var bagnumber = document.forms[0].bagNumber;
	var vbag = bag.exec(bagnumber.value);

	if (trim(bagnumber.value).length == 0)
	{
		alert('E-5205: Bag Number cannot be empty');
		document.forms[0].bagNumber.focus();
		return;
	}

	if(!vbag)
	{
		alert('E-5205: Bag number should be 12 digit numeric.');
		document.forms[0].bagNumber.select();
		document.forms[0].bagNumber.focus();
		return;
	}		

	var confirm = window.confirm("Do you want to change the status of the transaction '"+bagnumber.value+"' ?");

	if(confirm)
		bagOverrideForm.submit();
	else
		document.forms[0].bagNumber.select();
		document.forms[0].bagNumber.focus();		
}


//Added by selvam for CA# 294102 starts

// Added/Modified by David for CR 3659 starts
function bagLookUp() {

	//var paxnumber = document.all('bagBean.paxNumber');
	

		if(document.forms[0].paxNumber.value!="")
		{
			if(validatepaxNumber())
			{

				document.forms[0].method="POST";
				document.forms[0].action="bagOverrideAction.do?subaction=bagLookUp";
				bagOverrideForm.submit();
			}
		}
		else
		{
			alert("E-5205: PAX number cannot be empty.");
			bagOverrideForm.paxNumber.focus();
		}

}
		function releaseBagSubmit(index) {

	document.forms[0].bagNumber.value = "" ;
	

		if(document.forms[0].paxNumber.value!="")
		{
			//if(validatepaxNumber())
			//{
					if(confirm("Bag will be moved to Picked by Customer "  +".\nDo you want to continue ?"))
					{
				bagOverrideForm.index.value = index;
				document.forms[0].method="POST";
				document.forms[0].action="bagOverrideAction.do?subaction=releaseBags";
				bagOverrideForm.submit();
					}
				else
				{
				bagOverrideForm.paxNumber.select();
				bagOverrideForm.paxNumber.focus();
				return;
				}
			//}
		}
		else
		{
			alert("E-5205: PAX number cannot be empty.");
			bagOverrideForm.paxNumber.focus();
			return;
		}
}

	function releaseBagSubmit1() {

	
		

		if(document.forms[0].paxNumber.value!="")
		{
			if(validatepaxNumber())
			{
				if(validatebagNumber())
				{
					if(confirm("Bag will be moved to Picked by Customer "  +".\nDo you want to continue ?"))
					{
				
				
					document.forms[0].method="POST";
					document.forms[0].action="bagOverrideAction.do?subaction=releaseBags";
					bagOverrideForm.submit();
					}
					else
					{
					bagOverrideForm.bagNumber.select();
					bagOverrideForm.bagNumber.focus();
					return;
					}
				}
			}
		}
		else
		{
			alert("E-5205: PAX number cannot be empty.");
			bagOverrideForm.paxNumber.focus();
			return;
		}
}		

function assignSeaBin() {
//	var bagnumber = document.all('bagBean.bagNumber');
	
 
     var checkbox = document.all('bagBean.truck');
    var truckNo = checkbox.options[checkbox.selectedIndex].text;
    	var binlocation = document.all('bagBean.apBinLocation');
    if (checkbox.selectedIndex > 0) 
    {

    if (trim(binlocation.value).length == 0)
				{
					alert('E-5215: Sea binlocation cannot be empty');
			
					document.forms[0].apBin.focus();
		 return;
				}
				else
				{
			
					var bin = /^[A-Z a-z]{2}\d{2}$/;
	var exec = bin.exec(binlocation.value);
	if (!exec) {
		alert("E-4100: Bin location format should be AL93");
		document.forms[0].apBin.select();	
			return  ;
		}
					 
				}
				
		if(confirm("Cages in the truck will be Assigned to Sea bin"  +".\nDo you want to continue ?"))
    		bagOverrideForm.submit();
    	else
    	{
	    document.forms[0].truck.focus();
					return;
    	}	
    }
    else
    {
    	alert('Please select a truck');
    	document.forms[0].truck.focus();
    	return ;
    }
    		
     
	 
}


	function validatebagNumber()
	{
		var bag =/^\d{12,12}$/;
		var vbag = bag.exec(document.forms[0].bagNumber.value);
		
		if(!vbag)
		{
			alert("E-5205: Bag number should be 12 digit numeric.");
			document.forms[0].bagNumber.select();
			document.forms[0].bagNumber.focus();
			return(false);
		}		

		return(true);
	}	
	function validatepaxNumber()
{
	var paxn=/^[0-9]+$/;
	var vpaxn=paxn.exec(document.forms[0].paxNumber.value);

	if(!vpaxn)
	{
		window.alert("E-2100: PAX number can only contain numbers.");
		document.forms[0].paxNumber.select();
		document.forms[0].paxNumber.focus();
		return(false);
	}

	if(!checklength(document.forms[0].paxNumber,10,"PAX Number","digits","y"))
		return(false);
	
	if(document.forms[0].paxNumber.value == "0000000000")
	{
		alert("E-2101: Enter a valid PAX number.");
		document.forms[0].paxNumber.select();
		document.forms[0].paxNumber.focus();
		return(false);
	}

	return(true);

}
function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-2103: " + label + " should have " + len + " " + type+".");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}
//Added by selvam for CA# 294102 ends
// Added/Modified by David for CR 3659 ends
