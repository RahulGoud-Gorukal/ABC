// Flight Module's functions

function submitForm()
{
	var airlinecode = document.flightForm.airlineCode.options.value;
	var flightNumber = document.flightForm.flightNumber.value;
	var submitFlag = true;
	var key = window.event.keyCode;
	if(key == "9")
	{
		if(airlinecode == "0")
		{
			alert("E-1300: Select an airline code.");
			submitFlag = false;
		}		
		if (trim(flightNumber)=="" && submitFlag)
		{
			window.alert("E-1301: Flight number cannot be empty.");
			document.flightForm.flightNumber.focus();
			submitFlag = false;
		}	
		else
		{	
			var flightnumber = /^\d{1,5}$/ ;
			var flNumber=flightnumber.exec(document.flightForm.flightNumber.value);
			if(!flNumber && submitFlag)
			{
			window.alert("E-1302: Flight number should be numeric.");
			document.flightForm.flightNumber.select();
			document.flightForm.flightNumber.focus();
			submitFlag = false;
			}
			if(flightNumber.length < 3 && submitFlag)
			{
				alert("E-1303: Flight number length should be between 3 and 5.");
				submitFlag = false;
			}
		}	
		if(submitFlag)
		{
		document.flightForm.subaction.value = "loadFlightDetails";
		document.flightForm.action = "flightAction.do";
		document.flightForm.submit();
		}
	}
}
function clear()
{
	document.flightForm.subaction.value = "createFlightPage";
	document.flightForm.action = "flightAction.do";
	document.flightForm.submit();	

/*	document.flightForm.airlineCode.options.value = "0";
	document.flightForm.flightNumber.value = "";
	document.flightForm.originAirport.options.value	= "0";
	document.flightForm.destinationAirport.options.value = "0";
	document.flightForm.flightType.options.value = "1";
	document.flightForm.pickupLocation.options.value = "0";	
	document.flightForm.flightDate.value = "";
	document.flightForm.isDailyCheckBox.checked = false;
	document.flightForm.isMonCheckBox.checked = false;
	document.flightForm.isTueCheckBox.checked = false;
	document.flightForm.isWedCheckBox.checked = false;
	document.flightForm.isThuCheckBox.checked = false;
	document.flightForm.isFriCheckBox.checked = false;
	document.flightForm.isSatCheckBox.checked = false;
	document.flightForm.isSunCheckBox.checked = false;
	document.flightForm.isDailyCheckBox.disabled = false;
	document.flightForm.isMonCheckBox.disabled=false;
    document.flightForm.isTueCheckBox.disabled=false;
    document.flightForm.isWedCheckBox.disabled=false;
    document.flightForm.isThuCheckBox.disabled=false;
    document.flightForm.isFriCheckBox.disabled=false;
    document.flightForm.isSatCheckBox.disabled=false;
    document.flightForm.isSunCheckBox.disabled=false;	
    document.flightForm.dailyTimeInHr.disabled=true;		
	document.flightForm.dailyTimeInMin.disabled=true;
	document.flightForm.monTimeInHr.disabled=true;		
	document.flightForm.monTimeInMin.disabled=true;
	document.flightForm.tueTimeInHr.disabled=true;				
	document.flightForm.tueTimeInMin.disabled=true;	
	document.flightForm.wedTimeInHr.disabled=true;				
	document.flightForm.wedTimeInMin.disabled=true;	
	document.flightForm.thuTimeInHr.disabled=true;				
	document.flightForm.thuTimeInMin.disabled=true;	
	document.flightForm.friTimeInHr.disabled=true;				
	document.flightForm.friTimeInMin.disabled=true;		
	document.flightForm.satTimeInHr.disabled=true;				
	document.flightForm.satTimeInMin.disabled=true;	
	document.flightForm.sunTimeInHr.disabled=true;				
	document.flightForm.sunTimeInMin.disabled=true;			
	document.flightForm.dateTimeInHr.disabled=true;				
	document.flightForm.dateTimeInMin.disabled=true;
	document.flightForm.dailyTimeInHr.options.value = "00";			
	document.flightForm.dailyTimeInMin.options.value = "00";
	document.flightForm.monTimeInHr.options.value = "00";
	document.flightForm.tueTimeInHr.options.value = "00";			
	document.flightForm.wedTimeInHr.options.value = "00";			
	document.flightForm.thuTimeInHr.options.value = "00";			
	document.flightForm.friTimeInHr.options.value = "00";			
	document.flightForm.satTimeInHr.options.value = "00";															
	document.flightForm.sunTimeInHr.options.value = "00";				
	document.flightForm.monTimeInMin.options.value = "00";	
	document.flightForm.tueTimeInMin.options.value = "00";	
	document.flightForm.wedTimeInMin.options.value = "00";	
	document.flightForm.thuTimeInMin.options.value = "00";	
	document.flightForm.friTimeInMin.options.value = "00";	
	document.flightForm.satTimeInMin.options.value = "00";	
	document.flightForm.sunTimeInMin.options.value = "00";
	document.flightForm.dateTimeInHr.options.value = "00";			
	document.flightForm.dateTimeInMin.options.value = "00";		
	document.flightForm.hrFlightCutOffTime.options.value = "00";			
	document.flightForm.minFlightCutOffTime.options.value = "00";									*/
}
function checksubmit(page)
{
	var todaysdate = new Date();
	var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	var todaytime = "";
	if(todaysdate.getHours() < 10)
		hours = "0"+todaysdate.getHours();
	else
		hours = todaysdate.getHours();
	if(todaysdate.getMinutes() < 10)
		minutes = "0"+todaysdate.getMinutes();
	else
		minutes = todaysdate.getMinutes();
		
	todaytime = hours+":"+minutes;
		
	var flightTime = document.flightForm.dateTimeInHr.value+":"+document.flightForm.dateTimeInMin.value;
	var airlinecode = document.flightForm.airlineCode.options.value;
	var flightNumber = document.flightForm.flightNumber.value;
	var originAirport = document.flightForm.originAirport.options.value;
	var destinationAirport = document.flightForm.destinationAirport.options.value;
	var pickupLocation = document.flightForm.pickupLocation.options.value;
	var flightType = document.flightForm.flightType.options.value;	
	var flightDate = document.flightForm.flightDate.value;
	var vesselMode = document.flightForm.isVesselMode.value;
	var submitFlag = true;
	if(document.flightForm.isDailyCheckBox.checked)
		document.flightForm.dailyCheckBox.value = "true";
	else
		document.flightForm.dailyCheckBox.value = "false";
	if(document.flightForm.isSunCheckBox.checked)
		document.flightForm.sunCheckBox.value = "true";
	else
		document.flightForm.sunCheckBox.value = "false";			
	if(document.flightForm.isMonCheckBox.checked)
		document.flightForm.monCheckBox.value = "true";
	else
		document.flightForm.monCheckBox.value = "false";
	if(document.flightForm.isTueCheckBox.checked)
		document.flightForm.tueCheckBox.value = "true";
	else
		document.flightForm.tueCheckBox.value = "false";
	if(document.flightForm.isWedCheckBox.checked)
		document.flightForm.wedCheckBox.value = "true";
	else
		document.flightForm.wedCheckBox.value = "false";
	if(document.flightForm.isThuCheckBox.checked)
		document.flightForm.thuCheckBox.value = "true";
	else
		document.flightForm.thuCheckBox.value = "false";
	if(document.flightForm.isFriCheckBox.checked)
		document.flightForm.friCheckBox.value = "true";
	else
		document.flightForm.friCheckBox.value = "false";
	if(document.flightForm.isSatCheckBox.checked)
		document.flightForm.satCheckBox.value = "true";
	else
		document.flightForm.satCheckBox.value = "false";			

	if(page == "Delete")
	{
		var confirm = window.confirm("Do you want to delete");		
		if(!confirm)
			submitFlag = false;	
	}	
	if(page != "Delete" && page != "Home")
	{
			if(airlinecode == "0" && submitFlag)
			{
				alert("E-1304: Select an airline code.");		
				document.flightForm.airlineCode.focus();
				submitFlag = false;
			}		
			if (trim(flightNumber)=="" && submitFlag)
			{
				window.alert("E-1305: Flight number cannot be empty.");
				document.flightForm.flightNumber.value="";
				document.flightForm.flightNumber.focus();
				submitFlag = false;
			}	
			else
			{	
				var flightnumber = /^\d{1,5}$/ ;
				
				var flNumber=flightnumber.exec(document.flightForm.flightNumber.value);
				if(!flNumber && submitFlag)
				{
					window.alert("E-1306: Flight number should be numeric.");
					document.flightForm.flightNumber.select();
					document.flightForm.flightNumber.focus();
					submitFlag = false;
				}
				if(flightNumber.length < 3 && submitFlag)
				{
					alert("E-1307: Flight number length should be between 3 and 5.");
					document.flightForm.flightNumber.select();
					document.flightForm.flightNumber.focus();	
					submitFlag = false;
				}
			}	
			if(originAirport == "0" && submitFlag)
			{
				alert("E-1308: Select origin airport.");
				document.flightForm.originAirport.focus();	
				submitFlag = false;
			}
			if(destinationAirport == "0" && submitFlag)
			{
				alert("E-1309: Select destination airport.");
				document.flightForm.destinationAirport.focus();	
				submitFlag = false;		
			}	
			if(originAirport != "0" && originAirport == destinationAirport && submitFlag)
			{
				alert("E-1310: Origin airport & destination airport cannot be same.");
				document.flightForm.destinationAirport.focus();	
				submitFlag = false;		
			}
			if(pickupLocation == "0" && submitFlag)
			{
				alert("E-1311: Select pickup location.");
				document.flightForm.pickupLocation.focus();	
				submitFlag = false;				
			}
			if(flightType == "2" && submitFlag)
			{
				var flightDate = document.flightForm.flightDate.value;
				if(flightDate == "")
				{
					alert("E-1312: Departure date cannot be empty for non scheduled flights.");
					document.flightForm.flightDate.select();
					document.flightForm.flightDate.focus();
					submitFlag = false;
				}
			}
			if(document.flightForm.flightDate.disabled == false && submitFlag)
			{
				if(!validateDate(flightForm.flightDate,"yyyy/mm/dd","Flight date","y"))		
				{
						submitFlag = false;
						document.flightForm.flightDate.select();
						document.flightForm.flightDate.focus();
				}
				else
				{
					var flightDate1 = strconvert(flightDate);		
				}
			}
			if((flightDate1 < todaydate) && submitFlag)
			{
				alert("E-1313: Flight date should be greater than or equal to current date.");
				document.flightForm.flightDate.select();
				document.flightForm.flightDate.focus();	
				submitFlag = false;
			}			
			if((flightTime <= todaytime) && (flightDate1 == todaydate) && submitFlag)
			{
				alert("E-1314: Flight time should be greater than current time.");
				document.flightForm.dateTimeInHr.focus();
				submitFlag = false;		
			}		
			if(flightType == "1" && submitFlag)
			{
				if(!document.flightForm.isDailyCheckBox.checked && !document.flightForm.isMonCheckBox.checked &&
				   !document.flightForm.isTueCheckBox.checked && !document.flightForm.isWedCheckBox.checked &&
				   !document.flightForm.isThuCheckBox.checked && !document.flightForm.isFriCheckBox.checked	&&
				   !document.flightForm.isSatCheckBox.checked && !document.flightForm.isSunCheckBox.checked	)
		 	   {
		 	   		alert("E-1315: Select atleast one day for flight schedule.");
					submitFlag = false;
		 	   }
			}
			
			//added for CA#290863 by vignesh starts here
			if((airlinecode!=52 && document.flightForm.isVesselMode.checked && submitFlag))
			{
				alert("E-1323: Select correct flight code (SP) for vessel type");
				document.flightForm.airlinecode.focus();
				submitFlag = false;
			}
			if(airlinecode==52 && !(document.flightForm.isVesselMode.checked)&& (submitFlag))
			{
				alert("E:1324: Select Vessel type");
				document.flightForm.isVesselMode.focus();
				submitFlag = false;
			}
			
			if(document.flightForm.isVesselMode.checked && trim(document.flightForm.vesselName.value) == "" && submitFlag)
			{
				alert("E-1325: Vessel name cannot be empty for vessel type");
				document.flightForm.vesselName.focus();
				submitFlag = false;
			}
			if(flightType == "1" && document.flightForm.isVesselMode.checked && submitFlag)
			{
				alert("E:1326 Flight type should be non-scheduled for Vessel type");
				document.flightForm.flightType.focus();
				submitFlag = false;
			}
			//added for CA#290863 by vignesh ends here
			
	}
	if(submitFlag)
	{
		if(document.flightForm.isDailyCheckBox.checked=false)
		document.flightForm.isDailyCheckBox.value = false;
		document.flightForm.action = "flightAction.do";
		if(page == "Create")
			document.flightForm.subaction.value = "saveFlight";	
		else if(page == "Maintain")
			document.flightForm.subaction.value = "updateFlight";	
		else if(page == "Delete")			
			document.flightForm.subaction.value = "removeFlight";	
		else if(page == "Home")
			document.flightForm.subaction.value = "cancelFlightPage";	
		document.flightForm.submit();	
	}	
}
function maintainSearch()
{
	document.flightForm.action = "searchFlightAction.do";
	document.flightForm.subaction.value = "searchFlightPage";		
	document.flightForm.submit();
}
function checkFlightDetails(checkedvalue)
{	
	if(!document.flightForm.isMonCheckBox.checked 
	&& !document.flightForm.isTueCheckBox.checked
	&& !document.flightForm.isWedCheckBox.checked
	&& !document.flightForm.isThuCheckBox.checked
	&& !document.flightForm.isFriCheckBox.checked
	&& !document.flightForm.isSatCheckBox.checked
	&& !document.flightForm.isSunCheckBox.checked)	
	{
		document.flightForm.isDailyCheckBox.disabled = false;		
	}
	if(checkedvalue == "daily")
	{
		if(document.flightForm.isDailyCheckBox.checked)
		{
		document.flightForm.dailyTimeInHr.disabled=false;		
		document.flightForm.dailyTimeInMin.disabled=false;
		document.flightForm.sunTimeInHr.disabled=true;		
		document.flightForm.sunTimeInMin.disabled=true;
		document.flightForm.monTimeInHr.disabled=true;		
		document.flightForm.monTimeInMin.disabled=true;
		document.flightForm.tueTimeInHr.disabled=true;		
		document.flightForm.tueTimeInMin.disabled=true;
		document.flightForm.wedTimeInHr.disabled=true;		
		document.flightForm.wedTimeInMin.disabled=true;
		document.flightForm.thuTimeInHr.disabled=true;		
		document.flightForm.thuTimeInMin.disabled=true;
		document.flightForm.friTimeInHr.disabled=true;		
		document.flightForm.friTimeInMin.disabled=true;
		document.flightForm.satTimeInHr.disabled=true;		
		document.flightForm.satTimeInMin.disabled=true;
	    document.flightForm.isMonCheckBox.disabled=true;
	    document.flightForm.isTueCheckBox.disabled=true;
	    document.flightForm.isWedCheckBox.disabled=true;
	    document.flightForm.isThuCheckBox.disabled=true;
	    document.flightForm.isFriCheckBox.disabled=true;
	    document.flightForm.isSatCheckBox.disabled=true;
	    document.flightForm.isSunCheckBox.disabled=true;		
   	    document.flightForm.isDailyCheckBox.checked = true;
	    document.flightForm.isSunCheckBox.checked = false;
	    document.flightForm.isMonCheckBox.checked = false;
	    document.flightForm.isTueCheckBox.checked = false;
	    document.flightForm.isWedCheckBox.checked = false;
	    document.flightForm.isThuCheckBox.checked = false;
	    document.flightForm.isFriCheckBox.checked = false;
	    document.flightForm.isSatCheckBox.checked = false;
		}
		else
		{
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.sunTimeInHr.disabled=true;		
		document.flightForm.sunTimeInMin.disabled=true;
		document.flightForm.monTimeInHr.disabled=true;		
		document.flightForm.monTimeInMin.disabled=true;
		document.flightForm.tueTimeInHr.disabled=true;		
		document.flightForm.tueTimeInMin.disabled=true;
		document.flightForm.wedTimeInHr.disabled=true;		
		document.flightForm.wedTimeInMin.disabled=true;
		document.flightForm.thuTimeInHr.disabled=true;		
		document.flightForm.thuTimeInMin.disabled=true;
		document.flightForm.friTimeInHr.disabled=true;		
		document.flightForm.friTimeInMin.disabled=true;
		document.flightForm.satTimeInHr.disabled=true;		
		document.flightForm.satTimeInMin.disabled=true;
		document.flightForm.isMonCheckBox.disabled=false;
	    document.flightForm.isTueCheckBox.disabled=false;
	    document.flightForm.isWedCheckBox.disabled=false;
	    document.flightForm.isThuCheckBox.disabled=false;
	    document.flightForm.isFriCheckBox.disabled=false;
	    document.flightForm.isSatCheckBox.disabled=false;
	    document.flightForm.isSunCheckBox.disabled=false;	
   	    document.flightForm.isDailyCheckBox.checked = false;
	    document.flightForm.isSunCheckBox.checked = false;
	    document.flightForm.isMonCheckBox.checked = false;
	    document.flightForm.isTueCheckBox.checked = false;
	    document.flightForm.isWedCheckBox.checked = false;
	    document.flightForm.isThuCheckBox.checked = false;
	    document.flightForm.isFriCheckBox.checked = false;
	    document.flightForm.isSatCheckBox.checked = false;

		}
	}
	else if(checkedvalue == "mon")
	{
		if(document.flightForm.isMonCheckBox.checked)
		{
		document.flightForm.monTimeInHr.disabled=false;		
		document.flightForm.monTimeInMin.disabled=false;
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isDailyCheckBox.disabled=true;		
		document.flightForm.isDailyCheckBox.checked=false;		
	    document.flightForm.isMonCheckBox.checked = true;			    
		}
		else
		{
		document.flightForm.monTimeInHr.disabled=true;		
		document.flightForm.monTimeInMin.disabled=true;
		document.flightForm.isMonCheckBox.checked = false;			    		
		}		
	}
	else if(checkedvalue == "tue")
	{
		if(document.flightForm.isTueCheckBox.checked)
		{
		document.flightForm.tueTimeInHr.disabled=false;				
		document.flightForm.tueTimeInMin.disabled=false;
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isDailyCheckBox.checked=false;			
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isTueCheckBox.checked=true;			
		}
		else
		{
		document.flightForm.tueTimeInHr.disabled=true;				
		document.flightForm.tueTimeInMin.disabled=true;
		document.flightForm.isTueCheckBox.checked = false;			    			
		}
	}
	else if(checkedvalue == "wed")
	{
		if(document.flightForm.isWedCheckBox.checked)
		{
		document.flightForm.wedTimeInHr.disabled=false;				
		document.flightForm.wedTimeInMin.disabled=false;
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isDailyCheckBox.checked=false;			
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isWedCheckBox.checked=true;			
		}
		else
		{
		document.flightForm.wedTimeInHr.disabled=true;				
		document.flightForm.wedTimeInMin.disabled=true;
		document.flightForm.isWedCheckBox.checked = false;			    			
		}
	}
	else if(checkedvalue == "thu")
	{
		if(document.flightForm.isThuCheckBox.checked)
		{
		document.flightForm.thuTimeInHr.disabled=false;				
		document.flightForm.thuTimeInMin.disabled=false;
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isDailyCheckBox.checked=false;			
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isThuCheckBox.checked=true;			
		}
		else
		{
		document.flightForm.thuTimeInHr.disabled=true;				
		document.flightForm.thuTimeInMin.disabled=true;
		document.flightForm.isThuCheckBox.checked = false;			    			
		}
	}
	else if(checkedvalue == "fri")
	{
		if(document.flightForm.isFriCheckBox.checked)
		{
		document.flightForm.friTimeInHr.disabled=false;				
		document.flightForm.friTimeInMin.disabled=false;
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isDailyCheckBox.checked=false;			
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isFriCheckBox.checked=true;			
		}
		else
		{
		document.flightForm.friTimeInHr.disabled=true;				
		document.flightForm.friTimeInMin.disabled=true;
		document.flightForm.isFriCheckBox.checked = false;			    			
		}
	}
	else if(checkedvalue == "sat")
	{
		if(document.flightForm.isSatCheckBox.checked)
		{
		document.flightForm.satTimeInHr.disabled=false;				
		document.flightForm.satTimeInMin.disabled=false;
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isDailyCheckBox.checked=false;			
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isSatCheckBox.checked=true;			
		}
		else
		{
		document.flightForm.satTimeInHr.disabled=true;				
		document.flightForm.satTimeInMin.disabled=true;
		document.flightForm.isSatCheckBox.checked = false;			    			
		}
	}
	else if(checkedvalue == "sun")	
	{
		if(document.flightForm.isSunCheckBox.checked)
		{
		document.flightForm.sunTimeInHr.disabled=false;				
		document.flightForm.sunTimeInMin.disabled=false;
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isDailyCheckBox.checked=false;			
		document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.isSunCheckBox.checked=true;			
		}
		else
		{
		document.flightForm.sunTimeInHr.disabled=true;				
		document.flightForm.sunTimeInMin.disabled=true;
		document.flightForm.isSunCheckBox.checked = false;			    			
		}
	}
}

function changeFlightType()
{
    var flightType = document.flightForm.flightType.options.value    
    if(flightType == 2)
    {      	
	    document.flightForm.flightDate.disabled=false;	    
	    document.flightForm.dateTimeInHr.disabled=false;
	    document.flightForm.dateTimeInMin.disabled=false;    
	    document.flightForm.isDailyCheckBox.checked = false;
	    document.flightForm.isSunCheckBox.checked = false;
	    document.flightForm.isMonCheckBox.checked = false;
	    document.flightForm.isTueCheckBox.checked = false;
	    document.flightForm.isWedCheckBox.checked = false;
	    document.flightForm.isThuCheckBox.checked = false;
	    document.flightForm.isFriCheckBox.checked = false;
	    document.flightForm.isSatCheckBox.checked = false;
	    document.flightForm.isDailyCheckBox.disabled=true;
	    document.flightForm.isMonCheckBox.disabled=true;
	    document.flightForm.isTueCheckBox.disabled=true;
	    document.flightForm.isWedCheckBox.disabled=true;
	    document.flightForm.isThuCheckBox.disabled=true;
	    document.flightForm.isFriCheckBox.disabled=true;
	    document.flightForm.isSatCheckBox.disabled=true;
	    document.flightForm.isSunCheckBox.disabled=true;
	    document.flightForm.dailyTimeInHr.disabled=true;		
		document.flightForm.dailyTimeInMin.disabled=true;
		document.flightForm.sunTimeInHr.disabled=true;		
		document.flightForm.sunTimeInMin.disabled=true;
	    document.flightForm.monTimeInHr.disabled=true;		
		document.flightForm.monTimeInMin.disabled=true;
	    document.flightForm.tueTimeInHr.disabled=true;		
		document.flightForm.tueTimeInMin.disabled=true;
		document.flightForm.wedTimeInHr.disabled=true;		
		document.flightForm.wedTimeInMin.disabled=true;
		document.flightForm.thuTimeInHr.disabled=true;		
		document.flightForm.thuTimeInMin.disabled=true;	    
		document.flightForm.friTimeInHr.disabled=true;		
		document.flightForm.friTimeInMin.disabled=true;
		document.flightForm.satTimeInHr.disabled=true;		
		document.flightForm.satTimeInMin.disabled=true;
		document.flightForm.dailyTimeInHr.options.value = "00";			
		document.flightForm.dailyTimeInMin.options.value = "00";
		document.flightForm.monTimeInHr.options.value = "00";
		document.flightForm.tueTimeInHr.options.value = "00";			
		document.flightForm.wedTimeInHr.options.value = "00";			
		document.flightForm.thuTimeInHr.options.value = "00";			
		document.flightForm.friTimeInHr.options.value = "00";			
		document.flightForm.satTimeInHr.options.value = "00";															
		document.flightForm.sunTimeInHr.options.value = "00";				
		document.flightForm.monTimeInMin.options.value = "00";	
		document.flightForm.tueTimeInMin.options.value = "00";	
		document.flightForm.wedTimeInMin.options.value = "00";	
		document.flightForm.thuTimeInMin.options.value = "00";	
		document.flightForm.friTimeInMin.options.value = "00";	
		document.flightForm.satTimeInMin.options.value = "00";	
		document.flightForm.sunTimeInMin.options.value = "00";

	    var calendardepdate = document.all("calendardepdate");	  
	    calendardepdate.disabled=false;
    } 
    else if(flightType==1)
    {
    	document.flightForm.flightDate.value="";
		document.flightForm.flightDate.disabled=true;
	    document.flightForm.dateTimeInHr.disabled=true;
	    document.flightForm.dateTimeInMin.disabled=true;    
		document.flightForm.dateTimeInHr.options.value = "00";			
		document.flightForm.dateTimeInMin.options.value = "00";	    
	    document.flightForm.isDailyCheckBox.disabled=false;
	    document.flightForm.isMonCheckBox.disabled=false;
	    document.flightForm.isTueCheckBox.disabled=false;
	    document.flightForm.isWedCheckBox.disabled=false;
	    document.flightForm.isThuCheckBox.disabled=false;
	    document.flightForm.isFriCheckBox.disabled=false;
	    document.flightForm.isSatCheckBox.disabled=false;
	    document.flightForm.isSunCheckBox.disabled=false;    
   	    var calendardepdate = document.all("calendardepdate");
	    calendardepdate.disabled=true;
   	}    
}
function enabledisable(page,type)
{	
	if(page == "create")
	{
		if(type == "1" || type == "Scheduled Flights")
		{
		document.flightForm.airlineCode.focus();
		//document.flightForm.flightNumber.select();
		//document.flightForm.flightNumber.focus();
		document.flightForm.flightDate.disabled = true;
		var calendardepdate = document.all("calendardepdate");
		document.flightForm.flightType.value = "1";
		calendardepdate.disabled = true;
		document.flightForm.isDailyCheckBox.disabled=false;
		document.flightForm.isSunCheckBox.disabled=false;
		document.flightForm.isMonCheckBox.disabled=false;
		document.flightForm.isTueCheckBox.disabled=false;
		document.flightForm.isWedCheckBox.disabled=false;
		document.flightForm.isThuCheckBox.disabled=false;
		document.flightForm.isFriCheckBox.disabled=false;
		document.flightForm.isSatCheckBox.disabled=false;	
		}
		else if(type=="2" || type == "Non Scheduled Flights")
		{
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isSunCheckBox.disabled=true;
		document.flightForm.isMonCheckBox.disabled=true;
		document.flightForm.isTueCheckBox.disabled=true;
		document.flightForm.isWedCheckBox.disabled=true;
		document.flightForm.isThuCheckBox.disabled=true;
		document.flightForm.isFriCheckBox.disabled=true;
		document.flightForm.isSatCheckBox.disabled=true;
		//document.flightForm.flightNumber.select();
		//document.flightForm.flightNumber.focus();
		document.flightForm.airlineCode.focus();
		document.flightForm.flightDate.disabled = false;
		document.flightForm.flightType.value = "2";
		var calendardepdate = document.all("calendardepdate");
		calendardepdate.disabled = false;		
		}
	}
	if(page == "update" || page == "maintain")
	{
		/*Modified on 28th June 2006 - 
		*SR 1042 International DF Sale */
		document.flightForm.isInternational.disabled=true;
		document.flightForm.originAirport.disabled=true;
		document.flightForm.destinationAirport.disabled=true;
		document.flightForm.pickupLocation.disabled=true;							
		document.flightForm.departure[0].disabled = true;	
		document.flightForm.departure[1].disabled = true;	
		document.flightForm.hrFlightCutOffTime.disabled=true;		
		document.flightForm.minFlightCutOffTime.disabled=true;		
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isSunCheckBox.disabled=true;
		document.flightForm.isMonCheckBox.disabled=true;
		document.flightForm.isTueCheckBox.disabled=true;
		document.flightForm.isWedCheckBox.disabled=true;
		document.flightForm.isThuCheckBox.disabled=true;
		document.flightForm.isFriCheckBox.disabled=true;
		document.flightForm.isSatCheckBox.disabled=true;
		document.flightForm.flightDate.disabled = true;
		var calendardepdate = document.all("calendardepdate");
		calendardepdate.disabled = true;
	}
	else if(page == "failure")
	{
		if(type == "1")
		{
			var calendardepdate = document.all("calendardepdate");
			calendardepdate.disabled = true;
			document.flightForm.flightDate.disabled = true;
			document.flightForm.dateTimeInHr.disabled = true;	
			document.flightForm.dateTimeInMin.disabled = true;	
		}
		else
		{
			var calendardepdate = document.all("calendardepdate");
			calendardepdate.disabled = false;
			document.flightForm.flightDate.disabled = false;
			document.flightForm.dateTimeInHr.disabled = false;	
			document.flightForm.dateTimeInMin.disabled = false;	
		}		
		document.flightForm.airlineCode.disabled=false;	
		document.flightForm.flightNumber.disabled = false;
		/*Modified on 28th June 2006 - 
		*SR 1042 International DF Sale */
		document.flightForm.isInternational.disabled=true;
		document.flightForm.originAirport.disabled=true;
		document.flightForm.destinationAirport.disabled=true;
		document.flightForm.pickupLocation.disabled=true;							
		document.flightForm.flightType.disabled=true;
		document.flightForm.hrFlightCutOffTime.disabled=true;		
		document.flightForm.minFlightCutOffTime.disabled=true;	
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isSunCheckBox.disabled=true;
		document.flightForm.isMonCheckBox.disabled=true;
		document.flightForm.isTueCheckBox.disabled=true;
		document.flightForm.isWedCheckBox.disabled=true;
		document.flightForm.isThuCheckBox.disabled=true;
		document.flightForm.isFriCheckBox.disabled=true;
		document.flightForm.isSatCheckBox.disabled=true;	
		//document.flightForm.flightNumber.select();
		//document.flightForm.flightNumber.focus();
		document.flightForm.airlineCode.focus();
	}
	else if(page == "updateSearch")
	{
		/*Modified on 28th June 2006 - 
		*SR 1042 International DF Sale */
		document.flightForm.isInternational.disabled=true;
		if(type == "1")
		{
			document.flightForm.flightDate.value="";
			document.flightForm.flightDate.disabled=true;
		    document.flightForm.dateTimeInHr.disabled=true;
	    	document.flightForm.dateTimeInMin.disabled=true;    
			document.flightForm.dateTimeInHr.options.value = "00";			
			document.flightForm.dateTimeInMin.options.value = "00";	    				
			var calendardepdate = document.all("calendardepdate");
			calendardepdate.disabled = true;		
		}
		else if(type == "2")
		{
			document.flightForm.isDailyCheckBox.disabled=true;
		    document.flightForm.isMonCheckBox.disabled=true;
		    document.flightForm.isTueCheckBox.disabled=true;
		    document.flightForm.isWedCheckBox.disabled=true;
		    document.flightForm.isThuCheckBox.disabled=true;
		    document.flightForm.isFriCheckBox.disabled=true;
		    document.flightForm.isSatCheckBox.disabled=true;
		    document.flightForm.isSunCheckBox.disabled=true;
		    document.flightForm.dailyTimeInHr.disabled=true;		
			document.flightForm.dailyTimeInMin.disabled=true;
			document.flightForm.sunTimeInHr.disabled=true;		
			document.flightForm.sunTimeInMin.disabled=true;
		    document.flightForm.monTimeInHr.disabled=true;		
			document.flightForm.monTimeInMin.disabled=true;
		    document.flightForm.tueTimeInHr.disabled=true;		
			document.flightForm.tueTimeInMin.disabled=true;
			document.flightForm.wedTimeInHr.disabled=true;		
			document.flightForm.wedTimeInMin.disabled=true;
			document.flightForm.thuTimeInHr.disabled=true;		
			document.flightForm.thuTimeInMin.disabled=true;	    
			document.flightForm.friTimeInHr.disabled=true;		
			document.flightForm.friTimeInMin.disabled=true;
			document.flightForm.satTimeInHr.disabled=true;		
			document.flightForm.satTimeInMin.disabled=true;			
		}
		document.flightForm.airlineCode.disabled=true;	
		document.flightForm.flightNumber.disabled = true;
		document.flightForm.departure[0].disabled = true;	
		document.flightForm.departure[1].disabled = true;	
	}
	else if(page == "updateReload")
	{	
		/*Modified on 28th June 2006 - 
		*SR 1042 International DF Sale */
		document.flightForm.isInternational.disabled=true;
		document.flightForm.airlineCode.disabled=true;	
		document.flightForm.flightNumber.disabled = true;
		document.flightForm.departure[0].disabled = true;	
		document.flightForm.departure[1].disabled = true;	
		document.flightForm.originAirport.disabled=false;
		document.flightForm.destinationAirport.disabled=false;
		document.flightForm.pickupLocation.disabled=false;							
		document.flightForm.flightType.disabled=true;
		document.flightForm.hrFlightCutOffTime.disabled=false;		
		document.flightForm.minFlightCutOffTime.disabled=false;	
		changeFlightType();		
	}	
	else if(page == "updateDelete")
	{
		/*Modified on 28th June 2006 - 
		*SR 1042 International DF Sale */
		document.flightForm.isInternational.disabled=true;
		document.flightForm.originAirport.disabled=true;
		document.flightForm.destinationAirport.disabled=true;
		document.flightForm.pickupLocation.disabled=true;							
		document.flightForm.flightType.disabled=true;
		document.flightForm.hrFlightCutOffTime.disabled=true;		
		document.flightForm.minFlightCutOffTime.disabled=true;		
		document.flightForm.isDailyCheckBox.disabled=true;
		document.flightForm.isSunCheckBox.disabled=true;
		document.flightForm.isMonCheckBox.disabled=true;
		document.flightForm.isTueCheckBox.disabled=true;
		document.flightForm.isWedCheckBox.disabled=true;
		document.flightForm.isThuCheckBox.disabled=true;
		document.flightForm.isFriCheckBox.disabled=true;
		document.flightForm.isSatCheckBox.disabled=true;
		document.flightForm.flightDate.disabled = true;
		var calendardepdate = document.all("calendardepdate");
		calendardepdate.disabled = true;
		var save = document.all("save");
		save.disabled = true;
		var del = document.all("del");
		del.disabled = true;
		clear();	
	}	
}

function maintainsearch()
{
	var submitFlag = true;	
	var flightNumber = document.searchFlightForm.flightNumber.value;	
	if (trim(flightNumber)!="" && submitFlag)
	{		
		var flightnumber = /^\d{1,5}$/ ;	
		var flNumber=flightnumber.exec(document.searchFlightForm.flightNumber.value);
		if(!flNumber && submitFlag)
		{
		window.alert("E-1316: Flight number should be numeric.");
		document.searchFlightForm.flightNumber.select();
		document.searchFlightForm.flightNumber.focus();
		submitFlag = false;
		}		
	}
	if(submitFlag)
	{
		document.searchFlightForm.subaction.value = "searchFlightDetails";
		document.searchFlightForm.submit();
	}
}
function search()
{
	var todaysdate = new Date();
	var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	
	var submitFlag = true;
	var flightNumber = document.searchOverrideFlightForm.flightNumber.value;
	var flightDate = document.searchOverrideFlightForm.flightDate.value;
	if (trim(flightNumber)!="" && submitFlag)
	{		
		var flightnumber = /^\d{1,5}$/ ;		
		var flNumber=flightnumber.exec(document.searchOverrideFlightForm.flightNumber.value);
		if(!flNumber && submitFlag)
		{
		window.alert("E-1317: Flight number should be numeric.");
		document.searchOverrideFlightForm.flightNumber.select();
		document.searchOverrideFlightForm.flightNumber.focus();
		submitFlag = false;
		}	
	}				
	if(trim(flightDate) == "" && submitFlag)
	{
		alert("E-1318: Flight date cannot be empty.");
		document.searchOverrideFlightForm.flightDate.value="";
		document.searchOverrideFlightForm.flightDate.focus();
		submitFlag = false;
	}
	else
	{		
		if(!validateDate(searchOverrideFlightForm.flightDate,"yyyy/mm/dd","Flight date","y"))		
		{
				submitFlag = false;
				document.searchOverrideFlightForm.flightDate.select();
				document.searchOverrideFlightForm.flightDate.focus();
		}
		else
		{
			var flightDate1 = strconvert(flightDate);		
		}
	}
	if(flightDate1 < todaydate)
	{
		alert("E-1319: Override flight date should be greater than or equal to current date.");
		document.searchOverrideFlightForm.flightDate.select();
		document.searchOverrideFlightForm.flightDate.focus();	
		submitFlag = false;
	}		
	
	if(submitFlag)
	{
		document.searchOverrideFlightForm.subaction.value = "searchOverrideFlightDetails";
		document.searchOverrideFlightForm.submit();
	}
}

function submitOverrideForm()
{	
	var submitFlag=true;
	var todaysdate = new Date();
	var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	var todaytime = "";
	if(todaysdate.getHours() < 10)
		hours = "0"+todaysdate.getHours();
	else
		hours = todaysdate.getHours();
	if(todaysdate.getMinutes() < 10)
		minutes = "0"+todaysdate.getMinutes();
	else
		minutes = todaysdate.getMinutes();
		
	todaytime = hours+":"+minutes;

	var one  = document.all("one");		
	if(one.style.display != "none")
	{
		var flightOverrideDate = document.overrideFlightForm.flightOverrideDate.value;
		var flightOverrideTime = document.overrideFlightForm.overrideDateTimeInHr.value+":"+document.overrideFlightForm.overrideDateTimeInMin.value;
		if(trim(flightOverrideDate) == "" && submitFlag)
		{
			alert("E-1320: Flight override date cannot be empty.");
			document.overrideFlightForm.flightOverrideDate.focus();	
			submitFlag = false;
		}
		else
		{		
			if(!validateDate(overrideFlightForm.flightOverrideDate,"yyyy/mm/dd","Flight date","y"))		
			{
					submitFlag = false;
					document.overrideFlightForm.flightOverrideDate.select();
					document.overrideFlightForm.flightOverrideDate.focus();
			}
			else
			{
				var flightDate1 = strconvert(flightOverrideDate);		
			}
		}
		if((flightDate1 < todaydate) && submitFlag)
		{
			alert("E-1321: Override flight date should be greater than or equal to current date.");
			document.overrideFlightForm.flightOverrideDate.select();
			document.overrideFlightForm.flightOverrideDate.focus();	
			submitFlag = false;
		}
		if((flightOverrideTime <= todaytime) && (flightDate1 == todaydate) && submitFlag)
		{
			alert("E-1322: Override flight time should be greater than current time.");
			document.overrideFlightForm.overrideDateTimeInHr.focus();	
			submitFlag = false;		
		}		
	}	
	if(submitFlag)
	{
		document.overrideFlightForm.action ="overrideFlightAction.do";
		document.overrideFlightForm.subaction.value="saveOverrideFlightSchedule";
		document.overrideFlightForm.submit();	
	}
}
function removeOverride(status)
{
	var flag = false;
	document.overrideFlightForm.removeoverride.value = "true";
	var checkradio = document.all['cancelled'];
	if(checkradio[0].checked && status == "Overridden")
	{
		alert("Click on save to cancel this flight");
		flag = true;
	}
	if(!flag)
	{				
		var confirm = window.confirm("Do you want to override");
		if(confirm)
		{
			document.overrideFlightForm.action ="overrideFlightAction.do";
			document.overrideFlightForm.subaction.value="removeOverride";
			document.overrideFlightForm.submit();	
		}
	}
}
function showHidee(id){
	if(id==1)
	{
	var one  = document.all("one");
	one.style.display = "none";
	}
	else
	{
	var one  = document.all("one");
	one.style.display = "";
	}
}

function showHidee1(id){
	var one  = document.all("one");
	one.style.display = "";

}

function overrideFlightCancel()
{
	document.overrideFlightForm.action ="overrideFlightAction.do";
	document.overrideFlightForm.subaction.value="cancelOverrideFlightPage";
	document.overrideFlightForm.submit();	
}

function strconvert(str1)
{
	var temp = str1.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat == "yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag = true;
		}
		
		if(!flag)
		{
			if(prompt == "y")
			{
				alert("E-1323: "+ label + " is invalid. Expected date format is " + dateformat+".");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}

function massFlightSubmit(form)
{
	if(form.airlineCode.value=="-1")
	{
		alert("E-1300: Select an airline code.");
		return;
	}
	if (trim(form.flightNumber.value)=="" )
	{
		alert("E-1301: Flight number cannot be empty.");
		form.flightNumber.focus();
		return;
	}	
	var flightnumber = /^\d{1,5}$/ ;
	var flNumber=flightnumber.exec(form.flightNumber.value);
	if(!flNumber)
	{
		window.alert("E-1302: Flight number should be numeric.");
		form.flightNumber.select();
		form.flightNumber.focus();
		return;
	}
	if(!(validateDate(form.departureDate,"yyyy/mm/dd","Departure Date","y")))
	{		
		form.departureDate.select();
		return;
	}
	form.action = "overrideFlightAction.do?subaction=getPaxDetails";
	form.submit();
}




function massFlightChangeSave(form)
{
	/*var obj = document.getElementById("flightChange");
	var success = false;
	alert(obj.length)
	for(var i=0;i<obj.length;i++)
	{
		alert(obj[i].checked);
		if(obj[i].checked == true)
		{
			success	=true;
			break;
		}
	}
	if(success)
	{*/
		form.action = "overrideFlightAction.do?subaction=massFlightSave";
		form.submit();
	/*}
	else
	{
		alert("E-1303: Select the passenger to update the flight details");
		return;
	}*/
}
//added for CA#290863 by vignesh starts here
function vesselValidate()
{
	if(document.flightForm.isVesselMode.checked)
	{
		document.flightForm.vesselName.disabled=false;
	}
	else
	{
		document.flightForm.vesselName.value = ""
		document.flightForm.vesselName.disabled=true;
	}
}
//added for CA#290863 by vignesh ends here