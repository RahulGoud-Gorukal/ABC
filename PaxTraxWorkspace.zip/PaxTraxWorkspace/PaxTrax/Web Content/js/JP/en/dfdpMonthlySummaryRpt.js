//dfdpMonthlySummaryRpt.js

var printWindow;
function openPrintPage() {
	if(printWindow==null)
	{
		printWindow= window.open("./nabcoSummaryReportAction.do?subaction=printDFDPMonthlySummaryReport");
	}
	else
	{
		printWindow.close();
		printWindow=null;
		printWindow= window.open("./nabcoSummaryReportAction.do?subaction=printDFDPMonthlySummaryReport");
	}
}

function submitClickForm() {
	document.getElementById("nabcoProgress").innerHTML='Nabco Summary Report is in progress...';		
	stampDutyForm.submit();	
	stampDutyForm.submit();
}

function closePrintWindow() {
	if (printWindow != null) printWindow.close();
}
