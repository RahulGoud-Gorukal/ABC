var paxn=/^[0-9]+$/;
var totalCollapsibleMenuItems = 5;

function showHide(id)
{
	for (ctr=0; ctr<totalCollapsibleMenuItems; ctr++)
	 {
		var objectName = document.all ("CollapsibleMenuItem" + (ctr+1));
		if ((ctr+1) == id)
		{
			if(objectName.style.display == "")
			{
				objectName.style.display = "none" ;
			}
			else
			{
				objectName.style.display = "" ;
			}
		}
		else 
		{
		 	objectName.style.display = "none" ;
		}
	}

}



function spendlimit()
{
	
	var chk1 = eval("document.locationForm.isLimitTracking");
	if(chk1[1].checked)
	{
		document.locationForm.dutyFreeLimit.value = "";
		document.locationForm.dutyFreeLimit.disabled = true;
	}
	if(chk1[0].checked)
	{
		document.locationForm.dutyFreeLimit.disabled = false;
		document.locationForm.dutyFreeLimit.value = "";
		document.locationForm.dutyFreeLimit.focus();
	}
}

function changeLocationType()
{
	
	if(document.locationForm.locationType.length > 0)
	{
		var hiderows = document.all("hide1");
		var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
		var id= document.locationForm.locationType.selectedIndex;
		var arr =locationTypeHide.split("~");
		if(arr[id]=="Y")
		{
			hiderows[0].style.display="";
			hiderows[1].style.display="";
			hiderows[2].style.display="";
		}
		else
		{
			var isLimitTracking = eval("document.locationForm.isLimitTracking");
			isLimitTracking[0].checked=false;
			isLimitTracking[1].checked=false;	
			var isBagTracking = eval("document.locationForm.bagTracking");
			isBagTracking[0].checked=false;
			isBagTracking[1].checked=false;
			var autoPAXRequired = eval("document.locationForm.autoPAXRequired")
			autoPAXRequired[0].checked=false;
			autoPAXRequired[1].checked=false;
			document.locationForm.hrCutOffTime.value="00";
			document.locationForm.minCutOffTime.value="00";
			document.locationForm.dutyFreeLimit.value = "";
			document.locationForm.bondedWarehouseCode.value = "";
			hiderows[0].style.display="none";
			hiderows[1].style.display="none";
			hiderows[2].style.display="none";
		}
	}
}


function showHidee(id)
{
	var one  = document.all("one");
	one.style.display = "";
}
function security1()
{
	var one  = document.all("security");
	if(document.locationForm.select8.value=="Security")
		one.style.display = "none";
	else
		one.style.display = "";
}

function submitCheck()
{
	if(!(validateLocationType() && validateLocation() && validateLocationDesc() && validateIsAutoPaxRequired() && validateBondedWareHouse() && validateIsBagTracking()   && validateSpendLimitTracking() && validateDutyFreeLimit()  ))
	{
		return ;
	}
	else if(trim(document.locationForm.operation.value)=="create")
	{	
		document.locationForm.subaction.value="saveLocation";
	}
	else
	{
		document.locationForm.subaction.value="updateLocation";
	}
	
	
	document.locationForm.action="locationAction.do";
	document.locationForm.submit();
}

function validateLocation()
{
	var location=trim(document.locationForm.location.value);
	var locPattern=/^\d{1,4}$/;
	if(location=="")
	{
		alert("E-1100: Location cannot be empty.");
		document.locationForm.location.value="";
		document.locationForm.location.focus();
		return false;
	}
	else if(location == 0 )
	{
		alert("E-1101: Location cannot be zero.");
		document.locationForm.location.select();
		document.locationForm.location.focus();
		return false;
	}
	else if(!locPattern.exec(location))
	{
		alert("E-1102: Location should be numeric.");
		document.locationForm.location.select();
		document.locationForm.location.focus();
		return false;
	}
	else 
		return true;
}
function validateIsBagTracking()
{
	var chk1 = eval("document.locationForm.bagTracking");
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var id= document.locationForm.locationType.selectedIndex;
	var arr =locationTypeHide.split("~");
	if(chk1[0].checked || chk1[1].checked || arr[id]=="N")
	{
		return true;
	}
	else
	{
		alert("E-1103: Select bag tracking required.");
		chk1[0].focus();
		return false;
	}
}

function validateIsAutoPaxRequired()
{
	var chk1 = eval("document.locationForm.autoPAXRequired");
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var id= document.locationForm.locationType.selectedIndex;
	var arr =locationTypeHide.split("~");
	if(chk1[0].checked || chk1[1].checked || arr[id]=="N")
	{
		return true;
	}
	else
	{
		alert("E-1103: Select auto pax number required.");
		chk1[0].focus();
		return false;
	}
}

function validateBondedWareHouse()
{
	
	var id= document.locationForm.locationType.selectedIndex;
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var arr =locationTypeHide.split("~");
	document.locationForm.locationTypeSelected.value=arr[id];
	if(arr[id]=="N")
	{
		return true;
	}
	
	var bondedWareHouse=trim(document.locationForm.bondedWarehouseCode.value);
	var bondedWareHousePattern=/^\w+$/;
	if(bondedWareHouse=="")
	{
		alert("E-1100: Bonded warehouse code cannot be empty.");
		document.locationForm.bondedWarehouseCode.value="";
		document.locationForm.bondedWarehouseCode.focus();
		return false;
	}
	else if(!bondedWareHousePattern.exec(bondedWareHouse))
	{
		alert("E-1102: Special Characters are not allowed for bonded warehouse code.");
		document.locationForm.bondedWarehouseCode.select();
		document.locationForm.bondedWarehouseCode.focus();
		return false;
	}
	else 
		return true;
}

/*function validateIsOverideRefund()
{
	var chk1 = eval("document.locationForm.overrideRefund");
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var id= document.locationForm.locationType.selectedIndex;
	var arr =locationTypeHide.split("~");
	if(chk1[0].checked || chk1[1].checked || arr[id]=="N")
	{
		return true;
	}
	else
	{
		alert("Select Override Refund Required");
		chk1[0].focus();
		return false;
	}
}*/

function validateSpendLimitTracking()
{
	var chk1 = eval("document.locationForm.isLimitTracking");
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var id= document.locationForm.locationType.selectedIndex;
	var arr =locationTypeHide.split("~");
	if(chk1[0].checked || chk1[1].checked || arr[id]=="N")
	{
		return true;
	}
	else
	{
		alert("E-1104: Select spend limit tracking required.");
		chk1[0].focus();
		return false;
	}
}
function validateLocationDesc()
{
	var locationDesc=trim(document.locationForm.locationDesc.value);
	var locPattern=/^[\w\s]{1,25}$/;
	if(locationDesc=="")
	{
		alert("E-1105: Description cannot be empty.");
		document.locationForm.locationDesc.value="";
		
		document.locationForm.locationDesc.focus();
		return false;
	}
	else if(!locPattern.exec(locationDesc))
	{
		alert("E-1106: Special characters are not allowed for description.");
		document.locationForm.locationDesc.select();
		document.locationForm.locationDesc.focus();
		return false;
	}
	else
		return true;
}
function validateLocationType()
{
	if(document.locationForm.locationType.length < 1)
	{
		alert("E-1107: Reference data not available for location types.");
		return false;
	}
	else 
	return true;
}
/*function validateCutoffTime()
{
	var hrCutOffTime=trim(document.locationForm.hrCutOffTime.value);
	var minCutOffTime=trim(document.locationForm.minCutOffTime.value);
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var id= document.locationForm.locationType.selectedIndex;
	var arr =locationTypeHide.split("~");
	if(arr[id]=="N")
		return true;
	else if ((hrCutOffTime=="00") && (minCutOffTime=="00"))
	{
		alert("E-108: Cut off time cannot be zero");
		document.locationForm.hrCutOffTime.focus();
		return false;
	}
	else
	 return true;
}*/

function validateDutyFreeLimit()
{
	var dutyFreeLimit=trim(document.locationForm.dutyFreeLimit.value);
	var dutyFreeLimitPattern=/^[0-9]{1,10}$/;
	var chk1 = eval("document.locationForm.isLimitTracking");
	var flag=false;
	var locationTypeHide=trim(document.locationForm.locationTypeHide.value);
	var id= document.locationForm.locationType.selectedIndex;
	var arr =locationTypeHide.split("~");
	document.locationForm.locationTypeSelected.value=arr[id];
	
	if(arr[id]=="N")
	{
		return true;
	}
	else if(chk1[0].checked)
	{
		if(dutyFreeLimit=="")
		{
			alert("E-1108: Duty free spending limit cannot be empty.");
			document.locationForm.dutyFreeLimit.value="";
			document.locationForm.dutyFreeLimit.focus();
			return false;
		}
		else if(dutyFreeLimit==0)
		{
			alert("E-1109: Duty free spending limit cannot be zero.");
			document.locationForm.dutyFreeLimit.select();
			document.locationForm.dutyFreeLimit.focus();
	
			return false;
		}
		else if(!dutyFreeLimitPattern.exec(dutyFreeLimit))
		{
			alert("E-1110: Duty free spending limit should have only numeric values.");
			document.locationForm.dutyFreeLimit.select();
			document.locationForm.dutyFreeLimit.focus();
	
			return false;
		}
		else
			flag=true;
	}
	else
	{
	 document.locationForm.dutyFreeLimit.value="";
	 flag=true;
	}
	 
	 if(flag==false)
	 	{
	 		document.locationForm.dutyFreeLimit.select();
	 		document.locationForm.dutyFreeLimit.focus();
	 	}
	 return flag;
}


function deleteprompt()
{
	if(confirm("Do you want to delete ?"))
	{
		document.locationForm.subaction.value="removeLocation";
		document.locationForm.action="locationAction.do";
		document.locationForm.submit();
	}
	else
	{
		return ;
	}
}


/*function MM_popupMsg(msg)
{ 
	 alert("E-202: "+msg);
}
*/


function loadLocation()
{
	var keycode = window.event.keyCode;
	if(keycode==9 && (trim(document.locationForm.operation.value=="update") || trim(document.locationForm.operation.value=="updateDelete" )))
	{
		var locPattern=/^\d{0,4}$/;
		var location=document.locationForm.location.value; 
		if(location == "")
		{	
			document.locationForm.location.value="";
				
			return false;
		}
		else if(location==0)
		{
			alert("E-1111: Location cannot be zero.");
			document.locationForm.location.value="";
			document.locationForm.location.focus();
			return false;			 
		}
		else if(document.locationForm.locationType.length < 1)
		{
				alert("E-1112: Reference data not available for location type.");
				return true;
		}
		else if(!locPattern.exec(location))
		{
			alert("E-1113: Characters are not allowed for location.");
			document.locationForm.location.select();
			document.locationForm.location.focus();
			return false;
		}
		else
		{
			document.locationForm.action="locationAction.do";
			document.locationForm.subaction.value="loadLocation";
			document.locationForm.submit();
		}
		
	}	
	
}

function locationFocus()
{

document.locationForm.location.select();
document.locationForm.location.focus();
}


function locationFormOnload()
{
	
	if(trim(document.locationForm.operation.value=="updateReload") || trim(document.locationForm.operation.value=="updateSearch"))
	{
		document.locationForm.location.disabled=true;
		document.locationForm.locationDesc.disabled=false;
		document.locationForm.locationType.disabled=false;
		document.locationForm.hrCutOffTime.disabled=false;
		document.locationForm.minCutOffTime.disabled=false;
		var radioGrouplimitTracking=document.locationForm.isLimitTracking;
		radioGrouplimitTracking[0].disabled=false;
		radioGrouplimitTracking[1].disabled=false;
		
		var radioGroupBagTrack=document.locationForm.bagTracking;
		radioGroupBagTrack[0].disabled=false;
		radioGroupBagTrack[1].disabled=false;
		
		document.locationForm.bondedWarehouseCode.disabled=false;
		var radioGroupAutoPax=document.locationForm.autoPAXRequired;
		radioGroupAutoPax[0].disabled=false;
		radioGroupAutoPax[1].disabled=false;
		
		/*var radioGroupOverrideRefund=document.locationForm.overrideRefund;
		radioGroupOverrideRefund[0].disabled=false;
		radioGroupOverrideRefund[1].disabled=false;*/
		
		var chk1 = eval("document.locationForm.isLimitTracking");
		if(chk1[0].checked)
		document.locationForm.dutyFreeLimit.disabled=false;
		else
		document.locationForm.dutyFreeLimit.disabled=true;
		
		/*var btnSave=document.all("btnSave");
		btnSave.disabled=false;
		
		var btnDelete=document.all("btnDelete");
		btnDelete.disabled=false;
		
		var btnCancel=document.all("btnCancel");
		btnCancel.disabled=false;*/

		changeLocationType();
		
	}
	
	if(trim(document.locationForm.operation.value)=="update" || trim(document.locationForm.operation.value=="updateDelete"))
	{
		
		document.locationForm.location.disabled=false;
		document.locationForm.locationDesc.disabled=true;
		document.locationForm.locationType.disabled=true;
		document.locationForm.hrCutOffTime.disabled=true;
		document.locationForm.minCutOffTime.disabled=true;
		var radioGroup=document.locationForm.isLimitTracking;
		var radioGrouplimitTracking=document.locationForm.isLimitTracking;
		radioGrouplimitTracking[0].disabled=true;
		radioGrouplimitTracking[1].disabled=true;
		
		document.locationForm.dutyFreeLimit.disabled=true;
		document.locationForm.bondedWarehouseCode.disabled=true;
		
		var radioGroupBagTrack=document.locationForm.bagTracking;
		radioGroupBagTrack[0].disabled=true;
		radioGroupBagTrack[1].disabled=true;
		
		
		var radioGroupAutoPax=document.locationForm.autoPAXRequired;
		radioGroupAutoPax[0].disabled=true;
		radioGroupAutoPax[1].disabled=true;
		
		
		
		
		/*var radioGroupOverrideRefund=document.locationForm.overrideRefund;
		radioGroupOverrideRefund[0].disabled=true;
		radioGroupOverrideRefund[1].disabled=true;
		*/
		
		/*var btnSave=document.all("btnSave");
		btnSave.disabled=true;
		
		var btnDelete=document.all("btnDelete");
		btnDelete.disabled=true;
		
		var btnCancel=document.all("btnCancel");
		btnCancel.disabled=false;*/
		document.locationForm.dutyFreeLimit.value="";
		document.locationForm.location.select();
		document.locationForm.location.focus();
	}
	if(trim(document.locationForm.operation.value)=="create" )
	{
		document.locationForm.dutyFreeLimit.value="";
		
		changeLocationType();
		document.locationForm.location.select();
		document.locationForm.location.focus();
	}
	
	
	
}
 
 

function searchLocation()
{
	
	document.locationForm.action="searchLocation.do";
	document.locationForm.subaction.value="searchLocationPage";
	document.locationForm.submit();
	
}


function searchChangeLocationType()
{
	
	
	if(document.searchLocationForm.locationType.length > 0)
	{
	
		var hiderows = document.all("hide1");
	
		var locationTypeHide=trim(document.searchLocationForm.locationTypeHide.value);
		//alert(locationTypeHide);
		var id= document.searchLocationForm.locationType.selectedIndex;
	
		var arr =locationTypeHide.split("~");
	
		var i;
		//document.searchLocationForm.locationTypeHide.value = arr[id];
		for(i=0;i<hiderows.length;i++)
		{
			if(arr[id]=="Y")
			{
								
				hiderows[i].style.display="";
						
			}
			else
			{
				
				document.searchLocationForm.hrCutOffTime.value="00";
				document.searchLocationForm.minCutOffTime.value="00";	
				//document.searchLocationForm.dutyFreeLimit.value=0;
				hiderows[i].style.display="none";
			}
		}
	}
	document.searchLocationForm.location.focus();
}

function searchDisplay()
{
	if(validateSearchLocationType() && validateSearchLocation())
	{
		
		document.searchLocationForm.action="searchLocation.do";
		document.searchLocationForm.subaction.value="searchLocation";
		document.searchLocationForm.submit();
		
	}
	
}	


function displayEditLocation(location)
{
	document.searchLocationForm.subaction.value="loadLocation";
	document.searchLocationForm.action="locationAction.do?index="+location;
	document.searchLocationForm.submit();
}

function okAction()
{
	
	
	
	if(trim(document.locationForm.operation.value)=="updateSearch" || trim(document.locationForm.operation.value)=="updateDelete")
	{

		document.locationForm.action="searchLocation.do";
		document.locationForm.subaction.value="searchLocation";
		document.locationForm.submit();
	}
	else
	{
		document.locationForm.action="locationAction.do";
		document.locationForm.subaction.value="createLocationPage";
		document.locationForm.submit();
	}
}

function cancelAction(form)
{
	
	
	if(trim(form.operation.value)=="updateSearch" || trim(form.operation.value)=="updateDelete")
	{

		
		form.action="searchLocation.do";
		form.subaction.value="searchLocation";
		form.submit();
	}
	/*else if(trim(form.operation.value)=="updateReload" )
	{
		form.subaction.value="maintainLocationPage";
		form.action="locationAction.do";
		form.submit();
	}*/
	else
	{
		form.subaction.value="cancel";
		form.action="locationAction.do";
		form.submit();
	}
}

function clearContents(form)
{
	/*form.location.value="";
	form.locationDesc.value="";
	form.locationType.value="1";
	form.hrCutOffTime.value="00";
	form.minCutOffTime.value="00";
		var radioGrouplimitTracking=document.locationForm.isLimitTracking;
		radioGrouplimitTracking[0].checked=false;
		radioGrouplimitTracking[1].checked=false;
		
		var radioGroupBagTrack=document.locationForm.bagTracking;
		radioGroupBagTrack[0].checked=false;
		radioGroupBagTrack[1].checked=false;
		
		var radioGroupOverrideRefund=document.locationForm.overrideRefund;
		radioGroupOverrideRefund[0].checked=false;
		radioGroupOverrideRefund[1].checked=false;
	form.dutyFreeLimit.value="";
	changeLocationType();
	form.location.focus();*/
	
	form.action="locationAction.do";
	form.subaction.value="createLocationPage";
 	form.submit();
	
}

function changePasswordCancel(form)
{
 form.action="home.do";
 form.subaction.value="paxtraxHomePage"
 form.submit();
}

function validateSearchLocationType()
{
	if(document.searchLocationForm.locationType.length < 1)
	{
		alert("E-1114: Reference data not available for location type.")
		return false;
	}
	else
	return true;
}
function validateSearchLocation()
{
	var location=trim(document.searchLocationForm.location.value);
	var locPattern=/^\d{0,4}$/;
	
	if(!locPattern.exec(location))
	{
		alert("E-1115: Characters are not allowed for location.");
		document.searchLocationForm.location.select();
		document.searchLocationForm.location.focus();
		return false;
	}
	else
		return true;
}

function submitChangePassword()
{
var passPattern=/^\d+$/;
	
	if(trim(document.userForm.oldPassword.value)=="")
	{
		alert("E-1116: Old password cannot be empty.");
		document.userForm.oldPassword.value="";
		document.userForm.oldPassword.focus();
		return;
	}
	else if(trim(document.userForm.newPassword.value).length < 1)
	{
		alert("E-1117: New password cannot be empty.");
		document.userForm.newPassword.select();
		document.userForm.newPassword.focus();
		return;
	}
	else if(trim(document.userForm.confirmPassword.value).length < 1)
	{
		alert("E-1118: Confirm password cannot be empty.");
		document.userForm.confirmPassword.select();
		document.userForm.confirmPassword.focus();
		return;
	}
	
	else if(!passPattern.exec(document.userForm.newPassword.value))
	{
		alert("E-1121: Password should be numeric.");
		document.userForm.newPassword.select();
		document.userForm.newPassword.focus();
		return;
	}
	else if(trim(document.userForm.newPassword.value)!=trim(document.userForm.confirmPassword.value))	
	{
		alert("E-1119: New password and confirm password doesn't match.");
		document.userForm.newPassword.select();
		return;
	}
	else if(trim(document.userForm.newPassword.value) == trim(document.userForm.oldPassword.value))
	{
		alert("E-1120: Old password and the new password are the same.");
		document.userForm.confirmPassword.value="";
		document.userForm.newPassword.select();
		return;
	}
	else
	{ 
	
		document.userForm.action="userAction.do";
		document.userForm.subaction.value="changePassword";
		document.userForm.submit();
	}
}

function locationChangeLanguage(form,newLanguage,page,error)
{


//alert("inside locationChangeLanguage");
if(page == "create")
	form.action="locationAction.do?country=JP&language="+newLanguage+"&errorCode="+error;
else if(page=="password")	
	form.action="userAction.do?country=JP&language="+newLanguage+"&errorCode="+error;
else
	form.action="searchLocation.do?country=JP&language="+newLanguage+"&errorCode="+error+"&pageNumber="+page;
form.subaction.value="changeLanguage";
form.submit();

}

function trimObject(obj)
{
	obj.value=trim(obj.value);
	return true;
}


function trim(inputString)
{
	if (typeof inputString != "string")
	{ 
		return inputString;
	}
	var retValue = inputString;
	var ch = retValue.substring(0, 1);
	while (ch == " ")
	{
	      retValue = retValue.substring(1, retValue.length);
	      ch = retValue.substring(0, 1);
	}
	ch = retValue.substring(retValue.length-1, retValue.length);
	while (ch == " ")
	{
     		retValue = retValue.substring(0, retValue.length-1);
		 ch = retValue.substring(retValue.length-1, retValue.length);
	}
   	while (retValue.indexOf("  ") != -1)
	{
	      retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ")+1, retValue.length);
	      
	}
	return retValue; 
}

var itn = /^\d+$/;
var taxtype = /^[A-Za-z]+$/;
var unpri1 = /^(\d{1,6}|\d{1,6}\.{1}\d{1,2})$/;
var price = /^[^\d\.]+$/;
var todaysdate = new Date();
var skuWindow = null;

function skuList()
{
	skuWindow = window.open('skuAction.do?subaction=popSkuList','att','width=550,resizable=no,height=290,scrollbars=no');
}

function populateSku(unitprice,newprice,newpriceeffectivedate,promotionprice,promotionpricestartdate,promotionpriceenddate)
{
	skuForm.unitPrice.value = unitprice;
	skuForm.newPrice.value = newprice;
	skuForm.newPriceEffectiveDate.value = newpriceeffectivedate;
	skuForm.promotionPrice.value = promotionprice;
	skuForm.promotionStartDate.value = promotionpricestartdate;
	skuForm.promotionEndDate.value = promotionpriceenddate;
}

function addSku()
{
	if (isBlank(skuForm.itemDescription,"SKU description","y"))	
  	        return (false);

	if (isBlank(skuForm.department,"Department","y"))	
  	        return (false);

	var vitn = itn.exec(skuForm.department.value);
	if(!vitn)
	{
		alert("E-1121: Department can only be numeric.");
		skuForm.department.select();
		skuForm.department.focus();
		return(false);
	}
	
	if (skuForm.department.value == 0)
	{
		alert("E-1122: Department cannot be zero.");
		skuForm.department.select();
		skuForm.department.focus();
		return(false);
	}

	if (isBlank(skuForm.unitPrice,"Unit price","y"))
		return false;
		
	if (skuForm.unitPrice.value == 0)
	{
		alert("E-1123: Unit price cannot be zero.");
		skuForm.unitPrice.select();
		skuForm.unitPrice.focus();
		return(false);
	}
	
	var vprice = price.exec(skuForm.unitPrice.value);
	if (vprice)
	{
		alert("E-1124: Unit price can only be numeric.");
		skuForm.unitPrice.select();
		skuForm.unitPrice.focus();
		return(false);
	}
	
	var vunpri1 = unpri1.exec(skuForm.unitPrice.value);
	if(!vunpri1)
	{
		alert("E-1125: Unit price should have maximum of 6 digits and 2 decimal digits.");
		skuForm.unitPrice.select();
		skuForm.unitPrice.focus();
		return(false);
	}

	if (skuForm.unitPrice.value%100 != 0)
	{
		alert("E-1126: Unit price can only be multiples of 100.");
		skuForm.unitPrice.select();
		skuForm.unitPrice.focus();
		return false;
	}
	
	if (!isBlank(skuForm.newPriceEffectiveDate," ","n"))	
	{
		if (isBlank(skuForm.newPrice,"New price","y"))
			return false;

		if (skuForm.newPrice.value == 0)
		{
			alert("E-1127: New price cannot be zero.");
    		skuForm.newPrice.select();
			skuForm.newPrice.focus();
			return false;
		}
		
	}
	
	if(!isBlank(skuForm.newPrice," ","n"))
	{
		var vprice = price.exec(skuForm.newPrice.value);
		if (vprice)
		{
			alert("E-1128: New price can only be numeric.");
    		skuForm.newPrice.select();
			skuForm.newPrice.focus();
			return(false);
		}
		
		var vunpri1 = unpri1.exec(skuForm.newPrice.value);
		if(!vunpri1)
		{
			alert("E-1129: New price should have maximum of 6 digits and 2 decimal digits.");
    		skuForm.newPrice.select();
			skuForm.newPrice.focus();
			return(false);
		}
		
		if (skuForm.newPrice.value%100 != 0)
		{
			alert("E-1130: New price can only be multiples of 100.");
    		skuForm.newPrice.select();
			skuForm.newPrice.focus();
			return false;
		}
		
		if (skuForm.newPrice.value != 0)
		{
		if (isBlank(skuForm.newPriceEffectiveDate,"New price effective date","y"))
			return(false);
		}
	}

    var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	
	if(!isBlank(skuForm.newPriceEffectiveDate," ","n"))
	{
		if(!validateDate(skuForm.newPriceEffectiveDate,"yyyy/mm/dd","New price effective date","y"))		
			return(false);
		
	    var newpriceeffectivedate = strconvert(skuForm.newPriceEffectiveDate.value);
        if (newpriceeffectivedate < todaydate)
        {
        alert("E-1131: New price effective date should be greater than or equal to current date.");
        skuForm.newPriceEffectiveDate.select();
        skuForm.newPriceEffectiveDate.focus();
        return(false);
        }
    }
	
	if (!isBlank(skuForm.promotionStartDate," ","n") || !isBlank(skuForm.promotionEndDate," ","n"))	
	{
		if (isBlank(skuForm.promotionPrice,"Promotion price","y"))
			return false;
			
		if (skuForm.promotionPrice.value == 0)
		{
			alert("E-1132: Promotion price cannot be zero.");
    		skuForm.promotionPrice.select();
			skuForm.promotionPrice.focus();
			return false;
		}
	}

	if(!isBlank(skuForm.promotionPrice," ","n"))
	{
		var vprice = price.exec(skuForm.promotionPrice.value);
		if (vprice)
		{
			alert("E-1133: Promotion price can only be numeric.");
    		skuForm.promotionPrice.select();
			skuForm.promotionPrice.focus();
			return(false);
		}

		var vunpri1 = unpri1.exec(skuForm.promotionPrice.value);
		if(!vunpri1)
		{
			alert("E-1134: Promotion price should have maximum of 6 digits and 2 decimal digits.");
    		skuForm.promotionPrice.select();
			skuForm.promotionPrice.focus();
			return(false);
		}
		
		if (skuForm.promotionPrice.value%100 != 0)
		{
			alert("E-1135: Promotion price can only be multiples of 100.");
    		skuForm.promotionPrice.select();
			skuForm.promotionPrice.focus();
			return(false);
		}
		
		if (skuForm.promotionPrice.value != 0)
		{
			if (isBlank(skuForm.promotionStartDate,"Promotion start date","y"))
				return(false);
	
			if (isBlank(skuForm.promotionEndDate,"Promotion end date","y"))
				return(false);
		}	
	}
	
	if(!isBlank(skuForm.promotionStartDate," ","n"))
	{
		if(!validateDate(skuForm.promotionStartDate,"yyyy/mm/dd","Promotion start date","y"))		
			return(false);
		
	    var promotionStartDate = strconvert(skuForm.promotionStartDate.value);
        if (promotionStartDate < todaydate)
        {
        alert("E-1136: Promotion start date should be greater than or equal to current date.");
        skuForm.promotionStartDate.select();
        skuForm.promotionStartDate.focus();
        return(false);
        }
		
    }

	if(!isBlank(skuForm.promotionEndDate," ","n"))
	{
		if(!validateDate(skuForm.promotionEndDate,"yyyy/mm/dd","Promotion end date","y"))		
			return(false);
	    var promotionstartdate = strconvert(skuForm.promotionStartDate.value);
        var promotionenddate = strconvert(skuForm.promotionEndDate.value);    
     
            if(promotionenddate < promotionstartdate)
             {
                  alert("E-1137: Promotion end date should be greater than or equal to promotion start date.");
                  skuForm.promotionEndDate.select();
                  skuForm.promotionEndDate.focus();
                   return(false);
             }
    }
    
	if (skuForm.dutyType.selectedIndex == 0)
	{
		alert("E-1138: Select a valid duty type.");
		skuForm.dutyType.focus();
		return(false);
	}
	
    if (skuForm.dutyType.selectedIndex == 1)
    {
	    if (isBlank(skuForm.harmonizedCode,"Harmonized code","y"))
	    		return (false);
	    					
		var vitn = itn.exec(skuForm.harmonizedCode.value);
		if(!vitn)
		{
			window.alert("E-1139: Harmonized code can only be numeric.");
 			skuForm.harmonizedCode.select();
			skuForm.harmonizedCode.focus();
			return(false);
	    }
    }
    
    if (isBlank(skuForm.countryOfOrigin,"Country of origin","y"))
    	return (false);
    	
	var vitn = itn.exec(skuForm.countryOfOrigin.value);
	if(!vitn)
	{
		alert("E-1140: Country of origin can only be numeric.");
		skuForm.countryOfOrigin.select();
		skuForm.countryOfOrigin.focus();
		return(false);
	}
	
   if ((skuForm.dutyType.selectedIndex == 1) && (skuForm.department.value == 10 || skuForm.department.value == 11 || skuForm.department.value == 22 ))
   {
   		if (isBlank(skuForm.taxType,"Tax type","y"))
   		return(false);
   }

   if (!isBlank(skuForm.taxType,"","n"))
   {
	    skuForm.taxType.value = skuForm.taxType.value.toUpperCase();
	 	var vtaxtype = taxtype.exec(skuForm.taxType.value);
		if(!vtaxtype)
		{
			alert("E-1141: Tax type should contain only alphabets.");
			skuForm.taxType.select();
			skuForm.taxType.focus();
			return(false);
		}

        if ((skuForm.dutyType.selectedIndex == 1) && (skuForm.department.value == 10 || skuForm.department.value == 11 ))
        {
	        if (isBlank(skuForm.size,"Size","y"))
	        return(false);
	        if (isBlank(skuForm.alcoholStrength,"Alcohol strength","y"))
	        return(false);
        }
        if (!isBlank(skuForm.size,"","n"))
        {
           var vitn = itn.exec(skuForm.size.value);
			if(!vitn)
			{
				alert("E-1142: Size can only be numeric.");
				skuForm.size.select();
				skuForm.size.focus();
				return(false);
			}
	    }
	    if (!isBlank(skuForm.alcoholStrength,"","n"))
	    {
		   var vitn = itn.exec(skuForm.alcoholStrength.value);
			if(!vitn)
			{
				alert("E-1143: Alcohol strength can only be numeric.");
				skuForm.alcoholStrength.select();
				skuForm.alcoholStrength.focus();
				return(false);
			}	
		}
	}	
	

   if (skuForm.upccodelist.length == 0)
   {
	   	if (isBlank(document.all("upccode"),"UPC code","y"))
		return(false);

	   alert("E-1144: UPC code has to be shifted to the right side.");
   	   skuForm.upccode.focus();
   	   return(false);
   }
     
     skuForm.submit();	
}



function isBlank(str1,label,prompt)
{
	if(str1.value == "")
	{
		if(prompt == "y" || prompt == "Y")
		{
			alert("E-1145: "+ label + " cannot be empty.");
			str1.focus();
		}

		return(true);		
	}

	return(false);
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat == "yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag = true;
		}
		
		if(!flag)
		{
			if(prompt == "y")
			{
				alert("E-1146: " + label + " is invalid. Expected date format is " + dateformat+".");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <= 0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <= 0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon == 1 || mon == 3 || mon == 5 || mon == 7 || mon == 8 || mon == 10 || mon == 12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag == true && mon != 2 && day1 == 31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon == 2)  //If February
	{
		if(( ( year1%4 == 0 ) && ( year1 % 100 != 0)) ||( year1 %400 == 0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}

function clearPage()
{
	skuForm.itemCheck.value = "";
	skuForm.action = "skuAction.do?subaction=maintainSKUPage";
	skuForm.submit();
}


function enab()
{
skuForm.taxType.value=trim(skuForm.taxType.value);
if (!isBlank(skuForm.taxType,"","n"))
{
skuForm.size.disabled = false;
skuForm.alcoholStrength.disabled = false;
skuForm.disableSizeText.value = "N";
skuForm.size.focus();
}
else
{
skuForm.size.value = "";
skuForm.alcoholStrength.value = "";
skuForm.size.disabled = true;
skuForm.alcoholStrength.disabled = true;
skuForm.disableSizeText.value = "Y";
}
}

function locationEnable()
{
       	skuForm.itemDescription.disabled = false;
      	skuForm.department.disabled = false;
      	skuForm.dutyType.disabled = false;
      	skuForm.unitPrice.disabled = false;
      	skuForm.giftWithPurchase.disabled = false;
      	skuForm.newPrice.disabled = false;
      	skuForm.newPriceEffectiveDate.disabled = false;
      	skuForm.promotionPrice.disabled = false;
      	skuForm.promotionStartDate.disabled = false;
      	skuForm.promotionEndDate.disabled = false;
      	skuForm.harmonizedCode.disabled = false;
      	skuForm.countryOfOrigin.disabled = false;
      	skuForm.taxType.disabled = false;
      	skuForm.size.disabled = false;
      	skuForm.alcoholStrength.disabled = false;
      	document.all("upccode").disabled = false;
      	document.all("calendar1").disabled = false;
      	document.all("calendar2").disabled = false;
      	document.all("calendar3").disabled = false;
      	document.all("next").disabled = false;
      	document.all("previous").disabled = false;
      	document.all("add").disabled = false;
      	document.all("clear").disabled = false;
      	return(true);
}

function blankCheck()
{
	if (isBlank(skuForm.itemNumber,"","n"))
	{
       	skuForm.itemDescription.disabled = true;
       	skuForm.itemDescription.value = "";
      	skuForm.department.disabled = true;
      	skuForm.department.value = "";
      	skuForm.dutyType.disabled = true;
      	skuForm.dutyType.selectedIndex = 0;
      	skuForm.unitPrice.disabled = true;
      	skuForm.unitPrice.value = "";
      	skuForm.giftWithPurchase.disabled = true;
      	skuForm.newPrice.disabled = true;
      	skuForm.newPrice.value = "";
      	skuForm.newPriceEffectiveDate.disabled = true;
      	skuForm.newPriceEffectiveDate.value = "";
      	skuForm.promotionPrice.disabled = true;
      	skuForm.promotionPrice.value = "";
      	skuForm.promotionStartDate.disabled = true;
      	skuForm.promotionStartDate.value = "";
      	skuForm.promotionEndDate.disabled = true;
      	skuForm.promotionEndDate.value = "";
      	skuForm.harmonizedCode.disabled = true;
      	skuForm.harmonizedCode.value = "";
      	skuForm.countryOfOrigin.disabled = true;
      	skuForm.countryOfOrigin.value = "";
      	skuForm.taxType.disabled = true;
      	skuForm.taxType.value = "";
      	skuForm.size.disabled = true;
      	skuForm.size.value = "";
      	skuForm.alcoholStrength.disabled = true;
      	skuForm.alcoholStrength.value = "";
		skuForm.prevSellingLocation.value = "";
		skuForm.prevItemNumber.value = "";
      	document.all("upccode").disabled = true;
      	document.all("upccode").value = "";
		var len  =  skuForm.upccodelist.length;
		for (var i = 1 ; i <= len ; i++)
		{
		  skuForm.upccodelist.options[0] = null;
		  document.all("table1").deleteRow(1);
		}
      	document.all("calendar1").disabled = true;
      	document.all("calendar2").disabled = true;
      	document.all("calendar3").disabled = true;
      	document.all("next").disabled = true;
      	document.all("previous").disabled = true;
      	document.all("add").style.display = "none";
      	document.all("clear").style.display = "none";
      	return(false);
	}
	
	if (skuForm.itemCheck.value == "item")
	{
	    skuForm.itemNumber.select();
		skuForm.itemNumber.focus();
		skuForm.itemCheck.value = "";
		return false;	
	}

	if (skuForm.itemCheck.value == "sell")
	{
			skuForm.sellingLocation.focus();
			skuForm.itemCheck.value = "";		
			return;
	}
	}

function getLocationDetails()
{
    if (window.event.keyCode == 9)
    {
	    skuForm.itemNumber.value = trim(skuForm.itemNumber.value);
    	if (!isBlank(skuForm.itemNumber,"","n"))
    	{
		if (skuForm.sellingLocation.selectedIndex == 0)
		{
			alert("E-1147: Select a valid location.");
			skuForm.itemCheck.value = "sell";
			return(false);
		}
	
		var vitn = itn.exec(skuForm.itemNumber.value);
		if(!vitn)
		{
			window.alert("E-1148: SKU number can only be numeric.");
			skuForm.itemCheck.value = "item";
			return(false);
	    }
	
		if (skuForm.itemNumber.value == 0)
		{
			alert("E-1149: SKU number cannot be zero.");
			skuForm.itemCheck.value = "item";
			return(false);
		}
    
       if ((skuForm.prevSellingLocation.value != skuForm.sellingLocation.value) || (skuForm.prevItemNumber.value != skuForm.itemNumber.value))
        {
		skuForm.action = "skuAction.do?subaction=getLocationDetails";
		skuForm.itemCheck.value = "submit";
		skuForm.submit();
        }
        }   	
	}
	
}

function dutyTypeEnable()
{
     if (skuForm.dutyType.selectedIndex == 1)
     {
     	skuForm.harmonizedCode.disabled = false;
      	skuForm.taxType.disabled = false;
      	skuForm.disableText.value = "N";
      	enab();
     }
     else
     {
     	skuForm.harmonizedCode.value = "";
      	skuForm.taxType.value = "";
      	skuForm.size.value = "";
      	skuForm.alcoholStrength.value = "";
     	skuForm.harmonizedCode.disabled = true;
      	skuForm.taxType.disabled = true;
      	skuForm.size.disabled = true;
      	skuForm.alcoholStrength.disabled = true;
      	skuForm.disableText.value = "Y";
     }
}


function strconvert(str1)
{
	var temp = str1.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}

function upcAdd()
{
	var len = document.skuForm.upccodelist.length;

	var upccodesrc = eval(document.skuForm.upccodelist);
	var oTable = eval(document.all("table1"));
	var oRow;
	var oCell;
    for (i = 0;i < len;i++)
    {
		var bgcolor1;
		if (i%2 == 0)
			bgcolor1 = "#FAFAFA";
		else
			bgcolor1 = "#FFFEF6";

		oRow = oTable.insertRow();
		oCell = oRow.insertCell();
		oCell.innerHTML = "<input type=checkbox name=check id=check" + i + " onclick=checkStatus('check" + i + "');>";
		oCell.bgColor = bgcolor1;
		oCell = oRow.insertCell();
		oCell.bgColor = bgcolor1;
		oCell.innerHTML = '<div class="textfield">' + upccodesrc.options[i].value + '</div>';
    }

}

function checkStatus(name)
{
    var length = skuForm.upccodelist.length;
	var result = "unchecked";
	var box = eval(document.all(name));
	if(document.all(name).checked == true )
	{
		result = "checked";
	}
	if(length != null)
	{
		for(var i = 0; i < length; i++)
		{
		    var t = "check" + i;
			var chk1 = eval(document.all(t));
			if(chk1.id != name)
			{
				if(result == "checked")
				{
					chk1.disabled = true;
				}
				else 
				{
					chk1.disabled = false;					
				}
			}
		}	
	}
}

function moveintolistsku()
{   
    if (!isBlank(document.all("upccode"),"UPC code","y"))
    {
	var upc = /^\d+$/;
	var vupc = upc.exec(document.all("upccode").value);
	if (!vupc)
    {
	alert("E-1150: UPC code can only be numeric.");
	document.all("upccode").select();
	document.all("upccode").focus();
	return(false);
	}
	
	if (document.all("upccode").value == 0)
	{
	alert("E-1151: UPC code cannot be zero.");
	document.all("upccode").select();
	document.all("upccode").focus();
	return(false);
	}
	
	var len = document.skuForm.upccodelist.length;

	var upccodesrc = eval(document.skuForm.upccodelist);

	for (var i = 0;i < len;i++)
	{
	  if (upccodesrc.options[i].value == document.all("upccode").value)
	  {
	  alert("E-1152: UPC code already exists.");
	  document.all("upccode").select();
	  document.all("upccode").focus();
	  return(false);
	  }
	}

	upccodesrc.options[len] = new Option(document.all("upccode").value, document.all("upccode").value);

    upccodesrc.options[len].selected = true;
    
	document.all("upccode").value = "";

	var oTable = eval(document.all("table1"));
	var oRow;
	var oCell;

	var bgcolor1;
	if (len%2 == 0)
		bgcolor1 = "#FAFAFA";
	else
		bgcolor1 = "#FFFEF6";

	oRow = oTable.insertRow();
	oCell = oRow.insertCell();
	oCell.innerHTML = "<input type=checkbox name=check id=check" + len + " onclick=checkStatus('check" + len + "');>";
	oCell.bgColor = bgcolor1;
	oCell = oRow.insertCell();
	oCell.bgColor = bgcolor1;
	oCell.innerHTML = '<div class="textfield">' + upccodesrc.options[len].value + '</div>';
    
    for (var j = 0;j <= len;j++)
    {
    	var g = "check"+j;
    	var chk = eval(document.all(g));
    	if (chk != null)
    	{
    		chk.disabled = false;
    		chk.checked = false;
    	}
    }

    }		
	

}

function removefromlistsku()
{
	var upccodesrc = eval(document.skuForm.upccodelist);
	var len = document.skuForm.upccodelist.length;
	var chkcount = 0;
    if (len == 0)
    {
    	alert("E-1153: The UPC code list is empty.");
    	return(false);
    }
	for (var i=0;i<len; i++)
	{   
	    var t = "check" + i;
		var chk1 = eval(document.all(t));
		if (chk1.checked)
		{
            document.all("upccode").value = upccodesrc.options[i-chkcount].value;
			upccodesrc.options[i-chkcount] = null;   //i-chkcount is done inorder to account for the change in position of an option because of the removal of preceding options
			chkcount++;
		}

	}
    if (chkcount == 0)
    {
    	alert("E-1154: Select a valid UPC code.");
    }

	var oTable = eval(document.all("table1"));

	for (var i=1;i<=len; i++) //The length of the table is len + 1 (including the heading)
		oTable.deleteRow(1);

	var oRow;
	var oCell;

	len = document.skuForm.upccodelist.length;
	var bgcolor1;

	for (var i=0; i<len; i++)
	{
		if (i%2 == 0)
			bgcolor1 = "#FAFAFA";
		else
			bgcolor1 = "#FFFEF6";

		oRow = oTable.insertRow();
		oCell = oRow.insertCell();
		oCell.innerHTML = "<input type=checkbox name=check id=check" + i + " onclick=checkStatus('check" + i + "'); >";
		oCell.bgColor= bgcolor1;
		oCell = oRow.insertCell();
		oCell.innerHTML = '<div class="textfield">' + upccodesrc.options[i].value + '</div>';
		oCell.bgColor= bgcolor1;
	}

}

// login page js functions

function formSubmit(){

	var userId = trim(document.loginForm.userId.value);
	var password = trim(document.loginForm.password.value);
	var success = true;
	var keycode = window.event.keyCode;
	
	if(userId == "" && keycode == "13")
	{
		alert("E-1155: User ID cannot be empty.");
		document.loginForm.userId.value="";
		document.loginForm.userId.focus();
		success = false;
	}
	if(password == "" && success && keycode == "13")
	{
		alert("E-1156: Password cannot be empty.");
		document.loginForm.password.value="";
		document.loginForm.password.focus();
		success = false;
	}
	if(keycode == "13" && success)
	{
		document.loginForm.submit();	
	}

}
function formClickSubmit(){

	var userId = trim(document.loginForm.userId.value);
	var password = trim(document.loginForm.password.value);
	var success = true;	
	
	if(userId == "")
	{
		alert("E-1157: User ID cannot be empty.");
		document.loginForm.userId.value="";
		document.loginForm.userId.focus();
		success = false;
	}
	if(password == "" && success )
	{
		alert("E-1158: Password cannot be empty.");
		document.loginForm.password.value="";
		document.loginForm.password.focus();		
		success = false;
	}
	if(success)
	{
		document.loginForm.submit();	
	}
}
function load(result)
{
	if(result == "215")
	{
		document.loginForm.password.value = "";
		document.loginForm.password.focus();
	}		
	else if(result == "214" || result == "228" || result == "229") 
	{
		document.loginForm.userId.select();	
		document.loginForm.userId.focus();	
	}	
	else
	{
		document.loginForm.userId.focus();
	}
}

function onClear()
{
	document.userForm.subaction.value = "createUserPage";
	document.userForm.action = "userAction.do";
	document.userForm.submit();
/*	document.userForm.userId.value="";
	document.userForm.employeeId.value="";
	document.userForm.lastName.value="";
	document.userForm.firstName.value="";
	document.userForm.dateOfBirth.value="";
	document.userForm.invalidTries.value="";
	
	if (document.userForm.neverLock.checked == true)
	{
		document.userForm.invalidTries.disabled = false;
		document.userForm.neverLock.checked = false;		
	}	
	document.userForm.language.options[0].selected = true;	
	
	var length = document.userForm.assignedTransactionIds.length;
	if(length != null)
	{
		for(var i = 0; i < length; i++)
		{
			if (document.userForm.assignedTransactionIds.options[i] != null) 
			{
				document.userForm.assignedTransactionIds.options[i].selected = true;				
			}
		}	
	}
	if(document.userForm.assignedTransactionIds != null)
	{
		var length = document.userForm.assignedTransactionIds.length;
		if ((length != null) && (length != 0))
		{
			assignTransaction(document.userForm.assignedTransactionIds, document.userForm.selectedTransactionIds);
		}
	}*/
}

var totalCollapsibleMenuItems = 5;

function neverlockchecked()
{
	if(document.userForm.neverLock.checked)
	{
		document.userForm.invalidTries.value="";
		document.userForm.invalidTries.disabled=true		
	}
	else 
	{
		document.userForm.invalidTries.disabled=false
		
	}	
}


//-->
function assignTransaction(source, destination,operation) 
{	
	if(operation == "update")
	{
		return;
	}
	else
	{	
	
		var selected = false;
		var result = true;
		var sourceLength = source.length;
		var destinationLength = destination.length;
	
		if((sourceLength == null) || (sourceLength == 0))
		{
			if(source == document.userForm.selectedTransactionIds)
			{
				alert("E-1159: All the available transactions are assigned.");
				result = false;
			}
			else if (source == document.userForm.assignedTransactionIds)
			{
				alert("E-1160: Currently there are no assigned Transaction.");
				result = false;
			}
		}
		if(result == true)
		{
			for(var i = 0; i < sourceLength; i++)
			{
				if ((source.options[i] != null) && (source.options[i].selected))
				{
					selected = true;
					destination.options[destinationLength] = new Option(source.options[i].text,source.options[i].value);
					destinationLength++;
				}
			}
			if(selected == false)
			{
				if(source == document.userForm.selectedTransactionIds)
				{
					alert("E-1161: Select the transaction from the available transaction list.");
					result = false;
				}
				else if (source == document.userForm.assignedTransactionIds)
				{
					alert("E-1162: Select the transaction from the assigned transaction list.");
					result = false;
				}		
			}
			if(result == true )
			{
				for(var i=(sourceLength-1); i >= 0; i--)
				{
					if ((source.options[i] != null) && (source.options[i].selected == true))
					{
						source.options[i] = null;
					}
				}
				sort(destination);
			}
			/*if(source.length == 0)
			{		
				source.options[0]	= new Option("-1", "-1");		
			}*/
		}	
	}
}

function assignAllTransactions(source, destination,operation)
{
	if(operation == "update")
	{
		return;
	}
	else
	{
		var sourceLength = source.length;
		var destinationLength = destination.length;
		if((sourceLength == null) || (sourceLength == 0))
		{
			if(source == document.userForm.selectedTransactionIds)
			{
				alert("E-1163: All the available transactions are assigned.");
			}
			else if (source == document.userForm.assignedTransactionIds)
			{
				alert("E-1164: Currently there are no assigned Transaction.");
			}
		}
		
		for(var i = 0; i < sourceLength; i++)
		{
			if (source.options[i] != null) 
			{
				destination.options[destinationLength] = new Option(source.options[i].text,source.options[i].value);
				destinationLength++;
			}
		}
		for(var i=(sourceLength-1); i >= 0; i--)
		{
			if (source.options[i] != null) 
			{
				source.options[i] = null;
			}
		}
	}
	/*if(source.length == 0)
	{		
		source.options[0]	= new Option("-1", "-1");		
	}*/	
}
function sort(selobj)
{
	for(var i=0;i<selobj.length;i++)
	{
		for(var j=0;j<selobj.length-1;j++)
		{
			if(selobj.options[j].text > selobj.options[j+1].text)
			{
				var temptext = selobj.options[j].text;
				var tempvalue = selobj.options[j].value;
				selobj.options[j].text = selobj.options[j+1].text;
				selobj.options[j].value = selobj.options[j+1].value;
				selobj.options[j+1].text = temptext;
				selobj.options[j+1].value = tempvalue;
			}
		}
	}
}
function save()
{
	document.userForm.subaction.value="saveUserDetails";
	if (validate() == true)
	{
		var length = document.userForm.assignedTransactionIds.length;
		if(length != null)
		{
			for(var i = 0; i < length; i++)
			{
				if (document.userForm.assignedTransactionIds.options[i] != null) 
				{
					document.userForm.assignedTransactionIds.options[i].selected = true;				
				}
			}	
		}
		if(document.userForm.neverLock.checked)
		{
			document.userForm.invalidTries.value="";		
		}
		else
		{
			document.userForm.neverLock.value="N";
		}
		
		document.userForm.submit();
	}
}
function validate()
{
	var result = true;
	var userId = document.userForm.userId.value;
	if(userId != null)
	{
		userId = trim(userId);
	}
	if ((userId == null) || (userId.length == 0))
	{	
		alert("E-1165: User ID cannot be empty.");
		document.userForm.userId.value = "";
		document.userForm.userId.focus();
		result = false;
	}
	else
	{
		var result1 = isNaN(userId);
		//alert(result1);
		if(result1 == true)
		{
			alert("E-1166: User Id should be numeric.");
			document.userForm.userId.select();
			document.userForm.userId.focus();	
			result = false;	
		}
		else
		{
			var employeeId = 	document.userForm.employeeId.value;
			if(employeeId != null)
			{
				employeeId = trim(employeeId);
			}
			if((employeeId == null) || (employeeId.length == 0))
			{
				alert("E-1167: Employee ID should not be empty.");
				document.userForm.employeeId.value = "";
				document.userForm.employeeId.focus();
				result = false;
			}
			if(result == true )
			{
				/*result = checkAlphaNumericString(employeeId);				
				if(result == false)
				{
					alert("Special characters are not allowed in Employee id");
					document.userForm.employeeId.select();
					document.userForm.employeeId.focus();
					result = false;
				}*/
				result = isSplCharsPresent(employeeId);
				if(result == false)
				{
					alert("E-1168: Special characters are not allowed in employee ID.");
					document.userForm.employeeId.select();
					document.userForm.employeeId.focus();
					result = false;			
				}
				else
				{
					var password = document.userForm.password.value;
					if(password != null)
					{
						password= trim(password);
					}
					
					var passPattern=/^\d+$/;
					if((password == null) || (password.length == 0))
					{
						alert("E-1169: Password should not be empty.");
						document.userForm.password.value = "";
						document.userForm.password.focus();
						result = false;
					}
					else if(!passPattern.exec(password))
					{
						alert("E-1121: Password should be numeric.");
						document.userForm.password.select();
						document.userForm.password.focus();
						result = false;
					}	
					if(result == true)
					{
						var lastName = 	document.userForm.lastName.value;
						if(lastName != null)
						{
							lastName = trim(lastName);
						}
						if((lastName == null) || (lastName.length == 0))
						{
							alert("E-1170: Last name should not be empty.");
							document.userForm.lastName.value = "";
							document.userForm.lastName.focus();
							result = false;
						}
						if(result == true)
						{
							result = nameCheck(document.userForm.lastName, 'Last Name');	
							if(result == true)
							{
								var firstName = 	document.userForm.firstName.value;
								if(firstName != null)
								{
									firstName = trim(firstName);
								}
								if(result == true )
								{
									if ((firstName != null) && (firstName.length != 0))
									{
										result = nameCheck(document.userForm.firstName , 'First Name');
									}
									
									if(result == true)
									{
										var dateOfBirth = 	document.userForm.dateOfBirth.value;
										if(dateOfBirth != null)
										{
											dateOfBirth = trim(dateOfBirth);
										}
										if((dateOfBirth == null) || (dateOfBirth.length == 0))
										{
											alert("E-1171: Date of birth should not be empty.");
											document.userForm.dateOfBirth.value = "";
											document.userForm.dateOfBirth.focus();
											result = false;
										}	
										if(result == true )
										{
											result = validateDate(document.userForm.dateOfBirth, 'yyyy/mm/dd', 'Date of birth', 'y');
											if(result == true)
											{
												var checkDate = strconvert(document.userForm.dateOfBirth.value);
												var todaysdate = new Date();
												var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
												if(checkDate < todaydate)
												{
													if(result == true)
													{
														if(document.userForm.neverLock.checked == false)
														{
															var invalidTries = 	document.userForm.invalidTries.value;
															if(invalidTries != null)
															{
																invalidTries = trim(invalidTries);
															}
															if((invalidTries == null) || (invalidTries.length == 0))
															{
																alert("E-1172: Select never lock or give invalid tries.");
																document.userForm.invalidTries.value = "";
																document.userForm.invalidTries.focus();
																result = false;
															}
															if(isNaN(document.userForm.invalidTries.value))
															{
																alert("E-1173: Invalid tries should be a number.");
																document.userForm.invalidTries.select();
																document.userForm.invalidTries.focus();
																result = false;
															}
															else if(parseInt(document.userForm.invalidTries.value) < 0)
															{
																	alert("E-1174: Invalid tries should not be negative.");
																	document.userForm.invalidTries.select();
																	document.userForm.invalidTries.focus();
																	result = false;														
															}
															else
															{ 
																if ((document.userForm.invalidTries.value == '0') ||(document.userForm.invalidTries.value == '00'))
																{
																	alert("E-1175: Invalid tries should not be zero.");
																	document.userForm.invalidTries.select();
																	document.userForm.invalidTries.focus();
																	result = false;
																}
															}
														}						
													}
												}
												else
												{
													alert("E-1176: Date of birth should be lesser than current date.");
													document.userForm.dateOfBirth.select();
													document.userForm.dateOfBirth.focus();
													result = false;
												}
											}
										}	
									}
								}
							}			
						}
					}					
				}
			}	
		}
	}
	return result;
}
function update()
{
	if(validate() == true )
	{
		document.userForm.subaction.value="updateUserDetails";
		var length = document.userForm.selectedTransactionIds.length;
		
		if((length != null) && (length != 0))
		{
			for (var i = 0; i < length; i++)
			{
				document.userForm.selectedTransactionIds.options[i].selected = false;	
			}
		}
		
		
		length = document.userForm.assignedTransactionIds.length;
		if(length != null)
		{
			for(var i = 0; i < length; i++)
			{
				if (document.userForm.assignedTransactionIds.options[i] != null) 
				{
					document.userForm.assignedTransactionIds.options[i].selected = true;				
				}
			}	
		}
		if(document.userForm.neverLock.checked)
		{
			document.userForm.tries.value="";		
			document.userForm.locked.value="Y";
		}
		else
		{
			document.userForm.locked.value="N";
			document.userForm.tries.value = document.userForm.invalidTries.value;		
		}	
		document.userForm.submit();
	}
}


function cancelPage()
{
	userForm.subaction.value="cancelPage";
	userForm.submit();
}
function deleteUser()
{
	if (userForm.userId.length == 0)
	{	
		alert("E-1177: Please enter user ID.");
		return false;
	}
	else
	{
		if(confirm("Do you want to delete"))
		{
			userForm.subaction.value="removeUserDetails";
			userForm.submit();
		}
	}
}
function deleteCurrentUser()
{
	alert("E-1178: Logged in user cannot be deleted.");	
}
function deactivateUser()
{
	alert("E-1179: Logged in user cannot be deactivated.");	
}
function lockStatusChange()
{
	userForm.subaction.value="unLockUser";
	userForm.submit();
}
function activeStatusChange()
{
	window.open("userAction.do?subaction=loadReason","reason","width=600,height=225,left=50,top=100,scrollbars=yes,resizable=no,status=yes");	
}

function languageToggle(url)
{
	userForm.action = url;
	userForm.submit();
}

function searchUser()
{
	var keycode = window.event.keyCode;
	if ((keycode==9) && (document.userForm.userId.value != null) && ((document.userForm.userId.value).length != 0))
	{
		var result = checkSpecialCharacters(document.userForm.userId.value);
		
		if (result == true)
		{
			userForm.subaction.value="loadUserDetails";
			userForm.fromPage.value="maintainUserPage";
			userForm.submit();
		}
		else
		{
			alert("E-1180: Special characters are not allowed in user ID.");
			document.userForm.userId.select();
			document.userForm.userId.focus();
		}
	}
}
function loadUser(details,operation) 
{		
	if (document.userForm.invalidTries.value != null)
	{
		if (document.userForm.invalidTries.value == 0)
		{
			document.userForm.invalidTries.value="";	
		}
	}	
	sort(document.userForm.selectedTransactionIds);
	if(document.userForm.neverLock.checked)
	{
		document.userForm.invalidTries.disabled=true
	}
	if(details == "true")
	{
		document.userForm.employeeId.focus();
	}
	else
	{
		document.userForm.userId.focus();
	}
	if(operation == "true")
	{
		document.userForm.employeeId.disabled = true;
		document.userForm.password.disabled = true;
		document.userForm.lastName.disabled = true;
		document.userForm.firstName.disabled = true;
		document.userForm.dateOfBirth.disabled = true;
		document.userForm.neverLock.disabled = true;
		document.userForm.invalidTries.disabled = true;
		document.userForm.language.disabled = true;
		document.userForm.selectedTransactionIds.disabled = true;
		document.userForm.assignedTransactionIds.disabled = true;
		//document.userForm.dateImg.disabled = true;
		var dateImg = document.all("dateImg");	  
	    dateImg.disabled=true;
	    var navprev = document.all("navprev");	  
	    navprev.disabled=true;		
	    var navstart = document.all("navstart");	  
	    navstart.disabled=true;		
   	    var navend = document.all("navend");	  
	    navend.disabled=true;		
	    var navnext = document.all("navnext");	  
	    navnext.disabled=true;			    
	}
}
function disableCodeId(form,code)
{	

	if(document.referenceDataForm.referenceType.value != -1 && code == "false")
	{
		form.code.disabled=false;
		form.value.disabled=false;
		form.code.focus();
	}
	else if(code != "null")
	{
		form.code.disabled=true;
		//form.value.disabled=true;		
	}
}
function moveInToList()
{
	var codeIdExpr=/^[A-Z \s 0-9 a-z]*$/;
	var codeValueExpr=/^[A-Z \s 0-9 a-z]*$/;
	//var airlineCodeValue = /^((\d[A-Za-z])|([A-Za-z]\d)|([A-Za-z][A-Za-z]))$/;
	//Added by David for CO 5985 starts
	var airlineCodeValue = /^((\d[A-Za-z])|([A-Za-z]\d)|([A-Za-z][A-Za-z])|([0-9][0-9]))$/;
	//Added by David for CO 5985 ends
	var naccsCodeValue = /^[A-Za-z]{3}$/;
	var maxalphabets = /^[A-Za-z]*$/;
	var nationalityExpr = /^\d{1,2}$/;
	var groupCodeExpr =  /^[A-Za-z]$/;
	
	if(document.referenceDataForm.referenceType.value != -1)
	{
		var id = document.referenceDataForm.code.value;
		
		var codeId = trim(document.referenceDataForm.code.value);
		
		var codeValue = trim(document.referenceDataForm.value.value);
		
		var idResult = codeIdExpr.exec(codeId);

		var airlinecode = airlineCodeValue.exec(codeValue);			
		
		var maxalphabet = maxalphabets.exec(codeValue);
		
		var nationality = nationalityExpr.exec(codeId);
		
		var groupCode = groupCodeExpr.exec(codeId);
		
		if(codeId == "") 
		{
			alert("E-1181: Code cannot be empty.");
			document.referenceDataForm.code.value="";
			document.referenceDataForm.code.focus();
			return;
		}
		if(!idResult)
		{
			alert("E-1182: Special characters are not allowed for Code.");
			document.referenceDataForm.code.select();
			document.referenceDataForm.code.focus();
			return ;
			
		}
		if(document.referenceDataForm.referenceType.value == "4")
		{
			if(!nationality)
			{				
				alert("E-1183: Nationality code should be 2 digits.");
				document.referenceDataForm.code.select();		
				document.referenceDataForm.code.focus();
				return;				
			}		
			else if(codeId.substring(0,1) == "0")
			{
				alert("E-1185: Nationality code should not start with zero.");
				document.referenceDataForm.code.select();		
				document.referenceDataForm.code.focus();
				return;										
			}
			else if(codeId == "00")
			{
				alert("E-1184: Nationality code should not contain zeroes.");
				document.referenceDataForm.code.select();		
				document.referenceDataForm.code.focus();
				return;							
			}
		}
		if(document.referenceDataForm.referenceType.value == "10")
		{			
			if(!groupCode)
			{				
				alert("E-1185: Group code should contain one alphabet.");
				document.referenceDataForm.code.select();
				document.referenceDataForm.code.focus();
				return;				
			}
		}	
		if(codeValue == "")
		{
			alert("E-1186: Value cannot be empty.");
			document.referenceDataForm.value.value="";
			document.referenceDataForm.value.focus();
			return;
		}		
		
		if(document.referenceDataForm.referenceType.value == "7")
		{
			if(!maxalphabet)
			{				
				alert("E-1187: Language should contain only alphabets.");
				document.referenceDataForm.value.select();
				document.referenceDataForm.value.focus();
				return;				
			}	
		
		}
		if(document.referenceDataForm.referenceType.value == "8")
		{			
			var naccscode = naccsCodeValue.exec(document.referenceDataForm.naccsCode.value);
			if(!airlinecode)
			{
				alert("E-1188: Airline code should be alphanumeric.");
				document.referenceDataForm.value.select();
				document.referenceDataForm.value.focus();
				return;					
			}			
			if(document.referenceDataForm.naccsCode.value=="")
			{
				alert("E-1189: Naccs code cannot be empty.");
				document.referenceDataForm.naccsCode.value="";
				document.referenceDataForm.naccsCode.focus();
				 return;		
			}	
			if(!naccscode)
			{
				alert("E-1190: Naccs code should contain three alphabets.");
				document.referenceDataForm.naccsCode.select();
				document.referenceDataForm.naccsCode.focus();
				return;					
			}			
		}		
		if(document.referenceDataForm.referenceType.value == "9")
		{
			if (isNaN(codeId))
			{
				alert("E-1191: Code should be numeric only.");
				document.referenceDataForm.code.select();
				document.referenceDataForm.code.focus();
				return ;		
			}
		}	
		idResult = codeValueExpr.exec(codeValue);
			
		if(!idResult)
		{
			alert("E-1192: Special characters are not allowed for value.");
			document.referenceDataForm.value.select();
			document.referenceDataForm.value.focus();
			return ;
			
		}
		if(id.length != 0 )
		{
			var len = document.referenceDataForm.codeIdList.length;
		
			var codeSource = eval(document.referenceDataForm.codeIdList);
			var valueSource = eval(document.referenceDataForm.codeValueList);
			var shift = false;
			var store = false;
		
			/*Modified on 28th June 2006 - Starts
			*SR 1042 International DF Sale */
			
			var pickup = false;
			
		/*Modified on 28th June 2006 - End
		 *SR 1042 International DF Sale */
			
			var airlineCode = false;
			var fromTimeSource;
			var toTimeSource;
			var codeFlagSource;
			/*Modified on 28th June 2006 - Starts
		*SR 1042 International DF Sale */
			
			var pickupFlagSource;
	/*Modified on 28th June 2006 - Ends
	*SR 1042 International DF Sale */

			var naccsCodeSource;
			
			if(document.referenceDataForm.referenceType.value == "6")
			{
				shift=true;
				fromTimeSource = eval(document.referenceDataForm.fromTime);
				toTimeSource = eval(document.referenceDataForm.toTime);
			}
			else if(document.referenceDataForm.referenceType.value == "3")
			{
				store = true;
				codeFlagSource = eval(document.referenceDataForm.storeFlag);	
			}
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */
			
			else if(document.referenceDataForm.referenceType.value == "5")
			{
				pickup = true;
				pickupFlagSource = eval(document.referenceDataForm.pickupFlag);	
			}
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */
		
			else if (document.referenceDataForm.referenceType.value == "8")
			{
				airlineCode = true;
				naccsCodeSource = eval(document.referenceDataForm.naccsCodes);	
			}
			var codeId = trim(document.referenceDataForm.code.value);
			var codeValue = trim(document.referenceDataForm.value.value);
			var fromHr;
			var fromMin;
			var toHr;
			var toMin;
			var codeToFlag;
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */
			
			var pickupToFlag;
			
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */
		
			var naccsCodeValue;
			
			if(shift == true)
			{
				var timeLength =document.referenceDataForm.fromHrList.length;
				for ( var i = 0; i < timeLength; i++)
				{
					if (document.referenceDataForm.fromHrList.options[i].selected == true)
					{
						fromHr = document.referenceDataForm.fromHrList.options[i].value;
						
					}
					if (document.referenceDataForm.toHrList.options[i].selected == true)
					{
						toHr = document.referenceDataForm.toHrList.options[i].value;
						
					}
				}
				timeLength =document.referenceDataForm.fromMinList.length;
				for ( var i = 0; i < timeLength; i++)
				{
					if (document.referenceDataForm.fromMinList.options[i].selected == true)
					{
						fromMin = document.referenceDataForm.fromMinList.options[i].value;
						
					}
					if (document.referenceDataForm.toMinList.options[i].selected == true)
					{
						toMin = document.referenceDataForm.toMinList.options[i].value;
					}
				}
				if(validateTimeHrs(fromHr,fromMin,toHr,toMin))
				{
					document.referenceDataForm.toHrList.focus();
					return;
				}
			}
			if (store == true)
			{
				
				if (document.referenceDataForm.codeFlag.checked == true)
				{
					codeToFlag = document.referenceDataForm.codeFlag.value;
				}
				else
				{
					codeToFlag = "N";
				}
			}
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */
			
			if (pickup == true)
			{
				
				if (document.referenceDataForm.pickupCodeFlag.checked == true)
				{
					pickupToFlag = document.referenceDataForm.pickupCodeFlag.value;
				}
				else
				{
					pickupToFlag = "N";
				}
			}
			
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */
		
			if (airlineCode == true)
			{
				
				naccsCodeValue= trim(document.referenceDataForm.naccsCode.value);
				var codeIdExpr=/^[A-Z \s 0-9 a-z]*$/;
				if(naccsCodeValue == "")
				{
					alert("E-1193: Naccs code cannot be empty.");
					document.referenceDataForm.naccsCode.value="";
					document.referenceDataForm.naccsCode.focus();
					return;	
				}
				var result = codeIdExpr.exec(naccsCodeValue);
				if(!result)
				{
					alert("E-1194: Special characters are not allowed for naccs code.");
					document.referenceDataForm.naccsCode.select();
					document.referenceDataForm.naccsCode.focus();
					return;
				}
			}
			
			if (codeId != "")
			{
				if (codeValue != "")
				{
					var codeExists = false;
					var valueExists = false;
					var sourceLength = codeSource.length;
					for (var i=0; i < sourceLength; i++)
					{
						if ((codeSource.options[i].value).toUpperCase() == codeId.toUpperCase())
						{
							codeExists = true;
						}
					}
					if(codeExists == false)
					{
						sourceLength = valueSource.length;
						for (var i=0; i < sourceLength; i++)
						{
							if ((valueSource.options[i].value).toUpperCase() == codeValue.toUpperCase())
							{
								valueExists = true;
							}
						}
						
						if(valueExists == false)
						{
							codeSource.options[len] = new Option(codeId, codeId);
							valueSource.options[len] = new Option(codeValue, codeValue);
							if(shift == true)
							{
								var timeLength =document.referenceDataForm.fromHrList.length;
								fromTimeSource.options[len] = new Option(fromHr+":"+fromMin, fromHr+":"+fromMin);
								toTimeSource.options[len] = new Option(toHr+":"+toMin, toHr+":"+toMin);
								document.referenceDataForm.fromHrList.options[0].selected = true;
								document.referenceDataForm.fromMinList.options[0].selected = true;
								document.referenceDataForm.toHrList.options[0].selected = true;
								document.referenceDataForm.toMinList.options[0].selected = true;
							}
							if(store == true)
							{
								codeFlagSource.options[len] = new Option(codeToFlag, codeToFlag);
								document.referenceDataForm.codeFlag.checked = false;
							}
							/*Modified on 28th June 2006 - Starts
							 *SR 1042 International DF Sale */
							
							if(pickup == true)
							{
								pickupFlagSource.options[len] = new Option(pickupToFlag, pickupToFlag);
								document.referenceDataForm.pickupCodeFlag.checked = false;
							}

							/*Modified on 28th June 2006 - Ends
							 *SR 1042 International DF Sale */
						
							if(airlineCode == true)
							{
								naccsCodeSource.options[len] = new Option(naccsCodeValue, naccsCodeValue);	
								naccsCodeValue = "";
								document.referenceDataForm.naccsCode.value = "";
							}
							codeId = "";
							codeValue = "";
							
						
							document.referenceDataForm.code.value="";
							document.referenceDataForm.value.value="";
							document.referenceDataForm.code.disabled = false;
							
							
							
							var oTable = eval(document.all("codeValueTable"));
							var oRow;
							var oCell;
						
							var bgcolor1="#FAFAFA";
							/*if(len%2 == 0)
								bgcolor1 = "#FAFAFA";
							else
								bgcolor1 = "#FAFAFA";*/
							
						
							oRow = oTable.insertRow();
							oCell = oRow.insertCell();
							oCell.innerHTML = "<input type=checkbox name=check" + len + " onclick=changeBox('check"+len+"')>";
							oCell.bgColor = bgcolor1;
							oCell = oRow.insertCell();
							oCell.bgColor = bgcolor1;
							oCell.innerHTML = '<div class = "textfield">' + codeSource.options[len].value + '</div>';
							oCell = oRow.insertCell();
							oCell.bgColor = bgcolor1;
							oCell.innerHTML = '<div class="textfield">' + valueSource.options[len].value + '</div>';
							if(shift == true)
							{
								oCell = oRow.insertCell();
								oCell.bgColor = bgcolor1;
								oCell.innerHTML = '<div class="textfield">' + fromTimeSource.options[len].value + '</div>';
								oCell = oRow.insertCell();
								oCell.bgColor = bgcolor1;
								oCell.innerHTML = '<div class="textfield">' + toTimeSource.options[len].value + '</div>';
							}
							if(store == true)
							{
								oCell = oRow.insertCell();
								oCell.bgColor = bgcolor1;
								oCell.innerHTML = '<div class="textfield">' + codeFlagSource.options[len].value + '</div>';	
							}
							/*Modified on 28th June 2006 - Starts
							*SR 1042 International DF Sale */
							
							if(pickup == true)
							{
								oCell = oRow.insertCell();
								oCell.bgColor = bgcolor1;
								oCell.innerHTML = '<div class="BDYTBLrow">' + pickupFlagSource.options[len].value + '</div>';	
							}
							/*Modified on 28th June 2006 - Ends
							*SR 1042 International DF Sale */
							
							if (airlineCode == true)
							{
								oCell = oRow.insertCell();
								oCell.bgColor = bgcolor1;
								oCell.innerHTML = '<div class="textfield">' + naccsCodeSource.options[len].value + '</div>';
							}
							sourceLength = valueSource.length;
							for(var i=0;i<sourceLength; i++)
							{
								var chk1 = eval("document.referenceDataForm.check" + i);
								if (chk1 != null)
								{
									chk1.disabled = false;
									chk1.checked = false;
								}
							}
						}
						else
						{
							alert("E-1195: Value already exists.");
							document.referenceDataForm.value.select();
							document.referenceDataForm.value.focus();
							return;
						}
					}
					else
					{
						alert("E-1196: Code already exists.");
						document.referenceDataForm.code.select();
						document.referenceDataForm.code.focus();
						return;
					}
				}
				else
				{
					alert("E-1197: Value should not empty.");
					document.referenceDataForm.value.value = "";
					document.referenceDataForm.value.focus();
					return;
				}
			}
			else
			{
				alert("E-1198: Code should not empty.");
				document.referenceDataForm.code.value = "";
				document.referenceDataForm.code.focus();
				return;
			}
		}	
	}
	else
	{
		alert("E-1199: Please select reference type.");		
		document.referenceDataForm.referenceType.focus();
	}		
}

function removeFromList()
{
	var codeSource = eval(document.referenceDataForm.codeIdList);
	var valueSource = eval(document.referenceDataForm.codeValueList);
	var shift = false;
	var store = false;
	/*Modified on 28th June 2006 - Starts
	*SR 1042 International DF Sale */
	
	var pickup = false;
	
	/*Modified on 28th June 2006 - Ends
	*SR 1042 International DF Sale */
	
	var airlineCode = false;
	var fromTimeSource;
	var toTimeSource;
	var codeFlagSource;
	/*Modified on 28th June 2006 - Starts
	*SR 1042 International DF Sale */
	
	var pikcupFlagSource;
	/*Modified on 28th June 2006 - Ends
	*SR 1042 International DF Sale */
	
	var naccsCodeSource;
	if(document.referenceDataForm.referenceType.value == "6")
	{	
		shift = true;
		fromTimeSource = eval(document.referenceDataForm.fromTime);
		toTimeSource = eval(document.referenceDataForm.toTime);
	}
	if(document.referenceDataForm.referenceType.value == "3")
	{
		store = true;
		codeFlagSource = eval(document.referenceDataForm.storeFlag);	
	}
	/*Modified on 28th June 2006 - Starts
	*SR 1042 International DF Sale */
	
	if(document.referenceDataForm.referenceType.value == "5")
	{
		pickup = true;
		pikcupFlagSource = eval(document.referenceDataForm.pickupFlag);	
	}
	/*Modified on 28th June 2006 - Ends
	*SR 1042 International DF Sale */
	
	if(document.referenceDataForm.referenceType.value == "8")
	{
		airlineCode = true;
		naccsCodeSource = eval(document.referenceDataForm.naccsCodes);	
	}
	
	
	var len = document.referenceDataForm.codeIdList.length;
		
	var chkcount = 0;
	
	for(var i=0;i<len; i++)
	{
		var chk1 = eval("document.referenceDataForm.check" + i);
		if (chk1 != null)
		{
			if(chk1.checked)
			{
				referenceDataForm.code.value=codeSource.options[i-chkcount].value;
				referenceDataForm.code.disabled = true;
				referenceDataForm.value.value=valueSource.options[i-chkcount].value;
				codeSource.options[i-chkcount] = null   //i-chkcount is done inorder to account for the change in position of an option because of the removal of preceding options
				valueSource.options[i-chkcount] = null;
				if(airlineCode == true)
				{
					referenceDataForm.naccsCode.value = naccsCodeSource.options[i-chkcount].value;
					naccsCodeSource.options[i-chkcount] = null;
				}
				
				if (shift == true)
				{
					var fromTime = fromTimeSource.options[i-chkcount].value;
					var toTime = toTimeSource.options[i-chkcount].value;
					var pos = fromTime.indexOf(":");
					var fromHr = fromTime.substring(0,pos);
					var fromMin = fromTime.substring(pos+1, fromTime.length);
						
					pos = toTime.indexOf(":");
					var toHr = toTime.substring(0,pos);
					var toMin = toTime.substring(pos+1, toTime.length);
						
					var timeLength =document.referenceDataForm.fromHrList.length;
					
					for ( var j = 0; j < timeLength; j++)
					{
						if (document.referenceDataForm.fromHrList.options[j].value == fromHr)
						{
							document.referenceDataForm.fromHrList.options[j].selected = true;
							
						}
						if (document.referenceDataForm.toHrList.options[j].value == toHr)
						{
							document.referenceDataForm.toHrList.options[j].selected = true;
							
						}
					}
					
					
					var minLength =document.referenceDataForm.fromMinList.length;
					for ( var k = 0; k < minLength; k++)
					{
						if (document.referenceDataForm.fromMinList.options[k].value == fromMin)
						{
							document.referenceDataForm.fromMinList.options[k].selected = true;
							
						}
						if (document.referenceDataForm.toMinList.options[k].value == toMin)
						{
							document.referenceDataForm.toMinList.options[k].selected = true;
						}		
					}
					fromTimeSource.options[i-chkcount] = null;
					toTimeSource.options[i-chkcount] = null;
				}
				if(store == true)
				{
					if(codeFlagSource.options[i-chkcount].value == "Y")
					{
						document.referenceDataForm.codeFlag.checked = true;
					}	
					else
					{
						document.referenceDataForm.codeFlag.checked = false;
					}
					codeFlagSource.options[i-chkcount] = null   //i-chkcount is done inorder to account for the change in position of an option because of the removal of preceding options				
				}
	/*Modified on 28th June 2006 - Starts
	*SR 1042 International DF Sale */

				if(pickup == true)
				{
					if(pikcupFlagSource.options[i-chkcount].value == "Y")
					{
						document.referenceDataForm.pickupCodeFlag.checked = true;
					}	
					else
					{
						document.referenceDataForm.pickupCodeFlag.checked = false;
					}
					pikcupFlagSource.options[i-chkcount] = null   //i-chkcount is done inorder to account for the change in position of an option because of the removal of preceding options				
				}
	/*Modified on 28th June 2006 - Ends
	*SR 1042 International DF Sale */
	
				chkcount++;
			}
		}
		
	}
	
	var oTable = eval(document.all("codeValueTable"));
	
	//The length of the table is len + 1 (including the heading)
	
	for(var i=1;i<=len; i++) 
	{
		oTable.deleteRow(1);
	}	
	
	
	
	var oRow;
	var oCell;

	len = document.referenceDataForm.codeIdList.length;
	var bgcolor1;
	
	for(var i=0; i<len; i++)
	{
		if(i%2 == 0)
			bgcolor1 = "#FAFAFA";
		else
			bgcolor1 = "#FFFEF6";

		oRow = oTable.insertRow();
		oCell = oRow.insertCell();
		oCell.innerHTML = "<input type=checkbox name=check" + i + " onclick=changeBox('check" + i + "')>";
		oCell.bgColor= bgcolor1;
		oCell = oRow.insertCell();
		
		oCell.innerHTML = '<div class="textfield">' + codeSource.options[i].value + '</div>';
		oCell.bgColor= bgcolor1;
		oCell = oRow.insertCell();
		oCell.innerHTML = '<div class="textfield">' + valueSource.options[i].value + '</div>';
		oCell.bgColor= bgcolor1;
		if (shift == true)
		{
			oCell = oRow.insertCell();
			oCell.innerHTML = '<div class="textfield">' + fromTimeSource.options[i].value + '</div>';
			oCell.bgColor= bgcolor1;
			oCell = oRow.insertCell();
			oCell.innerHTML = '<div class="textfield">' + toTimeSource.options[i].value + '</div>';
			oCell.bgColor= bgcolor1;
		}
		if (store == true)
		{
			oCell = oRow.insertCell();
			oCell.innerHTML = '<div class="textfield">' + codeFlagSource.options[i].value + '</div>';
			oCell.bgColor= bgcolor1;
		}

	/*Modified on 28th June 2006 - Starts
	*SR 1042 International DF Sale */
		
		if (pickup == true)
		{
			oCell = oRow.insertCell();
			oCell.innerHTML = '<div class="textfield">' + pikcupFlagSource.options[i].value + '</div>';
			oCell.bgColor= bgcolor1;
		}
	/*Modified on 28th June 2006 - Ends
	*SR 1042 International DF Sale */

		if (airlineCode == true)
		{
			oCell = oRow.insertCell();
			oCell.innerHTML = '<div class="textfield">' + naccsCodeSource.options[i].value + '</div>';
			oCell.bgColor= bgcolor1;			
		}
	}
	/*if(document.referenceDataForm.codeIdList.length == 0)
	{		
		codeSource.options[0]	= new Option("-1", "-1");		
	}*/
	
}
function saveRefData()
{
	document.referenceDataForm.subaction.value="saveReferenceData";
	if (document.referenceDataForm.referenceType.value != "-1")
	{
		var length = document.referenceDataForm.codeIdList.length;		
		if(length != null)
		{	
			checkValue = true;
			/*if (length == 0)
			{
				checkValue = false;
			}
			if (length == 1)
			{
				if (document.referenceDataForm.codeIdList.options[0].value == -1)
				{
					checkValue = false;
				}
				else
				{
					checkValue = true;
				}
			}*/
			
			if(checkValue == true)
			{
				for(var i = 0; i < length; i++)
				{
					if (document.referenceDataForm.codeIdList.options[i] != null) 
					{
						document.referenceDataForm.codeIdList.options[i].selected = true;				
					}
					if (document.referenceDataForm.codeValueList.options[i] != null) 
					{
						document.referenceDataForm.codeValueList.options[i].selected = true;				
					}
					if(document.referenceDataForm.referenceType.value == "6")
					{
						if (document.referenceDataForm.fromTime.options[i] != null) 
						{
							document.referenceDataForm.fromTime.options[i].selected = true;				
						}
						if (document.referenceDataForm.toTime.options[i] != null) 
						{
							document.referenceDataForm.toTime.options[i].selected = true;				
						}
					}
					if(document.referenceDataForm.referenceType.value == "3")
					{
						if (document.referenceDataForm.storeFlag.options[i] != null) 
						{
							document.referenceDataForm.storeFlag.options[i].selected = true;	
						}	
					}
					/*Modified on 28th June 2006 - Starts
					*SR 1042 International DF Sale */
					
					if(document.referenceDataForm.referenceType.value == "5")
					{
						if (document.referenceDataForm.pickupFlag.options[i] != null) 
						{
							document.referenceDataForm.pickupFlag.options[i].selected = true;	
						}	
					}
					
					/*Modified on 28th June 2006 - Ends
					*SR 1042 International DF Sale */
					
					if(document.referenceDataForm.referenceType.value == "8")
					{
						if (document.referenceDataForm.naccsCodes.options[i] != null) 
						{
							document.referenceDataForm.naccsCodes.options[i].selected = true;	
						}	
					}
				}
				document.referenceDataForm.submit();	
			}	
			else
			{
				alert("E-1200: Insert atleast one reference data.");
				document.referenceDataForm.value.select();
				document.referenceDataForm.value.focus();
			}		
		}		
		else
		{
			alert("E-1201: Insert atleast one reference data.");
			document.referenceDataForm.value.select();
			document.referenceDataForm.value.focus();
		}
	}
	else
	{
		alert("E-1202: Please select atleast one reference type.");		 
		document.referenceDataForm.referenceType.focus();		
	}
}
function changeBox(name)
{
	var length = document.referenceDataForm.codeIdList.length;
	var result = "unchecked";
	var box = eval("document.referenceDataForm."+name);
	if(box.checked == true )
	{
		result = "checked";
	}
	if(length != null)
	{
		for(var i = 0; i < length; i++)
		{
			var chk1 = eval("document.referenceDataForm.check" + i);
			if (chk1 != null)
			{
				if(chk1.name != name)
				{
					if(result == "checked")
					{
						chk1.disabled = true;
					}
					else 
					{
						chk1.disabled = false;					
					}
				}
			}	
		}	
	}	
}
function saveActivate()
{
	if ((userForm.reason.value != null) && (userForm.reason.value.length != 0))
	{
		userForm.subaction.value="activateUser";
		userForm.saveReason.value="true";
		userForm.submit();
		
	}
	else
	{
		alert("E-1203: Reason cannot be empty.");
		document.userForm.reason.select();
		document.userForm.reason.focus();
	}
}

function checkReasonLength()
{
	if (userForm.reason.value != null)
	{
		var reason = userForm.reason.value;
		if (reason.length  > 50)
		{
			userForm.reason.value = reason.substring(0,50);
					
			userForm.reason.focus();
		}
	}
}

function onOk()
{
	if((document.userForm.fromPage.value == "maintainUserPage") || (document.userForm.fromPage.value == "SearchUserPage"))
	{
		document.userForm.subaction.value="maintainUserPage";
	}
	else
	{
		document.userForm.subaction.value="createUserPage";	
	}
	var presentValue = document.userForm.present.value;
	if(presentValue == false)
	{
		var length = document.userForm.assignedTransactionIds.length;
		if((length != null) && (length != 0))
		{
			for (var i = 0; i < length; i++)
			{
				document.userForm.assignedTransactionIds.options[i].selected = false;	
			}
		}		
	}
	document.userForm.submit();
}



function validateTimeHrs(opnHr,opnMns,closeHr,closeMns)
{

	
	var openHrs = parseInt(opnHr,10);
	var openMns = parseInt(opnMns,10);
	var closeHrs = parseInt(closeHr,10);
	var closeMins = parseInt(closeMns,10);

	
	if(openHrs == closeHrs)	
	{
		if(openMns > closeMins)
		{
			alert("E-1204: To time should  be greater than from time.");
			return (true);
		}
		else if(openMns == closeMins)
		{
			alert("E-1205: From time should not be same as to time.");
			return (true);
		}
		else
		return (false);
	}
	else if(openHrs > closeHrs)
	{
		alert("E-1206: To time should  be greater than from time.");
		return (true);
	}
	else
	{
		return (false);
	}
}
function search()
{
	var	result = nameCheck(document.searchUserForm.lastName , 'Last Name');
	if (result == true)
	{
		result = nameCheck(document.searchUserForm.firstName , 'First Name');
		
		
		
		if (result == true)
		{
			result = checkSpecialCharacters(document.searchUserForm.employeeId.value);
			
			if (result == true)
			{
				document.searchUserForm.subaction.value = "searchUserDetails";
				document.searchUserForm.submit();
			}
			else
			{
				alert("E-1207: Special characters are not allowed in employee ID.");
				document.searchUserForm.employeeId.select();
				document.searchUserForm.employeeId.focus();
			}
		}
		}
}

function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}
function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-5104: " + label + " should have " + len + " " + type+".");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}
function validatePAXNumber(paxvar)
{


var vpaxn=paxn.exec(paxvar.value);


	if(!vpaxn)
	{
		window.alert("E-5101: PAX number can only contain numbers.");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	if(!checklength(paxvar,10,"PAX Number","digits","y"))
		return(false);
	
	if(paxvar.value == "0000000000")
	{
		alert("E-5102: Enter a valid PAX number.");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	return(true);

}
function isBlankValue(value, label)
{
	if (value=="" || value.length <= 0)
	{
		alert("E-5131: "+label+" cannot be empty.");
		return false;
	}
	else
	{
		return true;
	}
}	
function createRacPreAssignment()
{

	//Validation for RACCode
		
	var racCode = document.racPreAssignmentForm['racPreAssignmentBean.racCode'].value;
		
	if (racCode == -1)
	{
		alert('E-6901: Select a valid RAC Code');
		document.racPreAssignmentForm['racPreAssignmentBean.racCode'].focus();
		return false;
	}

	//Added Remarks validation for CR1859
		
	var remarks = document.racPreAssignmentForm['racPreAssignmentBean.remarks'].value;
	var remarksexp = /[~']/;

	if(remarksexp.exec(remarks))			
	{	
		window.alert("E-6903: Remarks should not have ~ and ' characters. Please enter again.");	
		document.racPreAssignmentForm['racPreAssignmentBean.remarks'].focus();
		return false;
	}
	
	//Validation for Start PAX No
		
	var startPaxValue = document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].value;
	var blankStartPaxValue = isBlankValue(startPaxValue,"Starting PAX Number");
	
		
	if (!blankStartPaxValue)
	{
		
		document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].focus();
		return false;
	}
	else
	{
		
		if(!validatePAXNumber(document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber']))
			
		{
		
		document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].focus();
		return false;
		}
	
	}
	
	//Validation for End PAX No
			
		var endPaxValue = document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].value;
		var blankEndPaxValue = isBlankValue(endPaxValue,"Ending PAX Number");
		
			
		if (!blankEndPaxValue)
		{
			
			document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].focus();
			return false;
		}
		else
		{
			
			if(!validatePAXNumber(document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber']))
				
			{
			
			document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].focus();
			return false;
			}
		
	}
	
	//Start PAX No Should be smaller than End PAX No
	var endPaxNumber = document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].value;
	var startPaxNumber = document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].value;
	
	if(startPaxNumber > endPaxNumber)
	{
	
	alert('E-6902:Starting PAX No should be smaller than Ending PAX No');
	document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].focus();
	return false;
	
	}
	
	
	document.racPreAssignmentForm.action="racPreAssignment.do?subaction=createRacPreAssignmentConfirm";
	document.racPreAssignmentForm.submit();
	return true;
}

function clearRacPreAssignment()
{
	document.racPreAssignmentForm['racPreAssignmentBean.racCode'].value = -1  ;
	document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].value = "";
	document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].value = "";
	//Added for CR1859 to clear the added Remarks field
	document.racPreAssignmentForm['racPreAssignmentBean.remarks'].value = "";
	document.racPreAssignmentForm['racPreAssignmentBean.racCode'].focus();
	return;
}

function updateRacPreAssignment() {
	
	//Added Remarks validation for CR1859
		
	var remarks = document.racPreAssignmentForm['racPreAssignmentBean.remarks'].value;
	var remarksexp = /[~']/;

	if(remarksexp.exec(remarks))			
	{	
		window.alert("E-6903: Remarks should not have ~ and ' characters. Please enter again.");
		document.racPreAssignmentForm['racPreAssignmentBean.remarks'].focus();
		return;
	}
	
	//Validation for Start PAX No
		
	var startPaxValue = document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].value;
	var blankStartPaxValue = isBlankValue(startPaxValue,"Starting PAX Number");
	
		
	if (!blankStartPaxValue)
	{
		document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].focus();
		return;
	}
	else
	{
		
		if(!validatePAXNumber(document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber']))
			
		{
		
		document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].focus();
		return;
		
		}
	
	}
	
	//Validation for End PAX No
			
		var endPaxValue = document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].value;
		var blankEndPaxValue = isBlankValue(endPaxValue,"Ending PAX Number");
		
			
		if (!blankEndPaxValue)
		{
			
			document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].focus();
			return;
		}
		else
		{
			
			if(!validatePAXNumber(document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber']))
				
			{
			
			document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].focus();
			return ;
			}
		
	}
	
	//Start PAX No Should be smaller than End PAX No
	var endPaxNumber = document.racPreAssignmentForm['racPreAssignmentBean.endPaxNumber'].value;
	var startPaxNumber = document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].value;
	
	if(startPaxNumber > endPaxNumber)
	{
	
	alert('E-6902:Starting PAX No should be smaller than Ending PAX No');
	document.racPreAssignmentForm['racPreAssignmentBean.startPaxNumber'].focus();
	return ;
	
	}

	racPreAssignmentForm.action="racPreAssignment.do?subaction=updateRacPreAssignment&modify=true";
	racPreAssignmentForm.submit();

}

function deleteRacPreAssignment() {
	deletePrompt(racPreAssignmentForm, 
			"racPreAssignment.do?subaction=updateRacPreAssignment&delete=true");
}
