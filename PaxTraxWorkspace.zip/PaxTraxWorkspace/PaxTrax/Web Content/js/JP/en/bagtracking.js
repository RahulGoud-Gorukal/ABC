function typechanged()
{
	var carton2  = document.all("carton1");
	var cage2 = document.all("cage1");
	
	if(binLocationForm.wareHouse.checked)
	{
		var i=0;
		
		for(i =0; i<carton2.length;i++)
		{
			carton2[i].style.display = "";
			cage2[i].style.display = "none";
		}
		//binLocationForm.urgentBags.disabled = false;
		//binLocationForm.urgentBags.checked = false;
		binLocationForm.holdingLocation.checked = false;
		binLocationForm.holdingLocation.disabled = true;
	}

	if (binLocationForm.airPort.checked)	
	{
		var i=0;
		
		for(i =0; i<cage2.length;i++)
		{
			carton2[i].style.display = "none";
			cage2[i].style.display = "";
		}		
		binLocationForm.holdingLocation.disabled = false;
		//binLocationForm.holdingLocation.checked = false;
		//binLocationForm.urgentBags.checked = false;
		//binLocationForm.urgentBags.disabled = true;
	}
}

function binCapacityEnable()
{
	if (binLocationForm.holdingLocation.checked)
	{
		binLocationForm.capacity.value = "";
		binLocationForm.capacity.disabled = true;
	}
	else
	{
		binLocationForm.capacity.disabled = false;
	}
}

function binCheck()
{
	typechanged();	
	var wbin = /^[A-Z a-z]\d{2}[A-Z a-z]-\d$/;
	var abin = /^[A-Z a-z]{2}\d{2}$/;
	
		if (binLocationForm.wareHouse.checked)	
		{
				binLocationForm.pickupLocation.selectedIndex =0;
				binLocationForm.pickupLocation.disabled = true;
		}
		if (binLocationForm.airPort.checked)	
		{
			binLocationForm.pickupLocation.disabled = false;
		}
	
	/*if (!isBlank(binLocationForm.binLocation,"Bin Location","y"))
	{*/
	
		if (binLocationForm.wareHouse.checked)	
		{
				
				/*var vwbin = wbin.exec(binLocationForm.binLocation.value);
				if (!vwbin)
				{
				alert("E-4100: Bin location format should be A-23-L-3");
				binLocationForm.binLocation.select();
				binLocationForm.binLocation.focus();
				return false;
				}*/
			/*if(binLocationForm.capacity.value == "")
			{*/
				binLocationForm.capacity.value="2";	
			//}
		}

		if (binLocationForm.airPort.checked)	
		{
			
			/*var vabin = abin.exec(binLocationForm.binLocation.value);
			if (!vabin)
			{
			alert("E-4101: Bin location format should be A-L-93");
			binLocationForm.binLocation.select();
			binLocationForm.binLocation.focus();
			return false;
			}*/

			/*if(binLocationForm.capacity.value == "")
			{*/
		 		binLocationForm.capacity.value="1";
		 	//}
		}
		
		
		return true;
	//}
	
		
	return false;
}

function binCheck1()
{
	typechanged();	
	var wbin = /^[A-Z a-z]\d{2}[A-Z a-z]\d$/;
	var abin = /^[A-Z a-z]{2}\d{2}$/;
	
		if (binLocationForm.wareHouse.checked)	
		{
				binLocationForm.pickupLocation.selectedIndex =0;
				binLocationForm.pickupLocation.disabled = true;
		}
		if (binLocationForm.airPort.checked)	
		{
			binLocationForm.pickupLocation.disabled = false;
		}
	
	if (!isBlank(binLocationForm.binLocation,"Bin Location","y"))
	{
	
		if (binLocationForm.wareHouse.checked)	
		{
				
				var vwbin = wbin.exec(binLocationForm.binLocation.value);
				if (!vwbin)
				{
				alert("E-4100: Bin location format should be A23L3");
				binLocationForm.binLocation.select();
				binLocationForm.binLocation.focus();
				return false;
				}
			
		}

		if (binLocationForm.airPort.checked)	
		{
			
			var vabin = abin.exec(binLocationForm.binLocation.value);
			if (!vabin)
			{
			alert("E-4101: Bin location format should be AL93");
			binLocationForm.binLocation.select();
			binLocationForm.binLocation.focus();
			return false;
			}
		}
		
		
		return true;
	}
	
		
	return false;
}

var remarks = /^[\w\s]*$/;
var capacity = /^\d*$/;
function saveBinLocation()
{
	if (binLocationForm.page.value == "createBinLocation")
	{
	if (!binCheck1())
		return;
	}
		
	if (!(binLocationForm.wareHouse.checked || binLocationForm.airPort.checked))	
	{
		alert("E-4102: Select a valid type.");
		return;
	}

	
	if (binLocationForm.pickupLocation.selectedIndex == 0 && binLocationForm.airPort.checked)
	{
		alert("E-4103: Select a valid pickup location.");
		binLocationForm.pickupLocation.focus();
		return;
	}
	
	if (!binLocationForm.capacity.disabled)
	{
		if (isBlank(binLocationForm.capacity,"Capacity","y"))
			return;	
			
		var vcapacity = capacity.exec(binLocationForm.capacity.value);
		if (!vcapacity)
		{
			alert("E-4104: Capacity can only be numeric.");
			binLocationForm.capacity.select();
			binLocationForm.capacity.focus();
			return;
		}
		
		if (binLocationForm.capacity.value == 0)
		{
			alert("E-4105: Capacity cannot be zero.");
			binLocationForm.capacity.select();
			binLocationForm.capacity.focus();
			return;
		}
	}
	
	var vremarks = remarks.exec(binLocationForm.remarks.value);
	if (!vremarks)
	{
		alert("E-4106: Special characters are not allowed in remarks.");
		binLocationForm.remarks.select();
		binLocationForm.remarks.focus();
		return;
	}
	if (binLocationForm.page.value == "createBinLocation")
	{
		
		binLocationForm.action="binLocationAction.do?subaction=saveBinLocationDetails";
	}
	else
	{
		binLocationForm.action="binLocationAction.do?subaction=updateBinLocationDetails";
	}
	binLocationForm.submit();
}

function isBlank(str1,label,prompt)
{
	if(str1.value == "")
	{
		if(prompt == "y" || prompt == "Y")
		{
			alert("E-4107: " + label + " cannot be empty.");
			str1.focus();
		}

		return(true);		
	}

	return(false);
}

function ltrim(s) {
	return s.replace(/^\s*/, "");
}

function rtrim(s) {
	return s.replace(/\s*$/, "");
}

/**
funtion using for removing the empty spaces from both sides of  the String
*/
function trim(value) {
	return rtrim(ltrim(value));
}

function clearBinLocationPage()
{
	binLocationForm.action = "binLocationAction.do?subaction=createBinLocationPage";
	binLocationForm.submit();
}

function getBinLocation()
{
	if (window.event.keyCode == 9)
	{
		binLocationForm.binLocation.value=trim(binLocationForm.binLocation.value);
		if (!isBlank(binLocationForm.binLocation,"","n"))
		{
			var bin = /^[\w-]+$/;
			var vbin = bin.exec(binLocationForm.binLocation.value);
			if (!vbin)
			{
				alert("E-4108: Bin Location should not contain characters other than alphabets, digits and -");
				binLocationForm.binLocationCheck.value = "y";
				return (false);
			}
		
			binLocationForm.action = "binLocationAction.do?subaction=getBinLocation";
			binLocationForm.submit();		
		}
	}
}

function binBlur()
{
	if (binLocationForm.binLocationCheck.value == "y")
	{
		binLocationForm.binLocation.select();
		binLocationForm.binLocation.focus();
		binLocationForm.binLocationCheck.value = "";
	}
}

function binCreationConfirm()
{
	binLocationForm.action = "binLocationAction.do?subaction=createBinLocationPage";
	binLocationForm.submit();
}

function binPageEnable()
{
	binLocationForm.binLocation.disabled = true;
	
	binLocationForm.capacity.disabled = false;
	binLocationForm.remarks.disabled = false;
	document.all("save").style.display = "";
	document.all("delete").style.display = "";
	typechanged();
	binCapacityEnable();
	
	if (binLocationForm.wareHouse.checked)	
	{
		binLocationForm.pickupLocation.selectedIndex =0;
		binLocationForm.pickupLocation.disabled = true;
		if(binLocationForm.holdingLocation.checked)
		{
			binLocationForm.remarks.focus();
		}
		else
		{
			binLocationForm.capacity.focus();
		}
	}
	else
	{
		binLocationForm.pickupLocation.disabled = false;
		binLocationForm.pickupLocation.focus();
	}
}


function deletePrompt()
{
	if(window.confirm("Do you want to delete"))
	{
		binLocationForm.action="binLocationAction.do?subaction=removeBinLocationDetails";
		binLocationForm.submit();
	}
}

function binLocationCancel()
{
	if ((binLocationForm.fromPage.value == "null") || (binLocationForm.fromPage.value == "maintainBin"))
		binLocationForm.action="home.do?subaction=bagtrackingHomePage";

	if (binLocationForm.fromPage.value == "searchBin")
	{
		var frompageno = binLocationForm.fromPageNumber.value;
		binLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails&pageNumber="+frompageno;
	}
	binLocationForm.submit();
}

function iconSearch()
{
	 binLocationForm.action="searchBinLocationAction.do?subaction=goToBinLocationSearchPage";
	 binLocationForm.submit();
}

function searchTypeChanged()
{
	var carton2  = document.all("carton1");
	var cage2 = document.all("cage1");
	
	if(searchBinLocationForm.wareHouse.checked)
	{
		carton2.style.display = "";
		cage2.style.display = "none";
		searchBinLocationForm.pickupLocation.selectedIndex =0;
		searchBinLocationForm.pickupLocation.disabled = true;
	}

	if (searchBinLocationForm.airPort.checked)	
	{
		carton2.style.display = "none";
		cage2.style.display = "";
		searchBinLocationForm.pickupLocation.disabled = false;
	}
}

function searchBinLocationSubmit()
{
	var vcapacity = capacity.exec(searchBinLocationForm.capacity.value);
	if (!vcapacity)
	{
		alert("E-4109: Capacity can only be numeric.");
		searchBinLocationForm.capacity.select();
		searchBinLocationForm.capacity.focus();
		return;
	}
	var vremarks = remarks.exec(searchBinLocationForm.remarks.value);
	if (!vremarks)
	{
		alert("E-4110: Special characters are not allowed in remarks.");
		searchBinLocationForm.remarks.select();
		searchBinLocationForm.remarks.focus();
		return;
	}
	searchBinLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails";
	searchBinLocationForm.submit();
}

function binMaintainConfirm()
{
	if (binLocationForm.fromPage.value == "null")
		binLocationForm.action="home.do?subaction=bagtrackingHomePage";
	if (binLocationForm.fromPage.value == "maintainBin")
		binLocationForm.action="binLocationAction.do?subaction=maintainBinLocationPage";
	if (binLocationForm.fromPage.value == "searchBin")
	{
		var frompageno = binLocationForm.fromPageNumber.value;
		if (frompageno == "null")
		{
		binLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails";
		}
		else
		{
		binLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails&pageNumber="+frompageno;
		}
	}
	binLocationForm.submit();
}

function createTruckSubmit()
{
	if (truckForm.page.value == "createTruck")
	{
	if (isBlank(truckForm.number,"Truck number","y"))
		return;
	}
		
	var truck = /^[\w]*$/;
	var vtruck = truck.exec(truckForm.number.value);
	if (!vtruck)
	{
		alert("E-4111: Special characters are not allowed in truck number.");
		truckForm.number.select();
		truckForm.number.focus();
		return;
	}
	
	if(truckForm.number.value == 0)
	{
		alert("E-4111: Truck number cannot be zero.");
		truckForm.number.select();
		truckForm.number.focus();
		return;
	}	
	if (special(truckForm.model,"model"))
		return;

	if (special(truckForm.manufacturer,"manufacturer"))
		return;
		
	var year = /^\d*$/;
	var vyear = year.exec(truckForm.year.value);
	if (!vyear)
	{
		alert("E-4112: Year can only be numeric.");
		truckForm.year.select();
		truckForm.year.focus();
		return;
	}
	
	if (special(truckForm.make,"make"))
		return;

	if (special(truckForm.remarks,"remarks"))
		return;

	if (truckForm.page.value == "createTruck")
	{
	truckForm.action = "truckAction.do?subaction=saveTruckDetails";
	truckForm.submit();	
	}
	else
	{
	truckForm.action = "truckAction.do?subaction=updateTruckDetails";
	truckForm.submit();	
	}
}

function special(str,label)
{
	var remarks = /^[\w\s]*$/;
	var vtruck = remarks.exec(str.value);
	if (!vtruck)
	{
		alert("E-4113: Special characters are not allowed in "+label+".");
		str.select();
		str.focus();
		return true;
	}
	return false;
}

function getTruck()
{
	if (window.event.keyCode == 9)
	{
		truckForm.number.value=trim(truckForm.number.value);
		if (!isBlank(truckForm.number,"","n"))
		{
			var truck = /^[\w]*$/;
			var vtruck = truck.exec(truckForm.number.value);
			if (!vtruck)
			{
				alert("E-4114: Special characters are not allowed in truck number.");
				truckForm.number.select();
				truckForm.number.focus();
				truckForm.truckCheck.value = "y";
				return;
			}
					
			truckForm.action = "truckAction.do?subaction=selectTruck";
			truckForm.submit();		
		}
	}
}

function truckBlur()
{
	if (truckForm.truckCheck.value == "y")
	{
		truckForm.number.select();
		truckForm.number.focus();
		truckForm.truckCheck.value = "";
	}
}

function iconSearchTruck()
{
	 truckForm.action="searchTruckAction.do?subaction=goToTruckSearchPage";
	 truckForm.submit();
}

function clearTruckPage()
{
	truckForm.action="truckAction.do?subaction=createTruckPage";
	truckForm.submit();
}

function truckCreationConfirm()
{
	truckForm.action = "truckAction.do?subaction=createTruckPage";
	truckForm.submit();
}

function truckPageEnable()
{
	truckForm.number.disabled = true;
	truckForm.model.disabled = false;
	truckForm.manufacturer.disabled = false;
	truckForm.year.disabled = false;
	truckForm.make.disabled = false;
	truckForm.remarks.disabled = false;
	document.all("save").style.display = "";
	document.all("delete").style.display = "";
	truckForm.model.focus();
}

function truckDelete()
{
	if(window.confirm("Do you want to delete"))
	{
		truckForm.action = "truckAction.do?subaction=removeTruckDetails";
		truckForm.submit();
	}
}

function truckCancel()
{
	if ((truckForm.fromPage.value == "null") || (truckForm.fromPage.value == "maintainTruck"))
		truckForm.action="home.do?subaction=bagtrackingHomePage";
	if (truckForm.fromPage.value == "searchTruck")
	{
		var frompageno = truckForm.fromPageNumber.value;
		truckForm.action="searchTruckAction.do?subaction=searchTruckDetails&pageNumber="+frompageno;
	}
	truckForm.submit();
	
}

function truckMaintainConfirm()
{
	if (truckForm.fromPage.value == "null")
		truckForm.action="home.do?subaction=bagtrackingHomePage";
	if (truckForm.fromPage.value == "maintainTruck")
		truckForm.action="truckAction.do?subaction=maintainTruckPage";
	if (truckForm.fromPage.value == "searchTruck")
	{
		var frompageno = truckForm.fromPageNumber.value;
		if (frompageno == "null")
		{
		truckForm.action="searchTruckAction.do?subaction=searchTruckDetails";
		}
		else
		{
		truckForm.action="searchTruckAction.do?subaction=searchTruckDetails&pageNumber="+frompageno;
		}
	}
	truckForm.submit();
}

function searchTruckSubmit()
{
	if (special(searchTruckForm.manufacturer,"manufacturer"))
		return;

	if (special(searchTruckForm.make,"make"))
		return;

	if (special(searchTruckForm.model,"model"))
		return;

	var year = /^\d*$/;
	var vyear = year.exec(searchTruckForm.year.value);
	if (!vyear)
	{
		alert("E-4115: Year can only be numeric.");
		searchTruckForm.year.select();
		searchTruckForm.year.focus();
		return;
	}
	
	searchTruckForm.action = "searchTruckAction.do?subaction=searchTruckDetails";
	searchTruckForm.submit();
}


/*************************Cage Functions*******************************************/

var cageNumber=/^[\d]*$/;
var noOfCartons=/^[\d]+$/;
var cageDescription = /^[\w\s]*$/;
var specialCharacterMessage ="Special characters are not allowed for ";
var numericMessage=" can be only numeric.";


function changeLanguage(form,newLanguage,page,error)
{

	
	if(page=="search")
	{
		form.action="searchCageAction.do?country=JP&language="+newLanguage+"&errorCode="+error+"&pageNumber="+page;
	}
	else if(page=="paxRefund" || page == "paxFlightChange")
	{	
		//enableActionCheckBox(form); // This method exits in the PaxRefund Jsp
		form.action="paxRefund.do?country=JP&language="+newLanguage+"&errorCode="+error+"&page="+page;
		
	}
	else if(page=="paxDFpurchase")
	{	
		//enableActionCheckBox(form); // This method exits in the PaxRefund Jsp
		form.action="paxPurchaseEnquiry.do?country=JP&language="+newLanguage+"&errorCode="+error+"&page="+page;
		
	}
	else
	{
		form.action="cageAction.do?country=JP&language="+newLanguage+"&errorCode="+error+"&page="+page;
	}
		
	form.subaction.value="changeLanguage";
	form.submit();
}

function ltrim(s)
{
	return s.replace( /^\s*/, "" )
}

function rtrim(s)
{
	return s.replace( /\s*$/, "" );
}


function trim(s)
{
	return rtrim(ltrim(s));
}


function isNotEmpty(str1,label,prompt)
{
	var returnValue = true;
	var checkString = trim(str1.value);
	
	if(checkString == "")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-4116: " + label + " cannot be empty.");
			str1.select();
			str1.focus();
			returnValue = false;
		}

				
	}
	
	return(returnValue);
}


function validateCreateCageForm(cageForm)
{
	
	if(validateField(cageForm.cageNumber,'Cage number','Y',cageNumber,  "E-4127: Cage number"+numericMessage )
	&& validateCageLength(cageForm,cageForm.cageNumber.value.length)
	&& validateField(cageForm.cartonsPerCage,'Max.no.of cartons per cage','Y', noOfCartons,"E-4128: Max.no.of cartons per cage"+numericMessage)
	&& validateMaximumCartons(cageForm)
	&& validateField(cageForm.remarks,'Remarks','N', cageDescription , "E-4129: "+specialCharacterMessage +"remarks.")
	&& validateField(cageForm.description,'Description','N', cageDescription ,"E-4130: "+ specialCharacterMessage +"description."))
	{
		cageForm.action="cageAction.do?subaction=saveCageDetails";
		
		cageForm.submit();
	}
	
}

function validateMaximumCartons(form)
{
	if(trim(form.cartonsPerCage.value)==0)
	{
		alert("E-4131: Max.no.of cartons per cage cannot be zero.");
		form.cartonsPerCage.select();
		form.cartonsPerCage.focus();
		return false;
	}
	else
	return true;
}
function validateField(object, label, prompt, regularExpr, msg)
{
	
	var returnValue = true;
	returnValue=isNotEmpty(object,label,prompt);
	if(returnValue)
	{	
		
		var validated=regularExpr.exec(object.value);
		
		if(!validated)
		{
			alert(msg);
			object.select();
			object.focus();
			returnValue = false;
		}
	}
	return(returnValue)	;
}


function trimObject(obj)
{
	obj.value=trim(obj.value);
	return true;
}

function clearFields(form)
{
/*	form.cageNumber.value="";
	form.cartonsPerCage.value="";
	form.description.value="";
	form.remarks.value="";
	form.cageNumber.focus();*/
		form.action="cageAction.do?subaction=createCagePage";
	form.submit();
}

function createOkAction(form,forwardValue)
{
	if(forwardValue == "maintainCage")
	{
		var pageTransferValue = form.pageTransfer.value; 
		
		if(pageTransferValue == "updateSearch")
		{
			form.action="searchCageAction.do?subaction=searchCageDetails";
	
		}
		else
		{
		
			form.action="cageAction.do";
			form.subaction.value="maintainCagePage";
		}
	}
	else if(forwardValue == "createCage")
	{
		form.action="cageAction.do";
		form.subaction.value="createCagePage";
	}
		
	form.submit();
}

function searchCage(form)
{
	form.action="searchCage.do";
	form.subaction.value="createSearchPage";

	form.submit();
	
}

function onTabLoad(form)
{
	
	var keycode =window.event.keyCode;
	
	if(keycode == 9 && trim(form.cageNumber.value) != "")
	{
		
		var cageNumberValidated = cageNumber.exec(form.cageNumber.value);
		
		if(!cageNumberValidated)
		{
			alert( "E-4117: Cage number"+numericMessage);
			form.cageNumber.select();
			form.cageNumber.focus();
			return;
		}
		else if (! validateCageLength(form,form.cageNumber.value.length))
		{
		return false;
		}
		else
		{
			form.action="cageAction.do";
			form.subaction.value="loadCageDetails";
			form.submit();
		}	
	}
}

function enableFields(form)
{
	form.cageNumber.disabled =  true;
	form.cartonsPerCage.disabled = false;
	form.remarks.disabled = false;
	form.description.disabled = false;
}

function disableFields(form)
{

	form.cageNumber.disabled =  false;
	form.cartonsPerCage.disabled = true;
	form.remarks.disabled = true;
	form.description.disabled = true;
}


function validateMaintainCageForm(cageForm)
{

if(validateField(cageForm.cageNumber,'Cage number','Y',cageNumber, "E-4132: Cage number"+numericMessage )
	&& validateCageLength(cageForm,cageForm.cageNumber.value.length)
	&& validateField(cageForm.cartonsPerCage,'Max.no.of cartons per cage','Y', noOfCartons,"E-4133: Max.no.of cartons per cage"+numericMessage)
	&& validateMaximumCartons(cageForm)
	&& validateField(cageForm.remarks,'Remarks','N', cageDescription , "E-4134: "+specialCharacterMessage +"remarks.")
	&& validateField(cageForm.description,'Description','N', cageDescription , "E-4135: "+specialCharacterMessage +"description."))
	{
		cageForm.action="cageAction.do?subaction=updateCageDetails";
		
		cageForm.submit();
	}
}

function validateCageLength(form,len)
{
	if(form.cageNumber.value == 0)
	{
		alert("E-4132: Cage number cannot be zero.");
		form.cageNumber.select();
		form.cageNumber.focus();
		return false;
	}
	
	if(len< 3)
	{
		alert("E-4118: Cage number should have 3 characters.");
		form.cageNumber.select();
		form.cageNumber.focus();
		return false;
	}
	
	return true;
}

function cancelMaintainAction(cageForm)
{
	var pageTransferValue = cageForm.operation.value; 
		
	if(pageTransferValue == "updateSearch")
	{
		cageForm.action="searchCageAction.do?subaction=searchCageDetails";
	}
	/*else if(pageTransferValue == "updateReload")
	{
		cageForm.action="cageAction.do?subaction=maintainCagePage";	
	}*/
	else
	{
		cageForm.action="cageAction.do?subaction=cancel";
	}
	cageForm.submit();
}

function deleteMaintainPrompt(form)
{

	if(confirm("Do you want to delete."))
	{
		form.action="cageAction.do";
		form.subaction.value="removeCageDetails";
		form.submit();
	}
	else
	{
		return;
	}
}

function displayEditCage(cage,form)
{

	form.subaction.value="loadCageDetails";
	form.action="cageAction.do?index="+cage;
	form.submit();
}

function validateSearchCageForm(searchForm)
{
	if(validateField(searchForm.cageNumber,'Cage number','N',cageNumber, "Cage number"+numericMessage ))
	{
		searchForm.action="searchCageAction.do?subaction=searchCageDetails";
		searchForm.submit();
	}
}


/*************************Cage Functions*******************************************/

function generateTruckTrackingEnquiry()
{
	var truckNumber = document.all('truckNumber').value;
	if (truckNumber != "" &&  truckNumber !="-1")
	{
		document.truckTrackingEnquiryForm.action = "truckTrackingEnquiry.do";
		document.truckTrackingEnquiryForm.subaction.value = "getTruckTrackingEnquiry";
		document.truckTrackingEnquiryForm.submit();
	}
	else
	{
		alert("E-4119: Truck number not found");
		document.truckTrackingEnquiryForm.truckNumber.focus();
	}
}

function printTruckTrackingEnquiry()
{
	document.truckTrackingEnquiryForm.action = "truckTrackingEnquiry.do";
	document.truckTrackingEnquiryForm.subaction.value = "printTruckTrackingEnquiry";
	document.truckTrackingEnquiryForm.submit();
}
function getPaxPurchaseInquirySubmit()
{
	var paxNo = document.paxPurchaseInquiryForm.paxNumber.value;
	var keycode = window.event.keyCode;
	var paxPattern = /^[\d]{10}$/;
	if(paxNo == "" && keycode == "13")
	{
		alert("E-4120: Pax # cannot be empty");
		document.paxPurchaseInquiryForm.paxNumber.select();
		document.paxPurchaseInquiryForm.paxNumber.focus();		
		return false;
	}
	else if(paxNo != "" && keycode == "13")
	{
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX # should contain 10 digits");
				document.paxPurchaseInquiryForm.paxNumber.select();
				document.paxPurchaseInquiryForm.paxNumber.focus();			
				return false;
			}		
			else
			{
				document.paxPurchaseInquiryForm.action = "paxPurchaseEnquiry.do";
				document.paxPurchaseInquiryForm.subaction.value = "getPaxPurchaseInquiry";
				document.paxPurchaseInquiryForm.submit();
			}
	}
	
}
function getPaxPurchaseInquiry()
{
	var paxNo = document.paxPurchaseInquiryForm.paxNumber.value;
	var paxPattern = /^[\d]{10}$/;
	if(!isBlank(document.paxPurchaseInquiryForm.paxNumber,"PAX #","y"))
	{	
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4122: PAX # should contain 10 digits");
				document.paxPurchaseInquiryForm.paxNumber.select();
				document.paxPurchaseInquiryForm.paxNumber.focus();			
				return false;
			}		
			else
			{
				document.paxPurchaseInquiryForm.action = "paxPurchaseEnquiry.do";
				document.paxPurchaseInquiryForm.subaction.value = "getPaxPurchaseInquiry";
				document.paxPurchaseInquiryForm.submit();
			}
	}	
}

function getPaxDFPurchaseList(form)
{
	var paxNo = form.paxNumber.value;
	var keycode = window.event.keyCode;
	var paxPattern = /^[\d]{10}$/;
	if(paxNo == "" && keycode == "13")
	{
		alert("E-4120: Pax # cannot be empty");
		form.paxNumber.select();
		form.paxNumber.focus();		
		return false;
	}
	else if(paxNo != "" && keycode == "13")
	{
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX # should contain 10 digits");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return false;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do";
				form.subaction.value = "getPaxDFPurchaseList";
				form.submit();
			}
	}
	
}
function getPaxDPPurchaseList(form)
{
	var paxNo = form.paxNumber.value;
	var keycode = window.event.keyCode;
	var paxPattern = /^[\d]{10}$/;
	if(paxNo == "" && keycode == "13")
	{
		alert("E-4120: Pax # cannot be empty");
		form.paxNumber.select();
		form.paxNumber.focus();		
		return false;
	}
	else if(paxNo != "" && keycode == "13")
	{
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX # should contain 10 digits");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return false;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do";
				form.subaction.value = "getPaxDPPurchaseList";
				form.submit();
			}
	}
	
}
function paxDFPurchaseListSubmit(form)
{
	var paxNo = form.paxNumber.value;
	var paxPattern = /^[\d]{10}$/;
	if(!isBlank(form.paxNumber,"PAX #","y"))
	{	
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4122: PAX # should contain 10 digits");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do?subaction=getPaxDFPurchaseList";
				form.submit();
			}
	}	
}
function paxDPPurchaseListSubmit(form)
{
	var paxNo = form.paxNumber.value;
	var paxPattern = /^[\d]{10}$/;
	if(!isBlank(form.paxNumber,"PAX #","y"))
	{	
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4122: PAX # should contain 10 digits");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do?subaction=getPaxDPPurchaseList";
				form.submit();
			}
	}	
}
function approvePax(form)
{
	
	form.action = "paxPurchaseEnquiry.do";
	form.subaction.value = "approvePax";
	form.submit();
}

function rejectPax(form)
{
	
	form.action = "paxPurchaseEnquiry.do";
	form.subaction.value = "rejectPax";
	form.submit();
}


function parallelingReportSubmit(form)
{
	if(validateDate(form.fromDate,"yyyy/mm/dd","Departure Date","y"))
	{
		form.action = "paxPurchaseEnquiry.do?subaction=getPaxDetails";
		form.submit();
	}		
		
}
function printPaxPurchaseInquiry()
{
	document.paxPurchaseInquiryForm.action = "paxPurchaseEnquiry.do";
	document.paxPurchaseInquiryForm.subaction.value = "printPaxPurchaseEnquiry";
	document.paxPurchaseInquiryForm.submit();
}

function formatDateOnBlur(date1)
{
	if(date1.value!="")
	{
		if(validateDate(date1,"yyyy/mm/dd","Departure Date","y"))
			date1.value = strconvert(date1);			
	}
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-4123: " + label + " is invalid. Expected date format is " + dateformat+".");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}

function validateGeneratePicklistPage(print1)
{
	if(document.generatePicklistForm.pickupLocation.value=="-1")
	{
		alert("E-4124: Select a valid pickup location");
		document.generatePicklistForm.pickupLocation.focus();
		return(false);
	}
	
	if(document.generatePicklistForm.departureDate.value=="")
	{
		alert("E-4125: Departure Date cannot be blank.");
		document.generatePicklistForm.departureDate.select();
		document.generatePicklistForm.departureDate.focus();
		return(false);
	}
	
	if(!validateDate(document.generatePicklistForm.departureDate,"yyyy/mm/dd","Departure Date","y"))
		return(false);
	
	if(document.generatePicklistForm.shift.value=="-1")
	{
		alert("E-4126: Select a valid shift");
		document.generatePicklistForm.shift.focus();
		return(false);
	}
	
	if(print1=="print")
		document.generatePicklistForm.action="generatePicklistAction.do?subaction=getPickList&print=yes";
	else
		document.generatePicklistForm.action="generatePicklistAction.do?subaction=getPickList";
	
	document.generatePicklistForm.submit();
}

function strconvert(str1)
{
	var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}


function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}


function flightChangeSearch(form)
{
	if(!(validateDate(form.fromDate,"yyyy/mm/dd","From Date","y")))
	{		
		return(false);
	}
	if(!(validateDate(form.toDate,"yyyy/mm/dd","To Date","y")))
	{		
		return(false);	
	}
	if(form.fromDate.value > form.toDate.value)
	{
		alert("E-4127: To date should be greater than or equal to From date.");
		form.fromDate.focus();
		return false;
	}

form.action= "paxRefund.do";
form.subaction.value="searchFlightChangeItems";
form.submit();
	
}


function paxRefundPrint(form)
{
	
}


function paxRefundSave(form)
{
	
}

function paxRefundSearch(form)
{
	if(!(validateDate(form.fromDate,"yyyy/mm/dd","From Date","y")))
	{		
		return(false);
	}
	if(!(validateDate(form.toDate,"yyyy/mm/dd","To Date","y")))
	{		
		return(false);	
	}
	if(form.fromDate.value > form.toDate.value)
	{
		alert("E-4127: To date should be greater than or equal to From date.");
		form.fromDate.focus();
		return false;
	}
	form.action= "paxRefund.do";
	form.subaction.value="searchRefundItems";
	form.submit();	
}

function binLocationEnquiry(form)
{
	/*var arr1 = form.binLocFrom.value;
	var arr2 =	form.binLocTo.value;
	var i =arr1.split("~");
	var j =arr2.split("~");*/
	var i = form.binLocFrom.value;
	var j =	form.binLocTo.value;
	var len = form.binLocFrom.length;
	if(parseInt(len) < 2)
	{
		alert("E-4140: No bin locations available.");
		form.binLocFrom.focus();
		return false;
	}
	/*if(j==-1)
	{
		alert("E-4140: Select a valid to binLocation.");
		form.binLocTo.focus();
		return false;
	}*/
	if( parseInt(i)>parseInt(j) && parseInt(i) !=-1 && parseInt(j) !=-1)
	{
		alert("E-4140: To binLocation cannot be lesser than from binLocation.");
		form.binLocFrom.focus();
		return false;
	}
	form.action = "binLocReport.do?subaction=getBinLocReport";
	form.submit();
}

function submitPage()
	{
		if(document.forms[0].bagNumber.value!="")
		{
			if(validatebagNumber())
			{
				document.forms[0].method="POST";
				document.forms[0].action="bagTrackingEnquiryAction.do?subaction=getBagTrackingInquiry";
				document.forms[0].submit();
			}
		}
		else
		{
			alert("E-5205: Bag number cannot be empty.");
			document.forms[0].bagNumber.focus();
		}
	}
	
	function validatebagNumber()
	{
		var bag =/^\d{12,12}$/;
		var vbag = bag.exec(document.forms[0].bagNumber.value);
		
		if(!vbag)
		{
			alert("E-5205: Bag number should be 12 digit numeric.");
			document.forms[0].bagNumber.select();
			document.forms[0].bagNumber.focus();
			return(false);
		}		
		
		return(true);
	}	