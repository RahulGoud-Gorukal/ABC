var mywindow;
var txtBoxName;
var today = new Date();
var day;
var month;
var year;
var currentMonth;
var currentYear;

var isIE = document.all?true:false;
var isNav4 = document.layers?true:false;
var isNav6 = document.getElementById && !document.all?true:false;

//Function for getting 4 digit year
function y2k(number)
{
    return (number < 1000) ? number + 1900 : number;
}

//Function for padding zeros
function padout(number)
{
    return (number < 10) ? '0' + number : number;
}

//Function for setting the selected date value to the textbox
function restart()
{
	txtBoxName.value = '' + year + '/' + padout(month - 0 + 1) + "/" + padout(day);
      	txtBoxName.focus();
      	mywindow.close();
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}

//Function called for popping up the calendar window onclick of the calendar gif

function showCalendar(boxname)
{
	var flag=false;
	
	if(boxname.value != "")
	{
		temp = boxname.value.split("/"); //the value in the boxname field is split into month, date and year
	
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date

			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
	} 
	else 
	{ //If the boxname field is blank, the calendar opens with the current date selected
		flag = false;
	}

    
	//if flag is false default to today's date else default to the date value in the textbox
	if(flag==false)
	{
		day   = today.getDate(); //today's date
		month = today.getMonth();  //current month
		year  = y2k(today.getYear()); //current year
	} 
	else 
	{
		day = temp[2]/1; // The day in the boxname field
		month = temp[1]/1 - 1; // The month in the boxname field
		year = temp[0]; // The year in the boxname field 
	}

	currentMonth = month;
	currentYear = year;
	txtBoxName = boxname;

/*
	if(isIE)
		mywindow=open('about:blank','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=187,height=220');
	else if(isNav4)
		mywindow=open('about:blank','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=196,height=216');
	else if(isNav6)
		mywindow=open('about:blank','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=178,height=211');
	else
		mywindow=open('about:blank','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=196,height=200');
	
	mywindow.location.href = './jsp/cal.html';

	if (mywindow.opener == null) mywindow.opener = self;	
*/

	if(isIE)
		mywindow=open('./jsp/cal.jsp','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=187,height=220');
	else if(isNav4)
		mywindow=open('./jsp/cal.jsp','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=196,height=216');
	else if(isNav6)
		mywindow=open('./jsp/cal.jsp','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=178,height=211');
	else
		mywindow=open('./jsp/cal.jsp','Calendar','resizable=no,scrollbars=no,left=100,top=100,width=196,height=200');
	
	mywindow.focus();
}
