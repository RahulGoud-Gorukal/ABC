var childNabcoReportWindow=null;
var childNabcoShortSummaryWindow=null;

function submitForm() 
{   
	var mydate = document.all('departureDate');
	if (validateDate(mydate, 'yyyy/mm/dd', 'Departure Date', 'y')) {

		stampDutyForm.action="nabcoSummaryReportAction.do?subaction=displayNabcoSummaryReport&print=true";
		stampDutyForm.submit();
		return true;
	}
	return false;
}

function submitClickForm() 
{   
	var mydate = document.all('departureDate');
	if (validateDate(mydate, 'yyyy/mm/dd', 'Departure Date', 'y')) {

		stampDutyForm.action="nabcoSummaryReportAction.do?subaction=displayNabcoSummaryReport&print=true";		
		document.getElementById("nabcoProgress").innerHTML='Nabco report is in progress...';		
		stampDutyForm.submit();
	}
	
}

function openPrintPage() {
	if(childNabcoReportWindow==null)
	{
		childNabcoReportWindow= window.open("./nabcoSummaryReportAction.do?subaction=printNabcoSummaryReport");
	}
	else
	{
		childNabcoReportWindow.close();
		childNabcoReportWindow=null;
		childNabcoReportWindow= window.open("./nabcoSummaryReportAction.do?subaction=printNabcoSummaryReport");
		
	}
	
	if(childNabcoShortSummaryWindow==null)
	{
		childNabcoShortSummaryWindow= window.open("./nabcoSummaryReportAction.do?subaction=printNabcoNetSummaryReport");
	}
	else
	{
		childNabcoShortSummaryWindow.close();
		childNabcoShortSummaryWindow=null;
		childNabcoShortSummaryWindow= window.open("./nabcoSummaryReportAction.do?subaction=printNabcoNetSummaryReport");
	}
}


function validateDate(str1,dateformat,label,prompt)
{
	
	if(dateformat == "yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag = true;
		}
		
		if(!flag)
		{
			if(prompt == "y")
			{
				alert("E-1146: " + label + " is invalid. Expected date format is " + dateformat+".");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <= 0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <= 0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon == 1 || mon == 3 || mon == 5 || mon == 7 || mon == 8 || mon == 10 || mon == 12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag == true && mon != 2 && day1 == 31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon == 2)  //If February
	{
		if(( ( year1%4 == 0 ) && ( year1 % 100 != 0)) ||( year1 %400 == 0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}
