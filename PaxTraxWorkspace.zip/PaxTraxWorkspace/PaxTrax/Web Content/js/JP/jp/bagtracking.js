function typechanged()
{
	var carton2  = document.all("carton1");
	var cage2 = document.all("cage1");
	
	if(binLocationForm.wareHouse.checked)
	{
		var i=0;
		
		for(i =0; i<carton2.length;i++)
		{
			carton2[i].style.display = "";
			cage2[i].style.display = "none";
		}
		//binLocationForm.urgentBags.disabled = false;
		//binLocationForm.urgentBags.checked = false;
		binLocationForm.holdingLocation.checked = false;
		binLocationForm.holdingLocation.disabled = true;
	}

	if (binLocationForm.airPort.checked)	
	{
		var i=0;
		
		for(i =0; i<cage2.length;i++)
		{
			carton2[i].style.display = "none";
			cage2[i].style.display = "";
		}	
		binLocationForm.holdingLocation.disabled = false;
		//binLocationForm.holdingLocation.checked = false;
		//binLocationForm.urgentBags.checked = false;
		//binLocationForm.urgentBags.disabled = true;
	}
}

function binCapacityEnable()
{
	if (binLocationForm.holdingLocation.checked)
	{
		binLocationForm.capacity.value = "";
		binLocationForm.capacity.disabled = true;
	}
	else
	{
		binLocationForm.capacity.disabled = false;
	}
}

function binCheck()
{
	typechanged();	
	var wbin = /^[A-Z a-z]\d{2}[A-Z a-z]-\d$/;
	var abin = /^[A-Z a-z]{2}\d{2}$/;
	
		if (binLocationForm.wareHouse.checked)	
		{
				binLocationForm.pickupLocation.selectedIndex =0;
				binLocationForm.pickupLocation.disabled = true;
		}
		if (binLocationForm.airPort.checked)	
		{
			binLocationForm.pickupLocation.disabled = false;
		}
	
	/*if (!isBlank(binLocationForm.binLocation,"Bin Location","y"))
	{*/
	
		if (binLocationForm.wareHouse.checked)	
		{
				
				/*var vwbin = wbin.exec(binLocationForm.binLocation.value);
				if (!vwbin)
				{
				alert("E-4100: Bin location format should be A-23-L-3");
				binLocationForm.binLocation.select();
				binLocationForm.binLocation.focus();
				return false;
				}*/
			/*if(binLocationForm.capacity.value == "")
			{*/
				binLocationForm.capacity.value="2";	
			//}
		}

		if (binLocationForm.airPort.checked)	
		{
			
			/*var vabin = abin.exec(binLocationForm.binLocation.value);
			if (!vabin)
			{
			alert("E-4101: Bin location format should be A-L-93");
			binLocationForm.binLocation.select();
			binLocationForm.binLocation.focus();
			return false;
			}*/

			/*if(binLocationForm.capacity.value == "")
			{*/
		 		binLocationForm.capacity.value="1";
		 	//}
		}
		
		
		return true;
	//}
	
		
	return false;
}

function binCheck1()
{
	typechanged();	
var wbin = /^[A-Z a-z]\d{2}[A-Z a-z]-\d$/;
	var abin = /^[A-Z a-z]{2}\d{2}$/;
	if (binLocationForm.wareHouse.checked)	
	{
		binLocationForm.pickupLocation.selectedIndex =0;
		binLocationForm.pickupLocation.disabled = true;
	}
	else
	{
		binLocationForm.pickupLocation.disabled = false;
	}
	if (!isBlank(binLocationForm.binLocation,"\u30d3\u30f3\u306e\u5834\u6240","y"))
	{
		if (binLocationForm.wareHouse.checked)	
		{		
				
				var vwbin = wbin.exec(binLocationForm.binLocation.value);
				if (!vwbin)
				{
				alert("E-4100: \u30d3\u30f3\u306e\u5834\u6240\u306e\u30d5\u30a9\u30fc\u30de\u30c3\u30c8\u306fA23L3\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				binLocationForm.binLocation.select();
				binLocationForm.binLocation.focus();
				return false;
				}
				
		}

		if (binLocationForm.airPort.checked)	
		{	
			var vabin = abin.exec(binLocationForm.binLocation.value);
			if (!vabin)
			{
				alert("E-4101: \u30d3\u30f3\u306e\u5834\u6240\u306e\u30d5\u30a9\u30fc\u30de\u30c3\u30c8\u306fAL93\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				binLocationForm.binLocation.select();
				binLocationForm.binLocation.focus();
				return false;
			}
			
		}
		
		
		return true;
	}
	
	return false;
}

var remarks = /^[\w\s]*$/;
var capacity = /^\d*$/;
function saveBinLocation()
{
	if (binLocationForm.page.value == "createBinLocation")
	{
	if (!binCheck1())
		return;
	}
		
	if (!(binLocationForm.wareHouse.checked || binLocationForm.airPort.checked))	
	{
		alert("E-4102: \u9069\u5f53\u306a\u7a2e\u985e\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		return;
	}

	
	if (binLocationForm.pickupLocation.selectedIndex == 0 && binLocationForm.airPort.checked)
	{
		alert("E-4103: \u9069\u5f53\u306a\u30d4\u30c3\u30af\u30a2\u30c3\u30d7\u3059\u308b\u5834\u6240\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		binLocationForm.pickupLocation.focus();
		return;
	}
	
	if (!binLocationForm.capacity.disabled)
	{
		if (isBlank(binLocationForm.capacity,"\u5bb9\u91cf","y"))
			return;	
			
		var vcapacity = capacity.exec(binLocationForm.capacity.value);
		if (!vcapacity)
		{
			alert("E-4104: \u5bb9\u91cf\u306b\u306f\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			binLocationForm.capacity.select();
			binLocationForm.capacity.focus();
			return;
		}
		
		if (binLocationForm.capacity.value == 0)
		{
			alert("E-4105: \u5bb9\u91cf\u306f\u30bc\u30ed\u306b\u306a\u3063\u3066\u306f\u306a\u308a\u307e\u305b\u3093\u3002");
			binLocationForm.capacity.select();
			binLocationForm.capacity.focus();
			return;
		}
	}
	
	var vremarks = remarks.exec(binLocationForm.remarks.value);
	if (!vremarks)
	{
		alert("E-4106: \u5099\u8003\u6b04\u306b\u306f\u7279\u5225\u6587\u5b57\u304c\u4f7f\u3048\u307e\u305b\u3093\u3002");
		binLocationForm.remarks.select();
		binLocationForm.remarks.focus();
		return;
	}
	if (binLocationForm.page.value == "createBinLocation")
	{
		
		binLocationForm.action="binLocationAction.do?subaction=saveBinLocationDetails";
	}
	else
	{
		binLocationForm.action="binLocationAction.do?subaction=updateBinLocationDetails";
	}
	binLocationForm.submit();
}

function isBlank(str1,label,prompt)
{
	if(str1.value == "")
	{
		if(prompt == "y" || prompt == "Y")
		{
			alert("E-4107: " + label + "\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			str1.focus();
		}

		return(true);		
	}

	return(false);
}

function ltrim(s) {
	return s.replace(/^\s*/, "");
}

function rtrim(s) {
	return s.replace(/\s*$/, "");
}

/**
funtion using for removing the empty spaces from both sides of  the String
*/
function trim(value) {
	return rtrim(ltrim(value));
}

function clearBinLocationPage()
{
	binLocationForm.action = "binLocationAction.do?subaction=createBinLocationPage";
	binLocationForm.submit();
}

function getBinLocation()
{
	if (window.event.keyCode == 9)
	{
		binLocationForm.binLocation.value=trim(binLocationForm.binLocation.value);
		if (!isBlank(binLocationForm.binLocation,"","n"))
		{
			var bin = /^[\w-]+$/;
			var vbin = bin.exec(binLocationForm.binLocation.value);
			if (!vbin)
			{
				alert("E-4108: \u30d3\u30f3\u306e\u5834\u6240\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3001\u6570\u5b57\u3001-\u4ee5\u5916\u306e\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
				binLocationForm.binLocationCheck.value = "y";
				return (false);
			}
		
			binLocationForm.action = "binLocationAction.do?subaction=getBinLocation";
			binLocationForm.submit();		
		}
	}
}

function binBlur()
{
	if (binLocationForm.binLocationCheck.value == "y")
	{
		binLocationForm.binLocation.select();
		binLocationForm.binLocation.focus();
		binLocationForm.binLocationCheck.value = "";
	}
}

function binCreationConfirm()
{
	binLocationForm.action = "binLocationAction.do?subaction=createBinLocationPage";
	binLocationForm.submit();
}

function binPageEnable()
{
	binLocationForm.binLocation.disabled = true;
	
	binLocationForm.capacity.disabled = false;
	binLocationForm.remarks.disabled = false;
	document.all("save").style.display = "";
	document.all("delete").style.display = "";
	typechanged();
	binCapacityEnable();
	if (binLocationForm.wareHouse.checked)	
	{
		binLocationForm.pickupLocation.selectedIndex =0;
		binLocationForm.pickupLocation.disabled = true;
		if(binLocationForm.holdingLocation.checked)
		{
			binLocationForm.remarks.focus();
		}
		else
		{
			binLocationForm.capacity.focus();
		}
	}
	else
	{
		binLocationForm.pickupLocation.disabled = false;
		binLocationForm.pickupLocation.focus();
	}
}

function deletePrompt()
{
	if(window.confirm("\u524a\u9664\u3057\u307e\u3059\u304b\u3002"))
	{
		binLocationForm.action="binLocationAction.do?subaction=removeBinLocationDetails";
		binLocationForm.submit();
	}
}

function binLocationCancel()
{
	if ((binLocationForm.fromPage.value == "null") || (binLocationForm.fromPage.value == "maintainBin"))
		binLocationForm.action="home.do?subaction=bagtrackingHomePage";
	if (binLocationForm.fromPage.value == "searchBin")
	{
		var frompageno = binLocationForm.fromPageNumber.value;
		binLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails&pageNumber="+frompageno;
	}
	binLocationForm.submit();
}

function iconSearch()
{
	 binLocationForm.action="searchBinLocationAction.do?subaction=goToBinLocationSearchPage";
	 binLocationForm.submit();
}

function searchTypeChanged()
{
	var carton2  = document.all("carton1");
	var cage2 = document.all("cage1");
	
	if(searchBinLocationForm.wareHouse.checked)
	{
		carton2.style.display = "";
		cage2.style.display = "none";
		searchBinLocationForm.pickupLocation.selectedIndex =0;
		searchBinLocationForm.pickupLocation.disabled = true;
	}

	if (searchBinLocationForm.airPort.checked)	
	{
		carton2.style.display = "none";
		cage2.style.display = "";
		searchBinLocationForm.pickupLocation.disabled = false;
	}
}

function searchBinLocationSubmit()
{
	var vcapacity = capacity.exec(searchBinLocationForm.capacity.value);
	if (!vcapacity)
	{
		alert("E-4109: \u5bb9\u91cf\u306b\u306f\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		searchBinLocationForm.capacity.select();
		searchBinLocationForm.capacity.focus();
		return;
	}
	var vremarks = remarks.exec(searchBinLocationForm.remarks.value);
	if (!vremarks)
	{
		alert("E-4110: \u5099\u8003\u6b04\u306b\u306f\u7279\u5225\u6587\u5b57\u304c\u4f7f\u3048\u307e\u305b\u3093\u3002");
		searchBinLocationForm.remarks.select();
		searchBinLocationForm.remarks.focus();
		return;
	}
	searchBinLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails";
	searchBinLocationForm.submit();
}

function binMaintainConfirm()
{
	if (binLocationForm.fromPage.value == "null")
		binLocationForm.action="home.do?subaction=bagtrackingHomePage";
	if (binLocationForm.fromPage.value == "maintainBin")
		binLocationForm.action="binLocationAction.do?subaction=maintainBinLocationPage";
	if (binLocationForm.fromPage.value == "searchBin")
	{
		var frompageno = binLocationForm.fromPageNumber.value;
		if (frompageno == "null")
		{
		binLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails";
		}
		else
		{
		binLocationForm.action="searchBinLocationAction.do?subaction=searchBinLocationDetails&pageNumber="+frompageno;
		}
	}
	binLocationForm.submit();
}

function createTruckSubmit()
{
	if (truckForm.page.value == "createTruck")
	{
	if (isBlank(truckForm.number,"\u30c8\u30e9\u30c3\u30af\u756a\u53f7","y"))
		return;
	}
		
	var truck = /^[\w]*$/;
	var vtruck = truck.exec(truckForm.number.value);
	if (!vtruck)
	{
		alert("E-4111: \u30c8\u30e9\u30c3\u30af\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u304c\u4f7f\u3048\u307e\u305b\u3093\u3002");
		truckForm.number.select();
		truckForm.number.focus();
		return;
	}
	if(truckForm.number.value == 0)
	{
		alert("E-4111:\u30c8\u30e9\u30c3\u30af\u756a\u53f7\u306b\u306f\u3044\u3051\u306a\u3044\u3002.");
		truckForm.number.select();
		truckForm.number.focus();
		return;
	}		
	if (special(truckForm.model,"\u578b"))
		return;

	if (special(truckForm.manufacturer,"\u751f\u7523\u8005"))
		return;
		
	var year = /^\d*$/;
	var vyear = year.exec(truckForm.year.value);
	if (!vyear)
	{
		alert("E-4112: \u5e74\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		truckForm.year.select();
		truckForm.year.focus();
		return;
	}
	
	if (special(truckForm.make,"\u88fd"))
		return;

	if (special(truckForm.remarks,"\u5099\u8003"))
		return;

	if (truckForm.page.value == "createTruck")
	{
	truckForm.action = "truckAction.do?subaction=saveTruckDetails";
	truckForm.submit();	
	}
	else
	{
	truckForm.action = "truckAction.do?subaction=updateTruckDetails";
	truckForm.submit();	
	}
}

function special(str,label)
{
	var remarks = /^[\w\s]*$/;
	var vtruck = remarks.exec(str.value);
	if (!vtruck)
	{
		alert("E-4113: "+label+"\u306b\u306f\u7279\u5225\u6587\u5b57\u304c\u4f7f\u3048\u307e\u305b\u3093\u3002");
		str.select();
		str.focus();
		return true;
	}
	return false;
}

function getTruck()
{
	if (window.event.keyCode == 9)
	{
		truckForm.number.value=trim(truckForm.number.value);
		if (!isBlank(truckForm.number,"","n"))
		{
			var truck = /^[\w]*$/;
			var vtruck = truck.exec(truckForm.number.value);
			if (!vtruck)
			{
				alert("E-4114: \u30c8\u30e9\u30c3\u30af\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u304c\u4f7f\u3048\u307e\u305b\u3093\u3002");
				truckForm.number.select();
				truckForm.number.focus();
				truckForm.truckCheck.value = "y";
				return;
			}
					
			truckForm.action = "truckAction.do?subaction=selectTruck";
			truckForm.submit();		
		}
	}
}

function truckBlur()
{
	if (truckForm.truckCheck.value == "y")
	{
		truckForm.number.select();
		truckForm.number.focus();
		truckForm.truckCheck.value = "";
	}
}

function iconSearchTruck()
{
	 truckForm.action="searchTruckAction.do?subaction=goToTruckSearchPage";
	 truckForm.submit();
}

function clearTruckPage()
{
	truckForm.action="truckAction.do?subaction=createTruckPage";
	truckForm.submit();
}

function truckCreationConfirm()
{
	truckForm.action = "truckAction.do?subaction=createTruckPage";
	truckForm.submit();
}

function truckPageEnable()
{
	truckForm.number.disabled = true;
	truckForm.model.disabled = false;
	truckForm.manufacturer.disabled = false;
	truckForm.year.disabled = false;
	truckForm.make.disabled = false;
	truckForm.remarks.disabled = false;
	document.all("save").style.display = "";
	document.all("delete").style.display = "";
	truckForm.model.focus();
}

function truckDelete()
{
	if(window.confirm("\u524a\u9664\u3057\u307e\u3059\u304b\u3002"))
	{
		truckForm.action = "truckAction.do?subaction=removeTruckDetails";
		truckForm.submit();
	}
}

function truckCancel()
{
	if ((truckForm.fromPage.value == "null") || (truckForm.fromPage.value == "maintainTruck"))
		truckForm.action="home.do?subaction=bagtrackingHomePage";
	if (truckForm.fromPage.value == "searchTruck")
	{
		var frompageno = truckForm.fromPageNumber.value;
		truckForm.action="searchTruckAction.do?subaction=searchTruckDetails&pageNumber="+frompageno;
	}
	truckForm.submit();
	
}

function truckMaintainConfirm()
{
	if (truckForm.fromPage.value == "null")
		truckForm.action="home.do?subaction=bagtrackingHomePage";
	if (truckForm.fromPage.value == "maintainTruck")
		truckForm.action="truckAction.do?subaction=maintainTruckPage";
	if (truckForm.fromPage.value == "searchTruck")
	{
		var frompageno = truckForm.fromPageNumber.value;
		if (frompageno == "null")
		{
		truckForm.action="searchTruckAction.do?subaction=searchTruckDetails";
		}
		else
		{
		truckForm.action="searchTruckAction.do?subaction=searchTruckDetails&pageNumber="+frompageno;
		}
	}
	truckForm.submit();
}

function searchTruckSubmit()
{
	if (special(searchTruckForm.manufacturer,"\u751f\u7523\u8005"))
		return;

	if (special(searchTruckForm.make,"\u88fd"))
		return;

	if (special(searchTruckForm.model,"\u578b"))
		return;

	var year = /^\d*$/;
	var vyear = year.exec(searchTruckForm.year.value);
	if (!vyear)
	{
		alert("E-4115: \u5e74\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		searchTruckForm.year.select();
		searchTruckForm.year.focus();
		return;
	}
	
	searchTruckForm.action = "searchTruckAction.do?subaction=searchTruckDetails";
	searchTruckForm.submit();
}


/*************************Cage Functions*******************************************/

var cageNumber=/^[\d]*$/;
var noOfCartons=/^[\d]+$/;
var cageDescription = /^[\w\s]*$/;
var specialCharacterMessage ="\u306b\u306f\u7279\u5225\u6587\u5b57\u304c\u4f7f\u3048\u307e\u305b\u3093\u3002";
var numericMessage=" \u306b\u306f\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002";


function changeLanguage(form,newLanguage,page,error)
{
	
	if(page=="search")
	{
		form.action="searchCageAction.do?country=JP&language="+newLanguage+"&errorCode="+error+"&pageNumber="+page;
	}
	else if(page=="paxRefund" || page == "paxFlightChange")
	{	
		//enableActionCheckBox(form); // This method exits in the PaxRefund Jsp
		form.action="paxRefund.do?country=JP&language="+newLanguage+"&errorCode="+error+"&page="+page;
		
	}
	else if(page=="paxDFpurchase")
	{	
		//enableActionCheckBox(form); // This method exits in the PaxRefund Jsp
		form.action="paxPurchaseEnquiry.do?country=JP&language="+newLanguage+"&errorCode="+error+"&page="+page;
		
	}
	else
	{
		form.action="cageAction.do?country=JP&language="+newLanguage+"&errorCode="+error+"&page="+page;
	}
		
	form.subaction.value="changeLanguage";
	form.submit();
}
function ltrim(s)
{
	return s.replace( /^\s*/, "" )
}

function rtrim(s)
{
	return s.replace( /\s*$/, "" );
}


function trim(s)
{
	return rtrim(ltrim(s));
}


function isNotEmpty(str1,label,prompt)
{
	var returnValue = true;
	var checkString = trim(str1.value);
	
	if(checkString == "")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-4116: " + label + "\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			str1.select();
			str1.focus();
			returnValue = false;
		}

				
	}
	
	return(returnValue);
}


function validateCreateCageForm(cageForm)
{
	
	if(validateField(cageForm.cageNumber,'\u30b1\u30fc\u30b8\u756a\u53f7','Y',cageNumber,  "E-4127:  \u30b1\u30fc\u30b8\u756a\u53f7"+numericMessage )
	&& validateCageLength(cageForm,cageForm.cageNumber.value.length)
	&& validateField(cageForm.cartonsPerCage,'\u4e00\u500b\u306e\u30b1\u30fc\u30b8\u3042\u305f\u308a\u7bb1\u306e\u6700\u5927\u6570','Y', noOfCartons,"E-4128: \u4e00\u500b\u306e\u30b1\u30fc\u30b8\u3042\u305f\u308a\u7bb1\u306e\u6700\u5927\u6570"+numericMessage)
	&& validateMaximumCartons(cageForm)
	&& validateField(cageForm.remarks,'\u5099\u8003','N', cageDescription , "E-4129: "+specialCharacterMessage +"\u5099\u8003")
	&& validateField(cageForm.description,'\u8a73\u7d30','N', cageDescription , "E-4130: "+specialCharacterMessage +"\u8a73\u7d30"))
	{
		cageForm.action="cageAction.do?subaction=saveCageDetails";
		
		cageForm.submit();
	}
	
}

function validateMaximumCartons(form)
{
	if(trim(form.cartonsPerCage.value)==0)
	{
		alert("E-4131: \u4e00\u500b\u306e\u30b1\u30fc\u30b8\u3042\u305f\u308a\u7bb1\u306e\u6700\u5927\u6570 \u3044\u3051\u306a\u3044\u3002");
		form.cartonsPerCage.select();
		form.cartonsPerCage.focus();
		return false;
	}
	else
	return true;
}

function validateField(object, label, prompt, regularExpr, msg)
{
	
	var returnValue = true;
	returnValue=isNotEmpty(object,label,prompt);
	if(returnValue)
	{	
		
		var validated=regularExpr.exec(object.value);
		
		if(!validated)
		{
			alert(msg);
			object.select();
			object.focus();
			returnValue = false;
		}
	}
	return(returnValue)	;
}


function trimObject(obj)
{
	obj.value=trim(obj.value);
	return true;
}

function clearFields(form)
{
/*	form.cageNumber.value="";
	form.cartonsPerCage.value="";
	form.description.value="";
	form.remarks.value="";
	form.cageNumber.focus();*/
		form.action="cageAction.do?subaction=createCagePage";
	form.submit();
}

function createOkAction(form,forwardValue)
{
	if(forwardValue == "maintainCage")
	{
		var pageTransferValue = form.pageTransfer.value; 
		
		if(pageTransferValue == "updateSearch")
		{
			form.action="searchCageAction.do?subaction=searchCageDetails";
	
		}
		else
		{
		
			form.action="cageAction.do";
			form.subaction.value="maintainCagePage";
		}
	}
	else if(forwardValue == "createCage")
	{
		form.action="cageAction.do";
		form.subaction.value="createCagePage";
	}
		
	form.submit();
}

function searchCage(form)
{
	form.action="searchCage.do";
	form.subaction.value="createSearchPage";

	form.submit();
	
}

function onTabLoad(form)
{
	
	var keycode =window.event.keyCode;
	
	if(keycode == 9 && trim(form.cageNumber.value) != "")
	{
		
		var cageNumberValidated = cageNumber.exec(form.cageNumber.value);
		
		if(!cageNumberValidated)
		{
			alert( "E-4117: \u30b1\u30fc\u30b8\u756a\u53f7"+numericMessage);
			form.cageNumber.select();
			form.cageNumber.focus();
			return;
		}
		else if (! validateCageLength(form,form.cageNumber.value.length))
		{
		return false;
		}
		else
		{
			form.action="cageAction.do";
			form.subaction.value="loadCageDetails";
			form.submit();
		}	
	}
}

function enableFields(form)
{
	form.cageNumber.disabled =  true;
	form.cartonsPerCage.disabled = false;
	form.remarks.disabled = false;
	form.description.disabled = false;
}

function disableFields(form)
{

	form.cageNumber.disabled =  false;
	form.cartonsPerCage.disabled = true;
	form.remarks.disabled = true;
	form.description.disabled = true;
}


function validateMaintainCageForm(cageForm)
{

if(validateField(cageForm.cageNumber,'u30b1\u30fc\u30b8\u756a\u53f7','Y',cageNumber, "E-4132: \u30b1\u30fc\u30b8\u756a\u53f7"+numericMessage )
	&& validateCageLength(cageForm,cageForm.cageNumber.value.length)
	&& validateField(cageForm.cartonsPerCage,'\u4e00\u500b\u306e\u30b1\u30fc\u30b8\u3042\u305f\u308a\u7bb1\u306e\u6700\u5927\u6570','Y', noOfCartons,"E-4133:  \u4e00\u500b\u306e\u30b1\u30fc\u30b8\u3042\u305f\u308a\u7bb1\u306e\u6700\u5927\u6570"+numericMessage)
	&& validateMaximumCartons(cageForm)
	&& validateField(cageForm.remarks,'\u5099\u8003','N', cageDescription , "E-4134: "+specialCharacterMessage +"\u5099\u8003")
	&& validateField(cageForm.description,'\u8a73\u7d30','N', cageDescription , "E-4135: "+specialCharacterMessage +"\u8a73\u7d30"))
	{
		cageForm.action="cageAction.do?subaction=updateCageDetails";
		
		cageForm.submit();
	}
}

function validateCageLength(form,len)
{
	if(form.cageNumber.value == 0)
	{
		alert("E-4132: \u30b1\u30fc\u30b8\u756a\u53f7\u306b\u3044\u3051\u306a\u3044\u3002");
		form.cageNumber.select();
		form.cageNumber.focus();
		return false;
	}
	if(len< 3)
	{
		alert("E-4118: \u30b1\u30fc\u30b8\u756a\u53f7\u306b\u306f\uff13\u5b57\u304c\u5fc5\u8981\u3067\u3059\u3002");
		form.cageNumber.select();
		form.cageNumber.focus();
		return false;
	}
	
	return true;
}

function cancelMaintainAction(cageForm)
{
	var pageTransferValue = cageForm.operation.value; 
		
	if(pageTransferValue == "updateSearch")
	{
		cageForm.action="searchCageAction.do?subaction=searchCageDetails";
	}
	/*else if(pageTransferValue == "updateReload")
	{
		cageForm.action="cageAction.do?subaction=maintainCagePage";	
	}*/
	else
	{
		cageForm.action="cageAction.do?subaction=cancel";
	}
	cageForm.submit();
}

function deleteMaintainPrompt(form)
{

	if(confirm("\u524a\u9664\u3057\u307e\u3059\u304b\u3002"))
	{
		form.action="cageAction.do";
		form.subaction.value="removeCageDetails";
		form.submit();
	}
	else
	{
		return;
	}
}

function displayEditCage(cage,form)
{

	form.subaction.value="loadCageDetails";
	form.action="cageAction.do?index="+cage;
	form.submit();
}

function validateSearchCageForm(searchForm)
{
	if(validateField(searchForm.cageNumber,'Cage number','N',cageNumber, "\u30b1\u30fc\u30b8\u756a\u53f7"+numericMessage ))
	{
		searchForm.action="searchCageAction.do?subaction=searchCageDetails";
		searchForm.submit();
	}
}


/*************************Cage Functions*******************************************/

function generateTruckTrackingEnquiry()
{
	
	var truckNumber = document.all('truckNumber').value;
	
	if (truckNumber != "" &&  truckNumber !="-1")
	{
		
		
		document.truckTrackingEnquiryForm.action = "truckTrackingEnquiry.do";
		document.truckTrackingEnquiryForm.subaction.value = "getTruckTrackingEnquiry";
		document.truckTrackingEnquiryForm.submit();
	}
	else
	{
		alert("E-4119: \u30c8\u30e9\u30c3\u30af\u756a\u53f7\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093\u3002");
		document.truckTrackingEnquiryForm.truckNumber.focus();
	}
}

function printTruckTrackingEnquiry()
{
	document.truckTrackingEnquiryForm.action = "truckTrackingEnquiry.do";
	document.truckTrackingEnquiryForm.subaction.value = "printTruckTrackingEnquiry";
	document.truckTrackingEnquiryForm.submit();
}
function getPaxPurchaseInquirySubmit()
{
	var paxNo = document.paxPurchaseInquiryForm.paxNumber.value;
	var keycode = window.event.keyCode;
	var paxPattern = /^[\d]{10}$/;
	if(paxNo == "" && keycode == "13")
	{
		alert("E-4120: Pax # \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		document.paxPurchaseInquiryForm.paxNumber.select();
		document.paxPurchaseInquiryForm.paxNumber.focus();		
		return false;
	}
	else if(paxNo != "" && keycode == "13")
	{
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX\uff03\u306f\uff19\u6841\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				document.paxPurchaseInquiryForm.paxNumber.select();
				document.paxPurchaseInquiryForm.paxNumber.focus();			
				return false;
			}		
			else
			{
				document.paxPurchaseInquiryForm.action = "paxPurchaseEnquiry.do";
				document.paxPurchaseInquiryForm.subaction.value = "getPaxPurchaseInquiry";
				document.paxPurchaseInquiryForm.submit();
			}
	}
	
}


function paxDFPurchaseListSubmit(form)
{
	var paxNo = form.paxNumber.value;
	var paxPattern = /^[\d]{10}$/;
	if(!isBlank(form.paxNumber,"PAX #","y"))
	{	
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX\uff03\u306f\uff19\u6841\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do?subaction=getPaxDFPurchaseList";
				form.submit();
			}
	}	
}
function getPaxPurchaseInquiry()
{
	var paxNo = document.paxPurchaseInquiryForm.paxNumber.value;
	var paxPattern = /^[\d]{10}$/;
	if(!isBlank(document.paxPurchaseInquiryForm.paxNumber,"PAX #","y"))
	{		
		if(!paxPattern.exec(paxNo))
		{
			alert("E-4122: PAX\uff03\u306f\uff19\u6841\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.paxPurchaseInquiryForm.paxNumber.select();
			document.paxPurchaseInquiryForm.paxNumber.focus();			
			return false;
		}		
		else
		{
			document.paxPurchaseInquiryForm.action = "paxPurchaseEnquiry.do";
			document.paxPurchaseInquiryForm.subaction.value = "getPaxPurchaseInquiry";
			document.paxPurchaseInquiryForm.submit();
		}
	}	
}


function getPaxDFPurchaseList(form)
{
	var paxNo = form.paxNumber.value;
	var keycode = window.event.keyCode;
	var paxPattern = /^[\d]{10}$/;
	
	if(paxNo == "" && keycode == "13")
	{
		alert("E-4120: Pax # \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		form.paxNumber.select();
		form.paxNumber.focus();		
		return false;
	}
	else if(paxNo != "" && keycode == "13")
	{
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX\uff03\u306f\uff19\u6841\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return false;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do";
				form.subaction.value = "getPaxDFPurchaseList";
				form.submit();
			}
	}
	
}
function paxDPPurchaseListSubmit(form)
{
	var paxNo = form.paxNumber.value;
	var paxPattern = /^[\d]{10}$/;
	if(!isBlank(form.paxNumber,"PAX #","y"))
	{	
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4122: PAX\uff03\u306f\uff19\u6841\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do?subaction=getPaxDPPurchaseList";
				form.submit();
			}
	}	
}
function getPaxDPPurchaseList(form)
{
	var paxNo = form.paxNumber.value;
	var keycode = window.event.keyCode;
	var paxPattern = /^[\d]{10}$/;
	
	if(paxNo == "" && keycode == "13")
	{
		alert("E-4120: Pax # \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		form.paxNumber.select();
		form.paxNumber.focus();		
		return false;
	}
	else if(paxNo != "" && keycode == "13")
	{
			if(!paxPattern.exec(paxNo))
			{
				alert("E-4121: PAX\uff03\u306f\uff19\u6841\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				form.paxNumber.select();
				form.paxNumber.focus();			
				return false;
			}		
			else
			{
				form.action = "paxPurchaseEnquiry.do";
				form.subaction.value = "getPaxDPPurchaseList";
				form.submit();
			}
	}
	
}
function parallelingReportSubmit(form)
{
	if(validateDate(form.fromDate,"yyyy/mm/dd","Departure Date","y"))
	{
		form.action = "paxPurchaseEnquiry.do?subaction=getPaxDetails";
		form.submit();
	}		
		
}
function printPaxPurchaseInquiry()
{
	document.paxPurchaseInquiryForm.action = "paxPurchaseEnquiry.do";
	document.paxPurchaseInquiryForm.subaction.value = "printPaxPurchaseEnquiry";
	document.paxPurchaseInquiryForm.submit();
}

function formatDateOnBlur(date1)
{
	if(date1.value!="")
	{
		if(validateDate(date1,"yyyy/mm/dd","Departure Date","y"))
			date1.value = strconvert(date1);			
	}
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-4123: " + label + "\u306f\u7121\u52b9\u3067\u3059\u3002"+ dateformat+"\u306e\u5f62\u5f0f\u3067\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}

function validateGeneratePicklistPage(print1)
{
	if(document.generatePicklistForm.pickupLocation.value=="-1")
	{
		alert("E-4124: \u9069\u5f53\u306a\u30d4\u30c3\u30af\u30a2\u30c3\u30d7\u3059\u308b\u5834\u6240\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		document.generatePicklistForm.pickupLocation.focus();
		return(false);
	}
	
	if(document.generatePicklistForm.departureDate.value=="")
	{
		alert("E-4125: \u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		document.generatePicklistForm.departureDate.select();
		document.generatePicklistForm.departureDate.focus();
		return(false);
	}
	
	if(!validateDate(document.generatePicklistForm.departureDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))
		return(false);
	
	if(document.generatePicklistForm.shift.value=="-1")
	{
		alert("E-4126: \u9069\u5f53\u306a\u30b7\u30d5\u30c8\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		document.generatePicklistForm.shift.focus();
		return(false);
	}
	
	if(print1=="print")
		document.generatePicklistForm.action="generatePicklistAction.do?subaction=getPickList&print=yes";
	else
		document.generatePicklistForm.action="generatePicklistAction.do?subaction=getPickList";
	
	document.generatePicklistForm.submit();
}

function strconvert(str1)
{
	var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}


function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}

function flightChangeSearch(form)
{

	if(!(validateDate(form.fromDate,"yyyy/mm/dd","From Date","y")))
	{		
		return(false);
	}
	if(!(validateDate(form.toDate,"yyyy/mm/dd","To Date","y")))
	{		
		return(false);	
	}
	if(form.fromDate.value > form.toDate.value)
	{
		alert("E-4127: To date should be greater than or equal to From date.");
		form.fromDate.focus();
		return false;
	}
	form.action= "paxRefund.do";
	form.subaction.value="searchFlightChangeItems";
	form.submit();
	
}



function paxRefundSearch(form)
{

	if(!(validateDate(form.fromDate,"yyyy/mm/dd","From Date","y")))
	{		
		return(false);
	}
	if(!(validateDate(form.toDate,"yyyy/mm/dd","To Date","y")))
	{		
		return(false);	
	}
	if(form.fromDate.value > form.toDate.value)
	{
		alert("E-4127: To\u306e\u65e5\u4ed8\u306fFrom\u306e\u65e5\u4ed8\u3068\u540c\u3058\u307e\u305f\u306f\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		form.fromDate.focus();
		return false;
	}
	form.action= "paxRefund.do";
	form.subaction.value="searchRefundItems";
	form.submit();
}


function paxRefundPrint(form)
{
	
}


function paxRefundSave(form)
{
	
}


function binLocationEnquiry(form)
{
	/*var arr1 = form.binLocFrom.value;
	var arr2 =	form.binLocTo.value;
	var i =arr1.split("~");
	var j =arr2.split("~");*/
	var i = form.binLocFrom.value;
	var j =	form.binLocTo.value;
	var len = form.binLocFrom.length;
	if(parseInt(len) < 2)
	{
		alert("E-4140:  \u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002.");
		form.binLocFrom.focus();
		return false;
	}
	/*if(j==-1)
	{
		alert("E-4140: Select a valid to binLocation.");
		form.binLocTo.focus();
		return false;
	}*/
	if(parseInt(i) > parseInt(j) && parseInt(i) != -1 && parseInt(j) !=-1)
	{
		alert("E-4140: \u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002.");
		form.binLocFrom.focus();
		return false;
	}
	form.action = "binLocReport.do?subaction=getBinLocReport";
	form.submit();
}


function submitPage()
	{
		if(document.forms[0].bagNumber.value!="")
		{
			if(validatebagNumber())
			{
				document.forms[0].method="POST";
				document.forms[0].action="bagTrackingEnquiryAction.do?subaction=getBagTrackingInquiry";
				document.forms[0].submit();
			}
		}
		else
		{
			alert("E-5205: \u888b\u6570\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
			document.forms[0].bagNumber.focus();
		}
	}
	
	function validatebagNumber()
	{
		var bag =/^\d{12,12}$/;
		var vbag = bag.exec(document.form1.bagNumber.value);
		
		if(!vbag)
		{
			alert("E-5205: \u888b\u6570\u306f\u6570\u5b57 12 \u30c7\u30a3\u30b8\u30c3\u30c8\u306e\u3079\u304d\u3067\u3042\u308b");
			document.forms[0].bagNumber.select();
			document.forms[0].bagNumber.focus();
			
			return(false);
		}		
		
		return(true);
	}
	
	
function approvePax(form)
{
	form.action = "paxPurchaseEnquiry.do";
	form.subaction.value = "approvePax";
	form.submit();
}
	
function rejectPax(form)
{
	
	form.action = "paxPurchaseEnquiry.do";
	form.subaction.value = "rejectPax";
	form.submit();
}	
	