
var tacode=/^[A-Z 0-9 a-z]+$/;
var nam=/^[A-Z a-z]+$/;
var phone=/^[\+\-()\d]+$/;
var agencyname=/^[A-Z 0-9 a-z]+$/;
var postcode = /^[0-9]+$/;
var country = /^[A-Z a-z]+$/;

function maintenance_EnableAll()
{
	travelAgentForm.contactPerson.disabled=false;
	travelAgentForm.agencyName.disabled=false;
	travelAgentForm.agencyOwner.disabled=false;
	travelAgentForm.postCodePrefix.disabled=false;
	travelAgentForm.postCodeSuffix.disabled=false;
	travelAgentForm.addressLine1.disabled=false;
	travelAgentForm.addressLine2.disabled=false;
	travelAgentForm.city.disabled=false;
	travelAgentForm.country.disabled=false;
	travelAgentForm.phone.disabled=false;
	travelAgentForm.email.disabled=false;
	travelAgentForm.fax.disabled=false;
}


function tadetail()
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		if(travelAgentForm.travelAgentCode.value=="")
			return(false);
		
		if(travelAgentForm.travelAgentCode.value=="00000")
		{
			alert("E-2200: \u6709\u52b9\u306aTA\u30b3\u30fc\u30c9\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			travelAgentForm.travelAgentCode.select();
			travelAgentForm.travelAgentCode.focus();
			return(false);	
		}
		
		var vtacode = tacode.exec(travelAgentForm.travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2201: TA\u30b3\u30fc\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u3092\u542b\u3081\u3066\u306f\u3044\u3051\u307e\u305b\u3093\u3002.");
			travelAgentForm.travelAgentCode.select();
			travelAgentForm.travelAgentCode.focus();
			return(false);
		}
		
		travelAgentForm.action="travelAgent.do?subaction=validateTA";
		travelAgentForm.submit();
	}
}

function validatePostCode(fromValidation)
{
	if(!isBlank(travelAgentForm.postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(travelAgentForm.postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2202: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			if(fromValidation!="lookup")
			{
				travelAgentForm.postCodePrefix.select();
				travelAgentForm.postCodePrefix.focus();
			}
			else
				travelAgentForm.postcodeError.value="prefix";
					
			return(false);
		}
	}
	
	if(!isBlank(travelAgentForm.postCodeSuffix," ","n"))
	{	
		vpostcode = postcode.exec(travelAgentForm.postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2203: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			if(fromValidation!="lookup")
			{
				travelAgentForm.postCodeSuffix.select();
				travelAgentForm.postCodeSuffix.focus();
			}
			else
				travelAgentForm.postcodeError.value="suffix";
								
			return(false);
		}
	}
	
	return(true);
}

function postCodeLookup()
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		if(!isBlank(travelAgentForm.postCodePrefix," ","n") || !isBlank(travelAgentForm.postCodeSuffix," ","n"))
		{
			if(!validatePostCode("lookup"))
				return(false);
				
			if( (travelAgentForm.postCodePrefix.value!=travelAgentForm.prevPostCodePrefix.value) || (travelAgentForm.postCodeSuffix.value!=travelAgentForm.prevPostCodeSuffix.value) )
			{
				travelAgentForm.action="travelAgent.do?subaction=postCodeLookup";
				travelAgentForm.submit();
			}
		}
	}
}


function isBlank(str1,label,prompt)
{
	if(str1.value=="")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-2204: " + label + "\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			str1.select();
			str1.focus();
		}

		return(true);		
	}

	return(false);
}

function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-2205: " + label + "\u306b\u306f" + len + "\u5b57\u306e"+type+"\u6587\u5b57\u5217\u304c\u5fc5\u8981\u3067\u3059\u3002");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}

function emailCheck (emailStr)
{
	/* The following pattern is used to check if the entered e-mail address
	   fits the user@domain format.  It also is used to separate the username
	   from the domain. */
	var emailPat=/^(.+)@(.+)$/

	/* The following string represents the pattern for matching all special
	   characters.  We don't want to allow special characters in the address.
	   These characters include ( ) < > @ , ; : \ " . [ ]    */
	var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]"

	/* The following string represents the range of characters allowed in a
	   username or domainname.  It really states which chars aren't allowed. */
	var validChars="\[^\\s" + specialChars + "\]"

	/* The following pattern applies if the "user" is a quoted string (in
	   which case, there are no rules about which characters are allowed
	   and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
	   is a legal e-mail address. */
	var quotedUser="(\"[^\"]*\")"

	/* The following pattern applies for domains that are IP addresses,
	   rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
	   e-mail address. NOTE: The square brackets are required. */
	var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/

	/* The following string represents an atom (basically a series of
	   non-special characters.) */
	var atom=validChars + '+'

	/* The following string represents one word in the typical username.
	   For example, in john.doe@somewhere.com, john and doe are words.
	   Basically, a word is either an atom or quoted string. */
	var word="(" + atom + "|" + quotedUser + ")"

	// The following pattern describes the structure of the user
	var userPat=new RegExp("^" + word + "(\\." + word + ")*$")

	/* The following pattern describes the structure of a normal symbolic
	   domain, as opposed to ipDomainPat, shown above. */
	var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$")

	var matchArray=emailStr.match(emailPat)
	if (matchArray==null)
	{
		alert("E-2206: \u7121\u52b9\u306a\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u304c\u5165\u529b\u3055\u308c\u3066\u3044\u307e\u3059\u3002.")
		return false
	}
	var user=matchArray[1]
	var domain=matchArray[2]

	// See if "user" is valid
	if (user.match(userPat)==null)
	{
		// user is not valid
		alert("E-2206: \u7121\u52b9\u306a\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u304c\u5165\u529b\u3055\u308c\u3066\u3044\u307e\u3059\u3002.")
		return false
	}

	/* if the e-mail address is at an IP address (as opposed to a symbolic
	   host name) make sure the IP address is valid. */
	var IPArray=domain.match(ipDomainPat)
	if (IPArray!=null)
	{
		// this is an IP address
		  for (var i=1;i<=4;i++)
		  {
			if (IPArray[i]>255)
			{
				alert("E-2206: \u7121\u52b9\u306a\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u304c\u5165\u529b\u3055\u308c\u3066\u3044\u307e\u3059\u3002.")
				return false
			}
		  }

		  return true
	}

	// Domain is symbolic name
	var domainArray=domain.match(domainPat)
	if (domainArray==null)
	{
		alert("E-2206: \u7121\u52b9\u306a\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u304c\u5165\u529b\u3055\u308c\u3066\u3044\u307e\u3059\u3002.")
		return false
	}

	/* domain name seems valid, but now make sure that it ends in a
	   three-letter word (like com, edu, gov) or a two-letter word,
	   representing country (uk, nl), and that there's a hostname preceding
	   the domain or country. */

	/* Now we need to break up the domain to get a count of how many atoms
	   it consists of. */
	var atomPat=new RegExp(atom,"g")
	var domArr=domain.match(atomPat)
	var len=domArr.length
	if (domArr[domArr.length-1].length<2 || domArr[domArr.length-1].length>3)
	{
	   // the address must end in a two letter or three letter word.
	   alert("E-2206: \u7121\u52b9\u306a\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u304c\u5165\u529b\u3055\u308c\u3066\u3044\u307e\u3059\u3002.")
	   return false
	}

	// Make sure there's a host name preceding the domain.
	if (len<2)
	{
	   alert("E-2206: \u7121\u52b9\u306a\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9\u304c\u5165\u529b\u3055\u308c\u3066\u3044\u307e\u3059\u3002.")
	   return false
	}

	// If we've gotten this far, everything's valid!
	return true;
}


function validateTAPage(page, fromPage, searchPageNumber)
{
	if(travelAgentForm.page.value=="createTA")
	{
		if(isBlank(travelAgentForm.travelAgentCode,"TA \u30b3\u30fc\u30c9","y"))
			return(false);
		
		if(!checklength(travelAgentForm.travelAgentCode,5,"","","n"))
		{
			alert("E-2207: TA\u30b3\u30fc\u30c9\u306f\uff15\u6587\u5b57\u304c\u5fc5\u8981\u3067\u3059\u3002");
			travelAgentForm.travelAgentCode.select();
			travelAgentForm.travelAgentCode.focus();
			return(false);
		}

		var vtacode = tacode.exec(travelAgentForm.travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2208: TA\u30b3\u30fc\u30c9\u306b\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentForm.travelAgentCode.select();
			travelAgentForm.travelAgentCode.focus();
		    return(false);
		}
		
		if(travelAgentForm.travelAgentCode.value=="00000")
		{
			alert("E-2209: \u6709\u52b9\u306aTA\u30b3\u30fc\u30c9\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			travelAgentForm.travelAgentCode.select();
			travelAgentForm.travelAgentCode.focus();
			return(false);	
		}
		
	}
	
	if(travelAgentForm.contactPerson.value!="")
	{
		var vperson = nam.exec(travelAgentForm.contactPerson.value);
		if(!vperson)
		{
			alert("E-2210: \u9023\u7d61\u62c5\u5f53\u8005\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentForm.contactPerson.select();
			travelAgentForm.contactPerson.focus();
			return(false);
		}
	}
	
	
	if(isBlank(travelAgentForm.agencyName,"\u65c5\u884c\u4f1a\u793e\u540d","y"))
		return(false);
		
	var vagency = agencyname.exec(travelAgentForm.agencyName.value);
	if(!vagency)
	{
		alert("E-2211: \u65c5\u884c\u4f1a\u793e\u540d\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		travelAgentForm.agencyName.select();
		travelAgentForm.agencyName.focus();
		return(false);
	}
	
	
	if(travelAgentForm.agencyOwner.value!="")
	{
		var vagency = nam.exec(travelAgentForm.agencyOwner.value);
		if(!vagency)
		{
			alert("E-2212: \u65c5\u884c\u4f1a\u793e\u6240\u6709\u8005\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentForm.agencyOwner.select();
			travelAgentForm.agencyOwner.focus();
			return(false);
		}
	}
	
	if(!validatePostCode())
		return(false);
	
	/*
	if(travelAgentForm.city.value!="")
	{
		var vcity = nam.exec(travelAgentForm.city.value);
		if(!vcity)
		{
			alert("City can contain only alphabets");
			travelAgentForm.city.select();
			travelAgentForm.city.focus();
			return(false);
		}
	}
	*/
	
	if(travelAgentForm.country.value!="")
	{
		var vcountry = country.exec(travelAgentForm.country.value);
		
		if(!vcountry)
		{
			alert("E-2213: \u56fd\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentForm.country.select();
			travelAgentForm.country.focus();
			return(false);		
		}
	}
	
	if(travelAgentForm.phone.value!="")
	{
		var vphone = phone.exec(travelAgentForm.phone.value);
		if(!vphone)
		{
			alert("E-2214: \u96fb\u8a71\u756a\u53f7\u306b\u306f\u6570\u5b57\u53ca\u3073\u3000\u3000\uff0d\u3000\uff08\uff09\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002\u3000");
			travelAgentForm.phone.select();
			travelAgentForm.phone.focus();
			return(false);
		}
	}
	
	if(travelAgentForm.email.value!="")
	{
		if(!emailCheck(travelAgentForm.email.value))
		{
			travelAgentForm.email.select();
			travelAgentForm.email.focus();
			return(false);
		}
	}
	
	
	if(travelAgentForm.fax.value!="")
	{
		var vfax = phone.exec(travelAgentForm.fax.value);
		if(!vfax)
		{
			alert("E-2215: Fax\u756a\u53f7\u306b\u306f\u6570\u5b57\u53ca\u3073\u3000\u3000\uff0d\u3000\uff08\uff09\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentForm.fax.select();
			travelAgentForm.fax.focus();
			return(false);
		}
	}
	
	travelAgentForm.phone.value = travelAgentForm.phone.value.replace('+','');
	travelAgentForm.phone.value = travelAgentForm.phone.value.replace('-','');
	travelAgentForm.phone.value = travelAgentForm.phone.value.replace('(','');
	travelAgentForm.phone.value = travelAgentForm.phone.value.replace(')','');			
	
	if(page=="maintain" && fromPage!="-1" && searchPageNumber!="-1")
	{
		travelAgentForm.action = "travelAgent.do?subaction=updateTravelAgentDetails&fromPage="+fromPage+"&fromPageNumber="+searchPageNumber;
	}	
	
	travelAgentForm.submit();		
}

function clearTACreatePage()
{
	travelAgentForm.travelAgentCode.value="";
	travelAgentForm.contactPerson.value="";
	travelAgentForm.agencyName.value="";
	travelAgentForm.agencyOwner.value="";
	travelAgentForm.postCodePrefix.value="";
	travelAgentForm.postCodeSuffix.value="";
	travelAgentForm.addressLine1.value="";
	travelAgentForm.addressLine2.value="";
	travelAgentForm.city.value="";
	travelAgentForm.country.value="";
	travelAgentForm.phone.value="";
	travelAgentForm.email.value="";
	travelAgentForm.fax.value="";
	travelAgentForm.travelAgentCode.focus();	
}

function deactivate(fromPage, fromPageNumber)
{
	if(fromPage!="-1" && fromPageNumber!="-1")
		travelAgentForm.action="travelAgent.do?subaction=deActivateTravelAgent&fromPage="+fromPage+"&fromPageNumber="+fromPageNumber;
	else
		travelAgentForm.action="travelAgent.do?subaction=deActivateTravelAgent";
	
	travelAgentForm.submit();
}

function validateSearchPage() 
{
	if(travelAgentSearchForm.travelAgentCode.value!="")
	{
		var vtacode = tacode.exec(travelAgentSearchForm.travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2216: TA\u30b3\u30fc\u30c9\u306b\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentSearchForm.travelAgentCode.select();
			travelAgentSearchForm.travelAgentCode.focus();
		    return(false);
		}
	
	}

	
	if(travelAgentSearchForm.agencyName.value!="")
	{		
		var vagency = agencyname.exec(travelAgentSearchForm.agencyName.value);
		if(!vagency)
		{
			alert("E-2217: \u65c5\u884c\u4f1a\u793e\u540d\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentSearchForm.agencyName.select();
			travelAgentSearchForm.agencyName.focus();
			return(false);
		}
	}


	if(travelAgentSearchForm.agencyOwner.value!="")
	{
		var vagency = nam.exec(travelAgentSearchForm.agencyOwner.value);
		if(!vagency)
		{
			alert("E-2218: \u65c5\u884c\u4f1a\u793e\u6240\u6709\u8005\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentSearchForm.agencyOwner.select();
			travelAgentSearchForm.agencyOwner.focus();
			return(false);
		}
	}

	if(travelAgentSearchForm.city.value!="")
	{
		var vcity = nam.exec(travelAgentSearchForm.city.value);
		if(!vcity)
		{
			alert("E-2219: \u90fd\u5e02\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			travelAgentSearchForm.city.select();
			travelAgentSearchForm.city.focus();
			return(false);
		}
	}

	travelAgentSearchForm.submit();
}

function ltrim(s)
{
	return s.replace( /^\s*/, "" )
}

function rtrim(s)
{
	return s.replace( /\s*$/, "" );
}


function trim(s)
{
	return rtrim(ltrim(s));
}


function focusOnPostCodeField()
{
	if(travelAgentForm.postcodeError.value=="prefix")
	{
		travelAgentForm.postCodePrefix.select();
		travelAgentForm.postCodePrefix.focus();
	}

	if(travelAgentForm.postcodeError.value=="suffix")
	{
		travelAgentForm.postCodeSuffix.select();
		travelAgentForm.postCodeSuffix.focus();
	}
	
	travelAgentForm.postcodeError.value="";

}
