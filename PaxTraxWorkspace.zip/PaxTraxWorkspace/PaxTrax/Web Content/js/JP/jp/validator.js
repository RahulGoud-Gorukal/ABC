function ltrim(s) {
	return s.replace(/^\s*/, "");
}

function rtrim(s) {
	return s.replace(/\s*$/, "");
}

/**
funtion using for removing the empty spaces from both sides of  the String
*/
function trim(value) {
	return rtrim(ltrim(value));
}


function nameCheck(str1,label)
{
	var nam=/^[A-Z a-z]*$/;
	var vnam = nam.exec(str1.value);
		if(!vnam)
		{
			alert("E-2298: \u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002 " + label);
			str1.select();
			str1.focus();
			return(false);
		}
		else
			return(true);
}
function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-2299: " + label + "\u306f\u7121\u52b9\u3067\u3059\u3002"+ dateformat+"\u306e\u5f62\u5f0f\u3067\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}
function isSplCharsPresent(strng)  {
 strng=trim(strng);
 var valid = true;
 
 if(strng != "") {
 
 for(i=0;i<strng.length;i++) {
  val=strng.charAt(i);    // val: to get each character from string
 
	if ( (!(val>='0' && val<='9')) && (!(val>='a' && val<='z')) && (!(val>='A' && val<='Z'))) // checking for each character 
        {
        	valid = false; 
        	break;
        }
 
	}
	
  } else {
  	valid = false;
  }	
 	
 	return valid;
  
}
function checkAlphaNumericString(strng)  {
 strng=trim(strng);
 if(strng=="") return;
 for(i=0;i<strng.length;i++) {
  val=strng.charAt(i);    // val: to get each character from string
 
  if ( (!(val>='0' && val<='9')) && (!(val>='a' && val<='z')) && (!(val>='A' && val<='Z')) && (val!='-')&& (val!='.')&& (val!='_') && (val!=' ')) // checking for each character 
        {return false; }
 
 }
 return true;
  
}

function checkSpecialCharacters(value)
{
	value=trim(value);
		 
	for(i=0;i<value.length;i++) 
	{
	 	val=value.charAt(i);    // val: to get each character from string
	
	 	if ( (!(val>='0' && val<='9')) && (!(val>='a' && val<='z')) && (!(val>='A' && val<='Z')) && (val!='-')&& (val!='.')&& (val!='_') && (val!=' ')) // checking for each character 
	    {
	       return false; 
	 	}
 	}
 	return true;
}
	
function tabToNextField(curr)
{
	var keycode = window.event.keyCode;

	if(!( (keycode>=48 && keycode<=57) || (keycode>=65 && keycode<=90) || (keycode>=96 && keycode<=110) || (keycode>=186 && keycode<=222)))
		return(false);

	if(curr.value.length==curr.getAttribute('maxlength'))
	{
		var thisForm = window.document.forms[0];
		var count = thisForm.length;
		var firstelement = null;

		var currtabindex = curr.getAttribute('tabIndex');
		var totabindex = currtabindex + 1;
		var tabindex = 0;

		for (var i = 0; i < count; i++)
		{
			elem = thisForm.elements[i];
			tabindex = elem.getAttribute('tabIndex');

			if(tabindex==1)
				firstelement = elem;

			if(tabindex==totabindex)
			{
				if(elem.disabled == false)
				{
					elem.focus();
					return(false);
				}
				else
					totabindex = totabindex + 1;
			}
		}

		if(firstelement)
		{
			if(firstelement.disabled == false)
				firstelement.focus();
		}

	}

	return(false);
}

function deletePrompt(form, url) {
	if(confirm("\u524a\u9664\u3057\u305f\u3044\u3068\u601d\u3046\u304b\u3002 ?"))
	{
		form.action=url;
		form.submit();
	}
	else
	{
		return ;
	}
}