//dfdpMonthlySummaryRpt.js

var printWindow;
function openPrintPage() {
	if(printWindow==null)
	{
		printWindow= window.open("./nabcoSummaryReportAction.do?subaction=printDFDPMonthlySummaryReport");
	}
	else
	{
		printWindow.close();
		printWindow=null;
		printWindow= window.open("./nabcoSummaryReportAction.do?subaction=printDFDPMonthlySummaryReport");
	}
}

function submitClickForm() {
	document.getElementById("nabcoProgress").innerHTML='Nabco \u306e\u6708\u4f8b\u6982\u7565\u5831\u544a\u306f\u9032\u884c\u3057\u3066\u3044\u308b...';		
	stampDutyForm.submit();	
	stampDutyForm.submit();
}

function closePrintWindow() {
	if (printWindow != null) printWindow.close();
}
