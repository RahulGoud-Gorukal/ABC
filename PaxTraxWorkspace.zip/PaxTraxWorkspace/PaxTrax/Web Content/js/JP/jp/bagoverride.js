function languageToggle(url)
{
	bagOverrideForm.action = url;
	bagOverrideForm.submit();
}

function assignAirportSubmit() {
	var bagnumber = document.all('bagBean.bagNumber');
	var binlocation = document.all('bagBean.apBinLocation');
	if (validate()) {
		if(confirm("\u888b\u7b2c "+ bagnumber.value +" u306f AP \u306e\u5927\u7bb1 "+binlocation.value +".\n \u306b\u7d9a\u304d\u305f\u3044\u3068\u601d\u3046\u95a2\u9023\u4ed8\u3051\u3089\u308c\u308b\u304b\u3002 ?"))
		bagOverrideForm.submit();
		else
		{
			document.forms[0].bagNumber.select();		
			document.forms[0].bagNumber.focus();
			return;
		}
		
	}
}



function validate() {
	var bagnumber = document.all('bagBean.bagNumber');
	var binlocation = document.all('bagBean.apBinLocation');
	if (trim(bagnumber.value).length == 0)
	{
		alert('E-5205: \u888b\u6570\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044');
		document.forms[0].bagNumber.focus();
		return false;
	} 
	else
	{
			if (!validatebagNumber(bagnumber))
			{
				document.forms[0].bagNumber.select();		
				document.forms[0].bagNumber.focus();
				return false;
			}
			else
			{
			
				if (trim(binlocation.value).length == 0)
				{
					alert('E-5205: Ap \u306e\u5927\u7bb1\u306e\u4f4d\u7f6e\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044');
					document.forms[0].apBin.focus();
					return false;
				}
				else
				{
					if (validateBinLocation(binlocation))
					{
						return true;
					}
					else
					{
						document.forms[0].apBin.select();		
						document.forms[0].apBin.focus();
						return false;
					}
				}
			}
	}
}


function cancel() {
	bagOverrideForm.action="home.do?subaction=bagtrackingHomePage";
	bagOverrideForm.submit();
}

function trim(inputString)
{
	if (typeof inputString != "string")
	{ 
		return inputString;
	}
	var retValue = inputString;
	var ch = retValue.substring(0, 1);
	while (ch == " ")
	{
	      retValue = retValue.substring(1, retValue.length);
	      ch = retValue.substring(0, 1);
	}
	ch = retValue.substring(retValue.length-1, retValue.length);
	while (ch == " ")
	{
     		retValue = retValue.substring(0, retValue.length-1);
		 ch = retValue.substring(retValue.length-1, retValue.length);
	}
   	while (retValue.indexOf("  ") != -1)
	{
	      retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ")+1, retValue.length);
	      
	}
	return retValue; 
}

function validatebagNumber(bagNumber)
{
	var bag =/^\d{12,12}$/;
	var vbag = bag.exec(bagNumber.value);

	if(!vbag)
	{
		alert("E-5205: \u888b\u6570\u306f\u6570\u5b57 12 \u30c7\u30a3\u30b8\u30c3\u30c8\u306e\u3079\u304d\u3067\u3042\u308b");
		bagNumber.select();
		bagNumber.focus();
		return(false);
	}		

	return(true);
}


function validateBinLocation(binLocation) {
	var bin = /^[A-Z a-z]{2}\d{2}$/;
	var vbin = bin.exec(binLocation.value);
	if (!vbin) {
		alert("E-4101: \u30d3\u30f3\u306e\u5834\u6240\u306e\u30d5\u30a9\u30fc\u30de\u30c3\u30c8\u306fAL93\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		return false;
	} else {
		return true;
	}
}



function assignWareHouseSubmit() {
    
   var bagnumber = document.all('bagBean.bagNumber');
   	if (trim(bagnumber.value).length == 0)
	{
			alert('E-5205: \u888b\u6570\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044');
			document.forms[0].bagNumber.focus();
			return;
	}
	if (!validatebagNumber(bagnumber)) 
	{
			
		document.forms[0].bagNumber.select();		
		document.forms[0].bagNumber.focus();
		return;
	} 
	
    var checkbox = document.all('bagBean.truck');
    var truckNo = checkbox.options[checkbox.selectedIndex].text;
    if (checkbox.selectedIndex > 0) 
    {
    	if(confirm("\u7b2c "+ bagnumber.value +" \u3092\u30c8\u30e9\u30c3\u30af\u3067\u904b\u3076\u305f\u3081\u306b\u888b\u7b2c "+truckNo +".\n\u306f\u7d9a\u304d\u305f\u3044\u3068\u601d\u3046\u95a2\u9023\u4ed8\u3051\u3089\u308c\u308b\u304b\u3002 ?"))
    	bagOverrideForm.submit();
    	else
    	{
	    	document.forms[0].bagNumber.select();		
			document.forms[0].bagNumber.focus();
					return;
    	}	
    }
    else
    {
		alert(" E 4199 \u6709\u52b9\u306a\u30c8\u30e9\u30c3\u30af\u3092\u9078\u3073\u306a\u3055\u3044");
    	document.forms[0].truck.focus();
    	return;
    }
    
    
}


function validatebagNumberforChangeStatus()
{

	var bag =/^\d{12,12}$/;	
	var bagnumber = document.forms[0].bagNumber;
	var vbag = bag.exec(bagnumber.value);

	if (trim(bagnumber.value).length == 0)
	{
		alert('E-5205: \u888b\u6570\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044');
		document.forms[0].bagNumber.focus();
		return;
	}

	if(!vbag)
	{
		alert('E-5205: \u888b\u6570\u306f\u6570\u5b57 12 \u30c7\u30a3\u30b8\u30c3\u30c8\u306e\u3079\u304d\u3067\u3042\u308b');
		document.forms[0].bagNumber.select();
		document.forms[0].bagNumber.focus();		
		return;
	}		

	var confirm = window.confirm("\u30C8\u30E9\u30F3\u30B6\u30AF\u30B7\u30E7\u30F3\u306E\u30B9\u30C6\u30FC\u30BF\u30B9\u3092\u5909\u66F4\u3057\u307E\u3059\u304B\uFF1F '"+bagnumber.value+"' ?");		
	
	if(confirm)
		bagOverrideForm.submit();
	else
		document.forms[0].bagNumber.select();
		document.forms[0].bagNumber.focus();		
}


//Added by selvam for CA# 294102 starts

// Added/Modified by David for CR 3659 starts
function bagLookUp() {

	//var bagnumber = document.all('bagBean.bagNumber');
	

		if(document.forms[0].paxNumber.value!="")
		{
			if(validatepaxNumber())
			{

				document.forms[0].method="POST";
				document.forms[0].action="bagOverrideAction.do?subaction=bagLookUp";
				bagOverrideForm.submit();
			}
		}
		else
		{
		alert("E-5205: PAX\u756A\u53F7\u306F\u7A7A\u306B\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093\u3002");
			bagOverrideForm.paxNumber.focus();
		}

}
		function releaseBagSubmit(index) {

	
	document.forms[0].bagNumber.value = "" ;

		if(document.forms[0].paxNumber.value!="")
		{
		
					if(confirm('\u30D0\u30C3\u30B0\u306F\u30D4\u30C3\u30AF\u30C9\u30A2\u30C3\u30D7\u30D0\u30A4\u30AB\u30B9\u30BF\u30DE\u30FC\u306B\u5909\u66F4\u3055\u308C\u307E\u3059\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F'))
					{
				bagOverrideForm.index.value = index;
				document.forms[0].method="POST";
				document.forms[0].action="bagOverrideAction.do?subaction=releaseBags";
				bagOverrideForm.submit();
			       }
				else
				{
				bagOverrideForm.paxNumber.select();
				bagOverrideForm.paxNumber.focus();
				return;
				}
	
		}
		else
		{
		alert("E-5205: \u888b\u6570\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
		bagOverrideForm.paxNumber.focus();
		return;
		}
}

function releaseBagSubmit1() {

	
		

		if(document.forms[0].paxNumber.value!="")
		{
			if(validatepaxNumber())
			{
				if(validatebagNumber())
				{
					if(confirm('\u30D0\u30C3\u30B0\u306F\u30D4\u30C3\u30AF\u30C9\u30A2\u30C3\u30D7\u30D0\u30A4\u30AB\u30B9\u30BF\u30DE\u30FC\u306B\u5909\u66F4\u3055\u308C\u307E\u3059\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F'))
					{
				
				
					document.forms[0].method="POST";
					document.forms[0].action="bagOverrideAction.do?subaction=releaseBags";
					bagOverrideForm.submit();
					}
					else
					{
					bagOverrideForm.bagNumber.select();
					bagOverrideForm.bagNumber.focus();
					return;
					}
				}
			}
		}
		else
		{
			alert("E-5205: \u888b\u6570\u306f\u7a7a\u3067\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
			bagOverrideForm.paxNumber.focus();
			return;
		}
}	

function assignSeaBin() {
//	var bagnumber = document.all('bagBean.bagNumber');
	
 
     var checkbox = document.all('bagBean.truck');
    var truckNo = checkbox.options[checkbox.selectedIndex].text;
    	var binlocation = document.all('bagBean.apBinLocation');
    if (checkbox.selectedIndex > 0) 
    {

    if (trim(binlocation.value).length == 0)
				{
					alert('E-5215: \u6D77\u306E\u30D3\u30F3\u306E\u4F4D\u7F6E\u306F\u7A7A\u306B\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093');
			
					document.forms[0].apBin.focus();
		 return;
				}
				else
				{
			
					var bin = /^[A-Z a-z]{2}\d{2}$/;
	var exec = bin.exec(binlocation.value);
	if (!exec) {
		alert("E-4100: Bin location format should be AL93");
		document.forms[0].apBin.select();	
			return  ;
		}
					 
				}
				
		if(confirm('\u30C8\u30E9\u30C3\u30AF\u306E\u30B1\u30FC\u30B8\u306F\u30B7\u30FC\u30DD\u30FC\u30C8\u30D3\u30F3\u306B\u30A2\u30B5\u30A4\u30F3\u3055\u308C\u307E\u3059\u3002\u7D9A\u884C\u3057\u307E\u3059\u304B\uFF1F'))
    		bagOverrideForm.submit();
    	else
    	{
	    document.forms[0].truck.focus();
					return;
    	}	
    }
    else
    {
    			alert(" E 4199 \u6709\u52b9\u306a\u30c8\u30e9\u30c3\u30af\u3092\u9078\u3073\u306a\u3055\u3044");
    	document.forms[0].truck.focus();
    	return ;
    }
    		
     
	 
}


	function validatebagNumber()
	{
		var bag =/^\d{12,12}$/;
		var vbag = bag.exec(document.forms[0].bagNumber.value);
		
		if(!vbag)
		{
		alert("E-5205: \u888b\u6570\u306f\u6570\u5b57 12 \u30c7\u30a3\u30b8\u30c3\u30c8\u306e\u3079\u304d\u3067\u3042\u308b");
			document.forms[0].bagNumber.select();
			document.forms[0].bagNumber.focus();
			return(false);
		}		

		return(true);
	}	
	
	function validatepaxNumber()
{
	var paxn=/^[0-9]+$/;
	var vpaxn=paxn.exec(document.forms[0].paxNumber.value);

	if(!vpaxn)
	{
		window.alert('E-2100: PAX \u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002');
		document.forms[0].paxNumber.select();
		document.forms[0].paxNumber.focus();
		return(false);
	}

	if(!checklength(document.forms[0].paxNumber,10,"PAX \u756a\u53f7","\u6587\u5b57","y"))
		return(false);
	
	if(document.forms[0].paxNumber.value == "0000000000")
	{
		alert("E-2101: \u6709\u52b9\u306a PAX \u756a\u53f7\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		document.forms[0].paxNumber.select();
		document.forms[0].paxNumber.focus();
		return(false);
	}

	return(true);

}
function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-2103: " + label + " \u306b\u306f" + len + "\u5b57\u306e"+type+"\u5217\u304c\u5fc5\u8981\u3067\u3059\u3002");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}
//Added by selvam for CA# 294102 ends
// Added/Modified by David for CR 3659 ends

