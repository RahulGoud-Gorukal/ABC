
// passenger.js

var paxn=/^[0-9]+$/;
var nam=/^[A-Z a-z]+$/;
//var city=/^[A-Z a-z]+$/;
var tele=/^[\+\-()\d]+$/;
var passpo=/^[A-Z 0-9 a-z]+$/;
var flc=/^(\d)[A-Z]$/;
var fln=/^\d{3,5}$/;
var tacode=/^[A-Z 0-9 a-z]+$/;
var rentacar=/^[A-Z 0-9 a-z]+$/;
var tourcode = /^[A-Z 0-9 a-z]+$/;
var postcode = /^[0-9]+$/;
var tabranch = /^[A-Z 0-9 a-z]+$/;
var travelAgentWindow = null;
var country = /^[A-Z a-z]+$/;

function validatePAXNumber(paxvar)
{
	var vpaxn=paxn.exec(paxvar.value);

	if(!vpaxn)
	{
		window.alert("E-2100: PAX \u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	if(!checklength(paxvar,10,"PAX \u756a\u53f7","\u6587\u5b57","y"))
		return(false);
	
	if(paxvar.value == "0000000000")
	{
		alert("E-2101: \u6709\u52b9\u306a PAX \u756a\u53f7\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	return(true);

}


function isBlank(str1,label,prompt)
{
	if(str1.value=="")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-2102: " + label + " \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u3002");
			str1.select();
			str1.focus();
		}

		return(true);		
	}

	return(false);
}


function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-2103: " + label + " \u306b\u306f" + len + "\u5b57\u306e"+type+"\u5217\u304c\u5fc5\u8981\u3067\u3059\u3002");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}


function validatePostCode(fromValidation)
{
	if(!isBlank(visitPaxForm.postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(visitPaxForm.postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2104: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			if(fromValidation!="lookup")
			{
				visitPaxForm.postCodePrefix.select();
				visitPaxForm.postCodePrefix.focus();
			}
			else
				visitPaxForm.postcodeError.value="prefix";
				
			return(false);
		}
	}
	
	if(!isBlank(visitPaxForm.postCodeSuffix," ","n"))
	{	
		vpostcode = postcode.exec(visitPaxForm.postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2105: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			if(fromValidation!="lookup")
			{
				visitPaxForm.postCodeSuffix.select();
				visitPaxForm.postCodeSuffix.focus();
			}
			else
				visitPaxForm.postcodeError.value="suffix";
				
			return(false);
		}
	}
	
	return(true);
}

function postCodeLookup()
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		if(!isBlank(visitPaxForm.postCodePrefix," ","n") || !isBlank(visitPaxForm.postCodeSuffix," ","n"))
		{
			if(validatePostCode("lookup"))
			{
				visitPaxForm.action="visitPaxAction.do?subaction=postCodeLookup";
				visitPaxForm.submit();
			}
		}
	}
}

function validatePage(page, fromPage, searchPageNumber)
{
	if(isBlank(visitPaxForm.paxNumber,"PAX \u756a\u53f7","y"))
		return(false);

	if(isBlank(visitPaxForm.lastName,"\u59d3","y"))
		return(false);
		
	var vnam = nam.exec(visitPaxForm.lastName.value);
	if(!vnam)
	{
		alert("E-2106: \u59d3\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		visitPaxForm.lastName.select();
		visitPaxForm.lastName.focus();
		return(false);
	}

	if(isBlank(visitPaxForm.firstName,"\u540d","y"))
		return(false);

	vnam = nam.exec(visitPaxForm.firstName.value);
	if(!vnam)
	{
		alert("E-2107: \u540d\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		visitPaxForm.firstName.select();
		visitPaxForm.firstName.focus();
		return(false);
	}
	
	if(!validatePostCode())
		return(false);
	
	if(visitPaxForm.country.value!="")
	{
		var vcountry = country.exec(visitPaxForm.country.value);
		
		if(!vcountry)
		{
			alert("E-2108: \u56fd\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			visitPaxForm.country.select();
			visitPaxForm.country.focus();
			return(false);	
		}
	}
		
	if(visitPaxForm.departureAirlineCode.value=="-1")
	{
		alert("E-2111: \u9069\u5f53\u306a\u51fa\u767a\u822a\u7a7a\u4f1a\u793e\u30b3\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u4e0b\u3055\u3044\u3002");
		visitPaxForm.departureAirlineCode.focus();	
		return(false);
	}
	
	if(isBlank(visitPaxForm.departureFlightNumber,"\u51fa\u767a\u4fbf\u540d", "y"))
		return(false);
		
	var vfln=fln.exec(visitPaxForm.departureFlightNumber.value);

	if(!vfln)
	{
		window.alert("E-2112: \u51fa\u767a\u4fbf\u540d\u3092\u6b63\u3057\u304f\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		visitPaxForm.departureFlightNumber.select();
		visitPaxForm.departureFlightNumber.focus();
		return(false);
	}
	
	if(visitPaxForm.arrivalAirlineCode.value!="-1" || !isBlank(visitPaxForm.arrivalFlightNumber," ","n"))
	{
		if(visitPaxForm.arrivalAirlineCode.value=="-1")  
		{
			alert("E-2113: \u9069\u5f53\u306a\u5230\u7740\u822a\u7a7a\u4f1a\u793e\u30b3\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitPaxForm.arrivalAirlineCode.focus();
			return(false);
		}
		
		if(isBlank(visitPaxForm.arrivalFlightNumber,"\u5230\u7740\u4fbf\u540d", "y"))
			return(false);
			
		vfln=fln.exec(visitPaxForm.arrivalFlightNumber.value);
	
		if(!vfln)
		{
			window.alert("E-2114: \u5230\u7740\u4fbf\u540d\u3092\u6b63\u3057\u304f\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitPaxForm.arrivalFlightNumber.select();
			visitPaxForm.arrivalFlightNumber.focus();
			return(false);
		}
	}

	if (isBlank(visitPaxForm.departureFlightDate,"\u51fa\u767a\u65e5","y"))
		return(false);
		
	if(!validateDate(visitPaxForm.departureFlightDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
		return(false);
		
	var today = new Date();
	var day   = today.getDate();
	var month = today.getMonth();
	month = month + 1;
	var year  = today.getYear();

	if(day<10)
		day = "0" + day;

	if(month<10)
		month = "0" + month;
	
	if(year<1000)
		year + 1900;	
	
	var todayString = year + "/" + month + "/" + day;
	
	if(visitPaxForm.departureFlightDate.value<todayString)
	{
		alert("E-2115: \u51fa\u767a\u65e5\u306f\u904e\u53bb\u65e5\u3068\u306f\u306a\u3089\u306a\u3044\u3002");
		visitPaxForm.departureFlightDate.select();
		visitPaxForm.departureFlightDate.focus();
		return(false);
	}
		
	if(!isBlank(visitPaxForm.arrivalFlightDate," ","n"))
	{
		if(!validateDate(visitPaxForm.arrivalFlightDate,"yyyy/mm/dd","\u5230\u7740\u65e5","y"))		
			return(false);
	}
	
	if(visitPaxForm.departureFlightDate.value<visitPaxForm.arrivalFlightDate.value)
	{
	       alert("E-2116: \u51fa\u767a\u65e5\u306f\u5230\u7740\u65e5\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
	       return(false);
	}
	
	if(visitPaxForm.nationality.value!="-1")
		visitPaxForm.nationalityValue.value = visitPaxForm.nationality.options[visitPaxForm.nationality.selectedIndex].text;
	else
		visitPaxForm.nationalityValue.value = "";
		
// Added for CR611 changes on Jul 31, 2008 --  -Begin		
	if(visitPaxForm.promotion.value!="-1")
		visitPaxForm.promotionValue.value = visitPaxForm.promotion.options[visitPaxForm.promotion.selectedIndex].text;
	else
		visitPaxForm.promotionValue.value = "";		
// Added for CR611 changes on Jul 31, 2008 --  -End			
	
	if(visitPaxForm.departureAirlineCode.value!="-1")
		visitPaxForm.depAirlineCodeValue.value = visitPaxForm.departureAirlineCode.options[visitPaxForm.departureAirlineCode.selectedIndex].text;
	else
		visitPaxForm.depAirlineCodeValue.value = "";

	if(visitPaxForm.arrivalAirlineCode.value!="-1")
		visitPaxForm.arrAirlineCodeValue.value = visitPaxForm.arrivalAirlineCode.options[visitPaxForm.arrivalAirlineCode.selectedIndex].text;
	else
		visitPaxForm.arrAirlineCodeValue.value = "";

	visitPaxForm.submit();
	
}

function clearSubmit()
{
    visitPaxForm.paxNumber.value = "";
    visitPaxForm.lastName.value = "";
	visitPaxForm.firstName.value = "";
	visitPaxForm.postCodePrefix.value = "";
	visitPaxForm.postCodeSuffix.value = "";
	visitPaxForm.addressLine1.value = "";
	visitPaxForm.addressLine2.value = "";
	visitPaxForm.city.value="";
	visitPaxForm.country.value="";
	visitPaxForm.nationality.selectedIndex = 0;
	visitPaxForm.departureAirlineCode.selectedIndex = 0;
	visitPaxForm.departureFlightNumber.value = "";
	visitPaxForm.arrivalAirlineCode.selectedIndex = 0;
	visitPaxForm.arrivalFlightNumber.value = "";
	visitPaxForm.departureFlightDate.value = "";
	visitPaxForm.arrivalFlightDate.value = "";
	visitPaxForm.paxNumber.focus();
	visitPaxForm.primaryPAXChechbox.checked = false;
	visitPaxForm.primaryPAXNumber.value = "";
	return;
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-2121: " + label + "\u306f\u7121\u52b9\u3067\u3059\u3002"+ dateformat+"\u306e\u5f62\u5f0f\u3067\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}


function clearSearchForm()
{
	document.forms[0].lastName.value = "";
	document.forms[0].firstName.value = "";
	document.forms[0].postCodePrefix.value = "";
	document.forms[0].postCodeSuffix.value = "";
	document.forms[0].departureAirlineCode.selectedIndex = 0;
	document.forms[0].departureFlightNumber.value = "";
	document.forms[0].arrivalAirlineCode.selectedIndex = 0;
	document.forms[0].arrivalFlightNumber.value = "";
	document.forms[0].departureFlightDate.value = "";
	document.forms[0].arrivalFlightDate.value = "";
	document.forms[0].travelAgentCode.value = "";
	document.forms[0].lastName.focus();
}


function validateSearchForm()
{

	if(!isBlank(document.forms[0].lastName," ","n"))
	{
		var vnam = nam.exec(document.forms[0].lastName.value);
		if(!vnam)
		{
			alert("E-2122: \u59d3\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].lastName.select();
			document.forms[0].lastName.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].firstName," ","n"))
	{
		vnam = nam.exec(document.forms[0].firstName.value);
		if(!vnam)
		{
			alert("E-2123: \u540d\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].firstName.select();
			document.forms[0].firstName.focus();
			return(false);
		}	
	}
	
	if(!isBlank(document.forms[0].postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(document.forms[0].postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2124: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].postCodePrefix.select();
			document.forms[0].postCodePrefix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].postCodeSuffix," ","n"))
	{
		vpostcode = postcode.exec(document.forms[0].postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2125: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			document.forms[0].postCodeSuffix.select();
			document.forms[0].postCodeSuffix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].travelAgentCode," ","n"))
	{
		var vtacode = tacode.exec(document.forms[0].travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2126: TA \u30b3\u30fc\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].travelAgentCode.select();
			document.forms[0].travelAgentCode.focus();
			return(false);
		}
	}
	
	if(document.forms[0].departureFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].departureFlightNumber.value))
		{
			alert("E-2127: \u51fa\u767a\u4fbf\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].departureFlightNumber.select();
			document.forms[0].departureFlightNumber.focus();
			return(false);
		}
	}
	
	if(document.forms[0].arrivalFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].arrivalFlightNumber.value))
		{
			alert("E-2128: \u5230\u7740\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].arrivalFlightNumber.select();
			document.forms[0].arrivalFlightNumber.focus();
			return(false);
		}
	}
		
	if(!isBlank(document.forms[0].departureFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].departureFlightDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
			return(false);
	}
	
	if(!isBlank(document.forms[0].arrivalFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].arrivalFlightDate,"yyyy/mm/dd","\u5230\u7740\u65e5","y"))		
			return(false);
			
       var arrflidate=strconvert(document.forms[0].arrivalFlightDate);
       var depflidate=strconvert(document.forms[0].departureFlightDate);    
     
       if(depflidate<arrflidate)
       {
           alert("E-2129: \u51fa\u767a\u65e5\u306f\u5230\u7740\u65e5\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
           document.forms[0].departureFlightDate.select();
           document.forms[0].departureFlightDate.focus();
           return(false);
       }
    
	}
	
	paxSearchForm.submit();

}

function strconvert(str1)
{
	var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}


function newPax()
{
    visitPaxForm.action = "visitPaxAction.do?subaction=createPaxPage";
}

function primaryFlagChecked()
{
	if(visitPaxForm.primaryPAXChechbox.checked)
	{
		visitPaxForm.primaryPAXNumber.value = "";
		visitPaxForm.primaryPAXNumber.disabled = true;
		visitPaxForm.primaryFlag.value="Y";
	}
	else
	{
		visitPaxForm.primaryPAXNumber.disabled = false;
		visitPaxForm.primaryFlag.value="N";			
	}
}

function outboundFlagChecked()
{
	if(visitPaxForm.outboundPAXCheckbox.checked)
	{
		visitPaxForm.outboundFlag.value="Y";
	}
	else
	{
		visitPaxForm.outboundFlag.value="N";			
	}
}

function focusOnPostCodeField()
{
	if(visitPaxForm.postcodeError.value=="prefix")
	{
		visitPaxForm.postCodePrefix.select();
		visitPaxForm.postCodePrefix.focus();
	}

	if(visitPaxForm.postcodeError.value=="suffix")
	{
		visitPaxForm.postCodeSuffix.select();
		visitPaxForm.postCodeSuffix.focus();
	}
	
	visitPaxForm.postcodeError.value="";

}

function formatDateOnBlur(date1)
{
	if(date1.value!="")
	{
		if(validateDate(date1,"yyyy/mm/dd"," ","n"))
			date1.value = strconvert(date1);			
	}
}

function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}

function validateBTSearchForm()
{

	if(!isBlank(document.forms[0].lastName," ","n"))
	{
		var vnam = nam.exec(document.forms[0].lastName.value);
		if(!vnam)
		{
			alert("E-2122: \u59d3\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].lastName.select();
			document.forms[0].lastName.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].firstName," ","n"))
	{
		vnam = nam.exec(document.forms[0].firstName.value);
		if(!vnam)
		{
			alert("E-2123: \u540d\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].firstName.select();
			document.forms[0].firstName.focus();
			return(false);
		}	
	}
	
	if(!isBlank(document.forms[0].postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(document.forms[0].postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2124: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].postCodePrefix.select();
			document.forms[0].postCodePrefix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].postCodeSuffix," ","n"))
	{
		vpostcode = postcode.exec(document.forms[0].postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2125: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			document.forms[0].postCodeSuffix.select();
			document.forms[0].postCodeSuffix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].travelAgentCode," ","n"))
	{
		var vtacode = tacode.exec(document.forms[0].travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2126: TA \u30b3\u30fc\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].travelAgentCode.select();
			document.forms[0].travelAgentCode.focus();
			return(false);
		}
	}
	
	if(document.forms[0].departureFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].departureFlightNumber.value))
		{
			alert("E-2127: \u51fa\u767a\u4fbf\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].departureFlightNumber.select();
			document.forms[0].departureFlightNumber.focus();
			return(false);
		}
	}
	
	if(document.forms[0].arrivalFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].arrivalFlightNumber.value))
		{
			alert("E-2128: \u5230\u7740\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].arrivalFlightNumber.select();
			document.forms[0].arrivalFlightNumber.focus();
			return(false);
		}
	}
		
	if(!isBlank(document.forms[0].departureFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].departureFlightDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
			return(false);
	}
	
	if(!isBlank(document.forms[0].arrivalFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].arrivalFlightDate,"yyyy/mm/dd","\u5230\u7740\u65e5","y"))		
			return(false);
			
       var arrflidate=strconvert(document.forms[0].arrivalFlightDate);
       var depflidate=strconvert(document.forms[0].departureFlightDate);    
     
       if(depflidate<arrflidate)
       {
           alert("E-2129: \u51fa\u767a\u65e5\u306f\u5230\u7740\u65e5\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
           document.forms[0].departureFlightDate.select();
           document.forms[0].departureFlightDate.focus();
           return(false);
       }
    
	}
	document.paxSearchForm.action = "btPaxSearch.do";
	document.paxSearchForm.subaction.value = "searchPAXDetails";	
	document.paxSearchForm.submit();

}