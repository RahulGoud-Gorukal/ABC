
function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}


function trimObject(obj)
{
	obj.value=trim(obj.value);
	return true;
}


function SalesAssociateReport(form)
{
	
	if(form.location.value == "-1")
	{
		alert("E-1700 \u7121\u52b9\u306a\u4f4d\u7f6e");
		form.location.focus();
		return ;
	}
	
	if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To date","y"))		
			return;		
	if(!validateAssociateDate(form))
	return;
	
	var sellingLocation = document.getElementById('sellingLocation').innerHTML;	
	form.action="salesReportAction.do?subaction=getSalesAssociateReport&location="+sellingLocation;
	form.submit();
}

function SalesTerminalReport(form)
{
	
	if(form.location.value == "-1")
	{
		alert("E-1700 \u7121\u52b9\u306a\u4f4d\u7f6e");
		form.location.focus();
		return ;
	}
	
	if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To date","y"))		
			return;		
	if(!validateAssociateDate(form))
	return;
	var sellingLocation = document.getElementById('sellingLocation').innerHTML;	
	form.action="salesReportAction.do?subaction=getSalesTerminalReport&location="+sellingLocation;
	form.submit();
}

function SalesByHourReport(form)
{

	if(form.location.value == "-1")
	{
		alert("E-1700 \u7121\u52b9\u306a\u4f4d\u7f6e");
		form.location.focus();
		return ;
	}
	
	if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To date","y"))		
			return;		
	if(!validateAssociateDate(form))
	return;
	
	var sellingLocation = document.getElementById('sellingLocation').innerHTML;	
	form.action="salesReportAction.do?subaction=generateSalesByHourReport&location="+sellingLocation;
	form.submit();

}

function SalesDepartmentReport(form)
{
	
	if(form.location.value == "-1")
	{
		alert("E-1700 \u7121\u52b9\u306a\u4f4d\u7f6e");
		form.location.focus();
		return ;
	}
	
	if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To date","y"))		
			return;	

	if(!validateDepartmentTime(form))
	return;			
	var sellingLocation = document.getElementById('sellingLocation').innerHTML;
	form.action="salesReportAction.do?subaction=getSalesDepartmentReport&location="+sellingLocation;
	form.submit();
}

function SalesTenderReport(form)
{
	/*if(form.location.value == "-1")
	{
		alert("E-1700 \u7121\u52b9\u306a\u4f4d\u7f6e");
		form.location.focus();
		return ;
	}*/
	
	if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To date","y"))		
			return;		
	if(!validateAssociateDate(form))
	return;
	
	var sellingLocation = document.getElementById('sellingLocation').innerHTML;	
	form.action="salesReportAction.do?subaction=createSalesTenderReport&location="+sellingLocation;
	form.submit();
}

function SalesLocationReport(form)
{
/*if(form.location.value == "-1")
	{
		alert("E-1700 Invalid Location");
		form.location.focus();
		return ;
	}*/
	if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To date","y"))		
			return;		
	if(!validateAssociateDate(form))
	return;
	
	var todaysdate = new Date();
    var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	var fromdate = strconvert(document.forms[0].fromDate.value);
	var todate = strconvert(document.forms[0].toDate.value);
	if (fromdate > todaydate )
	{
		alert("E-3126: \u73fe\u5728\u306e\u65e5\u4ed8\u3088\u308a\u524d\u306e\u65e5\u4ed8\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
		return;
	}
	
	if (todate > todaydate )
	{
		alert("E-3127: \u73fe\u5728\u306e\u65e5\u4ed8\u3088\u308a\u5f8c\u306e\u65e5\u4ed8\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
		return;
	}
	
	form.action="salesReportAction.do?subaction=createSalesLocationReport";
	form.submit();
}

function strconvert(str1)
{
	var temp = str1.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-2121: " + label + "\u306f\u7121\u52b9\u3067\u3059\u3002"+ dateformat+"\u306e\u5f62\u5f0f\u3067\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}

function validateAssociateDate(form)
{
	
	if((form.fromDate.value)> (form.toDate.value))
	{
		alert("E-1004 - \u65e5\u4ed8\u304b\u3089\u306e\u3088\u308a\u3088\u308a\u5c11\u3057\u306f\u4eca\u307e\u3067\u306b\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
		form.fromDate.select();
		form.fromDate.focus();
		return false;
	}
	return true;
}

function validateDepartmentTime(form)
{
	if((form.fromDate.value)> (form.toDate.value))
	{
		alert("E-1004 - \u65e5\u4ed8\u304b\u3089\u306e\u3088\u308a\u3088\u308a\u5c11\u3057\u306f\u4eca\u307e\u3067\u306b\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
		form.fromDate.select();
		form.fromDate.focus();
		return false;
	}
	else if((form.fromDate.value) == (form.toDate.value))
	{
		
		if(validateTime(form.fromHr.value,form.fromMin.value,form.toHr.value,form.toMin.value))
		{	
			form.fromHr.focus();
			return false;
		}
	}
	
	return true;
}

function validateTime(opnHr,opnMns,closeHr,closeMns)
{

	openHrs = parseInt(opnHr,10);
	openMns = parseInt(opnMns,10);
	closeHrs = parseInt(closeHr,10);
	closeMins = parseInt(closeMns,10);
	
	if(openHrs == closeHrs)	
	{
		if(openMns > closeMins)
		{
			alert("E-3138: To\u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			return (true);
		}
		else if(openMns == closeMins)
		{
			alert("E-3139: From\u306e\u6642\u9593\u3068To\u306e\u6642\u9593\u304c\u540c\u3058\u306b\u306a\u3089\u306a\u3044\u3088\u3046\u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			return (true);
		}
		else
		return (false);
	}
	else if(openHrs > closeHrs)
	{
		alert("E-3140: To\u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		return (true);
	}
	else
	{
		return (false);
	}
}
	
function exportDepartmentData(form)
{

	var sellingLocation = document.getElementById('sellingLocation').innerHTML;	

	form.action="salesReportAction.do?subaction=generateSalesDepartmentReport&location="+sellingLocation;
	form.submit();

}

function exportAssociateData(form)
{

	var sellingLocation = document.getElementById('sellingLocation').innerHTML;	
	form.action="salesReportAction.do?subaction=generateSalesByAssociateReport&location="+sellingLocation;
	form.submit();

}

function checkCurrency(form)
{

 var currency =form.currency.options[form.currency.selectedIndex].text;
 
 	if(currency =="JPY" )
	{  
	   form.exchangeRate.value="1";
	   form.exchangeRate.disabled=true;   
	
	} 
	else
	{
	   form.exchangeRate.disabled=false;    
	}

}

function salesDFSOwnedReport(form)
{
	

	var currency =form.currency.options[form.currency.selectedIndex].text;
		
	if(!validateDate(document.forms[0].fromDate1,"yyyy/mm/dd","Range1 From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate1,"yyyy/mm/dd","Range1 To date","y"))		
			return;	

	if(!validateDate(document.forms[0].fromDate2,"yyyy/mm/dd","Range2 From Date","y"))		
			return;
	
	if(!validateDate(document.forms[0].toDate2,"yyyy/mm/dd","Range2 To date","y"))		
			return;	



	if(!validateDFSOwnedDateTime(form))
	return;	
	
	if(currency !="JPY" )
	{  
	   // Modified on 2006-07-27
	   // var exRate=/^[0-9.]+$/;  	   
	   // Regular Expression change to allow the user to enter decimal number in the Exchange Rate field 
	   var exRate=/(^-*\d+$)|(^-*\d+\.\d+$)/;  
	   var exchangeRate=exRate.exec(form.exchangeRate.value); 
	   
		if(form.exchangeRate.value=="")
		{
			window.alert("E-2201 - \u4F55\u304B\u6570\u5B57\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
			form.exchangeRate.select();
			form.exchangeRate.focus();
			return;
		}

		if(!exchangeRate || form.exchangeRate.value=="0")
		{
			window.alert("E-2200 - \u6570\u5B57\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
			form.exchangeRate.select();
			form.exchangeRate.focus();
			return;
		}
	} 		
    form.exRateHidden.value=form.exchangeRate.value;
	form.action="salesReportExtnAction.do?subaction=getDFSOwnedSalesReport";
    form.submit();
}

function exportDFSOWnedReportData(form)
{
	form.action="salesReportExtnAction.do?subaction=generateDFSOwnedSalesReport";
	form.submit();
}

function validateDFSOwnedDateTime(form)
{
	if((form.fromDate1.value)> (form.toDate1.value))
	{
		alert("E-1004 - \u65e5\u4ed8\u304b\u3089\u306e\u3088\u308a\u3088\u308a\u5c11\u3057\u306f\u4eca\u307e\u3067\u306b\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
		form.fromDate1.select();
		form.fromDate1.focus();
		return false;
	}
	else if((form.fromDate1.value) == (form.toDate1.value))
	{
		
		if(validateTime(form.fromHr1.value,form.fromMin1.value,form.toHr1.value,form.toMin1.value))
		{	
			form.fromHr1.focus();
			return false;
		}
	}
	
	if((form.fromDate2.value)> (form.toDate2.value))
	{
		alert("E-1004 - \u65e5\u4ed8\u304b\u3089\u306e\u3088\u308a\u3088\u308a\u5c11\u3057\u306f\u4eca\u307e\u3067\u306b\u3042\u308b\u3053\u3068\u304c\u3067\u304d\u306a\u3044");
		form.fromDate2.select();
		form.fromDate2.focus();
		return false;
	}
	else if((form.fromDate2.value) == (form.toDate2.value))
	{
		
		if(validateTime(form.fromHr2.value,form.fromMin2.value,form.toHr2.value,form.toMin2.value))
		{	
			form.fromHr2.focus();
			return false;
		}
	}

	
	return true;
}