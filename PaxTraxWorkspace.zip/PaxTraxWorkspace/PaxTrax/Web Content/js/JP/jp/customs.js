var flightNumber = /^\d+$/;
var postcode=/^\w+$/;
var accno=/^\w*$/;
var nam=/^[A-Z \s a-z]+$/;
var bankname=/^[A-Z \s a-z 0-9]*$/;
var city=/^[A-Z \s 0-9 a-z]+$/;
var country=/^[A-Z \s 0-9 a-z]*$/;
var addr=/^[.]+$/;
var addr2=/^[.]+$/;
var branchname=/^[A-Z \s 0-9 a-z]*$/;
var desc=/^[A-Z \s 0-9 a-z]*$/;
var remark=/^[A-Z \s 0-9 a-z]*$/;
var postcode = /^[0-9]+$/;

var totalCollapsibleMenuItems = 5;

function showHide(id){
	for (ctr=0; ctr<totalCollapsibleMenuItems; ctr++) {
		var objectName = document.all ("CollapsibleMenuItem" + (ctr+1));
		if ((ctr+1) == id) {
			if(objectName.style.display == ""){
				objectName.style.display = "none" ;
			}
			else {
				objectName.style.display = "" ;
			}
		}
		else {
				objectName.style.display = "none" ;
		}
	}
}

function isEmpty(value) {
		if (value == null || value.length == 0) return true;
		else return false;
	}

function isRepeated(dateValue, dateList) {
	var success = false;
	var dateListLen = dateList.length;
	for(j=0;j<dateListLen;j++)
	{
		if(dateValue == dateList[j].value){
			success = true;
			break;
		}
		else
		{
			success = false;
		}
	}
	return success;
}
function trimObject(obj)
{
	obj.value=trim(obj.value);
	return true;
}
function CompareTodaysDate(str1)
{
	var todaysdate = new Date();
	var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	
	var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
	
	
	if(str1.value < todaydate)
	{
	       	alert("E-3100: \u9280\u884c\u4f11\u65e5\u306e\u65e5\u4ed8\u306f\u4eca\u65e5\u3068\u540c\u3058\u307e\u305f\u306f\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
	       	str1.select();
	       	str1.focus();
	     	return(false);
    }
    else if(temp.length == 3 )
	{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10);
			var days = new Array(7)
			
			days[1] = "\u6708\u66dc\u65e5";
			days[2] = "\u706b\u66dc\u65e5"; 
			days[3] = "\u6c34\u66dc\u65e5";
			days[4] = "\u6728\u66dc\u65e5";
			days[5] = "\u91d1\u66dc\u65e5";
			days[6] = "\u571f\u66dc\u65e5";
			days[7] = "\u65e5\u66dc\u65e5";

			var selectedDate =new Date();
			selectedDate.setUTCFullYear(temp[0]);
			selectedDate.setUTCMonth(temp[1]-1);
			selectedDate.setUTCDate(temp[2]);
			var id = selectedDate.getUTCDay();
			if(id == 0)
			 id = 7;

			var obj = eval("document.bankAccountForm.checker"+id);
			if(obj.checked)
			{
				alert("E-3101: "+days[id] +" \u65e2\u306b\u975e\u55b6\u696d\u65e5\u3068\u9078\u629e\u3055\u308c\u3066\u3044\u307e\u3059\u3002");
				document.bankAccountForm.date1.select();
				document.bankAccountForm.date1.focus();
				return (false);
			}
			else
	   			return(true);

	}
	
}
	function moveintolist()
	{
		if(!isEmpty(document.bankAccountForm.date1.value))
		{
			if(validateDate(document.bankAccountForm.date1,"yyyy/mm/dd","\u65e5\u4ed8","y"))
			{
				if(CompareTodaysDate(document.bankAccountForm.date1))
				{
				
					if(!isRepeated(document.bankAccountForm.date1.value,document.bankAccountForm.bankHolidayDateList))
					{
					
						if(validateHoilidayWorkingHrs(document.bankAccountForm.holidayStartHrs1.value,document.bankAccountForm.holidayStartMins1.value,bankAccountForm.holidayEndHrs1.value,bankAccountForm.holidayEndMins1.value))
						{
			//				document.bankAccountForm.holidayEndHrs1.select();
							document.bankAccountForm.holidayEndHrs1.focus();
							return(false);
			  			}				
						
						if(!validateRemark(trim(document.bankAccountForm.remarks1.value)))
						{
							document.bankAccountForm.remarks1.select();
							document.bankAccountForm.remarks1.focus();
							//return(false);
						}
						else
						{
							var len = document.bankAccountForm.bankHolidayDateList.length;
							var datesrc = eval(document.bankAccountForm.bankHolidayDateList);
							var remarkssrc = eval(document.bankAccountForm.bankHolidayRemarkList);
							var holidayStartHrs = eval(document.bankAccountForm.holidayStartHrsList);
							var holidayStartMins = eval(document.bankAccountForm.holidayStartMinsList);
							var holidayEndHrs = eval(document.bankAccountForm.holidayEndHrsList);
							var holidayEndMins = eval(document.bankAccountForm.holidayEndMinsList);
	
							datesrc.options[len] = new Option(document.bankAccountForm.date1.value, document.bankAccountForm.date1.value);
							remarkssrc.options[len] = new Option(document.bankAccountForm.remarks1.value, document.bankAccountForm.remarks1.value);
							holidayStartHrs.options[len] = new Option(document.bankAccountForm.holidayStartHrs1.options[document.bankAccountForm.holidayStartHrs1.selectedIndex].text, document.bankAccountForm.holidayStartHrs1.options[document.bankAccountForm.holidayStartHrs1.selectedIndex].text);
							holidayStartMins.options[len] = new Option(document.bankAccountForm.holidayStartMins1.options[document.bankAccountForm.holidayStartMins1.selectedIndex].text, document.bankAccountForm.holidayStartMins1.options[document.bankAccountForm.holidayStartMins1.selectedIndex].text);
							holidayEndHrs.options[len] = new Option(document.bankAccountForm.holidayEndHrs1.options[document.bankAccountForm.holidayEndHrs1.selectedIndex].text, document.bankAccountForm.holidayEndHrs1.options[document.bankAccountForm.holidayEndHrs1.selectedIndex].text);
							holidayEndMins.options[len] = new Option(document.bankAccountForm.holidayEndMins1.options[document.bankAccountForm.holidayEndMins1.selectedIndex].text, document.bankAccountForm.holidayEndMins1.options[document.bankAccountForm.holidayEndMins1.selectedIndex].text);
	
							document.bankAccountForm.date1.value = "";
							document.bankAccountForm.remarks1.value = "";
							document.bankAccountForm.holidayStartHrs1.selectedIndex =0;
							document.bankAccountForm.holidayStartMins1.selectedIndex =0;
							document.bankAccountForm.holidayEndHrs1.selectedIndex =0;
							document.bankAccountForm.holidayEndMins1.selectedIndex =0;
	
							var oTable = eval(document.all("table1"));
							var oRow;
							var oCell;
	
							var bgcolor1;
							if(len%2 == 0)
								bgcolor1 = "#FAFAFA";
							else
								bgcolor1 = "#FFFEF6";
	
							oRow = oTable.insertRow();
							oCell = oRow.insertCell();
							oCell.innerHTML = "<input type=checkbox name=check" + len + " onclick=checkStatus('check"+len+"')>";
							oCell.bgColor = bgcolor1;
							oCell = oRow.insertCell();
							oCell.bgColor = bgcolor1;
							oCell.innerHTML = '<FONT SIZE="1.5" COLOR="#000000" FACE="Arial, Helvetica, sans-serif">' + datesrc.options[len].value + '&nbsp;&nbsp;&nbsp;' + holidayStartHrs.options[len].value + ':' + holidayStartMins.options[len].value + '&nbsp;-&nbsp;' + holidayEndHrs.options[len].value + ':' +holidayEndMins.options[len].value  + '</font>';
							oCell = oRow.insertCell();
							oCell.bgColor = bgcolor1;
							oCell.innerHTML = '<FONT SIZE="1.5" COLOR="#000000" FACE="Arial, Helvetica, sans-serif">' + remarkssrc.options[len].value + '</font>';

							for (var j = 0;j <= len;j++)
							{
								var h = "check"+j;
								var chk = eval(document.all(h));
								if (chk != null)
								{
									chk.disabled = false;
									chk.checked = false;
								}
							}
						}
					}
					else
					{
						alert("E-3102: \u5165\u529b\u3055\u308c\u305f\u65e5\u4ed8\u306f\u65e2\u306b\u4f11\u65e5\u30ea\u30b9\u30c8\u306b\u5165\u3063\u3066\u3044\u307e\u3059\u3002");
						document.bankAccountForm.date1.select();
						document.bankAccountForm.date1.focus();
					}
				}
			}
		}
		else
		{
			alert("E-3103: \u65e5\u4ed8\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			document.bankAccountForm.date1.focus();
		}
		
	}
	function checkStatus(checkBoxName)
	{
	
	
		var len = document.bankAccountForm.bankHolidayDateList.length;
		var id = len - 1;
		
		var k;
		
		var parentObj = eval("document.bankAccountForm."+checkBoxName)
		for(k=0; k<len;k++)
		{
			var obj = eval("document.bankAccountForm.check"+k);
		
			
			if(parentObj.checked)
			{
				if(checkBoxName == ("check"+k) )
				{
					obj.disabled = false;
					
				}
				else
				{
					obj.disabled = true;	
				}
			}
			else
				obj.disabled = false;
			
	
		}

	
		
	}
	function removefromlist()
	{
		var datesrc = eval(document.bankAccountForm.bankHolidayDateList);
		var remarkssrc = eval(document.bankAccountForm.bankHolidayRemarkList);
		var holidayStartHrs = eval(document.bankAccountForm.holidayStartHrsList);
		var holidayStartMins = eval(document.bankAccountForm.holidayStartMinsList);
		var holidayEndHrs = eval(document.bankAccountForm.holidayEndHrsList);
		var holidayEndMins = eval(document.bankAccountForm.holidayEndMinsList);
		var len = document.bankAccountForm.bankHolidayDateList.length;
	
		var chkcount = 0;

		for(var i=0;i<len; i++)
		{
			var chk1 = eval("document.bankAccountForm.check"+i);
			if(chk1.checked)
			{
				/*alert("i is"+i);
				alert("Date is "+ datesrc.options[i].value);
				alert("Remarks  is "+remarkssrc.options[i].value);
				alert("holidayStartHrs  is "+holidayStartHrs.options[i].value);
				alert("holidayStartMins  is "+holidayStartMins.options[i].value);
				alert("holidayEndHrs  is "+holidayEndHrs.options[i].value);
				alert("holidayEndMins  is "+holidayEndMins.options[i].value);*/
				document.bankAccountForm.date1.value = datesrc.options[i].value;
				document.bankAccountForm.remarks1.value = remarkssrc.options[i].value;
				document.bankAccountForm.holidayStartHrs1.value =holidayStartHrs.options[i].value;
				document.bankAccountForm.holidayStartMins1.value =holidayStartMins.options[i].value;
				document.bankAccountForm.holidayEndHrs1.value =holidayEndHrs.options[i].value;
				document.bankAccountForm.holidayEndMins1.value =holidayEndMins.options[i].value;
							
							
				datesrc.options[i-chkcount] = null   //i-chkcount is done inorder to account for the change in position of an option because of the removal of preceding options
				remarkssrc.options[i-chkcount] = null;
				holidayStartHrs.options[i-chkcount] = null;
				holidayStartMins.options[i-chkcount] = null;
				holidayEndHrs.options[i-chkcount] = null;
				holidayEndMins.options[i-chkcount] = null;
				
				chkcount++;
			}

		}


		var oTable = eval(document.all("table1"));

		for(var i=1;i<=len; i++) //The length of the table is len + 1 (including the heading)
			oTable.deleteRow(1);

		var oRow;
		var oCell;

		len = document.bankAccountForm.bankHolidayDateList.length;
		var bgcolor1;

		for(var i=0; i<len; i++)
		{
			if(i%2 == 0)
				bgcolor1 = "#FAFAFA";
			else
				bgcolor1 = "#FFFEF6";

			oRow = oTable.insertRow();
			oCell = oRow.insertCell();
			oCell.innerHTML = "<input type=checkbox name=check" + i + " onclick=checkStatus('check"+i+"')>";
			oCell.bgColor= bgcolor1;
			oCell = oRow.insertCell();
			oCell.innerHTML = '<FONT SIZE="1.5" COLOR="#000000" FACE="Arial, Helvetica, sans-serif">' + datesrc.options[i].value + '&nbsp;&nbsp;&nbsp;' + holidayStartHrs.options[i].value + ':' + holidayStartMins.options[i].value + '&nbsp;-&nbsp;' + holidayEndHrs.options[i].value + ':' +holidayEndMins.options[i].value  + '</font>';
			oCell.bgColor= bgcolor1;
			oCell = oRow.insertCell();
			oCell.innerHTML = '<FONT SIZE="1.5" COLOR="#000000" FACE="Arial, Helvetica, sans-serif">' + remarkssrc.options[i].value + '</font>';
			oCell.bgColor= bgcolor1;
		}

	}
	

function validateAccountNumber(accNo)
{
	var length= accNo.length;	
	var valToCompare = "";
	for (var k=0; k < length ; k++){
		valToCompare = valToCompare + "0";
	}
	if(accNo == valToCompare){
		alert("E-3104: \u5f53\u5ea7\u9810\u91d1\u756a\u53f7\u306f\u30bc\u30ed\u3067\u3044\u3051\u307e\u305b\u3093\u3002");
		document.bankAccountForm.savingAccountNum.select();
		document.bankAccountForm.savingAccountNum.focus();
		return(false);
	}
	var vnam = accno.exec(accNo);
	if(!vnam) 
	{
		alert("E-3105: \u5f53\u5ea7\u9810\u91d1\u756a\u53f7\u306b\u306f\u6570\u5b57\u306e\u307f\u304c\u4f7f\u3048\u307e\u3059\u3002");
		document.bankAccountForm.savingAccountNum.select();
		document.bankAccountForm.savingAccountNum.focus();
		return(false);
	}
	return(true);
}

function validateRemark(rmrk)
{

	document.bankAccountForm.remarks1.value=trim(document.bankAccountForm.remarks1.value);
//	alert(document.bankAccountForm.remarks1.value);
	if(document.bankAccountForm.remarks1.value ==null || trim(document.bankAccountForm.remarks1.value).length <= 0)		
	{
		alert("E-3106: \u5099\u8003\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		document.bankAccountForm.remarks1.select();
		document.bankAccountForm.remarks1.focus();
		return(false);
	}
	var vnam =remark.exec(rmrk);
	if(!vnam) 
	{
		alert("E-3107: \u5099\u8003\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
		document.bankAccountForm.remarks1.select();
		document.bankAccountForm.remarks1.focus();
		return(false);
	}
	return(true);
}

function validateAddr1(address1)
{

	var vnam = addr.exec(address1);
	if(!vnam) 
	{
		alert("E-3108: \u4f4f\u6240\uff11\u306b\u306f\u7279\u5225\u6587\u5b57\u3092\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
		document.bankAccountForm.add1.select();
		document.bankAccountForm.add1.focus();
		return(false);
	}
	return(true);
}

function validateAddr2(address2)
{

	var vnam = addr.exec(address2);
	if(!vnam)
	{
		alert("E-3109: \u4f4f\u6240\uff12\u306b\u306f\u7279\u5225\u6587\u5b57\u3092\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
		document.bankAccountForm.add2.select();
		document.bankAccountForm.add2.focus();
		return(false);
	}
	return(true);
}

function validateBankName(bankName)
{

	var vnam = bankname.exec(bankName);
	if(!vnam)
	{
		alert("E-3110: \u9280\u884c\u540d\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
		document.bankAccountForm.bankName.select();
		document.bankAccountForm.bankName.focus();
		return(false);
	}
	return(true);

}
function validateBranchName(branchName)
{

	var vnam=branchname.exec(branchName);
	if(!vnam) {
	alert("E-3111: \u652f\u5e97\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
	document.bankAccountForm.branch.select();
	document.bankAccountForm.branch.focus();
	return(false);
	}
	return(true);
}

function validatePostCodePrefix(postCodeValue)
{
 	var vnam = postcode.exec(postCodeValue);
	if(!vnam) {
		alert("E-3112: \u90f5\u4fbf\u756a\u53f7\u306e\u63a5\u982d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		document.bankAccountForm.postCodePre.select();
		document.bankAccountForm.postCodePre.focus();
		return (false);
	}
	return(true);
}


function validatePostCodeSuffix(postCodeValue)
{
 	var vnam = postcode.exec(postCodeValue);
	if(!vnam) {
		alert("E-3113: \u90f5\u4fbf\u756a\u53f7\u306e\u63a5\u5c3e\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		document.bankAccountForm.postcodeSuff.select();
		document.bankAccountForm.postcodeSuff.focus();
		return (false);
	}
	return(true);
}
function validateDescription(description)
{

	var vnam=desc.exec(description);
	if(!vnam) {
	alert("E-3114: \u8aac\u660e\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
	document.bankAccountForm.secAccountDesc.select();
	document.bankAccountForm.secAccountDesc.focus();
	return(false);
	}
	return(true);
}


function validateCity(cityName)
{

	var vnam = city.exec(cityName);
	if(!vnam) {
		alert("E-3115: \u90fd\u5e02\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
		document.bankAccountForm.city.select();
		document.bankAccountForm.city.focus();
		return(false);
	}
	return(true);

}

function validateCountry(countryName)
{

	var vnam = country.exec(countryName);
	if(!vnam) {
		alert("E-3116: \u56fd\u8aac\u660e\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
		document.bankAccountForm.country.select();
		document.bankAccountForm.country.focus();
		return(false);
	}
	return(true);

}


function validateSecAccountNumber(accNo)
{
	var length= accNo.length;
	var valToCompare = "";
	for (var k=0; k < length ; k++){
		valToCompare = valToCompare + "0";
	}
	if(accNo == valToCompare){
		alert("E-3117: \u4fdd\u8a3c\u9810\u91d1\u756a\u53f7\u306f\u30bc\u30ed\u3067\u3044\u3051\u307e\u305b\u3093\u3002" );
		document.bankAccountForm.secAccountNum.select();
		document.bankAccountForm.secAccountNum.select();
		return(false);
	}
	var vnam = accno.exec(accNo);
	if(!vnam) 
	{
		alert("E-3118: \u4fdd\u8a3c\u9810\u91d1\u756a\u53f7\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		document.bankAccountForm.secAccountNum.select();
		document.bankAccountForm.secAccountNum.focus();
		return(false);
	}
	return(true);
}






function checklength(str1,len,label,type,prompt) //checklength(text field object, the expected length, label, type, prompt)
{
	if(trim(str1.value).length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-3119: " + label + " \u306b\u306f " + len + "\u5b57\u306e"+type+"\u6587\u5b57\u5217\u304c\u5fc5\u8981\u3067\u3059\u3002");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}


function validateForm()
{
	// Validating Savings Account Number 
	if(isBlank(document.bankAccountForm.savingAccountNum,"\u53e3\u5ea7\u756a\u53f7","y"))
	{
			document.bankAccountForm.savingAccountNum.focus();
			return false;
	}
	if(!validateAccountNumber(trim(document.bankAccountForm.savingAccountNum.value)))
	{
		
		return(false);
	}
	
	// Validating Bank Name	
	if(!validateBankName(trim(document.bankAccountForm.bankName.value)))
	{
		
		return(false);
	}
	
	
	// Validating Branch Name
	 if(!validateBranchName(trim(document.bankAccountForm.branch.value)))
	{
				
				return(false);
	}

	 
	// Validating Postal Code
	 	
	 if(trim(document.bankAccountForm.postCodePre.value).length == 0
					&& trim(document.bankAccountForm.postcodeSuff.value).length  > 0)
	{
		   alert("E-3120: \u90f5\u4fbf\u756a\u53f7\u306e\u63a5\u982d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		   document.bankAccountForm.postCodePre.focus();	  
		   return(false);
	}
	if(trim(document.bankAccountForm.postCodePre.value).length > 0
					&& trim(document.bankAccountForm.postcodeSuff.value).length == 0)
	{
	  	   alert("E-3121: \u90f5\u4fbf\u756a\u53f7\u306e\u63a5\u5c3e\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		    document.bankAccountForm.postcodeSuff.focus();	  
		    return(false);
	  
	}
	if(trim(document.bankAccountForm.postCodePre.value).length > 0 &&
			trim(document.bankAccountForm.postcodeSuff.value).length  > 0)
	{
		if(!validatePostCodePrefix(trim(document.bankAccountForm.postCodePre.value)))
		{
				document.bankAccountForm.postCodePre.focus();
				return(false);				
		}
		if(!validatePostCodeSuffix(trim(document.bankAccountForm.postcodeSuff.value)))
		{
				document.bankAccountForm.postcodeSuff.focus();
				return(false);				
		}
	}
	
	 
	// Validatinging Address Line1
	if(isBlank(document.bankAccountForm.add1,'\u4f4f\u6240 1','y'))
	{
		document.bankAccountForm.add1.focus();
	 	return(false);
	}
	/*if(!validateAddr1(trim(document.bankAccountForm.add1.value))) 
	{
			document.bankAccountForm.add1.focus();
			return(false);
	}*/
	
	// Validating Address 2
 	/*if(! validateAddr2(trim(document.bankAccountForm.add2.value)))
	{
		document.bankAccountForm.add2.focus();
		return(false);
	}*/

	
	// Validating City
	if(isBlank(document.bankAccountForm.city,'\u90fd\u5e02','y'))
	{	 
		 return false;
	}
	/*if(!validateCity(trim(document.bankAccountForm.city.value)))
	{
		document.bankAccountForm.city.focus();
		return(false);
	}*/
	if(!validateCountry(trim(document.bankAccountForm.country.value))) 
	{
		document.bankAccountForm.country.focus();
		return(false);
	}	
	
	 
	 var k;
	 var obj;
	 var count=0;
	 for(k=1; k<=7;k++)
	 {
		obj=eval("document.bankAccountForm.checker"+k);
		if(!obj.checked)
		{
			count = 1;			
			var fromHr =eval("document.bankAccountForm.fromHr"+k);
			var fromMin =eval("document.bankAccountForm.fromMin"+k);
			var toHr =eval("document.bankAccountForm.toHr"+k);
			var toMin =eval("document.bankAccountForm.toMin"+k);
		 	if(validateWorkingHrs(fromHr.value,fromMin.value,	toHr.value, toMin.value))
			{
				obj=eval("document.bankAccountForm.toHr"+k);
				obj.focus();
				return(false);
			}
		}
	 }
	
	 if(count == 0)
	 {
		alert("E-3122: \u55b6\u696d\u65e5\u306f\u5c11\u306a\u304f\u3066\u3082\u4e00\u65e5\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
	
		return false;
	 }
	 
	  // Validation for Flight Security Account Number 
	 //Changed by David for CA #313423, Security account to Flight security account and related 
	 
	
	if(isBlank(document.bankAccountForm.secAccountNum,'\u30D5\u30E9\u30A4\u30C8\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u30A2\u30AB\u30A6\u30F3\u30C8 ','y'))
	{
		document.bankAccountForm.secAccountNum.focus();
		return false;
	}
	if(!validateSecAccountNumber(trim(document.bankAccountForm.secAccountNum.value)))
	{
		document.bankAccountForm.secAccountNum.focus();
		return(false);
	}
 
	 // Validation for Bank Ac / Flight Security Bank Account
	if(trim(document.bankAccountForm.savingAccountNum.value) == trim(document.bankAccountForm.secAccountNum.value))
	{
	  alert("E-3123: \u666E\u901A\u9810\u91D1\u53E3\u5EA7\u756A\u53F7\u306F\u3001\u98DB\u884C\u306E\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u30A2\u30AB\u30A6\u30F3\u30C8\u3068\u540C\u3058\u756A\u53F7\u306B\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093\u3002"); 
	  document.bankAccountForm.secAccountNum.select();
	  document.bankAccountForm.secAccountNum.focus();
	  return false;
	}
	if(!validateDescription(trim(document.bankAccountForm.secAccountDesc.value)))
	{

		document.bankAccountForm.secAccountDesc.focus();
		return(false);

	}
	//Added by David for CA #313423 starts
	
	// Validation for Vessel Security Account Number 
	
	if(isBlank(document.bankAccountForm.vesselAccountNum,'\u8239\u8236\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u30A2\u30AB\u30A6\u30F3\u30C8 ','y'))
	{
		document.bankAccountForm.vesselAccountNum.focus();
		return false;
	}
	if(!validateSecAccountNumber(trim(document.bankAccountForm.vesselAccountNum.value)))
	{
		document.bankAccountForm.vesselAccountNum.focus();
		return(false);
	}
	
	// Validation for Bank Ac / Vessel Security Bank Account
	
	if(trim(document.bankAccountForm.savingAccountNum.value) == trim(document.bankAccountForm.vesselAccountNum.value))
	{
	  alert("E-3123: \u666E\u901A\u9810\u91D1\u53E3\u5EA7\u756A\u53F7\u306F\u3001\u8239\u8236\u306E\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u30A2\u30AB\u30A6\u30F3\u30C8\u756A\u53F7\u3068\u540C\u3058\u306B\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093\u3002"); 
	  document.bankAccountForm.vesselAccountNum.select();
	  document.bankAccountForm.vesselAccountNum.focus();
	  return false;
	}
	
	if(!validateDescription(trim(document.bankAccountForm.vesselAccountDesc.value)))
	{

		document.bankAccountForm.vesselAccountDesc.focus();
		return(false);

	}
	//Added by David for CA #313423 ends
	else
	{
	
			return(true);
	}
	
	

  
}
function formSubmit(varAction,varPage,varModName,varSubAction){
	
	if(validateForm()){
	
		document.bankAccountForm.action = varAction;
		document.bankAccountForm.page.value = varPage;
		document.bankAccountForm.subaction.value = varSubAction;
		//document.bankAccountForm.countryValue.value = document.bankAccountForm.country.options[document.bankAccountForm.country.selectedIndex].text;
		for(i=0;i<document.bankAccountForm.bankHolidayDateList.length;i++){
			document.bankAccountForm.bankHolidayDateList.options[i].selected=true;
			document.bankAccountForm.bankHolidayRemarkList.options[i].selected=true;
			document.bankAccountForm.holidayStartHrsList.options[i].selected=true;
			document.bankAccountForm.holidayStartMinsList.options[i].selected=true;
			document.bankAccountForm.holidayEndHrsList.options[i].selected=true;
			document.bankAccountForm.holidayEndMinsList.options[i].selected=true;
		}
		document.bankAccountForm.submit();
	}
}


function naccsSearch()
{
	if (!isBlank(naccsFileGenerationForm.flightNumber,"","n"))
	{
		var vflightNumber = flightNumber.exec(naccsFileGenerationForm.flightNumber.value);
		
		if (!vflightNumber)
		{
			alert("E-3124: \u9069\u5f53\u306a\u30d5\u30e9\u30a4\u30c8\u756a\u53f7\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			return(false);
		}
	}
	
	if (isBlank(naccsFileGenerationForm.departureDate,"\u51fa\u767a\u65e5","y"))
		return(false);

	if(!validateDate(naccsFileGenerationForm.departureDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
	return(false);

	var todaysdate = new Date();
    var todaydate = strconvert(todaysdate.getYear()+"/"+(todaysdate.getMonth()+1)+"/"+todaysdate.getDate());
	var departuredate = strconvert(naccsFileGenerationForm.departureDate.value);
	if (departuredate > todaydate)
	{
		alert("E-3125: \u51fa\u767a\u65e5\u306f\u4eca\u65e5\u3088\u308a\u4ee5\u4e0b\u307e\u305f\u306f\u540c\u3058\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3060\u3059\u3002");
		return (false);
	}
	
    naccsFileGenerationForm.subaction.value = "searchFlight";
    naccsFileGenerationForm.submit();	
}

function isBlank(str1,label,prompt)
{

	if(trim(str1.value) == "")
	{
		if(prompt == "y" || prompt == "Y")
		{
			alert("E-3126: " + label + " \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			str1.focus();			
		}
		return(true);	
				
	}
	return(false);
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat == "yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag = true;
		}
		
		if(!flag)
		{
			if(prompt == "y")
			{
				alert("E-3127: " + label + "\u306f\u7121\u52b9\u3067\u3059\u3002"+ dateformat+"\u306e\u5f62\u5f0f\u3067\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				str1.focus();
				return(false);
			}
		}
		
		else
			return(true);
		
	
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <= 0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <= 0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon == 1 || mon == 3 || mon == 5 || mon == 7 || mon == 8 || mon == 10 || mon == 12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag == true && mon != 2 && day1 == 31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon == 2)  //If February
	{
		if(( ( year1%4 == 0 ) && ( year1 % 100 != 0)) ||( year1 %400 == 0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}






function trim(inputString)
{
	if (typeof inputString != "string")
	{ 
		return inputString;
	}
	var retValue = inputString;
	var ch = retValue.substring(0, 1);
	while (ch == " ")
	{
	      retValue = retValue.substring(1, retValue.length);
	      ch = retValue.substring(0, 1);
	}
	ch = retValue.substring(retValue.length-1, retValue.length);
	while (ch == " ")
	{
     		retValue = retValue.substring(0, retValue.length-1);
		 ch = retValue.substring(retValue.length-1, retValue.length);
	}
   	while (retValue.indexOf("  ") != -1)
	{
	      retValue = retValue.substring(0, retValue.indexOf("  ")) + retValue.substring(retValue.indexOf("  ")+1, retValue.length);
	      
	}
	return retValue; 
}


/*
function for converting date into string
*/

function strconvert(str1)
{
	var temp = str1.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}

/*
function for submitting & validating NACCS Submission Report
*/

function validateAndSubmit()
{

		if(naccsSubmissionReportForm.fromDate.value!="")
		{
			if(naccsSubmissionReportForm.toDate.value=="")
			{
					alert("E-3128: To\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");						
					naccsSubmissionReportForm.toDate.focus();
					return(false);
			}
		}
		if(naccsSubmissionReportForm.toDate.value!="")
		{
			if(naccsSubmissionReportForm.fromDate.value=="")
			{
					alert("E-3129: From\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");		
					naccsSubmissionReportForm.fromDate.focus();
					return(false);
			}	
		}
		
		if(naccsSubmissionReportForm.fromDate.value!="")
		{
			if(!validateDate(naccsSubmissionReportForm.fromDate,"yyyy/mm/dd","\u65e5\u4ed8","y"))
			{
					naccsSubmissionReportForm.fromDate.focus();
					return(false);
			}		
		}
		
		if(naccsSubmissionReportForm.toDate.value!="")
		{
		
			if(!validateDate(naccsSubmissionReportForm.toDate,"yyyy/mm/dd","\u65e5\u4ed8","y"))
			{
					naccsSubmissionReportForm.toDate.focus();
					return(false);
			}			
		}
		if(naccsSubmissionReportForm.toDate.value!="" && naccsSubmissionReportForm.fromDate.value!="")
		{
				
			Fromdate = strconvert(naccsSubmissionReportForm.fromDate.value);
			Todate = strconvert(naccsSubmissionReportForm.toDate.value);	
			if(Fromdate > Todate)
			{
					alert("E-3130: To\u306e\u65e5\u4ed8\u306fFrom\u306e\u65e5\u4ed8\u3068\u540c\u3058\u307e\u305f\u306f\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				naccsSubmissionReportForm.toDate.focus();
			return(false);	
			}
		}
		len=naccsSubmissionReportForm.flightNo.value;
		
		if(naccsSubmissionReportForm.flightNo.value != null && len.length >0)
		{
			var flightnumber = /^\d{1,5}$/ ;
			var flNumber=flightnumber.exec(naccsSubmissionReportForm.flightNo.value);
			if(!flNumber)
			{
				window.alert("E-3131: \u9069\u5207\u306a\u4fbf\u540d\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				naccsSubmissionReportForm.flightNo.value="";
				naccsSubmissionReportForm.flightNo.focus();
				return(false);
			}
			len=naccsSubmissionReportForm.flightNo.value;
			if(len.length < 3)
			{
					alert("E-3132: \u4fbf\u540d\u306e\u9577\u3055\u306f\uff13\u5b57\u304b\u3089\uff15\u5b57\u307e\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
					naccsSubmissionReportForm.flightNo.focus();
					return(false);
			}
			if(naccsSubmissionReportForm.airlineCode.value=="-1")
			{
				alert("E-3133: \u822a\u7a7a\u4f1a\u793e\u30b3\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				naccsSubmissionReportForm.airlineCode.focus();
				return(false);
			}	
		}
		naccsSubmissionReportForm.submit();	
}

/*
function validating NACCS Summary Report
*/


function validateNAACSSummarySubmit()
{
	if(naccsSummaryReportForm.fromDepDate.value!="")
	{
		if(naccsSummaryReportForm.toDepDate.value=="")
		{
				alert("E-3134: To\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");						
				naccsSummaryReportForm.toDepDate.focus();
				return(false);
		}
	}
	if(naccsSummaryReportForm.toDepDate.value!="")
	{
		if(naccsSummaryReportForm.fromDepDate.value=="")
		{
			alert("E-3135: From\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");		
			naccsSummaryReportForm.fromDepDate.focus();
			return(false);
		}		
	}
	if(naccsSummaryReportForm.fromDepDate.value!="")
	{
		if(!validateDate(naccsSummaryReportForm.fromDepDate,"yyyy/mm/dd","\u65e5\u4ed8","y"))
		{
			naccsSummaryReportForm.fromDepDate.focus();
			return(false);
		}		
	}
		
	if(naccsSummaryReportForm.toDepDate.value!="")
	{
		if(!validateDate(naccsSummaryReportForm.toDepDate,"yyyy/mm/dd","\u65e5\u4ed8","y"))
		{
			naccsSummaryReportForm.toDepDate.focus();
			return(false);
		}		
	}
	if(naccsSummaryReportForm.fromDepDate.value!="" && naccsSummaryReportForm.toDepDate.value!="")
	{

			Fromdate = strconvert(naccsSummaryReportForm.fromDepDate.value);
			Todate = strconvert(naccsSummaryReportForm.toDepDate.value);	
			if(Fromdate > Todate)
			{
				alert("E-3136: To\u306e\u51fa\u767a\u65e5\u306fFrom\u306e\u51fa\u767a\u65e5\u3068\u540c\u3058\u307e\u305f\u306f\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				naccsSummaryReportForm.toDepDate.focus();
				return(false);	
			}
	}
	naccsSummaryReportForm.submit();	
}


function generateNACCS(pageNumber)
{
  	var field = document.all.tags('INPUT');
	var submit = false;
	for (i = 0; i < field.length; i++) {
  	
	  	if (field[i].type =='checkbox' && field[i].checked) {
	  		submit = true;
	  	}
  	}
  	
  	if (submit) {
		naccsFileGenerationForm.action = "naccsFileGenerationAction.do?subaction=generateNACCSFile&pageNumber=" + pageNumber;
		
		//Code added to hide the Generate and Clear button once the user clicks the Generate Files button.
	    //This will avoid multiple clicks by the user.	
		naccsFileGenerationForm.generate.style.display="none";
        naccsFileGenerationForm.clear.style.display="none";
        
        if(document.getElementById("generationConfirm")!=null)
        { 
          
          document.getElementById("generationConfirm").style.display="none";
          document.getElementById("generation").style.display="";
        }
        //Code added to display the message 'NACCS File Generation in progress' 
        // when the user clicks the Generate Files button
        document.getElementById("generation").innerHTML='NACCS &#12501;&#12449;&#12452;&#12523;&#20316;&#25104;&#20013;';
		naccsFileGenerationForm.submit();
	} else {
		alert("E-3137: \u4fbf\u540d\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
	}
}

function clearNACCSFlightSearch()
{
	naccsFileGenerationForm.subaction.value = "naccsFileGenerationPage";
	naccsFileGenerationForm.submit();
}


function validateWorkingHrs(opnHr,opnMns,closeHr,closeMns)
{

	openHrs = parseInt(opnHr,10);
	openMns = parseInt(opnMns,10);
	closeHrs = parseInt(closeHr,10);
	closeMins = parseInt(closeMns,10);
	if(openHrs == closeHrs)	
	{
		if(openMns > closeMins)
		{
			alert("E-3138: To\u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			return (true);
		}
		else if(openMns == closeMins)
		{
			alert("E-3139: From\u306e\u6642\u9593\u3068To\u306e\u6642\u9593\u304c\u540c\u3058\u306b\u306a\u3089\u306a\u3044\u3088\u3046\u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			return (true);
		}
		else
		return (false);
	}
	else if(openHrs > closeHrs)
	{
		alert("E-3140: To\u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		return (true);
	}
	else
	{
		return (false);
	}
}

function validateHoilidayWorkingHrs(opnHr,opnMns,closeHr,closeMns)
{

	openHrs = parseInt(opnHr,10);
	openMns = parseInt(opnMns,10);
	closeHrs = parseInt(closeHr,10);
	closeMins = parseInt(closeMns,10);
	if(openHrs == 0 && openMns == 0 && closeHrs == 0 && closeMins == 0)
	{

		return (false);
	}
	if(openHrs == closeHrs)	
	{
		if(openMns > closeMins)
		{
			alert("E-3141: To\u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			return (true);
		}
		else if(openMns == closeMins)
		{
			alert("E-3142: From\u306e\u6642\u9593\u3068To\u306e\u6642\u9593\u304c\u540c\u3058\u306b\u306a\u3089\u306a\u3044\u3088\u3046\u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			return (true);
		}
		else
		return (false);
	}
	else if(openHrs > closeHrs)
	{
		alert("E-3143: To\u306e\u6642\u9593\u306fFrom\u306e\u6642\u9593\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
		return (true);
	}
	else
	{
		return (false);
	}
}

	
	
function validateDisableTime(form ,i)
{
	var obj;
	obj = eval(form.name+".checker"+i);
	if(obj .checked)
	{
		obj=eval(form.name+".fromHr"+i);
		obj.value="00";
		obj.disabled= true;
		obj=eval(form.name+".fromMin"+i);
		obj.value="00";
		obj.disabled= true;
		obj=eval(form.name+".toHr"+i);
		obj.value="00";
		obj.disabled= true;
		obj=eval(form.name+".toMin"+i);
		obj.value="00";
		obj.disabled= true;
	}
	else
	{
	     obj=eval(form.name+".fromHr"+i);
  	  	 obj.disabled= false;
	     obj=eval(form.name+".fromMin"+i);
		 obj.disabled= false;
		 obj=eval(form.name+".toHr"+i);
		 obj.disabled= false;
		 obj=eval(form.name+".toMin"+i);
		 obj.disabled= false;
	}

}

function selectCheckBox(form)
{
	var k;
	for(k=1;k<=7;k++)
	{
		validateDisableTime(form ,k)
	}
	form.savingAccountNum.focus();
}
function changeLanguage(page,form,languageTochange){
form.action = "./bankAction.do?subaction=changeLanguage&page="+page+"&language="+languageTochange+"&country=JP";
if(page == 'bankAccountPage'){
	for(i=0;i<document.bankAccountForm.bankHolidayDateList.length;i++){
				document.bankAccountForm.bankHolidayDateList.options[i].selected=true;
				document.bankAccountForm.bankHolidayRemarkList.options[i].selected=true;
				document.bankAccountForm.holidayStartHrsList.options[i].selected=true;
				document.bankAccountForm.holidayStartMinsList.options[i].selected=true;
				document.bankAccountForm.holidayEndHrsList.options[i].selected=true;
				document.bankAccountForm.holidayEndMinsList.options[i].selected=true;
	}
}
form.submit();
}

function postCodelookUp(form)
{

	var keycode = window.event.keyCode;
	
		if(keycode==9 && trim(form.postcodeSuff.value) != "" && trim(form.postCodePre.value) != "")
	{

		var postCodePrefValue= postcode.exec(form.postCodePre.value);
		if(!postCodePrefValue)
		{
			alert("E-3144: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			form.errorPost.value = "Prefix";
			return (false);
		}
		var postCodeSuffValue= postcode.exec(form.postcodeSuff.value);
		if(!postCodeSuffValue)
		{
			alert("E-3145: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			form.errorPost.value = "Suffix";
			return (false);
		}
		form.action= "./bankAction.do?subaction=postCodeLookup";
		form.submit();
			
	}
	
	else
	{
		return (false);
	}
}


function postCodelookUp1(form)
{

var keycode = window.event.keyCode;
if(keycode>47 && keycode <126 && form.postcodeSuff.value.length==4)	
	{
		
		var postCodePrefValue= postcode.exec(form.postCodePre.value);
		if(!postCodePrefValue)
		{
			alert("E-3146: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			form.postCodePre.select();
			form.postCodePre.focus();
			return (false);
		}
		var postCodeSuffValue= postcode.exec(form.postcodeSuff.value);
		if(!postCodeSuffValue)
		{
			alert("E-3147: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			form.postcodeSuff.select();
			form.postcodeSuff.focus();
			return (false);
		}
		form.action= "./bankAction.do?subaction=postCodeLookup";
		form.submit();
	}
	else
	{
		return (false);
	}
}

function postCodeAutoTab(form)
{
	var key =window.event.keyCode;
	
	if(key>47 && key <126 && form.postCodePre.value.length==3)	
	{
		form.postcodeSuff.select();
		form.postcodeSuff.focus();
	}
}


function holidayDateAutoTab()
{
	
	var key =window.event.keyCode;
	var id1= eval(document.all("input1"));
		
	
	if(key>47 && key <126 && id1.value.length==10)	
	{
		var id= eval(document.all("holidayStartHrs1"));
	
		id.focus();
	}
}

function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}

function validateNAACSDuplicatePaxSubmit()
{
	if(naccsDuplicatePaxReportForm.airlineCode.value=="-1")
	{
		alert("E-3133: Airline Code should not be empty.");
		naccsDuplicatePaxReportForm.airlineCode.focus();
		return(false);
	}
	if(naccsDuplicatePaxReportForm.flightNo.value=="")
	{
		alert("E-3133: Flight Number should not be empty.");
		naccsDuplicatePaxReportForm.flightNo.focus();
		return(false);
	}
	len=naccsDuplicatePaxReportForm.flightNo.value;
	
	if(naccsDuplicatePaxReportForm.flightNo.value != null && len.length >0)
	{
		var flightnumber = /^\d{1,5}$/ ;
		var flNumber=flightnumber.exec(naccsDuplicatePaxReportForm.flightNo.value);
		if(!flNumber)
		{
			window.alert("E-3131: Enter valid Flight Number.");
			naccsDuplicatePaxReportForm.flightNo.value="";
			naccsDuplicatePaxReportForm.flightNo.focus();
			return(false);
		}
		len = naccsDuplicatePaxReportForm.flightNo.value;
		if(len.length < 3)
		{
				alert("E-3132: Flight Number length should be between 3 and 5.");
				naccsDuplicatePaxReportForm.flightNo.focus();
				return(false);
		}
	
	}
	if(naccsDuplicatePaxReportForm.departureDate.value == "")
	{
			alert("E-3134: Departure date should not be empty.");						
			naccsDuplicatePaxReportForm.departureDate.focus();
			return(false);
	}
	//naccsDuplicatePaxReportForm.action= "naccsDuplicatePaxReportAction.do?subaction=searchNACCSDuplicatePaxDetails";
	naccsDuplicatePaxReportForm.submit();	
}


 function validateStampDuty(form)
 {
		if(form.location.value == "-1")
		{
			alert("E-3135 \u7121\u52b9\u306a\u4f4d\u7f6e");				
			form.location.focus();
			return;
		}        
var sellingLocation = document.getElementById('sellingLocation').innerHTML;	        
        form.action="stampDutyAction.do?subaction=getStampDuty&location="+sellingLocation;
        form.submit();
  
 }
 
//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report by 138295 starts.
  function validateAndSubmitDailyNACCSGeneration()
{

			if(dailyNACCSGenerationForm.fromDate.value=="")
			{
					alert("E-3129: From\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");		
					dailyNACCSGenerationForm.fromDate.focus();
					return(false);
			}	
		
	
			if(dailyNACCSGenerationForm.toDate.value=="")
			{
					alert("E-3128: To\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u51fa\u767a\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");						
					dailyNACCSGenerationForm.toDate.focus();
					return(false);
			}
		
		
		if(dailyNACCSGenerationForm.fromDate.value!="")
		{
			if(!validateDate(dailyNACCSGenerationForm.fromDate,"yyyy/mm/dd","\u65e5\u4ed8","y"))
			{
					dailyNACCSGenerationForm.fromDate.focus();
					return(false);
			}		
		}
		
		if(dailyNACCSGenerationForm.toDate.value!="")
		{
		
			if(!validateDate(dailyNACCSGenerationForm.toDate,"yyyy/mm/dd","\u65e5\u4ed8","y"))
			{
					dailyNACCSGenerationForm.toDate.focus();
					return(false);
			}			
		}
		if(dailyNACCSGenerationForm.toDate.value!="" && dailyNACCSGenerationForm.fromDate.value!="")
		{
				
			Fromdate = strconvert(dailyNACCSGenerationForm.fromDate.value);
			Todate = strconvert(dailyNACCSGenerationForm.toDate.value);	
			if(Fromdate > Todate)
			{
					alert("E-3130: To\u306e\u65e5\u4ed8\u306fFrom\u306e\u65e5\u4ed8\u3068\u540c\u3058\u307e\u305f\u306f\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				dailyNACCSGenerationForm.toDate.focus();
			return(false);	
			}
			
      diff= difference(Fromdate,Todate);
         if(diff+1>31){// The diff includes To date too , hence adding 1 .
			        alert("E-3150: 31 \u65E5\u4EE5\u5185\u3092\u5165\u529B\u3057\u3066\u4E0B\u3055\u3044\u3002");
				dailyNACCSGenerationForm.toDate.focus();
			return(false);	
			        }


		len=dailyNACCSGenerationForm.flightNo.value;
		
		if(dailyNACCSGenerationForm.flightNo.value != null && len.length >0)
		{
			var flightnumber = /^\d{1,5}$/ ;
			var flNumber=flightnumber.exec(dailyNACCSGenerationForm.flightNo.value);
			if(!flNumber)
			{
				window.alert("E-3131: \u9069\u5207\u306a\u4fbf\u540d\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				dailyNACCSGenerationForm.flightNo.value="";
				dailyNACCSGenerationForm.flightNo.focus();
				return(false);
			}
			len=dailyNACCSGenerationForm.flightNo.value;
			if(len.length < 3)
			{
					alert("E-3132: \u4fbf\u540d\u306e\u9577\u3055\u306f\uff13\u5b57\u304b\u3089\uff15\u5b57\u307e\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
					dailyNACCSGenerationForm.flightNo.focus();
					return(false);
			}
			if(dailyNACCSGenerationForm.airlineCode.value=="-1")
			{
				alert("E-3133: \u822a\u7a7a\u4f1a\u793e\u30b3\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				dailyNACCSGenerationForm.airlineCode.focus();
				return(false);
			}	
		}

		dailyNACCSGenerationForm.submit();	
}

}

 function difference(Fromdate,Todate)
			 {
			 
			  var one_day=1000*60*60*24; 
			
			
			        var x=Fromdate.split("/");     
			        var y=Todate.split("/");
			
			
			        var date1=new Date(x[0],(x[1]-1),x[2]);
			  
			        var date2=new Date(y[0],(y[1]-1),y[2]);
			        var month1=x[1]-1;
			        var month2=y[1]-1;
			        
			
			               
			        var diff=Math.ceil((date2.getTime()-date1.getTime())/(one_day)); 
			       return diff;
        }



//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report by 138295 ends. 
    