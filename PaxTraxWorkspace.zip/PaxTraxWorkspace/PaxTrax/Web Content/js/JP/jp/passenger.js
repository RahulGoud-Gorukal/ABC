
// passenger.js

var paxn=/^[0-9]+$/;
var nam=/^[A-Z a-z]+$/;
//var city=/^[A-Z a-z]+$/;
var tele=/^[\+\-()\d]+$/;
var passpo=/^[A-Z 0-9 a-z]+$/;
var flc=/^(\d)[A-Z]$/;
var fln=/^\d{3,5}$/;
var tacode=/^[A-Z 0-9 a-z]+$/;
var rentacar=/^[A-Z 0-9 a-z]+$/;
var tourcode = /^[A-Z 0-9 a-z]+$/;
var postcode = /^[0-9]+$/;
var tabranch = /^[A-Z 0-9 a-z]+$/;
var travelAgentWindow = null;
var country = /^[A-Z a-z]+$/;

var updatePaxWindow = null;

function insertPaxNo(sequenceId)
{
	updatePaxWindow = window.open('paxAction.do?subaction=updatePaxNo&indexId='+sequenceId, 'att', 'width=360, resizable=no, height=290,scrollbars=no');
}



function flightLookup()
{
	flightLookupWindow=open('paxAction.do?subaction=flightLookup','Flight','width=300,height=300');
	return(false);
}

function travelAgentLookup(formName,fieldName)
{
	travelAgentWindow = window.open('paxAction.do?subaction=travelAgentLookup&formName=' + formName + '&fieldName=' + fieldName,'att','width=380,resizable=no,height=290,scrollbars=no');
}


function maintenance_EnableAll()
{
	paxForm.lastName.disabled=false;
	paxForm.firstName.disabled=false;
	paxForm.postCodePrefix.disabled=false;
	paxForm.postCodeSuffix.disabled=false;
	paxForm.addressLine1.disabled=false;
	paxForm.addressLine2.disabled=false;
	paxForm.city.disabled=false;
	paxForm.country.disabled=false;
	paxForm.nationality.disabled=false;
	paxForm.departureAirlineCode.disabled=false;
	paxForm.departureFlightNumber.disabled=false;
	paxForm.arrivalAirlineCode.disabled=false;
	paxForm.arrivalFlightNumber.disabled=false;
	paxForm.departureFlightDate.disabled=false;
	paxForm.arrivalFlightDate.disabled=false;
	var tabranch = document.all('paxBean.taBranch');
	var tacode = document.all('paxBean.travelAgentCode');
	tabranch.disabled=false;
	tacode.disabled = false;
//	paxForm.tourCode.disabled = false;
//	paxForm.rentACar.disabled = false;
//	paxForm.group.disabled = false;

	paxForm.primaryPAXChechbox.disabled = false;

	if(paxForm.primaryPAXChechbox.checked)
		paxForm.primaryPAXNumber.disabled = true;
	else
		paxForm.primaryPAXNumber.disabled = false;

}


function validatePAXNumber(paxvar)
{
	var vpaxn=paxn.exec(paxvar.value);

	if(!vpaxn)
	{
		window.alert("E-2100: PAX \u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	if(!checklength(paxvar,10,"PAX \u756a\u53f7","\u6587\u5b57","y"))
		return(false);
	
	if(paxvar.value == "000000000")
	{
		alert("E-2101: \u6709\u52b9\u306a PAX \u756a\u53f7\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		paxvar.select();
		paxvar.focus();
		return(false);
	}

	return(true);

}


function isBlank(str1,label,prompt)
{
	if(str1.value=="")
	{
		if(prompt=="y" || prompt=="Y")
		{
			alert("E-2102: " + label + " \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u3002");
			str1.select();
			str1.focus();
		}

		return(true);		
	}

	return(false);
}


function checklength(str1,len,label,type,prompt)
{
	if(str1.value.length!=len)
	{
		if(prompt=="y" || prompt=="Y")
		{
			window.alert("E-2103: " + label + " \u306b\u306f" + len + "\u5b57\u306e"+type+"\u5217\u304c\u5fc5\u8981\u3067\u3059\u3002");
			str1.select();
			str1.focus();
		}
		return(false);
	}
	else
		return(true);
}


function validatePostCode(fromValidation)
{
	if(!isBlank(paxForm.postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(paxForm.postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2104: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			if(fromValidation!="lookup")
			{
				paxForm.postCodePrefix.select();
				paxForm.postCodePrefix.focus();
			}
			else
				paxForm.postcodeError.value="prefix";
				
			return(false);
		}
	}
	
	if(!isBlank(paxForm.postCodeSuffix," ","n"))
	{	
		vpostcode = postcode.exec(paxForm.postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2105: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			if(fromValidation!="lookup")
			{
				paxForm.postCodeSuffix.select();
				paxForm.postCodeSuffix.focus();
			}
			else
				paxForm.postcodeError.value="suffix";
				
			return(false);
		}
	}
	
	return(true);
}

function postCodeLookup()
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		if(!isBlank(paxForm.postCodePrefix," ","n") || !isBlank(paxForm.postCodeSuffix," ","n"))
		{
			if(validatePostCode("lookup"))
			{
				paxForm.action="paxAction.do?subaction=postCodeLookup";
				paxForm.submit();
			}
		}
	}
}

function validatePage(page, fromPage, searchPageNumber)
{
	// When the "Save" button is clicked by the user once, the save and clear buttons will be hidden. 
	// This will avoid involuntarily multiple clicks by the user.
	
	paxForm.save.style.display="none";
	paxForm.clear.style.display="none";
			
	/* Empty PaxNumber will have a value of "empty" when the paxNumber is an editable field or
	  else it has the value "label"  */
	  
	if(!(paxForm.emptyPaxNumber.value=="label"))
	{
		if(!(isBlank(paxForm.paxNumber,"","n")))
		{
			if(!validatePAXNumber(paxForm.paxNumber))
			{
				paxForm.save.style.display="";
				paxForm.clear.style.display="";
				return(false);
			}
		}
	}
	
	if(isBlank(paxForm.lastName,"\u59d3","y"))
	{
		paxForm.save.style.display="";
		paxForm.clear.style.display="";
		return(false);
	}
		
	var vnam = nam.exec(paxForm.lastName.value);
	if(!vnam)
	{
		alert("E-2106: \u59d3\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		paxForm.lastName.select();
		paxForm.lastName.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}

	if(isBlank(paxForm.firstName,"\u540d","y"))
	{
		paxForm.save.style.display="";
		paxForm.clear.style.display="";
		return(false);
	}

	vnam = nam.exec(paxForm.firstName.value);
	if(!vnam)
	{
		alert("E-2107: \u540d\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		paxForm.firstName.select();
		paxForm.firstName.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";
		return(false);
	}
	
	if(!validatePostCode())
	{
		paxForm.save.style.display="";
		paxForm.clear.style.display="";
		return(false);
	}

	/* Code added on August 12, 2005 */
	/* To mandate Address Line 1, City, Nationality, Departure Airline, Flight Number and Date */
	/* if the PAX has made a DF purchase */
	if(page=="maintain" && paxForm.dutyFreeSalePresent.value=="Y" && isBlank(paxForm.addressLine1))
	{
		alert("E-2150: \u514d\u7a0e\u54c1\u3092\u8cfc\u5165\u3059\u308b\u5834\u5408\u3001\u4f4f\u6240\u306f\u5165\u529b\u5fc5\u9808\u9805\u76ee\u3067\u3059\u3002");
		paxForm.addressLine1.select();
		paxForm.addressLine1.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}
	
	if(page=="maintain" && paxForm.dutyFreeSalePresent.value=="Y" && isBlank(paxForm.city))
	{
		alert("E-2151: \u514d\u7a0e\u54c1\u3092\u8cfc\u5165\u3059\u308b\u5834\u5408\u3001\u90fd\u5e02\u306f\u5165\u529b\u5fc5\u9808\u9805\u76ee\u3067\u3059\u3002");
		paxForm.city.select();
		paxForm.city.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}
	
	/*if(isBlank(paxForm.addressLine1,"\u4f4f\u6240 1","y"))
		return(false);

	if(isBlank(paxForm.city,"\u90fd\u5e02","y"))
		return(false);*/
	
	/*
	var vcity = city.exec(paxForm.city.value);
	if(!vcity)
	{
		alert("City can contain only alphabets");
		paxForm.city.select();
		paxForm.city.focus();
		return(false);
	}
	*/
	
	if(paxForm.country.value!="")
	{
		var vcountry = country.exec(paxForm.country.value);
		
		if(!vcountry)
		{			
			alert("E-2108: \u56fd\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.country.select();
			paxForm.country.focus();
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);	
		}
	}
		
	/* Code added on August 12, 2005 */
	if(page=="maintain" && paxForm.dutyFreeSalePresent.value=="Y" && paxForm.nationality.value=="-1")
	{
		alert("E-2152: \u514d\u7a0e\u54c1\u3092\u8cfc\u5165\u3059\u308b\u5834\u5408\u3001\u6b63\u3057\u3044\u56fd\u7c4d\u3092\u9078\u629e\u3057\u3066\u4e0b\u3055\u3044\u3002");
		paxForm.nationality.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}	
	
	/*if(!isBlank(paxForm.rentACar,"","n"))
	{
		if(paxForm.rentACar.value.length <3)
		{
			alert("E-2109: \u30ec\u30f3\u30bf\u30eb\u30ab\u30fc\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u5b57\u306e\u6587\u5b57\u5217\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			paxForm.rentACar.select();
			paxForm.rentACar.focus();
			return(false);
		}
		
		var vrentacar = rentacar.exec(paxForm.rentACar.value);
		
		if(!vrentacar)
		{
			window.alert("E-2110: \u30ec\u30f3\u30bf\u30eb\u30ab\u30fc\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.rentACar.select();
			paxForm.rentACar.focus();			
			return(false);
		}	
	}*/
	
	/* Code added on August 12, 2005 */	
	if(page=="maintain" && paxForm.dutyFreeSalePresent.value=="Y" && paxForm.departureAirlineCode.value=="-1")
	{
		alert("E-2153: \u514d\u7a0e\u54c1\u3092\u8cfc\u5165\u3059\u308b\u5834\u5408\u3001\u6b63\u3057\u3044\u51fa\u767a\u65e5\u4ed8\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		paxForm.departureAirlineCode.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}
	
	if(page=="maintain" && paxForm.dutyFreeSalePresent.value=="Y" && isBlank(paxForm.departureFlightNumber))
	{
		alert("E-2154: \u514d\u7a0e\u54c1\u3092\u8cfc\u5165\u3059\u308b\u5834\u5408\u3001\u6b63\u3057\u3044\u51fa\u767a\u30d5\u30e9\u30a4\u30c8\u60c5\u5831\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		paxForm.departureFlightNumber.select();
		paxForm.departureFlightNumber.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}

	if(paxForm.departureAirlineCode.value!="-1" || !isBlank(paxForm.departureFlightNumber," ","n"))
	{
		if(paxForm.departureAirlineCode.value=="-1")
		{
			alert("E-2111: \u9069\u5f53\u306a\u51fa\u767a\u822a\u7a7a\u4f1a\u793e\u30b3\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u4e0b\u3055\u3044\u3002");
			paxForm.departureAirlineCode.focus();	
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}

		if(isBlank(paxForm.departureFlightNumber,"\u51fa\u767a\u4fbf\u540d", "y"))
		{
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}

		var vfln=fln.exec(paxForm.departureFlightNumber.value);

		if(!vfln)
		{
			window.alert("E-2112: \u51fa\u767a\u4fbf\u540d\u3092\u6b63\u3057\u304f\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			paxForm.departureFlightNumber.select();
			paxForm.departureFlightNumber.focus();
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}
	}
	
	if(paxForm.arrivalAirlineCode.value!="-1" || !isBlank(paxForm.arrivalFlightNumber," ","n"))
	{
		if(paxForm.arrivalAirlineCode.value=="-1")  
		{
			alert("E-2113: \u9069\u5f53\u306a\u5230\u7740\u822a\u7a7a\u4f1a\u793e\u30b3\u30fc\u30c9\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			paxForm.arrivalAirlineCode.focus();
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}
		
		if(isBlank(paxForm.arrivalFlightNumber,"\u5230\u7740\u4fbf\u540d", "y"))
		{
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}
			
		vfln=fln.exec(paxForm.arrivalFlightNumber.value);
	
		if(!vfln)
		{
			window.alert("E-2114: \u5230\u7740\u4fbf\u540d\u3092\u6b63\u3057\u304f\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			paxForm.arrivalFlightNumber.select();
			paxForm.arrivalFlightNumber.focus();
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}
	}
	
	/* Code added on August 12, 2005 */
	if(page=="maintain" && paxForm.dutyFreeSalePresent.value=="Y" && isBlank(paxForm.departureFlightDate))
	{
		alert("E-2155: \u514d\u7a0e\u54c1\u3092\u8cfc\u5165\u3059\u308b\u5834\u5408\u3001\u6b63\u3057\u3044\u51fa\u767a\u65e5\u4ed8\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		paxForm.departureFlightDate.select();
		paxForm.departureFlightDate.focus();
		paxForm.save.style.display="";
		paxForm.clear.style.display="";		
		return(false);
	}	

	if(paxForm.departureAirlineCode.value!="-1" || !isBlank(paxForm.departureFlightNumber," ","n"))
	{
		
		
		if (isBlank(paxForm.departureFlightDate,"Departure flight date","y"))
		{
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}

		if(!validateDate(paxForm.departureFlightDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
		{
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}

		var today = new Date();
		var day   = today.getDate();
		var month = today.getMonth();
		month = month + 1;
		var year  = today.getYear();

		if(day<10)
			day = "0" + day;

		if(month<10)
			month = "0" + month;

		if(year<1000)
			year + 1900;	

		var todayString = year + "/" + month + "/" + day;

		if(paxForm.departureFlightDate.value<todayString)
		{
			alert("E-2115: \u51fa\u767a\u65e5\u306f\u904e\u53bb\u65e5\u3068\u306f\u306a\u3089\u306a\u3044\u3002");
			paxForm.departureFlightDate.select();
			paxForm.departureFlightDate.focus();
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}
	}
		
	if(!isBlank(paxForm.arrivalFlightDate," ","n"))
	{
		if(!validateDate(paxForm.arrivalFlightDate,"yyyy/mm/dd","\u5230\u7740\u65e5","y"))		
		{
			paxForm.save.style.display="";
			paxForm.clear.style.display="";
			return(false);
		}
	}
	
	if(paxForm.departureFlightDate.value!="" && paxForm.arrivalFlightDate.value!="" && paxForm.departureFlightDate.value<paxForm.arrivalFlightDate.value)
	{
		alert("E-2116: \u51fa\u767a\u65e5\u306f\u5230\u7740\u65e5\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
		paxForm.save.style.display="";
		paxForm.clear.style.display="";
	    return(false);
	}

	/*
	if(!isBlank(paxForm.travelAgentCode," ","n"))
	{
		if(paxForm.travelAgentCode.value.length < 5 )
		{
			alert("E-2117: \u65c5\u884c\u4ee3\u7406\u5e97\u30b3\u30fc\u30c9\u306f\uff15\u5b57\u306e\u6587\u5b57\u5217\u304c\u5fc5\u8981\u3067\u3059\u3002");
			paxForm.travelAgentCode.select();
			paxForm.travelAgentCode.focus();
			return(false);
		}
		
		var vtacode=tacode.exec(paxForm.travelAgentCode.value);

		if(!vtacode)
		{
			window.alert("E-2118: TA \u30b3\u30fc\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.travelAgentCode.select();
			paxForm.travelAgentCode.focus();
			return(false);
		}
		
		if(isBlank(paxForm.taBranch,"TA \u652f\u5e97","y"))
		{
			return(false);
		}
	}
	
	if(!isBlank(paxForm.taBranch," ","n"))
	{
		var vtabranch = tabranch.exec(paxForm.taBranch.value);
		
		if(!vtabranch)
		{
			window.alert("E-2119: TA \u652f\u5e97\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.taBranch.select();
			paxForm.taBranch.focus();
			return(false);
		}
	}
	
	if(!isBlank(paxForm.tourCode," ","n"))
	{
		var vtourcode = tourcode.exec(paxForm.tourCode.value);
		
		if(!vtourcode)
		{
			alert("E-2120: \u30c4\u30a2\u30fc\u30b3\u30fc\u30c9\u306f\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.tourCode.select();
			paxForm.tourCode.focus();
			return(false);
		}
	}*/
	
	if(paxForm.nationality.value!="-1")
		paxForm.nationalityValue.value = paxForm.nationality.options[paxForm.nationality.selectedIndex].text;
	else
		paxForm.nationalityValue.value = "";
// Added for CR611 changes on Aug 01, 2008 --  -Begin		
	if(paxForm.promotion.value!="-1")
		paxForm.promotionValue.value = paxForm.promotion.options[paxForm.promotion.selectedIndex].text;
	else
		paxForm.promotionValue.value = "";		
// Added for CR611 changes on Aug 01, 2008 --  -End		
/*	if(paxForm.group.value!="-1")
		paxForm.groupValue.value = paxForm.group.options[paxForm.group.selectedIndex].text;
	else
		paxForm.groupValue.value = "";*/
		
	if(paxForm.departureAirlineCode.value!="-1")
		paxForm.depAirlineCodeValue.value = paxForm.departureAirlineCode.options[paxForm.departureAirlineCode.selectedIndex].text;
	else
		paxForm.depAirlineCodeValue.value = "";

	if(paxForm.arrivalAirlineCode.value!="-1")
		paxForm.arrAirlineCodeValue.value = paxForm.arrivalAirlineCode.options[paxForm.arrivalAirlineCode.selectedIndex].text;
	else
		paxForm.arrAirlineCodeValue.value = "";

	if(page=="maintain" && fromPage!="-1" && searchPageNumber!="-1")
		paxForm.action = "paxAction.do?subaction=updatePAXDetails&fromPage="+fromPage+"&fromPageNumber="+searchPageNumber;
		
    if(paxForm.travelAgentCode.value=="" && paxForm.travelAgencyName.value.length>=1)
	{
	       alert("E-2117: \u6709\u52b9\u306a TA Code \u3092\u9078\u629e\u3057\u3066\u304F\u3060\u3055\u3044\u3002");
	       paxForm.save.style.display="";
		   paxForm.clear.style.display="";
		   paxForm.travelAgencyName.focus();
		   paxForm.travelAgencyName.select();
		   return(false);
	}
	paxForm.submit();
	
}

function validateDate(str1,dateformat,label,prompt)
{
	if(dateformat=="yyyy/mm/dd")
	{
		var flag = false;
		var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
		
		if(temp.length == 3 )
		{
			temp[0] = parseInt(temp[0],10); //year
			temp[1] = parseInt(temp[1],10); //month
			temp[2] = parseInt(temp[2],10); //date
	
			//Validating the date already present - Validation is done only if the three parts are numeric
			if(!isNaN(temp[0]) && !isNaN(temp[1]) && !isNaN(temp[2]) && validate_date(temp[1],temp[2],temp[0]))
				flag=true;
		}
		
		if(!flag)
		{
			if(prompt=="y")
			{
				alert("E-2121: " + label + "\u306f\u7121\u52b9\u3067\u3059\u3002"+ dateformat+"\u306e\u5f62\u5f0f\u3067\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				str1.select();
				str1.focus();
				return(false);
			}
		}
		else
			return(true);
	}
	
}

//Date Validation Function
function validate_date(mon,day1,year1)
{

	var dayflag = true;
	var leapflag = false;

	var date1 = mon + "/" + day1 +"/" + year1

	if(year1 > 2100||year1<1900)  //The range of years allowed
	{
		return false;
	}
	
	if(mon <=0 || mon > 12)  //The month cannot be <=0 and >12
	{
		return false;
	}
	
	if(day1 <=0 || day1 > 31)  //The day cannot be <=0 and >31
	{
		return false;
	}
	
	if(mon==1 || mon==3 || mon==5 || mon==7 || mon==8 || mon==10 || mon==12) // For a 31 day month set the dayflag to false 
	{
		dayflag = false;
	}
	
	if(dayflag==true && mon!=2 && day1==31) //If dayflag==true and month is not February and Days = 31 then it is an invalid date 
	{
		return false;
	}
	
	if(mon==2)  //If February
	{
		if(( ( year1%4==0 ) && ( year1 % 100 !=0)) ||( year1 %400==0)) //leap year checking
		{
		    leapflag = true;
		}
		if(leapflag == false && day1 > 28 ) //If not leap year, days cannot be >28
		{
	    		return false;
		}
	
		if(leapflag == true && day1 > 29 ) //If leap year days cannot be greater than 29
		{
	    		return false;
		}
	}

	return true; //if all validations are true , then it is a valid date
}


function clearSearchForm()
{
	document.forms[0].lastName.value = "";
	document.forms[0].firstName.value = "";
	document.forms[0].postCodePrefix.value = "";
	document.forms[0].postCodeSuffix.value = "";
	document.forms[0].departureAirlineCode.selectedIndex = 0;
	document.forms[0].departureFlightNumber.value = "";
	document.forms[0].arrivalAirlineCode.selectedIndex = 0;
	document.forms[0].arrivalFlightNumber.value = "";
	document.forms[0].departureFlightDate.value = "";
	document.forms[0].arrivalFlightDate.value = "";
	document.forms[0].travelAgentCode.value = "";
	document.forms[0].lastName.focus();																												
}


function validateSearchForm()
{
	/* Check being added to avoid the users from cliking on the search button without specifying a search
	   criteria */
	if(isBlank(document.forms[0].paxNumber,"","n") && isBlank(document.forms[0].lastName," ","n") &&
	   isBlank(document.forms[0].firstName," ","n") && isBlank(document.forms[0].postCodePrefix," ","n") && 
	   isBlank(document.forms[0].postCodeSuffix," ","n") && isBlank(document.forms[0].travelAgentCode," ","n") &&
	   document.forms[0].departureAirlineCode.value=="-1" && isBlank(document.forms[0].arrivalFlightNumber," ", "n") && 
	   document.forms[0].arrivalAirlineCode.value=="-1" && isBlank(document.forms[0].arrivalFlightNumber," ", "n") && 
	   isBlank(document.forms[0].departureFlightDate," ","n") && isBlank(document.forms[0].arrivalFlightDate," ","n"))
	{
		alert("E-2500: Please enter a search criteria");
		document.forms[0].paxNumber.focus();
		return(false);
	}
		
	if (document.forms[0].paxNumber != null)
	{
		if(!isBlank(document.forms[0].paxNumber,"","n"))
		{
			if(!validatePAXNumber(document.forms[0].paxNumber))
				return(false);
				
			//document.forms[0].action="paxAction.do?subaction=paxMaintainPageLookup&fieldName=searchPage&paxNumber="+document.forms[0].paxNumber.value;
			
				
		}
	}
		

	if(!isBlank(document.forms[0].lastName," ","n"))
	{
		var vnam = nam.exec(document.forms[0].lastName.value);
		if(!vnam)
		{
			alert("E-2122: \u59d3\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].lastName.select();
			document.forms[0].lastName.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].firstName," ","n"))
	{
		vnam = nam.exec(document.forms[0].firstName.value);
		if(!vnam)
		{
			alert("E-2123: \u540d\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].firstName.select();
			document.forms[0].firstName.focus();
			return(false);
		}	
	}
	
	if(!isBlank(document.forms[0].postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(document.forms[0].postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2124: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].postCodePrefix.select();
			document.forms[0].postCodePrefix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].postCodeSuffix," ","n"))
	{	
		vpostcode = postcode.exec(document.forms[0].postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2125: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			document.forms[0].postCodeSuffix.select();
			document.forms[0].postCodeSuffix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].travelAgentCode," ","n"))
	{
		var vtacode = tacode.exec(document.forms[0].travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2126: TA \u30b3\u30fc\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].travelAgentCode.select();
			document.forms[0].travelAgentCode.focus();
			return(false);
		}
	}
	
	if(document.forms[0].departureFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].departureFlightNumber.value))
		{
			alert("E-2127: \u51fa\u767a\u4fbf\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].departureFlightNumber.select();
			document.forms[0].departureFlightNumber.focus();
			return(false);
		}
	}
	
	if(document.forms[0].arrivalFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].arrivalFlightNumber.value))
		{
			alert("E-2128: \u5230\u7740\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].arrivalFlightNumber.select();
			document.forms[0].arrivalFlightNumber.focus();
			return(false);
		}
	}
		
	if(!isBlank(document.forms[0].departureFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].departureFlightDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
			return(false);
	}
	
	if(!isBlank(document.forms[0].arrivalFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].arrivalFlightDate,"yyyy/mm/dd","\u5230\u7740\u65e5","y"))		
			return(false);
			
       var arrflidate=strconvert(document.forms[0].arrivalFlightDate);
       var depflidate=strconvert(document.forms[0].departureFlightDate);    
     
       if(depflidate<arrflidate)
       {
           alert("E-2129: \u51fa\u767a\u65e5\u306f\u5230\u7740\u65e5\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
           document.forms[0].departureFlightDate.select();
           document.forms[0].departureFlightDate.focus();           
           return(false);
       }
    
	}
	
	paxSearchForm.submit();

}

function strconvert(str1)
{
	var temp = str1.value.split("/"); //the value in the str field is split into year, month and date
	temp[0] = parseInt(temp[0],10); //year
	temp[1] = parseInt(temp[1],10); //month
	temp[2] = parseInt(temp[2],10); //date

	var tdate = "" + temp[2];
	var tmonth = "" + temp[1];
	
	if (temp[2]<10)
		tdate = "0" + temp[2];

	if(temp[1]<10)
		tmonth = "0" + temp[1];

	return(""+ temp[0] + "/" + tmonth + "/" + tdate);
}

function clearSubmit()
{
    paxForm.paxNumber.value = "";
    paxForm.lastName.value = "";
	paxForm.firstName.value = "";
	paxForm.postCodePrefix.value = "";
	paxForm.postCodeSuffix.value = "";
	paxForm.addressLine1.value = "";
	paxForm.addressLine2.value = "";
	paxForm.city.value="";
	paxForm.country.value="";
	paxForm.nationality.selectedIndex = 0;
	paxForm.departureAirlineCode.selectedIndex = 0;
	paxForm.departureFlightNumber.value = "";
	paxForm.arrivalAirlineCode.selectedIndex = 0;
	paxForm.arrivalFlightNumber.value = "";
	paxForm.departureFlightDate.value = "";
	paxForm.arrivalFlightDate.value = "";
	paxForm.travelAgentCode.value = "";
	paxForm.rentACar.value = "";
//	paxForm.tourCode.value = "";
//	paxForm.group.selectedIndex = 0;
	paxForm.paxNumber.focus();
	paxForm.primaryPAXChechbox.checked = false;
	paxForm.primaryPAXNumber.value = "";
	paxForm.taBranch.value = "";
	
	if(document.forms[0].travelAgencyCleared.value=="N")
	{
		var oTable = eval(document.all("travelAgencyTable"));
		oTable.deleteRow(0);
		document.forms[0].travelAgencyCleared.value = "Y";
		paxForm.travelAgencySetOnBean.value="";
		document.forms[0].prevTACode.value = "";
	}
	
}


function replication()
{
    paxForm.action = "paxAction.do?subaction=replicatePax";      
}

function newPax()
{
    paxForm.action = "paxAction.do?subaction=createPaxPage";
}

function ltrim(s)
{
	return s.replace( /^\s*/, "" )
}

function rtrim(s)
{
	return s.replace( /\s*$/, "" );
}


function trim(s)
{
	return rtrim(ltrim(s));
}

function paxNumberLookup()
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		if(paxForm.paxNumber.value!="")
		{
			if(!validatePAXNumber(paxForm.paxNumber))
				return(false);
					
			paxForm.action="paxAction.do?subaction=paxMaintainPageLookup&fieldName=paxNumber";
			
			paxForm.submit();
		}
	}
	
	return(false);
}

function firstNameLookup()
{
	if(paxForm.firstName.value=="")
		paxForm.action="paxSearch.do?subaction=searchPAXPage";
	else
	{
		vnam = nam.exec(paxForm.firstName.value);
		if(!vnam)
		{
			alert("E-2130: \u540d\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.firstName.select();
			paxForm.firstName.focus();
			return(false);
		}

		paxForm.action="paxAction.do?subaction=paxMaintainPageLookup&fieldName=firstName";
	}

	paxForm.submit();	
}

function lastNameLookup()
{
	if(paxForm.lastName.value=="")
		paxForm.action="paxSearch.do?subaction=searchPAXPage";
	else
	{
		var vnam = nam.exec(paxForm.lastName.value);
		if(!vnam)
		{
			alert("E-2131: \u6027\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
			paxForm.lastName.select();
			paxForm.lastName.focus();
			return(false);
		}
	
		paxForm.action="paxAction.do?subaction=paxMaintainPageLookup&fieldName=lastName";
	}

	paxForm.submit();
}

function populateTravelAgency(travelAgency)
{
	var oTable = eval(document.all("travelAgencyTable"));
	var oRow;
	var oCell;
	
	if(document.forms[0].travelAgencyCleared.value=="N")
		oTable.deleteRow(0);	
		
	oRow = oTable.insertRow();
	oCell = oRow.insertCell();
	oCell.innerHTML = '<div class = "textfield">' + travelAgency + '</div>';
	document.forms[0].travelAgency.value = travelAgency;
	document.forms[0].validTACode.value = document.forms[0].travelAgentCode.value;
	document.forms[0].prevTACode.value = document.forms[0].travelAgentCode.value;
	document.forms[0].travelAgencyCleared.value = "N";
	paxForm.travelAgencySetOnBean.value = document.forms[0].travelAgency.value;	
}

function checkTravelAgency()
{
	if(document.forms[0].travelAgency.value!="" && document.forms[0].prevTACode.value != document.forms[0].travelAgentCode.value)
	{
		var oTable = eval(document.all("travelAgencyTable"));	
		
		if(document.forms[0].travelAgentCode.value!=document.forms[0].validTACode.value && document.forms[0].travelAgencyCleared.value=="N")
		{
			oTable.deleteRow(0);
			document.forms[0].travelAgencyCleared.value = "Y";
			paxForm.travelAgencySetOnBean.value="";
		}
		else
		{
			if(document.forms[0].travelAgencyCleared.value=="Y" && (document.forms[0].travelAgentCode.value==document.forms[0].validTACode.value))
			{
				oRow = oTable.insertRow();
				oCell = oRow.insertCell();
				oCell.innerHTML = '<div class = "textfield">' + document.forms[0].travelAgency.value + '</div>';
				document.forms[0].travelAgencyCleared.value = "N";
				paxForm.travelAgencySetOnBean.value = document.forms[0].travelAgency.value;				
			}
		}
	
		document.forms[0].prevTACode.value = document.forms[0].travelAgentCode.value;		
	}
}

function primaryFlagChecked()
{
	if(paxForm.primaryPAXChechbox.checked)
	{
		paxForm.primaryPAXNumber.value = "";
		paxForm.primaryPAXNumber.disabled = true;
		paxForm.primaryFlag.value="Y";
	}
	else
	{
		paxForm.primaryPAXNumber.disabled = false;
		paxForm.primaryFlag.value="N";			
	}
}

function outboundFlagChecked()
{
	if(paxForm.outboundPAXCheckbox.checked)
	{
		paxForm.outboundFlag.value="Y";
	}
	else
	{
		paxForm.outboundFlag.value="N";			
	}
}


function validatePAXFileUploadForm()
{
	if(paxFileUploadForm.fileType.value=="-1")
	{
		alert("E-2132: \u6709\u52b9\u306a\u30d5\u30a1\u30a4\u30eb\u30bf\u30a4\u30d7\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		paxFileUploadForm.fileType.focus();
		return(false);
	}
	
	if(paxFileUploadForm.fileType.value=="tourFile")
	{
		alert("E-2133: \u30c4\u30a2\u30fc\u30d5\u30a1\u30a4\u30eb\u306e\u30a2\u30c3\u30d7\u30ed\u30fc\u30c9\u306f\u73fe\u5728\u30b5\u30dd\u30fc\u30c8\u3055\u308c\u3066\u3044\u307e\u305b\u3093\u3002");
		paxFileUploadForm.fileType.focus();	
		return(false);
	}

	if(!checkFilesPresent())
		return(false);
	
	if(!checkFileType(paxFileUploadForm.file1,"\u30d5\u30a1\u30a4\u30eb 1")) return false;
	if(!checkFileType(paxFileUploadForm.file2,"\u30d5\u30a1\u30a4\u30eb 2")) return false;
	if(!checkFileType(paxFileUploadForm.file3,"\u30d5\u30a1\u30a4\u30eb 3")) return false;
	if(!checkFileType(paxFileUploadForm.file4,"\u30d5\u30a1\u30a4\u30eb 4")) return false;
	if(!checkFileType(paxFileUploadForm.file5,"\u30d5\u30a1\u30a4\u30eb 5")) return false;
	if(!checkFileType(paxFileUploadForm.file6,"\u30d5\u30a1\u30a4\u30eb 6")) return false;
	if(!checkFileType(paxFileUploadForm.file7,"\u30d5\u30a1\u30a4\u30eb 7")) return false;
	if(!checkFileType(paxFileUploadForm.file8,"\u30d5\u30a1\u30a4\u30eb 8")) return false;
	if(!checkFileType(paxFileUploadForm.file9,"\u30d5\u30a1\u30a4\u30eb 9")) return false;
	if(!checkFileType(paxFileUploadForm.file10,"\u30d5\u30a1\u30a4\u30eb 10")) return false;

	if(!checkFileNameLength())
		return(false);
	
	if(!checkFileRepetition())
		return(false);

	paxFileUploadForm.submit();
}

function checkFileType(file, label)
{
	var len = trim(file.value).length;
	if(len>0)
	{
		var extn = file.value.substring(len-4,len);
		if(extn!=".txt" &&  extn!=".TXT" && extn!=".csv" &&  extn!=".CSV")
		{
			alert("E-2134: " + label + " \u306f\u7121\u52b9\u3067\u3059\u3002. \u30a2\u30c3\u30d7\u30ed\u30fc\u30c9\u3055\u308c\u305f\u30d5\u30a1\u30a4\u30eb\u306f .txt \u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
			file.select();			
			file.focus();
			return(false);
		}
		else
		{
			if(file.value==".txt" || file.value==".csv" || file.value==".TXT" || file.value==".CSV")
			{
				alert("E-2135: " + label + " \u6709\u52b9\u306a\u30d5\u30a1\u30a4\u30eb\u540d\u3067\u306f\u3042\u308a\u307e\u305b\u3093\u3002");
				file.select();				
				file.focus();
				return(false);
			}
		}
		if(len > 20)
		{
		/* Commented on 20-12-2006 
			var fileName = file.value.substring(len-21,len-4);
			if(isNaN(fileName))
			{
				alert("E-2135: " + label + " \u6709\u52b9\u306a\u30d5\u30a1\u30a4\u30eb\u540d\u3092\u6301\u3063\u3066\u3044\u306a\u3044\u3002\u671f\u5f85\u3055\u308c\u305f TA \u30d5\u30a1\u30a4\u30eb\u5f62\u5f0f\u306f 'TTTYYYYMMDDhhmmss' \u3067\u3042\u308b");
				file.select();
				file.focus();
				return(false);		
			}
		}
		else
		{
			alert("E-2135: " + label + " \u6709\u52b9\u306a\u30d5\u30a1\u30a4\u30eb\u540d\u3092\u6301\u3063\u3066\u3044\u306a\u3044\u3002\u671f\u5f85\u3055\u308c\u305f TA \u30d5\u30a1\u30a4\u30eb\u5f62\u5f0f\u306f 'TTTYYYYMMDDhhmmss' \u3067\u3042\u308b");
			file.select();
			file.focus();
			return(false)
		}	
		*/
				//Modified on 20-12-2006 for 5-digit TA Code.
			
			var beginLetter=file.value.substring(0,1);
			var fileName;
							
			if(beginLetter=='N')			
				 fileName = file.value.substring(len-24,len-4);
			 else
				 fileName = file.value.substring(len-21,len-4);
			 
			
			
			if(isNaN(fileName))
			{
				alert("E-2135: " + label + " does not have a valid file name. Expected TA File format is 'TTTYYYYMMDDhhmmss' or 'NTTTTTYYYYMMDDhhmmss'");
				file.select();
				file.focus();
				return(false);		
			}
			
			
		}
		else
		{
			alert("E-2135: " + label + " does not have a valid file name. Expected TA File format is 'TTTYYYYMMDDhhmmss' or 'NTTTTTYYYYMMDDhhmmss'");
			file.select();
			file.focus();
			return(false)
		}
	
		
	}

	return(true);
}

function checkFilesPresent()
{
	if(trim(paxFileUploadForm.file1.value)=="" &&
	trim(paxFileUploadForm.file2.value)=="" &&
	trim(paxFileUploadForm.file3.value)=="" &&
	trim(paxFileUploadForm.file4.value)=="" &&
	trim(paxFileUploadForm.file5.value)=="" &&
	trim(paxFileUploadForm.file6.value)=="" &&
	trim(paxFileUploadForm.file7.value)=="" &&
	trim(paxFileUploadForm.file8.value)=="" &&
	trim(paxFileUploadForm.file9.value)=="" &&
	trim(paxFileUploadForm.file10.value)=="" )
	{
		alert("E-2136: \u30a2\u30c3\u30d7\u30ed\u30c9\u3059\u308b\u30d5\u30a1\u30a4\u30eb\u304c\u9078\u629e\u3055\u308c\u3066\u3044\u307e\u305b\u3093\u3002");
		paxFileUploadForm.file1.focus();
		return(false);
	}
	else
		return(true);
}

function checkFileRepetition()
{
	for(var i=1; i<=10; i++)
	{	
		//Code added on 2007-10-25 to fix the javascript error in the Upload PAX/Tour file screen 
		var field1 = eval("document.paxFileUploadForm.file"+i);
		
		if(trim(field1.value).length>0)
		{	
			var field1Value=field1.value;
			field1Value=field1Value.substring(field1.value.length-21,field1.value.length-4);
			
			for(var j=1; j<=10; j++)
			{
				if(j!=i)
				{
					var field2 = eval("document.paxFileUploadForm.file"+j);
					var field2Value=field2.value;
					field2Value=field2Value.substring(field2.value.length-21,field2.value.length-4);
					
					if(field1Value==field2Value)
					{
						alert("E-2137: \u30d5\u30a1\u30a4\u30eb\u540d" + field1Value + " \u306f\u4e00\u3064\u4ee5\u4e0a\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u3067\u7e70\u308a\u8fd4\u3055\u308c\u3066\u3044\u308b\u3002");
						field1.focus();
						return(false);
					}
				}
			}
		}
	}
	
	return(true);	
}

function focusOnPostCodeField()
{
	if(paxForm.postcodeError.value=="prefix")
	{
		paxForm.postCodePrefix.select();
		paxForm.postCodePrefix.focus();
	}

	if(paxForm.postcodeError.value=="suffix")
	{
		paxForm.postCodeSuffix.select();
		paxForm.postCodeSuffix.focus();
	}
	
	paxForm.postcodeError.value="";

}

function formatDateOnBlur(date1)
{
	if(date1.value!="")
	{
		if(validateDate(date1,"yyyy/mm/dd"," ","n"))
			date1.value = strconvert(date1);			
	}
}

function validateInvalidPAXSearchFormAndSubmit()
{
	if(document.forms[0].fromDate.value!="")
	{
		if(!validateDate(document.forms[0].fromDate,"yyyy/mm/dd","From \u65e5\u4ed8","y"))
		{
			document.forms[0].fromDate.select();
			document.forms[0].fromDate.focus();
			return(false);
		}
	}

	if(document.forms[0].toDate.value!="")
	{
		if(!validateDate(document.forms[0].toDate,"yyyy/mm/dd","To \u65e5\u4ed8","y"))
		{
			document.forms[0].toDate.select();
			document.forms[0].toDate.focus();
			return(false);
		}
	}
	
	if(document.forms[0].fromDate.value!="" && document.forms[0].toDate.value!="")
	{
		if(document.forms[0].fromDate.value>document.forms[0].toDate.value)
		{
			alert("E-2138: To \u306e\u65e5\u4ed8\u306f From \u306e\u65e5\u4ed8\u3068\u540c\u3058\u307e\u305f\u306f\u4ee5\u4e0a\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].toDate.select();
			document.forms[0].toDate.focus();
			return(false);
		}
	}
	
	document.forms[0].submit();
}

function checkFileNameLength()
{
	if(!fileNameLengthRestriction(paxFileUploadForm.file1)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file2)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file3)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file4)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file5)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file6)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file7)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file8)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file9)) return(false);
	if(!fileNameLengthRestriction(paxFileUploadForm.file10)) return(false);
	
	return(true);
}

function fileNameLengthRestriction(file1)
{
	if(file1.value.length>0)
	{
		var fileName = extractFileName(file1.value);
		
		if(fileName.length>30)
		{
			alert("E-2139: \u30d5\u30a1\u30a4\u30eb\u540d\u306e\u9577\u3055\u306f\uff13\uff10\u6587\u5b57\u4ee5\u4e0a\u306b\u306a\u3089\u306a\u3044\u3088\u3046\u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			file1.focus();
			return(false);
		}	
	}
	
	return(true);	
}

function extractFileName(fileName) 
{
    if (fileName.indexOf('/') > -1)
        answer = fileName.substring(fileName.lastIndexOf('/')+1,fileName.length);
    else
        answer = fileName.substring(fileName.lastIndexOf('\\')+1,fileName.length);
    
	return(answer);
}

function autoFormatDate(date1, label)
{
	var keycode = window.event.keyCode;

	if(keycode==9)
	{
		date1.value = trim(date1.value);
		
		if(!(isNaN(date1.value)))
		{
			if(date1.value.length==8)
			{
				var tempDate = date1.value;
				var year = date1.value.substring(0,4);
				var month = date1.value.substring(4,6);
				var day = date1.value.substring(6,8);
				
				var formatedDate = year + "/" + month + "/" + day;
				date1.value = formatedDate; 
								
				if(!validateDate(date1,"yyyy/mm/dd",label,"y"))
				{
					date1.value = tempDate;
					document.forms[0].dateAutoFormatError.value = "Y";
				}
				else
					date1.value = formatedDate;				
			}
		}
	}
}

function onDateAutoFormatError(date1)
{
	if(document.forms[0].dateAutoFormatError.value == "Y")
	{
		document.forms[0].dateAutoFormatError.value = "N";
		date1.select();
		date1.focus();	
	}	
}

function validateBTSearchForm()
{

	if(!isBlank(document.forms[0].lastName," ","n"))
	{
		var vnam = nam.exec(document.forms[0].lastName.value);
		if(!vnam)
		{
			alert("E-2122: \u59d3\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].lastName.select();
			document.forms[0].lastName.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].firstName," ","n"))
	{
		vnam = nam.exec(document.forms[0].firstName.value);
		if(!vnam)
		{
			alert("E-2123: \u540d\u306e\u30d5\u30a3\u30fc\u30eb\u30c9\u306b\u306f\u534a\u89d2\u82f1\u5b57\u3057\u304b\u5165\u529b\u3067\u304d\u307e\u305b\u3093\u3002");
			document.forms[0].firstName.select();
			document.forms[0].firstName.focus();
			return(false);
		}	
	}
	
	if(!isBlank(document.forms[0].postCodePrefix," ","n"))
	{
		var vpostcode = postcode.exec(document.forms[0].postCodePrefix.value);
		
		if(!vpostcode)
		{
			alert("E-2124: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].postCodePrefix.select();
			document.forms[0].postCodePrefix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].postCodeSuffix," ","n"))
	{	
		vpostcode = postcode.exec(document.forms[0].postCodeSuffix.value);
		
		if(!vpostcode)
		{
			alert("E-2125: \u90f5\u4fbf\u756a\u53f7\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			
			document.forms[0].postCodeSuffix.select();
			document.forms[0].postCodeSuffix.focus();
			return(false);
		}
	}
	
	if(!isBlank(document.forms[0].travelAgentCode," ","n"))
	{
		var vtacode = tacode.exec(document.forms[0].travelAgentCode.value);
		if(!vtacode)
		{
			alert("E-2126: TA \u30b3\u30fc\u30c9\u306b\u306f\u7279\u5225\u6587\u5b57\u306f\u4f7f\u3048\u307e\u305b\u3093\u3002");
			document.forms[0].travelAgentCode.select();
			document.forms[0].travelAgentCode.focus();
			return(false);
		}
	}
	
	if(document.forms[0].departureFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].departureFlightNumber.value))
		{
			alert("E-2127: \u51fa\u767a\u4fbf\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].departureFlightNumber.select();
			document.forms[0].departureFlightNumber.focus();
			return(false);
		}
	}
	
	if(document.forms[0].arrivalFlightNumber.value!="")
	{
		if(isNaN(document.forms[0].arrivalFlightNumber.value))
		{
			alert("E-2128: \u5230\u7740\u540d\u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
			document.forms[0].arrivalFlightNumber.select();
			document.forms[0].arrivalFlightNumber.focus();
			return(false);
		}
	}
		
	if(!isBlank(document.forms[0].departureFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].departureFlightDate,"yyyy/mm/dd","\u51fa\u767a\u65e5","y"))		
			return(false);
	}
	
	if(!isBlank(document.forms[0].arrivalFlightDate," ","n"))
	{
		if(!validateDate(document.forms[0].arrivalFlightDate,"yyyy/mm/dd","\u5230\u7740\u65e5","y"))		
			return(false);
			
       var arrflidate=strconvert(document.forms[0].arrivalFlightDate);
       var depflidate=strconvert(document.forms[0].departureFlightDate);    
     
       if(depflidate<arrflidate)
       {
           alert("E-2129: \u51fa\u767a\u65e5\u306f\u5230\u7740\u65e5\u3088\u308a\u4ee5\u4e0a\u3067\u3042\u308b\u5fc5\u8981\u304c\u3042\u308a\u307e\u3059\u3002");
           document.forms[0].departureFlightDate.select();
           document.forms[0].departureFlightDate.focus();           
           return(false);
       }
    
	}
	document.paxSearchForm.action = "btPaxSearch.do";
	document.paxSearchForm.subaction.value = "searchPAXDetails";	
	document.paxSearchForm.submit();

}



function savedetail() 
	{
		var taName = visitForm.taCode.value;
		var taBranchName = visitForm.taBranchCode.value;
		var expVisitDate = visitForm['visitBean.expVisitDate'].value;
		var expVisitTime = visitForm['visitBean.expVisitTime'].value;
		var expNoOfPax = visitForm['visitBean.expNoOfPax'];
		if(taName == ""){
			alert("E-2209: \u9069\u5207\u306a TA \u540d\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm.taCode.focus();
			return;				
		}
		else if(taBranchName == ""){
			alert("E-2210: \u9069\u5207\u306a TA \u652f\u5e97\u540d\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm.taBranchCode.focus();
			return;				
		}
		else if(expVisitDate == ""){
			alert("E-2211: \u671f\u5f85\u3059\u308b\u8a2a\u554f\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm['visitBean.expVisitDate'].focus();
			return;
		}
		else if(!validateDate(visitForm['visitBean.expVisitDate'],"yyyy/mm/dd","\u671f\u5f85\u3059\u308b\u65e5\u4ed8","y"))
			return;
		else if(expVisitTime == ""){
			alert("E-2212: \u671f\u5f85\u3059\u308b\u8a2a\u554f\u6642\u9593\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm['visitBean.expVisitTime'].focus();
			return;
		}
		else if(!checkIsDigit(expNoOfPax))
			return;
		
		if (!isBlank(visitForm.visitName,"","n"))		
		{
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.visitName.value);
			if (!vc)
			{
				alert("E-2213: \u8a2a\u554f\u540d\u306b\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
				visitForm.visitName.select();
				visitForm.visitName.focus();
				return;
			}
		}
			// Code change by selvam for ticket #257451 starts  
		if (!isBlank(visitForm.taEscort,"","n"))		
		{
			//var c = /^[A-Z a-z]+$/;;
			//var c = /^[\w\s]+$/;
        	//Added by Kumareswari for CO 6780 starts 
        	//taEscort field regular expresion is modified to allow numeric only
		    var c = /^[\d]+$/;
			var vc = c.exec(visitForm.taEscort.value);
			if (!vc)
			{
				//alert("E-2214: \u6dfb\u4e57\u54e1\u306e\u540d\u524d\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				//alert("E-2214: \u30A8\u30B9\u30B3\u30FC\u30C8\u540D\u306F\u3001\u82F1\u6570\u5B57\u306E\u307F\u5165\u529B\u53EF\u80FD\u3067\u3059");
   				alert("E-2214: \u30A8\u30B9\u30B3\u30FC\u30C8\u540D\u306F\u6570\u5024\u306E\u307F\u3092\u53D7\u3051\u5165\u308C\u308B\u3053\u3068\u304C\u3067\u304D\u307E\u3059");
				//Added by Kumareswari for CO 6780 ends
				visitForm.taEscort.select();
				visitForm.taEscort.focus();
				return;
			}
		}
		
		if (!isBlank(visitForm.taGuide,"","n"))		
		{
		//var c = /^[A-Z a-z]+$/;;
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.taGuide.value);
			if (!vc)
			{
				//alert("E-2215: \u30c4\u30a2\u30fc\u30ac\u30a4\u30c9\u540d\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				alert("E-2215: \u30AC\u30A4\u30C9\u540D\u306F\u3001\u82F1\u6570\u5B57\u306E\u307F\u5165\u529B\u53EF\u80FD\u3067\u3059");
				visitForm.taGuide.select();
				visitForm.taGuide.focus();
				return;
			}
		}
			// Code change by selvam for ticket #257451 ends  
		if (!isBlank(visitForm.taRemarks,"","n"))		
		{
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.taRemarks.value);
			if (!vc)
			{
				alert("E-2216: \u5099\u8003\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				visitForm.taRemarks.select();
				visitForm.taRemarks.focus();
				return;
			}
		}	
		visitForm.subaction.value="saveVisitDetails";
		visitForm.submit();
	}
	function savereplicatedetail(status,page) 
	{
			if (window.confirm("E-5217: \u8907\u5199\u3057\u307e\u3059\u304b\uff1f ?"))
			{
				visitForm.targetpage.value="replicate";
				document.visitForm.action="visitAction.do?subaction=saveVisitDetails";
				document.visitForm.submit();
			}
	}	
	
function checkIsDigit(str1)
{
	var num=/^[0-9]+$/;
	var vnum = "a";
	if(str1.value != ""){
	//alert(str1.value);
	vnum = num.exec(str1.value);
	}
	else{
		alert("E-2140: \u671f\u5f85\u3059\u308b Pax \u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		visitForm['visitBean.expNoOfPax'].focus();
		return(false);
	}
	//alert(vnum);
	if(!vnum)
	{
		alert("E-2141: \u671f\u5f85\u3059\u308b Pax \u306b\u306f\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		visitForm['visitBean.expNoOfPax'].select();
		visitForm['visitBean.expNoOfPax'].focus();
		return(false);
	}
	else
		return(true);
}
//added for CR695 on 08-oct-2008 "visited" argument in updatevisitdetail()
	function updatevisitdetail(visited) 
	{
		var expNoOfPax = visitForm.expNoOfPax;
		var taName = visitForm['visitBean.taCode'].value;
		var taBranchName = visitForm['visitBean.taBranchCode'].value;
		
		//added for CR695 
		var actNoOfPax = visitForm.actNoOfPax;		
				
		if(taName == "")
		{
			alert("E-2209: \u9069\u5207\u306a TA \u540d\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm.taCode.focus();
			return;				
		}
		
		if(taBranchName == "")
		{
			alert("E-2210: \u9069\u5207\u306a TA \u652f\u5e97\u540d\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm.taBranchCode.focus();
			return;				
		}
			//added for CR695 on 06-oct 2008 begin
		if(visited=="Y" && visitForm.actVisitTime.value == "" )
			{
				alert("E-2212: \u671f\u5f85\u3059\u308b\u8a2a\u554f\u6642\u9593\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				visitForm.actVisitTime.focus();
				return;
			}
		 //added for CR695 on 06-oct 2008 end 
		
		if (!isBlank(visitForm.visitName,"","n"))		
		{
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.visitName.value);
			if (!vc)
			{
				alert("E-2213: \u8a2a\u554f\u540d\u306b\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
				visitForm.visitName.select();
				visitForm.visitName.focus();
				return;
			}
		}
			// Code change by selvam for ticket #257451 starts  
		if (!isBlank(visitForm.taEscort,"","n"))		
		{
		//var c = /^[A-Z a-z]+$/;;
		//var c = /^[\w\s]+$/;
		 //Added by Kumareswari for CO 6780 starts 
		    var c = /^[\d]+$/;
			var vc = c.exec(visitForm.taEscort.value);
			if (!vc)
			{
				//alert("E-2214: \u6dfb\u4e57\u54e1\u306e\u540d\u524d\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				//alert("E-2214: \u30A8\u30B9\u30B3\u30FC\u30C8\u540D\u306F\u3001\u82F1\u6570\u5B57\u306E\u307F\u5165\u529B\u53EF\u80FD\u3067\u3059");
 				alert("E-2214: \u30A8\u30B9\u30B3\u30FC\u30C8\u540D\u306F\u6570\u5024\u306E\u307F\u3092\u53D7\u3051\u5165\u308C\u308B\u3053\u3068\u304C\u3067\u304D\u307E\u3059");
			     //Added by Kumareswari for CO 6780 ends
				visitForm.taEscort.select();
				visitForm.taEscort.focus();
				return;
			}
		}
		
		if (!isBlank(visitForm.taGuide,"","n"))		
		{
			//var c = /^[A-Z a-z]+$/;;
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.taGuide.value);
			if (!vc)
			{
				//alert("E-2215: \u30c4\u30a2\u30fc\u30ac\u30a4\u30c9\u540d\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				alert("E-2215: \u30AC\u30A4\u30C9\u540D\u306F\u3001\u82F1\u6570\u5B57\u306E\u307F\u5165\u529B\u53EF\u80FD\u3067\u3059");
				visitForm.taGuide.select();
				visitForm.taGuide.focus();
				return;
			}
		}
			// Code change by selvam for ticket #257451 ends
		if (!isBlank(visitForm.taRemarks,"","n"))		
		{
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.taRemarks.value);
			if (!vc)
			{
				alert("E-2216: \u5099\u8003\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				visitForm.taRemarks.select();
				visitForm.taRemarks.focus();
				return;
			}
		}
		
		if (expNoOfPax != null)
		{
			if (isBlank(visitForm.expVisitDate,"\u671f\u5f85\u8a2a\u554f\u65e5","y"))
				return;

			if(!validateDate(visitForm.expVisitDate,"yyyy/mm/dd","\u671f\u5f85\u8a2a\u554f\u65e5","y"))
				return;
	
			if(visitForm.expVisitTime.value == "")
			{
				alert("E-2212: \u671f\u5f85\u3059\u308b\u8a2a\u554f\u6642\u9593\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
				visitForm.expVisitTime.focus();
				return;
			}
		
			if (isBlank(expNoOfPax,"\u671f\u5f85 PAX \u756a\u53f7","y"))
				return;

			if(!checkIsDigitAct(expNoOfPax))
				return;
				
			if (!isBlank(visitForm.visitName,"","n"))		
			{
				var c = /^[\w\s]+$/;
				var vc = c.exec(visitForm.visitName.value);
				if (!vc)
				{
					alert("E-2213: \u8a2a\u554f\u540d\u306b\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
					visitForm.visitName.select();
					visitForm.visitName.focus();
					return;
				}
			}
				
			if (parseInt(expNoOfPax.value) < parseInt(visitForm.totalRecords.value))
			{
				alert("E-2142: \u95a2\u9023\u3055\u308c\u3066\u3044\u308b\u4e57\u5ba2\u306e\u5b9f\u969b\u6570\u306f "+visitForm.totalRecords.value+"\u3067\u3059\u3002\u671f\u5f85\u3059\u308b Pax \u6570\u306f\u8a2a\u554f\u3068\u95a2\u9023\u3055\u308c\u3066\u3044\u308b\u4e57\u5ba2\u6570\u4ee5\u4e0a\u307e\u305f\u306f\u540c\u3058\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				expNoOfPax.select();
				expNoOfPax.focus();
				return;
			}
		}
		
		//added for CR695 begin on 29th oct 2008
		if(visited=="Y" )
		{
			if ((actNoOfPax != null) && isBlank(actNoOfPax,"\u5b9f PAX \u756a\u53f7","y"))
			return;
		    
			var actPax = /^\d+$/;
			var act = actPax.exec(actNoOfPax.value);
			if (!act)
			{
				alert("E-5133: PAX \u306f\u6570\u5b57\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				actNoOfPax.select();
				actNoOfPax.focus();
				return;
			}		
			
		    if ((actNoOfPax != null) && parseInt(visitForm.expPax.value) < parseInt(actNoOfPax.value))
			{
				alert("E-5134: \u5b9f\u969b\u306e Pax \u6570\u306f\u671f\u5f85\u3059\u308b Pax \u6570\u4ee5\u4e0b\u307e\u305f\u306f\u540c\u3058\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				actNoOfPax.select();
				actNoOfPax.focus();
				return;
			}
			if ((actNoOfPax != null) && parseInt(actNoOfPax.value) < parseInt(visitForm.totalRecords.value))
			{
				alert("E-2144: \u95a2\u9023\u3055\u308c\u3066\u3044\u308b\u4e57\u5ba2\u306e\u5b9f\u969b\u6570\u306f "+visitForm.totalRecords.value+"\u3067\u3059\u3002\u5b9f\u969b Pax \u6570\u306f\u8a2a\u554f\u3068\u95a2\u9023\u3055\u308c\u3066\u3044\u308b\u4e57\u5ba2\u6570\u4ee5\u4e0a\u307e\u305f\u306f\u540c\u3058\u3067\u3042\u308b\u3053\u3068\u304c\u5fc5\u8981\u3067\u3059\u3002");
				actNoOfPax.select();
				actNoOfPax.focus();
				return;
			}
			
		}
		//added for CR695 end		
		visitForm.subaction.value="saveMaintainDetails";
		visitForm.submit();
	}
	
	function updatereplicatevisitdetail() 
	{
		
		var expNoOfPax = visitForm.expNoOfPax;
		var visitName = visitForm['visitBean.visitName'].value;
		var expVisitDate = visitForm['visitBean.expVisitDate'].value;
		var expVisitTime = visitForm['visitBean.expVisitTime'].value;
		var expNoOfPax = visitForm['visitBean.expNoOfPax'];
		var taGuide = visitForm['visitBean.taGuide'].value;
		var taEscort = visitForm['visitBean.taEscort'].value;
		var taRemarks = visitForm['visitBean.taRemarks'].value;
		
		if(expVisitDate == ""){
			alert("E-2211: \u671f\u5f85\u3059\u308b\u8a2a\u554f\u65e5\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm['visitBean.expVisitDate'].focus();
			return;
		}
		
		if(!validateDate(visitForm['visitBean.expVisitDate'],"yyyy/mm/dd","\u671f\u5f85\u3059\u308b\u65e5\u4ed8","y"))
			return;
			
		if(expVisitTime == ""){
			alert("E-2212: \u671f\u5f85\u3059\u308b\u8a2a\u554f\u6642\u9593\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
			visitForm['visitBean.expVisitTime'].focus();
			return;
		}
		
		if(!checkIsDigit(expNoOfPax))
			return;
							
		if (!isBlank(visitForm.visitName,"","n"))		
		{
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.visitName.value);
			if (!vc)
			{
				alert("E-2213: \u8a2a\u554f\u540d\u306b\u306f\u82f1\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
				visitForm.visitName.select();
				visitForm.visitName.focus();
				return;
			}
		}
		// Code change by selvam for ticket #257451 starts  
		if (!isBlank(visitForm.taEscort,"","n"))		
		{
			//var c = /^[A-Z a-z]+$/;;
			//var c = /^[\w\s]+$/;
		    //Added by Kumareswari for CO 6780 starts 
		    var c = /^[\d]+$/;
			var vc = c.exec(visitForm.taEscort.value);
			if (!vc)
			{
				//alert("E-2214: \u6dfb\u4e57\u54e1\u306e\u540d\u524d\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				//alert("E-2214: \u30A8\u30B9\u30B3\u30FC\u30C8\u540D\u306F\u3001\u82F1\u6570\u5B57\u306E\u307F\u5165\u529B\u53EF\u80FD\u3067\u3059");
				alert("E-2214: \u30A8\u30B9\u30B3\u30FC\u30C8\u540D\u306F\u6570\u5024\u306E\u307F\u3092\u53D7\u3051\u5165\u308C\u308B\u3053\u3068\u304C\u3067\u304D\u307E\u3059");
			     //Added by Kumareswari for CO 6780 ends
				visitForm.taEscort.select();
				visitForm.taEscort.focus();
				return;
			}
		}
		
		if (!isBlank(visitForm.taGuide,"","n"))		
		{
			//var c = /^[A-Z a-z]+$/;;
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.taGuide.value);
			if (!vc)
			{
			//alert("E-2215: \u30c4\u30a2\u30fc\u30ac\u30a4\u30c9\u540d\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				alert("E-2215: \u30AC\u30A4\u30C9\u540D\u306F\u3001\u82F1\u6570\u5B57\u306E\u307F\u5165\u529B\u53EF\u80FD\u3067\u3059");
				visitForm.taGuide.select();
				visitForm.taGuide.focus();
				return;
			}
		}
		// Code change by selvam for ticket #257451 ends  
		if (!isBlank(visitForm.taRemarks,"","n"))		
		{
			var c = /^[\w\s]+$/;
			var vc = c.exec(visitForm.taRemarks.value);
			if (!vc)
			{
				alert("E-2216: \u5099\u8003\u306f\u82f1\u5b57\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044");
				visitForm.taRemarks.select();
				visitForm.taRemarks.focus();
				return;
			}
		}
		visitForm.subaction.value="saveMaintainDetails";
		visitForm.submit();
	}
	


function checkIsDigitAct(str1)
{
	var num=/^[0-9]+$/;
	var vnum = "a";
	if(str1.value != ""){
	vnum = num.exec(str1.value);
	}
	if(!vnum)
	{
		alert("E-2141: \u671f\u5f85\u3059\u308b Pax \u306b\u306f\u6570\u5b57\u3057\u304b\u4f7f\u3048\u307e\u305b\u3093\u3002");
		visitForm.expNoOfPax.select();
		visitForm.expNoOfPax.focus();
		return(false);
	}
	else
		return(true);
}

function addPaxToVisit(url)
{
	var c = false;
	var len = paxSearchForm.addPax.length;
	if (len == null)
	{
		if (paxSearchForm.addPax.checked)
			c = true;
	}
	else
	{
		for (var i = 0;i < len;i++)
		{
			if (paxSearchForm.addPax[i].checked)
			{
				c= true;
				break;
			}
				
		}
	}
	
	if (!c)
	{
		alert("E-2144: \u8a2a\u554f\u306b\u8ffd\u52a0\u3059\u308b PAX \u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
		return;
	}
	paxSearchForm.action = url;
	paxSearchForm.submit();
}

function deleteVisitDetail()
{
    if(window.confirm("E-2130: \u524a\u9664\u3057\u307e\u3059\u304b\u3002 ?"))
    {
        document.visitForm.action="visitAction.do?subaction=deleteVisitDetails";
        document.visitForm.submit();
    }
}

function getMatchingTA(formName,taName,taCode)
{
	var vtourcode = tourcode.exec(paxForm.travelAgencyName.value);
	       		
	if(!vtourcode && !paxForm.travelAgencyName.value=="")
	{
		alert("E-2120: TA \u30b3\u30fc\u30c9\u306f\u82f1\u6570\u5b57\u306e\u5024\u3060\u3051\u3092\u542b\u3080\u3079\u304d\u3067\u3059\u3002");
	}  
	else
	{
		paxForm.action="paxAction.do?subaction=getMatchingTA&formName="+ formName +"&taName="+ taName +"&taCode=" +taCode;
		paxForm.submit();  
	}   
}

function checkTaName()
{ 
	var taName=paxForm.travelAgencyName.value;
	var hiddenTaName=paxForm.travelAgencySetOnBean.value;
	  
	if(taName.toUpperCase()!=hiddenTaName.toUpperCase())
	{
		if(!paxForm.travelAgentCode.value=="")
		{
			document.getElementById("taBranchTD").innerHTML='<select name="paxBean.taBranch" class="textfield" id="taBranch"><option value="-1">--Select--</option></select>';
		}   
		
		paxForm.travelAgentCode.value=""; 
		paxForm.travelAgentCodeSetOnBean.value="";
	}

}