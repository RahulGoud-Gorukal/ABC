package com.dfs.paxtrax.passenger.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.util.XmlUtil;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 *
 * The passenger value object
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created
 */
public class PAXBean extends PaxTraxValueObject implements Cloneable {

	//Used in CommTrax
	//Holds add Pax
	private String addPax = "N";

	//PaxTrax
	private AdditionalPAX additionalPAX =null;
	/* The PAX Number */
	private String paxNumber = null;

	/* Passport number */
	private String passportNumber = null;

	/* First name */
	private String firstName = null;

	/* Last name */
	private String lastName = null;

	/* The Address Details Bean */

	private AddressBean address = null;

	/* The Telephone Details Bean */
	private TelephoneNumberBean phone = null;

	/* The arrival Flight Details bean */
	private FlightDetailsBean arrivalFlightDetails = null;

	/* The Departure Flight Details Bean */
	private FlightDetailsBean departureFlightDetails = null;

	//TA Branch Name field.
	private String taBranchName = null;

	/* The Original Departure Flight Details  - if flight has been rescheduled*/
	private FlightDetailsBean originalDepartureFlightDetails = null;

	/* The action to be taken for the customer record*/
	private String action = null;

	/* Travel Agent Code */
	private String travelAgentCode = null;

	//Travel Agnecy Name
	private String travelAgencyName = null;

	//Tour Code
	private String tourCode = null;

	//The Group Code
	private String group = null;

	//The Group Reference ID
	private String groupRefId = null;

	//The Group Value
	private String groupValue = null;

	//The Nationality Code
	private String nationality = null;

	//The Nationality Reference ID
	private String nationalityRefId = null;

	//The Nationality Value
	private String nationalityValue = null;

	//The TA File Uploaded Date
	private String uploadDate = null;

	//Rent A Car
	private String rentACar = null;

	//The PAX Sequence ID
	private String paxSequenceId = null;

	//The Location from which the Lookup request has come
	private String location = null;

	// added for CR1832 by shruthi
	//The terminal from where the request has come
	private String terminal = null;

	//Should Cut Off Time Validation be done
	private String validate = null;

	//TA Branch field.
	private String taBranch = null;

	//Primary Flag
	private String primaryFlag = null;

	private String outboundFlag = null;

	//Primary PAX Sequence ID
	private String primaryPAXSeqId = null;

	private String primaryPaxLastName =null;
	private String primaryPaxFirstName =null;


	//Primary PAX Number
	private String primaryPAXNumber = null;

	//Cut Off Time
	private String cutOffTime = null;

	//Exception list to be given as a part of the response to Triversity
	ArrayList exceptionList = null;

	//This boolean value will be used to identify a request from TE POS
	boolean fromTEPOS = false;

	boolean autoPax = false;

	private double salesDutyFreeTotal;

	// This replaces selling location for pax related messages.
	private String reportGroupId;

	private boolean lookUpTimedOut = false;

	//This field holds the ID of the person who created the PAX
	private String createdBy = null;

	//This field holds the date on which the record was created
	private String createdDate = null;

	//This field holds the ID of the person who modified the PAX
	private String lastModifiedBy = null;

	//This holds the date on which the record was last Modified
	private String lastModifiedDate = null;

//	Added for CR611 changes on Jul 30, 2008 --Begin
	private String promotionCode = null;

	private String promotionValue = null;
	private String promotionRefId = null;
//	Added for CR611 changes on Jul 30, 2008 --End

	/**
	 * Returns the action.
	 * @return String
	 */
	public String getAction()
	{
		return action;
	}

	/**
	 * Returns the address.
	 * @return AddressBean
	 */
	public AddressBean getAddress()
	{
		return address;
	}

	/**
	 * Returns the arrivalFlightDetails.
	 * @return FlightDetailsBean
	 */
	public FlightDetailsBean getArrivalFlightDetails()
	{
		return arrivalFlightDetails;
	}

	/**
	 * Returns the cutOffTime.
	 * @return String
	 */
	public String getCutOffTime()
	{
		return cutOffTime;
	}

	/**
	 * Returns the departureFlightDetails.
	 * @return FlightDetailsBean
	 */
	public FlightDetailsBean getDepartureFlightDetails()
	{
		return departureFlightDetails;
	}

	/**
	 * Returns the exceptionList.
	 * @return ArrayList
	 */
	public ArrayList getExceptionList()
	{
		return exceptionList;
	}

	/**
	 * Returns the firstName.
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Returns the group.
	 * @return String
	 */
	public String getGroup()
	{
		return group;
	}

	/**
	 * Returns the groupRefId.
	 * @return String
	 */
	public String getGroupRefId()
	{
		return groupRefId;
	}

	/**
	 * Returns the groupValue.
	 * @return String
	 */
	public String getGroupValue()
	{
		return groupValue;
	}

	/**
	 * Returns the lastName.
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Returns the location.
	 * @return String
	 */
	public String getLocation()
	{
		return location;
	}

	//added for CR1832 by shruthi
	
	/**
	 * Returns the terminal.
	 * @return String
	 */
	public String getTerminal()
	{
		return terminal;
	}

	/**
	 * Returns the nationality.
	 * @return String
	 */
	public String getNationality()
	{
		return nationality;
	}

	/**
	 * Returns the nationalityRefId.
	 * @return String
	 */
	public String getNationalityRefId()
	{
		return nationalityRefId;
	}

	/**
	 * Returns the nationalityValue.
	 * @return String
	 */
	public String getNationalityValue()
	{
		return nationalityValue;
	}

	/**
	 * Returns the originalDepartureFlightDetails.
	 * @return FlightDetailsBean
	 */
	public FlightDetailsBean getOriginalDepartureFlightDetails()
	{
		return originalDepartureFlightDetails;
	}

	/**
	 * Returns the passportNumber.
	 * @return String
	 */
	public String getPassportNumber()
	{
		return passportNumber;
	}

	/**
	 * Returns the paxNumber.
	 * @return String
	 */
	public String getPaxNumber()
	{
		return paxNumber;
	}

	/**
	 * Returns the paxSequenceId.
	 * @return String
	 */
	public String getPaxSequenceId()
	{
		return paxSequenceId;
	}

	/**
	 * Returns the phone.
	 * @return TelephoneNumberBean
	 */
	public TelephoneNumberBean getPhone()
	{
		return phone;
	}

	/**
	 * Returns the primaryFlag.
	 * @return String
	 */
	public String getPrimaryFlag()
	{
		return primaryFlag;
	}

	/**
	 * Returns the primaryPAXNumber.
	 * @return String
	 */
	public String getPrimaryPAXNumber()
	{
		return primaryPAXNumber;
	}

	/**
	 * Returns the primaryPAXSeqId.
	 * @return String
	 */
	public String getPrimaryPAXSeqId()
	{
		return primaryPAXSeqId;
	}

	/**
	 * Returns the rentACar.
	 * @return String
	 */
	public String getRentACar()
	{
		return rentACar;
	}

	/**
	 * Returns the taBranch.
	 * @return String
	 */
	public String getTaBranch()
	{
		return taBranch;
	}

	/**
	 * Returns the tourCode.
	 * @return String
	 */
	public String getTourCode()
	{
		return tourCode;
	}

	/**
	 * Returns the travelAgencyName.
	 * @return String
	 */
	public String getTravelAgencyName()
	{
		return travelAgencyName;
	}

	/**
	 * Returns the travelAgentCode.
	 * @return String
	 */
	public String getTravelAgentCode()
	{
		return travelAgentCode;
	}

	/**
	 * Returns the uploadDate.
	 * @return String
	 */
	public String getUploadDate()
	{
		return uploadDate;
	}

	/**
	 * Returns the validate.
	 * @return String
	 */
	public String getValidate()
	{
		return validate;
	}

	/**
	 * Sets the action.
	 * @param action The action to set
	 */
	public void setAction(String action)
	{
		this.action = action;
	}

	/**
	 * Sets the address.
	 * @param address The address to set
	 */
	public void setAddress(AddressBean address)
	{
		this.address = address;
	}

	/**
	 * Sets the arrivalFlightDetails.
	 * @param arrivalFlightDetails The arrivalFlightDetails to set
	 */
	public void setArrivalFlightDetails(FlightDetailsBean arrivalFlightDetails)
	{
		this.arrivalFlightDetails = arrivalFlightDetails;
	}

	/**
	 * Sets the cutOffTime.
	 * @param cutOffTime The cutOffTime to set
	 */
	public void setCutOffTime(String cutOffTime)
	{
		this.cutOffTime = cutOffTime;
	}

	/**
	 * Sets the departureFlightDetails.
	 * @param departureFlightDetails The departureFlightDetails to set
	 */
	public void setDepartureFlightDetails(FlightDetailsBean departureFlightDetails)
	{
		this.departureFlightDetails = departureFlightDetails;
	}

	/**
	 * Sets the exceptionList.
	 * @param exceptionList The exceptionList to set
	 */
	public void setExceptionList(ArrayList exceptionList)
	{
		this.exceptionList = exceptionList;
	}

	/**
	 * Sets the firstName.
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Sets the group.
	 * @param group The group to set
	 */
	public void setGroup(String group)
	{
		this.group = group;
	}

	/**
	 * Sets the groupRefId.
	 * @param groupRefId The groupRefId to set
	 */
	public void setGroupRefId(String groupRefId)
	{
		this.groupRefId = groupRefId;
	}

	/**
	 * Sets the groupValue.
	 * @param groupValue The groupValue to set
	 */
	public void setGroupValue(String groupValue)
	{
		this.groupValue = groupValue;
	}

	/**
	 * Sets the lastName.
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Sets the location.
	 * @param location The location to set
	 */
	public void setLocation(String location)
	{
		this.location = location;
	}
	
	// added for CR1832 by shruthi
	/**
	 * Sets the terminal.
	 * @param terminal The terminal to set
	 */
	public void setTerminal(String terminal)
	{
		this.terminal = terminal;
	}

	/**
	 * Sets the nationality.
	 * @param nationality The nationality to set
	 */
	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	/**
	 * Sets the nationalityRefId.
	 * @param nationalityRefId The nationalityRefId to set
	 */
	public void setNationalityRefId(String nationalityRefId)
	{
		this.nationalityRefId = nationalityRefId;
	}

	/**
	 * Sets the nationalityValue.
	 * @param nationalityValue The nationalityValue to set
	 */
	public void setNationalityValue(String nationalityValue)
	{
		this.nationalityValue = nationalityValue;
	}

	/**
	 * Sets the originalDepartureFlightDetails.
	 * @param originalDepartureFlightDetails The originalDepartureFlightDetails to set
	 */
	public void setOriginalDepartureFlightDetails(FlightDetailsBean originalDepartureFlightDetails)
	{
		this.originalDepartureFlightDetails = originalDepartureFlightDetails;
	}

	/**
	 * Sets the passportNumber.
	 * @param passportNumber The passportNumber to set
	 */
	public void setPassportNumber(String passportNumber)
	{
		this.passportNumber = passportNumber;
	}

	/**
	 * Sets the paxNumber.
	 * @param paxNumber The paxNumber to set
	 */
	public void setPaxNumber(String paxNumber)
	{
		this.paxNumber = paxNumber;
	}

	/**
	 * Sets the paxSequenceId.
	 * @param paxSequenceId The paxSequenceId to set
	 */
	public void setPaxSequenceId(String paxSequenceId)
	{
		this.paxSequenceId = paxSequenceId;
	}

	/**
	 * Sets the phone.
	 * @param phone The phone to set
	 */
	public void setPhone(TelephoneNumberBean phone)
	{
		this.phone = phone;
	}

	/**
	 * Sets the primaryFlag.
	 * @param primaryFlag The primaryFlag to set
	 */
	public void setPrimaryFlag(String primaryFlag)
	{
		this.primaryFlag = primaryFlag;
	}

	/**
	 * Sets the primaryPAXNumber.
	 * @param primaryPAXNumber The primaryPAXNumber to set
	 */
	public void setPrimaryPAXNumber(String primaryPAXNumber)
	{
		this.primaryPAXNumber = primaryPAXNumber;
	}

	/**
	 * Sets the primaryPAXSeqId.
	 * @param primaryPAXSeqId The primaryPAXSeqId to set
	 */
	public void setPrimaryPAXSeqId(String primaryPAXSeqId)
	{
		this.primaryPAXSeqId = primaryPAXSeqId;
	}

	/**
	 * Sets the rentACar.
	 * @param rentACar The rentACar to set
	 */
	public void setRentACar(String rentACar)
	{
		this.rentACar = rentACar;
	}

	/**
	 * Sets the taBranch.
	 * @param taBranch The taBranch to set
	 */
	public void setTaBranch(String taBranch)
	{
		this.taBranch = taBranch;
	}

	/**
	 * Sets the tourCode.
	 * @param tourCode The tourCode to set
	 */
	public void setTourCode(String tourCode)
	{
		this.tourCode = tourCode;
	}

	/**
	 * Sets the travelAgencyName.
	 * @param travelAgencyName The travelAgencyName to set
	 */
	public void setTravelAgencyName(String travelAgencyName)
	{
		this.travelAgencyName = travelAgencyName;
	}

	/**
	 * Sets the travelAgentCode.
	 * @param travelAgentCode The travelAgentCode to set
	 */
	public void setTravelAgentCode(String travelAgentCode)
	{
		this.travelAgentCode = travelAgentCode;
	}

	/**
	 * Sets the uploadDate.
	 * @param uploadDate The uploadDate to set
	 */
	public void setUploadDate(String uploadDate)
	{
		this.uploadDate = uploadDate;
	}

	/**
	 * Sets the validate.
	 * @param validate The validate to set
	 */
	public void setValidate(String validate)
	{
		this.validate = validate;
	}

	/**
	 * Method setValidate.
	 * @param validate
	 */
	public void encodeData(){

		XmlUtil xmlUtil = new XmlUtil();

		this.firstName = xmlUtil.encodeCharacterData(firstName);
		this.lastName = xmlUtil.encodeCharacterData(lastName);
		this.nationalityValue = xmlUtil.encodeCharacterData(nationalityValue);
		this.travelAgencyName = xmlUtil.encodeCharacterData(travelAgencyName);

		if(this.address !=null)
		address.encodeData();


	}



	public String toString(){

		StringBuffer buffer = new StringBuffer();
		buffer.append("\n    **************  PAXBean Values   ***********");
		buffer.append("\n    First Name              :        "+this.firstName);
		buffer.append("\n    Last Name               :        "+this.lastName);
		buffer.append("\n    Pax Number              :        "+this.paxNumber);
		buffer.append("\n    Nationality             :        "+this.nationalityValue);
		buffer.append("\n    Passport Number         :        "+this.passportNumber);
		buffer.append("\n    Action                  :        "+this.action);
		buffer.append("\n    TravelAgentCode         :        "+this.travelAgentCode);
		buffer.append("\n    TravelAgencyName        :        "+this.travelAgencyName);
		buffer.append("\n    TourCode                :        "+this.travelAgencyName);
		buffer.append("\n    TA Branch               :        "+this.taBranch);
		buffer.append("\n    Pax SeqId               :        "+this.primaryPAXSeqId);
		buffer.append("\n    ********************************************\n");

		if(this.address!=null)
			buffer.append(address.toString());

		if(departureFlightDetails!=null)
			buffer.append(departureFlightDetails.toString());

		if(arrivalFlightDetails!=null)
			buffer.append(arrivalFlightDetails.toString());

		if(originalDepartureFlightDetails!=null)
			buffer.append(originalDepartureFlightDetails.toString());



		return (buffer.toString());


	}

	/**
	 * Returns the fromTEPOS.
	 * @return boolean
	 */
	public boolean getFromTEPOS()
	{
		return fromTEPOS;
	}

	/**
	 * Sets the fromTEPOS.
	 * @param fromTEPOS The fromTEPOS to set
	 */
	public void setFromTEPOS(boolean fromTEPOS)
	{
		this.fromTEPOS = fromTEPOS;
	}

	/**
	 * Returns the autoPax.
	 * @return boolean
	 */
	public boolean isAutoPax() {
		return autoPax;
	}

	/**
	 * Sets the autoPax.
	 * @param autoPax The autoPax to set
	 */
	public void setAutoPax(boolean autoPax) {
		this.autoPax = autoPax;
	}

	/**
	 * Returns the salesDutyFreeTotal.
	 * @return double
	 */
	public double getSalesDutyFreeTotal() {
		return salesDutyFreeTotal;
	}

	/**
	 * Sets the salesDutyFreeTotal.
	 * @param salesDutyFreeTotal The salesDutyFreeTotal to set
	 */
	public void setSalesDutyFreeTotal(double salesDutyFreeTotal) {
		this.salesDutyFreeTotal = salesDutyFreeTotal;
	}

	/**
	 * Returns the reportGroupId.
	 * @return String
	 */
	public String getReportGroupId() {
		return reportGroupId;
	}

	/**
	 * Sets the reportGroupId.
	 * @param reportGroupId The reportGroupId to set
	 */
	public void setReportGroupId(String reportGroupId) {
		this.reportGroupId = reportGroupId;
	}

	/**
	 * Returns the taBranchName.
	 * @return String
	 */
	public String getTaBranchName()
	{
		return taBranchName;
	}

	/**
	 * Sets the taBranchName.
	 * @param taBranchName The taBranchName to set
	 */
	public void setTaBranchName(String taBranchName)
	{
		this.taBranchName = taBranchName;
	}

	/**
	 * Returns the primaryPaxFirstName.
	 * @return String
	 */
	public String getPrimaryPaxFirstName()
	{
		return primaryPaxFirstName;
	}

	/**
	 * Returns the primaryPaxLastName.
	 * @return String
	 */
	public String getPrimaryPaxLastName()
	{
		return primaryPaxLastName;
	}

	/**
	 * Sets the primaryPaxFirstName.
	 * @param primaryPaxFirstName The primaryPaxFirstName to set
	 */
	public void setPrimaryPaxFirstName(String primaryPaxFirstName)
	{
		this.primaryPaxFirstName = primaryPaxFirstName;
	}

	/**
	 * Sets the primaryPaxLastName.
	 * @param primaryPaxLastName The primaryPaxLastName to set
	 */
	public void setPrimaryPaxLastName(String primaryPaxLastName)
	{
		this.primaryPaxLastName = primaryPaxLastName;
	}

	/**
	 * Returns the additionalPAX.
	 * @return AdditionalPAX
	 */
	public AdditionalPAX getAdditionalPAX()
	{
		return additionalPAX;
	}

	/**
	 * Sets the additionalPAX.
	 * @param additionalPAX The additionalPAX to set
	 */
	public void setAdditionalPAX(AdditionalPAX additionalPAX)
	{
		this.additionalPAX = additionalPAX;
	}

	/**
	 * Returns the addPax.
	 * @return String
	 */
	public String getAddPax()
	{
		return addPax;
	}

	/**
	 * Sets the addPax.
	 * @param addPax The addPax to set
	 */
	public void setAddPax(String addPax)
	{
		this.addPax = addPax;
	}

	/**
	 * Returns the lookUpTimedOut.
	 * @return boolean
	 */
	public boolean isLookUpTimedOut()
	{
		return lookUpTimedOut;
	}

	/**
	 * Sets the lookUpTimedOut.
	 * @param lookUpTimedOut The lookUpTimedOut to set
	 */
	public void setLookUpTimedOut(boolean lookUpTimedOut)
	{
		this.lookUpTimedOut = lookUpTimedOut;
	}

	/**
	 * Returns the createdBy.
	 * @return String
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * Returns the createdDate.
	 * @return String
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * Returns the lastModifiedBy.
	 * @return String
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * Returns the lastModifiedDate.
	 * @return String
	 */
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * Sets the createdBy.
	 * @param createdBy The createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * Sets the createdDate.
	 * @param createdDate The createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * Sets the lastModifiedBy.
	 * @param lastModifiedBy The lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * Sets the lastModifiedDate.
	 * @param lastModifiedDate The lastModifiedDate to set
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * Returns the inboundFlag.
	 * @return String
	 */
	public String getOutboundFlag() {
		return outboundFlag;
	}

	/**
	 * Sets the inboundFlag.
	 * @param inboundFlag The inboundFlag to set
	 */
	public void setOutboundFlag(String inboundFlag) {
		this.outboundFlag = inboundFlag;
	}

	/**
	 * @return
	 */
	public String getPromotionCode() {
		return promotionCode;
	}


	/**
	 * @param string
	 */
	public void setPromotionCode(String string) {
		promotionCode = string;
	}


	/**
	 * @return
	 */
	public String getPromotionRefId() {
		return promotionRefId;
	}

	/**
	 * @param string
	 */
	public void setPromotionRefId(String string) {
		promotionRefId = string;
	}

	/**
	 * @return
	 */
	public String getPromotionValue() {
		return promotionValue;
	}

	/**
	 * @param string
	 */
	public void setPromotionValue(String string) {
		promotionValue = string;
	}

}
