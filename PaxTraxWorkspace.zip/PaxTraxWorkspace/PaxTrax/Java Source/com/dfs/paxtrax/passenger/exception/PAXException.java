package com.dfs.paxtrax.passenger.exception;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.exception.PaxTraxException;


/**
 * 
 * The Exception class used during exceptions in PAX related operations
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXException extends PaxTraxException
{
	/**
	 * @see com.dfs.paxtrax.common.exception.PaxTraxException#PaxTraxException(int)
	 */
	/** The constructor for the PAX Exception class with errorCode as parameter  */
	public PAXException(int errorCode)
	{
		super(errorCode);
	}

}
