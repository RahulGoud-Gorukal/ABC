package com.dfs.paxtrax.passenger.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.valueobject.TravelAgentBranch;
import com.dfs.paxtrax.commtracking.valueobject.TravelAgentInfoBean;
import com.dfs.paxtrax.passenger.actionform.PAXForm;
import com.dfs.paxtrax.passenger.exception.PAXException;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.service.TravelAgentDelegate;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TelephoneNumberBean;
import com.dfs.paxtrax.passenger.valueobject.TravelAgentBean;

/**
 *
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created
 */
public class PAXAction extends PaxTraxAction
{

	/**
	 * Method createPaxPage.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the create PAX page
	 */
	public ActionForward createPaxPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::createPaxPage::Begin");
			PAXForm paxForm = (PAXForm) form;

			PAXBean paxBean = new PAXBean();
			paxBean = initializePAXBean(paxBean);
			paxBean.getAddress().setCountry(PaxTraxConstants.DEFAULT_COUNTRY);
			paxBean.setNationality(PaxTraxConstants.DEFAULT_NATIONALITY);

			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();

			/* --- Commented as a part of the change made for making country a textfield and not a dropdown
			paxForm.setCountryList(
				rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
			*/

			ArrayList nationalityList =
				rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
			nationalityList = formatNationality(nationalityList);

			paxForm.setNationalityList(nationalityList);

			paxForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));
			paxForm.setGroupList(
				rdDelegate.loadReferenceData(PaxTraxConstants.GROUP));

//			Added for CR611 changes on Jul 31,2008 --Begin
		   paxForm.setPromotionList(
			   rdDelegate.loadReferenceData(PaxTraxConstants.PROMOTION_CODE));
//			Added for CR611 changes on Jul 31,2008 --End

			paxForm.setPaxBean(paxBean);

			HttpSession session = request.getSession();
			session.setAttribute(
				PaxTraxConstants.MODULE_NAME,
				PaxTraxConstants.PASSENGER);

			// Commented as part of changes to make the TA code a free type field
			//ArrayList travelAgentCodeList = rdDelegate.getTravelAgentCodes();
			//paxForm.setTravelAgentCodeList(travelAgentCodeList);

			paxForm.setTravelAgentBranchesList(null);
			paxForm.setTravelAgentBranch(null);
			paxForm.setTravelAgentCode(null);
			paxForm.setPrimaryPAXCheckbox(false);

			PaxTraxLog.logDebug("PaxTrax::PAXAction::createPaxPage::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::createPaxPage",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.CREATE_PAX_PAGE);
	}


	public ActionForward getBranch(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXAction::getBranch()::Begin");
		String forward = request.getParameter("forward");
		PAXForm paxForm = (PAXForm) form;
		String travelAgentCode = paxForm.getPaxBean().getTravelAgentCode();
		PaxTraxLog.logDebug("PaxTrax::PAXAction::getBranch()::travelAgentCode "+ travelAgentCode);
		ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
		ArrayList travelAgentBranchList = rdDelegate.getTravelAgentBranches(travelAgentCode);
		paxForm.setTravelAgentBranchesList(travelAgentBranchList);
		if (PaxTraxConstants.DISP_MAINTAIN_PAGE.equals(forward)) {
				request.setAttribute(
						PaxTraxConstants.DISABLE_PAX_SCREEN,
						PaxTraxConstants.TRUE);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXAction::getBranch()::travel agent branch list "+ travelAgentBranchList.size());
		PaxTraxLog.logDebug("PaxTrax::PAXAction::getBranch():: Forwarding to "+ forward);
		PaxTraxLog.logDebug("PaxTrax::PAXAction::getBranch()::End");
		request.setAttribute("taBranchfocus","true");
		return mapping.findForward(forward);
	}

	/**
	 * Method savePAXDetails.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 * The method to create a PAX record
	 */
	public ActionForward savePAXDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::savePAXDetails::Begin");

			PAXForm paxForm = (PAXForm) form;
			PAXBean paxBean = paxForm.getPaxBean();

			if (paxBean.getTravelAgentCode().equals("") || paxBean.getTravelAgentCode()==null) {
				paxBean.setTravelAgentCode(null);
				paxBean.setTravelAgencyName(null);
				paxForm.setTravelAgentBranchesList(null);
			}
		 /* else
			{

				String travelAgentName = getTravelAgentName(
				paxBean.getTravelAgentCode(),
				paxForm.getTravelAgentCodeList());
				paxBean.setTravelAgencyName(travelAgentName);
			}
         */
			if (paxBean.getTaBranch().equals("-1")) {
				paxBean.setTaBranch(null);
				paxBean.setTaBranchName(null);
			} else {
				String taBranchName = getTravelAgentBranchName(
											paxBean.getTaBranch(),
											paxForm.getTravelAgentBranchesList());
				paxBean.setTaBranchName(taBranchName);
			}

			paxBean.setAction("C");
			paxBean.setValidate("N");
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");

			if (user != null)
				paxBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

			PAXDelegate delegate = new PAXDelegate();
			paxBean = delegate.savePAXDetails(paxBean);
			paxForm.setPaxBean(paxBean);

			PaxTraxLog.logDebug("PaxTrax::PAXAction::savePAXDetails::End");
		}
		catch (PAXException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::savePAXDetails",
				pe);
			request.setAttribute("errorCode", "" + pe.getErrorCode());
			return mapping.findForward(PaxTraxConstants.CREATE_PAX_PAGE);
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::savePAXDetails",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.SAVE_PAX_PAGE);
	}

	/**
	 * Method maintainPAXPage.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the PAX Maintain Page
	 */
	public ActionForward maintainPAXPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::maintainPAXPage::Begin");

			PAXForm paxForm = (PAXForm) form;

			PAXBean paxBean = new PAXBean();
			paxBean = initializePAXBean(paxBean);

			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();

			/* --- Commented as a part of the change made for making country a textfield and not a dropdown
			paxForm.setCountryList(
				rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
			*/

			ArrayList nationalityList =
				rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
			nationalityList = formatNationality(nationalityList);

			paxForm.setNationalityList(nationalityList);
			paxForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));
			paxForm.setGroupList(
				rdDelegate.loadReferenceData(PaxTraxConstants.GROUP));

			paxForm.setPaxBean(paxBean);

			HttpSession session = request.getSession();
			session.setAttribute(
				PaxTraxConstants.MODULE_NAME,
				PaxTraxConstants.PASSENGER);

			PaxTraxLog.logDebug("PaxTrax::PAXAction::maintainPAXPage::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::maintainPAXPage",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE));
	}

	/**
	 * Method updatePAXDetails.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	/** The method to update a PAX record  */
	public ActionForward updatePAXDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PAXForm paxForm = (PAXForm) form;
		PAXBean paxBean = null;
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::updatePAXDetails::Begin");

			paxBean = paxForm.getPaxBean();

			if (paxBean.getPaxNumber() != null
				&& paxBean.getPaxNumber().equals(""))
				paxBean.setPaxNumber(null);

			paxBean.setAction("U");
			paxBean.setValidate("N");

			if (paxBean.getTravelAgentCode().equals("") || paxBean.getTravelAgentCode()==null) {
				paxBean.setTravelAgentCode(null);
				paxBean.setTravelAgencyName(null);
				paxForm.setTravelAgentBranchesList(null);
			}
		 /* else
			{
				String travelAgentName = getTravelAgentName(
				paxBean.getTravelAgentCode(),
				paxForm.getTravelAgentCodeList());
				paxBean.setTravelAgencyName(travelAgentName);
			}
         */
			if (paxBean.getTaBranch().equals("-1")) {
				paxBean.setTaBranch(null);
				paxBean.setTaBranchName(null);
			} else {
				String taBranchName = getTravelAgentBranchName(
											paxBean.getTaBranch(),
											paxForm.getTravelAgentBranchesList());
				paxBean.setTaBranchName(taBranchName);
			}
			PAXDelegate delegate = new PAXDelegate();

			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");

			if (user != null)
				paxBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

			paxBean = delegate.updatePAXDetails(paxBean);
			paxForm.setPaxBean(paxBean);

			String fromPage = request.getParameter("fromPage");
			String fromPageNumber = request.getParameter("fromPageNumber");

			if (fromPage != null && fromPageNumber != null)
			{
				request.setAttribute("fromPage", fromPage);
				request.setAttribute("fromPageNumber", fromPageNumber);
			}

			PaxTraxLog.logDebug("PaxTrax::PAXAction::updatePAXDetails::End");
		}
		catch (PAXException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::updatePAXDetails",
				pe);

			//Code added on 05/12/2005. To catch the exception thrown from the DAO.
			if(((pe.getErrorCode())==PaxTraxErrorMessages.PT_ADDRESS1_REQ) || ((pe.getErrorCode())==PaxTraxErrorMessages.PT_CITY_REQ) || ((pe.getErrorCode())==PaxTraxErrorMessages.PT_NATIONALITY_REQ) || ((pe.getErrorCode())==PaxTraxErrorMessages.PT_DEPT_AIRLINE_REQ))
            {
				paxBean.setSalesDutyFreeTotal(PaxTraxConstants.DUTYFREE_NON_ZERO);
				paxForm.setPaxBean(paxBean);
        	}


			request.setAttribute("errorCode", "" + pe.getErrorCode());
			request.setAttribute(
				PaxTraxConstants.DISABLE_PAX_SCREEN,
				PaxTraxConstants.FALSE);
			return mapping.findForward(PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE);
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::updatePAXDetails",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (
			mapping.findForward(PaxTraxConstants.FWD_MAINTAIN_CONFIRM_PAGE));
	}

	/**
	 * Method loadPAX.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to load a PAX record  onto the PAX Maintain Page from the PAX Search Page
	 */
	public ActionForward loadPAX(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXAction::loadPAX::Begin");
		String forward = null;
		try
		{
			HttpSession session = request.getSession();
			ArrayList allRecords =
				(ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);

			String indexOfRecord = null;

			int indexId = 0;
			String sizeOfAllRecords =
				(String) session.getAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS);

			if (sizeOfAllRecords != null && sizeOfAllRecords.equals("1"))
			{
				indexOfRecord = "1";
			}
			else
			{
				indexOfRecord = request.getParameter("indexId");
			}
			if (indexOfRecord != null)
			{
				indexId = Integer.parseInt(indexOfRecord);
				indexId = indexId - 1;

				PAXForm paxForm = (PAXForm) form;
				PAXBean paxBean = (PAXBean) allRecords.get(indexId);

				request.setAttribute(
					PaxTraxConstants.DISABLE_PAX_SCREEN,
					PaxTraxConstants.FALSE);
				FlightDetailsBean deptFlightBean =
					paxBean.getDepartureFlightDetails();
				deptFlightBean.setFlightType("D");
				FlightDetailsBean arrFlightBean =
					paxBean.getArrivalFlightDetails();
				arrFlightBean.setFlightType("A");

				AddressBean addrBean = paxBean.getAddress();

				ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();



				/* --- Commented as a part of the change made for making country a textfield and not a dropdown
				paxForm.setCountryList(
					rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
				addrBean.setCountryRefId(PaxTraxConstants.COUNTRY);
				*/

				ArrayList nationalityList =
					rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
				nationalityList = formatNationality(nationalityList);

				paxForm.setNationalityList(nationalityList);
				paxBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);
//				Added for CR611 changes on Jul 31,2008 --Begin
			   paxForm.setPromotionList(
				   rdDelegate.loadReferenceData(PaxTraxConstants.PROMOTION_CODE));
//				Added for CR611 changes on Jul 31,2008 --End
				paxForm.setAirlineCodeList(
					rdDelegate.loadReferenceData(
						PaxTraxConstants.AIRLINE_CODE));
				deptFlightBean.setAirlineCodeRefId(
					PaxTraxConstants.AIRLINE_CODE);
				arrFlightBean.setAirlineCodeRefId(
					PaxTraxConstants.AIRLINE_CODE);

				paxForm.setGroupList(
					rdDelegate.loadReferenceData(PaxTraxConstants.GROUP));
				paxBean.setGroupRefId(PaxTraxConstants.GROUP);

				paxBean.setAddress(addrBean);
				paxBean.setDepartureFlightDetails(deptFlightBean);
				paxBean.setArrivalFlightDetails(arrFlightBean);

				if (paxBean.getPrimaryFlag() != null)
				{
					if (paxBean.getPrimaryFlag().equals("Y"))
						paxForm.setPrimaryPAXCheckbox(true);
					else
						paxForm.setPrimaryPAXCheckbox(false);
				}
				else
				{
					paxForm.setPrimaryPAXCheckbox(false);
					paxBean.setPrimaryPAXNumber(null);
				}
				//System.out.println("paxbean inbound val=="+ paxBean.getOutboundFlag());
				if (paxBean.getOutboundFlag() != null)
				{
					if (paxBean.getOutboundFlag().equals("Y"))
						paxForm.setOutboundPAXCheckbox(true);
					else
						paxForm.setOutboundPAXCheckbox(false);
				}
				else
				{
					paxForm.setOutboundPAXCheckbox(false);
				}

				if(paxBean.getTravelAgentCode() !=null)
                {
                    TravelAgentBean taBean=new TravelAgentBean();
                    taBean.setTravelAgentCode(paxBean.getTravelAgentCode());
                    TravelAgentDelegate taDelegate = new TravelAgentDelegate();
		            taBean = taDelegate.getTaName(taBean);
		            paxBean.setTravelAgencyName(taBean.getAgencyName());

                }
				forward = PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE;
                paxForm.setPaxBean(paxBean);

				/* Travel agent info */
				//ArrayList travelAgentCodeList = rdDelegate.getTravelAgentCodes();
				//paxForm.setTravelAgentCodeList(travelAgentCodeList);

				ArrayList travelAgentBranchList = rdDelegate.getTravelAgentBranches(paxBean.getTravelAgentCode());
				paxForm.setTravelAgentBranchesList(travelAgentBranchList);

				/* Travel agent info */

				request.setAttribute("fromPage", "searchPAX");

				String pageNumber = request.getParameter("pageNumber");
				if (pageNumber != null)
					request.setAttribute("fromPageNumber", pageNumber);
				else
					request.setAttribute("fromPageNumber", "1");


				PaxTraxLog.logDebug("PaxTrax::PAXAction::loadPAX::End");
			}
			else
			{
				PaxTraxLog.logError(
					"Exception in PaxTrax::PAXAction::loadPAX::index null");
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
			}
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::loadPAX",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(forward));

	}

	/**
	 * Method paxMaintainPageLookup.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to handle the lookup by PAX number, First Name and Last Name
	 */
	public ActionForward paxMaintainPageLookup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{

		String forwardPage = "";

		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::PAXAction::paxMaintainPageLookup::Begin");

			String fieldName = request.getParameter("fieldName");


			if (fieldName == null)
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

			/* paxBean - The new PAX bean that will be sent to the search routine for lookup */
			PAXBean paxBean = new PAXBean();
			FlightDetailsBean dept = new FlightDetailsBean();
			FlightDetailsBean arr = new FlightDetailsBean();
			AddressBean addr = new AddressBean();
			TelephoneNumberBean teleBean = new TelephoneNumberBean();

			paxBean.setDepartureFlightDetails(dept);
			paxBean.setArrivalFlightDetails(arr);
			paxBean.setAddress(addr);
			paxBean.setPhone(teleBean);

			PAXForm paxForm = (PAXForm) form;

			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();

			/* --- Commented as a part of the change made for making country a textfield and not a dropdown
			paxForm.setCountryList(
				rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
			*/

			ArrayList nationalityList =
				rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
			nationalityList = formatNationality(nationalityList);

			paxForm.setNationalityList(nationalityList);
			paxForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));
			PAXBean formPAXBean = paxForm.getPaxBean();

			if (fieldName.equals("paxNumber"))
				paxBean.setPaxNumber(formPAXBean.getPaxNumber());

			if (fieldName.equals("firstName"))
				paxBean.setFirstName(formPAXBean.getFirstName());

			if (fieldName.equals("lastName"))
				paxBean.setLastName(formPAXBean.getLastName());
			HttpSession session = request.getSession();
			if (fieldName.equals("searchPage"))
			{

				String paxNumber = request.getParameter("paxNumber");
				paxBean.setPaxNumber(paxNumber);
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute("fieldName", "paxNumber");
				session.setAttribute("fieldValue", paxNumber);
			}

			PAXDelegate delegate = new PAXDelegate();
			ArrayList paxRecords = delegate.searchPAXDetails(paxBean);

			if (paxRecords.size() == 0)
			{
				int errorCode = 0;

				if (fieldName.equals("paxNumber")
					|| fieldName.equals("searchPage"))
					errorCode = 2009;
				if (fieldName.equals("firstName"))
					errorCode = 317;
				if (fieldName.equals("lastName"))
					errorCode = 318;

				/*String paxNumber = formPAXBean.getPaxNumber();
				String lastName = formPAXBean.getLastName();
				String firstName = formPAXBean.getFirstName();


				formPAXBean = new PAXBean();
				formPAXBean = initializePAXBean(formPAXBean);
				formPAXBean.setPaxNumber(paxNumber);
				formPAXBean.setFirstName(firstName);
				formPAXBean.setLastName(lastName);
				paxForm.setPaxBean(formPAXBean);

				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.ACTION_MESSAGE_PAX,
					new ActionMessage("" + errorCode));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute("errorCode", "" + errorCode);*/

				session.setAttribute("fromMaintainPAXPage", "true");

				forwardPage =
					PaxTraxConstants.FROM_MAINTAIN_PAX_PAGE_TO_PAX_SEARCH_PAGE;
			}

			if (paxRecords.size() == 1)
			{
				request.setAttribute(
					PaxTraxConstants.DISABLE_PAX_SCREEN,
					PaxTraxConstants.FALSE);
				formPAXBean = (PAXBean) paxRecords.get(0);
				FlightDetailsBean deptFlightBean =
					formPAXBean.getDepartureFlightDetails();
				deptFlightBean.setFlightType("D");
				FlightDetailsBean arrFlightBean =
					formPAXBean.getArrivalFlightDetails();
				arrFlightBean.setFlightType("A");

				/* --- Commented as a part of the change made for making country a textfield and not a dropdown
				AddressBean addrBean = formPAXBean.getAddress();
				addrBean.setCountryRefId(PaxTraxConstants.COUNTRY);
				*/

				formPAXBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);

				deptFlightBean.setAirlineCodeRefId(
					PaxTraxConstants.AIRLINE_CODE);
				arrFlightBean.setAirlineCodeRefId(
					PaxTraxConstants.AIRLINE_CODE);

				formPAXBean.setGroupRefId(PaxTraxConstants.GROUP);

				/* --- Commented as a part of the change made for making country a textfield and not a dropdown
				formPAXBean.setAddress(addrBean);
				*/

				formPAXBean.setDepartureFlightDetails(deptFlightBean);
				formPAXBean.setArrivalFlightDetails(arrFlightBean);

				/* If the PAX record fetched has the primary flag as 'Y', the corresponding boolena in the
				 * form has to be set to true */
				if (formPAXBean.getPrimaryFlag() != null)
				{
					if (formPAXBean.getPrimaryFlag().equals("Y"))
						paxForm.setPrimaryPAXCheckbox(true);
					else
						paxForm.setPrimaryPAXCheckbox(false);
				}
				else
				{
					paxForm.setPrimaryPAXCheckbox(false);
					paxBean.setPrimaryPAXNumber(null);
				}

				if (formPAXBean.getOutboundFlag() != null)
				{
					if (formPAXBean.getOutboundFlag().equals("Y"))
						paxForm.setOutboundPAXCheckbox(true);
					else
						paxForm.setOutboundPAXCheckbox(false);
				}
				else
				{
					paxForm.setOutboundPAXCheckbox(false);
				}

				paxForm.setPaxBean(formPAXBean);

				forwardPage = PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE;
			}

			if (paxRecords.size() > 1)
			{
				session = request.getSession();
				session.setAttribute("fromMaintainPAXPage", "true");

				String value = "";
				if (fieldName.equals("firstName"))
					value = formPAXBean.getFirstName();

				if (fieldName.equals("lastName"))
					value = formPAXBean.getLastName();

				session.setAttribute("fieldName", fieldName);
				session.setAttribute("fieldValue", value);
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, paxRecords);

				forwardPage =
					PaxTraxConstants.FROM_MAINTAIN_PAX_PAGE_TO_PAX_SEARCH_PAGE;
			}

			PaxTraxLog.logDebug(
				"PaxTrax::PAXAction::paxMaintainPageLookup::End");

		}
		catch (PAXException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::paxMaintainPageLookup",
				pe);
			request.setAttribute("errorCode", "" + pe.getErrorCode());
			return (
				mapping.findForward(PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE));
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::paxMaintainPageLookup",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(forwardPage));
	}

	/**
	 * Method postCodeLookup.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to handle the Postcode Lookup
	 */
	public ActionForward postCodeLookup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forwardPage = "";

		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::postCodeLookup::Begin");

			PAXForm paxForm = (PAXForm) form;
			PAXBean paxBean = paxForm.getPaxBean();
			AddressBean addrBean = paxBean.getAddress();

			PAXDelegate delegate = new PAXDelegate();
			addrBean = delegate.postCodeLookup(addrBean);
			paxBean.setAddress(addrBean);
			paxForm.setPaxBean(paxBean);

			if (request.getParameter("page").equals("maintainPAX"))
			{
				forwardPage = PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE;
				request.setAttribute(
					PaxTraxConstants.DISABLE_PAX_SCREEN,
					PaxTraxConstants.FALSE);
			}
			else
				forwardPage = PaxTraxConstants.CREATE_PAX_PAGE;

			request.setAttribute("postCodeLookup", "true");

			PaxTraxLog.logDebug("PaxTrax::PAXAction::postCodeLookup::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::postCodeLookup",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(forwardPage));
	}

	/**
	 * Method replicatePax.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to replicate PAX Details on to the Create PAX Screen
	 */
	public ActionForward replicatePax(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXAction::replicatePax::Begin");
		PAXForm paxForm = (PAXForm) form;
		PAXBean paxBean = paxForm.getPaxBean();

		paxBean.setFirstName(null);
		paxBean.setPaxNumber(null);
		paxBean.setPrimaryFlag(null);
		paxBean.setOutboundFlag(null);
		paxBean.setPrimaryPAXNumber(null);
		paxBean.setPrimaryPAXSeqId(null);

		/* Changes made to fix the issue with the creation of PAX after clicking on replicate - May 27, 2005 */
		FlightDetailsBean deptFlightBean = paxBean.getDepartureFlightDetails();
		deptFlightBean.setFlightType("D");
		deptFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
		paxBean.setDepartureFlightDetails(deptFlightBean);

		FlightDetailsBean arrFlightBean = paxBean.getArrivalFlightDetails();
		arrFlightBean.setFlightType("A");
		arrFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
		paxBean.setArrivalFlightDetails(arrFlightBean);

		paxBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);
		paxBean.setGroupRefId(PaxTraxConstants.GROUP);
		/* End of changes */

		paxForm.setPaxBean(paxBean);

		PaxTraxLog.logDebug("PaxTrax::PAXAction::replicatePax::End");

		return mapping.findForward(PaxTraxConstants.CREATE_PAX_PAGE);
	}

	/**
	 * Method travelAgentLookup.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to handle the Travel Agent Lookup
	 */
	public ActionForward travelAgentLookup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::travelAgentLookup::Begin");

			PAXDelegate delegate = new PAXDelegate();
			ArrayList travelAgentList = delegate.loadActiveTravelAgents();
			if (travelAgentList.size() > 0)
				request.setAttribute("activeTA", travelAgentList);

			request.setAttribute("formName", request.getParameter("formName"));
			request.setAttribute(
				"fieldName",
				request.getParameter("fieldName"));

			PaxTraxLog.logDebug("PaxTrax::PAXAction::travelAgentLookup::End");
		}
		catch (PAXException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::travelAgentLookup",
				pe);
			request.setAttribute("errorCode", "" + pe.getErrorCode());
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}
		catch (PaxTraxSystemException ps)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXAction::travelAgentLookup",
				ps);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(PaxTraxConstants.TRAVEL_AGENT_LOOKUP_PAGE));
	}

	/**
	 * Method initializePAXBean.
	 *
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * The method to initialize PAX bean with all the constituent Beans
	 */

	private PAXBean initializePAXBean(PAXBean paxBean)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXAction::initializePAXBean::Begin");
		AddressBean addrBean = new AddressBean();

		FlightDetailsBean deptFlightBean = new FlightDetailsBean();
		deptFlightBean.setFlightType("D");

		FlightDetailsBean arrFlightBean = new FlightDetailsBean();
		arrFlightBean.setFlightType("A");

		/* --- Commented as a part of the change made for making country a textfield and not a dropdown
		addrBean.setCountryRefId(PaxTraxConstants.COUNTRY);
		*/

		paxBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);
		deptFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
		arrFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
		paxBean.setGroupRefId(PaxTraxConstants.GROUP);

		paxBean.setAddress(addrBean);
		paxBean.setDepartureFlightDetails(deptFlightBean);
		paxBean.setArrivalFlightDetails(arrFlightBean);
		paxBean.setPrimaryFlag("N");
		paxBean.setOutboundFlag("N");

		PaxTraxLog.logDebug("PaxTrax::PAXAction::initializePAXBean::End");
		return (paxBean);

	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXAction::changeLanguage::Begin");

		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country =
			request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String page = request.getParameter(PaxTraxConstants.PAGE);

		if (language != null && country != null && page != null)
			super.changeLanguage(request, language, country);
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		if (page.equals("createPAX"))
			forwardPage = PaxTraxConstants.CREATE_PAX_PAGE;

		if (page.equals("createPAXConf"))
			forwardPage = PaxTraxConstants.SAVE_PAX_PAGE;

		if (page.equals("maintainPAX"))
		{
			forwardPage = PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE;
			String disable = request.getParameter("disable");

			if (disable.equals("false"))
				request.setAttribute(
					PaxTraxConstants.DISABLE_PAX_SCREEN,
					disable);
		}

		if (page.equals("maintainPAXConf"))
			forwardPage = PaxTraxConstants.FWD_MAINTAIN_CONFIRM_PAGE;

		String errorCode = request.getParameter("errc");

		if (errorCode != null)
		{
			if (!(errorCode.equals("-1")))
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.ACTION_MESSAGE_PAX,
					new ActionMessage(errorCode));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute("errorCode", errorCode);
			}
		}

		PaxTraxLog.logDebug("PaxTrax::PAXAction::changeLanguage::End");
		return (mapping.findForward(forwardPage));
	}

	private ArrayList formatNationality(ArrayList nationalityList)
	{
		if (nationalityList.size() > 0)
		{
			for (int i = 0; i < nationalityList.size(); i++)
			{
				ReferenceDataBean rdBean =
					(ReferenceDataBean) nationalityList.get(i);

				rdBean.setCodeValue(
					rdBean.getCodeId() + " - " + rdBean.getCodeValue());
				nationalityList.set(i, rdBean);
			}
		}

		return (nationalityList);
	}


	public ActionForward updatePaxNo(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	{
		PaxTraxLog.logDebug("PaxTrax::PaxAction::updatePaxNo::Begin");
 		PAXForm paxForm = (PAXForm) form;
		PAXBean paxBean = new PAXBean();
		paxForm.setPaxBean(paxBean);

		String indexId = (String)request.getParameter("indexId");
		request.setAttribute("indexId", indexId);
		PaxTraxLog.logDebug("PaxTrax::PaxAction::updatePaxNo::End");
		return mapping.findForward("updatePaxNo");
	}


	public ActionForward updatePax(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response) throws PaxTraxSystemException
	{
		try
		{
		PaxTraxLog.logDebug("PaxTrax::PaxAction::updatePax::Begin");
		PAXBean pax = null;
		int i = 0;

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		String sequenceId = request.getParameter("indexId");
		String paxNo = request.getParameter("paxNo");
		HttpSession session = request.getSession();
		ArrayList paxList = (ArrayList)session.
			getAttribute(PaxTraxConstants.ALL_RECORDS);

		if (sequenceId != null)
			i = Integer.parseInt(sequenceId);

		if (paxList != null)
		{
			pax = (PAXBean)paxList.get(i-1);
		}
		pax.setPaxNumber(paxNo);

		PAXDelegate delegate = new PAXDelegate();
		delegate.updatePAXNo(pax);
		paxList.remove(i-1);
		paxList.add(i-1,pax);
		session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
		session.setAttribute(PaxTraxConstants.ALL_RECORDS,paxList);
		PaxTraxLog.logDebug("PaxTrax::PaxAction::updatePax::End");
		}
		catch (PAXException paxException)
		{
			PaxTraxLog.logError("Pax Exception in updatepax",paxException);
			request.setAttribute(PaxTraxConstants.ERRORCODE,
				""+paxException.getErrorCode());
			return mapping.findForward("commtraxPAXSearchPage");
		}
		return mapping.findForward("updatePax");

	}

	private String getTravelAgentName(String taCode, ArrayList taCodeList) {
		for (int i = 0; i < taCodeList.size(); i++) {
			TravelAgentInfoBean travelAgentInfoBean = (TravelAgentInfoBean) taCodeList.get(i);
			if (travelAgentInfoBean.getTaCode().equals(taCode)) {
				return travelAgentInfoBean.getTaAgencyName();
			}
		}
		return null;
	}

	private String getTravelAgentBranchName(String branchCode, ArrayList taBranchList) {
		for (int i = 0; i < taBranchList.size(); i++) {
			TravelAgentBranch taBranch = (TravelAgentBranch) taBranchList.get(i);
			if (taBranch.getTaBranchCode().equals(branchCode)) {
				return taBranch.getTaBranchName();
			}
		}
		return null;
	}

    public ActionForward getMatchingTA(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forwardPage = "";
		PAXForm paxForm=null;
		PAXBean paxBean=null;
		TravelAgentBean taBean=new TravelAgentBean();

		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXAction::getMatchingTA()::Begin");

		    paxForm = (PAXForm) form;
			paxBean= paxForm.getPaxBean();
            String taName=paxBean.getTravelAgencyName().toUpperCase();
			PAXDelegate delegate = new PAXDelegate();
			ArrayList taList = delegate.getMatchingTA(taName);
		    if (taList.size()==0)
			{
			 	//Setting errorCode as 2007 if TA Code entered is invalid
				request.setAttribute(PaxTraxConstants.ERRORCODE,"2007");
			}
			else if (taList.size() == 1)
			{
			    taBean=(TravelAgentBean)taList.get(0);
			    paxBean.setTravelAgencyName(taBean.getAgencyName());
			    paxBean.setTravelAgentCode(taBean.getTravelAgentCode());
			    paxForm.setPaxBean(paxBean);
			    ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
				ArrayList travelAgentBranchList = rdDelegate.getTravelAgentBranches(taBean.getTravelAgentCode());
			    paxForm.setTravelAgentBranchesList(travelAgentBranchList);
			    request.setAttribute("taBranchfocus","true");
			}
			else
			{
			    HttpSession session = request.getSession();
			    session.setAttribute("activeTA", taList);
			    request.setAttribute("talookup","true");
			    session.setAttribute("formName", request.getParameter("formName"));
			    session.setAttribute("taName", request.getParameter("taName"));
			    session.setAttribute("taCode", request.getParameter("taCode"));
			}
			if (request.getParameter("page").equals("maintainPAX"))
			{
				forwardPage = PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE;
				request.setAttribute(PaxTraxConstants.DISABLE_PAX_SCREEN,PaxTraxConstants.FALSE);
			}
		    else
				forwardPage = PaxTraxConstants.CREATE_PAX_PAGE;

	       if(paxBean.getTravelAgentCode()==null || paxBean.getTravelAgentCode().equals(""))
		   {
		        paxForm.setTravelAgentBranchesList(null);
		   }

			PaxTraxLog.logDebug("PaxTrax::PAXAction::getMatchingTA::End");
		}

		catch (PAXException pxe)
		{
			PaxTraxLog.logError("Pax Exception in getMatchingTA",pxe);

		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXAction::getMatchingTA",pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		PaxTraxLog.logDebug("PaxTrax::PAXAction::getMatchingTA::End");

		return (mapping.findForward(forwardPage));
	}

}
