package com.dfs.paxtrax.passenger.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * 
 * The Travel Agent value object
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Joseph			Created   
 */
public class TAFileBean extends PaxTraxValueObject
{

	private String fileName = null;
	private String fileYear = null;
	private String fileMonth = null;
	private String fileDate = null;
	private String taCode = null;
	private String taBranch = null;

	private String fileEncryptionType = "Shift_JIS";
	private String delimitedFile = "N";
	private String delimiterUsed = null;
	private String headerPresent = "N";
	private String headerDelimited = "N";
	private String headerDelimiter = null;
	private String footerPresent = "N";
	private String footerDelimited = "N";
	private String footerDelimiter = null;
	private String dateFormat = null;
	private String headerIndicator = null;
	private String detailsIndicator = null;
	private String footerIndicator = null;
	private String ftpLocationIp = null;
	private String ftpLocationPort = null;
	private String ftpUserId = null;
	private String ftpUserPassword = null;
	private String ftpSrcFolder = null;
	private String localDestFolder = null;
	private String logFolder = null;

	private int fieldCodeID = 0;
	private String lineType = null;
	private int startIndexPosition = 0;
	private int endPosition = 0;
	private int length = 0;

	private String dateType = null;
	private String airLineValueType = null;
	private ArrayList fieldDetails = null;

	private ArrayList headerList = null;
	private ArrayList footerList = null;
	private ArrayList detailsList = null;

	/**
	 * Returns the airLineValueType.
	 * @return String
	 */
	public String getAirLineValueType()
	{
		return airLineValueType;
	}

	/**
	 * Returns the dateType.
	 * @return String
	 */
	public String getDateType()
	{
		return dateType;
	}

	/**
	 * Returns the endPosition.
	 * @return int
	 */
	public int getEndPosition()
	{
		return endPosition;
	}

	/**
	 * Returns the fieldCodeID.
	 * @return int
	 */
	public int getFieldCodeID()
	{
		return fieldCodeID;
	}

	/**
	 * Returns the length.
	 * @return int
	 */
	public int getLength()
	{
		return length;
	}

	/**
	 * Returns the lineType.
	 * @return String
	 */
	public String getLineType()
	{
		return lineType;
	}

	/**
	 * Returns the startIndexPosition.
	 * @return int
	 */
	public int getStartIndexPosition()
	{
		return startIndexPosition;
	}

	/**
	 * Sets the airLineValueType.
	 * @param airLineValueType The airLineValueType to set
	 */
	public void setAirLineValueType(String airLineValueType)
	{
		this.airLineValueType = airLineValueType;
	}

	/**
	 * Sets the dateType.
	 * @param dateType The dateType to set
	 */
	public void setDateType(String dateType)
	{
		this.dateType = dateType;
	}

	/**
	 * Sets the endPosition.
	 * @param endPosition The endPosition to set
	 */
	public void setEndPosition(int endPosition)
	{
		this.endPosition = endPosition;
	}

	/**
	 * Sets the fieldCodeID.
	 * @param fieldCodeID The fieldCodeID to set
	 */
	public void setFieldCodeID(int fieldCodeID)
	{
		this.fieldCodeID = fieldCodeID;
	}

	/**
	 * Sets the length.
	 * @param length The length to set
	 */
	public void setLength(int length)
	{
		this.length = length;
	}

	/**
	 * Sets the lineType.
	 * @param lineType The lineType to set
	 */
	public void setLineType(String lineType)
	{
		this.lineType = lineType;
	}

	/**
	 * Sets the startIndexPosition.
	 * @param startIndexPosition The startIndexPosition to set
	 */
	public void setStartIndexPosition(int startIndexPosition)
	{
		this.startIndexPosition = startIndexPosition;
	}

	/**
	 * Returns the fieldDetails.
	 * @return ArrayList
	 */
	public ArrayList getFieldDetails()
	{
		return fieldDetails;
	}

	/**
	 * Sets the fieldDetails.
	 * @param fieldDetails The fieldDetails to set
	 */
	public void setFieldDetails(ArrayList fieldDetails)
	{
		this.fieldDetails = fieldDetails;
	}

	/**
	 * Returns the taBranch.
	 * @return String
	 */
	public String getTaBranch()
	{
		return taBranch;
	}

	/**
	 * Returns the taCode.
	 * @return String
	 */
	public String getTaCode()
	{
		return taCode;
	}

	/**
	 * Sets the taBranch.
	 * @param taBranch The taBranch to set
	 */
	public void setTaBranch(String taBranch)
	{
		this.taBranch = taBranch;
	}

	/**
	 * Sets the taCode.
	 * @param taCode The taCode to set
	 */
	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}

	/**
	 * Returns the detailsList.
	 * @return ArrayList
	 */
	public ArrayList getDetailsList()
	{
		return detailsList;
	}

	/**
	 * Sets the detailsList.
	 * @param detailsList The detailsList to set
	 */
	public void setDetailsList(ArrayList detailsList)
	{
		this.detailsList = detailsList;
	}

	/**
	 * Returns the fileName.
	 * @return String
	 */
	public String getFileName()
	{
		return fileName;
	}

	/**
	 * Sets the fileName.
	 * @param fileName The fileName to set
	 */
	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	/**
	 * Returns the fileDate.
	 * @return String
	 */
	public String getFileDate()
	{
		return fileDate;
	}

	/**
	 * Returns the fileMonth.
	 * @return String
	 */
	public String getFileMonth()
	{
		return fileMonth;
	}

	/**
	 * Returns the fileYear.
	 * @return String
	 */
	public String getFileYear()
	{
		return fileYear;
	}

	/**
	 * Sets the fileDate.
	 * @param fileDate The fileDate to set
	 */
	public void setFileDate(String fileDate)
	{
		this.fileDate = fileDate;
	}

	/**
	 * Sets the fileMonth.
	 * @param fileMonth The fileMonth to set
	 */
	public void setFileMonth(String fileMonth)
	{
		this.fileMonth = fileMonth;
	}

	/**
	 * Sets the fileYear.
	 * @param fileYear The fileYear to set
	 */
	public void setFileYear(String fileYear)
	{
		this.fileYear = fileYear;
	}

	/**
	 * Returns the dateFormat.
	 * @return String
	 */
	public String getDateFormat()
	{
		return dateFormat;
	}

	/**
	 * Returns the delimitedFile.
	 * @return String
	 */
	public String getDelimitedFile()
	{
		return delimitedFile;
	}

	/**
	 * Returns the delimiterUsed.
	 * @return String
	 */
	public String getDelimiterUsed()
	{
		return delimiterUsed;
	}

	/**
	 * Returns the detailsIndicator.
	 * @return String
	 */
	public String getDetailsIndicator()
	{
		return detailsIndicator;
	}

	/**
	 * Returns the fileEncryptionType.
	 * @return String
	 */
	public String getFileEncryptionType()
	{
		return fileEncryptionType;
	}

	/**
	 * Returns the footerDelimited.
	 * @return String
	 */
	public String getFooterDelimited()
	{
		return footerDelimited;
	}

	/**
	 * Returns the footerDelimiter.
	 * @return String
	 */
	public String getFooterDelimiter()
	{
		return footerDelimiter;
	}

	/**
	 * Returns the footerIndicator.
	 * @return String
	 */
	public String getFooterIndicator()
	{
		return footerIndicator;
	}

	/**
	 * Returns the footerPresent.
	 * @return String
	 */
	public String getFooterPresent()
	{
		return footerPresent;
	}

	/**
	 * Returns the headerDelimited.
	 * @return String
	 */
	public String getHeaderDelimited()
	{
		return headerDelimited;
	}

	/**
	 * Returns the headerDelimiter.
	 * @return String
	 */
	public String getHeaderDelimiter()
	{
		return headerDelimiter;
	}

	/**
	 * Returns the headerIndicator.
	 * @return String
	 */
	public String getHeaderIndicator()
	{
		return headerIndicator;
	}

	/**
	 * Returns the headerPresent.
	 * @return String
	 */
	public String getHeaderPresent()
	{
		return headerPresent;
	}

	/**
	 * Sets the dateFormat.
	 * @param dateFormat The dateFormat to set
	 */
	public void setDateFormat(String dateFormat)
	{
		this.dateFormat = dateFormat;
	}

	/**
	 * Sets the delimitedFile.
	 * @param delimitedFile The delimitedFile to set
	 */
	public void setDelimitedFile(String delimitedFile)
	{
		this.delimitedFile = delimitedFile;
	}

	/**
	 * Sets the delimiterUsed.
	 * @param delimiterUsed The delimiterUsed to set
	 */
	public void setDelimiterUsed(String delimiterUsed)
	{
		this.delimiterUsed = delimiterUsed;
	}

	/**
	 * Sets the detailsIndicator.
	 * @param detailsIndicator The detailsIndicator to set
	 */
	public void setDetailsIndicator(String detailsIndicator)
	{
		this.detailsIndicator = detailsIndicator;
	}

	/**
	 * Sets the fileEncryptionType.
	 * @param fileEncryptionType The fileEncryptionType to set
	 */
	public void setFileEncryptionType(String fileEncryptionType)
	{
		this.fileEncryptionType = fileEncryptionType;
	}

	/**
	 * Sets the footerDelimited.
	 * @param footerDelimited The footerDelimited to set
	 */
	public void setFooterDelimited(String footerDelimited)
	{
		this.footerDelimited = footerDelimited;
	}

	/**
	 * Sets the footerDelimiter.
	 * @param footerDelimiter The footerDelimiter to set
	 */
	public void setFooterDelimiter(String footerDelimiter)
	{
		this.footerDelimiter = footerDelimiter;
	}

	/**
	 * Sets the footerIndicator.
	 * @param footerIndicator The footerIndicator to set
	 */
	public void setFooterIndicator(String footerIndicator)
	{
		this.footerIndicator = footerIndicator;
	}

	/**
	 * Sets the footerPresent.
	 * @param footerPresent The footerPresent to set
	 */
	public void setFooterPresent(String footerPresent)
	{
		this.footerPresent = footerPresent;
	}

	/**
	 * Sets the headerDelimited.
	 * @param headerDelimited The headerDelimited to set
	 */
	public void setHeaderDelimited(String headerDelimited)
	{
		this.headerDelimited = headerDelimited;
	}

	/**
	 * Sets the headerDelimiter.
	 * @param headerDelimiter The headerDelimiter to set
	 */
	public void setHeaderDelimiter(String headerDelimiter)
	{
		this.headerDelimiter = headerDelimiter;
	}

	/**
	 * Sets the headerIndicator.
	 * @param headerIndicator The headerIndicator to set
	 */
	public void setHeaderIndicator(String headerIndicator)
	{
		this.headerIndicator = headerIndicator;
	}

	/**
	 * Sets the headerPresent.
	 * @param headerPresent The headerPresent to set
	 */
	public void setHeaderPresent(String headerPresent)
	{
		this.headerPresent = headerPresent;
	}

	/**
	 * Returns the footerList.
	 * @return ArrayList
	 */
	public ArrayList getFooterList()
	{
		return footerList;
	}

	/**
	 * Returns the headerList.
	 * @return ArrayList
	 */
	public ArrayList getHeaderList()
	{
		return headerList;
	}

	/**
	 * Sets the footerList.
	 * @param footerList The footerList to set
	 */
	public void setFooterList(ArrayList footerList)
	{
		this.footerList = footerList;
	}

	/**
	 * Sets the headerList.
	 * @param headerList The headerList to set
	 */
	public void setHeaderList(ArrayList headerList)
	{
		this.headerList = headerList;
	}

	/**
	 * Returns the ftpLocationIp.
	 * @return String
	 */
	public String getFtpLocationIp()
	{
		return ftpLocationIp;
	}

	/**
	 * Returns the ftpLocationPort.
	 * @return String
	 */
	public String getFtpLocationPort()
	{
		return ftpLocationPort;
	}

	/**
	 * Returns the ftpSrcFolder.
	 * @return String
	 */
	public String getFtpSrcFolder()
	{
		return ftpSrcFolder;
	}

	/**
	 * Returns the ftpUserId.
	 * @return String
	 */
	public String getFtpUserId()
	{
		return ftpUserId;
	}

	/**
	 * Returns the ftpUserPassword.
	 * @return String
	 */
	public String getFtpUserPassword()
	{
		return ftpUserPassword;
	}

	/**
	 * Sets the ftpLocationIp.
	 * @param ftpLocationIp The ftpLocationIp to set
	 */
	public void setFtpLocationIp(String ftpLocationIp)
	{
		this.ftpLocationIp = ftpLocationIp;
	}

	/**
	 * Sets the ftpLocationPort.
	 * @param ftpLocationPort The ftpLocationPort to set
	 */
	public void setFtpLocationPort(String ftpLocationPort)
	{
		this.ftpLocationPort = ftpLocationPort;
	}

	/**
	 * Sets the ftpSrcFolder.
	 * @param ftpSrcFolder The ftpSrcFolder to set
	 */
	public void setFtpSrcFolder(String ftpSrcFolder)
	{
		this.ftpSrcFolder = ftpSrcFolder;
	}

	/**
	 * Sets the ftpUserId.
	 * @param ftpUserId The ftpUserId to set
	 */
	public void setFtpUserId(String ftpUserId)
	{
		this.ftpUserId = ftpUserId;
	}

	/**
	 * Sets the ftpUserPassword.
	 * @param ftpUserPassword The ftpUserPassword to set
	 */
	public void setFtpUserPassword(String ftpUserPassword)
	{
		this.ftpUserPassword = ftpUserPassword;
	}

	/**
	 * Returns the localDestFolder.
	 * @return String
	 */
	public String getLocalDestFolder()
	{
		return localDestFolder;
	}

	/**
	 * Sets the localDestFolder.
	 * @param localDestFolder The localDestFolder to set
	 */
	public void setLocalDestFolder(String localDestFolder)
	{
		this.localDestFolder = localDestFolder;
	}

	/**
	 * Returns the logFolder.
	 * @return String
	 */
	public String getLogFolder()
	{
		return logFolder;
	}

	/**
	 * Sets the logFolder.
	 * @param logFolder The logFolder to set
	 */
	public void setLogFolder(String logFolder)
	{
		this.logFolder = logFolder;
	}

}
