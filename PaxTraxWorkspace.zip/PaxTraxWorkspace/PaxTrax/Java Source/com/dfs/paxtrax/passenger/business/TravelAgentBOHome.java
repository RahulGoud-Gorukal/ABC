package com.dfs.paxtrax.passenger.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import javax.ejb.CreateException;


/**
 * 
 * The EJB Home Object for the PAXBOBean
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public interface TravelAgentBOHome extends javax.ejb.EJBHome
{
		/**
		 * Method create.
		 * 
		 * @return TravelAgentBO
		 * @throws CreateException
		 * @throws RemoteException
		 */
	    public TravelAgentBO create() throws CreateException, RemoteException;
}
