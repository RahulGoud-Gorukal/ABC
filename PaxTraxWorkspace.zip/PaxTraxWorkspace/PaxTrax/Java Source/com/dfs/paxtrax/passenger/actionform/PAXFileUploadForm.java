package com.dfs.paxtrax.passenger.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import org.apache.struts.upload.FormFile;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * 
 * The Action Form for the Upload PAX File Page
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXFileUploadForm extends PaxTraxActionForm
{
	//File Type
	private String fileType = null;
	
	//ArrayList to hold the list of valid File Types
	ArrayList fileTypeList = null;
	
	//File 1 on Upload Page
	private FormFile file1 = null;
	
	//File 2 on Upload Page	
	private FormFile file2 = null;
	
	//File 3 on Upload Page	
	private FormFile file3 = null;	
	
	//File 4 on Upload Page	
	private FormFile file4 = null;
	
	//File 5 on Upload Page	
	private FormFile file5 = null;
	
	//File 6 on Upload Page	
	private FormFile file6 = null;
	
	//File 7 on Upload Page	
	private FormFile file7 = null;	
	
	//File 8 on Upload Page	
	private FormFile file8 = null;
	
	//File 9 on Upload Page	
	private FormFile file9 = null;
	
	//File 10 on Upload Page	
	private FormFile file10 = null;
		
	/**
	 * Returns the file1.
	 * @return FormFile
	 */
	public FormFile getFile1() {
		return file1;
	}

	/**
	 * Returns the file2.
	 * @return FormFile
	 */
	public FormFile getFile2() {
		return file2;
	}

	/**
	 * Returns the file3.
	 * @return FormFile
	 */
	public FormFile getFile3() {
		return file3;
	}

	/**
	 * Returns the file4.
	 * @return FormFile
	 */
	public FormFile getFile4() {
		return file4;
	}

	/**
	 * Sets the file1.
	 * @param file1 The file1 to set
	 */
	public void setFile1(FormFile file1) {
		this.file1 = file1;
	}

	/**
	 * Sets the file2.
	 * @param file2 The file2 to set
	 */
	public void setFile2(FormFile file2) {
		this.file2 = file2;
	}

	/**
	 * Sets the file3.
	 * @param file3 The file3 to set
	 */
	public void setFile3(FormFile file3) {
		this.file3 = file3;
	}

	/**
	 * Sets the file4.
	 * @param file4 The file4 to set
	 */
	public void setFile4(FormFile file4) {
		this.file4 = file4;
	}

	/**
	 * Returns the file10.
	 * @return FormFile
	 */
	public FormFile getFile10()
	{
		return file10;
	}

	/**
	 * Returns the file5.
	 * @return FormFile
	 */
	public FormFile getFile5()
	{
		return file5;
	}

	/**
	 * Returns the file6.
	 * @return FormFile
	 */
	public FormFile getFile6()
	{
		return file6;
	}

	/**
	 * Returns the file7.
	 * @return FormFile
	 */
	public FormFile getFile7()
	{
		return file7;
	}

	/**
	 * Returns the file8.
	 * @return FormFile
	 */
	public FormFile getFile8()
	{
		return file8;
	}

	/**
	 * Returns the file9.
	 * @return FormFile
	 */
	public FormFile getFile9()
	{
		return file9;
	}

	/**
	 * Sets the file10.
	 * @param file10 The file10 to set
	 */
	public void setFile10(FormFile file10)
	{
		this.file10 = file10;
	}

	/**
	 * Sets the file5.
	 * @param file5 The file5 to set
	 */
	public void setFile5(FormFile file5)
	{
		this.file5 = file5;
	}

	/**
	 * Sets the file6.
	 * @param file6 The file6 to set
	 */
	public void setFile6(FormFile file6)
	{
		this.file6 = file6;
	}

	/**
	 * Sets the file7.
	 * @param file7 The file7 to set
	 */
	public void setFile7(FormFile file7)
	{
		this.file7 = file7;
	}

	/**
	 * Sets the file8.
	 * @param file8 The file8 to set
	 */
	public void setFile8(FormFile file8)
	{
		this.file8 = file8;
	}

	/**
	 * Sets the file9.
	 * @param file9 The file9 to set
	 */
	public void setFile9(FormFile file9)
	{
		this.file9 = file9;
	}

	/**
	 * Returns the fileType.
	 * @return String
	 */
	public String getFileType()
	{
		return fileType;
	}

	/**
	 * Returns the fileTypeList.
	 * @return ArrayList
	 */
	public ArrayList getFileTypeList()
	{
		return fileTypeList;
	}

	/**
	 * Sets the fileType.
	 * @param fileType The fileType to set
	 */
	public void setFileType(String fileType)
	{
		this.fileType = fileType;
	}

	/**
	 * Sets the fileTypeList.
	 * @param fileTypeList The fileTypeList to set
	 */
	public void setFileTypeList(ArrayList fileTypeList)
	{
		this.fileTypeList = fileTypeList;
	}

}
