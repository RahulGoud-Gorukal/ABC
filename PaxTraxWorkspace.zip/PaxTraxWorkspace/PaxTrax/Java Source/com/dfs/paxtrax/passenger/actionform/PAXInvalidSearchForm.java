package com.dfs.paxtrax.passenger.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import java.util.ArrayList;


/**
 * 
 * The Action Form for the Invalid PAX Search Flow
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXInvalidSearchForm extends PaxTraxActionForm{
	/* The Travel Agent Code  */
    private String travelAgentCode = null;
    
    /* The From date Field on the page  */
    private String fromDate = null;
    
    /* The To date Field on the page */
    private String toDate = null;
    
    /* The ArrayList that contains the current view pf invalid PAX Records */ 
    private ArrayList invalidPAXRecordList = null;
    
    /* The ArrayList that contains the list of Active Travel Agent Codes  */
    private ArrayList travelAgentCodes = null;

	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate()
	{
		return fromDate;
	}

	/**
	 * Returns the invalidPAXRecordList.
	 * @return ArrayList
	 */
	public ArrayList getInvalidPAXRecordList()
	{
		return invalidPAXRecordList;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate()
	{
		return toDate;
	}

	/**
	 * Returns the travelAgentCode.
	 * @return String
	 */
	public String getTravelAgentCode()
	{
		return travelAgentCode;
	}

	/**
	 * Returns the travelAgentCodes.
	 * @return ArrayList
	 */
	public ArrayList getTravelAgentCodes()
	{
		return travelAgentCodes;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate)
	{
		this.fromDate = fromDate;
	}

	/**
	 * Sets the invalidPAXRecordList.
	 * @param invalidPAXRecordList The invalidPAXRecordList to set
	 */
	public void setInvalidPAXRecordList(ArrayList invalidPAXRecordList)
	{
		this.invalidPAXRecordList = invalidPAXRecordList;
	}

	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate)
	{
		this.toDate = toDate;
	}

	/**
	 * Sets the travelAgentCode.
	 * @param travelAgentCode The travelAgentCode to set
	 */
	public void setTravelAgentCode(String travelAgentCode)
	{
		this.travelAgentCode = travelAgentCode;
	}

	/**
	 * Sets the travelAgentCodes.
	 * @param travelAgentCodes The travelAgentCodes to set
	 */
	public void setTravelAgentCodes(ArrayList travelAgentCodes)
	{
		this.travelAgentCodes = travelAgentCodes;
	}

}
