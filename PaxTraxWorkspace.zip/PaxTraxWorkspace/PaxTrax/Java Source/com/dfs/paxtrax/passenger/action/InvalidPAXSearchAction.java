package com.dfs.paxtrax.passenger.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.passenger.actionform.PAXInvalidSearchForm;
import com.dfs.paxtrax.passenger.exception.PAXException;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.valueobject.InvalidPAXSearchResultBean;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class InvalidPAXSearchAction extends PaxTraxAction
{

	public ActionForward invalidPAXSearchPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws CommTraxException
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::InvalidPAXSearchAction::invalidPAXSearchPage::Begin");
			PAXInvalidSearchForm paxInvalidSearchForm =
				(PAXInvalidSearchForm) form;

			paxInvalidSearchForm.setTravelAgentCode(null);
			paxInvalidSearchForm.setFromDate(null);
			paxInvalidSearchForm.setToDate(null);

			// populate values in the combobox for TravelAgent Code
			paxInvalidSearchForm.setTravelAgentCodes(getTravelAgentCodeList());

			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.FAILURE);

			HttpSession session = request.getSession();
			session.setAttribute(
				PaxTraxConstants.MODULE_NAME,
				PaxTraxConstants.PASSENGER);
			PaxTraxLog.logDebug(
				"PaxTrax::InvalidPAXSearchAction::invalidPAXSearchPage::End");
		}
		catch (CommTraxException ce)
		{
			PaxTraxLog.logError(
				"Exception in ::InvalidPAXSearchAction::invalidPAXSearchPage",
				ce);			
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in ::InvalidPAXSearchAction::invalidPAXSearchPage",
				pse);
			return (mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));
		}

		return mapping.findForward(PaxTraxConstants.INVALID_PAX_SEARCH_PAGE);
	}

	public ActionForward searchInvalidPAXRecord(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, PAXException
	{

		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::InvalidPAXSearchAction::searchInvalidPAXRecord::Begin");

			int pageNumber = 0;
			ArrayList currentRecords = null;
			ArrayList allRecords = null;
			HttpSession session = request.getSession();
			PAXInvalidSearchForm paxInvalidSearchForm =
				(PAXInvalidSearchForm) form;

			//Code Inserted for Pagination
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
			{
				pageNumber = Integer.parseInt(pageNumberStr);
			}

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */

			if (pageNumber == 0)
			{
				int size = 0;
				pageNumber = 1;
				allRecords =
					getInvalidPaxDetails(
						paxInvalidSearchForm.getTravelAgentCode(),
						paxInvalidSearchForm.getFromDate(),
						paxInvalidSearchForm.getToDate());

				if (allRecords != null)
				{
					size = allRecords.size();
				}

				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
			}
			else
			{
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
			}

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((allRecords != null) && (allRecords.size() != 0))
			{
				// Get records to be displayed for the passed page number
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
			}

			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));

			paxInvalidSearchForm.setInvalidPAXRecordList(currentRecords);

			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);

			PaxTraxLog.logDebug(
				"PaxTrax::InvalidPAXSearchAction::searchInvalidPAXRecord::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::InvalidPAXSearchAction::searchInvalidPAXRecord",
				pse);
			return (mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));
		}

		return mapping.findForward(PaxTraxConstants.INVALID_PAX_SEARCH_PAGE);
	}

	private ArrayList getTravelAgentCodeList() throws CommTraxException,PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::InvalidPAXSearchAction::getTravelAgentCodeList::Begin");
		ArrayList taCodeArrayList = new ArrayList();
		
		
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		taCodeArrayList = commTraxDelegate.loadTaName();
	
		
		return taCodeArrayList;
	}

	private ArrayList getInvalidPaxDetails(
		String travelAgentCode,
		String fromDate,
		String toDate)
		throws PaxTraxSystemException, PAXException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::InvalidPAXSearchAction::getInvalidPaxDetails::Begin");

		if (fromDate != null && fromDate.equals(""))
			fromDate = null;

		if (toDate != null && toDate.equals(""))
			toDate = null;

		if (travelAgentCode != null && travelAgentCode.equals("-1"))
			travelAgentCode = null;

		ArrayList invalidPAXDetails = new ArrayList();

		PAXDelegate paxDelegateObj = new PAXDelegate();
		InvalidPAXSearchResultBean invalidPAX =
			new InvalidPAXSearchResultBean();

		invalidPAX.setTravelAgentCode(travelAgentCode);
		invalidPAX.setFromDate(fromDate);
		invalidPAX.setToDate(toDate);

		invalidPAXDetails = paxDelegateObj.searchInvalidPaxRecords(invalidPAX);

		PaxTraxLog.logDebug(
			"PaxTrax::InvalidPAXSearchAction::getInvalidPaxDetails::End");
		return invalidPAXDetails;
	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::InvalidPAXSearchAction::changeLanguage::Begin");
		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String result = request.getParameter("res");
		String pageNumber = request.getParameter("pN");

		if (language != null && country != null && result != null)
		{
			super.changeLanguage(request, language, country);
			forwardPage = PaxTraxConstants.INVALID_PAX_SEARCH_PAGE;
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		if (result.equals(PaxTraxConstants.SUCCESS))
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
		}
		else
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.FAILURE);

		PaxTraxLog.logDebug(
			"PaxTrax::InvalidPAXSearchAction::changeLanguage::End");
		return (mapping.findForward(forwardPage));
	}

}
