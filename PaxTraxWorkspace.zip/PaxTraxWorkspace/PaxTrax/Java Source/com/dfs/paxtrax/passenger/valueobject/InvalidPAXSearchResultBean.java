package com.dfs.paxtrax.passenger.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * @author 107316
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
/**
 * 
 * The Value object used in for the Invalid PAX Search Page
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class InvalidPAXSearchResultBean extends  PaxTraxValueObject 
{
	/* The Travel Agent Code  */
    private String travelAgentCode = null;
    
    /* The Tour Code of the passenger  */
    private String tourCode = null;
    
    /* The File Name  */
    private String fileName = null;
    
    /* The File Date */
    private String fileDate = null;
    
    /* The Last Name   */
    private String paxLastName = null;
    
    /* The First Name  */
    private String paxFirstName = null;
    
    /* The List of Rejection Reasons  */
    private ArrayList rejectionReasonList = null;
    
    /* The From Date field used for the search */
    private String fromDate = null;
    
    /* The To Date field used for the search */
    private String toDate = null;
    
	/**
	 * @see java.lang.Object#Object()
	 */
    public InvalidPAXSearchResultBean() {
    }

	/**
	 * Method getTravelAgentCode.
	 * @return String
	 */
    public String getTravelAgentCode() {
        return travelAgentCode;
    }

	/**
	 * Method setTravelAgentCode.
	 * @param travelAgentCode
	 */
    public void setTravelAgentCode(String travelAgentCode) {
        this.travelAgentCode = travelAgentCode;
    }

	/**
	 * Method getPaxLastName.
	 * @return String
	 */
    public String getPaxLastName() {
        return paxLastName;
    }

	/**
	 * Method setPaxLastName.
	 * @param paxLastName
	 */
    public void setPaxLastName(String paxLastName) {
        this.paxLastName = paxLastName;
    }

	/**
	 * Method getPaxFirstName.
	 * @return String
	 */
    public String getPaxFirstName() {
        return paxFirstName;
    }

	/**
	 * Method setPaxFirstName.
	 * @param paxFirstName
	 */
    public void setPaxFirstName(String paxFirstName) {
        this.paxFirstName = paxFirstName;
    }
	/**
	 * Returns the rejectionReasonList.
	 * @return ArrayList
	 */
	public ArrayList getRejectionReasonList()
	{
		return rejectionReasonList;
	}

	/**
	 * Sets the rejectionReasonList.
	 * @param rejectionReasonList The rejectionReasonList to set
	 */
	public void setRejectionReasonList(ArrayList rejectionReasonList)
	{
		this.rejectionReasonList = rejectionReasonList;
	}

	/**
	 * Returns the tourCode.
	 * @return String
	 */
	public String getTourCode()
	{
		return tourCode;
	}

	/**
	 * Sets the tourCode.
	 * @param tourCode The tourCode to set
	 */
	public void setTourCode(String tourCode)
	{
		this.tourCode = tourCode;
	}

	/**
	 * Returns the fileDate.
	 * @return String
	 */
	public String getFileDate()
	{
		return fileDate;
	}

	/**
	 * Returns the fileName.
	 * @return String
	 */
	public String getFileName()
	{
		return fileName;
	}

	/**
	 * Sets the fileDate.
	 * @param fileDate The fileDate to set
	 */
	public void setFileDate(String fileDate)
	{
		this.fileDate = fileDate;
	}

	/**
	 * Sets the fileName.
	 * @param fileName The fileName to set
	 */
	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate()
	{
		return fromDate;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate()
	{
		return toDate;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate)
	{
		this.fromDate = fromDate;
	}

	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate)
	{
		this.toDate = toDate;
	}

}
