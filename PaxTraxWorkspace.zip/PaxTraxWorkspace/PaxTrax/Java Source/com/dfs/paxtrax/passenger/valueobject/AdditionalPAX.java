package com.dfs.paxtrax.passenger.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 * 
 * The passenger value object
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 08/01/2005	Joseph			Created   
 */
public class AdditionalPAX extends PaxTraxValueObject
{

	private String paxLastName1 = null;
	private String paxLastName2 = null;
	private String paxLastName3 = null;
	private String paxLastName4 = null;
	private String paxLastName5 = null;
	private String paxLastName6 = null;
	private String paxFirstName1 = null;
	private String paxFirstName2 = null;
	private String paxFirstName3 = null;
	private String paxFirstName4 = null;
	private String paxFirstName5 = null;
	private String paxFirstName6 = null;
	/**
	 * Returns the paxFirstName1.
	 * @return String
	 */
	public String getPaxFirstName1()
	{
		return paxFirstName1;
	}

	/**
	 * Returns the paxFirstName2.
	 * @return String
	 */
	public String getPaxFirstName2()
	{
		return paxFirstName2;
	}

	/**
	 * Returns the paxFirstName3.
	 * @return String
	 */
	public String getPaxFirstName3()
	{
		return paxFirstName3;
	}

	/**
	 * Returns the paxFirstName4.
	 * @return String
	 */
	public String getPaxFirstName4()
	{
		return paxFirstName4;
	}

	/**
	 * Returns the paxFirstName5.
	 * @return String
	 */
	public String getPaxFirstName5()
	{
		return paxFirstName5;
	}

	/**
	 * Returns the paxFirstName6.
	 * @return String
	 */
	public String getPaxFirstName6()
	{
		return paxFirstName6;
	}

	/**
	 * Returns the paxLastName1.
	 * @return String
	 */
	public String getPaxLastName1()
	{
		return paxLastName1;
	}

	/**
	 * Returns the paxLastName2.
	 * @return String
	 */
	public String getPaxLastName2()
	{
		return paxLastName2;
	}

	/**
	 * Returns the paxLastName3.
	 * @return String
	 */
	public String getPaxLastName3()
	{
		return paxLastName3;
	}

	/**
	 * Returns the paxLastName4.
	 * @return String
	 */
	public String getPaxLastName4()
	{
		return paxLastName4;
	}

	/**
	 * Returns the paxLastName5.
	 * @return String
	 */
	public String getPaxLastName5()
	{
		return paxLastName5;
	}

	/**
	 * Returns the paxLastName6.
	 * @return String
	 */
	public String getPaxLastName6()
	{
		return paxLastName6;
	}

	/**
	 * Sets the paxFirstName1.
	 * @param paxFirstName1 The paxFirstName1 to set
	 */
	public void setPaxFirstName1(String paxFirstName1)
	{
		this.paxFirstName1 = paxFirstName1;
	}

	/**
	 * Sets the paxFirstName2.
	 * @param paxFirstName2 The paxFirstName2 to set
	 */
	public void setPaxFirstName2(String paxFirstName2)
	{
		this.paxFirstName2 = paxFirstName2;
	}

	/**
	 * Sets the paxFirstName3.
	 * @param paxFirstName3 The paxFirstName3 to set
	 */
	public void setPaxFirstName3(String paxFirstName3)
	{
		this.paxFirstName3 = paxFirstName3;
	}

	/**
	 * Sets the paxFirstName4.
	 * @param paxFirstName4 The paxFirstName4 to set
	 */
	public void setPaxFirstName4(String paxFirstName4)
	{
		this.paxFirstName4 = paxFirstName4;
	}

	/**
	 * Sets the paxFirstName5.
	 * @param paxFirstName5 The paxFirstName5 to set
	 */
	public void setPaxFirstName5(String paxFirstName5)
	{
		this.paxFirstName5 = paxFirstName5;
	}

	/**
	 * Sets the paxFirstName6.
	 * @param paxFirstName6 The paxFirstName6 to set
	 */
	public void setPaxFirstName6(String paxFirstName6)
	{
		this.paxFirstName6 = paxFirstName6;
	}

	/**
	 * Sets the paxLastName1.
	 * @param paxLastName1 The paxLastName1 to set
	 */
	public void setPaxLastName1(String paxLastName1)
	{
		this.paxLastName1 = paxLastName1;
	}

	/**
	 * Sets the paxLastName2.
	 * @param paxLastName2 The paxLastName2 to set
	 */
	public void setPaxLastName2(String paxLastName2)
	{
		this.paxLastName2 = paxLastName2;
	}

	/**
	 * Sets the paxLastName3.
	 * @param paxLastName3 The paxLastName3 to set
	 */
	public void setPaxLastName3(String paxLastName3)
	{
		this.paxLastName3 = paxLastName3;
	}

	/**
	 * Sets the paxLastName4.
	 * @param paxLastName4 The paxLastName4 to set
	 */
	public void setPaxLastName4(String paxLastName4)
	{
		this.paxLastName4 = paxLastName4;
	}

	/**
	 * Sets the paxLastName5.
	 * @param paxLastName5 The paxLastName5 to set
	 */
	public void setPaxLastName5(String paxLastName5)
	{
		this.paxLastName5 = paxLastName5;
	}

	/**
	 * Sets the paxLastName6.
	 * @param paxLastName6 The paxLastName6 to set
	 */
	public void setPaxLastName6(String paxLastName6)
	{
		this.paxLastName6 = paxLastName6;
	}

}