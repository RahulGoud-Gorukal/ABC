package com.dfs.paxtrax.passenger.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import java.util.ArrayList;


/**
 * 
 * The Action Form for the Search Travel Agent flow
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TravelAgentSearchForm extends PaxTraxActionForm {
	
	/** The Travel Agent Code */
	private String travelAgentCode = null;
	
	/** The Agency Name  */
	private String agencyName = null;
	
	/** The Travel Agency Owner  */
	private String agencyOwner = null;
	
	/** The City */
	private String city = null;
	
	/** The Collection that holds that TA search results  */
	private ArrayList travelAgents = null;

	/**
	 * Method getTravelAgentCode.
	 * @return String
	 */
	public String getTravelAgentCode() {
		return travelAgentCode;
	}

	/**
	 * Method setTravelAgentCode.
	 * @param travelAgentCode
	 */
	public void setTravelAgentCode(String travelAgentCode) {
		this.travelAgentCode = travelAgentCode;
	}

	/**
	 * Method getAgencyName.
	 * @return String
	 */
	public String getAgencyName() {
		return agencyName;
	}

	/**
	 * Method setAgencyName.
	 * @param agencyName
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	/**
	 * Method getAgencyOwner.
	 * @return String
	 */
	public String getAgencyOwner() {
		return agencyOwner;
	}

	/**
	 * Method setAgencyOwner.
	 * @param agencyOwner
	 */
	public void setAgencyOwner(String agencyOwner) {
		this.agencyOwner = agencyOwner;
	}

	/**
	 * Method getCity.
	 * @return String
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Method setCity.
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Method getTravelAgents.
	 * @return ArrayList
	 */
	public ArrayList getTravelAgents() {
		return travelAgents;
	}

	/**
	 * Method setTravelAgents.
	 * @param travelAgents
	 */
	public void setTravelAgents(ArrayList travelAgents) {
		this.travelAgents = travelAgents;
	}
}
