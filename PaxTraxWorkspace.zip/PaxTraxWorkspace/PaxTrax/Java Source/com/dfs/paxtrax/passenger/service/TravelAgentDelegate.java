package com.dfs.paxtrax.passenger.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.passenger.business.TravelAgentBO;
import com.dfs.paxtrax.passenger.business.TravelAgentBOHome;
import com.dfs.paxtrax.passenger.exception.TravelAgentException;
import com.dfs.paxtrax.passenger.valueobject.TravelAgentBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import javax.sql.DataSource;



/**
 * 
 * The Delagate that will route requests to the EJB tier of Travel Agent
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TravelAgentDelegate {

	public TravelAgentDelegate() {
	}

	/**
	 * Method saveTravelAgentDetails.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to create a Travel Agent record
	 */
	/**   */
	public void saveTravelAgentDetails(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException, TravelAgentException {
		try {
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::saveTravelAgentDetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =
				(TravelAgentBOHome) PortableRemoteObject.narrow(
					obj,
					TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			
			remote.saveTravelAgentDetails(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::saveTravelAgentDetails::End");
		} 
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::saveTravelAgentDetails",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::saveTravelAgentDetails",re);
			throw new PaxTraxSystemException(re);
		} 
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::saveTravelAgentDetails",ce);
			throw new PaxTraxSystemException(ce);
		}

	}

	/**
	 * Method getTravelAgentDetails.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @return TravelAgentBean
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to get a Travel Agent record based on the Travel Agent Code
	 */
	public TravelAgentBean getTravelAgentDetails(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException, TravelAgentException {
		try {
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::getTravelAgentDetails::Begin");
			
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =
				(TravelAgentBOHome) PortableRemoteObject.narrow(
					obj,
					TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			travelAgentBean = remote.getTravelAgentDetails(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::getTravelAgentDetails::End");
		}
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::getTravelAgentDetails",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::getTravelAgentDetails",re);
			throw new PaxTraxSystemException(re);
		} 
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::getTravelAgentDetails",ce);
			throw new PaxTraxSystemException(ce);
		}

		return (travelAgentBean);
	}

	/**
	 * Method updateTravelAgentDetails.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to update a Travel Agent record
	 */
	public void updateTravelAgentDetails(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException, TravelAgentException {
		try {

			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::updateTravelAgentDetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =
				(TravelAgentBOHome) PortableRemoteObject.narrow(
					obj,
					TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			remote.updateTravelAgentDetails(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::updateTravelAgentDetails::End");
		} 
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::updateTravelAgentDetails",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::updateTravelAgentDetails",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::updateTravelAgentDetails",ce);
			throw new PaxTraxSystemException(ce);
		}

	}

	/**
	 * Method deactivateTravelAgent.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to deactivate a Travel Agent
	 */
	public void deactivateTravelAgent(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException, TravelAgentException {
		try {
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::deactivateTravelAgent::Begin");
			
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =
				(TravelAgentBOHome) PortableRemoteObject.narrow(
					obj,
					TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			remote.deactivateTravelAgent(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::deactivateTravelAgent::End");
		} 
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::deactivateTravelAgent",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::deactivateTravelAgent",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::deactivateTravelAgent",ce);
			throw new PaxTraxSystemException(ce);
		}

	}

	/**
	 * Method searchTravelAgents.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to search for Travel Agent records based on the search criteria
	 */
	public ArrayList searchTravelAgents(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException, TravelAgentException {
		ArrayList taBeanList = new ArrayList();

		try {
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::searchTravelAgents::Begin");
			
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =
				(TravelAgentBOHome) PortableRemoteObject.narrow(
					obj,
					TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			taBeanList = remote.searchTravelAgents(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::searchTravelAgents::End");
			
		} 
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::searchTravelAgents",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::searchTravelAgents",re);
			throw new PaxTraxSystemException(re);
		} 
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::searchTravelAgents",ce);
			throw new PaxTraxSystemException(ce);
		}

		return (taBeanList);
	}

	/**
	 * Method postCodeLookup.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @return TravelAgentBean
	 * @throws PaxTraxSystemException
	 * The method to perform the postcode lookup
	 */
	public TravelAgentBean postCodeLookup(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException {
		try {
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::postCodeLookup::Begin");
			
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =
				(TravelAgentBOHome) PortableRemoteObject.narrow(
					obj,
					TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			travelAgentBean = remote.postCodeLookup(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::postCodeLookup::End");
		} 
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::postCodeLookup",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::postCodeLookup",re);
			throw new PaxTraxSystemException(re);
		} 
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::postCodeLookup",ce);
			throw new PaxTraxSystemException(ce);
		}

		return (travelAgentBean);
	}
	
 public TravelAgentBean getTaName(TravelAgentBean travelAgentBean)
		throws PaxTraxSystemException{
		try {
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::getTaName::Begin");
			
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.TA_BO_HOME_JNDI);
			TravelAgentBOHome home =(TravelAgentBOHome) PortableRemoteObject.narrow(obj,TravelAgentBOHome.class);
			TravelAgentBO remote = home.create();
			travelAgentBean = remote.getTaName(travelAgentBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentDelegate::getTaName::End");
		}
		catch (NamingException ne) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::getTaName",ne);
			throw new PaxTraxSystemException(ne);
		} 
		catch (RemoteException re) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::getTaName",re);
			throw new PaxTraxSystemException(re);
		} 
		catch (CreateException ce) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentDelegate::getTaName",ce);
			throw new PaxTraxSystemException(ce);
		}

		return (travelAgentBean);
	}


}
