package com.dfs.paxtrax.passenger.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.passenger.exception.PAXException;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.InvalidPAXSearchResultBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TAFileBean;

/**
 * 
 * The Remote Object for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public interface PAXBO extends javax.ejb.EJBObject
{
	/**
	 * Method savePAXDetails.
	 * 
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to create a PAX Record
	 */
	public PAXBean savePAXDetails(PAXBean paxBean) throws RemoteException, PaxTraxSystemException, PAXException;

	/**
	 * Method updatePAXDetails.
	 * 
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to update a PAX Record
	 */
	public PAXBean updatePAXDetails(PAXBean paxBean) throws RemoteException, PaxTraxSystemException, PAXException;

	/**
	 * Method searchInvalidPaxRecords.
	 * 
	 * @param paxBean PAXBean
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to search for Invalid PAX Records
	 */
	public ArrayList searchInvalidPaxRecords(InvalidPAXSearchResultBean invalidPAX) throws RemoteException, PaxTraxSystemException, PAXException;

	/**
	 * Method loadActiveTravelAgents.
	 * 
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to get the list of active Travel Agents
	 */
	public ArrayList loadActiveTravelAgents() throws RemoteException, PaxTraxSystemException, PAXException;

	/**
	 * Method searchPAXRecords.
	 * 
	 * @param paxBean PAXBean
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to get the PAX search results
	 */
	public ArrayList searchPAXRecords(PAXBean paxBean) throws RemoteException, PaxTraxSystemException, PAXException;

	/**
	 * Method postCodeLookup.
	 * 
	 * @param addrBean AddressBean
	 * @return AddressBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * The method to perform the postcode Lookup
	 */
	public AddressBean postCodeLookup(AddressBean addrBean) throws RemoteException, PaxTraxSystemException;

	/**
	 * Method uploadPAXFiles.
	 * 
	 * @param filesList ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * Method to upload Data from PAX Files
	 */
	public ArrayList uploadPAXFiles(ArrayList filesList, String userId) throws RemoteException, PaxTraxSystemException;

	/**
	 * Method getNextAutoPAXNumber.
	 * 
	 * @param String reportGroupId the report group id
	 * @return String
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public String getNextAutoPAXNumber(String reportGroupId) throws RemoteException, PAXException, PaxTraxSystemException;

	public void updatePAXNo(PAXBean paxBean) throws RemoteException, PaxTraxSystemException, PAXException;

	public ArrayList validateTA(ArrayList filesList) throws PaxTraxSystemException, RemoteException;

	public TAFileBean getFileTypeBean(String fileName) throws PaxTraxSystemException, RemoteException;

	public ArrayList insertPaxRecordFromTAFile(ArrayList paxList, String userId, TAFileBean taFileTypeBean) throws PaxTraxSystemException, RemoteException;

	public ArrayList getFTPParameters() throws PaxTraxSystemException, RemoteException;
	
	public ArrayList getMatchingTA(String taName) throws RemoteException, PaxTraxSystemException, PAXException;

	//Added for CR1832 starts
		public ArrayList getPaxChangesLog(String TEPOS)	throws RemoteException, PaxTraxSystemException;
//	Added for CR1832 ends

}
