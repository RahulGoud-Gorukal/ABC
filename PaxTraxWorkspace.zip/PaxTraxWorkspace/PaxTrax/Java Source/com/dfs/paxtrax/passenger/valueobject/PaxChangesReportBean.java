package com.dfs.paxtrax.passenger.valueobject;

/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList; 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
** @author Cognizant Technology Solutions
* 
* * @version    1.0
* * MOD HISTORY
* DATE          USER            COMMENTS
* 07/10/2010    Selvam		 	Created   
*/

public class PaxChangesReportBean extends PaxTraxValueObject {

	
	private String action = null;
	
	private String PaxNumber = null;
		
	private String nationality = null;
	
	private String location = null;
	
	private String terminal = null;
	
	private String name = null; //sales_type

	private String oldValue = null;
	
	private String newValue  = null;
	
	private String updatedUser = null;

	private String modifiedDate = null;
	/**
	 * @return
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @return
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return
	 */
	public String getNationality() {
		return nationality;
	}

	/**
	 * @return
	 */
	public String getLocation() {
		return location;
	}
	
	/**
	 * @return
	 */
	public String getTerminal() {
		return terminal;
	}
	
	/**
	 * @return
	 */
	public String getNewValue() {
		return newValue;
	}

	/**
	 * @return
	 */
	public String getOldValue() {
		return oldValue;
	}

	/**
	 * @return
	 */
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @return
	 */
	public String getPaxNumber() {
		return PaxNumber;
	}

	/**
	 * @param string
	 */
	public void setAction(String string) {
		action = string;
	}

	
	/**
	 * @param string
	 */
	public void setModifiedDate(String string) {
		modifiedDate = string;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		name = string;
	}

	/**
	 * @param string
	 */
	public void setNationality(String string) {
		nationality = string;
	}

	/**
	 * @param string
	 */
	public void setLocation(String string) {
		location = string;
	}
	
	/**
	 * @param string
	 */
	public void setTerminal(String string) {
		terminal = string;
	}
	
	/**
	 * @param string
	 */
	public void setNewValue(String string) {
		newValue = string;
	}

	/**
	 * @param string
	 */
	public void setOldValue(String string) {
		oldValue = string;
	}

	/**
	 * @param string
	 */
	public void setUpdatedUser(String string) {
		updatedUser = string;
	}

	
	/**
	 * @param string
	 */
	public void setPaxNumber(String string) {
		PaxNumber = string;
	}

}