package com.dfs.paxtrax.passenger.helpers;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.valueobject.AdditionalPAX;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TAFileBean;
import com.dfs.util.kanaroman.api.KanaStringToRoman;
import com.dfs.util.kanaroman.api.KanaToRomanException;

/**
* This Delegate  class is used for inserting and updating cage records
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 21/01/2005    Joseph Oommen A Created
*/
public class TAFileFTPHelper
{
	FTPClient ftpClient = null;

	public TAFileFTPHelper()
	{
	}

	public ArrayList transferFTPFiles(ArrayList taDetailsList) throws PaxTraxSystemException
	{
		ArrayList resultList = new ArrayList();
		ArrayList totalPaxList = null;
		ArrayList resultListFinal = null;
		for (int i = 0; i < taDetailsList.size(); i++)
		{
			TAFileBean taFileBean = (TAFileBean) taDetailsList.get(i);
			String taCode = taFileBean.getTaCode();
			try
			{

				ftpClient = new FTPClient();
				int reply;
				String locationIp = taFileBean.getFtpLocationIp();
				if (locationIp != null)
				{
					ftpClient.connect(taFileBean.getFtpLocationIp());
					reply = ftpClient.getReplyCode();

					if (!FTPReply.isPositiveCompletion(reply))
					{
						ftpClient.disconnect();

					}
					if (ftpClient.login(taFileBean.getFtpUserId(), taFileBean.getFtpUserPassword()))
					{

						//ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
						ftpClient.changeWorkingDirectory(taFileBean.getFtpSrcFolder());
						if (new File(taFileBean.getLocalDestFolder()).isDirectory() == false)
						{
							new File(taFileBean.getLocalDestFolder()).mkdir();
						}

						FTPFile[] files = ftpClient.listFiles();
						String remFileName = null;
						String localFileName = null;
						int len = 0;
						if (files != null)
							len = files.length;

						for (int j = 0; j < len; j++)
						{
							remFileName = taFileBean.getFtpSrcFolder() + files[j].getName();
							localFileName = taFileBean.getLocalDestFolder() + files[j].getName();

							OutputStream output;
							output = new FileOutputStream(localFileName);
							boolean result = ftpClient.retrieveFile(remFileName, output);

							if (result)
							{
								TAFileBean newBean = new TAFileBean();
								newBean.setLocalDestFolder(taFileBean.getLocalDestFolder());
								newBean.setFileName(files[j].getName());
								resultList.add(newBean);
								ftpClient.deleteFile(remFileName);
							}

						}

					}

					else
					{
					}
				}
				else
				{
				}
			}

			catch (IOException e)
			{
				e.printStackTrace();
				if (ftpClient.isConnected())
				{
					try
					{
						ftpClient.disconnect();
					}
					catch (IOException f)
					{
						e.printStackTrace();
					}
				}
			}
			finally
			{
				if (ftpClient.isConnected())
				{
					try
					{
						ftpClient.disconnect();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
		}
		return resultList;
	}

	public ArrayList readFile(TAFileBean taFileTypeBean, String userId) throws PaxTraxSystemException
	{
		String fileName = taFileTypeBean.getFileName();
		String field = null;
		ArrayList paxBeanList = null;
		String directory = taFileTypeBean.getLocalDestFolder();
		File iFile = new File(directory + fileName);

		String fileEncryptionType = taFileTypeBean.getFileEncryptionType();
		//fileEncryptionType ="UTF16";
		Reader fReader = null;
		BufferedReader bReader = null;
		PAXDelegate paxDelegate = new PAXDelegate();
		ArrayList paxPerFileList = new ArrayList();
		ArrayList totalPaxList = new ArrayList();
		PrintWriter printWriter = null;
		BufferedWriter bufferedWriter = null;
		File f = null;
		try
		{
			fReader = new InputStreamReader(new FileInputStream(iFile), fileEncryptionType);
			bReader = new BufferedReader(fReader);
			String line = bReader.readLine();
			paxBeanList = new ArrayList();
			boolean firstLine = true;
			ArrayList headerList = taFileTypeBean.getHeaderList();
			ArrayList detailsList = taFileTypeBean.getDetailsList();
			String footerIndicator = taFileTypeBean.getFooterIndicator();
			String delimitedFile = taFileTypeBean.getDelimitedFile();
			String delimiterUsed = taFileTypeBean.getDelimiterUsed();
			if (delimiterUsed != null)
			{
				delimiterUsed = delimiterUsed.trim();
			}
			StringTokenizer detailTokens = null;
			StringTokenizer headerTokens = null;

			while (line != null)
			{
				log(line);
				PAXBean paxBean = new PAXBean();
				if (firstLine && headerList != null && headerList.size() > 0)
				{
					/*if (headerDelimited.equals("Y"))
					{
						if (headerDelimiter.equals("\\t"))
						{
							headerTokens = new StringTokenizer(line, "\t");
						}
						else
							headerTokens = new StringTokenizer(line, headerDelimiter.trim());
					
						int countTokens = 0;
					
						for (int k = 0; k < headerList.size(); k++)
						{
							TravelAgentBean travelAgentBean = (TravelAgentBean) headerList.get(k);
					
							while (headerTokens.hasMoreTokens())
							{
								field = headerTokens.nextToken();
					
								countTokens++;
					
								if (countTokens == travelAgentBean.getStartIndexPosition())
								{
									getFieldMapping(travelAgentBean.getFieldCodeID(), field.trim());
									break;
								}
							}
						}
					}
					else
					{
						field = null;
					
						for (int j = 0; j < headerList.size(); j++)
						{
							TravelAgentBean travelAgentBean = (TravelAgentBean) headerList.get(j);
							field = line.substring(travelAgentBean.getStartIndexPosition() - 1, travelAgentBean.getEndPosition());
					
							getFieldMapping(travelAgentBean.getFieldCodeID(), field.trim());
						}
					}*/
					firstLine = false;
				}
				else
				{
					boolean processLine = true;

					if (footerIndicator != null)
					{
						footerIndicator = footerIndicator.trim();
						String lineIndicator = null;
						if (line.length() >= footerIndicator.length())
						{
							lineIndicator = line.substring(0, footerIndicator.length());
						}
						if (footerIndicator.equals(lineIndicator))
						{
							/* If required process footer */
							processLine = false;
							break;
						}
					}
					if (processLine)
					{

						if ("Y".equals(delimitedFile))
						{

							if ("\\t".equals(delimiterUsed))
							{
								line = replaceAll(line, "\t", " \t ");
								detailTokens = new StringTokenizer(line, "\t");
							}
							else if (",".equals(delimiterUsed))
							{
								line = replaceAll(line, ",", " , ");
								detailTokens = new StringTokenizer(line, delimiterUsed);
							}
							else
								detailTokens = new StringTokenizer(line, delimiterUsed);
							log(line);	
							int countTokens1 = 0;
							TAFileBean taFileBean = null;
							for (int k = 0; k < detailsList.size(); k++)
							{
								taFileBean = (TAFileBean) detailsList.get(k);

								while (detailTokens.hasMoreTokens())
								{
									field = detailTokens.nextToken();

									if (field != null)
									{
										field = field.replace('"', ' ');
										field = field.trim();
									}

									countTokens1++;

									log("Token is " + countTokens1 + "Field is  " + field);
									if (countTokens1 == taFileBean.getStartIndexPosition())
									{

										paxBean = getFieldMapping(taFileTypeBean, taFileBean.getFieldCodeID(), field, paxBean);

										break;
									}
								}
							}

						}
						else
						{
							for (int k = 0; k < detailsList.size(); k++)
							{
								TAFileBean taFileBean = (TAFileBean) detailsList.get(k);
								if (taFileBean.getEndPosition() != 0)
								{

									if ((line.length()) >= taFileBean.getEndPosition())
									{
										field = line.substring(taFileBean.getStartIndexPosition() - 1, taFileBean.getEndPosition());
									}
								}
								else
								{
									if ((line.length()) >= (taFileBean.getStartIndexPosition() - 1 + taFileBean.getLength()))
									{
										field =
											line.substring(
												taFileBean.getStartIndexPosition() - 1,
												taFileBean.getStartIndexPosition() - 1 + taFileBean.getLength());
									}
								}
								if (field != null)
								{
									field = field.replace('"', ' ');
									field = field.trim();
								}
								paxBean = getFieldMapping(taFileTypeBean, taFileBean.getFieldCodeID(), field, paxBean);
								//printPaxDetails(paxBean);
							}
						}
						//paxBean.setTaBranch(branchCode);
						paxBean.setTravelAgentCode(taFileTypeBean.getTaCode());
						AdditionalPAX additionalPAX = paxBean.getAdditionalPAX();
						String addPax = paxBean.getAddPax();
						log("addPax is " + addPax);
						if (!"F".equals(addPax))
						{
							if (additionalPAX != null)
							{

								String firstName1 = additionalPAX.getPaxFirstName1();
								String lastName1 = additionalPAX.getPaxLastName1();
								if (firstName1 != null && lastName1 != null)
								{
									log("firstName1 not null");
									paxBeanList.add(getDuplicatePaxBean(paxBean, lastName1, firstName1));
								}

								String firstName2 = additionalPAX.getPaxFirstName2();
								String lastName2 = additionalPAX.getPaxLastName2();
								if (firstName2 != null && lastName2 != null)
								{
									log("firstName2 not null");
									paxBeanList.add(getDuplicatePaxBean(paxBean, lastName2, firstName2));
								}

								String firstName3 = additionalPAX.getPaxFirstName3();
								String lastName3 = additionalPAX.getPaxLastName3();
								if (firstName3 != null && lastName3 != null)
								{
									log("firstName3 not null");
									paxBeanList.add(getDuplicatePaxBean(paxBean, lastName3, firstName3));
								}

								String firstName4 = additionalPAX.getPaxFirstName4();
								String lastName4 = additionalPAX.getPaxLastName4();
								if (firstName4 != null && lastName4 != null)
								{
									log("firstName4 not null");
									paxBeanList.add(getDuplicatePaxBean(paxBean, lastName4, firstName4));
								}

								String firstName5 = additionalPAX.getPaxFirstName5();
								String lastName5 = additionalPAX.getPaxLastName5();
								if (firstName5 != null && lastName5 != null)
								{
									log("firstName5 not null");
									paxBeanList.add(getDuplicatePaxBean(paxBean, lastName5, firstName5));
								}

								String firstName6 = additionalPAX.getPaxFirstName6();
								String lastName6 = additionalPAX.getPaxLastName6();
								if (firstName6 != null && lastName6 != null)
								{
									log("firstName6 not null");
									paxBeanList.add(getDuplicatePaxBean(paxBean, lastName6, firstName6));
								}
							}
							else
								paxBeanList.add(paxBean);
						}

						if (paxBeanList.size() >= 25)
						{
							totalPaxList.addAll(paxBeanList);
							ArrayList tempList = paxDelegate.insertPaxRecordFromTAFile(paxBeanList, userId, taFileTypeBean);
							if (tempList != null && tempList.size() > 0)
								paxPerFileList.addAll(tempList);
							paxBeanList.clear();
						}

					}

				}

				line = bReader.readLine();
			}
			if (paxBeanList.size() > 0)
			{
				totalPaxList.addAll(paxBeanList);
				ArrayList tempList = paxDelegate.insertPaxRecordFromTAFile(paxBeanList, userId, taFileTypeBean);
				if (tempList != null && tempList.size() > 0)
					paxPerFileList.addAll(tempList);
				paxBeanList.clear();
			}

			String logFolder = taFileTypeBean.getLogFolder();
			if (logFolder != null)
			{
				if (new File(logFolder).isDirectory() == false)
				{
					new File(taFileTypeBean.getLogFolder()).mkdir();
				}
				f = new File(taFileTypeBean.getLogFolder() + "/log.txt");

				if (f.length() > 999999999)
				{
					bufferedWriter = new BufferedWriter(new FileWriter(taFileTypeBean.getLogFolder() + "/log.txt", false));
				}
				else
				{
					bufferedWriter = new BufferedWriter(new FileWriter(taFileTypeBean.getLogFolder() + "/log.txt", true));
				}
				printWriter = new PrintWriter(bufferedWriter);
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
				printWriter.println("Upload Time is " + dateFormat.format(cal.getTime()));
				printWriter.println("File name is " + fileName);
				printWriter.println("Total Pax records exists in the file " + totalPaxList.size());
				printWriter.println("No: of Pax records uploaded succesfully " + paxPerFileList.size());
				printWriter.println("***********************************");

			}
			totalPaxList.clear();
		}

		catch (IOException ioexception)
		{
			ioexception.printStackTrace();
			throw new PaxTraxSystemException(ioexception);
		}
		finally
		{
			try
			{
				if (bufferedWriter != null)
				{
					bufferedWriter.close();
					bufferedWriter = null;
				}
				if (printWriter != null)
				{
					printWriter.close();
					printWriter = null;
				}
			}
			catch (IOException ioexception)
			{
			}
		}
		return paxPerFileList;
	}

	private PAXBean getDuplicatePaxBean(PAXBean paxBean, String lastName, String firstName)
	{
		PAXBean newPaxBean = new PAXBean();
		newPaxBean.setAddress(paxBean.getAddress());
		newPaxBean.setArrivalFlightDetails(paxBean.getArrivalFlightDetails());
		newPaxBean.setDepartureFlightDetails(paxBean.getDepartureFlightDetails());

		newPaxBean.setFirstName(firstName);
		newPaxBean.setLastName(lastName);
		newPaxBean.setPaxNumber(paxBean.getPaxNumber());
		newPaxBean.setPrimaryPaxFirstName(paxBean.getPrimaryPaxFirstName());
		newPaxBean.setPrimaryPaxLastName(paxBean.getPrimaryPaxLastName());
		newPaxBean.setTaBranch(paxBean.getTaBranch());
		newPaxBean.setTourCode(paxBean.getTourCode());
		newPaxBean.setTravelAgentCode(paxBean.getTravelAgentCode());
		newPaxBean.setUploadDate(paxBean.getUploadDate());
		newPaxBean.setUser(paxBean.getUser());
		return newPaxBean;
	}

	private PAXBean getFieldMapping(TAFileBean tafileTypeBean, int fieldCodeID, String field, PAXBean paxBean)
	{
		KanaStringToRoman kstr = null;

		String fieldValue = getFieldType(tafileTypeBean.getFieldDetails(), fieldCodeID);

		try
		{

			switch (fieldCodeID)
			{
				case 1 :
					{
						paxBean.setTravelAgentCode(tafileTypeBean.getTaCode());
						break;
					}

				case 2 :
					{
						paxBean.setUploadDate(field);
						break;
					}

				case 3 :
					{

						if (field != null && field.length() > 20)
							field = field.substring(0, 20);
						if (field != null && field.length() > 0)
							paxBean.setTaBranch(field);
						break;
					}

				case 4 :
					{
						kstr = KanaStringToRoman.getInstance();

						String lastName = kstr.convert(field);
						if (lastName != null && lastName.length() > 30)
							lastName = lastName.substring(0, 30);
						if (lastName != null && lastName.length() > 0)
							paxBean.setLastName(lastName);
						break;
					}

				case 5 :
					{
						kstr = KanaStringToRoman.getInstance();

						String firstName = kstr.convert(field);
						if (firstName != null && firstName.length() > 30)
							firstName = firstName.substring(0, 30);
						if (firstName != null && firstName.length() > 0)
							paxBean.setFirstName(firstName);
						break;
					}

				case 6 :
					{

						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						if (flightDetailsBean == null)
							flightDetailsBean = new FlightDetailsBean();
						paxBean.setArrivalFlightDetails(getFlightDetails(tafileTypeBean, field, flightDetailsBean));
						break;
					}

				case 7 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						if (flightDetailsBean == null)
							flightDetailsBean = new FlightDetailsBean();
						flightDetailsBean.setDate(formatDateValue(tafileTypeBean, field));
						paxBean.setArrivalFlightDetails(flightDetailsBean);
						break;
					}

				case 8 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
						if (flightDetailsBean == null)
							flightDetailsBean = new FlightDetailsBean();
						paxBean.setDepartureFlightDetails(getFlightDetails(tafileTypeBean, field, flightDetailsBean));
						break;
					}

				case 9 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
						if (flightDetailsBean == null)
							flightDetailsBean = new FlightDetailsBean();
						flightDetailsBean.setDate(formatDateValue(tafileTypeBean, field));
						paxBean.setDepartureFlightDetails(flightDetailsBean);
						break;
					}

				case 10 :
					{
						kstr = KanaStringToRoman.getInstance();
						String primaryLastName = kstr.convert(field);
						if (primaryLastName != null && primaryLastName.length() > 30)
						{
							primaryLastName = primaryLastName.substring(0, 30);
						}

						if (primaryLastName != null && primaryLastName.length() > 00)
							paxBean.setPrimaryPaxLastName(primaryLastName);

						break;
					}

				case 11 :
					{
						kstr = KanaStringToRoman.getInstance();
						String primaryFirstName = kstr.convert(field);
						if (primaryFirstName != null && primaryFirstName.length() > 30)
						{
							primaryFirstName = primaryFirstName.substring(0, 30);
						}

						if (primaryFirstName != null && primaryFirstName.length() > 00)
							paxBean.setPrimaryPaxFirstName(primaryFirstName);

						break;
					}

				case 12 :
					{
						break;
					}

				case 13 :
					{
						break;
					}

				case 14 :
					{

						AddressBean addressBean = paxBean.getAddress();
						if (addressBean == null)
							addressBean = new AddressBean();

						if (field != null && field.length() > 10)
						{

							field = field.substring(0, 10);

						}
						if (field != null)
						{
							StringBuffer str = new StringBuffer(field);
							int id = str.toString().indexOf('-');
							if (id != -1)
							{
								str.deleteCharAt(id);
							}

							if (field.length() > 0)
								addressBean.setPostCodePrefix(str.toString());
						}
						paxBean.setAddress(addressBean);

						break;
					}
				case 15 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();

						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "Y", field);
						paxBean.setDepartureFlightDetails(flightDetailsBean);
						break;

					}
				case 16 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "M", field);
						paxBean.setDepartureFlightDetails(flightDetailsBean);
						break;

					}
				case 17 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "D", field);
						paxBean.setDepartureFlightDetails(flightDetailsBean);
						break;

					}
				case 18 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "Y", field);
						paxBean.setArrivalFlightDetails(flightDetailsBean);
						break;

					}
				case 19 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "M", field);
						paxBean.setArrivalFlightDetails(flightDetailsBean);
						break;

					}
				case 20 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "D", field);
						paxBean.setArrivalFlightDetails(flightDetailsBean);
						break;

					}
				case 21 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						flightDetailsBean = getFlightDetailsBean("AIRLINECODE", field, flightDetailsBean);
						paxBean.setArrivalFlightDetails(flightDetailsBean);
						break;

					}
				case 22 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
						flightDetailsBean = getFlightDetailsBean("FLIGHTNUMBER", field, flightDetailsBean);
						paxBean.setArrivalFlightDetails(flightDetailsBean);
						break;

					}
				case 23 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
						flightDetailsBean = getFlightDetailsBean("AIRLINECODE", field, flightDetailsBean);
						paxBean.setDepartureFlightDetails(flightDetailsBean);
						break;

					}
				case 24 :
					{
						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
						flightDetailsBean = getFlightDetailsBean("FLIGHTNUMBER", field, flightDetailsBean);
						paxBean.setDepartureFlightDetails(flightDetailsBean);
						break;

					}
				case 25 :
					{
						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 1));

						break;

					}
				case 26 :
					{

						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 2));
						break;

					}
				case 27 :
					{
						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 3));

						break;

					}
				case 28 :
					{
						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 4));
						break;

					}
				case 29 :
					{
						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 5));
						break;

					}
				case 30 :
					{
						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 6));
						break;

					}
				case 31 :
					{
						kstr = KanaStringToRoman.getInstance();
						String additionalPaxLastName1 = kstr.convert(field);
						if (additionalPaxLastName1 != null && additionalPaxLastName1.length() > 30)
						{
							additionalPaxLastName1 = additionalPaxLastName1.substring(0, 30);
						}
						AdditionalPAX additionalPAX = paxBean.getAdditionalPAX();

						if (additionalPAX == null)
							additionalPAX = new AdditionalPAX();

						if (additionalPaxLastName1 != null && additionalPaxLastName1.length() > 00)
						{
							additionalPAX.setPaxLastName1(additionalPaxLastName1);
							paxBean.setAdditionalPAX(additionalPAX);
						}

						break;

					}
				case 32 :
					{
						kstr = KanaStringToRoman.getInstance();
						String additionalPaxFirstName1 = kstr.convert(field);
						if (additionalPaxFirstName1 != null && additionalPaxFirstName1.length() > 30)
						{
							additionalPaxFirstName1 = additionalPaxFirstName1.substring(0, 30);
						}
						AdditionalPAX additionalPAX = paxBean.getAdditionalPAX();

						if (additionalPAX == null)
							additionalPAX = new AdditionalPAX();

						if (additionalPaxFirstName1 != null && additionalPaxFirstName1.length() > 00)
						{
							additionalPAX.setPaxFirstName1(additionalPaxFirstName1);
							paxBean.setAdditionalPAX(additionalPAX);
						}

						break;

					}
				case 33 :
					{
						kstr = KanaStringToRoman.getInstance();
						String additionalPaxLastName2 = kstr.convert(field);
						if (additionalPaxLastName2 != null && additionalPaxLastName2.length() > 30)
						{
							additionalPaxLastName2 = additionalPaxLastName2.substring(0, 30);
						}
						AdditionalPAX additionalPAX = paxBean.getAdditionalPAX();

						if (additionalPAX == null)
							additionalPAX = new AdditionalPAX();

						if (additionalPaxLastName2 != null && additionalPaxLastName2.length() > 00)
						{
							additionalPAX.setPaxLastName2(additionalPaxLastName2);
							paxBean.setAdditionalPAX(additionalPAX);
						}

						break;

					}
				case 34 :
					{
						kstr = KanaStringToRoman.getInstance();
						String additionalPaxFirstName2 = kstr.convert(field);
						if (additionalPaxFirstName2 != null && additionalPaxFirstName2.length() > 30)
						{
							additionalPaxFirstName2 = additionalPaxFirstName2.substring(0, 30);
						}
						AdditionalPAX additionalPAX = paxBean.getAdditionalPAX();

						if (additionalPAX == null)
							additionalPAX = new AdditionalPAX();

						if (additionalPaxFirstName2 != null && additionalPaxFirstName2.length() > 00)
						{
							additionalPAX.setPaxFirstName2(additionalPaxFirstName2);
							paxBean.setAdditionalPAX(additionalPAX);
						}

						break;

					}
				case 35 :
					{

						if (field != null)
						{
							int len = field.length();
							if (len > 4)
							{
								field = field.substring(field.length() - 4, field.length());
							}
							else if (len < 4)
							{
								for (int i = len; i < 4; i++)
								{
									field = "0" + field;
								}

							}
							paxBean.setTaBranch(field);
						}
						break;
					}

				case 36 :
					{
						if (field != null)
						{
							log("Field is " + field);
							field = field.trim();
							if (!"OKA".equalsIgnoreCase(field))
								paxBean.setAddPax("F");
						}
						break;
					}
				case 37 :
					{

						AddressBean addressBean = paxBean.getAddress();
						if (addressBean == null)
							addressBean = new AddressBean();

						if (field != null)
						{

							kstr = KanaStringToRoman.getInstance();
							field = kstr.convert(field);
							if (field.length() > 25)
								field = field.substring(0, 25);

							addressBean.setAddressLine1(field);
						}
						paxBean.setAddress(addressBean);

						break;
					}
				case 38 :
					{

						AddressBean addressBean = paxBean.getAddress();
						if (addressBean == null)
							addressBean = new AddressBean();

						if (field != null)
						{

							kstr = KanaStringToRoman.getInstance();
							field = kstr.convert(field);
							if (field.length() > 25)
								field = field.substring(0, 25);

							addressBean.setAddressLine2(field);
						}
						paxBean.setAddress(addressBean);

						break;
					}
				case 39 :
					{

						AddressBean addressBean = paxBean.getAddress();
						if (addressBean == null)
							addressBean = new AddressBean();

						if (field != null)
						{

							kstr = KanaStringToRoman.getInstance();
							field = kstr.convert(field);
							if (field.length() > 25)
								field = field.substring(0, 25);

							addressBean.setCity(field);
						}
						paxBean.setAddress(addressBean);

						break;
					}
				case 40 :
					{

						AddressBean addressBean = paxBean.getAddress();
						if (addressBean == null)
							addressBean = new AddressBean();

						if (field != null)
						{

							kstr = KanaStringToRoman.getInstance();
							field = kstr.convert(field);
							if (field.length() > 25)
								field = field.substring(0, 25);

							addressBean.setCountry(field);
						}
						paxBean.setAddress(addressBean);

						break;
					}

			}
		}
		catch (KanaToRomanException ke)
		{
			PaxTraxLog.logError("IOException in finally block in PaxTrax::PAXDAO::uploadPAXFiles " + ke);
		}

		if (kstr != null)
			kstr = null;
		return paxBean;

	}

	private AdditionalPAX getAdditionalPax(AdditionalPAX additionalPAX, String field, int index) throws KanaToRomanException
	{
		KanaStringToRoman kstr = KanaStringToRoman.getInstance();
		if (additionalPAX == null)
			additionalPAX = new AdditionalPAX();
		if (field != null && field.indexOf(" ") != -1)
		{
			StringTokenizer str = new StringTokenizer(field, " ");
			/* The order of name retreival from this String has been changed from First-Last to Last-First Name */
			String lastName = kstr.convert(str.nextToken());
			if (lastName != null && lastName.length() > 30)
				lastName = lastName.substring(0, 30);
			String firstName = kstr.convert(str.nextToken());
			if (firstName != null && firstName.length() > 30)
				firstName = firstName.substring(0, 30);

			switch (index)
			{
				case 1 :

					additionalPAX.setPaxFirstName1(firstName);
					additionalPAX.setPaxLastName1(lastName);
					break;
				case 2 :

					additionalPAX.setPaxFirstName2(firstName);
					additionalPAX.setPaxLastName2(lastName);
					break;
				case 3 :

					additionalPAX.setPaxFirstName3(firstName);
					additionalPAX.setPaxLastName3(lastName);
					break;
				case 4 :

					additionalPAX.setPaxFirstName4(firstName);
					additionalPAX.setPaxLastName4(lastName);
					break;
				case 5 :

					additionalPAX.setPaxFirstName5(firstName);
					additionalPAX.setPaxLastName5(lastName);
					break;
				case 6 :

					additionalPAX.setPaxFirstName6(firstName);
					additionalPAX.setPaxLastName6(lastName);
					break;

			}
		}
		return additionalPAX;
	}
	private FlightDetailsBean getFlightDetails(TAFileBean taFileTypeBean, String airLineFlightNumber, FlightDetailsBean flightDetailsBean)
	{

		String airLineValue = null;
		String flightNumber = null;

		if (PaxTraxConstants.AIRLINE_VALUE_REFERRED_TO_NACCS.equals(taFileTypeBean.getAirLineValueType()))
		{
			if (airLineFlightNumber != null && airLineFlightNumber.length() > 3)
			{
				airLineValue = airLineFlightNumber.substring(0, 3);
				flightNumber = airLineFlightNumber.substring(3);
			}
		}
		if (PaxTraxConstants.AIRLINE_VALUE_REFERRED_TO_VALUE.equals(taFileTypeBean.getAirLineValueType()))
		{
			if (airLineFlightNumber != null && airLineFlightNumber.length() > 2)
			{
				airLineValue = airLineFlightNumber.substring(0, 2);
				flightNumber = airLineFlightNumber.substring(2);
			}
		}

		if (airLineValue != null && airLineValue.length() > 5)
			airLineValue = airLineValue.substring(0, 5);
		flightDetailsBean.setAirlineCodeValue(airLineValue);

		if (flightNumber != null && flightNumber.length() > 5)
			flightNumber = flightNumber.substring(0, 5);
		flightDetailsBean.setFlightNumber(flightNumber);
		return flightDetailsBean;
	}

	private FlightDetailsBean getFlightDetailsBean(String field, String value, FlightDetailsBean flightDetailsBean)
	{

		if (value != null && value.length() > 5)
			value = value.substring(0, 5);
		if ("AIRLINECODE".equals(field))
		{

			flightDetailsBean.setAirlineCodeValue(value);
		}
		else
		{
			flightDetailsBean.setFlightNumber(value);
		}
		return flightDetailsBean;
	}
	private FlightDetailsBean getDateCalendarObject(FlightDetailsBean flightDetailsBean, String dateVaribale, String value)
	{

		if (flightDetailsBean == null)
			flightDetailsBean = new FlightDetailsBean();

		String date = flightDetailsBean.getDate();

		StringBuffer flightDate = null;
		if (date == null)
		{
			flightDate = new StringBuffer("9999-99-99");
		}
		else
		{
			flightDate = new StringBuffer(date);
		}

		int dateValue = 0;
		try
		{
			dateValue = Integer.parseInt(value);
			if ("M".equals(dateVaribale))
			{
				if (dateValue < 10)
				{
					flightDate.replace(5, 7, "0" + dateValue);

				}
				else
				{
					flightDate.replace(5, 7, dateValue + "");
				}
			}
			if ("D".equals(dateVaribale))
			{
				if (dateValue < 10)
				{
					flightDate.replace(8, 10, "0" + dateValue);

				}
				else
				{
					flightDate.replace(8, 10, dateValue + "");
				}
			}
			if ("Y".equals(dateVaribale))
			{

				flightDate.replace(0, 4, dateValue + "");
			}
			flightDetailsBean.setDate(flightDate.toString());
		}
		catch (NumberFormatException e)
		{
			flightDate = null;
			flightDetailsBean.setDate(null);
		}

		return flightDetailsBean;
	}

	private String getDateTokenValue(String dateValue, int index)
	{
		StringTokenizer str = new StringTokenizer(dateValue, "/");
		int count = 0;
		String tokenValue = null;
		while (str.hasMoreTokens())
		{
			count++;
			String token = str.nextToken();
			if (count == index)
			{
				tokenValue = token;
				if (tokenValue != null && tokenValue.length() == 1)
				{
					tokenValue = "0" + tokenValue;
				}

				break;
			}

		}
		return tokenValue;
	}
	private String formatDateValue(TAFileBean taFileTypeBean, String dateValue)
	{
		String formattedDate = null;
		String dateFormat = taFileTypeBean.getDateType();
		dateFormat = dateFormat.toUpperCase();
		String year = null, month = null, day = null;
		if (dateFormat.indexOf("/") == -1)
		{
			int yearStartIndex = dateFormat.indexOf("YYYY");
			int monthStartIndex = dateFormat.indexOf("MM");
			int dayStartIndex = dateFormat.indexOf("DD");

			if (dateValue != null && dateValue.length() >= yearStartIndex + 4)
				year = dateValue.substring(yearStartIndex, yearStartIndex + 4);
			if (dateValue != null && dateValue.length() >= monthStartIndex + 2)
				month = dateValue.substring(monthStartIndex, monthStartIndex + 2);
			if (dateValue != null && dateValue.length() >= dayStartIndex + 2)
				day = dateValue.substring(dayStartIndex, dayStartIndex + 2);

		}
		else
		{
			StringTokenizer str = new StringTokenizer(dateFormat, "/");
			int count = 0;
			while (str.hasMoreTokens())
			{
				count++;
				String token = str.nextToken();
				if ("DD".equals(token))
				{
					day = getDateTokenValue(dateValue, count);
				}
				if ("MM".equals(token))
				{
					month = getDateTokenValue(dateValue, count);
				}
				if ("YYYY".equals(token))
				{
					year = getDateTokenValue(dateValue, count);
				}

			}

		}
		if (year != null && month != null && day != null)
			return (year + "-" + month + "-" + day);
		else
			return null;

	}
	private String getFieldType(ArrayList list, int index)
	{
		String returnValue = null;
		if (list != null)
		{
			for (int i = 0; i < list.size(); i++)
			{
				ReferenceDataBean referenceDataBean = (ReferenceDataBean) list.get(i);
				if (Integer.parseInt(referenceDataBean.getCodeId()) == index)
				{
					returnValue = referenceDataBean.getCodeValue();
					break;
				}
			}
		}
		return returnValue;
	}

	private String replaceAll(String sourceString, String replace, String with)
	{
		if (sourceString == null || replace == null || with == null || "".equals(replace))
		{
			return sourceString;
		}

		StringBuffer buf = new StringBuffer(sourceString.length());
		int start = 0, end = 0;
		while ((end = sourceString.indexOf(replace, start)) != -1)
		{
			buf.append(sourceString.substring(start, end)).append(with);
			start = end + replace.length();
		}
		buf.append(sourceString.substring(start));
		return buf.toString();
	}

	private void log(String s)
	{
		//System.out.println(s);
	}
}