package com.dfs.paxtrax.passenger.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;


/**
 * 
 * The Action Form used for the PAX Search
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXSearchForm extends PaxTraxActionForm
{
	//Added for commtrax
	private PAXBean visitPax = null;
	
	/** The Last Name */
	private String lastName = null;

	/** The First Name */
	private String firstName = null;

	/** The Postcode Prefix  */
	private String postCodePrefix = null;

	/** The Postcode Suffix  */
	private String postCodeSuffix = null;

	/** The Telephone Number  */
	private String telephoneNumber = null;

	/** The Departure Airline Code  */
	private String departureAirlineCode = null;

	/** The Departure Flight Number  */
	private String departureFlightNumber = null;

	/** The Arrival Airline Code  */
	private String arrivalAirlineCode = null;

	/** The Arrival Flight Number  */
	private String arrivalFlightNumber = null;

	/** The Departure Flight Date  */
	private String departureFlightDate = null;

	/** The Arrival Flight Date  */
	private String arrivalFlightDate = null;

	/** The Travel Agent Code  */
	private String travelAgentCode = null;

	/** The Collection which will hold all the search results */
	private ArrayList paxDetails = null;

	/** The list od Airline Code values  */
	private ArrayList airlineCodeList = null;

	/** The Arrival Airline Code Reference Id  */
	private String arrivalAirlineCodeRefId = null;

	/** The Departure Airline Code Reference Id */
	private String departureAirlineCodeRefId = null;
	
	private String paxNumber =null;

	/**
	 * Method getLastName.
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Method setLastName.
	 * @param lastName
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Method getFirstName.
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Method setFirstName.
	 * @param firstName
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Method getPostCodePrefix.
	 * @return String
	 */
	public String getPostCodePrefix()
	{
		return postCodePrefix;
	}

	/**
	 * Method setPostCodePrefix.
	 * @param postCodePrefix
	 */
	public void setPostCodePrefix(String postCodePrefix)
	{
		this.postCodePrefix = postCodePrefix;
	}

	/**
	 * Method getPostCodeSuffix.
	 * @return String
	 */
	public String getPostCodeSuffix()
	{
		return postCodeSuffix;
	}

	/**
	 * Method setPostCodeSuffix.
	 * @param postCodeSuffix
	 */
	public void setPostCodeSuffix(String postCodeSuffix)
	{
		this.postCodeSuffix = postCodeSuffix;
	}

	/**
	 * Method getTelephoneNumber.
	 * @return String
	 */
	public String getTelephoneNumber()
	{
		return telephoneNumber;
	}

	/**
	 * Method setTelephoneNumber.
	 * @param telephoneNumber
	 */
	public void setTelephoneNumber(String telephoneNumber)
	{
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * Method getDepartureAirlineCode.
	 * @return String
	 */
	public String getDepartureAirlineCode()
	{
		return departureAirlineCode;
	}

	/**
	 * Method setDepartureAirlineCode.
	 * @param departureAirlineCode
	 */
	public void setDepartureAirlineCode(String departureAirlineCode)
	{
		this.departureAirlineCode = departureAirlineCode;
	}

	/**
	 * Method getDepartureFlightNumber.
	 * @return String
	 */
	public String getDepartureFlightNumber()
	{
		return departureFlightNumber;
	}

	/**
	 * Method setDepartureFlightNumber.
	 * @param departureFlightNumber
	 */
	public void setDepartureFlightNumber(String departureFlightNumber)
	{
		this.departureFlightNumber = departureFlightNumber;
	}

	/**
	 * Method getArrivalAirlineCode.
	 * @return String
	 */
	public String getArrivalAirlineCode()
	{
		return arrivalAirlineCode;
	}

	/**
	 * Method setArrivalAirlineCode.
	 * @param arrivalAirlineCode
	 */
	public void setArrivalAirlineCode(String arrivalAirlineCode)
	{
		this.arrivalAirlineCode = arrivalAirlineCode;
	}

	/**
	 * Method getArrivalFlightNumber.
	 * @return String
	 */
	public String getArrivalFlightNumber()
	{
		return arrivalFlightNumber;
	}

	/**
	 * Method setArrivalFlightNumber.
	 * @param arrivalFlightNumber
	 */
	public void setArrivalFlightNumber(String arrivalFlightNumber)
	{
		this.arrivalFlightNumber = arrivalFlightNumber;
	}

	/**
	 * Method getDepartureFlightDate.
	 * @return String
	 */
	public String getDepartureFlightDate()
	{
		return departureFlightDate;
	}

	/**
	 * Method setDepartureFlightDate.
	 * @param departureFlightDate
	 */
	public void setDepartureFlightDate(String departureFlightDate)
	{
		this.departureFlightDate = departureFlightDate;
	}

	/**
	 * Method getArrivalFlightDate.
	 * @return String
	 */
	public String getArrivalFlightDate()
	{
		return arrivalFlightDate;
	}

	/**
	 * Method setArrivalFlightDate.
	 * @param arrivalFlightDate
	 */
	public void setArrivalFlightDate(String arrivalFlightDate)
	{
		this.arrivalFlightDate = arrivalFlightDate;
	}

	/**
	 * Method getTravelAgentCode.
	 * @return String
	 */
	public String getTravelAgentCode()
	{
		return travelAgentCode;
	}

	/**
	 * Method setTravelAgentCode.
	 * @param travelAgentCode
	 */
	public void setTravelAgentCode(String travelAgentCode)
	{
		this.travelAgentCode = travelAgentCode;
	}

	/**
	 * Method getPaxDetails.
	 * @return ArrayList
	 */
	public ArrayList getPaxDetails()
	{
		return paxDetails;
	}

	/**
	 * Method setPaxDetails.
	 * @param paxDetails
	 */
	public void setPaxDetails(ArrayList paxDetails)
	{
		this.paxDetails = paxDetails;
	}
	/**
	 * Returns the airlineCodeList.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodeList()
	{
		return airlineCodeList;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setAirlineCodeList(ArrayList airlineCodeList)
	{
		this.airlineCodeList = airlineCodeList;
	}

	/**
	 * Returns the arrivalAirlineCodeRefId.
	 * @return String
	 */
	public String getArrivalAirlineCodeRefId()
	{
		return arrivalAirlineCodeRefId;
	}

	/**
	 * Returns the departureAirlineCodeRefId.
	 * @return String
	 */
	public String getDepartureAirlineCodeRefId()
	{
		return departureAirlineCodeRefId;
	}

	/**
	 * Sets the arrivalAirlineCodeRefId.
	 * @param arrivalAirlineCodeRefId The arrivalAirlineCodeRefId to set
	 */
	public void setArrivalAirlineCodeRefId(String arrivalAirlineCodeRefId)
	{
		this.arrivalAirlineCodeRefId = arrivalAirlineCodeRefId;
	}

	/**
	 * Sets the departureAirlineCodeRefId.
	 * @param departureAirlineCodeRefId The departureAirlineCodeRefId to set
	 */
	public void setDepartureAirlineCodeRefId(String departureAirlineCodeRefId)
	{
		this.departureAirlineCodeRefId = departureAirlineCodeRefId;
	}

	/**
	 * Returns the paxNumber.
	 * @return String
	 */
	public String getPaxNumber()
	{
		return paxNumber;
	}

	/**
	 * Sets the paxNumber.
	 * @param paxNumber The paxNumber to set
	 */
	public void setPaxNumber(String paxNumber)
	{
		this.paxNumber = paxNumber;
	}

	/**
	 * Returns the visitPax.
	 * @return PAXBean
	 */
	public PAXBean getVisitPax()
	{
		return visitPax;
	}

	/**
	 * Sets the visitPax.
	 * @param visitPax The visitPax to set
	 */
	public void setVisitPax(PAXBean visitPax)
	{
		this.visitPax = visitPax;
	}

	public void reset(ActionMapping mapping,HttpServletRequest request)
	{
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
		{
			if (page.equals("searchPAX"))
			{
				if (paxDetails != null)
				{
					int size = paxDetails.size();
					PAXBean pax = null;
					for (int i = 0;i < size;i++)
					{	
						pax = (PAXBean)paxDetails.get(i);
						pax.setAddPax("N");
						paxDetails.remove(i);
						paxDetails.add(i,pax);
					}
				}
			}
		}
	}
}
