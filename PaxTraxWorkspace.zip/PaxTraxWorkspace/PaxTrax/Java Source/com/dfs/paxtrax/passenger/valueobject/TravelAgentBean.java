package com.dfs.paxtrax.passenger.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * 
 * The Travel Agent value object
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TravelAgentBean extends PaxTraxValueObject {
	/**
	   Unique code that identifies a TravelAgent
	 */
	private String travelAgentCode = null;
	/**
	   Contact person for this Agency
	 */
	private String contactPerson = null;
	/**
	   Name of the Agency
	 */
	private String agencyName = null;
	/**
	   Agency owner Name
	 */
	private String agencyOwner = null;
	/**
	   prefix for the post code
	 */
	private String postCodePrefix = null;
	/**
	   suffix for the post code
	 */
	private String postCodeSuffix = null;
	/**
	   Address Line 1 of the travelagent
	 */
	private String addressLine1 = null;
	/**
	   Address Line 2 of the travelagent
	 */
	private String addressLine2 = null;
	/**
	   City name
	 */
	private String city = null;
	/**
	   Country Code
	 */
	private String country = null;

	/**
	  	Country Reference Id 
	*/
	private String countryRefId = null;

	/** Country Value */
	private String countryValue = null;

	/** The telephone Number */
	private String phone = null;

	/** The email of the Travel Agnet */
	private String email = null;

	/** The FAX number of the Travel Agnet */
	private String fax = null;

	/**
	 * Method getTravelAgentCode.
	 * @return String
	 */
	public String getTravelAgentCode() {
		return travelAgentCode;
	}

	/**
	 * Method setTravelAgentCode.
	 * @param travelAgentCode
	 */
	public void setTravelAgentCode(String travelAgentCode) {
		this.travelAgentCode = travelAgentCode;
	}

	/**
	 * Method getContactPerson.
	 * @return String
	 */
	public String getContactPerson() {
		return contactPerson;
	}

	/**
	 * Method setContactPerson.
	 * @param contactPerson
	 */
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	/**
	 * Method getAgencyName.
	 * @return String
	 */
	public String getAgencyName() {
		return agencyName;
	}

	/**
	 * Method setAgencyName.
	 * @param agencyName
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	/**
	 * Method getAgencyOwner.
	 * @return String
	 */
	public String getAgencyOwner() {
		return agencyOwner;
	}

	/**
	 * Method setAgencyOwner.
	 * @param agencyOwner
	 */
	public void setAgencyOwner(String agencyOwner) {
		this.agencyOwner = agencyOwner;
	}

	/**
	 * Method getPostCodePrefix.
	 * @return String
	 */
	public String getPostCodePrefix() {
		return postCodePrefix;
	}

	/**
	 * Method setPostCodePrefix.
	 * @param postCodePrefix
	 */
	public void setPostCodePrefix(String postCodePrefix) {
		this.postCodePrefix = postCodePrefix;
	}

	/**
	 * Method getPostCodeSuffix.
	 * @return String
	 */
	public String getPostCodeSuffix() {
		return postCodeSuffix;
	}

	/**
	 * Method setPostCodeSuffix.
	 * @param postCodeSuffix
	 */
	public void setPostCodeSuffix(String postCodeSuffix) {
		this.postCodeSuffix = postCodeSuffix;
	}

	/**
	 * Method getAddressLine1.
	 * @return String
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * Method setAddressLine1.
	 * @param addressLine1
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * Method getAddressLine2.
	 * @return String
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * Method setAddressLine2.
	 * @param addressLine2
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * Method getCity.
	 * @return String
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Method setCity.
	 * @param city
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Method getCountry.
	 * @return String
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Method setCountry.
	 * @param country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Method getPhone.
	 * @return String
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * Method setPhone.
	 * @param phone
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * Method getEmail.
	 * @return String
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Method setEmail.
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Method getFax.
	 * @return String
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * Method setFax.
	 * @param fax
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}
	/**
	 * Method getCountryRefId.
	 * @return String
	 */
	public String getCountryRefId() {
		return countryRefId;
	}

	/**
	 * Method getCountryValue.
	 * @return String
	 */
	public String getCountryValue() {
		return countryValue;
	}

	/**
	 * Method setCountryRefId.
	 * @param countryRefId
	 */
	public void setCountryRefId(String countryRefId) {
		this.countryRefId = countryRefId;
	}

	/**
	 * Method setCountryValue.
	 * @param countryValue
	 */
	public void setCountryValue(String countryValue) {
		this.countryValue = countryValue;
	}

}
