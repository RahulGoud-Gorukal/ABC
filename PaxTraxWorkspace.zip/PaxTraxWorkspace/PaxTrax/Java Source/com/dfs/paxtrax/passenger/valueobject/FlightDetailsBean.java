package com.dfs.paxtrax.passenger.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * 
 * The Flight Details Bean used in the passenger value object
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class FlightDetailsBean extends PaxTraxValueObject
{
	//Arrival Flight Type
	public final static String ARRIVAL = "A";

	//Departure Flight Type
	public final static String DEPARTURE = "D";

	//The Flight Type
	private String flightType = null;

	//The Airline Code
	private String airlineCode = null;

	//The Airline Code Reference Id
	private String airlineCodeRefId = null;

	//The Airline Code Value
	private String airlineCodeValue = null;

	//The Flight Number
	private String flightNumber = null;

	//The Flight Date
	private String date = null;

	//The Flight Time
	private String time = null;

	//The Origin or Detination of the flight
	private String originDestination = null;

	private String flightPickupLocCodeId;

	private String flightPickupLocDescription;

	private ArrayList airLineCodeList = null;

	private String flightChange = "T";

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber()
	{
		return flightNumber;
	}

	/**
	 * Returns the flightType.
	 * @return int
	 */
	public String getFlightType()
	{
		return flightType;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber)
	{
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the flightType.
	 * @param flightType The flightType to set
	 */
	public void setFlightType(String flightType)
	{
		this.flightType = flightType;
	}

	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode()
	{
		return airlineCode;
	}

	/**
	 * Returns the date.
	 * @return String
	 */
	public String getDate()
	{
		return date;
	}

	/**
	 * Returns the time.
	 * @return String
	 */
	public String getTime()
	{
		return time;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode)
	{
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the date.
	 * @param date The date to set
	 */
	public void setDate(String date)
	{
		this.date = date;
	}

	/**
	 * Sets the time.
	 * @param time The time to set
	 */
	public void setTime(String time)
	{
		this.time = time;
	}

	/**
	 * Returns the originDestination.
	 * @return String
	 */
	public String getOriginDestination()
	{
		return originDestination;
	}

	/**
	 * Sets the originDestination.
	 * @param originDestination The originDestination to set
	 */
	public void setOriginDestination(String originDestination)
	{
		this.originDestination = originDestination;
	}

	/**
	 * Returns the airlineCodeRefId.
	 * @return String
	 */
	public String getAirlineCodeRefId()
	{
		return airlineCodeRefId;
	}

	/**
	 * Returns the airlineCodeValue.
	 * @return String
	 */
	public String getAirlineCodeValue()
	{
		return airlineCodeValue;
	}

	/**
	 * Sets the airlineCodeRefId.
	 * @param airlineCodeRefId The airlineCodeRefId to set
	 */
	public void setAirlineCodeRefId(String airlineCodeRefId)
	{
		this.airlineCodeRefId = airlineCodeRefId;
	}

	/**
	 * Sets the airlineCodeValue.
	 * @param airlineCodeValue The airlineCodeValue to set
	 */
	public void setAirlineCodeValue(String airlineCodeValue)
	{
		this.airlineCodeValue = airlineCodeValue;
	}

	public String toString()
	{

		StringBuffer flightString = new StringBuffer();
		flightString.append(
			"\n\n    ******  FLIGHT BEAN VALUES *****************");
		flightString.append(
			"\n    AirlineCode : " + this.airlineCode);
		flightString.append(
			"\n Date :" + this.date);
		flightString.append(
			"\n  Flight No : " + this.flightNumber);
		flightString.append(
		flightString.append("\n Flight Change :  "+ this.flightChange));
		flightString.append(
			"\n *** ********************************************");
		return flightString.toString();

	}
	/**
	 * Returns the flightPickupLocCodeId.
	 * @return String
	 */
	public String getFlightPickupLocCodeId()
	{
		return flightPickupLocCodeId;
	}

	/**
	 * Returns the flightPickupLocDescription.
	 * @return String
	 */
	public String getFlightPickupLocDescription()
	{
		return flightPickupLocDescription;
	}

	/**
	 * Sets the flightPickupLocCodeId.
	 * @param flightPickupLocCodeId The flightPickupLocCodeId to set
	 */
	public void setFlightPickupLocCodeId(String flightPickupLocCodeId)
	{
		this.flightPickupLocCodeId = flightPickupLocCodeId;
	}

	/**
	 * Sets the flightPickupLocDescription.
	 * @param flightPickupLocDescription The flightPickupLocDescription to set
	 */
	public void setFlightPickupLocDescription(String flightPickupLocDescription)
	{
		this.flightPickupLocDescription = flightPickupLocDescription;
	}

	/**
	 * Returns the airLineCodeList.
	 * @return ArrayList
	 */
	public ArrayList getAirLineCodeList()
	{
		return airLineCodeList;
	}

	/**
	 * Sets the airLineCodeList.
	 * @param airLineCodeList The airLineCodeList to set
	 */
	public void setAirLineCodeList(ArrayList airLineCodeList)
	{
		this.airLineCodeList = airLineCodeList;
	}

	/**
	 * Returns the flightChange.
	 * @return String
	 */
	public String getFlightChange()
	{
		return flightChange;
	}

	/**
	 * Sets the flightChange.
	 * @param flightChange The flightChange to set
	 */
	public void setFlightChange(String flightChange)
	{
		this.flightChange = flightChange;
	}

}
