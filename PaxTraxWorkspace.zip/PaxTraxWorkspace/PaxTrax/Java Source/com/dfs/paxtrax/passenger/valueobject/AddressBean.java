package com.dfs.paxtrax.passenger.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.util.XmlUtil;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * 
 * The Address value object used in the PAX Bean
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class AddressBean extends PaxTraxValueObject {

	//Home Adress Type 
	public final static String TYPE_HOME = "H";
	
	//Other Address Type
	public final static String TYPE_OTHER = "O";
	
	//The Address Type 
	private String addressType = null;
	
	//City
	private String city = null;

	//Country
	private String country = null;

	/* Commented as part of the changes made for converting country from a dropdown to a textfield 
	 * 	
	//The Country reference Id
	private String countryRefId = null;
	
	//The Country Value
	private String countryValue = null;
	*/
	
	//The Postcode Prefix
	private String postCodePrefix = null;
	
	//The Postcode Suffix
	private String postCodeSuffix = null;
	
	//Address Line 1
	private String addressLine1 = null;
	
	//Address Line 2
	private String addressLine2 = null;
	
	//This boolean flag represents the status of postcode lookup from TE POS
	private boolean postCodeLookupError = false;

	/**
	 * Returns the addressLine1.
	 * @return String
	 */
	public String getAddressLine1()
	{
		return addressLine1;
	}

	/**
	 * Returns the addressLine2.
	 * @return String
	 */
	public String getAddressLine2()
	{
		return addressLine2;
	}

	/**
	 * Returns the addressType.
	 * @return String
	 */
	public String getAddressType()
	{
		return addressType;
	}

	/**
	 * Returns the city.
	 * @return String
	 */
	public String getCity()
	{
		return city;
	}

	/**
	 * Returns the country.
	 * @return String
	 */
	public String getCountry()
	{
		return country;
	}

	/**
	 * Returns the postCodePrefix.
	 * @return String
	 */
	public String getPostCodePrefix()
	{
		return postCodePrefix;
	}

	/**
	 * Returns the postCodeSuffix.
	 * @return String
	 */
	public String getPostCodeSuffix()
	{
		return postCodeSuffix;
	}

	/**
	 * Sets the addressLine1.
	 * @param addressLine1 The addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	/**
	 * Sets the addressLine2.
	 * @param addressLine2 The addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	/**
	 * Sets the addressType.
	 * @param addressType The addressType to set
	 */
	public void setAddressType(String addressType)
	{
		this.addressType = addressType;
	}

	/**
	 * Sets the city.
	 * @param city The city to set
	 */
	public void setCity(String city)
	{
		this.city = city;
	}

	/**
	 * Sets the country.
	 * @param country The country to set
	 */
	public void setCountry(String country)
	{
		this.country = country;
	}

	/**
	 * Sets the postCodePrefix.
	 * @param postCodePrefix The postCodePrefix to set
	 */
	public void setPostCodePrefix(String postCodePrefix)
	{
		this.postCodePrefix = postCodePrefix;
	}

	/**
	 * Sets the postCodeSuffix.
	 * @param postCodeSuffix The postCodeSuffix to set
	 */
	public void setPostCodeSuffix(String postCodeSuffix)
	{
		this.postCodeSuffix = postCodeSuffix;
	}
	
	public void encodeData(){
		
		XmlUtil xmlUtil = new XmlUtil();
		
		this.addressLine1 = xmlUtil.encodeCharacterData(addressLine1);
		this.addressLine2 = xmlUtil.encodeCharacterData(addressLine2);		
		this.city = xmlUtil.encodeCharacterData(city);
		this.country = xmlUtil.encodeCharacterData(country);

	}
	
	public String toString(){
		
		StringBuffer addressString  = new StringBuffer();
		
		addressString.append("\n\t *******  ADDRESS BEAN VALUES *******");
		addressString.append("\n\t AddressLine1 			: "+this.addressLine1);
		addressString.append("\n\t AddressLine2 			: "+this.addressLine2);
		addressString.append("\n\t AddressType  			: "+this.addressType);
		addressString.append("\n\t Country					: "+this.country);
		addressString.append("\n\t City						: "+this.city);
		addressString.append("\n\t PostCode Prefix			: "+this.postCodePrefix);
		addressString.append("\n\t PostCode Suffix			: "+this.postCodeSuffix);
		addressString.append("\n\t ************************************");

		return addressString.toString();
	}

	/**
	 * Returns the postCodeLookupError.
	 * @return boolean
	 */
	public boolean getPostCodeLookupError()
	{
		return postCodeLookupError;
	}

	/**
	 * Sets the postCodeLookupError.
	 * @param postCodeLookupError The postCodeLookupError to set
	 */
	public void setPostCodeLookupError(boolean postCodeLookupError)
	{
		this.postCodeLookupError = postCodeLookupError;
	}

}
