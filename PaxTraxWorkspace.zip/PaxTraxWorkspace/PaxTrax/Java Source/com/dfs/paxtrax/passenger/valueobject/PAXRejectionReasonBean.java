package com.dfs.paxtrax.passenger.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


/**
 * 
 * The Address value object used in the PAX Bean
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXRejectionReasonBean extends  PaxTraxValueObject
{
	/* The rejection reason code */
	private String code = null;
	
	/* The Description of the rejection reason  */
	private String description = null;
	/**
	 * Returns the code.
	 * @return String
	 */
	public String getCode()
	{
		return code;
	}

	/**
	 * Returns the description.
	 * @return String
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * Sets the code.
	 * @param code The code to set
	 */
	public void setCode(String code)
	{
		this.code = code;
	}

	/**
	 * Sets the description.
	 * @param description The description to set
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

}
