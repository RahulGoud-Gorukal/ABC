package com.dfs.paxtrax.passenger.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * 
 * The Telephone Number Bean used in the passenger value object
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TelephoneNumberBean extends PaxTraxValueObject {

	//The Telephone Number Type
	private String telephoneNumberType = null;
	
	//The Country Code of the Telephone Number
	private String countryCode = null;
	
	//The Area Code of the Telephone Number
	private String areaCode = null;
	
	//The Telephone Number
	private String telephoneNumber = null;

	/**
	 * Returns the areaCode.
	 * @return String
	 */
	public String getAreaCode() {
		return areaCode;
	}

	/**
	 * Returns the countryCode.
	 * @return String
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * Returns the telephoneNumber.
	 * @return String
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * Returns the telephoneNumberType.
	 * @return String
	 */
	public String getTelephoneNumberType() {
		return telephoneNumberType;
	}

	/**
	 * Sets the areaCode.
	 * @param areaCode The areaCode to set
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	/**
	 * Sets the countryCode.
	 * @param countryCode The countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * Sets the telephoneNumber.
	 * @param telephoneNumber The telephoneNumber to set
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * Sets the telephoneNumberType.
	 * @param telephoneNumberType The telephoneNumberType to set
	 */
	public void setTelephoneNumberType(String telephoneNumberType) {
		this.telephoneNumberType = telephoneNumberType;
	}

}
