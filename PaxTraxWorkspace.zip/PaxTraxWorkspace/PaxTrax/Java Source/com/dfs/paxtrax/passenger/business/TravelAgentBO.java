package com.dfs.paxtrax.passenger.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.passenger.exception.TravelAgentException;
import com.dfs.paxtrax.passenger.valueobject.TravelAgentBean;

/**
 * 
 * The Remote Object for Travel Agent related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public interface TravelAgentBO extends javax.ejb.EJBObject
{
	/**
	 * Method saveTravelAgentDetails.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to create Travel Agent record
	 */
	public void saveTravelAgentDetails(TravelAgentBean travelAgentBean)
		throws RemoteException, PaxTraxSystemException, TravelAgentException;

	/**
	 * Method getTravelAgentDetails.
	 * 
	 * @param travelAgnetBean TravelAgentBean
	 * @return TravelAgentBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to get a Travel Agent record
	 */
	public TravelAgentBean getTravelAgentDetails(TravelAgentBean travelAgnetBean)
		throws RemoteException, PaxTraxSystemException, TravelAgentException;

	/**
	 * Method updateTravelAgentDetails.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to update Travel Agent record
	 */
	public void updateTravelAgentDetails(TravelAgentBean travelAgentBean)
		throws RemoteException, PaxTraxSystemException, TravelAgentException;

	/**
	 * Method deactivateTravelAgent.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @throws RemoteException 
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to deactivate Travel Agent record
	 */
	public void deactivateTravelAgent(TravelAgentBean travelAgentBean)
		throws RemoteException, PaxTraxSystemException, TravelAgentException;

	/**
	 * Method searchTravelAgents.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws TravelAgentException
	 * The method to search for Travel Agent records
	 */
	public ArrayList searchTravelAgents(TravelAgentBean travelAgentBean)
		throws RemoteException, PaxTraxSystemException, TravelAgentException;

	/**
	 * Method postCodeLookup.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @return TravelAgentBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * The method to perform postcode Lookup
	 */
	public TravelAgentBean postCodeLookup(TravelAgentBean travelAgentBean)
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Method getTaName.
	 * 
	 * @param travelAgentBean TravelAgentBean
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * The method to search for Travel Agent records
	 */
		
    public TravelAgentBean getTaName(TravelAgentBean travelAgentBean)
		throws RemoteException, PaxTraxSystemException;

}
