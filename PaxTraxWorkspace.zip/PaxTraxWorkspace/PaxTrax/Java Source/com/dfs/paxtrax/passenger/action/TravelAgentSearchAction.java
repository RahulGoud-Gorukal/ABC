package com.dfs.paxtrax.passenger.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.actionform.TravelAgentSearchForm;
import com.dfs.paxtrax.passenger.exception.TravelAgentException;
import com.dfs.paxtrax.passenger.service.TravelAgentDelegate;
import com.dfs.paxtrax.passenger.valueobject.TravelAgentBean;


/**
 * 
 * The Action Class for the Search Travel Agent flow
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TravelAgentSearchAction extends PaxTraxAction
{
	/**
	 * Method searchTravelAgentPage.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the Travel Agent Page
	 */
	public ActionForward searchTravelAgentPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::searchTravelAgentPage::Begin");
		
		TravelAgentSearchForm taSearchForm = (TravelAgentSearchForm) form;
		taSearchForm.setAgencyName(null);
		taSearchForm.setAgencyOwner(null);
		taSearchForm.setCity(null);
		taSearchForm.setTravelAgentCode(null);
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
		
		PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::searchTravelAgentPage::End");
		
		return (mapping.findForward(PaxTraxConstants.FWD_TA_SEARCH_PAGE));
	}

	/**
	 * Method searchTravelAgents.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to search for Travel Agent Records
	 */
	public ActionForward searchTravelAgents(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::searchTravelAgents::Begin");

			int pageNumber = 0;
			ArrayList allRecords = null;
			ArrayList currentRecords = null;
			TravelAgentSearchForm taSearchForm = (TravelAgentSearchForm) form;
			HttpSession session = request.getSession();
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0))
			{
				int size = 0;
				pageNumber = 1;
				TravelAgentDelegate taDelegate = new TravelAgentDelegate();
				TravelAgentBean taBean = new TravelAgentBean();
				taBean.setTravelAgentCode(taSearchForm.getTravelAgentCode());
				taBean.setAgencyName(taSearchForm.getAgencyName());
				taBean.setAgencyOwner(taSearchForm.getAgencyOwner());
				taBean.setCity(taSearchForm.getCity());
				allRecords = taDelegate.searchTravelAgents(taBean);

				if (allRecords != null)
					size = allRecords.size();

				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
			}
			else
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((allRecords != null) && (allRecords.size() != 0))
			{
				// Get records to be displayed for the passed page number
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));

			//Sets records to be displayed for the page number 
			taSearchForm.setTravelAgents(currentRecords);

			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::searchTravelAgents::End");
		}
		catch (TravelAgentException te)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentSearchAction::searchTravelAgents", te);
			return mapping.findForward(PaxTraxConstants.FWD_TA_SEARCH_PAGE);
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentSearchAction::searchTravelAgents", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(PaxTraxConstants.FWD_TA_SEARCH_PAGE));
	}
	
	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		String forwardPage = "";
		
		PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::changeLanguage::Begin");
		
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String result = request.getParameter("res");
		String pageNumber = request.getParameter("pN");
		
		if(language!=null && country!=null && result!=null)		
		{
			super.changeLanguage(request, language, country);
			forwardPage = PaxTraxConstants.FWD_TA_SEARCH_PAGE;			
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;					
		
		if(result.equals(PaxTraxConstants.SUCCESS))
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		}
		else
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);		
		
		PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::changeLanguage::End");
			
		return(mapping.findForward(forwardPage));
	}

	public ActionForward backToSearchTAPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::backToSearchTAPage::Begin");
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);		
		
		String pageNumber = request.getParameter("fromPageNumber");
		if(pageNumber==null)
			pageNumber = "1";
		
		String deactivatedTAIndex = request.getParameter("deactivatedTAIndex");
		
		if(deactivatedTAIndex!=null)
		{
			int taIndex = Integer.parseInt(deactivatedTAIndex);
			taIndex = taIndex - 1;
			HttpSession session = request.getSession();
			
			ArrayList allRecords = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);
			
			if(allRecords!=null && allRecords.size()>0)
			{
				allRecords.remove(taIndex);

				PaginationHelper helper = PaginationHelper.getInstance();				
				int currPageNumber = Integer.parseInt(pageNumber);
				
				if(currPageNumber!=1)
				{
					if(allRecords.size()<=((currPageNumber-1) * 10))
					{
						currPageNumber = currPageNumber - 1;	
					}
				}
				
				pageNumber = "" + currPageNumber;
				
				ArrayList currentRecords = helper.getCurrentTableContent(allRecords, currPageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
				
				TravelAgentSearchForm taSearchForm = (TravelAgentSearchForm)form;
				taSearchForm.setTravelAgents(currentRecords);
				
				int size = allRecords.size();
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
			}
			
		}

		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		PaxTraxLog.logDebug("PaxTrax::TravelAgentSearchAction::backToSearchTAPage::End");
		
		return(mapping.findForward(PaxTraxConstants.FWD_TA_SEARCH_PAGE));
	}

}
