package com.dfs.paxtrax.passenger.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.actionform.PAXSearchForm;
import com.dfs.paxtrax.passenger.exception.PAXException;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TelephoneNumberBean;

/**
 * 
 * The Action Class for the PAX Search Flow
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXSearchAction extends PaxTraxAction
{

	/**
	 * Method searchPAXDetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to search for PAX Details
	 */

	public ActionForward searchPAXDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::PAXSearchAction::searchPAXDetails::Begin");

			int pageNumber = 0;
			ArrayList allRecords = null;
			ArrayList currentRecords = null;
			PAXSearchForm paxSearchForm = (PAXSearchForm) form;
			HttpSession session = request.getSession();
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0))
			{
				int size = 0;
				pageNumber = 1;
				PAXDelegate delegate = new PAXDelegate();

				PAXBean paxBean = new PAXBean();
				if (paxSearchForm.getPaxNumber() != null
					&& !(paxSearchForm.getPaxNumber().equals("")))
					paxBean.setPaxNumber(paxSearchForm.getPaxNumber());

				if (paxSearchForm.getLastName() != null
					&& !(paxSearchForm.getLastName().equals("")))
					paxBean.setLastName(paxSearchForm.getLastName());

				if (paxSearchForm.getFirstName() != null
					&& !(paxSearchForm.getFirstName().equals("")))
					paxBean.setFirstName(paxSearchForm.getFirstName());

				AddressBean addr = new AddressBean();

				if (paxSearchForm.getPostCodePrefix() != null
					&& !(paxSearchForm.getPostCodePrefix().equals("")))
					addr.setPostCodePrefix(paxSearchForm.getPostCodePrefix());

				if (paxSearchForm.getPostCodeSuffix() != null
					&& !(paxSearchForm.getPostCodeSuffix().equals("")))
					addr.setPostCodeSuffix(paxSearchForm.getPostCodeSuffix());

				TelephoneNumberBean teleBean = new TelephoneNumberBean();
				if (paxSearchForm.getTelephoneNumber() != null
					&& !(paxSearchForm.getTelephoneNumber().equals("")))
					teleBean.setTelephoneNumberType(
						paxSearchForm.getTelephoneNumber());

				FlightDetailsBean dept = new FlightDetailsBean();

				if (paxSearchForm.getDepartureAirlineCode() != null
					&& !(paxSearchForm.getDepartureAirlineCode().equals("-1")))
				{
					dept.setAirlineCode(
						paxSearchForm.getDepartureAirlineCode());
					dept.setAirlineCodeRefId(
						paxSearchForm.getDepartureAirlineCodeRefId());
					dept.setFlightType("D");
				}

				if (paxSearchForm.getDepartureFlightNumber() != null
					&& !(paxSearchForm.getDepartureFlightNumber().equals("")))
					dept.setFlightNumber(
						paxSearchForm.getDepartureFlightNumber());

				if (paxSearchForm.getDepartureFlightDate() != null
					&& !(paxSearchForm.getDepartureFlightDate().equals("")))
					dept.setDate(paxSearchForm.getDepartureFlightDate());

				FlightDetailsBean arr = new FlightDetailsBean();

				if (paxSearchForm.getArrivalAirlineCode() != null
					&& !(paxSearchForm.getArrivalAirlineCode().equals("-1")))
				{
					arr.setAirlineCode(paxSearchForm.getArrivalAirlineCode());
					arr.setAirlineCodeRefId(
						paxSearchForm.getArrivalAirlineCodeRefId());
					arr.setFlightType("A");
				}

				if (paxSearchForm.getArrivalFlightNumber() != null
					&& !(paxSearchForm.getArrivalFlightNumber().equals("")))
					arr.setFlightNumber(paxSearchForm.getArrivalFlightNumber());

				if (paxSearchForm.getArrivalFlightDate() != null
					&& !(paxSearchForm.getArrivalFlightDate().equals("")))
					arr.setDate(paxSearchForm.getArrivalFlightDate());

				if (paxSearchForm.getTravelAgentCode() != null
					&& !(paxSearchForm.getTravelAgentCode().equals("")))
					paxBean.setTravelAgentCode(
						paxSearchForm.getTravelAgentCode());

				paxBean.setAddress(addr);
				paxBean.setDepartureFlightDetails(dept);
				paxBean.setArrivalFlightDetails(arr);
				paxBean.setPhone(teleBean);
				try 
				{
					allRecords = delegate.searchPAXDetails(paxBean);
				}
				catch (PAXException paxException)
				{
					PaxTraxLog.logError("PaxTrax::PAXSearchAction:;searchPAXDetails();;PaxException ", paxException);
					request.setAttribute(PaxTraxConstants.REFINE_SEARCH, PaxTraxConstants.TRUE);
				}

				if (allRecords != null)
					size = allRecords.size();

				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
			}
			else
			{
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
			}

			if ((allRecords != null) && (allRecords.size() == 1))
			{
				forward = PaxTraxConstants.FWD_MAINTAIN_PAX_PAGE;
			}
			else
			{
				PaginationHelper helper = PaginationHelper.getInstance();

				if ((allRecords != null) && (allRecords.size() != 0))
				{
					// Get records to be displayed for the passed page number
					currentRecords =
						helper.getCurrentTableContent(
							allRecords,
							pageNumber,
							PaxTraxConstants.RECORDS_PER_PAGE);
				}
				request.setAttribute(
					PaxTraxConstants.PAGE_NUMBER,
					Integer.toString(pageNumber));

				//Sets records to be displayed for the page number 
				paxSearchForm.setPaxDetails(currentRecords);

				request.setAttribute(
					PaxTraxConstants.RESULT,
					PaxTraxConstants.SUCCESS);
				forward = PaxTraxConstants.FWD_PAX_SEARCH_PAGE;
			}
			PaxTraxLog.logDebug(
				"PaxTrax::PAXSearchAction::searchPAXDetails::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXSearchAction::searchPAXDetails",
				pse);
			forward = PaxTraxConstants.SYSTEM_ERROR;

		}

		return (mapping.findForward(forward));
	}

	/**
	 * Method searchPAXPage.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the PAX Search page
	 */
	public ActionForward searchPAXPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::PAXSearchAction::searchPAXPage::Begin");

			PAXSearchForm psForm = (PAXSearchForm) form;
			psForm.setPaxNumber(null);

			psForm.setArrivalAirlineCode(null);
			psForm.setArrivalFlightDate(null);
			psForm.setArrivalFlightNumber(null);
			psForm.setDepartureAirlineCode(null);
			psForm.setDepartureFlightDate(null);
			psForm.setDepartureFlightNumber(null);

			HttpSession session = request.getSession();

			String fromMaintainPAXPage =
				(String) session.getAttribute("fromMaintainPAXPage");

			if (fromMaintainPAXPage != null)
			{
				String fieldName = (String) session.getAttribute("fieldName");
				String fieldValue = (String) session.getAttribute("fieldValue");

				if (fieldName != null)
				{
					if (fieldName.equals("firstName"))
					{
						psForm.setFirstName(fieldValue);
						psForm.setLastName(null);
					}

					if (fieldName.equals("lastName"))
					{
						psForm.setLastName(fieldValue);
						psForm.setFirstName(null);
					}
					if (fieldName.equals("paxNumber"))
					{
						psForm.setPaxNumber(fieldValue);
						//psForm.setFirstName(null);
						//psForm.setLastName(null);
					}

					ArrayList allRecords =
						(ArrayList) session.getAttribute(
							PaxTraxConstants.ALL_RECORDS);
					int size = 0;

					if (allRecords != null)
						size = allRecords.size();

					session.removeAttribute(
						PaxTraxConstants.SIZE_OF_ALL_RECORDS);
					session.setAttribute(
						PaxTraxConstants.SIZE_OF_ALL_RECORDS,
						Integer.toString(size));

					PaginationHelper helper = PaginationHelper.getInstance();
					ArrayList currentRecords = null;
					int pageNumber = 1;

					if ((allRecords != null) && (allRecords.size() != 0))
					{
						// Get records to be displayed for the passed page number
						currentRecords =
							helper.getCurrentTableContent(
								allRecords,
								pageNumber,
								PaxTraxConstants.RECORDS_PER_PAGE);
					}
					request.setAttribute(
						PaxTraxConstants.PAGE_NUMBER,
						Integer.toString(pageNumber));

					//Sets records to be displayed for the page number 
					psForm.setPaxDetails(currentRecords);

					session.removeAttribute("fieldName");
					session.removeAttribute("fieldValue");

					request.setAttribute(
						PaxTraxConstants.RESULT,
						PaxTraxConstants.SUCCESS);
				}
				else
				{
					psForm.setFirstName(null);
					psForm.setLastName(null);
					psForm.setArrivalAirlineCode(null);
					psForm.setArrivalFlightDate(null);
					psForm.setArrivalFlightNumber(null);
					psForm.setDepartureAirlineCode(null);
					psForm.setDepartureFlightDate(null);
					psForm.setPaxNumber(null);
					request.setAttribute(
						PaxTraxConstants.RESULT,
						PaxTraxConstants.FAILURE);
				}

				session.removeAttribute("fromMaintainPAXPage");

			}
			else
			{
				psForm.setFirstName(null);
				psForm.setLastName(null);
				psForm.setPaxDetails(null);
				request.setAttribute(
					PaxTraxConstants.RESULT,
					PaxTraxConstants.FAILURE);
			}

			psForm.setPostCodePrefix(null);
			psForm.setPostCodeSuffix(null);
			psForm.setTelephoneNumber(null);
			psForm.setTravelAgentCode(null);

			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
			psForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));
			psForm.setArrivalAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
			psForm.setDepartureAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);

			PaxTraxLog.logDebug("PaxTrax::PAXSearchAction::searchPAXPage::End");

			return (mapping.findForward(PaxTraxConstants.FWD_PAX_SEARCH_PAGE));
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::PAXSearchAction::searchPAXPage",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}
	}

	public ActionForward backToSearchPAXPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::PAXSearchAction::backToSearchPAXPage::Begin");

		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);

		String pageNumber = request.getParameter("fromPageNumber");
		if (pageNumber == null)
			pageNumber = "1";

		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);

		PaxTraxLog.logDebug(
			"PaxTrax::PAXSearchAction::backToSearchPAXPage::End");
		return (mapping.findForward(PaxTraxConstants.FWD_PAX_SEARCH_PAGE));
	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXSearchAction::changeLanguage::Begin");

		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country =
			request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String result = request.getParameter("res");
		String pageNumber = request.getParameter("pN");

		if (language != null && country != null && result != null)
		{
			super.changeLanguage(request, language, country);
			forwardPage = PaxTraxConstants.FWD_PAX_SEARCH_PAGE;
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		if (result.equals(PaxTraxConstants.SUCCESS))
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
		}
		else
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.FAILURE);

		PaxTraxLog.logDebug("PaxTrax::PAXSearchAction::changeLanguage::End");
		return (mapping.findForward(forwardPage));
	}

}
