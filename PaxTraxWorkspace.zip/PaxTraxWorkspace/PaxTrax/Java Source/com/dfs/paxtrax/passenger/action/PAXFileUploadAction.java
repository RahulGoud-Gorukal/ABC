package com.dfs.paxtrax.passenger.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.actionform.PAXFileUploadForm;
import com.dfs.paxtrax.passenger.helpers.TAFileFTPHelper;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.valueobject.AdditionalPAX;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TAFileBean;
import com.dfs.paxtrax.passenger.valueobject.UploadedPAXListBean;
import com.dfs.util.kanaroman.api.KanaStringToRoman;
import com.dfs.util.kanaroman.api.KanaToRomanException;

/**
 * 
 * The Action Class for the Upload PAX File Page
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXFileUploadAction extends PaxTraxAction
{

	/**
	 * Method uploadPAXPage.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * Method to go to the Upload PAX File Page
	 */
	public ActionForward uploadPAXPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::uploadPAXPage::Begin");

		ArrayList fileTypeList = new ArrayList();
		ReferenceDataBean rdBean = new ReferenceDataBean();
		rdBean.setCodeId("paxFile");
		rdBean.setCodeValue("PAX File");
		fileTypeList.add(rdBean);

		/*		
		rdBean = new ReferenceDataBean();
		rdBean.setCodeId("tourFile");
		rdBean.setCodeValue("Tour File");
		fileTypeList.add(rdBean);
		*/

		PAXFileUploadForm pForm = (PAXFileUploadForm) form;
		pForm.setFileTypeList(fileTypeList);
		pForm.setFileType(null);

		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME, PaxTraxConstants.PASSENGER);

		PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::uploadPAXPage::End");

		return (mapping.findForward(PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE));
	}

	/**
	 * Method uploadPAXDetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 * Method to upload PAX Files
	 */
	public ActionForward uploadPAXDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::uploadPAXDetails::Begin");
			ArrayList filesList = new ArrayList();
			ArrayList resultList = new ArrayList();
			ArrayList finalFileList = new ArrayList();
			HttpSession session = request.getSession();
			TAFileFTPHelper taFileHelper = new TAFileFTPHelper();
			if (form instanceof PAXFileUploadForm)
			{
				PAXFileUploadForm paxFileUploadForm = (PAXFileUploadForm) form;

				if (paxFileUploadForm.getFileType() != null && paxFileUploadForm.getFileType().equals("paxFile"))
				{

					if (paxFileUploadForm.getFile1() != null && !(paxFileUploadForm.getFile1().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile1().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile1());
							filesList.add(paxFileUploadForm.getFile1().getFileName());
						}
					}

					if (paxFileUploadForm.getFile2() != null && !(paxFileUploadForm.getFile2().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile2().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile2());
							filesList.add(paxFileUploadForm.getFile2().getFileName());
						}
					}

					if (paxFileUploadForm.getFile3() != null && !(paxFileUploadForm.getFile3().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile3().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile3());
							filesList.add(paxFileUploadForm.getFile3().getFileName());
						}
					}

					if (paxFileUploadForm.getFile4() != null && !(paxFileUploadForm.getFile4().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile4().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile4());
							filesList.add(paxFileUploadForm.getFile4().getFileName());
						}
					}

					if (paxFileUploadForm.getFile5() != null && !(paxFileUploadForm.getFile5().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile5().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile5());
							filesList.add(paxFileUploadForm.getFile5().getFileName());
						}
					}

					if (paxFileUploadForm.getFile6() != null && !(paxFileUploadForm.getFile6().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile6().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile6());
							filesList.add(paxFileUploadForm.getFile6().getFileName());
						}
					}

					if (paxFileUploadForm.getFile7() != null && !(paxFileUploadForm.getFile7().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile7().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile7());
							filesList.add(paxFileUploadForm.getFile7().getFileName());
						}
					}

					if (paxFileUploadForm.getFile8() != null && !(paxFileUploadForm.getFile8().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile8().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile8());
							filesList.add(paxFileUploadForm.getFile8().getFileName());
						}
					}

					if (paxFileUploadForm.getFile9() != null && !(paxFileUploadForm.getFile9().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile9().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile9());
							filesList.add(paxFileUploadForm.getFile9().getFileName());
						}
					}

					if (paxFileUploadForm.getFile10() != null && !(paxFileUploadForm.getFile10().getFileName().equals("")))
					{
						if (paxFileUploadForm.getFile10().getFileSize() != 0)
						{
							//saveFile(paxFileUploadForm.getFile10());
							filesList.add(paxFileUploadForm.getFile10().getFileName());
						}
					}

					if (filesList.size() > 0)
					{
						PAXDelegate delegate = new PAXDelegate();

						String userId = (String) session.getAttribute("userId");
						resultList = delegate.validateTA(filesList);
						if (resultList == null || resultList.size() < 1)
						{
							request.setAttribute("errorCode", "" + PaxTraxErrorMessages.PT_PAX_NO_FILES_FOR_UPLAOD);
							return (mapping.findForward(PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE));
						}
						else
						{
							for (int i = 0; i < resultList.size(); i++)
							{
								String fileName = (String) resultList.get(i);
								if (fileName.equals(paxFileUploadForm.getFile1().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile1());
								}
								else if (fileName.equals(paxFileUploadForm.getFile2().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile2());
								}
								else if (fileName.equals(paxFileUploadForm.getFile3().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile3());
								}
								else if (fileName.equals(paxFileUploadForm.getFile4().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile4());
								}
								else if (fileName.equals(paxFileUploadForm.getFile5().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile5());
								}
								else if (fileName.equals(paxFileUploadForm.getFile6().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile6());
								}
								else if (fileName.equals(paxFileUploadForm.getFile7().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile7());
								}
								else if (fileName.equals(paxFileUploadForm.getFile8().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile8());
								}
								else if (fileName.equals(paxFileUploadForm.getFile9().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile9());
								}
								else if (fileName.equals(paxFileUploadForm.getFile10().getFileName()))
								{
									saveFile(paxFileUploadForm.getFile10());
								}
							}
						}
						/*ArrayList filePaxList = delegate.uploadPAXFile(resultList, userId);
						if (filePaxList == null || filePaxList.size() < 1)
						{
							request.setAttribute("errorCode", "" + PaxTraxErrorMessages.PT_PAX_INFO_INVALID);
							return (mapping.findForward(PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE));
						}
						else
						{*/

						ArrayList taFileBeanList = new ArrayList();
						for (int i = 0; i < resultList.size(); i++)
						{
							//UploadedPAXListBean uploadedPAXListBean = (UploadedPAXListBean) resultList.get(i);
							String fileName = (String) resultList.get(i);
							TAFileBean taFileBean = delegate.getFileTypeBean(fileName);
							taFileBean.setLocalDestFolder(PaxTraxConstants.FILE_UPLOAD_BASE);
							taFileBeanList.add(taFileBean);
							finalFileList.add(taFileBean.getFileName());

						}
						ArrayList totalPaxList = new ArrayList();
						for (int j = 0; j < taFileBeanList.size(); j++)
						{
							
							ArrayList paxPerFileList = taFileHelper.readFile((TAFileBean) taFileBeanList.get(j), userId);
							totalPaxList.addAll(paxPerFileList);
						}
						if (totalPaxList == null || totalPaxList.size() < 1)
						{
							request.setAttribute("errorCode", "" + PaxTraxErrorMessages.PT_PAX_INFO_INVALID);
							return (mapping.findForward(PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE));
						}

					}
					else
					{
						request.setAttribute("errorCode", "" + PaxTraxErrorMessages.PT_PAX_NO_FILES_FOR_UPLAOD);
						return (mapping.findForward(PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE));
					}
				}

			}
			else
			{
				PaxTraxLog.logError("Exception in PaxTrax::PAXFileUploadAction::uploadPAXDetails");
				return (mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));
			}

			//The ArrayList containing the list of file names is placed on the session scope to be displayed on the page

			session.setAttribute("paxTourUploadFilesList", finalFileList);

			PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::uploadPAXDetails::End");
		}
		catch (FileNotFoundException e)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXFileUploadAction::uploadPAXDetails " + e);
			request.setAttribute("errorCode", "" + PaxTraxErrorMessages.PT_PAX_NO_FILES_FOR_UPLAOD);
			return (mapping.findForward(PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE));
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXFileUploadAction::uploadPAXDetails", pse);
			return (mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));
		}

		return (mapping.findForward("goToUploadPAXFileConfirmation"));
	}

//	private ArrayList readFile(TAFileBean taFileTypeBean, String userId) throws PaxTraxSystemException
//	{
//		String fileName = taFileTypeBean.getFileName();
//		String field = null;
//		ArrayList paxBeanList = null;
//		File iFile = new File(PaxTraxConstants.FILE_UPLOAD_BASE + fileName);
//
//		String fileEncryptionType = taFileTypeBean.getFileEncryptionType();
//		//fileEncryptionType ="UTF16";
//		Reader fReader = null;
//		BufferedReader bReader = null;
//		PAXDelegate paxDelegate = new PAXDelegate();
//		ArrayList paxPerFileList = new ArrayList();
//		try
//		{
//			fReader = new InputStreamReader(new FileInputStream(iFile), fileEncryptionType);
//			bReader = new BufferedReader(fReader);
//			String line = bReader.readLine();
//			paxBeanList = new ArrayList();
//			boolean firstLine = true;
//			ArrayList headerList = taFileTypeBean.getHeaderList();
//			ArrayList detailsList = taFileTypeBean.getDetailsList();
//			String footerIndicator = taFileTypeBean.getFooterIndicator();
//			String delimitedFile = taFileTypeBean.getDelimitedFile();
//			String delimiterUsed = taFileTypeBean.getDelimiterUsed();
//			if (delimiterUsed != null)
//			{
//				delimiterUsed = delimiterUsed.trim();
//			}
//			StringTokenizer detailTokens = null;
//			StringTokenizer headerTokens = null;
//
//			while (line != null)
//			{
//				PAXBean paxBean = new PAXBean();
//				if (firstLine && headerList != null && headerList.size() > 0)
//				{
//					/*if (headerDelimited.equals("Y"))
//					{
//						if (headerDelimiter.equals("\\t"))
//						{
//							headerTokens = new StringTokenizer(line, "\t");
//						}
//						else
//							headerTokens = new StringTokenizer(line, headerDelimiter.trim());
//					
//						int countTokens = 0;
//					
//						for (int k = 0; k < headerList.size(); k++)
//						{
//							TravelAgentBean travelAgentBean = (TravelAgentBean) headerList.get(k);
//					
//							while (headerTokens.hasMoreTokens())
//							{
//								field = headerTokens.nextToken();
//					
//								countTokens++;
//					
//								if (countTokens == travelAgentBean.getStartIndexPosition())
//								{
//									getFieldMapping(travelAgentBean.getFieldCodeID(), field.trim());
//									break;
//								}
//							}
//						}
//					}
//					else
//					{
//						field = null;
//					
//						for (int j = 0; j < headerList.size(); j++)
//						{
//							TravelAgentBean travelAgentBean = (TravelAgentBean) headerList.get(j);
//							field = line.substring(travelAgentBean.getStartIndexPosition() - 1, travelAgentBean.getEndPosition());
//					
//							getFieldMapping(travelAgentBean.getFieldCodeID(), field.trim());
//						}
//					}*/
//					firstLine = false;
//				}
//				else
//				{
//					boolean processLine = true;
//
//					if (footerIndicator != null)
//					{
//						footerIndicator = footerIndicator.trim();
//						String lineIndicator = null;
//						if (line.length() >= footerIndicator.length())
//						{
//							lineIndicator = line.substring(0, footerIndicator.length());
//						}
//						if (footerIndicator.equals(lineIndicator))
//						{
//							/* If required process footer */
//							processLine = false;
//						}
//					}
//					if (processLine)
//					{
//
//						if ("Y".equals(delimitedFile))
//						{
//
//							if ("\\t".equals(delimiterUsed))
//							{
//								detailTokens = new StringTokenizer(line, "\t");
//							}
//							else
//								detailTokens = new StringTokenizer(line, delimiterUsed);
//							int countTokens1 = 0;
//							TAFileBean taFileBean = null;
//							for (int k = 0; k < detailsList.size(); k++)
//							{
//								taFileBean = (TAFileBean) detailsList.get(k);
//
//								while (detailTokens.hasMoreTokens())
//								{
//									field = detailTokens.nextToken();
//
//									if (field != null)
//									{
//										field = field.replace('"', ' ');
//										field = field.trim();
//									}
//									countTokens1++;
//
//									if (countTokens1 == taFileBean.getStartIndexPosition())
//									{
//										paxBean = getFieldMapping(taFileTypeBean, taFileBean.getFieldCodeID(), field, paxBean);
//										//printPaxDetails(paxBean);
//										break;
//									}
//								}
//							}
//
//						}
//						else
//						{
//							for (int k = 0; k < detailsList.size(); k++)
//							{
//								TAFileBean taFileBean = (TAFileBean) detailsList.get(k);
//								if (taFileBean.getEndPosition() != 0)
//								{
//
//									if ((line.length()) >= taFileBean.getEndPosition())
//									{
//										field = line.substring(taFileBean.getStartIndexPosition() - 1, taFileBean.getEndPosition());
//									}
//								}
//								else
//								{
//									if ((line.length()) >= (taFileBean.getStartIndexPosition() - 1 + taFileBean.getLength()))
//									{
//										field =
//											line.substring(
//												taFileBean.getStartIndexPosition() - 1,
//												taFileBean.getStartIndexPosition() - 1 + taFileBean.getLength());
//									}
//								}
//								if (field != null)
//								{
//									field = field.replace('"', ' ');
//									field = field.trim();
//								}
//								paxBean = getFieldMapping(taFileTypeBean, taFileBean.getFieldCodeID(), field, paxBean);
//								//printPaxDetails(paxBean);
//							}
//						}
//						//paxBean.setTaBranch(branchCode);
//						paxBean.setTravelAgentCode(taFileTypeBean.getTaCode());
//						AdditionalPAX additionalPAX = paxBean.getAdditionalPAX();
//						if (additionalPAX != null)
//						{
//
//							String firstName1 = additionalPAX.getPaxFirstName1();
//							String lastName1 = additionalPAX.getPaxLastName1();
//							if (firstName1 != null && lastName1 != null)
//								paxBeanList.add(getDuplicatePaxBean(paxBean, lastName1, firstName1));
//
//							String firstName2 = additionalPAX.getPaxFirstName2();
//							String lastName2 = additionalPAX.getPaxLastName2();
//							if (firstName2 != null && lastName2 != null)
//								paxBeanList.add(getDuplicatePaxBean(paxBean, lastName2, firstName2));
//
//							String firstName3 = additionalPAX.getPaxFirstName3();
//							String lastName3 = additionalPAX.getPaxLastName3();
//							if (firstName3 != null && lastName3 != null)
//								paxBeanList.add(getDuplicatePaxBean(paxBean, lastName3, firstName3));
//
//							String firstName4 = additionalPAX.getPaxFirstName4();
//							String lastName4 = additionalPAX.getPaxLastName4();
//							if (firstName4 != null && lastName4 != null)
//								paxBeanList.add(getDuplicatePaxBean(paxBean, lastName4, firstName4));
//
//							String firstName5 = additionalPAX.getPaxFirstName5();
//							String lastName5 = additionalPAX.getPaxLastName5();
//							if (firstName5 != null && lastName5 != null)
//								paxBeanList.add(getDuplicatePaxBean(paxBean, lastName5, firstName5));
//
//							String firstName6 = additionalPAX.getPaxFirstName6();
//							String lastName6 = additionalPAX.getPaxLastName6();
//							if (firstName6 != null && lastName6 != null)
//								paxBeanList.add(getDuplicatePaxBean(paxBean, lastName6, firstName6));
//						}
//						else
//							paxBeanList.add(paxBean);
//
//						if (paxBeanList.size() >= 25)
//						{
//
//							ArrayList tempList = paxDelegate.insertPaxRecordFromTAFile(paxBeanList, userId, taFileTypeBean);
//							if (tempList != null && tempList.size() > 0)
//								paxPerFileList.addAll(tempList);
//							paxBeanList.clear();
//						}
//
//					}
//
//				}
//
//				line = bReader.readLine();
//			}
//			if (paxBeanList.size() > 0)
//			{
//
//				ArrayList tempList = paxDelegate.insertPaxRecordFromTAFile(paxBeanList, userId, taFileTypeBean);
//				if (tempList != null && tempList.size() > 0)
//					paxPerFileList.addAll(tempList);
//				paxBeanList.clear();
//			}
//		}
//
//		catch (IOException ioexception)
//		{
//			ioexception.printStackTrace();
//			throw new PaxTraxSystemException(ioexception);
//		}
//		return paxPerFileList;
//	}
//	private PAXBean getDuplicatePaxBean(PAXBean paxBean, String lastName, String firstName)
//	{
//		PAXBean newPaxBean = new PAXBean();
//		newPaxBean.setAddress(paxBean.getAddress());
//		newPaxBean.setArrivalFlightDetails(paxBean.getArrivalFlightDetails());
//		newPaxBean.setDepartureFlightDetails(paxBean.getDepartureFlightDetails());
//
//		newPaxBean.setFirstName(firstName);
//		newPaxBean.setLastName(lastName);
//		newPaxBean.setPaxNumber(paxBean.getPaxNumber());
//		newPaxBean.setPrimaryPaxFirstName(paxBean.getPrimaryPaxFirstName());
//		newPaxBean.setPrimaryPaxLastName(paxBean.getPrimaryPaxLastName());
//		newPaxBean.setTaBranch(paxBean.getTaBranch());
//		newPaxBean.setTourCode(paxBean.getTourCode());
//		newPaxBean.setTravelAgentCode(paxBean.getTravelAgentCode());
//		newPaxBean.setUploadDate(paxBean.getUploadDate());
//		newPaxBean.setUser(paxBean.getUser());
//		return newPaxBean;
//	}
//	private String getFieldType(ArrayList list, int index)
//	{
//		String returnValue = null;
//		if (list != null)
//		{
//			for (int i = 0; i < list.size(); i++)
//			{
//				ReferenceDataBean referenceDataBean = (ReferenceDataBean) list.get(i);
//				if (Integer.parseInt(referenceDataBean.getCodeId()) == index)
//				{
//					returnValue = referenceDataBean.getCodeValue();
//					break;
//				}
//			}
//		}
//		return returnValue;
//	}
//
//	private AdditionalPAX getAdditionalPax(AdditionalPAX additionalPAX, String field, int index) throws KanaToRomanException
//	{
//		KanaStringToRoman kstr = KanaStringToRoman.getInstance();
//		if (additionalPAX == null)
//			additionalPAX = new AdditionalPAX();
//		if (field != null && field.indexOf(" ") != -1)
//		{
//			StringTokenizer str = new StringTokenizer(field, " ");
//			String firstName = kstr.convert(str.nextToken());
//			if (firstName != null && firstName.length() > 30)
//				firstName = firstName.substring(0, 30);
//			String lastName = kstr.convert(str.nextToken());
//			if (lastName != null && lastName.length() > 30)
//				lastName = lastName.substring(0, 30);
//
//			switch (index)
//			{
//				case 1 :
//
//					additionalPAX.setPaxFirstName1(firstName);
//					additionalPAX.setPaxLastName1(lastName);
//					break;
//				case 2 :
//
//					additionalPAX.setPaxFirstName2(firstName);
//					additionalPAX.setPaxLastName2(lastName);
//					break;
//				case 3 :
//
//					additionalPAX.setPaxFirstName3(firstName);
//					additionalPAX.setPaxLastName3(lastName);
//					break;
//				case 4 :
//
//					additionalPAX.setPaxFirstName4(firstName);
//					additionalPAX.setPaxLastName4(lastName);
//					break;
//				case 5 :
//
//					additionalPAX.setPaxFirstName5(firstName);
//					additionalPAX.setPaxLastName5(lastName);
//					break;
//				case 6 :
//
//					additionalPAX.setPaxFirstName6(firstName);
//					additionalPAX.setPaxLastName6(lastName);
//					break;
//
//			}
//		}
//		return additionalPAX;
//	}
//	private FlightDetailsBean getFlightDetails(TAFileBean taFileTypeBean, String airLineFlightNumber, FlightDetailsBean flightDetailsBean)
//	{
//
//		String airLineValue = null;
//		String flightNumber = null;
//		if (PaxTraxConstants.AIRLINE_VALUE_REFERRED_TO_NACCS.equals(taFileTypeBean.getAirLineValueType()))
//		{
//			if (airLineFlightNumber != null && airLineFlightNumber.length() > 3)
//			{
//				airLineValue = airLineFlightNumber.substring(0, 3);
//				flightNumber = airLineFlightNumber.substring(3);
//			}
//		}
//		if (PaxTraxConstants.AIRLINE_VALUE_REFERRED_TO_VALUE.equals(taFileTypeBean.getAirLineValueType()))
//		{
//			if (airLineFlightNumber != null && airLineFlightNumber.length() > 2)
//			{
//				airLineValue = airLineFlightNumber.substring(0, 2);
//				flightNumber = airLineFlightNumber.substring(2);
//			}
//		}
//		flightDetailsBean.setAirlineCodeValue(airLineValue);
//		flightDetailsBean.setFlightNumber(flightNumber);
//		return flightDetailsBean;
//	}
//
//	private FlightDetailsBean getFlightDetailsBean(String field, String value, FlightDetailsBean flightDetailsBean)
//	{
//
//		if (value != null && value.length() > 5)
//			value = value.substring(0, 5);
//		if ("AIRLINECODE".equals(field))
//		{
//
//			flightDetailsBean.setAirlineCodeValue(value);
//		}
//		else
//		{
//			flightDetailsBean.setFlightNumber(value);
//		}
//		return flightDetailsBean;
//	}
//	private FlightDetailsBean getDateCalendarObject(FlightDetailsBean flightDetailsBean, String dateVaribale, String value)
//	{
//
//		if (flightDetailsBean == null)
//			flightDetailsBean = new FlightDetailsBean();
//
//		String date = flightDetailsBean.getDate();
//
//		StringBuffer flightDate = null;
//		if (date == null)
//		{
//			flightDate = new StringBuffer("9999-99-99");
//		}
//		else
//		{
//			flightDate = new StringBuffer(date);
//		}
//
//		int dateValue = 0;
//		try
//		{
//			dateValue = Integer.parseInt(value);
//			if ("M".equals(dateVaribale))
//			{
//				if (dateValue < 10)
//				{
//					flightDate.replace(5, 7, "0" + dateValue);
//
//				}
//				else
//				{
//					flightDate.replace(5, 7, dateValue + "");
//				}
//			}
//			if ("D".equals(dateVaribale))
//			{
//				if (dateValue < 10)
//				{
//					flightDate.replace(8, 10, "0" + dateValue);
//
//				}
//				else
//				{
//					flightDate.replace(8, 10, dateValue + "");
//				}
//			}
//			if ("Y".equals(dateVaribale))
//			{
//
//				flightDate.replace(0, 4, dateValue + "");
//			}
//			flightDetailsBean.setDate(flightDate.toString());
//		}
//		catch (NumberFormatException e)
//		{
//			flightDate = null;
//			flightDetailsBean.setDate(null);
//		}
//
//		return flightDetailsBean;
//	}
//	private PAXBean getFieldMapping(TAFileBean tafileTypeBean, int fieldCodeID, String field, PAXBean paxBean)
//	{
//		KanaStringToRoman kstr = null;
//
//		String fieldValue = getFieldType(tafileTypeBean.getFieldDetails(), fieldCodeID);
//
//		try
//		{
//
//			switch (fieldCodeID)
//			{
//				case 1 :
//					{
//						paxBean.setTravelAgentCode(tafileTypeBean.getTaCode());
//						break;
//					}
//
//				case 2 :
//					{
//						paxBean.setUploadDate(field);
//						break;
//					}
//
//				case 3 :
//					{
//						if (field != null && field.length() > 20)
//							field = field.substring(0, 20);
//						paxBean.setTaBranch(field);
//						break;
//					}
//
//				case 4 :
//					{
//						kstr = KanaStringToRoman.getInstance();
//						String lastName = kstr.convert(field);
//						if (lastName != null && lastName.length() > 30)
//							lastName = lastName.substring(0, 30);
//						paxBean.setLastName(lastName);
//						break;
//					}
//
//				case 5 :
//					{
//						kstr = KanaStringToRoman.getInstance();
//						String firstName = kstr.convert(field);
//						if (firstName != null && firstName.length() > 30)
//							firstName = firstName.substring(0, 30);
//						paxBean.setFirstName(firstName);
//						break;
//					}
//
//				case 6 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						if (flightDetailsBean == null)
//							flightDetailsBean = new FlightDetailsBean();
//						paxBean.setArrivalFlightDetails(getFlightDetails(tafileTypeBean, field, flightDetailsBean));
//						break;
//					}
//
//				case 7 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						if (flightDetailsBean == null)
//							flightDetailsBean = new FlightDetailsBean();
//						flightDetailsBean.setDate(formatDateValue(tafileTypeBean, field));
//						paxBean.setArrivalFlightDetails(flightDetailsBean);
//						break;
//					}
//
//				case 8 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//						if (flightDetailsBean == null)
//							flightDetailsBean = new FlightDetailsBean();
//						paxBean.setDepartureFlightDetails(getFlightDetails(tafileTypeBean, field, flightDetailsBean));
//						break;
//					}
//
//				case 9 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//						if (flightDetailsBean == null)
//							flightDetailsBean = new FlightDetailsBean();
//						flightDetailsBean.setDate(formatDateValue(tafileTypeBean, field));
//						paxBean.setDepartureFlightDetails(flightDetailsBean);
//						break;
//					}
//
//				case 10 :
//					{
//						kstr = KanaStringToRoman.getInstance();
//						String primaryLastName = kstr.convert(field);
//						if (primaryLastName != null && primaryLastName.length() > 30)
//							primaryLastName = primaryLastName.substring(0, 30);
//						paxBean.setPrimaryPaxLastName(primaryLastName);
//						break;
//					}
//
//				case 11 :
//					{
//						kstr = KanaStringToRoman.getInstance();
//						String primaryFirstName = kstr.convert(field);
//						if (primaryFirstName != null && primaryFirstName.length() > 30)
//							primaryFirstName = primaryFirstName.substring(0, 30);
//						paxBean.setPrimaryPaxFirstName(primaryFirstName);
//						break;
//					}
//
//				case 12 :
//					{
//						break;
//					}
//
//				case 13 :
//					{
//						break;
//					}
//
//				case 14 :
//					{
//
//						AddressBean addressBean = paxBean.getAddress();
//						if (addressBean == null)
//							addressBean = new AddressBean();
//						if (field != null && field.length() > 10)
//							addressBean.setPostCodePrefix(field);
//						addressBean.setPostCodeSuffix("");
//						paxBean.setAddress(addressBean);
//
//						break;
//					}
//				case 15 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//
//						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "Y", field);
//						paxBean.setDepartureFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 16 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "M", field);
//						paxBean.setDepartureFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 17 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "D", field);
//						paxBean.setDepartureFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 18 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "Y", field);
//						paxBean.setArrivalFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 19 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "M", field);
//						paxBean.setArrivalFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 20 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						flightDetailsBean = getDateCalendarObject(flightDetailsBean, "D", field);
//						paxBean.setArrivalFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 21 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						flightDetailsBean = getFlightDetailsBean("AIRLINECODE", field, flightDetailsBean);
//						paxBean.setArrivalFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 22 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getArrivalFlightDetails();
//						flightDetailsBean = getFlightDetailsBean("FLIGHTNUMBER", field, flightDetailsBean);
//						paxBean.setArrivalFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 23 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//						flightDetailsBean = getFlightDetailsBean("AIRLINECODE", field, flightDetailsBean);
//						paxBean.setDepartureFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 24 :
//					{
//						FlightDetailsBean flightDetailsBean = paxBean.getDepartureFlightDetails();
//						flightDetailsBean = getFlightDetailsBean("FLIGHTNUMBER", field, flightDetailsBean);
//						paxBean.setDepartureFlightDetails(flightDetailsBean);
//						break;
//
//					}
//				case 25 :
//					{
//						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
//						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 1));
//
//						break;
//
//					}
//				case 26 :
//					{
//
//						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
//						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 2));
//						break;
//
//					}
//				case 27 :
//					{
//						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
//						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 3));
//
//						break;
//
//					}
//				case 28 :
//					{
//						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
//						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 4));
//						break;
//
//					}
//				case 29 :
//					{
//						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
//						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 5));
//						break;
//
//					}
//				case 30 :
//					{
//						AdditionalPAX additionalPax = paxBean.getAdditionalPAX();
//						paxBean.setAdditionalPAX(getAdditionalPax(additionalPax, field, 6));
//						break;
//
//					}
//
//			}
//		}
//		catch (KanaToRomanException ke)
//		{
//			PaxTraxLog.logError("IOException in finally block in PaxTrax::PAXDAO::uploadPAXFiles " + ke);
//
//		}
//
//		if (kstr != null)
//			kstr = null;
//		return paxBean;
//
//	}
//
//	private String getDateTokenValue(String dateValue, int index)
//	{
//		StringTokenizer str = new StringTokenizer(dateValue, "/");
//		int count = 0;
//		String tokenValue = null;
//		while (str.hasMoreTokens())
//		{
//			count++;
//			String token = str.nextToken();
//			if (count == index)
//			{
//				tokenValue = token;
//				if (tokenValue != null && tokenValue.length() == 1)
//				{
//					tokenValue = "0" + tokenValue;
//				}
//
//				break;
//			}
//
//		}
//		return tokenValue;
//	}
//	private String formatDateValue(TAFileBean taFileTypeBean, String dateValue)
//	{
//		String formattedDate = null;
//		String dateFormat = taFileTypeBean.getDateType();
//		dateFormat = dateFormat.toUpperCase();
//		String year = null, month = null, day = null;
//		if (dateFormat.indexOf("/") == -1)
//		{
//			int yearStartIndex = dateFormat.indexOf("YYYY");
//			int monthStartIndex = dateFormat.indexOf("MM");
//			int dayStartIndex = dateFormat.indexOf("DD");
//
//			if (dateValue != null && dateValue.length() >= yearStartIndex + 4)
//				year = dateValue.substring(yearStartIndex, yearStartIndex + 4);
//			if (dateValue != null && dateValue.length() >= monthStartIndex + 2)
//				month = dateValue.substring(monthStartIndex, monthStartIndex + 2);
//			if (dateValue != null && dateValue.length() >= dayStartIndex + 2)
//				day = dateValue.substring(dayStartIndex, dayStartIndex + 2);
//
//		}
//		else
//		{
//			StringTokenizer str = new StringTokenizer(dateFormat, "/");
//			int count = 0;
//			while (str.hasMoreTokens())
//			{
//				count++;
//				String token = str.nextToken();
//				if ("DD".equals(token))
//				{
//					day = getDateTokenValue(dateValue, count);
//				}
//				if ("MM".equals(token))
//				{
//					month = getDateTokenValue(dateValue, count);
//				}
//				if ("YYYY".equals(token))
//				{
//					year = getDateTokenValue(dateValue, count);
//				}
//
//			}
//
//		}
//		if (year != null && month != null && day != null)
//			return (year + "-" + month + "-" + day);
//		else
//			return null;
//
//	}
	/**
	 * Method saveFile.
	 * 
	 * @param file FormFile
	 * @return String
	 * Method to save a file in the server
	 */
	private void saveFile(FormFile file) throws PaxTraxSystemException, FileNotFoundException
	{
		try
		{

			PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::saveFile::Begin");

			InputStream iStream = file.getInputStream();
			//iStream.read()
			//byte b[]=new byte[file.getFileSize()]; 
			//b= file.getFileData();
			FileOutputStream oStream = new FileOutputStream(PaxTraxConstants.FILE_UPLOAD_BASE + file.getFileName());
			//FileWriter fileWriter = new FileWriter(PaxTraxConstants.FILE_UPLOAD_BASE + file.getFileName());
			Writer fileWriter = new OutputStreamWriter(oStream, "Shift_JIS");
			//for(int i=0;i<b.length;i++)
			//				fileWriter.write(b[i]);
			//fileWriter.close();

			int bytesRead = 0;
			//byte[] buffer = new byte[file.getFileSize()];
			byte[] buffer = new byte[8192];
			while ((bytesRead = iStream.read(buffer, 0, 8192)) != -1)
			{
				oStream.write(buffer, 0, bytesRead);

			}
			/*for(int i=0;i <buffer.length;i++)*/

			oStream.close();
			iStream.close();

			PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::saveFile::End");
		}
		catch (FileNotFoundException fileNotFoundException)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXFileUploadAction::saveFile", fileNotFoundException);
			throw new FileNotFoundException();
		}
		catch (IOException ioe)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXFileUploadAction::saveFile", ioe);
			throw new PaxTraxSystemException(ioe);
		}
	}

	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::changeLanguage::Begin");

		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String page = request.getParameter(PaxTraxConstants.PAGE);

		if (language != null && country != null && page != null)
		{
			super.changeLanguage(request, language, country);

			if (page.equals("uploadPAXFiles"))
				forwardPage = PaxTraxConstants.FWD_PAX_FILE_UPLOAD_PAGE;
			else
				forwardPage = "goToUploadPAXFileConfirmation";
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::changeLanguage::End");

		return (mapping.findForward(forwardPage));
	}
	public ActionForward taFileFTP(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::TAFileFTP::Begin");
		PAXDelegate paxDelegate = new PAXDelegate();
		paxDelegate.getFTPParameters();
		PaxTraxLog.logDebug("PaxTrax::PAXFileUploadAction::TAFileFTP::End");
		return (mapping.findForward(null));
	}

}
