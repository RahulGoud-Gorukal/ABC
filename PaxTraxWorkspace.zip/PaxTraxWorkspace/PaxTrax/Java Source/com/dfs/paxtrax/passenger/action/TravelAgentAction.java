package com.dfs.paxtrax.passenger.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.actionform.TravelAgentForm;
import com.dfs.paxtrax.passenger.exception.TravelAgentException;
import com.dfs.paxtrax.passenger.service.TravelAgentDelegate;
import com.dfs.paxtrax.passenger.valueobject.TravelAgentBean;


/**
 * 
 * The Action Class for Travel Agent Related Flows (Creation and Maintenance)
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TravelAgentAction extends PaxTraxAction
{
	/**
	 * Method travelAgentPage.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the Travel Agent Creation Page 
	 */
	public ActionForward travelAgentPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::travelAgentPage::Begin");
		
		TravelAgentBean ta = new TravelAgentBean();
		TravelAgentForm tForm = (TravelAgentForm) form;
		
		/*
		 * Commented as part of the changes made for converting country from a drop down to a textfield 
		 * 
		
		ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
		tForm.setCountryList(
			rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
		ta.setCountryRefId(PaxTraxConstants.COUNTRY);
		*/
		
		ta.setCountry("Japan");
		tForm.setTravelAgentBean(ta);
		
		HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);			
        
        PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::travelAgentPage::End");

		return mapping.findForward(PaxTraxConstants.FWD_TA_CREATE_PAGE);
	}

	/**
	 * Method saveTravelAgentDetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to create a Travel Agent record
	 */
	public ActionForward saveTravelAgentDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::saveTravelAgentDetails::Begin");

			TravelAgentDelegate delegate = new TravelAgentDelegate();
			TravelAgentForm tForm = (TravelAgentForm) form;
			TravelAgentBean tBean = tForm.getTravelAgentBean();
			String travelAgentCode = tBean.getTravelAgentCode();
			
			if(travelAgentCode!=null)
				travelAgentCode = travelAgentCode.toUpperCase();
			
			tBean.setTravelAgentCode(travelAgentCode);
			
			/*
			 * Commented as part of the changes made for converting country from a drop down to a textfield 
			 * 
			
			if (tBean.getCountry() != null && tBean.getCountry().equals("-1"))
			{
				tBean.setCountry(null);
				tBean.setCountryRefId(null);
			}
			
			*/
			
			HttpSession session = request.getSession();
			String user = (String)session.getAttribute("userId");
			
			if(user!=null)
				tBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);				

			delegate.saveTravelAgentDetails(tBean);
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::saveTravelAgentDetails::End");
		}
		catch (TravelAgentException te)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::saveTravelAgentDetails", te);
			request.setAttribute("errorCode", "" + te.getErrorCode());
			return mapping.findForward(PaxTraxConstants.FWD_TA_CREATE_PAGE);
		}

		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::saveTravelAgentDetails", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(
			PaxTraxConstants.FWD_TA_CREATE_CONFIRMATION_PAGE);

	}

	/**
	 * Method maintainTravelAgentPage.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the Maintain Travel Agent page
	 */
	public ActionForward maintainTravelAgentPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::maintainTravelAgentPage::Begin");
		
		TravelAgentBean ta = new TravelAgentBean();
		TravelAgentForm tform = (TravelAgentForm) form;

		/*
		 * Commented as part of the changes made for converting country from a drop down to a textfield 
		 * 
		
		ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
		tform.setCountryList(
			rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
		ta.setCountryRefId(PaxTraxConstants.COUNTRY);
		*/
		
		tform.setTravelAgentBean(ta);

		HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);			
        
        PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::maintainTravelAgentPage::End");

		return (mapping.findForward(PaxTraxConstants.FWD_TA_MAINTAIN_PAGE));		
	}

	/**
	 * Method validateTA.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to validate if the specified Travel Agent Code exists in the database
	 */
	public ActionForward validateTA(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		TravelAgentForm tForm = (TravelAgentForm) form;
		TravelAgentBean taBean = tForm.getTravelAgentBean();

		try
		{
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::validateTA::Begin");
			
			TravelAgentDelegate taDelegate = new TravelAgentDelegate();
			taBean = taDelegate.getTravelAgentDetails(taBean);

			if (taBean.getAgencyName() != null)
			{
				tForm.setTravelAgentBean(taBean);
				String disableTAScreen = "false";
				request.setAttribute(
					PaxTraxConstants.DISABLE_TA_SCREEN,
					disableTAScreen);
			}
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::validateTA::End");
		}
		catch (TravelAgentException te)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::validateTA", te);
			request.setAttribute("errorCode", "" + te.getErrorCode());

			/* This is done to avoid the previous search results being taken into the 
			 * next search result because of a browser back operation */
			String travelAgentCode = taBean.getTravelAgentCode();
			taBean = new TravelAgentBean();
			taBean.setTravelAgentCode(travelAgentCode);
			tForm.setTravelAgentBean(taBean);
			return mapping.findForward(PaxTraxConstants.FWD_TA_MAINTAIN_PAGE);
		}

		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::validateTA", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(PaxTraxConstants.FWD_TA_MAINTAIN_PAGE));

	}

	/**
	 * Method loadTADetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to load the Travel Agent record on to the Maintain TA page from the search page
	 */
	public ActionForward loadTADetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::loadTADetails::Begin");
		
		HttpSession session = request.getSession();
		ArrayList allRecords =
			(ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);

		String indexOfRecord = request.getParameter("indexId");
		int indexId = 0;

		if (indexOfRecord != null)
		{
			indexId = Integer.parseInt(indexOfRecord);
			indexId = indexId - 1;

			TravelAgentForm taForm = (TravelAgentForm) form;
			TravelAgentBean taBean = (TravelAgentBean)allRecords.get(indexId);
			
			String strIndex = "" + indexId;
			request.setAttribute("indexOfTARecord", strIndex);
			
			/*
			 * Commented as part of the changes made for converting country from a drop down to a textfield 
			 * 
			
			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();			
			try{
			taForm.setCountryList(rdDelegate.loadReferenceData(PaxTraxConstants.COUNTRY));
			}catch(PaxTraxSystemException ptse)
			{
				PaxTraxLog.logError("PaxTraxSystemException Occured in TravelAgentAction:loadTADetails",ptse);
				return (mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));
			}
			taBean.setCountryRefId(PaxTraxConstants.COUNTRY);
			*/
			
			taForm.setTravelAgentBean(taBean);

			String disableTAScreen = "false";
			request.setAttribute(PaxTraxConstants.DISABLE_TA_SCREEN, disableTAScreen);
			
			request.setAttribute("fromPage", "searchTA");

			String pageNumber = request.getParameter("pageNumber");
			if (pageNumber != null)
				request.setAttribute("fromPageNumber", pageNumber);
			else
				request.setAttribute("fromPageNumber", "1");

		}
		
		PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::loadTADetails::End");

		return (mapping.findForward(PaxTraxConstants.FWD_TA_MAINTAIN_PAGE));
	}

	/**
	 * Method updateTravelAgentDetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to update the Travel Agent Record
	 */
	public ActionForward updateTravelAgentDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::updateTravelAgentDetails::Begin");
			
			TravelAgentDelegate delegate = new TravelAgentDelegate();
			TravelAgentForm taForm = (TravelAgentForm) form;
			TravelAgentBean taBean = taForm.getTravelAgentBean();
			
			/*
			 * Commented as part of the changes made for converting country from a drop down to a textfield 
			 * 
			
			if (taBean.getCountry() != null && taBean.getCountry().equals("-1"))
			{
				taBean.setCountry(null);
				taBean.setCountryRefId(null);
			}
			*/
			
			HttpSession session = request.getSession();
			String user = (String)session.getAttribute("userId");
			
			if(user!=null)
				taBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);				

			delegate.updateTravelAgentDetails(taBean);

			String fromPage = request.getParameter("fromPage");
			String fromPageNumber = request.getParameter("fromPageNumber");
			
			if(fromPage!=null && fromPageNumber!=null)
			{
				request.setAttribute("fromPage",fromPage);
				request.setAttribute("fromPageNumber",fromPageNumber);
			}
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::updateTravelAgentDetails::End");
			
		}

		catch (TravelAgentException te)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::updateTravelAgentDetails", te);
			request.setAttribute("errorCode", "" + te.getErrorCode());
			return mapping.findForward(PaxTraxConstants.FWD_TA_MAINTAIN_PAGE);
		}

		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::updateTravelAgentDetails", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (
			mapping.findForward(
				PaxTraxConstants.FWD_TA_MAINTAIN_CONFIRMATION_PAGE));
	}

	/**
	 * Method deActivateTravelAgent.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to deactivate the Travel Agent
	 */
	public ActionForward deActivateTravelAgent(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::deActivateTravelAgent::Begin");
			
			TravelAgentForm taForm = (TravelAgentForm) form;
			TravelAgentBean taBean = taForm.getTravelAgentBean();

			HttpSession session = request.getSession();
			String user = (String)session.getAttribute("userId");
			
			if(user!=null)
				taBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);				

			TravelAgentDelegate delegate = new TravelAgentDelegate();
			delegate.deactivateTravelAgent(taBean);

		
			String deactivated = "true";
			request.setAttribute(PaxTraxConstants.TA_DEACTIVATED, deactivated);
			
			String fromPage = request.getParameter("fromPage");
			String fromPageNumber = request.getParameter("fromPageNumber");
			
			if(fromPage!=null && fromPageNumber!=null)
			{
				request.setAttribute("fromPage",fromPage);
				request.setAttribute("fromPageNumber",fromPageNumber);
			}
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::deActivateTravelAgent::End");
			
		}

		catch (TravelAgentException te)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::deActivateTravelAgent", te);
			request.setAttribute("errorCode", "" + te.getErrorCode());
			return mapping.findForward(PaxTraxConstants.FWD_TA_MAINTAIN_PAGE);
		}

		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::deActivateTravelAgent", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (
			mapping.findForward(
				PaxTraxConstants.FWD_TA_MAINTAIN_CONFIRMATION_PAGE));
	}

	/**
	 * Method postCodeLookup.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to handle the Post Code Lookup 
	 */
	public ActionForward postCodeLookup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forwardTo = "";

		try
		{
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::postCodeLookup::Begin");
			
			TravelAgentForm taForm = (TravelAgentForm) form;
			TravelAgentBean taBean = taForm.getTravelAgentBean();

			TravelAgentDelegate delegate = new TravelAgentDelegate();
			taBean = delegate.postCodeLookup(taBean);
			taForm.setTravelAgentBean(taBean);

			if (request.getParameter(PaxTraxConstants.PAGE).equals("createTA"))
				forwardTo = PaxTraxConstants.FWD_TA_CREATE_PAGE;
			else
			{
				String disableTAScreen = "false";
				request.setAttribute(
					PaxTraxConstants.DISABLE_TA_SCREEN,
					disableTAScreen);
				forwardTo = PaxTraxConstants.FWD_TA_MAINTAIN_PAGE;
			}
			
			request.setAttribute("postCodeLookup","true");			
			
			PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::postCodeLookup::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::TravelAgentAction::postCodeLookup", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(forwardTo);
	}
	
	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::changeLanguage::Begin");
		
		String forwardPage = "";
		
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		
		if(language!=null && country!=null && page!=null)		
			super.changeLanguage(request, language, country);
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;					
		
		if(page.equals("createTA"))
			forwardPage = PaxTraxConstants.FWD_TA_CREATE_PAGE;
		
		if(page.equals("createTAConf"))
			forwardPage = PaxTraxConstants.FWD_TA_CREATE_CONFIRMATION_PAGE;
			
		if(page.equals("maintainTA"))
		{
			forwardPage = PaxTraxConstants.FWD_TA_MAINTAIN_PAGE;
			String disable = request.getParameter("disable");
			
			if(disable.equals("false"))
				request.setAttribute(PaxTraxConstants.DISABLE_TA_SCREEN, disable);
		}
		
		if(page.equals("maintainTAConf"))
			forwardPage = PaxTraxConstants.FWD_TA_MAINTAIN_CONFIRMATION_PAGE;
			
		String errorCode = request.getParameter("errc");
		
		if(errorCode!=null)		
		{
			if(!(errorCode.equals("-1")))
			{
				/*
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.ACTION_MESSAGE_PAX,new ActionMessage(errorCode));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				*/
				request.setAttribute("errorCode",errorCode);						
			}
		}
		
		String deactivatedTA = request.getParameter("deactivatedTA");
		if(deactivatedTA !=null)
			request.setAttribute(PaxTraxConstants.TA_DEACTIVATED, "true");

		PaxTraxLog.logDebug("PaxTrax::TravelAgentAction::changeLanguage::End");
			
		return(mapping.findForward(forwardPage));
	}

}
