package com.dfs.paxtrax.passenger.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 * 
 * The Address value object used in the PAX Bean
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/12/2004	Joseph			Created   
 */
public class UploadedPAXListBean extends PaxTraxValueObject
{

	private String fileName = null;

	private ArrayList paxBeanList = null;
	/**
	 * Returns the fileName.
	 * @return String
	 */
	public String getFileName()
	{
		return fileName;
	}

	/**
	 * Returns the paxBeanList.
	 * @return ArrayList
	 */
	public ArrayList getPaxBeanList()
	{
		return paxBeanList;
	}

	/**
	 * Sets the fileName.
	 * @param fileName The fileName to set
	 */
	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	/**
	 * Sets the paxBeanList.
	 * @param paxBeanList The paxBeanList to set
	 */
	public void setPaxBeanList(ArrayList paxBeanList)
	{
		this.paxBeanList = paxBeanList;
	}

}
