package com.dfs.paxtrax.passenger.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.passenger.valueobject.TravelAgentBean;



/**
 * 
 * The Action Form for the Create and Maintain Travel Agent flows
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class TravelAgentForm extends PaxTraxActionForm
{
	/** The Travel Agent Bean that holds that all Travel Agent Details  */
	private TravelAgentBean travelAgentBean = null;

	/** The list of all Country Values  */
	private ArrayList countryList = null;

	/**
	 * Method getTravelAgentBean.
	 * @return TravelAgentBean
	 */
	public TravelAgentBean getTravelAgentBean()
	{
		return travelAgentBean;
	}

	/**
	 * Method setTravelAgentBean.
	 * @param travelAgentBean
	 */
	public void setTravelAgentBean(TravelAgentBean travelAgentBean)
	{
		this.travelAgentBean = travelAgentBean;
	}

	/**
	 * Returns the countryList.
	 * @return ArrayList
	 */
	public ArrayList getCountryList()
	{
		return countryList;
	}

	/**
	 * Sets the countryList.
	 * @param countryList The countryList to set
	 */
	public void setCountryList(ArrayList countryList)
	{
		this.countryList = countryList;
	}

}
