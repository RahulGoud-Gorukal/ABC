package com.dfs.paxtrax.passenger.service;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.passenger.business.PAXBO;
import com.dfs.paxtrax.passenger.business.PAXBOHome;
import com.dfs.paxtrax.passenger.exception.PAXException;
import com.dfs.paxtrax.passenger.helpers.TAFileFTPHelper;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.InvalidPAXSearchResultBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TAFileBean;

/**
 * 
 * The Delagate that will route requests to the EJB tier of PAX
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Anand			Created   
 */
public class PAXDelegate
{

	public PAXDelegate()
	{
	}

	/**
	 * Method savePAXDetails.
	 * 
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * Method to save a PAX record
	 */
	public PAXBean savePAXDetails(PAXBean paxBean) throws PaxTraxSystemException, PAXException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::savePAXDetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();
			paxBean = remote.savePAXDetails(paxBean);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::savePAXDetails::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::savePAXDetails", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::savePAXDetails", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::savePAXDetails", ce);
			throw new PaxTraxSystemException(ce);
		}

		return (paxBean);
	}

	/**
	 * Method updatePAXDetails.
	 * 
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to update a PAX record
	 */
	public PAXBean updatePAXDetails(PAXBean paxBean) throws PaxTraxSystemException, PAXException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::updatePAXDetails::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();
			paxBean = remote.updatePAXDetails(paxBean);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::updatePAXDetails::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::updatePAXDetails", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::updatePAXDetails", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::updatePAXDetails", ce);
			throw new PaxTraxSystemException(ce);
		}

		return (paxBean);
	}

	/**
	 * Method searchPAXDetails.
	 * 
	 * @param paxBean PAXBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to get the search for PAX records
	 */
	public ArrayList searchPAXDetails(PAXBean paxBean) throws PaxTraxSystemException, PAXException
	{
		ArrayList paxDetails = new ArrayList();

		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::searchPAXDetails::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();
			paxDetails = remote.searchPAXRecords(paxBean);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::searchPAXDetails::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::searchPAXDetails", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::searchPAXDetails", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::searchPAXDetails", ce);
			throw new PaxTraxSystemException(ce);
		}

		return (paxDetails);

	}

	/**
	 * Method searchInvalidPaxRecords.
	 * 
	 * @param paxBean PAXBean
	 * @return ArrayList
	 * The method to search for Invalid PAX Records
	 */
	public ArrayList searchInvalidPaxRecords(InvalidPAXSearchResultBean invalidPAX) throws PaxTraxSystemException, PAXException
	{
		ArrayList invalidPAXList = new ArrayList();
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::searchInvalidPaxRecords::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();
			invalidPAXList = remote.searchInvalidPaxRecords(invalidPAX);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::searchInvalidPaxRecords::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::searchInvalidPaxRecords", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::searchInvalidPaxRecords", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::searchInvalidPaxRecords", ce);
			throw new PaxTraxSystemException(ce);
		}

		return invalidPAXList;
	}

	/**
	 * Method uploadFile.
	 * 
	 * @param filesList ArrayList
	 * @throws PaxTraxSystemException
	 * Method to upload Data from the PAX Files
	 */
	public ArrayList uploadPAXFile(ArrayList filesList, String userId) throws PaxTraxSystemException
	{
		ArrayList resultList = null;
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::uploadPAXFile::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			resultList = remote.uploadPAXFiles(filesList, userId);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::uploadPAXFile::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::uploadPAXFile", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::uploadPAXFile", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::uploadPAXFile", ce);
			throw new PaxTraxSystemException(ce);
		}
		return resultList;

	}

	/**
	 * Method loadActiveTravelAgents.
	 * 
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * The method to get the list of active travel Agents
	 */
	public ArrayList loadActiveTravelAgents() throws PaxTraxSystemException, PAXException
	{
		ArrayList taCodeList = new ArrayList();

		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::loadActiveTravelAgents::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			taCodeList = remote.loadActiveTravelAgents();

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::loadActiveTravelAgents::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::loadActiveTravelAgents", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::loadActiveTravelAgents", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::loadActiveTravelAgents", ce);
			throw new PaxTraxSystemException(ce);
		}

		return taCodeList;
	}

	/**
	 * Method postCodeLookup.
	 * 
	 * @param addrBean AddressBean
	 * @return AddressBean
	 * @throws PaxTraxSystemException
	 * The method to perform the postcode Lookup
	 */
	public AddressBean postCodeLookup(AddressBean addrBean) throws PaxTraxSystemException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::postCodeLookup::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			addrBean = remote.postCodeLookup(addrBean);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::postCodeLookup::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::postCodeLookup", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::postCodeLookup", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::postCodeLookup", ce);
			throw new PaxTraxSystemException(ce);
		}

		return (addrBean);

	}

	public void updatePAXNo(PAXBean paxBean) throws PaxTraxSystemException, PAXException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::updatePAXNo::Begin");

		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			remote.updatePAXNo(paxBean);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::postCodeLookup", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::postCodeLookup", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::postCodeLookup", ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::updatePAXNo::End");

	}
	public ArrayList validateTA(ArrayList filesList) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::updatePAXNo::Begin");
		ArrayList resultList = null;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			resultList = remote.validateTA(filesList);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::updatePAXNo", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::updatePAXNo", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::updatePAXNo", ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::updatePAXNo::End");
		return resultList;
	}

	public TAFileBean getFileTypeBean(String fileName) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getFileTypeBean::Begin");
		TAFileBean taFileBean = null;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			taFileBean = remote.getFileTypeBean(fileName);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFileTypeBean", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFileTypeBean", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFileTypeBean", ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getFileTypeBean::End");
		return taFileBean;
	}

	public ArrayList insertPaxRecordFromTAFile(ArrayList paxList, String userId, TAFileBean taFileTypeBean) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::insertPaxRecordFromTAFile::Begin");
		ArrayList resultList = null;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			resultList = remote.insertPaxRecordFromTAFile(paxList, userId, taFileTypeBean);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::insertPaxRecordFromTAFile", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::insertPaxRecordFromTAFile", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::insertPaxRecordFromTAFile", ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::insertPaxRecordFromTAFile::End");
		return resultList;
	}
	public ArrayList getFTPParameters() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getFTPParameters::Begin");
		ArrayList resultList = null;
		ArrayList totalPaxList = new ArrayList();
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			resultList = remote.getFTPParameters();
			TAFileFTPHelper tAFileFTPhelper = new TAFileFTPHelper();
			ArrayList fileNameList = new ArrayList();
			fileNameList = tAFileFTPhelper.transferFTPFiles(resultList);
			
			
			ArrayList newList  = new ArrayList();
				int taFTPfileNameListSize =0;
			if(fileNameList != null)
				taFTPfileNameListSize = fileNameList.size();
			for(int z=0;z<taFTPfileNameListSize;z++)
			{
				TAFileBean tempBean = (TAFileBean)fileNameList.get(z);
				newList.add(tempBean.getFileName());
			}
			
			resultList = remote.validateTA(newList);
			ArrayList taFileBeanList = new ArrayList();
			for (int i = 0; i < resultList.size(); i++)
			{

				String fileName = (String) resultList.get(i);
				TAFileBean taFileBean = remote.getFileTypeBean(fileName);
				taFileBeanList.add(taFileBean);
			}

			for (int j = 0; j < taFileBeanList.size(); j++)
			{
				TAFileBean taFileBean = (TAFileBean) taFileBeanList.get(j);
				ArrayList paxPerFileList = tAFileFTPhelper.readFile(taFileBean, PaxTraxConstants.TFAFTPUserId);
				
				totalPaxList.addAll(paxPerFileList);
			}
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFTPParameters", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFTPParameters", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFTPParameters", ce);
			throw new PaxTraxSystemException(ce);
		}
		catch (IOException ioe)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getFTPParameters", ioe);

		}

		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getFTPParameters::End");
		return totalPaxList;
	}
	
   public ArrayList getMatchingTA(String taName) throws PaxTraxSystemException, PAXException
	{
		ArrayList taList = new ArrayList();

		try
		{
			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getMatchingTA::Begin");

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home = (PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();

			taList = remote.getMatchingTA(taName);

			PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getMatchingTA::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getMatchingTA", ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getMatchingTA", re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::PAXDelegate::getMatchingTA", ce);
			throw new PaxTraxSystemException(ce);
		}

		return taList;
	}
	//	Added for CR1832 starts
	
	public ArrayList getPaxChangesLog(String TEPOS)	throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getPaxChangesLog::Begin");
		ArrayList VisitChanges = null;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();

			Object obj = locator.getEJBHome(PaxTraxConstants.PAX_BO_HOME_JNDI);
			PAXBOHome home =
				(PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();
			VisitChanges = remote.getPaxChangesLog(TEPOS);
		}
		catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::PAXDelegate::getPaxChangesLog::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getPaxChangesLog::End");

		return VisitChanges;
	}
	
/*	public ArrayList getPaxDetails(String VisitFlag)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getPaxDetails::Begin");
		ArrayList VisitChanges = null;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();

			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			PAXBOHome home =
				(PAXBOHome) PortableRemoteObject.narrow(obj, PAXBOHome.class);
			PAXBO remote = home.create();
			VisitChanges = remote.getPaxDetails(VisitFlag);
		}
		catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::PAXDelegate::getPaxDetails::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		PaxTraxLog.logDebug("PaxTrax::PAXDelegate::getPaxDetails::End");

		return VisitChanges;
	}
	*/
//	Added for CR1832 ends

}
