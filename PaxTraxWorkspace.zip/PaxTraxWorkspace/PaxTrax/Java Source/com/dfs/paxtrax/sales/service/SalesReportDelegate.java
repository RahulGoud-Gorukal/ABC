package com.dfs.paxtrax.sales.service;

/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.sales.business.SalesReportBO;
import com.dfs.paxtrax.sales.business.SalesReportBOHome;
import com.dfs.paxtrax.sales.valueobject.SalesReportBean;
import com.dfs.paxtrax.sales.valueobject.SalesReportExtnBean;



/**
* This Delegate  class is used for inserting and updating cage records
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 29/05/2004    Joseph Oommen A Created
*/
public class SalesReportDelegate
{

	/*
	 * Holds service locator instance
	 */
	private ServiceLocator serviceLocator = null;
	/*
	 * Holds the Home interface
	 */
	private SalesReportBOHome salesReportBOHome = null;
	/*
	 * Hold the remote interface
	 */
	private SalesReportBO salesReportBO = null;
	/*
	 *Default Construtor for SalesReportDelegate
	 */

	public SalesReportDelegate()
	{
	}

	/*
	 * Jndi look up is performed here
	 */
	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::SalesReportDelegate::jndiCall::Begin");
		try
		{
			
			serviceLocator = ServiceLocator.getInstance();
			salesReportBOHome =
				(SalesReportBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						"ejb/com/dfs/paxtrax/sales/business/SalesReportBOHome"),
					SalesReportBOHome.class);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}
		if (salesReportBOHome == null)
		{
			throw new PaxTraxSystemException(PaxTraxConstants.STAMP_DUTY_BO_HOME_NOT_FOUND);
		}
		try
		{
			salesReportBO = salesReportBOHome.create();
		}
		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportDelegate::jndiCall::End");
	}
	
	
	/**
	 * Saves details details into the database by 
	 * delegating the request to  the cage  bean. 
	 * @param cageBean CageBean object
	 * @throws PaxTraxSystemException,CageException
	 */
	public ArrayList listLocations()
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::listLocations::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.listLocations();
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: listLocations() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::listLocations::End");
		return salesReportList;
	}


	/**
	 * Saves sales report details into the database by 
	 * delegating the request to  the cage  bean. 
	 * @param SalesReportBean salesReportBean
	 * @throws PaxTraxSystemException
	 */
	public ArrayList createSalesAssociateReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesAssociateReport::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.createSalesAssociateReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: createSalesAssociateReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesAssociateReport::End");
		return salesReportList;
	}
	
	public SalesReportBean getSalesAssociateReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getSalesAssociateReport::Begin");
		
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportBean = salesReportBO.getSalesAssociateReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: getSalesAssociateReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getSalesAssociateReport::End");
		return salesReportBean;
	}
	/**
	 * Saves sales report details into the database by 
	 * delegating the request to  the cage  bean. 
	 * @param SalesReportBean salesReportBean
	 * @throws PaxTraxSystemException
	 */
	public ArrayList createSalesDepartmentReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesDepartmentReport::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.createSalesDepartmentReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: createSalesDepartmentReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesDepartmentReport::End");
		return salesReportList;
	}
	
	
	public SalesReportBean getSalesDepartmentReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getSalesDepartmentReport::Begin");
		
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportBean = salesReportBO.getSalesDepartmentReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: getSalesDepartmentReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getSalesDepartmentReport::End");
		return salesReportBean;
	}
	
	
	
	/**
	 * Saves sales report details into the database by 
	 * delegating the request to  the cage  bean. 
	 * @param SalesReportBean salesReportBean
	 * @throws PaxTraxSystemException
	 */
	public ArrayList createSalestTerminalReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalestTerminalReport::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.createTerminalReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: createSalestTerminalReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalestTerminalReport::End");
		return salesReportList;
	}
	
	
	
	public SalesReportBean getSalestTerminalReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getSalestTerminalReport::Begin");
		
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportBean = salesReportBO.getTerminalReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: getSalestTerminalReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getSalestTerminalReport::End");
		return salesReportBean;
	}


	/**
	 * Saves sales report details into the database by 
	 * delegating the request to  the cage  bean. 
	 * @param SalesReportBean salesReportBean
	 * @throws PaxTraxSystemException
	 */
	public ArrayList createSalesTenderReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesTenderReport::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.createSalesTenderReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: createSalesTenderReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesTenderReport::End");
		return salesReportList;
	}
	
	public ArrayList generateSalesByHourReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::generateSalesByHourReport::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
			salesReportList = salesReportBO.generateSalesByHourReport(salesReportBean);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: generateSalesByHourReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportDelegate::generateSalesByHourReport::End");
		return salesReportList;
	}	

	public ArrayList listAllLocations()
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::listAllLocations::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.listAllLocations();
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: listAllLocations : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::listAllLocations::End");
		return salesReportList;
	}
	
	/*
	 * For sales by location report 
	*/
	
	public ArrayList createSalesLocationReport(SalesReportBean salesReportBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesLocationReport::Begin");
		ArrayList salesReportList = null;
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportList = salesReportBO.createSalesLocationReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: createSalesLocationReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::createSalesLocationReport::End");
		return salesReportList;
	}

	
	public SalesReportExtnBean getDFSOwnedSalesReport(SalesReportExtnBean salesReportBean) throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getDFSOwnedSalesReport::Begin");
		
		if (salesReportBOHome == null)
		{
			jndiCall();
		}
		try
		{
		
			salesReportBean = salesReportBO.getDFSOwnedSalesReport(salesReportBean);
		
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("SalesReportDelegate: getDFSOwnedSalesReport() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SalesReportDelegate::getDFSOwnedSalesReport::End");
		return salesReportBean;
	}

}
