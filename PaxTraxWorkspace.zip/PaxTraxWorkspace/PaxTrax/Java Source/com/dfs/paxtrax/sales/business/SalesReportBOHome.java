package com.dfs.paxtrax.sales.business;
/**
 * Home interface for Enterprise Bean: SalesReportBO
 */
public interface SalesReportBOHome extends javax.ejb.EJBHome
{
	/**
	 * Creates a default instance of Session Bean: SalesReportBO
	 */
	public com.dfs.paxtrax.sales.business.SalesReportBO create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
