package com.dfs.paxtrax.sales.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 107316
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SalesByHourBean extends PaxTraxValueObject {
	
	String departmentID = null;
	String departmentDesc = null;
	double hourSales[] = new double[24];
	/**
	 * Returns the departmentDesc.
	 * @return String
	 */
	public String getDepartmentDesc() {
		return departmentDesc;
	}

	/**
	 * Returns the departmentID.
	 * @return String
	 */
	public String getDepartmentID() {
		return departmentID;
	}

	/**
	 * Returns the hourSales.
	 * @return float[]
	 */
	public double getHourSales(int i) {
		return this.hourSales[i];
	}

	/**
	 * Sets the departmentDesc.
	 * @param departmentDesc The departmentDesc to set
	 */
	public void setDepartmentDesc(String departmentDesc) {
		this.departmentDesc = departmentDesc;
	}

	/**
	 * Sets the departmentID.
	 * @param departmentID The departmentID to set
	 */
	public void setDepartmentID(String departmentID) {
		this.departmentID = departmentID;
	}

	/**
	 * Sets the hourSales.
	 * @param hourSales The hourSales to set
	 */
	public void setHourSales(int i, double hourSalesAtI) {
		this.hourSales[i] = hourSalesAtI;
	}

}
