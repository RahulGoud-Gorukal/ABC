package com.dfs.paxtrax.sales.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.sales.valueobject.SalesReportBean;

/**
 * This is action form which contains Cage attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/09/2004   Joseph Oommen A     Created   
*/

public class SalesReportForm extends PaxTraxActionForm
{

	private ArrayList locationList = null;
	private ArrayList resultList = null;
	private ArrayList hourList =null;
	private ArrayList minuteList=null;
	
		private ArrayList reverseHourList =null;
	private ArrayList reverseMinuteList=null;
	private SalesReportBean salesReportBean = null;
	private String salesGrossTotal = null;
	private String salesDiscountsTotal = null;
	private String salesNetTotal = null;
	private String refundsGrossTotal = null;
	private String refundsDiscountsTotal = null;
	private String refundsNetTotal = null;
	private String netSalesTotal = null;
	private long unitsSoldTotal = 0;
	private long unitsRefundedTotal = 0;
	private long transactionCountTotal = 0;
	private String fromDateDisplay=null;
	private String toDateDisplay =null;
	private String fromTimeDisplay =null;
	private String toTimeDisplay = null;
	private String locationDescription;

	
	public void reset() {
		salesGrossTotal = null;
		salesDiscountsTotal = null;
		salesNetTotal = null;
		refundsGrossTotal = null;
		refundsDiscountsTotal = null;
		refundsNetTotal = null;
		netSalesTotal = null;
		unitsSoldTotal = 0;
		unitsRefundedTotal = 0;
		transactionCountTotal = 0;
		fromDateDisplay=null;
		toDateDisplay =null;
		fromTimeDisplay =null;
		toTimeDisplay = null;		
		locationDescription = null;
	}
	/**
	 * Returns the locationList.
	 * @return ArrayList
	 */
	public ArrayList getLocationList()
	{
		return locationList;
	}

	/**
	 * Returns the netSalesTotal.
	 * @return String
	 */
	public String getNetSalesTotal()
	{
		return netSalesTotal;
	}

	/**
	 * Returns the refundsDiscountsTotal.
	 * @return String
	 */
	public String getRefundsDiscountsTotal()
	{
		return refundsDiscountsTotal;
	}

	/**
	 * Returns the refundsGrossTotal.
	 * @return String
	 */
	public String getRefundsGrossTotal()
	{
		return refundsGrossTotal;
	}

	/**
	 * Returns the refundsNetTotal.
	 * @return String
	 */
	public String getRefundsNetTotal()
	{
		return refundsNetTotal;
	}

	/**
	 * Returns the resultList.
	 * @return ArrayList
	 */
	public ArrayList getResultList()
	{
		return resultList;
	}

	/**
	 * Returns the salesDiscountsTotal.
	 * @return String
	 */
	public String getSalesDiscountsTotal()
	{
		return salesDiscountsTotal;
	}

	/**
	 * Returns the salesGrossTotal.
	 * @return String
	 */
	public String getSalesGrossTotal()
	{
		return salesGrossTotal;
	}

	/**
	 * Returns the salesNetTotal.
	 * @return String
	 */
	public String getSalesNetTotal()
	{
		return salesNetTotal;
	}

	/**
	 * Returns the salesReportBean.
	 * @return SalesReportBean
	 */
	public SalesReportBean getSalesReportBean()
	{
		return salesReportBean;
	}

	/**
	 * Returns the transactionCountTotal.
	 * @return long
	 */
	public long getTransactionCountTotal()
	{
		return transactionCountTotal;
	}

	/**
	 * Returns the unitsRefundedTotal.
	 * @return long
	 */
	public long getUnitsRefundedTotal()
	{
		return unitsRefundedTotal;
	}

	/**
	 * Returns the unitsSoldTotal.
	 * @return long
	 */
	public long getUnitsSoldTotal()
	{
		return unitsSoldTotal;
	}

	/**
	 * Sets the locationList.
	 * @param locationList The locationList to set
	 */
	public void setLocationList(ArrayList locationList)
	{
		this.locationList = locationList;
	}

	/**
	 * Sets the netSalesTotal.
	 * @param netSalesTotal The netSalesTotal to set
	 */
	public void setNetSalesTotal(String netSalesTotal)
	{
		this.netSalesTotal = netSalesTotal;
	}

	/**
	 * Sets the refundsDiscountsTotal.
	 * @param refundsDiscountsTotal The refundsDiscountsTotal to set
	 */
	public void setRefundsDiscountsTotal(String refundsDiscountsTotal)
	{
		this.refundsDiscountsTotal = refundsDiscountsTotal;
	}

	/**
	 * Sets the refundsGrossTotal.
	 * @param refundsGrossTotal The refundsGrossTotal to set
	 */
	public void setRefundsGrossTotal(String refundsGrossTotal)
	{
		this.refundsGrossTotal = refundsGrossTotal;
	}

	/**
	 * Sets the refundsNetTotal.
	 * @param refundsNetTotal The refundsNetTotal to set
	 */
	public void setRefundsNetTotal(String refundsNetTotal)
	{
		this.refundsNetTotal = refundsNetTotal;
	}

	/**
	 * Sets the resultList.
	 * @param resultList The resultList to set
	 */
	public void setResultList(ArrayList resultList)
	{
		this.resultList = resultList;
	}

	/**
	 * Sets the salesDiscountsTotal.
	 * @param salesDiscountsTotal The salesDiscountsTotal to set
	 */
	public void setSalesDiscountsTotal(String salesDiscountsTotal)
	{
		this.salesDiscountsTotal = salesDiscountsTotal;
	}

	/**
	 * Sets the salesGrossTotal.
	 * @param salesGrossTotal The salesGrossTotal to set
	 */
	public void setSalesGrossTotal(String salesGrossTotal)
	{
		this.salesGrossTotal = salesGrossTotal;
	}

	/**
	 * Sets the salesNetTotal.
	 * @param salesNetTotal The salesNetTotal to set
	 */
	public void setSalesNetTotal(String salesNetTotal)
	{
		this.salesNetTotal = salesNetTotal;
	}

	/**
	 * Sets the salesReportBean.
	 * @param salesReportBean The salesReportBean to set
	 */
	public void setSalesReportBean(SalesReportBean salesReportBean)
	{
		this.salesReportBean = salesReportBean;
	}

	/**
	 * Sets the transactionCountTotal.
	 * @param transactionCountTotal The transactionCountTotal to set
	 */
	public void setTransactionCountTotal(long transactionCountTotal)
	{
		this.transactionCountTotal = transactionCountTotal;
	}

	/**
	 * Sets the unitsRefundedTotal.
	 * @param unitsRefundedTotal The unitsRefundedTotal to set
	 */
	public void setUnitsRefundedTotal(long unitsRefundedTotal)
	{
		this.unitsRefundedTotal = unitsRefundedTotal;
	}

	/**
	 * Sets the unitsSoldTotal.
	 * @param unitsSoldTotal The unitsSoldTotal to set
	 */
	public void setUnitsSoldTotal(long unitsSoldTotal)
	{
		this.unitsSoldTotal = unitsSoldTotal;
	}

	/**
	 * Returns the hourList.
	 * @return ArrayList
	 */
	public ArrayList getHourList()
	{
		return hourList;
	}

	/**
	 * Returns the minuteList.
	 * @return ArrayList
	 */
	public ArrayList getMinuteList()
	{
		return minuteList;
	}

	/**
	 * Sets the hourList.
	 * @param hourList The hourList to set
	 */
	public void setHourList(ArrayList hourList)
	{
		this.hourList = hourList;
	}

	/**
	 * Sets the minuteList.
	 * @param minuteList The minuteList to set
	 */
	public void setMinuteList(ArrayList minuteList)
	{
		this.minuteList = minuteList;
	}

	/**
	 * Returns the fromDateDisplay.
	 * @return String
	 */
	public String getFromDateDisplay()
	{
		return fromDateDisplay;
	}

	/**
	 * Returns the fromTimeDisplay.
	 * @return String
	 */
	public String getFromTimeDisplay()
	{
		return fromTimeDisplay;
	}

	/**
	 * Returns the toDateDisplay.
	 * @return String
	 */
	public String getToDateDisplay()
	{
		return toDateDisplay;
	}

	/**
	 * Returns the toTimeDisplay.
	 * @return String
	 */
	public String getToTimeDisplay()
	{
		return toTimeDisplay;
	}

	/**
	 * Sets the fromDateDisplay.
	 * @param fromDateDisplay The fromDateDisplay to set
	 */
	public void setFromDateDisplay(String fromDateDisplay)
	{
		this.fromDateDisplay = fromDateDisplay;
	}

	/**
	 * Sets the fromTimeDisplay.
	 * @param fromTimeDisplay The fromTimeDisplay to set
	 */
	public void setFromTimeDisplay(String fromTimeDisplay)
	{
		this.fromTimeDisplay = fromTimeDisplay;
	}

	/**
	 * Sets the toDateDisplay.
	 * @param toDateDisplay The toDateDisplay to set
	 */
	public void setToDateDisplay(String toDateDisplay)
	{
		this.toDateDisplay = toDateDisplay;
	}

	/**
	 * Sets the toTimeDisplay.
	 * @param toTimeDisplay The toTimeDisplay to set
	 */
	public void setToTimeDisplay(String toTimeDisplay)
	{
		this.toTimeDisplay = toTimeDisplay;
	}

	/**
	 * Returns the locationDescription.
	 * @return String
	 */
	public String getLocationDescription() {
		return locationDescription;
	}

	/**
	 * Sets the locationDescription.
	 * @param locationDescription The locationDescription to set
	 */
	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

		/**
		 * Returns the reverseHourList.
		 * @return ArrayList
		 */
		public ArrayList getReverseHourList()
		{
			return reverseHourList;
		}

	/**
	 * Returns the reverseMinuteList.
	 * @return ArrayList
	 */
	public ArrayList getReverseMinuteList()
	{
		return reverseMinuteList;
	}

		/**
		 * Sets the reverseHourList.
		 * @param reverseHourList The reverseHourList to set
		 */
		public void setReverseHourList(ArrayList reverseHourList)
		{
			this.reverseHourList = reverseHourList;
		}

	/**
	 * Sets the reverseMinuteList.
	 * @param reverseMinuteList The reverseMinuteList to set
	 */
	public void setReverseMinuteList(ArrayList reverseMinuteList)
	{
		this.reverseMinuteList = reverseMinuteList;
	}

}