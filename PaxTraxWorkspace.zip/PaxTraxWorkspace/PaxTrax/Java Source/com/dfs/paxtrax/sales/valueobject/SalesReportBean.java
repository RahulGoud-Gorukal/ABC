package com.dfs.paxtrax.sales.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.HashMap;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * This is the valueobject class which stores the data 
 * of the stamp duty colections
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/09/2004   Joseph Oommen A     Created
*/
public class SalesReportBean extends PaxTraxValueObject
{

	private String location = null;
	private String locationType = null;
	private String fromDate = null;
	private String toDate = null;
	private long associateId = 0;
	private String associateName = null;
	private long departmentId = 0;
	private String departmentName = null;
	private double salesGross = 0.00;
	private double salesDiscounts = 0.00;
	private double salesNet = 0.00;
	private double refundsGross = 0.00;
	private double refundsDiscounts = 0.00;
	private double refundsNet = 0.00;
	private double netSales = 0.00;
	private double salesLocation = 0.00;
	private long unitsSold = 0;
	private long unitsRefunded = 0;
	private long transactionCount = 0;
	private double ticketSpending=0.00;
	private String fromHr = null;
	private String fromMin = null;
	private String toHr = null;
	private String toMin = null;
	private int totalTransactionCount = 0;

	private String tenderCode = null;
	private String tenderDescription = null;
	private double salesTenderReceived = 0.0;
	private double salesTenderRefunded = 0.0;
	private double salesTenderTotal = 0.0;

	private HashMap userNameMap = null;
	private HashMap userSalesMap = null;
	private HashMap userRefundMap = null;
	private HashMap userSalesDiscountMap = null;
	private HashMap userRefundDiscountMap = null;
	private HashMap userSalesQtyMap = null;
	private HashMap userRefundQtyMap = null;
	private HashMap userTransactionQtyMap = null;
	private HashMap userTicketSpendingMap = null;
	private ArrayList salesAssociateList= null;

	private String terminal = null;
	private String userNameTemp=null;
	private String userIdTemp=null;
	
		private HashMap userNameMapTemp=null;
			private HashMap userIdMapTemp=null;
	/**
	 * Returns the associateId.
	 * @return long
	 */
	public long getAssociateId()
	{
		return associateId;
	}

	/**
	 * Returns the associateName.
	 * @return String
	 */
	public String getAssociateName()
	{
		return associateName;
	}

	/**
	 * Returns the departmentId.
	 * @return long
	 */
	public long getDepartmentId()
	{
		return departmentId;
	}

	/**
	 * Returns the departmentName.
	 * @return String
	 */
	public String getDepartmentName()
	{
		return departmentName;
	}

	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate()
	{
		return fromDate;
	}

	/**
	 * Returns the fromHr.
	 * @return String
	 */
	public String getFromHr()
	{
		return fromHr;
	}

	/**
	 * Returns the fromMin.
	 * @return String
	 */
	public String getFromMin()
	{
		return fromMin;
	}

	/**
	 * Returns the location.
	 * @return String
	 */
	public String getLocation()
	{
		return location;
	}

	/**
	 * Returns the netSales.
	 * @return double
	 */
	public double getNetSales()
	{
		return netSales;
	}

	/**
	 * Returns the refundsDiscounts.
	 * @return double
	 */
	public double getRefundsDiscounts()
	{
		return refundsDiscounts;
	}

	/**
	 * Returns the refundsGross.
	 * @return double
	 */
	public double getRefundsGross()
	{
		return refundsGross;
	}

	/**
	 * Returns the refundsNet.
	 * @return double
	 */
	public double getRefundsNet()
	{
		return refundsNet;
	}

	/**
	 * Returns the salesDiscounts.
	 * @return double
	 */
	public double getSalesDiscounts()
	{
		return salesDiscounts;
	}

	/**
	 * Returns the salesGross.
	 * @return double
	 */
	public double getSalesGross()
	{
		return salesGross;
	}

	/**
	 * Returns the salesNet.
	 * @return double
	 */
	public double getSalesNet()
	{
		return salesNet;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate()
	{
		return toDate;
	}

	/**
	 * Returns the toHr.
	 * @return String
	 */
	public String getToHr()
	{
		return toHr;
	}

	/**
	 * Returns the toMin.
	 * @return String
	 */
	public String getToMin()
	{
		return toMin;
	}

	/**
	 * Returns the totalTransactionCount.
	 * @return int
	 */
	public int getTotalTransactionCount()
	{
		return totalTransactionCount;
	}

	/**
	 * Returns the transactionCount.
	 * @return long
	 */
	public long getTransactionCount()
	{
		return transactionCount;
	}

	/**
	 * Returns the unitsRefunded.
	 * @return long
	 */
	public long getUnitsRefunded()
	{
		return unitsRefunded;
	}

	/**
	 * Returns the unitsSold.
	 * @return long
	 */
	public long getUnitsSold()
	{
		return unitsSold;
	}

	/**
	 * Sets the associateId.
	 * @param associateId The associateId to set
	 */
	public void setAssociateId(long associateId)
	{
		this.associateId = associateId;
	}

	/**
	 * Sets the associateName.
	 * @param associateName The associateName to set
	 */
	public void setAssociateName(String associateName)
	{
		this.associateName = associateName;
	}

	/**
	 * Sets the departmentId.
	 * @param departmentId The departmentId to set
	 */
	public void setDepartmentId(long departmentId)
	{
		this.departmentId = departmentId;
	}

	/**
	 * Sets the departmentName.
	 * @param departmentName The departmentName to set
	 */
	public void setDepartmentName(String departmentName)
	{
		this.departmentName = departmentName;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate)
	{
		this.fromDate = fromDate;
	}

	/**
	 * Sets the fromHr.
	 * @param fromHr The fromHr to set
	 */
	public void setFromHr(String fromHr)
	{
		this.fromHr = fromHr;
	}

	/**
	 * Sets the fromMin.
	 * @param fromMin The fromMin to set
	 */
	public void setFromMin(String fromMin)
	{
		this.fromMin = fromMin;
	}

	/**
	 * Sets the location.
	 * @param location The location to set
	 */
	public void setLocation(String location)
	{
		this.location = location;
	}

	/**
	 * Sets the netSales.
	 * @param netSales The netSales to set
	 */
	public void setNetSales(double netSales)
	{
		this.netSales = netSales;
	}

	/**
	 * Sets the refundsDiscounts.
	 * @param refundsDiscounts The refundsDiscounts to set
	 */
	public void setRefundsDiscounts(double refundsDiscounts)
	{
		this.refundsDiscounts = refundsDiscounts;
	}

	/**
	 * Sets the refundsGross.
	 * @param refundsGross The refundsGross to set
	 */
	public void setRefundsGross(double refundsGross)
	{
		this.refundsGross = refundsGross;
	}

	/**
	 * Sets the refundsNet.
	 * @param refundsNet The refundsNet to set
	 */
	public void setRefundsNet(double refundsNet)
	{
		this.refundsNet = refundsNet;
	}

	/**
	 * Sets the salesDiscounts.
	 * @param salesDiscounts The salesDiscounts to set
	 */
	public void setSalesDiscounts(double salesDiscounts)
	{
		this.salesDiscounts = salesDiscounts;
	}

	/**
	 * Sets the salesGross.
	 * @param salesGross The salesGross to set
	 */
	public void setSalesGross(double salesGross)
	{
		this.salesGross = salesGross;
	}

	/**
	 * Sets the salesNet.
	 * @param salesNet The salesNet to set
	 */
	public void setSalesNet(double salesNet)
	{
		this.salesNet = salesNet;
	}

	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate)
	{
		this.toDate = toDate;
	}

	/**
	 * Sets the toHr.
	 * @param toHr The toHr to set
	 */
	public void setToHr(String toHr)
	{
		this.toHr = toHr;
	}

	/**
	 * Sets the toMin.
	 * @param toMin The toMin to set
	 */
	public void setToMin(String toMin)
	{
		this.toMin = toMin;
	}

	/**
	 * Sets the totalTransactionCount.
	 * @param totalTransactionCount The totalTransactionCount to set
	 */
	public void setTotalTransactionCount(int totalTransactionCount)
	{
		this.totalTransactionCount = totalTransactionCount;
	}

	/**
	 * Sets the transactionCount.
	 * @param transactionCount The transactionCount to set
	 */
	public void setTransactionCount(long transactionCount)
	{
		this.transactionCount = transactionCount;
	}

	/**
	 * Sets the unitsRefunded.
	 * @param unitsRefunded The unitsRefunded to set
	 */
	public void setUnitsRefunded(long unitsRefunded)
	{
		this.unitsRefunded = unitsRefunded;
	}

	/**
	 * Sets the unitsSold.
	 * @param unitsSold The unitsSold to set
	 */
	public void setUnitsSold(long unitsSold)
	{
		this.unitsSold = unitsSold;
	}

	/**
	 * Returns the salesTenderReceived.
	 * @return double
	 */
	public double getSalesTenderReceived()
	{
		return salesTenderReceived;
	}

	/**
	 * Returns the salesTenderRefunded.
	 * @return double
	 */
	public double getSalesTenderRefunded()
	{
		return salesTenderRefunded;
	}

	/**
	 * Returns the salesTenderTotal.
	 * @return double
	 */
	public double getSalesTenderTotal()
	{
		return salesTenderTotal;
	}

	/**
	 * Returns the tenderCode.
	 * @return String
	 */
	public String getTenderCode()
	{
		return tenderCode;
	}

	/**
	 * Returns the tenderDescription.
	 * @return String
	 */
	public String getTenderDescription()
	{
		return tenderDescription;
	}

	/**
	 * Sets the salesTenderReceived.
	 * @param salesTenderReceived The salesTenderReceived to set
	 */
	public void setSalesTenderReceived(double salesTenderReceived)
	{
		this.salesTenderReceived = salesTenderReceived;
	}

	/**
	 * Sets the salesTenderRefunded.
	 * @param salesTenderRefunded The salesTenderRefunded to set
	 */
	public void setSalesTenderRefunded(double salesTenderRefunded)
	{
		this.salesTenderRefunded = salesTenderRefunded;
	}

	/**
	 * Sets the salesTenderTotal.
	 * @param salesTenderTotal The salesTenderTotal to set
	 */
	public void setSalesTenderTotal(double salesTenderTotal)
	{
		this.salesTenderTotal = salesTenderTotal;
	}

	/**
	 * Sets the tenderCode.
	 * @param tenderCode The tenderCode to set
	 */
	public void setTenderCode(String tenderCode)
	{
		this.tenderCode = tenderCode;
	}

	/**
	 * Sets the tenderDescription.
	 * @param tenderDescription The tenderDescription to set
	 */
	public void setTenderDescription(String tenderDescription)
	{
		this.tenderDescription = tenderDescription;
	}

	/**
	 * Returns the terminal.
	 * @return String
	 */
	public String getTerminal()
	{
		return terminal;
	}

	/**
	 * Sets the terminal.
	 * @param terminal The terminal to set
	 */
	public void setTerminal(String terminal)
	{
		this.terminal = terminal;
	}

	/**
	 * Returns the userNameMap.
	 * @return HashMap
	 */
	public HashMap getUserNameMap()
	{
		return userNameMap;
	}

	/**
	 * Returns the userRefundDiscountMap.
	 * @return HashMap
	 */
	public HashMap getUserRefundDiscountMap()
	{
		return userRefundDiscountMap;
	}

	/**
	 * Returns the userRefundMap.
	 * @return HashMap
	 */
	public HashMap getUserRefundMap()
	{
		return userRefundMap;
	}

	/**
	 * Returns the userRefundQtyMap.
	 * @return HashMap
	 */
	public HashMap getUserRefundQtyMap()
	{
		return userRefundQtyMap;
	}

	/**
	 * Returns the userSalesDiscountMap.
	 * @return HashMap
	 */
	public HashMap getUserSalesDiscountMap()
	{
		return userSalesDiscountMap;
	}

	/**
	 * Returns the userSalesMap.
	 * @return HashMap
	 */
	public HashMap getUserSalesMap()
	{
		return userSalesMap;
	}

	/**
	 * Returns the userSalesQtyMap.
	 * @return HashMap
	 */
	public HashMap getUserSalesQtyMap()
	{
		return userSalesQtyMap;
	}

	/**
	 * Returns the userTransactionQtyMap.
	 * @return HashMap
	 */
	public HashMap getUserTransactionQtyMap()
	{
		return userTransactionQtyMap;
	}

	/**
	 * Sets the userNameMap.
	 * @param userNameMap The userNameMap to set
	 */
	public void setUserNameMap(HashMap userNameMap)
	{
		this.userNameMap = userNameMap;
	}

	/**
	 * Sets the userRefundDiscountMap.
	 * @param userRefundDiscountMap The userRefundDiscountMap to set
	 */
	public void setUserRefundDiscountMap(HashMap userRefundDiscountMap)
	{
		this.userRefundDiscountMap = userRefundDiscountMap;
	}

	/**
	 * Sets the userRefundMap.
	 * @param userRefundMap The userRefundMap to set
	 */
	public void setUserRefundMap(HashMap userRefundMap)
	{
		this.userRefundMap = userRefundMap;
	}

	/**
	 * Sets the userRefundQtyMap.
	 * @param userRefundQtyMap The userRefundQtyMap to set
	 */
	public void setUserRefundQtyMap(HashMap userRefundQtyMap)
	{
		this.userRefundQtyMap = userRefundQtyMap;
	}

	/**
	 * Sets the userSalesDiscountMap.
	 * @param userSalesDiscountMap The userSalesDiscountMap to set
	 */
	public void setUserSalesDiscountMap(HashMap userSalesDiscountMap)
	{
		this.userSalesDiscountMap = userSalesDiscountMap;
	}

	/**
	 * Sets the userSalesMap.
	 * @param userSalesMap The userSalesMap to set
	 */
	public void setUserSalesMap(HashMap userSalesMap)
	{
		this.userSalesMap = userSalesMap;
	}

	/**
	 * Sets the userSalesQtyMap.
	 * @param userSalesQtyMap The userSalesQtyMap to set
	 */
	public void setUserSalesQtyMap(HashMap userSalesQtyMap)
	{
		this.userSalesQtyMap = userSalesQtyMap;
	}

	/**
	 * Sets the userTransactionQtyMap.
	 * @param userTransactionQtyMap The userTransactionQtyMap to set
	 */
	public void setUserTransactionQtyMap(HashMap userTransactionQtyMap)
	{
		this.userTransactionQtyMap = userTransactionQtyMap;
	}

	/**
	 * Returns the salesAssociateMap.
	 * @return HashMap
	 */
	

	/**
	 * Returns the salesAssociateList.
	 * @return ArrayList
	 */
	public ArrayList getSalesAssociateList()
	{
		return salesAssociateList;
	}

	/**
	 * Sets the salesAssociateList.
	 * @param salesAssociateList The salesAssociateList to set
	 */
	public void setSalesAssociateList(ArrayList salesAssociateList)
	{
		this.salesAssociateList = salesAssociateList;
	}

	/**
	 * Returns the ticketSpending.
	 * @return long
	 */
	public double getTicketSpending() {
		return ticketSpending;
	}

	/**
	 * Sets the ticketSpending.
	 * @param ticketSpending The ticketSpending to set
	 */
	public void setTicketSpending(double ticketSpending) {

		this.ticketSpending = ticketSpending;
	}

	/**
	 * Returns the associateNameTemp.
	 * @return String
	 */
	public String getUserNameTemp() {
		return userNameTemp;
	}

	/**
	 * Sets the associateNameTemp.
	 * @param associateNameTemp The associateNameTemp to set
	 */
	public void setUserNameTemp(String userNameTemp) {
		this.userNameTemp = userNameTemp;
	}

	/**
	 * Returns the associateIdTemp.
	 * @return long
	 */
	public String getUserIdTemp() {
		return userIdTemp;
	}

	/**
	 * Sets the associateIdTemp.
	 * @param associateIdTemp The associateIdTemp to set
	 */
	public void setUserIdTemp(String userIdTemp) {
		this.userIdTemp = userIdTemp;
	}

		/**
		 * Returns the userNameMapTemp.
		 * @return HashMap
		 */
		public HashMap getUserNameMapTemp() {
			return userNameMapTemp;
		}

		/**
		 * Sets the userNameMapTemp.
		 * @param userNameMapTemp The userNameMapTemp to set
		 */
		public void setUserNameMapTemp(HashMap userNameMapTemp) {
			this.userNameMapTemp = userNameMapTemp;
		}

	/**
	 * Returns the usetIdMapTemp.
	 * @return HashMap
	 */
	public HashMap getUserIdMapTemp() {
		return userIdMapTemp;
	}

	/**
	 * Sets the usetIdMapTemp.
	 * @param usetIdMapTemp The usetIdMapTemp to set
	 */
	public void setUserIdMapTemp(HashMap usetIdMapTemp) {
		this.userIdMapTemp = usetIdMapTemp;
	}
			
			
	/**
	 * Returns the locationType.
	 * @return String
	 */
	public String getLocationType() {
		return locationType;
	}

	/**
	 * Sets the locationType.
	 * @param locationType The locationType to set
	 */
	public void setLocationType(String locationType) {
		this.locationType = locationType;
	}

	/**
	 * Returns the salesLocation.
	 * @return double
	 */
	public double getSalesLocation() {
		return salesLocation;
	}

	/**
	 * Sets the salesLocation.
	 * @param salesLocation The salesLocation to set
	 */
	public void setSalesLocation(double salesLocation) {
		this.salesLocation = salesLocation;
	}

	/**
	 * Returns the userTicketSpendingMap.
	 * @return HashMap
	 */
	public HashMap getUserTicketSpendingMap() {
		return userTicketSpendingMap;
	}

	/**
	 * Sets the userTicketSpendingMap.
	 * @param userTicketSpendingMap The userTicketSpendingMap to set
	 */
	public void setUserTicketSpendingMap(HashMap userTicketSpendingMap) {
		this.userTicketSpendingMap = userTicketSpendingMap;
	}

}
