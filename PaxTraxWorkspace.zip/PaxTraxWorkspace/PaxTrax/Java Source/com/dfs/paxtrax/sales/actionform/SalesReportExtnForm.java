package com.dfs.paxtrax.sales.actionform;

/**
 * @author 124496
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
import java.util.ArrayList;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.sales.valueobject.SalesReportBean;
import com.dfs.paxtrax.sales.valueobject.SalesReportExtnBean;


public class SalesReportExtnForm extends PaxTraxActionForm {
	
	private ArrayList currencyList = null;
	private ArrayList hourList =null;
	private ArrayList minuteList=null;
	private ArrayList reverseHourList =null;
	private ArrayList reverseMinuteList=null;
	private SalesReportExtnBean salesReportExtnBean = null;
	private String fromDateDisplay1=null;
	private String toDateDisplay1 =null;
	private String fromDateDisplay2=null;
	private String toDateDisplay2 =null;
	


	/**
	 * Returns the currencyList.
	 * @return ArrayList
	 */
	public ArrayList getCurrencyList() {
		return currencyList;
	}

	/**
	 * Returns the fromDateDisplay1.
	 * @return String
	 */
	public String getFromDateDisplay1() {
		return fromDateDisplay1;
	}

	/**
	 * Returns the fromDateDisplay2.
	 * @return String
	 */
	public String getFromDateDisplay2() {
		return fromDateDisplay2;
	}

	/**
	 * Returns the hourList.
	 * @return ArrayList
	 */
	public ArrayList getHourList() {
		return hourList;
	}

	/**
	 * Returns the minuteList.
	 * @return ArrayList
	 */
	public ArrayList getMinuteList() {
		return minuteList;
	}

	/**
	 * Returns the reverseHourList.
	 * @return ArrayList
	 */
	public ArrayList getReverseHourList() {
		return reverseHourList;
	}

	/**
	 * Returns the reverseMinuteList.
	 * @return ArrayList
	 */
	public ArrayList getReverseMinuteList() {
		return reverseMinuteList;
	}

	/**
	 * Returns the salesReportExtnBean.
	 * @return SalesReportExtnBean
	 */
	public SalesReportExtnBean getSalesReportExtnBean() {
		return salesReportExtnBean;
	}

	/**
	 * Returns the toDateDisplay1.
	 * @return String
	 */
	public String getToDateDisplay1() {
		return toDateDisplay1;
	}

	/**
	 * Returns the toDateDisplay2.
	 * @return String
	 */
	public String getToDateDisplay2() {
		return toDateDisplay2;
	}

	/**
	 * Sets the currencyList.
	 * @param currencyList The currencyList to set
	 */
	public void setCurrencyList(ArrayList currencyList) {
		this.currencyList = currencyList;
	}

	/**
	 * Sets the fromDateDisplay1.
	 * @param fromDateDisplay1 The fromDateDisplay1 to set
	 */
	public void setFromDateDisplay1(String fromDateDisplay1) {
		this.fromDateDisplay1 = fromDateDisplay1;
	}

	/**
	 * Sets the fromDateDisplay2.
	 * @param fromDateDisplay2 The fromDateDisplay2 to set
	 */
	public void setFromDateDisplay2(String fromDateDisplay2) {
		this.fromDateDisplay2 = fromDateDisplay2;
	}

	/**
	 * Sets the hourList.
	 * @param hourList The hourList to set
	 */
	public void setHourList(ArrayList hourList) {
		this.hourList = hourList;
	}

	/**
	 * Sets the minuteList.
	 * @param minuteList The minuteList to set
	 */
	public void setMinuteList(ArrayList minuteList) {
		this.minuteList = minuteList;
	}

	/**
	 * Sets the reverseHourList.
	 * @param reverseHourList The reverseHourList to set
	 */
	public void setReverseHourList(ArrayList reverseHourList) {
		this.reverseHourList = reverseHourList;
	}

	/**
	 * Sets the reverseMinuteList.
	 * @param reverseMinuteList The reverseMinuteList to set
	 */
	public void setReverseMinuteList(ArrayList reverseMinuteList) {
		this.reverseMinuteList = reverseMinuteList;
	}

	/**
	 * Sets the salesReportExtnBean.
	 * @param salesReportExtnBean The salesReportExtnBean to set
	 */
	public void setSalesReportExtnBean(SalesReportExtnBean salesReportExtnBean) {
		this.salesReportExtnBean = salesReportExtnBean;
	}

	/**
	 * Sets the toDateDisplay1.
	 * @param toDateDisplay1 The toDateDisplay1 to set
	 */
	public void setToDateDisplay1(String toDateDisplay1) {
		this.toDateDisplay1 = toDateDisplay1;
	}

	/**
	 * Sets the toDateDisplay2.
	 * @param toDateDisplay2 The toDateDisplay2 to set
	 */
	public void setToDateDisplay2(String toDateDisplay2) {
		this.toDateDisplay2 = toDateDisplay2;
	}

}
