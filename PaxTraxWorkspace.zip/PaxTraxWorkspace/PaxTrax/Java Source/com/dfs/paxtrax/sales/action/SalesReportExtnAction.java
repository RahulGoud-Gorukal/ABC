package com.dfs.paxtrax.sales.action;

/**
 * @author 124496
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.sales.actionform.SalesReportExtnForm;
import com.dfs.paxtrax.sales.service.SalesReportDelegate;
import com.dfs.paxtrax.sales.valueobject.SalesReportExtnBean;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;


public class SalesReportExtnAction extends PaxTraxAction{
        String forward = null;

 public ActionForward createDFSOwnedSalesReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportExtnAction::createDFSOwnedSalesReportPage::Begin");

		try
		{
			SalesReportExtnForm salesReportForm = (SalesReportExtnForm) form;
			SalesReportExtnBean salesReportBean = new SalesReportExtnBean();
			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
			ArrayList currencyList = rdDelegate.loadReferenceData(PaxTraxConstants.CURRENCIES);
    		salesReportForm.setCurrencyList(currencyList);
			salesReportForm.setHourList(getArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setMinuteList(getArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setReverseHourList(getReverseArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setReverseMinuteList(getReverseArrayList(PaxTraxConstants.TIME_MIN));

			String currentDate = getCurrentDate();
			salesReportBean.setFromDate1(currentDate);
			salesReportBean.setToDate1(currentDate);
			String previousDate=getPreviousDate();
			salesReportBean.setFromDate2(previousDate);
			salesReportBean.setToDate2(previousDate);

			Calendar a = Calendar.getInstance();
			int hr=a.get(Calendar.HOUR_OF_DAY);

			/* Code Starts.Code Added on 2006-07-26.To display the current time in "Range2 To Time field" */
			if(hr<10)
			{
				salesReportBean.setToHr1("0"+hr);
				salesReportBean.setToHr2("0"+hr);
			}
			else
			{
				salesReportBean.setToHr1(hr + "");
				salesReportBean.setToHr2(hr + "");
			}
			int min=a.get(Calendar.MINUTE);

			if(min<10)
			{
				salesReportBean.setToMin1("0"+min);
				salesReportBean.setToMin2("0"+min);
			}
			else
			{
				salesReportBean.setToMin1(min + "");
				salesReportBean.setToMin2(min + "");
			}
			/* Code Ends */

			salesReportForm.setSalesReportExtnBean(salesReportBean);
			forward = "salesDFSOwnedDepartmentReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportExtnAction::createDFSOwnedSalesReportPage ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportExtnAction::createDFSOwnedSalesReportPage::End");
		return mapping.findForward(forward);
	}



	public ActionForward getDFSOwnedSalesReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportExtnAction::getDFSOwnedSalesReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportExtnForm salesReportForm = (SalesReportExtnForm) form;
		SalesReportExtnBean salesReportBean = salesReportForm.getSalesReportExtnBean();

		try
		{
			salesReportBean = salesReportDelegate.getDFSOwnedSalesReport(salesReportBean);
			salesReportForm.setSalesReportExtnBean(salesReportBean);
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			forward = "salesDFSOwnedDepartmentReport";

		}
		catch (PaxTraxSystemException e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportExtnAction::getDFSOwnedSalesReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportExtnAction::getDFSOwnedSalesReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward printSalesDFSOwnedReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportExtnAction::printSalesDFSOwnedReport::Begin");
		SalesReportExtnForm salesReportForm = (SalesReportExtnForm) form;
		SalesReportExtnBean salesReportBean = salesReportForm.getSalesReportExtnBean();
		String fromDate1 = salesReportBean.getFromDate1();
		String toDate1 = salesReportBean.getToDate1();
		String fromHr1 = salesReportBean.getFromHr1();
		String fromMin1 = salesReportBean.getFromMin1();
		String toHr1 = salesReportBean.getToHr1();
		String toMin1 = salesReportBean.getToMin1();
		String fromDate2 = salesReportBean.getFromDate2();
		String toDate2 = salesReportBean.getToDate2();
		String fromHr2 = salesReportBean.getFromHr2();
		String fromMin2 = salesReportBean.getFromMin2();
		String toHr2 = salesReportBean.getToHr2();
		String toMin2 = salesReportBean.getToMin2();

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mma");
		Calendar cal = Calendar.getInstance();
		int year = Integer.parseInt(fromDate1.substring(0, 4));
		int month = Integer.parseInt(fromDate1.substring(5, 7));
		int date = Integer.parseInt(fromDate1.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(fromHr1));
		cal.set(Calendar.MINUTE, Integer.parseInt(fromMin1));
		salesReportForm.setFromDateDisplay1(formatter.format(cal.getTime()));

		year = Integer.parseInt(toDate1.substring(0, 4));
		month = Integer.parseInt(toDate1.substring(5, 7));
		date = Integer.parseInt(toDate1.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(toHr1));
		cal.set(Calendar.MINUTE, Integer.parseInt(toMin1));
		salesReportForm.setToDateDisplay1(formatter.format(cal.getTime()));

		year = Integer.parseInt(fromDate2.substring(0, 4));
		month = Integer.parseInt(fromDate2.substring(5, 7));
		date = Integer.parseInt(fromDate2.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(fromHr2));
		cal.set(Calendar.MINUTE, Integer.parseInt(fromMin2));
		salesReportForm.setFromDateDisplay2(formatter.format(cal.getTime()));

		year = Integer.parseInt(toDate2.substring(0, 4));
		month = Integer.parseInt(toDate2.substring(5, 7));
		date = Integer.parseInt(toDate2.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(toHr2));
		cal.set(Calendar.MINUTE, Integer.parseInt(toMin2));
		salesReportForm.setToDateDisplay2(formatter.format(cal.getTime()));
		ReferenceDataBean refBean=new ReferenceDataBean();
		ArrayList currencyList = new ArrayList();
		currencyList=salesReportForm.getCurrencyList();
		for(int i=0;i<currencyList.size();i++)
		{

		   refBean=(ReferenceDataBean)currencyList.get(i);
		   if(salesReportBean.getCurrency().equals(refBean.getCodeId()))
		       salesReportBean.setCurrencyDescription(refBean.getCodeValue());
		}

		request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug("PaxTrax::SalesReportExtnAction::printSalesDFSOwnedReport::Begin");
		return mapping.findForward("printSalesDFSOwnedReport");
	}

	public ActionForward generateDFSOwnedSalesReport(ActionMapping mapping, ActionForm form , HttpServletRequest request, HttpServletResponse response)
	throws PaxTraxSystemException
	{
		ReferenceDataBean refBean=new ReferenceDataBean();
		ArrayList currencyList = new ArrayList();
		try
		{
			SalesReportExtnForm salesReportForm=(SalesReportExtnForm) form;
			SalesReportExtnBean salesReportBean = salesReportForm.getSalesReportExtnBean();

			currencyList=salesReportForm.getCurrencyList();
			for(int i=0;i<currencyList.size();i++)
			{

			   refBean=(ReferenceDataBean)currencyList.get(i);
			   if(salesReportBean.getCurrency().equals(refBean.getCodeId()))
			       salesReportBean.setCurrencyDescription(refBean.getCodeValue());
			}


			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");

			if (user != null)
				salesReportBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("DFS Owned Sales Report");

			sheet.setDefaultColumnWidth((short)14);

			//Create Header Font
			HSSFFont fontHeader = wb.createFont();
			fontHeader.setFontHeightInPoints((short)10);
			fontHeader.setFontName(HSSFFont.FONT_ARIAL);
			fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);

			//Create font for the workbook Data cells
			HSSFFont font = wb.createFont();
			font.setFontHeightInPoints((short)10);
			font.setFontName(HSSFFont.FONT_ARIAL);

			//Style for the Header cells
			HSSFCellStyle styleHeader = wb.createCellStyle();
			styleHeader.setFont(fontHeader);
			styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);

		    styleHeader.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    styleHeader.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    styleHeader.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    styleHeader.setBorderTop(HSSFCellStyle.BORDER_THIN);


			HSSFCellStyle styleHeaderRight = wb.createCellStyle();
			styleHeaderRight.setFont(fontHeader);
			styleHeaderRight.setFillForegroundColor(HSSFColor.AQUA.index);
			styleHeaderRight.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			HSSFDataFormat frmt = wb.createDataFormat();
			styleHeaderRight.setDataFormat(frmt.getFormat("#,##0.00"));
            styleHeaderRight.setAlignment(HSSFCellStyle.ALIGN_RIGHT);

            styleHeaderRight.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    styleHeaderRight.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    styleHeaderRight.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    styleHeaderRight.setBorderTop(HSSFCellStyle.BORDER_THIN);

            HSSFCellStyle styleHeaderRight1 = wb.createCellStyle(); // Format Style for Okinawa Ticket Count Total
			styleHeaderRight1.setFont(fontHeader);
			styleHeaderRight1.setFillForegroundColor(HSSFColor.AQUA.index);
			styleHeaderRight1.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
            styleHeaderRight1.setAlignment(HSSFCellStyle.ALIGN_RIGHT);

            styleHeaderRight1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    styleHeaderRight1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    styleHeaderRight1.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    styleHeaderRight1.setBorderTop(HSSFCellStyle.BORDER_THIN);

			//Style for the Side Title cells
			HSSFCellStyle styleTitle = wb.createCellStyle();
			styleTitle.setFont(fontHeader);

			styleTitle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    styleTitle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    styleTitle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    styleTitle.setBorderTop(HSSFCellStyle.BORDER_THIN);


			//Style for the Data cells
			HSSFCellStyle style = wb.createCellStyle();
			style.setFont(font);

			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    style.setBorderTop(HSSFCellStyle.BORDER_THIN);

			//Style for numeric data cells
			HSSFCellStyle styleNum = wb.createCellStyle();
			HSSFDataFormat format = wb.createDataFormat();
			styleNum.setDataFormat(format.getFormat("#,##0.00"));
			styleNum.setFont(font);

			styleNum.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		    styleNum.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		    styleNum.setBorderRight(HSSFCellStyle.BORDER_THIN);
		    styleNum.setBorderTop(HSSFCellStyle.BORDER_THIN);

			//Create Title rows
			HSSFRow row = sheet.createRow((short)0);
			HSSFCell cell = null;
			sheet.addMergedRegion(new Region(0, (short)0, 0, (short)7));
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.DFS_OKINAWA, 0.0);
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);
			createCell(row,cell,2, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);
			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);
			createCell(row,cell,4, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);
			createCell(row,cell,6, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);
			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);

			row = sheet.createRow((short)1);
			sheet.addMergedRegion(new Region(1, (short)0, 1, (short)7));
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "DFS Owned Sales Report", 0.0);
			cell = row.createCell((short)1);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)2);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)3);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)4);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)5);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)6);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)7);
			cell.setCellStyle(styleHeader);

		    row = sheet.createRow((short)3);
			createCell(row,cell,2, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Currency", 0.0);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, style, salesReportBean.getCurrencyDescription() , 0.0);

			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Exchange Rate" , 0.0);

			//createCell(row,cell,6, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_NUMERIC, style,null ,Integer.parseInt(salesReportBean.getExchangeRate()));

			createCell(row,cell,6, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_NUMERIC, style,null ,Double.parseDouble(salesReportBean.getExchangeRate()));

			row = sheet.createRow((short)5);
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Department", 0.0);

			sheet.addMergedRegion(new Region(5, (short)1, 5, (short)3));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Range 1", 0.0);
			cell = row.createCell((short)2);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)3);
			cell.setCellStyle(styleHeader);

			sheet.addMergedRegion(new Region(5, (short)5, 5, (short)7));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Range 2", 0.0);
			cell = row.createCell((short)6);
			cell.setCellStyle(styleHeader);
			cell = row.createCell((short)7);
			cell.setCellStyle(styleHeader);

			row = sheet.createRow((short)6);
			sheet.addMergedRegion(new Region(6, (short)1, 6, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "From Date/Time: "+salesReportBean.getFromDate1(), 0.0);
			cell = row.createCell((short)2);
			cell.setCellStyle(styleTitle);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Hr:"+salesReportBean.getFromHr1()+" Min:"+salesReportBean.getFromMin1(), 0.0);

			sheet.addMergedRegion(new Region(6, (short)5, 6, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "From Date/Time: "+salesReportBean.getFromDate2(), 0.0);
			cell = row.createCell((short)6);
			cell.setCellStyle(styleTitle);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Hr:"+salesReportBean.getFromHr2()+" Min:"+salesReportBean.getFromMin2(), 0.0);

			row = sheet.createRow((short)7);
			sheet.addMergedRegion(new Region(7, (short)1, 7, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "To Date/Time  : "+salesReportBean.getToDate1(), 0.0);
			cell = row.createCell((short)2);
			cell.setCellStyle(styleTitle);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Hr:"+salesReportBean.getToHr1()+" Min:"+salesReportBean.getToMin1(), 0.0);

			sheet.addMergedRegion(new Region(7, (short)5, 7, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "To Date/Time  : "+salesReportBean.getToDate2(), 0.0);
			cell = row.createCell((short)6);
			cell.setCellStyle(styleTitle);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Hr:"+salesReportBean.getToHr2()+" Min:"+salesReportBean.getToMin2(), 0.0);

			row = sheet.createRow((short)8);
			sheet.addMergedRegion(new Region(8, (short)1, 8, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Net Sales", 0.0);
			cell = row.createCell((short)2);
			cell.setCellStyle(styleHeader);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Ticket Count", 0.0);

			sheet.addMergedRegion(new Region(8, (short)5, 8, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Net Sales", 0.0);
			createCell(row,cell,6, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "", 0.0);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Ticket Count", 0.0);

			row = sheet.createRow((short)9);
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Galleria 610", 0.0);

			sheet.addMergedRegion(new Region(9, (short)1, 9, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, (salesReportBean.getNetSalesGalleriaDF1()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesGalleriaDF1(),",",""))));
			cell = row.createCell((short)2);
			cell.setCellStyle(styleNum);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, style, null,(salesReportBean.getTicketCountGalleriaDF1()==null?0:Integer.parseInt(salesReportBean.getTicketCountGalleriaDF1())));

			sheet.addMergedRegion(new Region(9, (short)5, 9, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleNum,null,(salesReportBean.getNetSalesGalleriaDF2()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesGalleriaDF2(),",",""))));
			cell = row.createCell((short)6);
			cell.setCellStyle(styleNum);


			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, style,null,(salesReportBean.getTicketCountGalleriaDF2()==null?0:Integer.parseInt(salesReportBean.getTicketCountGalleriaDF2())));

			row = sheet.createRow((short)10);
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Galleria 630", 0.0);

			sheet.addMergedRegion(new Region(10, (short)1, 10, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC,styleNum,null,(salesReportBean.getNetSalesGalleriaDP1()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesGalleriaDP1(),",",""))));
			cell = row.createCell((short)2);
			cell.setCellStyle(styleNum);


			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, style,null,(salesReportBean.getTicketCountGalleriaDP1()==null?0:Integer.parseInt(salesReportBean.getTicketCountGalleriaDP1())));

			sheet.addMergedRegion(new Region(10, (short)5, 10, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleNum,null,(salesReportBean.getNetSalesGalleriaDP2()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesGalleriaDP2(),",",""))));
			cell = row.createCell((short)6);
			cell.setCellStyle(styleNum);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, style,null,(salesReportBean.getTicketCountGalleriaDP2()==null?0:Integer.parseInt(salesReportBean.getTicketCountGalleriaDP2())));

			row = sheet.createRow((short)11);
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Galleria Total", 0.0);

			sheet.addMergedRegion(new Region(11, (short)1, 11, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleNum,null,(salesReportBean.getNetSalesGalleriaTotal1()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesGalleriaTotal1(),",",""))));
			cell = row.createCell((short)2);
			cell.setCellStyle(styleNum);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, style,null,(salesReportBean.getTicketCountGalleriaTotal1()==null?0:Integer.parseInt(salesReportBean.getTicketCountGalleriaTotal1())));

			sheet.addMergedRegion(new Region(11, (short)5, 11, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC,styleNum,null,(salesReportBean.getNetSalesGalleriaTotal2()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesGalleriaTotal2(),",",""))));
			cell = row.createCell((short)6);
			cell.setCellStyle(styleNum);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC,style,null,(salesReportBean.getTicketCountGalleriaTotal2()==null?0:Integer.parseInt(salesReportBean.getTicketCountGalleriaTotal2())));

			row = sheet.createRow((short)12);
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleTitle, "Airport 451", 0.0);


			sheet.addMergedRegion(new Region(12, (short)1, 12, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC,styleNum,null,(salesReportBean.getNetSalesAirportTotal1()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesAirportTotal1(),",",""))));
			cell = row.createCell((short)2);
			cell.setCellStyle(styleNum);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC,style,null,(salesReportBean.getTicketCountAirportTotal1()==null?0:Integer.parseInt(salesReportBean.getTicketCountAirportTotal1())));

			sheet.addMergedRegion(new Region(12, (short)5, 12, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleNum,null,(salesReportBean.getNetSalesAirportTotal2()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesAirportTotal2(),",",""))));
			cell = row.createCell((short)6);
			cell.setCellStyle(styleNum);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, style,null,(salesReportBean.getTicketCountAirportTotal2()==null?0:Integer.parseInt(salesReportBean.getTicketCountAirportTotal2())));

			row = sheet.createRow((short)13);
			createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, "Okinawa Total", 0.0);

			sheet.addMergedRegion(new Region(13, (short)1, 13, (short)2));
			createCell(row,cell,1, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleHeaderRight,null,(salesReportBean.getNetSalesOkinawaTotal1()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesOkinawaTotal1(),",",""))));
			cell = row.createCell((short)2);
			cell.setCellStyle(styleNum);

			createCell(row,cell,3, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleHeaderRight1,null,(salesReportBean.getTicketCountOkinawaTotal1()==null?0:Integer.parseInt(salesReportBean.getTicketCountOkinawaTotal1())));

			sheet.addMergedRegion(new Region(13, (short)5, 13, (short)6));
			createCell(row,cell,5, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleHeaderRight,null,(salesReportBean.getNetSalesOkinawaTotal2()==null?0.0:Double.parseDouble(replaceAll(salesReportBean.getNetSalesOkinawaTotal2(),",",""))));
			cell = row.createCell((short)6);
			cell.setCellStyle(styleNum);

			createCell(row,cell,7, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_NUMERIC, styleHeaderRight1,null,(salesReportBean.getTicketCountOkinawaTotal2()==null?0:Integer.parseInt(salesReportBean.getTicketCountOkinawaTotal2())));

			FileOutputStream fileOut = new FileOutputStream(PaxTraxConstants.SALES_REPORTS_BASE_PATH + "DFSOwnedSalesReport" + salesReportBean.getUser() + ".xls");

			wb.write(fileOut);
			fileOut.close();
			request.setAttribute(PaxTraxConstants.SUCCESS, "y");
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			request.setAttribute(PaxTraxConstants.FILE_NAME, "DFSOwnedSalesReport" + salesReportBean.getUser() + ".xls");


			forward = "salesDFSOwnedDepartmentReport";

		}
		catch(Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportExtnAction::generateSalesDepartmentReport ", e);
			e.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}

		return mapping.findForward(forward);
	}


	/**
	 * Returns a temporary ArrayList with  values for Time Array
	 * @param String type
	 * @return ArrayList temp
	 */
	private ArrayList getArrayList(String type)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getArrayList::Begin");
		ReferenceDataBean commonBean = null;
		ArrayList temp = new ArrayList();
		for (int i = 0; i < 10; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}
		if (type.equals(PaxTraxConstants.TIME_HR))
		{
			for (int i = 10; i < 24; i++)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		else if (type.equals(PaxTraxConstants.TIME_MIN))
		{
			for (int i = 10; i < 60; i++)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getArrayList::End");
		return temp;
	}

	private ArrayList getReverseArrayList(String type)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getReverseArrayList::Begin");
		ReferenceDataBean commonBean = null;
		ArrayList temp = new ArrayList();

		if (type.equals(PaxTraxConstants.TIME_HR))
		{
			for (int i = 23; i > 9; i--)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		else if (type.equals(PaxTraxConstants.TIME_MIN))
		{
			for (int i = 59; i > 9; i--)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		for (int i = 9; i >= 0; i--)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}

		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getReverseArrayList::End");
		return temp;
	}

	private String getCurrentDate()
	{
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE);
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);

		String currentDate = "";
        currentDate = "" + year + "/" + (month<10 ? "0" + month : "" + month) + "/" + (day<10 ? "0" + day : "" + day);

	    return(currentDate);
    }

	private String getPreviousDate()
	{
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE)-1;
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);

		String previousDate = "";
        previousDate = "" + year + "/" + (month<10 ? "0" + month : "" + month) + "/" + (day<10 ? "0" + day : "" + day);

	    return(previousDate);
    }

	private void createCell(HSSFRow row, HSSFCell cell, int cellPosition, boolean newCell,
							int cellAlignment, int cellType, HSSFCellStyle style ,String strValue, double doubleValue)
	{
		if(newCell)
			cell = row.createCell((short)cellPosition);

		cell.setCellType(cellType);
		style.setAlignment((short)cellAlignment);

		if(cell.getCellType()==HSSFCell.CELL_TYPE_NUMERIC)
			cell.setCellValue(doubleValue);
		else
			cell.setCellValue(strValue);

		cell.setCellStyle(style);
	}

	private String replaceAll(String sourceString, String replace, String with)
	{
		if (sourceString == null || replace == null || with == null || "".equals(replace))
		{
			return sourceString;
		}

		StringBuffer buf = new StringBuffer(sourceString.length());
		int start = 0, end = 0;
		while ((end = sourceString.indexOf(replace, start)) != -1)
		{
			buf.append(sourceString.substring(start, end)).append(with);
			start = end + replace.length();
		}
		buf.append(sourceString.substring(start));
		return buf.toString();
	}

}
