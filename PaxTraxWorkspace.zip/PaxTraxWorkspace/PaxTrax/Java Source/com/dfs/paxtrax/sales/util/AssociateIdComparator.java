package com.dfs.paxtrax.sales.util;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.Comparator;

import com.dfs.paxtrax.sales.valueobject.SalesReportBean;


/**
 * Comparator class for sorting Associate Ids.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 31/08/2004	P.C. Sathish	Created 
 */
public class AssociateIdComparator implements Comparator {
	public int compare(Object o1, Object o2) {
		SalesReportBean item1 = (SalesReportBean) o1;
		SalesReportBean item2 = (SalesReportBean) o2;
		if (item1.getAssociateId() > item2.getAssociateId()) {
			return 1;
		} else if (item1.getAssociateId() < item2.getAssociateId()) {
			return -1;
		} else {
			return 0;
		}
	}
}
