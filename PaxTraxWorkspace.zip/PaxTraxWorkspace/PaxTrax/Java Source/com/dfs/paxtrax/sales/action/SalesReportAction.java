package com.dfs.paxtrax.sales.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.apache.commons.collections.comparators.ReverseComparator;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.sales.actionform.SalesReportForm;
import com.dfs.paxtrax.sales.service.SalesReportDelegate;
import com.dfs.paxtrax.sales.util.AssociateIdComparator;
import com.dfs.paxtrax.sales.util.DepartmentIdComparator;
import com.dfs.paxtrax.sales.util.NetSalesComparator;
import com.dfs.paxtrax.sales.util.SalesTerminalComparator;
import com.dfs.paxtrax.sales.util.TenderCodeComparator;
import com.dfs.paxtrax.sales.util.TenderReceivedComparator;
import com.dfs.paxtrax.sales.util.TenderRefundedComparator;
import com.dfs.paxtrax.sales.util.TenderTotalComparator;
import com.dfs.paxtrax.sales.util.TxnCountComparator;
import com.dfs.paxtrax.sales.util.UnitsRefundedComparator;
import com.dfs.paxtrax.sales.util.UnitsSoldComparator;
import com.dfs.paxtrax.sales.util.TicketSpendingComparator;
import com.dfs.paxtrax.sales.valueobject.SalesByHourBean;
import com.dfs.paxtrax.sales.valueobject.SalesReportBean;

/**
* This action class is used for calculating stamp duty and printing the report
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 19/09/2004    Joseph Oommen A Created
*/
public class SalesReportAction extends PaxTraxAction
{

	String forward = null;

	/**
	* Forwards to create stamp duty page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to sales Report home page
	*/
	public ActionForward createSalesReportHomePage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		return mapping.findForward("salesReportHome");
	}

	public ActionForward createSalesTenderReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTenderReportPage::Begin");

		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			SalesReportBean salesReportBean = new SalesReportBean();
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			ArrayList locationList = salesReportDelegate.listAllLocations();
			salesReportForm.setLocationDescription(null);
			salesReportForm.setLocationList(locationList);
			salesReportForm.setHourList(getArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setMinuteList(getArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setReverseHourList(getReverseArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setReverseMinuteList(getReverseArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setLocationDescription(null);
			
			//May 14, 2005
			//Change made to initialise the from date and to date to the current system date
			String currentDate = getCurrentDate();
			salesReportBean.setFromDate(currentDate);
			salesReportBean.setToDate(currentDate);
			//			
			
			salesReportForm.setSalesReportBean(salesReportBean);
			initializeForm(salesReportForm);
			forward = "salesTenderReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesTenderReportPage ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTenderReportPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesTenderReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTenderReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			resultList = salesReportDelegate.createSalesTenderReport(salesReportBean);
			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;

			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesTenderReceived();

					salesNetTotal = salesNetTotal + tempBean.getSalesTenderTotal();
					refundsGrossTotal = refundsGrossTotal + tempBean.getSalesTenderRefunded();

				}

				salesReportForm.setResultList(resultList);

				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{

				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = "salesTenderReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesTenderReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTenderReport::End");
		return mapping.findForward(forward);
	}
	public ActionForward createSalesAssociateReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesAssociateReportPage::Begin");

		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			SalesReportBean salesReportBean = new SalesReportBean();
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			ArrayList locationList = salesReportDelegate.listAllLocations();
			salesReportForm.setLocationDescription(null);
			salesReportForm.setLocationList(locationList);
			salesReportForm.setHourList(getArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setMinuteList(getArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setLocationDescription(null);
			
			//May 14, 2005
			//Change made to initialise the from date and to date to the current system date
			String currentDate = getCurrentDate();
			salesReportBean.setFromDate(currentDate);
			salesReportBean.setToDate(currentDate);
			//
			
			salesReportForm.setSalesReportBean(salesReportBean);
			initializeForm(salesReportForm);
			forward = "salesAssociateReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesAssociateReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesAssociateReportPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesAssociateReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesAssociateReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			resultList = salesReportDelegate.createSalesAssociateReport(salesReportBean);

			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;

			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal = transactionCountTotal + tempBean.getTransactionCount();

				}
				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesDiscountsTotal(formatter.format(salesDiscountsTotal));
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				salesReportForm.setRefundsNetTotal(formatter.format(refundsNetTotal));
				salesReportForm.setRefundsDiscountsTotal(formatter.format(refundsDiscountsTotal));
				salesReportForm.setNetSalesTotal(formatter.format(netSalesTotal));
				salesReportForm.setUnitsSoldTotal(unitsSoldTotal);
				salesReportForm.setUnitsRefundedTotal(unitsRefundedTotal);
				salesReportForm.setTransactionCountTotal(transactionCountTotal);
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = "salesAssociateReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesAssociateReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesAssociateReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward getSalesDepartmentReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesDepartmentReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			salesReportBean = salesReportDelegate.getSalesDepartmentReport(salesReportBean);
			HashMap userNameMap = salesReportBean.getUserNameMap();
			HashMap userSalesMap = salesReportBean.getUserSalesMap();
			HashMap userRefundMap = salesReportBean.getUserRefundMap();
			HashMap userSalesDiscountMap = salesReportBean.getUserSalesDiscountMap();
			HashMap userRefundDiscountMap = salesReportBean.getUserRefundDiscountMap();
			HashMap userSalesQtyMap = salesReportBean.getUserSalesQtyMap();
			HashMap userRefundQtyMap = salesReportBean.getUserRefundQtyMap();
			HashMap userTransactionQtyMap = salesReportBean.getUserTransactionQtyMap();
			HashMap userTicketSpendingMap = salesReportBean.getUserTicketSpendingMap();

			ArrayList salesDepartmentList = salesReportBean.getSalesAssociateList();
			int size = 0;
			if (salesDepartmentList != null)
				size = salesDepartmentList.size();

			//System.out.println("Size is " + size);

			for (int i = 0; i < size; i++)
			{
				String departmentId = (String) salesDepartmentList.get(i);
				SalesReportBean tempBean = new SalesReportBean();
				tempBean.setDepartmentId(Long.parseLong(departmentId));

				double NET_SALE = 0;
				if (userSalesMap.containsKey(departmentId))
					NET_SALE = Double.parseDouble((String) userSalesMap.get(departmentId));
				//System.out.println("NET_SALE " + NET_SALE);

				double DISC_SALE = 0;
				if (userSalesDiscountMap.containsKey(departmentId))
					DISC_SALE = Double.parseDouble((String) userSalesDiscountMap.get(departmentId));
				//System.out.println("DISC_SALE " + DISC_SALE);

				double NET_REFUND = 0;
				if (userRefundMap.containsKey(departmentId))
					NET_REFUND = Double.parseDouble((String) userRefundMap.get(departmentId));

				//System.out.println("NET_REFUND " + NET_REFUND);
				double DISC_REFUND = 0;
				if (userRefundDiscountMap.containsKey(departmentId))
					DISC_REFUND = Double.parseDouble((String) userRefundDiscountMap.get(departmentId));
				//System.out.println("DISC_REFUND " + DISC_REFUND);

				
				long SALEUNIT = 0;
				if (userSalesQtyMap.containsKey(departmentId))
					SALEUNIT = Long.parseLong((String) userSalesQtyMap.get(departmentId));
				//System.out.println("SALEUNIT " + SALEUNIT);

				long REFUNDUNIT = 0;
				if (userRefundQtyMap.containsKey(departmentId))
					REFUNDUNIT = Long.parseLong((String) userRefundQtyMap.get(departmentId));

				
				//System.out.println("REFUNDUNIT " + REFUNDUNIT);

				long TXNCOUNT = 0;
				if (userTransactionQtyMap.containsKey(departmentId))
					TXNCOUNT = Long.parseLong((String) userTransactionQtyMap.get(departmentId));
				//System.out.println("TXNCOUNT " + TXNCOUNT);
				
				long TICKSPENDCOUNT = 0;
				if (userTicketSpendingMap.containsKey(departmentId))
					TICKSPENDCOUNT = Long.parseLong((String) userTicketSpendingMap.get(departmentId));

				double SALEGROSSAMT = NET_SALE - DISC_SALE;

				double REFUNDGROSSAMT = (NET_REFUND - DISC_REFUND);
				if (REFUNDGROSSAMT != 0)
					REFUNDGROSSAMT = -1 * REFUNDGROSSAMT;

				double SALEDISCAMT = DISC_SALE;
				if (SALEDISCAMT != 0)
					SALEDISCAMT = -1 * SALEDISCAMT;

				double REFUNDDISCAMT = DISC_REFUND;
				double SALENETAMT = NET_SALE;
				double REFUNDNETAMT = NET_REFUND;
				if (REFUNDNETAMT != 0)
					REFUNDNETAMT = -1 * REFUNDNETAMT;
				double NETSALEAMT = SALENETAMT - REFUNDNETAMT;
				if (REFUNDUNIT != 0)
					REFUNDUNIT = (-1) * REFUNDUNIT;

				tempBean.setSalesGross(SALEGROSSAMT);
				tempBean.setSalesDiscounts(SALEDISCAMT);
				double salesNet = SALENETAMT;
				tempBean.setSalesNet(salesNet);
				tempBean.setRefundsGross(REFUNDGROSSAMT);
				tempBean.setRefundsDiscounts(REFUNDDISCAMT);
				double refundNet = REFUNDNETAMT;
				tempBean.setRefundsNet(refundNet);
				tempBean.setNetSales(salesNet - refundNet);
				tempBean.setUnitsSold(SALEUNIT-REFUNDUNIT);
				tempBean.setUnitsRefunded(REFUNDUNIT);
				tempBean.setTransactionCount(TXNCOUNT);
							
				//tempBean.setTicketSpending((double)TICKSPENDCOUNT);
				double tspend = (double)((tempBean.getSalesNet())/TICKSPENDCOUNT);
				if(Double.isNaN(tspend)){
					tempBean.setTicketSpending(0.00);
				} else {
					tempBean.setTicketSpending(tspend);
				}
				
				if (userNameMap.containsKey(departmentId))
					tempBean.setAssociateName((String) userNameMap.get(departmentId));
				else
					tempBean.setAssociateName(departmentId + " Unknown Department");
				resultList.add(tempBean);

			}

			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;
			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();

				}

				transactionCountTotal = salesReportBean.getTotalTransactionCount();
				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesDiscountsTotal(formatter.format(salesDiscountsTotal));
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				salesReportForm.setRefundsNetTotal(formatter.format(refundsNetTotal));
				salesReportForm.setRefundsDiscountsTotal(formatter.format(refundsDiscountsTotal));
				salesReportForm.setNetSalesTotal(formatter.format(netSalesTotal));
				salesReportForm.setUnitsSoldTotal(unitsSoldTotal);
				salesReportForm.setUnitsRefundedTotal(unitsRefundedTotal);
				salesReportForm.setTransactionCountTotal(transactionCountTotal);
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{

				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			TicketSpendingComparator ticketSpendingComparator = new TicketSpendingComparator ();
			boolean sort = sortSalesList(salesReportForm, ticketSpendingComparator , false);
			forward = "salesDepartmentReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::getSalesDepartmentReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesDepartmentReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward getSalesAssociateReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesAssociateReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			salesReportBean = salesReportDelegate.getSalesAssociateReport(salesReportBean);

			HashMap userNameMap = salesReportBean.getUserNameMap();
			HashMap userSalesMap = salesReportBean.getUserSalesMap();
			HashMap userRefundMap = salesReportBean.getUserRefundMap();
			HashMap userSalesDiscountMap = salesReportBean.getUserSalesDiscountMap();
			HashMap userRefundDiscountMap = salesReportBean.getUserRefundDiscountMap();
			HashMap userSalesQtyMap = salesReportBean.getUserSalesQtyMap();
			HashMap userRefundQtyMap = salesReportBean.getUserRefundQtyMap();
			HashMap userTransactionQtyMap = salesReportBean.getUserTransactionQtyMap();
			HashMap userTicketSpendingMap = salesReportBean.getUserTicketSpendingMap();
			ArrayList salesAssociateList = salesReportBean.getSalesAssociateList();

			//System.out.println(userSalesMap);

			//Set set = userSalesMap.keySet();
			//Iterator iterator = set.iterator();
			//while (iterator.hasNext())
			int size = 0;
			if (salesAssociateList != null)
				size = salesAssociateList.size();

			for (int i = 0; i < size; i++)
			{
				String associateId = (String) salesAssociateList.get(i);

				SalesReportBean tempBean = new SalesReportBean();
				tempBean.setAssociateId(Long.parseLong(associateId));
				//System.out.println("associateId " + associateId);

				double NET_SALE = 0;
				if (userSalesMap.containsKey(associateId))
					NET_SALE = Double.parseDouble((String) userSalesMap.get(associateId));
				//System.out.println("NET_SALE " + NET_SALE);

				double DISC_SALE = 0;
				if (userSalesDiscountMap.containsKey(associateId))
					DISC_SALE = Double.parseDouble((String) userSalesDiscountMap.get(associateId));
				//System.out.println("DISC_SALE " + DISC_SALE);

				double NET_REFUND = 0;
				if (userRefundMap.containsKey(associateId))
					NET_REFUND = Double.parseDouble((String) userRefundMap.get(associateId));

				//System.out.println("NET_REFUND " + NET_REFUND);
				double DISC_REFUND = 0;
				if (userRefundDiscountMap.containsKey(associateId))
					DISC_REFUND = Double.parseDouble((String) userRefundDiscountMap.get(associateId));
				//System.out.println("DISC_REFUND " + DISC_REFUND);

				long SALEUNIT = 0;
				if (userSalesQtyMap.containsKey(associateId))
					SALEUNIT = Long.parseLong((String) userSalesQtyMap.get(associateId));
				//System.out.println("SALEUNIT " + SALEUNIT);

				long REFUNDUNIT = 0;
				if (userRefundQtyMap.containsKey(associateId))
					REFUNDUNIT = Long.parseLong((String) userRefundQtyMap.get(associateId));
				//System.out.println("REFUNDUNIT " + REFUNDUNIT);

				long TXNCOUNT = 0;
				if (userTransactionQtyMap.containsKey(associateId))
					TXNCOUNT = Long.parseLong((String) userTransactionQtyMap.get(associateId));
				//System.out.println("TXNCOUNT " + TXNCOUNT);
				
				long TICKSPENDCOUNT = 0;
				if (userTicketSpendingMap.containsKey(associateId))
					TICKSPENDCOUNT = Long.parseLong((String) userTicketSpendingMap.get(associateId));

				double SALEGROSSAMT = NET_SALE - DISC_SALE;

				double REFUNDGROSSAMT = (NET_REFUND - DISC_REFUND);
				if (REFUNDGROSSAMT != 0)
					REFUNDGROSSAMT = -1 * REFUNDGROSSAMT;

				double SALEDISCAMT = DISC_SALE;
				if (SALEDISCAMT != 0)
					SALEDISCAMT = -1 * SALEDISCAMT;

				double REFUNDDISCAMT = DISC_REFUND;
				double SALENETAMT = NET_SALE;
				double REFUNDNETAMT = NET_REFUND;
				if (REFUNDNETAMT != 0)
					REFUNDNETAMT = -1 * REFUNDNETAMT;
				double NETSALEAMT = SALENETAMT - REFUNDNETAMT;
				/*if (REFUNDUNIT != 0)
					REFUNDUNIT = (-1) * REFUNDUNIT;*/

				tempBean.setSalesGross(SALEGROSSAMT);
				tempBean.setSalesDiscounts(SALEDISCAMT);
				double salesNet = SALENETAMT;
				tempBean.setSalesNet(salesNet);
				tempBean.setRefundsGross(REFUNDGROSSAMT);
				tempBean.setRefundsDiscounts(REFUNDDISCAMT);
				double refundNet = REFUNDNETAMT;
				tempBean.setRefundsNet(refundNet);
				tempBean.setNetSales(salesNet - refundNet);
				tempBean.setUnitsSold(SALEUNIT-REFUNDUNIT);
				tempBean.setUnitsRefunded(REFUNDUNIT);
				tempBean.setTransactionCount(TXNCOUNT);
				//tempBean.setTicketSpending((double)TICKSPENDCOUNT);
				double tspend = (double)((tempBean.getSalesNet())/TICKSPENDCOUNT);
				if(Double.isNaN(tspend)){
					tempBean.setTicketSpending(0.00);
				} else {
					tempBean.setTicketSpending(tspend);
				}
				if (userNameMap.containsKey(associateId))
					tempBean.setAssociateName((String) userNameMap.get(associateId));
				else
					tempBean.setAssociateName(associateId + " Unknown User");
				resultList.add(tempBean);

			}
			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;

			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal = transactionCountTotal + tempBean.getTransactionCount();

				}
				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesDiscountsTotal(formatter.format(salesDiscountsTotal));
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				salesReportForm.setRefundsNetTotal(formatter.format(refundsNetTotal));
				salesReportForm.setRefundsDiscountsTotal(formatter.format(refundsDiscountsTotal));
				salesReportForm.setNetSalesTotal(formatter.format(netSalesTotal));
				salesReportForm.setUnitsSoldTotal(unitsSoldTotal);
				salesReportForm.setUnitsRefundedTotal(unitsRefundedTotal);
				salesReportForm.setTransactionCountTotal(transactionCountTotal);
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = "salesAssociateReport";
			TicketSpendingComparator ticketSpendingComparator = new TicketSpendingComparator ();
			boolean sort = sortSalesList(salesReportForm, ticketSpendingComparator , false);
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::getSalesAssociateReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesAssociateReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesTerminalReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTerminalReportPage::Begin");

		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			SalesReportBean salesReportBean = new SalesReportBean();
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			ArrayList locationList = salesReportDelegate.listAllLocations();
			salesReportForm.setLocationDescription(null);
			salesReportForm.setLocationList(locationList);
			salesReportForm.setHourList(getArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setMinuteList(getArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setLocationDescription(null);

			//May 14, 2005
			//Change made to initialise the from date and to date to the current system date
			String currentDate = getCurrentDate();
			salesReportBean.setFromDate(currentDate);
			salesReportBean.setToDate(currentDate);
			//
						
			salesReportForm.setSalesReportBean(salesReportBean);
			initializeForm(salesReportForm);
			forward = "salesTerminalReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesTerminalReportPage ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTerminalReportPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesTerminalReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTerminalReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			resultList = salesReportDelegate.createSalestTerminalReport(salesReportBean);

			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;

			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal = transactionCountTotal + tempBean.getTransactionCount();

				}
				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesDiscountsTotal(formatter.format(salesDiscountsTotal));
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				salesReportForm.setRefundsNetTotal(formatter.format(refundsNetTotal));
				salesReportForm.setRefundsDiscountsTotal(formatter.format(refundsDiscountsTotal));
				salesReportForm.setNetSalesTotal(formatter.format(netSalesTotal));
				salesReportForm.setUnitsSoldTotal(unitsSoldTotal);
				salesReportForm.setUnitsRefundedTotal(unitsRefundedTotal);
				salesReportForm.setTransactionCountTotal(transactionCountTotal);
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = "salesTerminalReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesTerminalReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTerminalReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward getSalesTerminalReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesTerminalReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			salesReportBean = salesReportDelegate.getSalestTerminalReport(salesReportBean);

			

			HashMap userNameMap = salesReportBean.getUserNameMap();
			HashMap userSalesMap = salesReportBean.getUserSalesMap();
			HashMap userRefundMap = salesReportBean.getUserRefundMap();
			HashMap userSalesDiscountMap = salesReportBean.getUserSalesDiscountMap();
			HashMap userRefundDiscountMap = salesReportBean.getUserRefundDiscountMap();
			HashMap userSalesQtyMap = salesReportBean.getUserSalesQtyMap();
			HashMap userRefundQtyMap = salesReportBean.getUserRefundQtyMap();
			HashMap userTransactionQtyMap = salesReportBean.getUserTransactionQtyMap();
			ArrayList salesAssociateList = salesReportBean.getSalesAssociateList();


			//System.out.println(userSalesMap);

			//Set set = userSalesMap.keySet();
			//Iterator iterator = set.iterator();
			//while (iterator.hasNext())
			int size = 0;
			if (salesAssociateList != null)
				size = salesAssociateList.size();

			for (int i = 0; i < size; i++)
			{
				String terminalId = (String) salesAssociateList.get(i);

				SalesReportBean tempBean = new SalesReportBean();
				tempBean.setAssociateId(Long.parseLong(terminalId));

				tempBean.setTerminal(terminalId);
				//System.out.println("associateId " + associateId);

				double NET_SALE = 0;
				if (userSalesMap.containsKey(terminalId))
					NET_SALE = Double.parseDouble((String) userSalesMap.get(terminalId));
				//System.out.println("NET_SALE " + NET_SALE);

				double DISC_SALE = 0;
				if (userSalesDiscountMap.containsKey(terminalId))
					DISC_SALE = Double.parseDouble((String) userSalesDiscountMap.get(terminalId));
				//System.out.println("DISC_SALE " + DISC_SALE);

				double NET_REFUND = 0;
				if (userRefundMap.containsKey(terminalId))
					NET_REFUND = Double.parseDouble((String) userRefundMap.get(terminalId));

				//System.out.println("NET_REFUND " + NET_REFUND);
				double DISC_REFUND = 0;
				if (userRefundDiscountMap.containsKey(terminalId))
					DISC_REFUND = Double.parseDouble((String) userRefundDiscountMap.get(terminalId));
				//System.out.println("DISC_REFUND " + DISC_REFUND);

				long SALEUNIT = 0;
				if (userSalesQtyMap.containsKey(terminalId))
					SALEUNIT = Long.parseLong((String) userSalesQtyMap.get(terminalId));
				//System.out.println("SALEUNIT " + SALEUNIT);

				long REFUNDUNIT = 0;
				if (userRefundQtyMap.containsKey(terminalId))
					REFUNDUNIT = Long.parseLong((String) userRefundQtyMap.get(terminalId));
				//System.out.println("REFUNDUNIT " + REFUNDUNIT);

				long TXNCOUNT = 0;
				if (userTransactionQtyMap.containsKey(terminalId))
					TXNCOUNT = Long.parseLong((String) userTransactionQtyMap.get(terminalId));
				//System.out.println("TXNCOUNT " + TXNCOUNT);

				double SALEGROSSAMT = NET_SALE - DISC_SALE;

				double REFUNDGROSSAMT = (NET_REFUND - DISC_REFUND);
				if (REFUNDGROSSAMT != 0)
					REFUNDGROSSAMT = -1 * REFUNDGROSSAMT;

				double SALEDISCAMT = DISC_SALE;
				if (SALEDISCAMT != 0)
					SALEDISCAMT = -1 * SALEDISCAMT;

				double REFUNDDISCAMT = DISC_REFUND;
				double SALENETAMT = NET_SALE;
				double REFUNDNETAMT = NET_REFUND;
				if (REFUNDNETAMT != 0)
					REFUNDNETAMT = -1 * REFUNDNETAMT;
				double NETSALEAMT = SALENETAMT - REFUNDNETAMT;
				if (REFUNDUNIT != 0)
					REFUNDUNIT = (-1) * REFUNDUNIT;

				tempBean.setSalesGross(SALEGROSSAMT);
				tempBean.setSalesDiscounts(SALEDISCAMT);
				double salesNet = SALENETAMT;
				tempBean.setSalesNet(salesNet);
				tempBean.setRefundsGross(REFUNDGROSSAMT);
				tempBean.setRefundsDiscounts(REFUNDDISCAMT);
				double refundNet = REFUNDNETAMT;
				tempBean.setRefundsNet(refundNet);
				tempBean.setNetSales(salesNet - refundNet);
				tempBean.setUnitsSold(SALEUNIT);
				tempBean.setUnitsRefunded(REFUNDUNIT);
				tempBean.setTransactionCount(TXNCOUNT);

				resultList.add(tempBean);

			}

			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;

			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal = transactionCountTotal + tempBean.getTransactionCount();

				}
				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesDiscountsTotal(formatter.format(salesDiscountsTotal));
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				salesReportForm.setRefundsNetTotal(formatter.format(refundsNetTotal));
				salesReportForm.setRefundsDiscountsTotal(formatter.format(refundsDiscountsTotal));
				salesReportForm.setNetSalesTotal(formatter.format(netSalesTotal));
				salesReportForm.setUnitsSoldTotal(unitsSoldTotal);
				salesReportForm.setUnitsRefundedTotal(unitsRefundedTotal);
				salesReportForm.setTransactionCountTotal(transactionCountTotal);
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = "salesTerminalReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesTerminalReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesTerminalReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesDepartmentReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesDepartmentReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		salesReportForm.setLocationDescription(request.getParameter("location"));
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			resultList = salesReportDelegate.createSalesDepartmentReport(salesReportBean);
			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;
			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal = tempBean.getTotalTransactionCount();

				}

				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesDiscountsTotal(formatter.format(salesDiscountsTotal));
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				salesReportForm.setSalesNetTotal(formatter.format(salesNetTotal));
				salesReportForm.setRefundsGrossTotal(formatter.format(refundsGrossTotal));
				salesReportForm.setRefundsNetTotal(formatter.format(refundsNetTotal));
				salesReportForm.setRefundsDiscountsTotal(formatter.format(refundsDiscountsTotal));
				salesReportForm.setNetSalesTotal(formatter.format(netSalesTotal));
				salesReportForm.setUnitsSoldTotal(unitsSoldTotal);
				salesReportForm.setUnitsRefundedTotal(unitsRefundedTotal);
				salesReportForm.setTransactionCountTotal(transactionCountTotal);
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			}
			else
			{

				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = "salesDepartmentReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesDepartmentReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesDepartmentReport::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesDepartmentReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesDepartmentReportPage::Begin");
		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			SalesReportBean salesReportBean = new SalesReportBean();
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			ArrayList locationList = salesReportDelegate.listAllLocations();
			salesReportForm.setLocationList(locationList);
			salesReportForm.setHourList(getArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setMinuteList(getArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setReverseHourList(getReverseArrayList(PaxTraxConstants.TIME_HR));
			salesReportForm.setReverseMinuteList(getReverseArrayList(PaxTraxConstants.TIME_MIN));
			salesReportForm.setLocationDescription(null);
			
			// May 14, 2005 
			// Code added to initialise the fromDate and toDate on the screen to the current system date 
			String currentDate = getCurrentDate();
			salesReportBean.setFromDate(currentDate);
			salesReportBean.setToDate(currentDate);
			//
			
			salesReportForm.setSalesReportBean(salesReportBean);
			initializeForm(salesReportForm);
			forward = "salesDepartmentReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesDepartmentReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesDepartmentReportPage::End");
		return mapping.findForward(forward);
	}
	public ActionForward printSalesAssociateReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesAssociateReport::Begin");

		SalesReportForm salesReportForm = (SalesReportForm) form;
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		String fromDate = salesReportBean.getFromDate();
		String toDate = salesReportBean.getToDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		int year = Integer.parseInt(fromDate.substring(0, 4));
		int month = Integer.parseInt(fromDate.substring(5, 7));
		int date = Integer.parseInt(fromDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setFromDateDisplay(formatter.format(cal.getTime()));
		year = Integer.parseInt(toDate.substring(0, 4));
		month = Integer.parseInt(toDate.substring(5, 7));
		date = Integer.parseInt(toDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setToDateDisplay(formatter.format(cal.getTime()));

		request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesAssociateReport::End");
		return mapping.findForward("printSalesAssociateReport");
	}

	public ActionForward printSalesDepartmentReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesDepartmentReport::Begin");
		SalesReportForm salesReportForm = (SalesReportForm) form;
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		String fromDate = salesReportBean.getFromDate();
		String toDate = salesReportBean.getToDate();
		String fromHr = salesReportBean.getFromHr();
		String fromMin = salesReportBean.getFromMin();
		String toHr = salesReportBean.getToHr();
		String toMin = salesReportBean.getToMin();

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mma");
		Calendar cal = Calendar.getInstance();
		int year = Integer.parseInt(fromDate.substring(0, 4));
		int month = Integer.parseInt(fromDate.substring(5, 7));
		int date = Integer.parseInt(fromDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(fromHr));
		cal.set(Calendar.MINUTE, Integer.parseInt(fromMin));
		salesReportForm.setFromDateDisplay(formatter.format(cal.getTime()));
		year = Integer.parseInt(toDate.substring(0, 4));
		month = Integer.parseInt(toDate.substring(5, 7));
		date = Integer.parseInt(toDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(toHr));
		cal.set(Calendar.MINUTE, Integer.parseInt(toMin));
		salesReportForm.setToDateDisplay(formatter.format(cal.getTime()));
		request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesDepartmentReport::Begin");
		return mapping.findForward("printSalesDepartmentReport");
	}

	public ActionForward printSalesTerminalReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesTerminalReport::Begin");
		SalesReportForm salesReportForm = (SalesReportForm) form;
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		String fromDate = salesReportBean.getFromDate();
		String toDate = salesReportBean.getToDate();
		String fromHr = salesReportBean.getFromHr();
		String fromMin = salesReportBean.getFromMin();
		String toHr = salesReportBean.getToHr();
		String toMin = salesReportBean.getToMin();

		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		int year = Integer.parseInt(fromDate.substring(0, 4));
		int month = Integer.parseInt(fromDate.substring(5, 7));
		int date = Integer.parseInt(fromDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setFromDateDisplay(formatter.format(cal.getTime()));
		year = Integer.parseInt(toDate.substring(0, 4));
		month = Integer.parseInt(toDate.substring(5, 7));
		date = Integer.parseInt(toDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);

		salesReportForm.setToDateDisplay(formatter.format(cal.getTime()));
		request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesTerminalReport::Begin");
		return mapping.findForward("printSalesTerminalReport");
	}

	public ActionForward printSalesTenderReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesTerminalReport::Begin");

		SalesReportForm salesReportForm = (SalesReportForm) form;
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		String fromDate = salesReportBean.getFromDate();
		String toDate = salesReportBean.getToDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		int year = Integer.parseInt(fromDate.substring(0, 4));
		int month = Integer.parseInt(fromDate.substring(5, 7));
		int date = Integer.parseInt(fromDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setFromDateDisplay(formatter.format(cal.getTime()));
		year = Integer.parseInt(toDate.substring(0, 4));
		month = Integer.parseInt(toDate.substring(5, 7));
		date = Integer.parseInt(toDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setToDateDisplay(formatter.format(cal.getTime()));

		request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesTerminalReport::End");
		return mapping.findForward("printSalesTenderReport");
	}

	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::changeLanguage::Begin");
		String page = request.getParameter("page");
		String forwardPage = null;
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		super.changeLanguage(request, language, country);

		if ("salesReportHome".equals(page))
		{
			forwardPage = "salesReportHome";

		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::changeLanguage::End");
		return mapping.findForward(forwardPage);

	}

	/**
	 * Returns a temporary ArrayList with  values for Time Array
	 * @param String type
	 * @return ArrayList temp
	 */
	private ArrayList getArrayList(String type)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getArrayList::Begin");
		ReferenceDataBean commonBean = null;
		LocationBean locationBean = null;
		ArrayList temp = new ArrayList();
		for (int i = 0; i < 10; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}
		if (type.equals(PaxTraxConstants.TIME_HR))
		{
			for (int i = 10; i < 24; i++)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		else if (type.equals(PaxTraxConstants.TIME_MIN))
		{
			for (int i = 10; i < 60; i++)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getArrayList::End");
		return temp;
	}

	private ArrayList getReverseArrayList(String type)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getReverseArrayList::Begin");
		ReferenceDataBean commonBean = null;
		LocationBean locationBean = null;
		ArrayList temp = new ArrayList();

		if (type.equals(PaxTraxConstants.TIME_HR))
		{
			for (int i = 23; i > 9; i--)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		else if (type.equals(PaxTraxConstants.TIME_MIN))
		{
			for (int i = 59; i > 9; i--)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		for (int i = 9; i >= 0; i--)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}

		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getReverseArrayList::End");
		return temp;
	}

	private void initializeForm(SalesReportForm salesReportForm)
	{
		salesReportForm.setResultList(null);
		salesReportForm.setLocationDescription(null);
		salesReportForm.setSalesDiscountsTotal(null);
		salesReportForm.setSalesGrossTotal(null);
		salesReportForm.setSalesNetTotal(null);
		salesReportForm.setRefundsGrossTotal(null);
		salesReportForm.setRefundsNetTotal(null);
		salesReportForm.setRefundsDiscountsTotal(null);
		salesReportForm.setNetSalesTotal(null);
		salesReportForm.setUnitsSoldTotal(0);
		salesReportForm.setUnitsRefundedTotal(0);
		salesReportForm.setTransactionCountTotal(0);
	}
	
	/* May 14, 2005 
	 * Code added as a part of the CR to initialise the from date and to date 
	 * on the sales reports to the current system date 
	 */
	private String getCurrentDate()
	{
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE);
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);
		
		String currentDate = "";
		currentDate = "" + year + "/" + (month<10 ? "0" + month : "" + month) + "/" + (day<10 ? "0" + day : "" + day); 
	
		return(currentDate);
	}
	
	public ActionForward getSalesByHourReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesByHourReportPage::Begin");

		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			SalesReportBean salesReportBean = new SalesReportBean();
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			ArrayList locationList = salesReportDelegate.listAllLocations();
			salesReportForm.setLocationDescription(null);
			salesReportForm.setLocationList(locationList);

			String currentDate = getCurrentDate();
			salesReportBean.setFromDate(currentDate);
			salesReportBean.setToDate(currentDate);
						
			salesReportForm.setSalesReportBean(salesReportBean);
			forward = "salesByHourReportPage";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::getSalesByHourReportPage ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesByHourReportPage::End");
		return mapping.findForward(forward);
	}
	
	public ActionForward generateSalesDepartmentReport(ActionMapping mapping, ActionForm form , HttpServletRequest request, HttpServletResponse response)
	throws PaxTraxSystemException
	{
		ArrayList resultList = new ArrayList();;
		String groupColumnArray[]={"","","Sales","","","Refunds","","","","","",""};
		String columnArray[]={"Department Id","Department Name","Gross","Discounts","Net","Gross","Discounts","Net","Net Sales","Units Sold","Txn Count","Ticket Spending"};
		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;

			salesReportForm.setLocationDescription(request.getParameter("location"));
			//System.out.println("LOCATION DESCRIPTION--"+salesReportForm.getLocationDescription());
			SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
			
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");
			//System.out.println("USER--"+user);
			if (user != null)
				salesReportBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
			
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			salesReportBean = salesReportDelegate.getSalesDepartmentReport(salesReportBean);
			
		
			
			HashMap userNameMap = salesReportBean.getUserNameMap();
			HashMap userSalesMap = salesReportBean.getUserSalesMap();
			HashMap userRefundMap = salesReportBean.getUserRefundMap();
			HashMap userSalesDiscountMap = salesReportBean.getUserSalesDiscountMap();
			HashMap userRefundDiscountMap = salesReportBean.getUserRefundDiscountMap();
			HashMap userSalesQtyMap = salesReportBean.getUserSalesQtyMap();
			HashMap userRefundQtyMap = salesReportBean.getUserRefundQtyMap();
			HashMap userTransactionQtyMap = salesReportBean.getUserTransactionQtyMap();
			HashMap userTicketSpendingMap = salesReportBean.getUserTicketSpendingMap();

			ArrayList salesDepartmentList = salesReportBean.getSalesAssociateList();
			
			HashMap userNameMapTemp=salesReportBean.getUserNameMapTemp();
			HashMap userIdMapTemp=salesReportBean.getUserIdMapTemp();
			//System.out.println("(String) userNameMapTemp.get(departmentId):" + (String) userNameMapTemp.get(departmentId));
			int size = 0;
			if (salesDepartmentList != null)
				size = salesDepartmentList.size();
				
				
				
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("Sales By Department - "+salesReportBean.getLocation());
				sheet.setDefaultColumnWidth((short)16);
				//Create Header Font
				HSSFFont fontHeader = wb.createFont();
				fontHeader.setFontHeightInPoints((short)10);
				fontHeader.setFontName(HSSFFont.FONT_ARIAL);
				fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
								
				//Create font for the workbook Data cells
				HSSFFont font = wb.createFont();
				font.setFontHeightInPoints((short)10);
				font.setFontName(HSSFFont.FONT_ARIAL);
				
				//Style for the Header cells
				HSSFCellStyle styleHeader = wb.createCellStyle();
				styleHeader.setFont(fontHeader);
				styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
				styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				
				//Style for the Side Title cells
				HSSFCellStyle styleTitle = wb.createCellStyle();
				styleTitle.setFont(fontHeader);

				//Style for the Data cells
				HSSFCellStyle style = wb.createCellStyle();
				style.setFont(font);
				
				//Style for numeric data cells
				HSSFCellStyle styleNum = wb.createCellStyle();
				HSSFDataFormat format = wb.createDataFormat();
				styleNum.setDataFormat(format.getFormat("#,##0.00"));				
				styleNum.setFont(font);
				
				//Create Title rows
				HSSFRow row = sheet.createRow((short)0);
				HSSFCell cell = null;
				sheet.addMergedRegion(new Region(0, (short)0, 0, (short)11));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.DFS_OKINAWA, 0.0);
				//cell = row.getCell((short)0);
				//cell.setCellStyle(styleHeader);
								
				row = sheet.createRow((short)1);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT, 0.0);
				sheet.addMergedRegion(new Region(1, (short)0, 1, (short)11));	
				cell = row.getCell((short)0);
				cell.setCellStyle(styleHeader);				

				row = sheet.createRow((short)2);
				sheet.addMergedRegion(new Region(2, (short)0, 2, (short)1));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, "Location    :"+salesReportBean.getLocation()+" "+salesReportForm.getLocationDescription(), 0.0);				

				row = sheet.createRow((short)3);
				sheet.addMergedRegion(new Region(3, (short)0, 3, (short)1));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, "From Date :"+salesReportBean.getFromDate()+" "+"Time Hr "+salesReportBean.getFromHr()+":"+salesReportBean.getFromMin(), 0.0);				

				row = sheet.createRow((short)4);
				sheet.addMergedRegion(new Region(4, (short)0, 4, (short)1));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, "To Date     :"+salesReportBean.getToDate()+" "+"Time Hr "+salesReportBean.getToHr()+":"+salesReportBean.getToMin(), 0.0);





				int groupColnum=1;
				row = sheet.createRow((short)5);
				sheet.addMergedRegion(new Region(5, (short)2,5, (short)4));				
				sheet.addMergedRegion(new Region(5, (short)5,5, (short)7));				

				for(groupColnum=0; groupColnum<groupColumnArray.length; groupColnum++)
				{

					createCell(row,cell,groupColnum, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, groupColumnArray[groupColnum], 0.0);

				//	sheet.addMergedRegion(new Region(3, (short)colnum,3, (short)3));
				}
				

				
				
				row = sheet.createRow((short)6);

				int colnum=1;
						
				for(colnum=0; colnum<columnArray.length; colnum++)
				{

		

					createCell(row,cell,colnum, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, columnArray[colnum], 0.0);

				//	sheet.addMergedRegion(new Region(3, (short)colnum,3, (short)3));
				}
				
//				createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_HOUR_TOTAL_SALES, 0.0);
				
				sheet.createFreezePane(0,7,0,7);
		
			

			for (int i = 0; i < size; i++)
			{
				String departmentId = (String) salesDepartmentList.get(i);
				SalesReportBean tempBean = new SalesReportBean();
				tempBean.setDepartmentId(Long.parseLong(departmentId));
				double NET_SALE = 0;
				if (userSalesMap.containsKey(departmentId))
					NET_SALE = Double.parseDouble((String) userSalesMap.get(departmentId));
				//System.out.println("NET_SALE " + NET_SALE);

				double DISC_SALE = 0;
				if (userSalesDiscountMap.containsKey(departmentId))
					DISC_SALE = Double.parseDouble((String) userSalesDiscountMap.get(departmentId));
				//System.out.println("DISC_SALE " + DISC_SALE);

				double NET_REFUND = 0;
				if (userRefundMap.containsKey(departmentId))
					NET_REFUND = Double.parseDouble((String) userRefundMap.get(departmentId));

				//System.out.println("NET_REFUND " + NET_REFUND);
				double DISC_REFUND = 0;
				if (userRefundDiscountMap.containsKey(departmentId))
					DISC_REFUND = Double.parseDouble((String) userRefundDiscountMap.get(departmentId));
				//System.out.println("DISC_REFUND " + DISC_REFUND);

				
				long SALEUNIT = 0;
				if (userSalesQtyMap.containsKey(departmentId))
					SALEUNIT = Long.parseLong((String) userSalesQtyMap.get(departmentId));
				//System.out.println("SALEUNIT " + SALEUNIT);

				long REFUNDUNIT = 0;
				if (userRefundQtyMap.containsKey(departmentId))
					REFUNDUNIT = Long.parseLong((String) userRefundQtyMap.get(departmentId));

				
				//System.out.println("REFUNDUNIT " + REFUNDUNIT);

				long TXNCOUNT = 0;
				if (userTransactionQtyMap.containsKey(departmentId))
					TXNCOUNT = Long.parseLong((String) userTransactionQtyMap.get(departmentId));
				//System.out.println("TXNCOUNT " + TXNCOUNT);
				
				long TICKSPENDCOUNT = 0;
				if (userTicketSpendingMap.containsKey(departmentId))
					TICKSPENDCOUNT = Long.parseLong((String) userTicketSpendingMap.get(departmentId));

				double SALEGROSSAMT = NET_SALE - DISC_SALE;

				double REFUNDGROSSAMT = (NET_REFUND - DISC_REFUND);
				if (REFUNDGROSSAMT != 0)
					REFUNDGROSSAMT = -1 * REFUNDGROSSAMT;

				double SALEDISCAMT = DISC_SALE;
				if (SALEDISCAMT != 0)
					SALEDISCAMT = -1 * SALEDISCAMT;

				double REFUNDDISCAMT = DISC_REFUND;
				double SALENETAMT = NET_SALE;
				double REFUNDNETAMT = NET_REFUND;
				if (REFUNDNETAMT != 0)
					REFUNDNETAMT = -1 * REFUNDNETAMT;
				double NETSALEAMT = SALENETAMT - REFUNDNETAMT;
				if (REFUNDUNIT != 0)
					REFUNDUNIT = (-1) * REFUNDUNIT;

				tempBean.setSalesGross(SALEGROSSAMT);
				tempBean.setSalesDiscounts(SALEDISCAMT);
				double salesNet = SALENETAMT;
				tempBean.setSalesNet(salesNet);
				tempBean.setRefundsGross(REFUNDGROSSAMT);
				tempBean.setRefundsDiscounts(REFUNDDISCAMT);
				double refundNet = REFUNDNETAMT;
				tempBean.setRefundsNet(refundNet);
				tempBean.setNetSales(salesNet - refundNet);
				tempBean.setUnitsSold(SALEUNIT-REFUNDUNIT);
				tempBean.setUnitsRefunded(REFUNDUNIT);
				tempBean.setTransactionCount(TXNCOUNT);
				
				//tempBean.setTicketSpending((double)TICKSPENDCOUNT);
				double tspend = (double)((tempBean.getSalesNet())/TICKSPENDCOUNT);
				if(Double.isNaN(tspend)){
					tempBean.setTicketSpending(0.00);
				} else {
					tempBean.setTicketSpending(tspend);
				}
				
				if (userNameMap.containsKey(departmentId))
					tempBean.setAssociateName((String) userNameMap.get(departmentId));
				else
					tempBean.setAssociateName(departmentId + " Unknown Department");
					
				tempBean.setUserNameTemp((String) userNameMapTemp.get(departmentId));
				tempBean.setUserIdTemp((String) userIdMapTemp.get(departmentId));
				resultList.add(tempBean);
				
			}
			
			BeanComparator objComparator =
				new BeanComparator(
					"ticketSpending",new ReverseComparator(new ComparableComparator()));

			Collections.sort(resultList, objComparator);
			
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;
			if (resultList != null && !resultList.isEmpty())
			{


				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal = salesReportBean.getTotalTransactionCount();

				}
				}
			
				int deptRow=7;
				int col=0;			
			for(int j=0;j<size;j++)
			{
				row=sheet.createRow(deptRow);
				SalesReportBean tempBean = (SalesReportBean)resultList.get(j);
				if(tempBean.getUserIdTemp()!=null)
				{
				
					createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null,Double.parseDouble(tempBean.getUserIdTemp()) );					
				}
				else
				{
				
					createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_STRING, style, "-",0.0 );						
				}
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_STRING, style, tempBean.getUserNameTemp(),0.0 );

				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getSalesGross());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getSalesDiscounts());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getSalesNet());

				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getRefundsGross());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getRefundsDiscounts());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getRefundsNet());
				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getNetSales());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, tempBean.getUnitsSold());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, tempBean.getTransactionCount());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getTicketSpending());
				col=0;
				deptRow++;	
				
			}
			row=sheet.createRow(deptRow);

			for(colnum=0; colnum<columnArray.length; colnum++)
			{
				createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_STRING, style, "Total", 0.0);				
				col=1;
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesGrossTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesDiscountsTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesNetTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, refundsGrossTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, refundsDiscountsTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, refundsNetTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, netSalesTotal);	
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, unitsSoldTotal);	
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, transactionCountTotal);	
				break;
																
			}
		
			if(resultList!=null && resultList.size()>0)
			{
				
				//System.out.println("FILE--"+PaxTraxConstants.SALES_REPORTS_BASE_PATH + PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT + salesReportBean.getUser() + ".xls");
				FileOutputStream fileOut = new FileOutputStream(PaxTraxConstants.SALES_REPORTS_BASE_PATH + PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT + salesReportBean.getUser() + ".xls");
				wb.write(fileOut);
				fileOut.close();
				request.setAttribute(PaxTraxConstants.SUCCESS, "y");
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
				request.setAttribute(PaxTraxConstants.FILE_NAME, PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT + salesReportBean.getUser() + ".xls");
	
		
			}
				forward = "salesDepartmentReport";	
		}
		catch(Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::generateSalesByHourReport ", e);
			e.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
	
		return mapping.findForward(forward);
	}
	
	public ActionForward generateSalesByAssociateReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		ArrayList resultList = new ArrayList();
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		String groupColumnArray[]={"","","Sales","","","Refunds","","","","","",""};
		String columnArray[]={"Employee Id","Employee Name","Gross","Discounts","Net","Gross","Discounts","Net","Net Sales","Units Sold","Txn Count","Ticket Spending"};
		try
		{
			SalesReportForm salesReportForm=(SalesReportForm) form;
			salesReportForm.setLocationDescription(request.getParameter("location"));

			SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
			
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");

			if (user != null)
				salesReportBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
				
			salesReportBean = salesReportDelegate.getSalesAssociateReport(salesReportBean);
			
			
			
			
			HashMap userNameMap = salesReportBean.getUserNameMap();
			HashMap userSalesMap = salesReportBean.getUserSalesMap();
			HashMap userRefundMap = salesReportBean.getUserRefundMap();
			HashMap userSalesDiscountMap = salesReportBean.getUserSalesDiscountMap();
			HashMap userRefundDiscountMap = salesReportBean.getUserRefundDiscountMap();
			HashMap userSalesQtyMap = salesReportBean.getUserSalesQtyMap();
			HashMap userRefundQtyMap = salesReportBean.getUserRefundQtyMap();
			HashMap userTransactionQtyMap = salesReportBean.getUserTransactionQtyMap();
			HashMap userTicketSpendingMap = salesReportBean.getUserTicketSpendingMap();

			ArrayList salesDepartmentList = salesReportBean.getSalesAssociateList();
						
			HashMap userNameMapTemp=salesReportBean.getUserNameMapTemp();
			HashMap userIdMapTemp=salesReportBean.getUserIdMapTemp();
			int size = 0;
			if (salesDepartmentList != null)
				size = salesDepartmentList.size();
				
				
				
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("Sales By Associate - "+salesReportBean.getLocation());

				sheet.setDefaultColumnWidth((short)14);
				//Create Header Font
				HSSFFont fontHeader = wb.createFont();
				fontHeader.setFontHeightInPoints((short)10);
				fontHeader.setFontName(HSSFFont.FONT_ARIAL);
				fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
								
				//Create font for the workbook Data cells
				HSSFFont font = wb.createFont();
				font.setFontHeightInPoints((short)10);
				font.setFontName(HSSFFont.FONT_ARIAL);
				
				//Style for the Header cells
				HSSFCellStyle styleHeader = wb.createCellStyle();
				styleHeader.setFont(fontHeader);
				styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
				styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				
				//Style for the Side Title cells
				HSSFCellStyle styleTitle = wb.createCellStyle();
				styleTitle.setFont(fontHeader);

				//Style for the Data cells
				HSSFCellStyle style = wb.createCellStyle();
				style.setFont(font);
				
				//Style for numeric data cells
				HSSFCellStyle styleNum = wb.createCellStyle();
				HSSFDataFormat format = wb.createDataFormat();
				styleNum.setDataFormat(format.getFormat("#,##0.00"));				
				styleNum.setFont(font);
				
				//Create Title rows
				HSSFRow row = sheet.createRow((short)0);
				HSSFCell cell = null;
				sheet.addMergedRegion(new Region(0, (short)0, 0, (short)11));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.DFS_OKINAWA, 0.0);
				//cell = row.getCell((short)0);
				//cell.setCellStyle(styleHeader);
								
				row = sheet.createRow((short)1);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_ASSOCIATE_REPORT, 0.0);
				sheet.addMergedRegion(new Region(1, (short)0, 1, (short)11));	
				cell = row.getCell((short)0);
				cell.setCellStyle(styleHeader);				
				
				row = sheet.createRow((short)2);
				sheet.addMergedRegion(new Region(2, (short)0, 2, (short)1));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, "Location    :"+salesReportBean.getLocation()+" "+salesReportForm.getLocationDescription(), 0.0);				

				row = sheet.createRow((short)3);
				sheet.addMergedRegion(new Region(3, (short)0, 3, (short)1));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, "From Date :"+salesReportBean.getFromDate(), 0.0);				

				row = sheet.createRow((short)4);
				sheet.addMergedRegion(new Region(4, (short)0, 4, (short)1));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, "To Date     :"+salesReportBean.getToDate(), 0.0);


				int groupColnum=1;
				row = sheet.createRow((short)5);
				sheet.addMergedRegion(new Region(5, (short)2,5, (short)4));				
				sheet.addMergedRegion(new Region(5, (short)5,5, (short)7));				

				for(groupColnum=0; groupColnum<groupColumnArray.length; groupColnum++)
				{

					createCell(row,cell,groupColnum, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, groupColumnArray[groupColnum], 0.0);

				//	sheet.addMergedRegion(new Region(3, (short)colnum,3, (short)3));
				}
				
				

				int colnum=1;
				row = sheet.createRow((short)6);						
				for(colnum=0; colnum<columnArray.length; colnum++)
				{

		

					createCell(row,cell,colnum, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, columnArray[colnum], 0.0);

				//	sheet.addMergedRegion(new Region(3, (short)colnum,3, (short)3));
				}
	
//				createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_HOUR_TOTAL_SALES, 0.0);
				
				sheet.createFreezePane(0,7,0,7);
		
			

			for (int i = 0; i < size; i++)
			{
				String departmentId = (String) salesDepartmentList.get(i);
				
				SalesReportBean tempBean = new SalesReportBean();
				tempBean.setDepartmentId(Long.parseLong(departmentId));
				double NET_SALE = 0;
				if (userSalesMap.containsKey(departmentId))
					NET_SALE = Double.parseDouble((String) userSalesMap.get(departmentId));
				//System.out.println("NET_SALE " + NET_SALE);

				double DISC_SALE = 0;
				if (userSalesDiscountMap.containsKey(departmentId))
					DISC_SALE = Double.parseDouble((String) userSalesDiscountMap.get(departmentId));
				//System.out.println("DISC_SALE " + DISC_SALE);

				double NET_REFUND = 0;
				if (userRefundMap.containsKey(departmentId))
					NET_REFUND = Double.parseDouble((String) userRefundMap.get(departmentId));

				//System.out.println("NET_REFUND " + NET_REFUND);
				double DISC_REFUND = 0;
				if (userRefundDiscountMap.containsKey(departmentId))
					DISC_REFUND = Double.parseDouble((String) userRefundDiscountMap.get(departmentId));
				//System.out.println("DISC_REFUND " + DISC_REFUND);

				
				long SALEUNIT = 0;
				if (userSalesQtyMap.containsKey(departmentId))
					SALEUNIT = Long.parseLong((String) userSalesQtyMap.get(departmentId));
				//System.out.println("SALEUNIT " + SALEUNIT);

				long REFUNDUNIT = 0;
				if (userRefundQtyMap.containsKey(departmentId))
					REFUNDUNIT = Long.parseLong((String) userRefundQtyMap.get(departmentId));

				
				//System.out.println("REFUNDUNIT " + REFUNDUNIT);

				long TXNCOUNT = 0;
				if (userTransactionQtyMap.containsKey(departmentId))
					TXNCOUNT = Long.parseLong((String) userTransactionQtyMap.get(departmentId));
				//System.out.println("TXNCOUNT " + TXNCOUNT);
				
				long TICKSPENDCOUNT = 0;
				if (userTicketSpendingMap.containsKey(departmentId))
					TICKSPENDCOUNT = Long.parseLong((String) userTicketSpendingMap.get(departmentId));
				//System.out.println("TXNCOUNT " + TXNCOUNT);

				double SALEGROSSAMT = NET_SALE - DISC_SALE;

				double REFUNDGROSSAMT = (NET_REFUND - DISC_REFUND);
				if (REFUNDGROSSAMT != 0)
					REFUNDGROSSAMT = -1 * REFUNDGROSSAMT;

				double SALEDISCAMT = DISC_SALE;
				if (SALEDISCAMT != 0)
					SALEDISCAMT = -1 * SALEDISCAMT;

				double REFUNDDISCAMT = DISC_REFUND;
				double SALENETAMT = NET_SALE;
				double REFUNDNETAMT = NET_REFUND;
				if (REFUNDNETAMT != 0)
					REFUNDNETAMT = -1 * REFUNDNETAMT;
				double NETSALEAMT = SALENETAMT - REFUNDNETAMT;
				/* Commented for Ticket # 245517 by Selvam starts 	
				if (REFUNDUNIT != 0)
					REFUNDUNIT = (-1) * REFUNDUNIT;
				Commented for Ticket # 245517 by Selvam ends 	*/

				tempBean.setSalesGross(SALEGROSSAMT);
				tempBean.setSalesDiscounts(SALEDISCAMT);
				double salesNet = SALENETAMT;
				tempBean.setSalesNet(salesNet);
				tempBean.setRefundsGross(REFUNDGROSSAMT);
				tempBean.setRefundsDiscounts(REFUNDDISCAMT);
				double refundNet = REFUNDNETAMT;
				tempBean.setRefundsNet(refundNet);
				tempBean.setNetSales(salesNet - refundNet);
				tempBean.setUnitsSold(SALEUNIT-REFUNDUNIT);
				tempBean.setUnitsRefunded(REFUNDUNIT);
				tempBean.setTransactionCount(TXNCOUNT);
				
				//tempBean.setTicketSpending((double)TICKSPENDCOUNT);
				double tspend = (double)((tempBean.getSalesNet())/TICKSPENDCOUNT);
				if(Double.isNaN(tspend)){
					tempBean.setTicketSpending(0.00);
				} else {
					tempBean.setTicketSpending(tspend);
				}
				
				if (userNameMap.containsKey(departmentId))
					tempBean.setAssociateName((String) userNameMap.get(departmentId));
				else
					tempBean.setAssociateName(departmentId + " Unknown Department");
					
				tempBean.setUserNameTemp((String) userNameMapTemp.get(departmentId));
				tempBean.setUserIdTemp(departmentId);
				resultList.add(tempBean);
				
			}
			
			BeanComparator objComparator =
				new BeanComparator(
					"ticketSpending",new ReverseComparator(new ComparableComparator()));

			Collections.sort(resultList, objComparator);
			
			double salesGrossTotal = 0;
			double salesDiscountsTotal = 0;
			double salesNetTotal = 0;
			double refundsGrossTotal = 0;
			double refundsDiscountsTotal = 0;
			double refundsNetTotal = 0;
			double netSalesTotal = 0;
			long unitsSoldTotal = 0;
			long unitsRefundedTotal = 0;
			long transactionCountTotal = 0;
			if (resultList != null && !resultList.isEmpty())
			{


				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesGross();
					salesDiscountsTotal = salesDiscountsTotal + tempBean.getSalesDiscounts();
					salesNetTotal = salesNetTotal + tempBean.getSalesNet();
					refundsGrossTotal = refundsGrossTotal + tempBean.getRefundsGross();
					refundsDiscountsTotal = refundsDiscountsTotal + tempBean.getRefundsDiscounts();
					refundsNetTotal = refundsNetTotal + tempBean.getRefundsNet();
					netSalesTotal = netSalesTotal + tempBean.getNetSales();
					unitsSoldTotal = unitsSoldTotal + tempBean.getUnitsSold();
					unitsRefundedTotal = unitsRefundedTotal + tempBean.getUnitsRefunded();
					transactionCountTotal=transactionCountTotal+tempBean.getTransactionCount();

				}
				}
			
				int deptRow=7;
				int col=0;			
			for(int j=0;j<size;j++)
			{
				row=sheet.createRow(deptRow);
				SalesReportBean tempBean = (SalesReportBean)resultList.get(j);
				if(tempBean.getUserIdTemp()!=null)
				{
					//System.out.println("NOT NULL");
					createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null,Double.parseDouble(tempBean.getUserIdTemp()) );					
				}
				else
				{
					//System.out.println("NULL");
					createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_STRING, style, "-",0.0 );						
				}
//				createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null,tempBean.getUserIdTemp()!=null? Integer.parseInt(tempBean.getUserIdTemp()):0 );
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_STRING, style, tempBean.getUserNameTemp(),0.0 );

				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getSalesGross());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getSalesDiscounts());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getSalesNet());

				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getRefundsGross());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getRefundsDiscounts());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getRefundsNet());
				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getNetSales());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, tempBean.getUnitsSold());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, tempBean.getTransactionCount());
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, tempBean.getTicketSpending());
				col=0;
				deptRow++;	
				
			}
			row=sheet.createRow(deptRow);

			for(colnum=0; colnum<columnArray.length; colnum++)
			{
				createCell(row,cell,col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_STRING, style, "Total", 0.0);				
				col=1;
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesGrossTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesDiscountsTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesNetTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, refundsGrossTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, refundsDiscountsTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, refundsNetTotal);				
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, netSalesTotal);	
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, unitsSoldTotal);	
				createCell(row,cell,++col, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, style, null, transactionCountTotal);	
				break;
																
			}
		
			if(resultList!=null && resultList.size()>0)
			{
				
				//System.out.println("FILE--"+PaxTraxConstants.SALES_REPORTS_BASE_PATH + PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT + salesReportBean.getUser() + ".xls");
				FileOutputStream fileOut = new FileOutputStream(PaxTraxConstants.SALES_REPORTS_BASE_PATH + PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT + salesReportBean.getUser() + ".xls");
				
				wb.write(fileOut);
				fileOut.close();
				request.setAttribute(PaxTraxConstants.SUCCESS, "y");
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
				request.setAttribute(PaxTraxConstants.FILE_NAME, PaxTraxConstants.SALES_BY_DEPARTMENT_REPORT + salesReportBean.getUser() + ".xls");
	
		
			}
			
			
			
			
			
			
			

			forward="salesAssociateReport";
		}
		catch(Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::generateSalesByAssociateReport ", e);
			e.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}
	
	public ActionForward generateSalesByHourReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::generateSalesByHourReport::Begin");
		ArrayList resultList = null;
		String durationArray[] = {"", "", "", "", "", "5-6 AM", "6-7 AM", "7-8 AM", 
											"8-9 AM", "9-10 AM", "10-11 AM", "11-12 AM", "12-1 PM", 
											"1-2 PM", "2-3 PM", "3-4 PM", "4-5 PM", "5-6 PM", 
											"6-7 PM", "7-8 PM", "8-9 PM", "9-10 PM", "10-11 PM"};
		
		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			salesReportForm.setLocationDescription(request.getParameter("location"));
			SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
			
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");

			if (user != null)
				salesReportBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
			
			SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
			resultList = salesReportDelegate.generateSalesByHourReport(salesReportBean);
			
			if(resultList!=null && resultList.size()>0)
			{
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("Sales By Hour - "+salesReportBean.getLocation());
				
				//Create Header Font
				HSSFFont fontHeader = wb.createFont();
				fontHeader.setFontHeightInPoints((short)10);
				fontHeader.setFontName(HSSFFont.FONT_ARIAL);
				fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
								
				//Create font for the workbook Data cells
				HSSFFont font = wb.createFont();
				font.setFontHeightInPoints((short)10);
				font.setFontName(HSSFFont.FONT_ARIAL);
				
				//Style for the Header cells
				HSSFCellStyle styleHeader = wb.createCellStyle();
				styleHeader.setFont(fontHeader);
				styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
				styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				
				//Style for the Side Title cells
				HSSFCellStyle styleTitle = wb.createCellStyle();
				styleTitle.setFont(fontHeader);

				//Style for the Data cells
				HSSFCellStyle style = wb.createCellStyle();
				style.setFont(font);
				
				//Style for numeric data cells
				HSSFCellStyle styleNum = wb.createCellStyle();
				HSSFDataFormat format = wb.createDataFormat();
				styleNum.setDataFormat(format.getFormat("#,##0.00"));				
				styleNum.setFont(font);
								
				//Create Title rows
				HSSFRow row = sheet.createRow((short)0);
				HSSFCell cell = null;
				sheet.addMergedRegion(new Region(0, (short)0, 0, (short)19));
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.DFS_OKINAWA, 0.0);
				//cell = row.getCell((short)0);
				//cell.setCellStyle(styleHeader);
								
				row = sheet.createRow((short)1);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_HOUR_REPORT, 0.0);
				sheet.addMergedRegion(new Region(1, (short)0, 1, (short)19));	
				cell = row.getCell((short)0);
				cell.setCellStyle(styleHeader);				
				
				row = sheet.createRow((short)2);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, PaxTraxConstants.GENERATED_DATE + getCurrentDate(), 0.0);
				
				row = sheet.createRow((short)3);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_RIGHT, HSSFCell.CELL_TYPE_STRING, styleTitle, PaxTraxConstants.SALES_BY_HOUR_LOCATION + salesReportBean.getLocation(), 0.0);
				
				row = sheet.createRow((short)4);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, PaxTraxConstants.SALES_BY_HOUR_FROM_DATE +salesReportBean.getFromDate(), 0.0);
				
				row = sheet.createRow((short)5);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, PaxTraxConstants.SALES_BY_HOUR_TO_DATE +salesReportBean.getToDate(), 0.0);
				
				row = sheet.createRow((short)6);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_HOUR_DEPARTMENT, 0.0);
				
				int colnum=1;
				
				for(colnum=5; colnum<=22; colnum++)
					createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, durationArray[colnum], 0.0);
				
				createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_CENTER, HSSFCell.CELL_TYPE_STRING, styleHeader, PaxTraxConstants.SALES_BY_HOUR_TOTAL_SALES, 0.0);
				
				sheet.createFreezePane(0,7,0,7);
				
				int rownum = 7;
				colnum = 0;
				double totalSalesByDepartment = 0.0;
				double totalSales = 0.0;
				SalesByHourBean salesMixBean = new SalesByHourBean();
				
				for(int i=0; i<resultList.size();i++)
				{
					colnum = 0;
					SalesByHourBean salesByHourBean = (SalesByHourBean)resultList.get(i);

					row = sheet.createRow((short)rownum);
					createCell(row,cell,colnum, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, style, salesByHourBean.getDepartmentID() + " - " + salesByHourBean.getDepartmentDesc(), 0.0);
					
					totalSalesByDepartment = 0.0;
					
					for(colnum=5; colnum<=22; colnum++)
					{
						createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, salesByHourBean.getHourSales(colnum));
						totalSalesByDepartment = totalSalesByDepartment + salesByHourBean.getHourSales(colnum);
						salesMixBean.setHourSales(colnum, salesMixBean.getHourSales(colnum) + salesByHourBean.getHourSales(colnum));
					}
					
					createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, totalSalesByDepartment);
					rownum++;
					totalSales = totalSales + totalSalesByDepartment;
				}
				
				row = sheet.createRow((short)rownum);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, PaxTraxConstants.SALES_BY_HOUR_TOTAL_SALES, 0.0);
				
				row = sheet.createRow((short)rownum);
				createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, totalSales);
				
				rownum++;
				row = sheet.createRow((short)rownum);
				createCell(row,cell,0, true, HSSFCellStyle.ALIGN_LEFT, HSSFCell.CELL_TYPE_STRING, styleTitle, PaxTraxConstants.SALES_BY_HOUR_SALES_MIX, 0.0);
				
				for(colnum=5; colnum<=22; colnum++)
				{
					if(salesMixBean.getHourSales(colnum)!=0.0 && totalSales!=0.0)
						createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, (salesMixBean.getHourSales(colnum)/totalSales * 100));
					else
						createCell(row,cell,colnum-4, true, HSSFCellStyle.ALIGN_GENERAL, HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, 0.00);
				}
				
				//Set column Width - Column Formatting
				sheet.setColumnWidth((short)0, (short)10500);
				for(int i=1; i<20; i++)
					sheet.setColumnWidth((short)i, (short)3600);
				
				FileOutputStream fileOut = new FileOutputStream(PaxTraxConstants.SALES_REPORTS_BASE_PATH + PaxTraxConstants.SALES_BY_HOUR_REPORT + salesReportBean.getUser() + ".xls");
				wb.write(fileOut);
				fileOut.close();
				
				request.setAttribute(PaxTraxConstants.SUCCESS, "y");
	
				request.setAttribute(PaxTraxConstants.FILE_NAME, PaxTraxConstants.SALES_BY_HOUR_REPORT + salesReportBean.getUser() + ".xls");
			}
			else
			{
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = "salesByHourReportPage";
		}
		catch(Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::generateSalesByHourReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
			e.printStackTrace();
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::getSalesByHourReportPage::End");
		return mapping.findForward(forward);		
	}
	
	private void createCell(HSSFRow row, HSSFCell cell, int cellPosition, boolean newCell, 
							int cellAlignment, int cellType, HSSFCellStyle style ,String strValue, double doubleValue)
	{
		if(newCell)
			cell = row.createCell((short)cellPosition);
		
		cell.setCellType(cellType);
		style.setAlignment((short)cellAlignment);

		if(cell.getCellType()==HSSFCell.CELL_TYPE_NUMERIC)
			cell.setCellValue(doubleValue);
		else	
			cell.setCellValue(strValue);
			
		cell.setCellStyle(style);
	}	
	public ActionForward sortSalesReportByDeptId(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByDeptId::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			DepartmentIdComparator deptNameComparator = new DepartmentIdComparator();
			boolean sort = sortSalesList(salesReportForm, deptNameComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = forwardPage;//"salesDepartmentReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByDeptId::Exception caught :SalesReportAction::generateSalesByHourReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByDeptId::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByNetsales(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByNetsales::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}

			NetSalesComparator netSalesComparator = new NetSalesComparator();
			boolean sort = sortSalesList(salesReportForm, netSalesComparator, ascending);
			
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage;//forward = "salesDepartmentReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByNetsales", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByNetsales::End");
		return mapping.findForward(forward);
	}


	public ActionForward sortSalesReportByUnitsSold(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByUnitsSold::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}

			UnitsSoldComparator unitsSoldComparator = new UnitsSoldComparator();
			boolean sort = sortSalesList(salesReportForm, unitsSoldComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage;//forward = "salesDepartmentReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByUnitsSold", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByUnitsSold::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByUnitsRefunded(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByUnitsRefunded::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}

			UnitsRefundedComparator unitsRefundedComparator = new UnitsRefundedComparator();
			boolean sort = sortSalesList(salesReportForm, unitsRefundedComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesDepartmentReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByUnitsRefunded", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByUnitsRefunded::End");
		return mapping.findForward(forward);
	}
	
	public ActionForward sortSalesReportByTxnCount(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTxnCount::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}

			TxnCountComparator txnCountComparator = new TxnCountComparator();
			boolean sort = sortSalesList(salesReportForm, txnCountComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesDepartmentReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByTxnCount", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTxnCount::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByTerminal(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTerminal::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			boolean dataExists = false;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			SalesTerminalComparator terminalComparator = new SalesTerminalComparator();
			boolean sort = sortSalesList(salesReportForm, terminalComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
		
			forward = forwardPage; //forward = "salesTerminalReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByTerminal", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTerminal::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByAssociateId(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByAssociateId::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			boolean dataExists = false;
			
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			AssociateIdComparator associateIdComparator = new AssociateIdComparator();
			boolean sort = sortSalesList(salesReportForm, associateIdComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesTerminalReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByAssociateId", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByAssociateId::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByTenderCode(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderCode::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			boolean dataExists = false;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			TenderCodeComparator tenderCodeComparator = new TenderCodeComparator();
			boolean sort = sortSalesList(salesReportForm, tenderCodeComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesTerminalReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByTenderCode", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderCode::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByTenderReceived(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderReceived::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			boolean dataExists = false;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			TenderReceivedComparator tenderReceivedComparator = new TenderReceivedComparator();
			boolean sort = sortSalesList(salesReportForm, tenderReceivedComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesTerminalReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByTenderReceived", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderReceived::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByTenderRefunded(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderRefunded::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			boolean dataExists = false;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			TenderRefundedComparator tenderRefundedComparator = new TenderRefundedComparator();
			boolean sort = sortSalesList(salesReportForm, tenderRefundedComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesTerminalReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByTenderRefunded", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderRefunded::End");
		return mapping.findForward(forward);
	}

	public ActionForward sortSalesReportByTenderTotal(
								ActionMapping mapping, 
								ActionForm form, 
								HttpServletRequest request, 
								HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderTotal::Begin");
		try {
			SalesReportForm salesReportForm = (SalesReportForm) form;
			boolean ascending = true;
			boolean dataExists = false;
			String order = request.getParameter("Asc");
			String forwardPage = request.getParameter("forwardPage");
			if (order==null || order.equals(PaxTraxConstants.TRUE)) {
				ascending = true;
			} else {
				ascending = false;
			}
			
			TenderTotalComparator tenderTotalComparator = new TenderTotalComparator();
			boolean sort = sortSalesList(salesReportForm, tenderTotalComparator, ascending);
			if (sort) {
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			} else {
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			
			forward = forwardPage; //forward = "salesTerminalReport";
		}
		catch(Exception e) {
			PaxTraxLog.logError("PaxTrax::SalesReportAction::sortSalesReportByTenderTotal", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesReportByTenderTotal::End");
		return mapping.findForward(forward);
	}

	private boolean sortSalesList(SalesReportForm salesReportForm, 
								Comparator comparator, 
								boolean ascending) {
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesList::Begin");
		ArrayList resultList = salesReportForm.getResultList();
		if (resultList != null && !resultList.isEmpty()) {
			Collections.sort(resultList, comparator);
			if (!ascending) {
				Collections.reverse(resultList);
			}
			salesReportForm.setResultList(resultList);
			return true;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::sortSalesList::End");
		return false;
	}
	
	/*
	 * The report for location based sales at Airport
	*/
	public ActionForward createSalesLocationReportPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesLocationReportPage::Begin");

		try
		{
			SalesReportForm salesReportForm = (SalesReportForm) form;
			SalesReportBean salesReportBean = new SalesReportBean();
			String currentDate = getCurrentDate();
			salesReportBean.setFromDate(currentDate);
			salesReportBean.setToDate(currentDate);
			salesReportForm.setSalesReportBean(salesReportBean);
			initializeForm(salesReportForm);
			forward = "salesLocationReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesTenderReportPage ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTenderReportPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward createSalesLocationReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesTenderReport::Begin");
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		SalesReportForm salesReportForm = (SalesReportForm) form;
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		ArrayList resultList = new ArrayList();
		try
		{
			resultList = salesReportDelegate.createSalesLocationReport(salesReportBean);
			DecimalFormat formatter = new DecimalFormat("#,##0.00");
			double salesGrossTotal = 0;
			double refundsGrossTotal = 0;

			if (resultList != null && !resultList.isEmpty())
			{

				for (int i = 0; i < resultList.size(); i++)
				{
					SalesReportBean tempBean = (SalesReportBean) resultList.get(i);
					salesGrossTotal = salesGrossTotal + tempBean.getSalesLocation();
				
				}

				salesReportForm.setResultList(resultList);
				salesReportForm.setSalesGrossTotal(formatter.format(salesGrossTotal));
				request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
				
			}
			else
			{
				initializeForm(salesReportForm);
				ActionMessages messages = new ActionMessages();
				messages.add(PaxTraxConstants.LOCATION_ERROR, new ActionMessage("" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);

			}
			forward = "salesLocationReport";
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::createSalesLocationReport ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::createSalesLocationReport::End");
		return mapping.findForward(forward);
	}
	public ActionForward printSalesLocationReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesLocationReport::Begin");

		SalesReportForm salesReportForm = (SalesReportForm) form;
		SalesReportBean salesReportBean = salesReportForm.getSalesReportBean();
		String fromDate = salesReportBean.getFromDate();
		String toDate = salesReportBean.getToDate();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		int year = Integer.parseInt(fromDate.substring(0, 4));
		int month = Integer.parseInt(fromDate.substring(5, 7));
		int date = Integer.parseInt(fromDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setFromDateDisplay(formatter.format(cal.getTime()));
		year = Integer.parseInt(toDate.substring(0, 4));
		month = Integer.parseInt(toDate.substring(5, 7));
		date = Integer.parseInt(toDate.substring(8, 10));

		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month - 1);
		cal.set(Calendar.DATE, date);
		salesReportForm.setToDateDisplay(formatter.format(cal.getTime()));

		request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug("PaxTrax::SalesReportAction::printSalesLocationReport::End");
		return mapping.findForward("printSalesLocationReport");
	}
	
}
