package com.dfs.paxtrax.sales.business;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.sales.valueobject.SalesReportBean;
import com.dfs.paxtrax.sales.valueobject.SalesReportExtnBean;

/**
*Remote interface for Enterprise Bean: LocationBO
*
* @author Cognizant Technology Solutions
* contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER                COMMENTS
* 18/09/2004    Joseph Oommen A     Created   
*/
public interface SalesReportBO extends EJBObject
{

	/**
	   * Generate sales Associate reports from the database.
	   * @SalesReportBean- stampDutyBean
	   * @throws PaxTraxException This exception is thrown
	   * if there is any problem in insert
	   * 
	  */
	public ArrayList createSalesAssociateReport(SalesReportBean stampDutyBean) throws PaxTraxSystemException, RemoteException;

	public SalesReportBean getSalesAssociateReport(SalesReportBean salesReportBean) throws PaxTraxSystemException, RemoteException;

	/**
	   * Generate sales Associate reports from the database.
	   * @SalesReportBean- stampDutyBean
	   * @throws PaxTraxException This exception is thrown
	   * if there is any problem in insert
	   * 
	  */
	public ArrayList createSalesDepartmentReport(SalesReportBean stampDutyBean) throws PaxTraxSystemException, RemoteException;

	public SalesReportBean getSalesDepartmentReport(SalesReportBean stampDutyBean) throws PaxTraxSystemException, RemoteException;

	/**
	* Generate sales Tender reports from the database.
	* @SalesReportBean- stampDutyBean
	* @throws PaxTraxException This exception is thrown
	* if there is any problem in insert
	* 
	*/
	public ArrayList createTerminalReport(SalesReportBean stampDutyBean) throws PaxTraxSystemException, RemoteException;

	public SalesReportBean getTerminalReport(SalesReportBean stampDutyBean) throws PaxTraxSystemException, RemoteException;

	/**
		   * Generate sales Tender reports from the database.
		   * @SalesReportBean- stampDutyBean
		   * @throws PaxTraxException This exception is thrown
		   * if there is any problem in insert
		   * 
		 */
	public ArrayList createSalesTenderReport(SalesReportBean stampDutyBean) throws PaxTraxSystemException, RemoteException;
	/**
	* Lists the locations reports from the database.
	* @throws PaxTraxException This exception is thrown
	* if there is any problem in insert
	* 
	*/
	public ArrayList listLocations() throws PaxTraxSystemException, RemoteException;

	/**
	* Lists the locations reports from the database.
	* @throws PaxTraxException This exception is thrown
	* if there is any problem in insert
	* 
	*/
	public ArrayList listAllLocations() throws PaxTraxSystemException, RemoteException;
	
	public ArrayList generateSalesByHourReport(SalesReportBean salesReportBean) throws PaxTraxSystemException, RemoteException;
	
	/**
	 * Generate sales location reports from the database for the 2 airport locations
	 * @SalesReportBean- salesReportBean
	 * @throws PaxTraxException This exception is thrown
	 * if there is any problem in insert
	 * 
	*/
	public ArrayList createSalesLocationReport(SalesReportBean salesReportBean) throws PaxTraxSystemException, RemoteException;
	
    public SalesReportExtnBean getDFSOwnedSalesReport(SalesReportExtnBean salesReportBean) throws PaxTraxSystemException, RemoteException;
}
