package com.dfs.paxtrax.sales.valueobject;

/**
 * @author 124496
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
import java.util.ArrayList;
import java.util.HashMap;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


public class SalesReportExtnBean extends PaxTraxValueObject {
	
	private String currency=null;
	private String currencyDescription=null;
	private String exchangeRate="1";
	private String fromDate1 = null;
	private String toDate1 = null;
    private String fromDate2 = null;
	private String toDate2 = null;
	private String fromHr1=null;
	private String fromHr2=null;
	private String fromMin1=null;
	private String fromMin2=null;
	private String toHr1=null;
	private String toHr2=null;
	private String toMin1=null;
	private String toMin2=null;
	private String netSalesGalleriaDF1=null;
	private String ticketCountGalleriaDF1=null;
	private String netSalesGalleriaDP1=null;
	private String ticketCountGalleriaDP1=null;
	private String netSalesGalleriaTotal1=null;
	private String ticketCountGalleriaTotal1=null;
	private String netSalesAirportTotal1=null;
	private String ticketCountAirportTotal1=null;
	private String netSalesOkinawaTotal1=null;
	private String ticketCountOkinawaTotal1=null;
	private String netSalesGalleriaDF2=null;
	private String ticketCountGalleriaDF2=null;
	private String netSalesGalleriaDP2=null;
	private String ticketCountGalleriaDP2=null;
	private String netSalesGalleriaTotal2=null;
	private String ticketCountGalleriaTotal2=null;
	private String netSalesAirportTotal2=null;
	private String ticketCountAirportTotal2=null;
	private String netSalesOkinawaTotal2=null;
	private String ticketCountOkinawaTotal2=null;
	
	
	
	/**
	 * Returns the currency.
	 * @return String
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * Returns the currencyDescription.
	 * @return String
	 */
	public String getCurrencyDescription() {
		return currencyDescription;
	}

	/**
	 * Returns the exchangeRate.
	 * @return String
	 */
	public String getExchangeRate() {
		return exchangeRate;
	}

	/**
	 * Returns the fromDate1.
	 * @return String
	 */
	public String getFromDate1() {
		return fromDate1;
	}

	/**
	 * Returns the fromDate2.
	 * @return String
	 */
	public String getFromDate2() {
		return fromDate2;
	}

	/**
	 * Returns the fromHr1.
	 * @return String
	 */
	public String getFromHr1() {
		return fromHr1;
	}

	/**
	 * Returns the fromHr2.
	 * @return String
	 */
	public String getFromHr2() {
		return fromHr2;
	}

	/**
	 * Returns the fromMin1.
	 * @return String
	 */
	public String getFromMin1() {
		return fromMin1;
	}

	/**
	 * Returns the fromMin2.
	 * @return String
	 */
	public String getFromMin2() {
		return fromMin2;
	}

	/**
	 * Returns the netSalesAirportTotal1.
	 * @return String
	 */
	public String getNetSalesAirportTotal1() {
		return netSalesAirportTotal1;
	}

	/**
	 * Returns the netSalesAirportTotal2.
	 * @return String
	 */
	public String getNetSalesAirportTotal2() {
		return netSalesAirportTotal2;
	}

	/**
	 * Returns the netSalesGalleriaDF1.
	 * @return String
	 */
	public String getNetSalesGalleriaDF1() {
		return netSalesGalleriaDF1;
	}

	/**
	 * Returns the netSalesGalleriaDF2.
	 * @return String
	 */
	public String getNetSalesGalleriaDF2() {
		return netSalesGalleriaDF2;
	}

	/**
	 * Returns the netSalesGalleriaDP1.
	 * @return String
	 */
	public String getNetSalesGalleriaDP1() {
		return netSalesGalleriaDP1;
	}

	/**
	 * Returns the netSalesGalleriaDP2.
	 * @return String
	 */
	public String getNetSalesGalleriaDP2() {
		return netSalesGalleriaDP2;
	}

	/**
	 * Returns the netSalesGalleriaTotal1.
	 * @return String
	 */
	public String getNetSalesGalleriaTotal1() {
		return netSalesGalleriaTotal1;
	}

	/**
	 * Returns the netSalesGalleriaTotal2.
	 * @return String
	 */
	public String getNetSalesGalleriaTotal2() {
		return netSalesGalleriaTotal2;
	}

	/**
	 * Returns the netSalesOkinawaTotal1.
	 * @return String
	 */
	public String getNetSalesOkinawaTotal1() {
		return netSalesOkinawaTotal1;
	}

	/**
	 * Returns the netSalesOkinawaTotal2.
	 * @return String
	 */
	public String getNetSalesOkinawaTotal2() {
		return netSalesOkinawaTotal2;
	}

	/**
	 * Returns the ticketCountAirportTotal1.
	 * @return String
	 */
	public String getTicketCountAirportTotal1() {
		return ticketCountAirportTotal1;
	}

	/**
	 * Returns the ticketCountAirportTotal2.
	 * @return String
	 */
	public String getTicketCountAirportTotal2() {
		return ticketCountAirportTotal2;
	}

	/**
	 * Returns the ticketCountGalleriaDF1.
	 * @return String
	 */
	public String getTicketCountGalleriaDF1() {
		return ticketCountGalleriaDF1;
	}

	/**
	 * Returns the ticketCountGalleriaDF2.
	 * @return String
	 */
	public String getTicketCountGalleriaDF2() {
		return ticketCountGalleriaDF2;
	}

	/**
	 * Returns the ticketCountGalleriaDP1.
	 * @return String
	 */
	public String getTicketCountGalleriaDP1() {
		return ticketCountGalleriaDP1;
	}

	/**
	 * Returns the ticketCountGalleriaDP2.
	 * @return String
	 */
	public String getTicketCountGalleriaDP2() {
		return ticketCountGalleriaDP2;
	}

	/**
	 * Returns the ticketCountGalleriaTotal1.
	 * @return String
	 */
	public String getTicketCountGalleriaTotal1() {
		return ticketCountGalleriaTotal1;
	}

	/**
	 * Returns the ticketCountGalleriaTotal2.
	 * @return String
	 */
	public String getTicketCountGalleriaTotal2() {
		return ticketCountGalleriaTotal2;
	}

	/**
	 * Returns the ticketCountOkinawaTotal1.
	 * @return String
	 */
	public String getTicketCountOkinawaTotal1() {
		return ticketCountOkinawaTotal1;
	}

	/**
	 * Returns the ticketCountOkinawaTotal2.
	 * @return String
	 */
	public String getTicketCountOkinawaTotal2() {
		return ticketCountOkinawaTotal2;
	}

	/**
	 * Returns the toDate1.
	 * @return String
	 */
	public String getToDate1() {
		return toDate1;
	}

	/**
	 * Returns the toDate2.
	 * @return String
	 */
	public String getToDate2() {
		return toDate2;
	}

	/**
	 * Returns the toHr1.
	 * @return String
	 */
	public String getToHr1() {
		return toHr1;
	}

	/**
	 * Returns the toHr2.
	 * @return String
	 */
	public String getToHr2() {
		return toHr2;
	}

	/**
	 * Returns the toMin1.
	 * @return String
	 */
	public String getToMin1() {
		return toMin1;
	}

	/**
	 * Returns the toMin2.
	 * @return String
	 */
	public String getToMin2() {
		return toMin2;
	}

	/**
	 * Sets the currency.
	 * @param currency The currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * Sets the currencyDescription.
	 * @param currencyDescription The currencyDescription to set
	 */
	public void setCurrencyDescription(String currencyDescription) {
		this.currencyDescription = currencyDescription;
	}

	/**
	 * Sets the exchangeRate.
	 * @param exchangeRate The exchangeRate to set
	 */
	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	/**
	 * Sets the fromDate1.
	 * @param fromDate1 The fromDate1 to set
	 */
	public void setFromDate1(String fromDate1) {
		this.fromDate1 = fromDate1;
	}

	/**
	 * Sets the fromDate2.
	 * @param fromDate2 The fromDate2 to set
	 */
	public void setFromDate2(String fromDate2) {
		this.fromDate2 = fromDate2;
	}

	/**
	 * Sets the fromHr1.
	 * @param fromHr1 The fromHr1 to set
	 */
	public void setFromHr1(String fromHr1) {
		this.fromHr1 = fromHr1;
	}

	/**
	 * Sets the fromHr2.
	 * @param fromHr2 The fromHr2 to set
	 */
	public void setFromHr2(String fromHr2) {
		this.fromHr2 = fromHr2;
	}

	/**
	 * Sets the fromMin1.
	 * @param fromMin1 The fromMin1 to set
	 */
	public void setFromMin1(String fromMin1) {
		this.fromMin1 = fromMin1;
	}

	/**
	 * Sets the fromMin2.
	 * @param fromMin2 The fromMin2 to set
	 */
	public void setFromMin2(String fromMin2) {
		this.fromMin2 = fromMin2;
	}

	/**
	 * Sets the netSalesAirportTotal1.
	 * @param netSalesAirportTotal1 The netSalesAirportTotal1 to set
	 */
	public void setNetSalesAirportTotal1(String netSalesAirportTotal1) {
		this.netSalesAirportTotal1 = netSalesAirportTotal1;
	}

	/**
	 * Sets the netSalesAirportTotal2.
	 * @param netSalesAirportTotal2 The netSalesAirportTotal2 to set
	 */
	public void setNetSalesAirportTotal2(String netSalesAirportTotal2) {
		this.netSalesAirportTotal2 = netSalesAirportTotal2;
	}

	/**
	 * Sets the netSalesGalleriaDF1.
	 * @param netSalesGalleriaDF1 The netSalesGalleriaDF1 to set
	 */
	public void setNetSalesGalleriaDF1(String netSalesGalleriaDF1) {
		this.netSalesGalleriaDF1 = netSalesGalleriaDF1;
	}

	/**
	 * Sets the netSalesGalleriaDF2.
	 * @param netSalesGalleriaDF2 The netSalesGalleriaDF2 to set
	 */
	public void setNetSalesGalleriaDF2(String netSalesGalleriaDF2) {
		this.netSalesGalleriaDF2 = netSalesGalleriaDF2;
	}

	/**
	 * Sets the netSalesGalleriaDP1.
	 * @param netSalesGalleriaDP1 The netSalesGalleriaDP1 to set
	 */
	public void setNetSalesGalleriaDP1(String netSalesGalleriaDP1) {
		this.netSalesGalleriaDP1 = netSalesGalleriaDP1;
	}

	/**
	 * Sets the netSalesGalleriaDP2.
	 * @param netSalesGalleriaDP2 The netSalesGalleriaDP2 to set
	 */
	public void setNetSalesGalleriaDP2(String netSalesGalleriaDP2) {
		this.netSalesGalleriaDP2 = netSalesGalleriaDP2;
	}

	/**
	 * Sets the netSalesGalleriaTotal1.
	 * @param netSalesGalleriaTotal1 The netSalesGalleriaTotal1 to set
	 */
	public void setNetSalesGalleriaTotal1(String netSalesGalleriaTotal1) {
		this.netSalesGalleriaTotal1 = netSalesGalleriaTotal1;
	}

	/**
	 * Sets the netSalesGalleriaTotal2.
	 * @param netSalesGalleriaTotal2 The netSalesGalleriaTotal2 to set
	 */
	public void setNetSalesGalleriaTotal2(String netSalesGalleriaTotal2) {
		this.netSalesGalleriaTotal2 = netSalesGalleriaTotal2;
	}

	/**
	 * Sets the netSalesOkinawaTotal1.
	 * @param netSalesOkinawaTotal1 The netSalesOkinawaTotal1 to set
	 */
	public void setNetSalesOkinawaTotal1(String netSalesOkinawaTotal1) {
		this.netSalesOkinawaTotal1 = netSalesOkinawaTotal1;
	}

	/**
	 * Sets the netSalesOkinawaTotal2.
	 * @param netSalesOkinawaTotal2 The netSalesOkinawaTotal2 to set
	 */
	public void setNetSalesOkinawaTotal2(String netSalesOkinawaTotal2) {
		this.netSalesOkinawaTotal2 = netSalesOkinawaTotal2;
	}

	/**
	 * Sets the ticketCountAirportTotal1.
	 * @param ticketCountAirportTotal1 The ticketCountAirportTotal1 to set
	 */
	public void setTicketCountAirportTotal1(String ticketCountAirportTotal1) {
		this.ticketCountAirportTotal1 = ticketCountAirportTotal1;
	}

	/**
	 * Sets the ticketCountAirportTotal2.
	 * @param ticketCountAirportTotal2 The ticketCountAirportTotal2 to set
	 */
	public void setTicketCountAirportTotal2(String ticketCountAirportTotal2) {
		this.ticketCountAirportTotal2 = ticketCountAirportTotal2;
	}

	/**
	 * Sets the ticketCountGalleriaDF1.
	 * @param ticketCountGalleriaDF1 The ticketCountGalleriaDF1 to set
	 */
	public void setTicketCountGalleriaDF1(String ticketCountGalleriaDF1) {
		this.ticketCountGalleriaDF1 = ticketCountGalleriaDF1;
	}

	/**
	 * Sets the ticketCountGalleriaDF2.
	 * @param ticketCountGalleriaDF2 The ticketCountGalleriaDF2 to set
	 */
	public void setTicketCountGalleriaDF2(String ticketCountGalleriaDF2) {
		this.ticketCountGalleriaDF2 = ticketCountGalleriaDF2;
	}

	/**
	 * Sets the ticketCountGalleriaDP1.
	 * @param ticketCountGalleriaDP1 The ticketCountGalleriaDP1 to set
	 */
	public void setTicketCountGalleriaDP1(String ticketCountGalleriaDP1) {
		this.ticketCountGalleriaDP1 = ticketCountGalleriaDP1;
	}

	/**
	 * Sets the ticketCountGalleriaDP2.
	 * @param ticketCountGalleriaDP2 The ticketCountGalleriaDP2 to set
	 */
	public void setTicketCountGalleriaDP2(String ticketCountGalleriaDP2) {
		this.ticketCountGalleriaDP2 = ticketCountGalleriaDP2;
	}

	/**
	 * Sets the ticketCountGalleriaTotal1.
	 * @param ticketCountGalleriaTotal1 The ticketCountGalleriaTotal1 to set
	 */
	public void setTicketCountGalleriaTotal1(String ticketCountGalleriaTotal1) {
		this.ticketCountGalleriaTotal1 = ticketCountGalleriaTotal1;
	}

	/**
	 * Sets the ticketCountGalleriaTotal2.
	 * @param ticketCountGalleriaTotal2 The ticketCountGalleriaTotal2 to set
	 */
	public void setTicketCountGalleriaTotal2(String ticketCountGalleriaTotal2) {
		this.ticketCountGalleriaTotal2 = ticketCountGalleriaTotal2;
	}

	/**
	 * Sets the ticketCountOkinawaTotal1.
	 * @param ticketCountOkinawaTotal1 The ticketCountOkinawaTotal1 to set
	 */
	public void setTicketCountOkinawaTotal1(String ticketCountOkinawaTotal1) {
		this.ticketCountOkinawaTotal1 = ticketCountOkinawaTotal1;
	}

	/**
	 * Sets the ticketCountOkinawaTotal2.
	 * @param ticketCountOkinawaTotal2 The ticketCountOkinawaTotal2 to set
	 */
	public void setTicketCountOkinawaTotal2(String ticketCountOkinawaTotal2) {
		this.ticketCountOkinawaTotal2 = ticketCountOkinawaTotal2;
	}

	/**
	 * Sets the toDate1.
	 * @param toDate1 The toDate1 to set
	 */
	public void setToDate1(String toDate1) {
		this.toDate1 = toDate1;
	}

	/**
	 * Sets the toDate2.
	 * @param toDate2 The toDate2 to set
	 */
	public void setToDate2(String toDate2) {
		this.toDate2 = toDate2;
	}

	/**
	 * Sets the toHr1.
	 * @param toHr1 The toHr1 to set
	 */
	public void setToHr1(String toHr1) {
		this.toHr1 = toHr1;
	}

	/**
	 * Sets the toHr2.
	 * @param toHr2 The toHr2 to set
	 */
	public void setToHr2(String toHr2) {
		this.toHr2 = toHr2;
	}

	/**
	 * Sets the toMin1.
	 * @param toMin1 The toMin1 to set
	 */
	public void setToMin1(String toMin1) {
		this.toMin1 = toMin1;
	}

	/**
	 * Sets the toMin2.
	 * @param toMin2 The toMin2 to set
	 */
	public void setToMin2(String toMin2) {
		this.toMin2 = toMin2;
	}

}
