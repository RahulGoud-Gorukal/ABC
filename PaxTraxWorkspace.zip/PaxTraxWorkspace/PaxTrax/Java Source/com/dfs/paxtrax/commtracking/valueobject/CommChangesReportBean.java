package com.dfs.paxtrax.commtracking.valueobject;

/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList; 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
** @author Cognizant Technology Solutions
* 
* * @version    1.0
* * MOD HISTORY
* DATE          USER            COMMENTS
* 21/09/2010    Viji		 	Created   
*/

public class CommChangesReportBean extends PaxTraxValueObject {

	private String seqId = null;
	
	private String action = null;
	
	private String taCode = null;
	
	private String taAgencyName = null;
	
	private String taAgencyOwner = null;
	
	private String purchaseRefID = null; //sales_type

	private String visitType = null;
	
	private String Original_Rate  = null;
	
	private String New_Rate = null;

	private String createdDate = null;

	private String modifiedUser = null;

	private String modifiedDate = null;

	/**
	 * Default Constructor for CommChangesBean
	 */
	public CommChangesReportBean()
	{
	}


	/**
	 * @return
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @return
	 */
	public String getModifiedUser() {
		return modifiedUser;
	}

	/**
	 * @return
	 */
	public String getNew_Rate() {
		return New_Rate;
	}

	/**
	 * @return
	 */
	public String getOriginal_Rate() {
		return Original_Rate;
	}

	/**
	 * @return
	 */
	public String getPurchaseRefID() {
		return purchaseRefID;
	}

	/**
	 * @return
	 */
	public String getSeqId() {
		return seqId;
	}

	/**
	 * @return
	 */
	public String getTaCode() {
		return taCode;
	}

	/**
	 * @return
	 */
	public String getVisitType() {
		return visitType;
	}

	/**
	 * @param string
	 */
	public void setModifiedDate(String string) {
		modifiedDate = string;
	}

	/**
	 * @param string
	 */
	public void setModifiedUser(String string) {
		modifiedUser = string;
	}

	/**
	 * @param string
	 */
	public void setNew_Rate(String string) {
		New_Rate = string;
	}

	/**
	 * @param string
	 */
	public void setOriginal_Rate(String string) {
		Original_Rate = string;
	}

	/**
	 * @param string
	 */
	public void setPurchaseRefID(String string) {
		purchaseRefID = string;
	}

	/**
	 * @param string
	 */
	public void setSeqId(String string) {
		seqId = string;
	}

	/**
	 * @param string
	 */
	public void setTaCode(String string) {
		taCode = string;
	}

	/**
	 * @param string
	 */
	public void setVisitType(String string) {
		visitType = string;
	}

	/**
	 * @return
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @return
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @return
	 */
	public String getTaAgencyName() {
		return taAgencyName;
	}

	/**
	 * @return
	 */
	public String getTaAgencyOwner() {
		return taAgencyOwner;
	}

	/**
	 * @param string
	 */
	public void setAction(String string) {
		action = string;
	}

	/**
	 * @param string
	 */
	public void setCreatedDate(String string) {
		createdDate = string;
	}

	/**
	 * @param string
	 */
	public void setTaAgencyName(String string) {
		taAgencyName = string;
	}

	/**
	 * @param string
	 */
	public void setTaAgencyOwner(String string) {
		taAgencyOwner = string;
	}

}