package com.dfs.paxtrax.commtracking.actionform;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;
import com.dfs.paxtrax.common.actionform.CommTraxActionForm;


public class SearchBranchForm extends CommTraxActionForm
{
	private ArrayList branchCollection = null;

	private String taCode = null;

	private String branchName = null;

	private String country = null;

	private String city= null;

	private String phone = null;

	private String email = null;

	private String contactPerson = null;
	
	private String segmentCode = null;

	private String branchCode = null;



	public String getTaCode()
	{
		return taCode;
	}

	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}

	public String getBranchName()
	{
		return branchName;
	}

	public void setBranchName(String branchName)
	{
		this.branchName = branchName;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getPhone()
	{
		return phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getContactPerson()
	{
		return contactPerson;
	}

	public void setContactPerson(String contactPerson)
	{
		this.contactPerson = contactPerson;
	}

	public ArrayList getBranchCollection()
	{
		return branchCollection;
	}

	public void setBranchCollection(ArrayList branchCollection)
	{
		this.branchCollection = branchCollection;
	}
	/**
	 * Returns the segmentCode.
	 * @return String
	 */
	public String getSegmentCode() {
		return segmentCode;
	}

	/**
	 * Sets the segmentCode.
	 * @param segmentCode The segmentCode to set
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	/**
	 * Returns the branchCode.
	 * @return String
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * Sets the branchCode.
	 * @param branchCode The branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

}