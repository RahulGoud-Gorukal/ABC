package com.dfs.paxtrax.commtracking.valueobject;

/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList; 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
** @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
* DFS - Buensalida Sheila
* * @version    1.0
* * MOD HISTORY
* DATE          USER            COMMENTS
* 18/05/2004    Joseph Oommen A Created   
*/

public class VisitBean extends PaxTraxValueObject {

	private String taCode = null;

	private String taBranchCode = null;

	private String targetPage = null;

	private String index = null;

	private String agencyName = null;
	
	private String agencyOwner = null;

	private String refCodeName = null;

	private ArrayList paxList = null;
	
	private String paxNo = null;

	private String paxLastName = null;

	private String paxFirstName = null;

	private String flightDeptDate = null;
	
	private String flightDeptFlightNo = null;

	private String postCode = null;
	
	private String comment = null;

	private String visitName = null;
	
	private String paxSeq = null;	

	  // Added by David for CR#3563 starts here
	  private String nationality = null;	
	  private String expVisitDateTo = null;
	  private String actVisitDateTo = null;
	  // Added by David for CR#3563 ends here
/* Commented by Vani on 06/08/2005
 * This change was done to dynamically populate the 
 * leased vendors of a TA and to add RAC classification based commission */


//	private String 	dfCo  = null;
//	private String 	dfCr  = null;
//	private String 	dfNco = null;
//	private String 	dfNcr = null;
//
//	private String 	dpCo  = null;
//	private String 	dpCr  = null;
//	private String 	dpNco = null;
//	private String 	dpNcr = null;
//
//	private String 	fenCo  = null;
//	private String 	fenCr  = null;
//	private String 	fenNco = null;
//	private String 	fenNcr = null;
//
//	private String 	praCo  = null;
//	private String 	praCr  = null;
//	private String 	praNco = null;
//	private String 	praNcr = null;
//
//	private String 	chaCo  = null;
//	private String 	chaCr  = null;
//	private String 	chaNco = null;
//	private String 	chaNcr = null;
//
//	private String 	othCo  = null;
//	private String 	othCr  = null;
//	private String 	othNco = null;
//	private String 	othNcr = null;


/* Added by Vani on 06/08/2005
 * This change was done to dynamically populate the 
 * leased vendors of a TA and to add RAC classification based commission */

 //Code addition starts here	
 
	private String conOri = null;
	private String conRep = null;
	private String nonConOri = null;
	private String nonConRep = null;
					
	private String RACDfsOri = null;
	private String RACDfsRep = null;
	private String RACDriOri = null;
	private String RACDriRep = null;
	
	//Modified on 2006-11-08  for CommTrax Enhancement
	private String RACDfsPick = null;
	private String RACDfsDori = null;
	private String RACDfsDrep = null;
	
	
	private String refCodeId = null;
	private String refId = null; 

 //Code addition ends here
 
	public String getTargetPage()
	{
		return targetPage;
	}
	
	public void setTargetPage(String targetPage)
	{
		this.targetPage = targetPage;
	}
	
	public String getIndex()
	{
		return index;
	}
	
	public void setIndex(String index)
	{
		this.index = index;
	}

	public String getPaxNo()
	{
		return paxNo;
	}

	public void setPaxNo(String paxNo)
	{
		this.paxNo = paxNo;
	}

	public String getPaxLastName()
	{
		return paxLastName;
	}

	public void setPaxLastName(String paxLastName)
	{
		this.paxLastName = paxLastName;
	}

	public String getPaxFirstName()
	{
		return paxFirstName;
	}

	public void setPaxFirstName(String paxFirstName)
	{
		this.paxFirstName = paxFirstName;
	}

	public String getFlightDeptDate()
	{
		return flightDeptDate;
	}

	public void setFlightDeptDate(String flightDeptDate)
	{
		this.flightDeptDate = flightDeptDate;
	}

	public String getFlightDeptFlightNo()
	{
		return flightDeptFlightNo;
	}

	public void setFlightDeptFlightNo(String flightDeptFlightNo)
	{
		this.flightDeptFlightNo = flightDeptFlightNo;
	}

	public String getPostCode()
	{
		return postCode;
	}

	public void setPostCode(String postCode)
	{
		this.postCode = postCode;
	}

	public String getTaCode()
	{
		return taCode;
	}
	
	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}

	public String getTaBranchCode()
	{
		return taBranchCode;
	}
	
	public void setTaBranchCode(String taBranchCode)
	{
		this.taBranchCode = taBranchCode;
	}	


	public String getAgencyName()
	{
		return agencyName;
	}
	
	public void setAgencyName(String agencyName)
	{
		this.agencyName = agencyName;
	}
	
	public String getAgencyOwner()
	{
		return agencyOwner;
	}
	
	public void setAgencyOwner(String agencyOwner)
	{
		this.agencyOwner = agencyOwner;
	}

    /**
       The Visit Code of the passenger
     */
    private String visitCode = null;
    /**
       The Description of the cage
     */
    private String taName = null;

    /**
       Remarks on the Cage
     */
    private String expVisitDate = null;

    /**
       Remarks on the Cage
     */
    private String expVisitTime = null;

    /**
       The maximum number of bags that can be placed in a cage
     */
    private String expNoOfPax = null;
    
    
    /**
       The  current status of the cage
     */
    private String currentStatus = "R";
    
    private String createdUser = null;
	
	private String modifiedUser = null;

	private String actVisitDate = null;

	private String actVisitTime = null;

    private String actNoOfPax = null;

	private String taBranchName = null;
	
	private String taGuide = null;
	
	private String taEscort = null;
	
	private String taRemarks = null;

	/** The List of all country values */
	private ArrayList arlTaName = null;

	/** The List of all Nationality values */
	private ArrayList arlTaBranchName = null;	

    /**
     * Default Constructor for CageBean
     */
	public VisitBean()
    {
    }
    /**
     * Returns the cageNumber.
     * @return String
     */
    
	public String getVisitCode()
	{
		return visitCode;
	}

	/**
	 * Returns the description.
	 * @return String
	 */
	public String getExpVisitDate()
	{
		return expVisitDate;
	}

	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getExpVisitTime()
	{
		return expVisitTime;
	}
/**
	 * Returns the description.
	 * @return String
	 */
	public String getActVisitDate()
	{
		return actVisitDate;
	}

	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getActVisitTime()
	{
		return actVisitTime;
	}
	/**
	 * Returns the maxNoOfCartonsPerCage.
	 * @return int
	 */
	public String getExpNoOfPax()
	{
		return expNoOfPax;
	}

	/**
	 * Returns the maxNoOfCartonsPerCage.
	 * @return int
	 */
	public String getActNoOfPax()
	{
		return actNoOfPax;
	}
	
	/**
	 * Sets the cageNumber.
	 * @param cageNumber The cageNumber to set
	 */
	public void setVisitCode(String visitCode)
	{
		this.visitCode = visitCode;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setExpVisitDate(String expVisitDate)
	{
		this.expVisitDate = expVisitDate;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setExpVisitTime(String expVisitTime)
	{
		this.expVisitTime = expVisitTime;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setActVisitDate(String actVisitDate)
	{
		this.actVisitDate = actVisitDate;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setActVisitTime(String actVisitTime)
	{
		this.actVisitTime = actVisitTime;
	}
	
	/**
	 * Sets the maxNoOfCartonsPerCage.
	 * @param maxNoOfCartonsPerCage The maxNoOfCartonsPerCage to set
	 */
	public void setExpNoOfPax(String expNoOfPax)
	{
		this.expNoOfPax = expNoOfPax;
	}

	/**
	 * Sets the maxNoOfCartonsPerCage.
	 * @param maxNoOfCartonsPerCage The maxNoOfCartonsPerCage to set
	 */
	public void setActNoOfPax(String actNoOfPax)
	{
		this.actNoOfPax = actNoOfPax;
	}

	/**
	 * Returns the currentStatus.
	 * @return String
	 */
	public String getCurrentStatus()
	{
		return currentStatus;
	}

	/**
	 * Sets the currentStatus.
	 * @param currentStatus The currentStatus to set
	 */
	public void setCurrentStatus(String currentStatus)
	{
		this.currentStatus = currentStatus;
	}

	public String getCreatedUser()
	{
		return createdUser;
	}
	
	public void setCreatedUser(String createdUser)
	{
		this.createdUser = createdUser;
	}

	public String getModifiedUser()
	{
		return modifiedUser;
	}
	
	public void setModifiedUser(String modifiedUser)
	{
		this.modifiedUser = modifiedUser;
	}

	public String getTaName()
	{
		return taName;
	}
	
	public void setTaName(String taName)
	{
		this.taName = taName;
	}

	public String getTaBranchName()
	{
		return taBranchName;
	}
	
	public void setTaBranchName(String taBranchName)
	{
		this.taBranchName = taBranchName;
	}
	
	public String getTaGuide()
	{
		return taGuide;
	}
	
	public void setTaGuide(String taGuide)
	{
		this.taGuide = taGuide;
	}
	
	public String getTaEscort()
	{
		return taEscort;
	}
	
	public void setTaEscort(String taEscort)
	{
		this.taEscort = taEscort;
	}
	
	public String getTaRemarks()
	{
		return taRemarks;
	}
	
	public void setTaRemarks(String taRemarks)
	{
		this.taRemarks = taRemarks;
	}

	public String getRefCodeName()
	{
		return refCodeName;
	}
	
	public void setRefCodeName(String refCodeName)
	{
		this.refCodeName = refCodeName;
	}
	/**
	 * Returns the arlTaName.
	 * @return ArrayList
	 */
	public ArrayList getArlTaName()
	{
		return arlTaName;
	}

	/**
	 * Returns the arlTaBranchName.
	 * @return ArrayList
	 */
	public ArrayList getArlTaBranchName()
	{
		return arlTaBranchName;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setArlTaName(ArrayList arlTaName)
	{
		this.arlTaName = arlTaName;
	}

	/**
	 * Sets the countryList.
	 * @param countryList The countryList to set
	 */
	public void setArlTaBranchName(ArrayList arlTaBranchName)
	{
		this.arlTaBranchName = arlTaBranchName;
	}

/* Commented by Vani on 06/08/2005
 * This change was done to dynamically populate the 
 * leased vendors of a TA and to add RAC classification based commission */

	
 
	/*Start Ta Commision*/
//	public String getDfCo()
//	{
//		return dfCo;
//	}
//
//	public void setDfCo(String dfCo)
//	{
//		this.dfCo = dfCo;
//	}
//
//	public String getDfCr()
//	{
//		return dfCr;
//	}
//
//	public void setDfCr(String dfCr)
//	{
//		this.dfCr = dfCr;
//	}
//
//	public String getDfNco()
//	{
//		return dfNco;
//	}
//
//	public void setDfNco(String dfNco)
//	{
//		this.dfNco = dfNco;
//	}
//
//	public String getDfNcr()
//	{
//		return dfNcr;
//	}
//
//	public void setDfNcr(String dfNcr)
//	{
//		this.dfNcr = dfNcr;
//	}
//
//	public String getDpCo()
//	{
//		return dpCo;
//	}
//
//	public void setDpCo(String dpCo)
//	{
//		this.dpCo = dpCo;
//	}
//
//	public String getDpCr()
//	{
//		return dpCr;
//	}
//
//	public void setDpCr(String dpCr)
//	{
//		this.dpCr = dpCr;
//	}
//
//	public String getDpNco()
//	{
//		return dpNco;
//	}
//
//	public void setDpNco(String dpNco)
//	{
//		this.dpNco = dpNco;
//	}
//
//	public String getDpNcr()
//	{
//		return dpNcr;
//	}
//
//	public void setDpNcr(String dpNcr)
//	{
//		this.dpNcr = dpNcr;
//	}
//
//	public String getFenCo()
//	{
//		return fenCo;
//	}
//
//	public void setFenCo(String fenCo)
//	{
//		this.fenCo = fenCo;
//	}
//
//	public String getFenCr()
//	{
//		return fenCr;
//	}
//
//	public void setFenCr(String fenCr)
//	{
//		this.fenCr = fenCr;
//	}
//
//	public String getFenNco()
//	{
//		return fenNco;
//	}
//
//	public void setFenNco(String fenNco)
//	{
//		this.fenNco = fenNco;
//	}
//
//	public String getFenNcr()
//	{
//		return fenNcr;
//	}
//
//	public void setFenNcr(String fenNcr)
//	{
//		this.fenNcr = fenNcr;
//	}
//
//	public String getPraCo()
//	{
//		return praCo;
//	}
//
//	public void setPraCo(String praCo)
//	{
//		this.praCo = praCo;
//	}
//
//	public String getPraCr()
//	{
//		return praCr;
//	}
//
//	public void setPraCr(String praCr)
//	{
//		this.praCr = praCr;
//	}
//
//	public String getPraNco()
//	{
//		return praNco;
//	}
//
//	public void setPraNco(String praNco)
//	{
//		this.praNco = praNco;
//	}
//
//	public String getPraNcr()
//	{
//		return praNcr;
//	}
//
//	public void setPraNcr(String praNcr)
//	{
//		this.praNcr = praNcr;
//	}
//
//	public String getChaCo()
//	{
//		return chaCo;
//	}
//
//	public void setChaCo(String chaCo)
//	{
//		this.chaCo = chaCo;
//	}
//
//	public String getChaCr()
//	{
//		return chaCr;
//	}
//
//	public void setChaCr(String chaCr)
//	{
//		this.chaCr = chaCr;
//	}
//
//	public String getChaNco()
//	{
//		return chaNco;
//	}
//
//	public void setChaNco(String chaNco)
//	{
//		this.chaNco = chaNco;
//	}
//
//	public String getChaNcr()
//	{
//		return chaNcr;
//	}
//
//	public void setChaNcr(String chaNcr)
//	{
//		this.chaNcr = chaNcr;
//	}
//
//	public String getOthCo()
//	{
//		return othCo;
//	}
//
//	public void setOthCo(String othCo)
//	{
//		this.othCo = othCo;
//	}
//
//	public String getOthCr()
//	{
//		return othCr;
//	}
//
//	public void setOthCr(String othCr)
//	{
//		this.othCr = othCr;
//	}
//
//	public String getOthNco()
//	{
//		return othNco;
//	}
//
//	public void setOthNco(String othNco)
//	{
//		this.othNco = othNco;
//	}
//
//	public String getOthNcr()
//	{
//		return othNcr;
//	}
//
//	public void setOthNcr(String othNcr)
//	{
//		this.othNcr = othNcr;
//	}
	/*End TA Commision*/

	/**
	 * Returns the paxList.
	 * @return ArrayList
	 */
	public ArrayList getPaxList()
	{
		return paxList;
	}

	/**
	 * Sets the paxList.
	 * @param paxList The paxList to set
	 */
	public void setPaxList(ArrayList paxList)
	{
		this.paxList = paxList;
	}

	/**
	 * Returns the comment.
	 * @return String
	 */
	public String getComment()
	{
		return comment;
	}

	/**
	 * Sets the comment.
	 * @param comment The comment to set
	 */
	public void setComment(String comment)
	{
		this.comment = comment;
	}

	/**
	 * Returns the paxSeq.
	 * @return String
	 */
	public String getPaxSeq()
	{
		return paxSeq;
	}

	/**
	 * Sets the paxSeq.
	 * @param paxSeq The paxSeq to set
	 */
	public void setPaxSeq(String paxSeq)
	{
		this.paxSeq = paxSeq;
	}

	/**
	 * Returns the visitName.
	 * @return String
	 */
	public String getVisitName()
	{
		return visitName;
	}

	/**
	 * Sets the visitName.
	 * @param visitName The visitName to set
	 */
	public void setVisitName(String visitName)
	{
		this.visitName = visitName;
	}
	
/* Added by Vani on 06/08/2005
 * This change was done to dynamically populate the 
 * leased vendors of a TA and to add RAC classification based commission */

 //Code addition starts here	
	/**
	 * Returns the nonConRep.
	 * @return String
	 */
	public String getNonConRep() {
		return nonConRep;
	}

	/**
	 * Returns the rACDfsOri.
	 * @return String
	 */
	public String getRACDfsOri() {
		return RACDfsOri;
	}

	/**
	 * Returns the rACDfsRep.
	 * @return String
	 */
	public String getRACDfsRep() {
		return RACDfsRep;
	}

	/**
	 * Returns the rACDriOri.
	 * @return String
	 */
	public String getRACDriOri() {
		return RACDriOri;
	}

	/**
	 * Returns the rACDriRep.
	 * @return String
	 */
	public String getRACDriRep() {
		return RACDriRep;
	}

	/**
	 * Sets the nonConRep.
	 * @param nonConRep The nonConRep to set
	 */
	public void setNonConRep(String nonConRep) {
		this.nonConRep = nonConRep;
	}

	/**
	 * Sets the rACDfsOri.
	 * @param rACDfsOri The rACDfsOri to set
	 */
	public void setRACDfsOri(String rACDfsOri) {
		RACDfsOri = rACDfsOri;
	}

	/**
	 * Sets the rACDfsRep.
	 * @param rACDfsRep The rACDfsRep to set
	 */
	public void setRACDfsRep(String rACDfsRep) {
		RACDfsRep = rACDfsRep;
	}

	/**
	 * Sets the rACDriOri.
	 * @param rACDriOri The rACDriOri to set
	 */
	public void setRACDriOri(String rACDriOri) {
		RACDriOri = rACDriOri;
	}

	/**
	 * Sets the rACDriRep.
	 * @param rACDriRep The rACDriRep to set
	 */
	public void setRACDriRep(String rACDriRep) {
		RACDriRep = rACDriRep;
	}

	/**
	 * Returns the conOri.
	 * @return String
	 */
	public String getConOri() {
		return conOri;
	}

	/**
	 * Returns the conRep.
	 * @return String
	 */
	public String getConRep() {
		return conRep;
	}

	/**
	 * Returns the nonConOri.
	 * @return String
	 */
	public String getNonConOri() {
		return nonConOri;
	}

	/**
	 * Sets the conOri.
	 * @param conOri The conOri to set
	 */
	public void setConOri(String conOri) {
		this.conOri = conOri;
	}

	/**
	 * Sets the conRep.
	 * @param conRep The conRep to set
	 */
	public void setConRep(String conRep) {
		this.conRep = conRep;
	}

	/**
	 * Sets the nonConOri.
	 * @param nonConOri The nonConOri to set
	 */
	public void setNonConOri(String nonConOri) {
		this.nonConOri = nonConOri;
	}

	/**
	 * Returns the refCodeId.
	 * @return String
	 */
	public String getRefCodeId() {
		return refCodeId;
	}

	/**
	 * Returns the refId.
	 * @return String
	 */
	public String getRefId() {
		return refId;
	}

	/**
	 * Sets the refCodeId.
	 * @param refCodeId The refCodeId to set
	 */
	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	/**
	 * Sets the refId.
	 * @param refId The refId to set
	 */
	public void setRefId(String refId) {
		this.refId = refId;
	}

 //Code addition ends here	
	/**
	 * Returns the rACDfsDori.
	 * @return String
	 */
	public String getRACDfsDori() {
		return RACDfsDori;
	}

	/**
	 * Returns the rACDfsDrep.
	 * @return String
	 */
	public String getRACDfsDrep() {
		return RACDfsDrep;
	}

	/**
	 * Returns the rACDfsPick.
	 * @return String
	 */
	public String getRACDfsPick() {
		return RACDfsPick;
	}

	/**
	 * Sets the rACDfsDori.
	 * @param rACDfsDori The rACDfsDori to set
	 */
	public void setRACDfsDori(String rACDfsDori) {
		RACDfsDori = rACDfsDori;
	}

	/**
	 * Sets the rACDfsDrep.
	 * @param rACDfsDrep The rACDfsDrep to set
	 */
	public void setRACDfsDrep(String rACDfsDrep) {
		RACDfsDrep = rACDfsDrep;
	}

	/**
	 * Sets the rACDfsPick.
	 * @param rACDfsPick The rACDfsPick to set
	 */
	public void setRACDfsPick(String rACDfsPick) {
		RACDfsPick = rACDfsPick;
	}

	/**
	 * @return
	 */
	public String getActVisitDateTo() {
		return actVisitDateTo;
	}

	/**
	 * @return
	 */
	public String getExpVisitDateTo() {
		return expVisitDateTo;
	}

	/**
	 * @return
	 */
	public String getNationality() {
		return nationality;
	}

	/**
	 * @param string
	 */
	public void setActVisitDateTo(String string) {
		actVisitDateTo = string;
	}

	/**
	 * @param string
	 */
	public void setExpVisitDateTo(String string) {
		expVisitDateTo = string;
	}

	/**
	 * @param string
	 */
	public void setNationality(String string) {
		nationality = string;
	}

}