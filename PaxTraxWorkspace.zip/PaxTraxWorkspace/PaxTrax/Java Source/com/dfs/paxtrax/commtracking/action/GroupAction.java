package com.dfs.paxtrax.commtracking.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.GroupForm;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.GroupBean;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

//Added by selvam for Ticket # 283759  starts
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
//Added by selvam for Ticket # 283759  ends

/**
 * This is action class which perform create and search group
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/11/2004	Yuvarani    	Created   
 */


public class GroupAction extends PaxTraxAction
{
	
	/**
	 * Searches Group for a given visit code.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward searchGroup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::searchGroup::Begin");		
		GroupForm groupForm = (GroupForm)form;
		HttpSession session = request.getSession();
		String index = (String)request.getAttribute(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getAttribute("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getAttribute(PaxTraxConstants.PAGE_NUMBER));
		VisitBean visit = (VisitBean)request.getAttribute(
			PaxTraxConstants.VISIT_BEAN);

		String forward = "";
 
		try
		{
			CommTraxDelegate groupDelegate = new CommTraxDelegate();
			ArrayList groupList = groupDelegate.searchGroup(visit);
			groupForm.setGroupList(groupList);		
			groupForm.setGroupVisitBean(visit);
			forward = PaxTraxConstants.SEARCH_GROUP_PAGE;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logError("PaxTrax::GroupAction::searchGroup::SystemException",
				paxException);
			forward = PaxTraxConstants.SYSTEM_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::GroupAction::searchGroup::End");		
		return mapping.findForward(forward);
	}

//Added by selvam for Ticket # 283759  starts


  private ArrayList formatNationality(ArrayList nationalityList)
  {
	  if (nationalityList.size() > 0)
	  {
		  for (int i = 0; i < nationalityList.size(); i++)
		  {
			  ReferenceDataBean rdBean =
				  (ReferenceDataBean) nationalityList.get(i);

			  rdBean.setCodeValue(
				  rdBean.getCodeId() + " - " + rdBean.getCodeValue());
			  nationalityList.set(i, rdBean);
		  }
	  }

	  return (nationalityList);
  }
  
//Added by selvam for Ticket # 283759  ends 

	public ActionForward goToAddGroup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::goToAddGroup::Begin");
		GroupForm groupForm = (GroupForm)form;

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		VisitBean visit = groupForm.getGroupVisitBean();
		GroupBean groupBean = new GroupBean();
		PAXBean paxBean = new PAXBean();
		paxBean = initializePAXBean(paxBean);

		try
		{
			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
			groupForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));

			paxBean.setTaBranch(visit.getTaBranchCode());
			paxBean.setTaBranchName(visit.getTaBranchName());
			paxBean.setTourCode(visit.getVisitCode());
			paxBean.setTravelAgencyName(visit.getTaName());
			paxBean.setTravelAgentCode(visit.getTaCode());
			//Added by selvam for Ticket # 283759  starts
			paxBean.setNationality(PaxTraxConstants.DEFAULT_NATIONALITY);
			ArrayList nationalityList =
							rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
						nationalityList = formatNationality(nationalityList);

					 
			//Added by selvam for Ticket # 283759  ends
		 
			
			groupBean.setPaxBean(paxBean);
			groupForm.setGroupBean(groupBean);
			//Added by selvam for Ticket # 283759  starts
			groupForm.setNationalityList(nationalityList);
			//Added by selvam for Ticket # 283759  ends
			System.out.println("GroupAction ::  goToAddGroup ends");
			PaxTraxLog.logDebug("PaxTrax::GroupAction::goToAddGroup::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::createVisiPaxPage",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}
		return mapping.findForward(PaxTraxConstants.ADD_GROUP);
	}

	/**
	 * Method initializePAXBean.
	 * 
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * The method to initialize PAX bean with all the constituent Beans
	 */

	private PAXBean initializePAXBean(PAXBean paxBean)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::GroupAction::initializePAXBean::Begin");

		FlightDetailsBean deptFlightBean = paxBean.getDepartureFlightDetails();
		
		if (deptFlightBean == null)
			deptFlightBean = new FlightDetailsBean();
			
		deptFlightBean.setFlightType("D");
		paxBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);
		FlightDetailsBean arrFlightBean = paxBean.getArrivalFlightDetails();
		if (arrFlightBean == null)
			arrFlightBean = new FlightDetailsBean();
		arrFlightBean.setFlightType("A");

		deptFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
		arrFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);

		paxBean.setDepartureFlightDetails(deptFlightBean);
		paxBean.setArrivalFlightDetails(arrFlightBean);

		PaxTraxLog.logDebug("PaxTrax::GroupAction::initializePAXBean::End");
		return (paxBean);
	}
	
	/**
	 * Adds Group.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward addGroup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::addGroup::Begin");
		GroupForm groupForm = (GroupForm)form;
		GroupBean groupBean = groupForm.getGroupBean();

		HttpSession session = request.getSession();
		String user = (String) session.getAttribute(PaxTraxConstants.USER_ID);

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		if (user != null)
			groupBean.setUser(user);
		else
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

		try
		{
			CommTraxDelegate delegate = new CommTraxDelegate();
			delegate.addGroup(groupBean);
			PaxTraxLog.logDebug("PaxTrax::GroupAction::addGroup::End");
		}
		catch (CommTraxException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::addGroup",pe);
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + pe.getErrorCode());
			return mapping.findForward(PaxTraxConstants.ADD_GROUP);
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::addGroup",pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.SAVE_ADD_GROUP);

	}

	/**
	 * Confirm Group.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward confirmGroup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::confirmGroup::Begin");
		GroupForm groupForm = (GroupForm) form;
		request.setAttribute(PaxTraxConstants.INDEX,
			request.getParameter(PaxTraxConstants.INDEX));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute(PaxTraxConstants.VISIT_BEAN,groupForm.getGroupVisitBean());
		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::confirmGroup::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE);
	}

	public ActionForward loadGroupDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::loadGroupDetails::Begin");
		GroupForm groupForm = (GroupForm)form;
		ArrayList groupList = groupForm.getGroupList();

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		
		
		request.setAttribute("paxNo",request.getParameter("paxNo"));
		String indexId = request.getParameter("indexId");
		GroupBean groupBean = null;
		if (indexId != null)
			groupBean = (GroupBean)groupList.get(Integer.parseInt(indexId));
		
		PAXBean paxBean = groupBean.getPaxBean();
		paxBean = initializePAXBean(paxBean);
		
		VisitBean visit = groupForm.getGroupVisitBean();

		try
		{
			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
			groupForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));

//Added by selvam for Ticket # 283759  starts
 
 			ArrayList nationalityList =rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
			nationalityList = formatNationality(nationalityList);
			groupForm.setNationalityList(nationalityList);	
			paxBean.setNationality(paxBean.getNationality());
//Added by selvam for Ticket # 283759  ends	 

			paxBean.setTaBranch(visit.getTaBranchCode());
			paxBean.setTaBranchName(visit.getTaBranchName());
			paxBean.setTourCode(visit.getVisitCode());
			paxBean.setTravelAgencyName(visit.getTaName());
			paxBean.setTravelAgentCode(visit.getTaCode());
			groupBean.setPaxBean(paxBean);
			groupForm.setGroupBean(groupBean);

			PaxTraxLog.logDebug("PaxTrax::GroupAction::goToAddGroup::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::createVisiPaxPage",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}
		
		PaxTraxLog.logDebug("PaxTrax::GroupAction::loadGroupDetails::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_GROUP);
	}

	/**
	 * Maintain Group.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward maintainGroup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::maintainGroup::Begin");
		GroupForm groupForm = (GroupForm)form;
		GroupBean groupBean = groupForm.getGroupBean();

		HttpSession session = request.getSession();
		String user = (String) session.getAttribute(PaxTraxConstants.USER_ID);

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute("paxNo",request.getParameter("paxNo"));
		
		if (user != null)
			groupBean.setUser(user);
		else
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

		try
		{
			CommTraxDelegate delegate = new CommTraxDelegate();
			delegate.maintainGroup(groupBean);
			request.setAttribute(PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.MAINTAIN);
			PaxTraxLog.logDebug("PaxTrax::GroupAction::maintainGroup::End");
		}
		catch (CommTraxException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::maintainGroup",pe);
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + pe.getErrorCode());
			return mapping.findForward(PaxTraxConstants.MAINTAIN_GROUP);
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::maintainGroup",pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.SAVE_ADD_GROUP);

	}

	public ActionForward deleteGroup(	
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::deleteGroup::Begin");
		GroupForm groupForm = (GroupForm)form;
		GroupBean groupBean = groupForm.getGroupBean();

		HttpSession session = request.getSession();
		String user = (String) session.getAttribute(PaxTraxConstants.USER_ID);

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		if (user != null)
			groupBean.setUser(user);
		else
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

		try
		{
			CommTraxDelegate delegate = new CommTraxDelegate();
			delegate.deleteGroup(groupBean);
			request.setAttribute(PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.DELETE);
			PaxTraxLog.logDebug("PaxTrax::GroupAction::deleteGroup::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::GroupAction::deleteGroup",pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.SAVE_ADD_GROUP);
	}
	
	/**
	 * Used change the language
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::GroupAction::changeLanguage::Begin");

		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country =
			request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String page = request.getParameter(PaxTraxConstants.PAGE);

		if (language != null && country != null && page != null)
			super.changeLanguage(request, language, country);
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		if (page.equals(PaxTraxConstants.SEARCH_GROUP_PAGE))
			forwardPage = PaxTraxConstants.SEARCH_GROUP_PAGE;

		if (page.equals(PaxTraxConstants.ADD_GROUP))
			forwardPage = PaxTraxConstants.ADD_GROUP;

		if (page.equals(PaxTraxConstants.SAVE_ADD_GROUP))
			forwardPage = PaxTraxConstants.SAVE_ADD_GROUP;

		if (page.equals(PaxTraxConstants.MAINTAIN_GROUP))
			forwardPage = PaxTraxConstants.MAINTAIN_GROUP;

		String index = request.getParameter(PaxTraxConstants.INDEX);
		if (index != null && !index.equals("null"))
		{
			request.setAttribute(PaxTraxConstants.INDEX,index);
		}
		
		String errorCode = request.getParameter("errc");

		if (errorCode != null)
		{
			if (!(errorCode.equals("-1")))
			{
				request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
			}
		}

		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		if (fromPage != null && !fromPage.equals("null"))
		{
			request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);
		}
		
		request.setAttribute("paxNo",request.getParameter("paxNo"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));

		PaxTraxLog.logDebug("PaxTrax::GroupAction::changeLanguage::End");
		return (mapping.findForward(forwardPage));
	}

}

