package com.dfs.paxtrax.commtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 * This class is a value object holding commtrax params
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 18/05/2005	P.C.Sathish		Created
 */
public class CommTraxParams {
	private String fromDate;
	private String toDate;
	private String driveConstant;
	//Modified on 2006-11-30 for CommTrax Automation
	private String lastCommTraxGenDate;
	private String lastTaCorrectedDate;
	private String considerTaCorrectionProgram;

	/**
	 * Returns the driveConstant.
	 * @return String
	 */
	public String getDriveConstant() {
		return driveConstant;
	}

	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the driveConstant.
	 * @param driveConstant The driveConstant to set
	 */
	public void setDriveConstant(String driveConstant) {
		this.driveConstant = driveConstant;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	//Modified on 2006-11-30 for CommTrax Automation

		/**
		 * Returns the considerTaCorrectionProgram.
		 * @return
		 */
		public String getConsiderTaCorrectionProgram() {
			return considerTaCorrectionProgram;
		}

		/**
		 * Returns the lastCommTraxGenDate.
		 * @return
		 */
		public String getLastCommTraxGenDate() {
			return lastCommTraxGenDate;
		}

		/**
		 * Returns the lastTaCorrectedDate.
		 * @return
		 */
		public String getLastTaCorrectedDate() {
			return lastTaCorrectedDate;
		}

		/**
		 * Sets the considerTaCorrectionProgram.
		 * @param string
		 */
		public void setConsiderTaCorrectionProgram(String string) {
			considerTaCorrectionProgram = string;
		}

		/**
		 * Sets the lastCommTraxGenDate.
		 * @param string
		 */
		public void setLastCommTraxGenDate(String string) {
			lastCommTraxGenDate = string;
		}

		/**
		 * Sets the lastTaCorrectedDate.
		 * @param string
		 */
		public void setLastTaCorrectedDate(String string) {
			lastTaCorrectedDate = string;
		}



}
