/*
 * This file is created for Generating a report based on the Visit Changes.
 * Created on Sep 23, 2010
 * Create for CR1832 - 211360
 *
 */
package com.dfs.paxtrax.commtracking.action;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/*import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.apache.commons.collections.comparators.ReverseComparator;
*/
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.passenger.exception.PAXException;

import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.CommChangesReportBean;
import com.dfs.paxtrax.commtracking.valueobject.VisitChangesReportBean;

/**
 * @author 138182
 *
 */
public class VisitTrackingReportGenerator extends TimerTask {

	public VisitTrackingReportGenerator() {
	}

	public void init() {
	}

	public void run() {
		try {
			generateVisitChangeReport();
		} catch (PaxTraxSystemException paxtraxSystemException) {
			PaxTraxLog.logError(
				"PaxtraxPurgeScheduler : run()  PaxTrax System Exception ",
				paxtraxSystemException);
		}
	}

	private void createCell(
		HSSFRow row,
		HSSFCell cell,
		int cellPosition,
		boolean newCell,
		int cellAlignment,
		int cellType,
		HSSFCellStyle style,
		String strValue,
		double doubleValue) {
		if (newCell)
			cell = row.createCell((short) cellPosition);

		cell.setCellType(cellType);
		style.setAlignment((short) cellAlignment);

		if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
			cell.setCellValue(doubleValue);
		else
			cell.setCellValue(strValue);

		cell.setCellStyle(style);
	}

	void generateVisitChangeReport() throws PaxTraxSystemException {

		ArrayList resultList = new ArrayList();
		CommTraxDelegate commtraxDelegate = new CommTraxDelegate();
		ArrayList VisitChanges = new ArrayList();

		//	String groupColumnArray1[] = { "", "", "", "", "" };
		String VisitFlag = "N";

		try {
			if (VisitFlag.equalsIgnoreCase("N")) {

				VisitChanges = commtraxDelegate.getVisitChanges(VisitFlag);

				resultList = VisitChanges;

				createVisitChangeReports(VisitChanges, resultList, VisitFlag);
				VisitFlag = "Y";
			} 

				VisitChanges = commtraxDelegate.getVisitChanges(VisitFlag);

				resultList = VisitChanges;

				createVisitChangeReports(VisitChanges, resultList, VisitFlag);

			

		} catch (Exception e) {
			PaxTraxLog.logError(
				"Exception caught :SalesReportAction::generateSalesByAssociateReport ",
				e);
			e.printStackTrace();
		}

	}

	void createVisitChangeReports(
		ArrayList VisitChanges,
		ArrayList resultList,
		String VisitFlag) {
		String flag = VisitFlag;
		int size = 0;
		String columnArray[] =
			{
				"Action",
				"Visit Code",
				"Visit Date",
				"Group Number",
				"Nationality",
				"Value Changed",
				"Old value",
				"New Value",
				"Updated User",
				"Date/Time of Change" };
		try {
			Date today = new Date();

			if (VisitChanges != null)
				size = VisitChanges.size();

			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("Visit_Changes");

			sheet.setDefaultColumnWidth((short) 17);
			//Create Header Font
			HSSFFont fontHeader = wb.createFont();
			fontHeader.setFontHeightInPoints((short) 8);
			fontHeader.setFontName(HSSFFont.FONT_ARIAL);
			fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			fontHeader.setColor(HSSFColor.WHITE.index);

			//Create font for Date and Time
			HSSFFont fontWhite = wb.createFont();
			fontWhite.setFontHeightInPoints((short) 8);
			fontWhite.setFontName(HSSFFont.FONT_ARIAL);
			fontWhite.setColor(HSSFColor.DARK_RED.index);

			//Create font for the workbook Data cells
			HSSFFont font = wb.createFont();
			font.setFontHeightInPoints((short) 8);
			font.setFontName(HSSFFont.FONT_ARIAL);

			//Style for the Header cells
			HSSFCellStyle styleHeader = wb.createCellStyle();
			styleHeader.setFont(fontHeader);
			styleHeader.setFillForegroundColor(HSSFColor.DARK_RED.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			//Style for the Side Title cells
			HSSFCellStyle styleTitle = wb.createCellStyle();
			styleTitle.setFont(fontWhite);

//Style for the Header cells
		  HSSFCellStyle styleColHeader = wb.createCellStyle();
		  styleColHeader.setFont(fontHeader);
		  styleColHeader.setFillForegroundColor(HSSFColor.DARK_RED.index);
		  styleColHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		  styleColHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		  styleColHeader.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
		  styleColHeader.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
		  styleColHeader.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
		  styleColHeader.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);

			//Style for the Data cells
			HSSFCellStyle style = wb.createCellStyle();
			style.setFont(font);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);

			//Style for numeric data cells
			HSSFCellStyle styleNum = wb.createCellStyle();
			HSSFDataFormat format = wb.createDataFormat();
			styleNum.setDataFormat(format.getFormat("#,##0.00"));
			styleNum.setFont(font);
			styleNum.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			styleNum.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			styleNum.setBorderTop(HSSFCellStyle.BORDER_THIN);
			styleNum.setBorderRight(HSSFCellStyle.BORDER_THIN);

			//Create Title rows
			HSSFRow row = sheet.createRow((short) 0);
			HSSFCell cell = null;
			sheet.addMergedRegion(new Region(0, (short) 0, 0, (short) 9));
			//12 Columns
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.VERTICAL_CENTER,
				HSSFCell.CELL_TYPE_STRING,
				styleHeader,
				PaxTraxConstants.VISIT_CHANGES_REPORT,
				0.0);
			//cell = row.getCell((short)0);
			//cell.setCellStyle(styleHeader);

			row = sheet.createRow((short) 1);
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.VERTICAL_CENTER,
				HSSFCell.CELL_TYPE_STRING,
				styleHeader,
				"",
				0.0);
			sheet.addMergedRegion(new Region(0, (short) 0, 1, (short) 9));
			cell = row.getCell((short) 0);
			cell.setCellStyle(styleHeader);

			row = sheet.createRow((short) 2);
			sheet.addMergedRegion(new Region(2, (short) 0, 2, (short) 9));
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.ALIGN_LEFT,
				HSSFCell.CELL_TYPE_STRING,
				styleTitle,
				"Date :" + sdf.format(today),
				0.0);

			row = sheet.createRow((short) 3);
			sheet.addMergedRegion(new Region(3, (short) 0, 3, (short) 9));
			sdf = new SimpleDateFormat("hh:mm:ss a");
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.ALIGN_LEFT,
				HSSFCell.CELL_TYPE_STRING,
				styleTitle,
				"Time : " + sdf.format(today),
				0.0);

			//	int groupColnum = 1;
			row = sheet.createRow((short) 4);


			int colnum = 1;
			row = sheet.createRow((short) 5);
			for (colnum = 0; colnum < columnArray.length; colnum++) {

				createCell(
					row,
					cell,
					colnum,
					true,
					HSSFCellStyle.ALIGN_LEFT,
					HSSFCell.CELL_TYPE_STRING,
					styleColHeader,
					columnArray[colnum],
					0.0);

			}

			sheet.createFreezePane(0, 6, 0, 6);

			int deptRow = 6;
			int col = 0;
			for (int j = 0; j < size; j++) {
				row = sheet.createRow(deptRow);
				VisitChangesReportBean tempBean =
					(VisitChangesReportBean) resultList.get(j);

				System.out.println(
					tempBean.getVisitCode()
						+ " - "
						+ tempBean.getVisitDate()
						+ " - "
						+ tempBean.getGroupNumber()
						+ " - "
						+ tempBean.getNationality()
						+ " - "
						+ tempBean.getName()
						+ " - "
						+ tempBean.getOldValue()
						+ " - "
						+ tempBean.getNewValue()
						+ " - "
						+ tempBean.getUpdatedUser()
						+ " - "
						+ tempBean.getModifiedDate());
				VisitChanges.add(tempBean);

				createCell(
					row,
					cell,
					col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getAction(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getVisitCode(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getVisitDate(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getGroupNumber(),
					0.0);

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getNationality(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getName(),
					0.0);
			
			//Added for CR1832 UAT additional changes

			if( tempBean.getAction()!=null && tempBean.getAction().equalsIgnoreCase("Delete Group")) {
			
				String groupPax = (tempBean.getOldValue()!=null)? tempBean.getOldValue().trim() : tempBean.getOldValue() ;
				
				ArrayList paxNumList = getPaxSequencenumbers(groupPax.substring(0,groupPax.indexOf("_")),groupPax.substring(groupPax.indexOf("_")+1));
			
				String paxNumbers = "";
				
				
				for (int i=0; i< paxNumList.size() ; i++ ){
					paxNumbers = paxNumbers + paxNumList.get(i) +",";
				}

				if(paxNumList != null && paxNumList.size() > 0 ) {
					paxNumbers = paxNumbers.substring(0,paxNumbers.length()-1 );
				}
			
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					paxNumbers, /*tempBean.getOldValue(),*/
					0.0);
					
				System.err.println("PAXNUMBERS :::  DELETE GROUP ::: " + paxNumbers);
				
			} else {

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getOldValue(),
					0.0);
			}
			
			if( tempBean.getAction()!=null && tempBean.getAction().equalsIgnoreCase("Add Group")) {
			
				String groupPax = (tempBean.getNewValue()!=null)? tempBean.getNewValue().trim() : tempBean.getNewValue() ;
				
				ArrayList paxNumList = getPaxSequencenumbers(groupPax.substring(0,groupPax.indexOf("_")),groupPax.substring(groupPax.indexOf("_")+1));
			
				String paxNumbers = "";
				
				
				for (int i=0; i< paxNumList.size() ; i++ ){
					paxNumbers = paxNumbers + paxNumList.get(i) +",";
				}

				if(paxNumList != null && paxNumList.size() > 0 ) {
					paxNumbers = paxNumbers.substring(0,paxNumbers.length()-1 );
				}
			System.err.println("PAXNUMBERS :::  ADD GROUP ::: " + paxNumbers);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					paxNumbers,
					0.0);
			}
			else{

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getNewValue(),
					0.0);
			}
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getUpdatedUser(),
					0.0);

/*				Date updatedDate = new Date();

				SimpleDateFormat df =
					new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
				updatedDate = df.parse(tempBean.getModifiedDate());
				df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					System.out.println(
						"==================MODIFIED DATE: "
							+ tempBean.getModifiedDate() + " :: "+df.format(updatedDate));
*/
				String date = tempBean.getModifiedDate();
				date = date.substring(0,date.lastIndexOf(".")==-1 ? 0:date.lastIndexOf("."));
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					date,
					0.0);

				col = 0;
				deptRow++;

			}

			if (resultList != null && resultList.size() > 0) {
				sdf = new SimpleDateFormat("yyyyMMdd");
				if (flag.equalsIgnoreCase("Y")) {

					FileOutputStream fileOut =
						new FileOutputStream(
							PaxTraxConstants.SALES_REPORTS_BASE_PATH
								+ sdf.format(today)
								+ "_"
								+ PaxTraxConstants.VISIT_CHANGE_REPORTA
								+ ".xls");

					wb.write(fileOut);
					fileOut.close();
				}
				if (flag.equalsIgnoreCase("N")) {

					FileOutputStream fileOut =
						new FileOutputStream(
							PaxTraxConstants.SALES_REPORTS_BASE_PATH
								+ sdf.format(today)
								+ "_"
								+ PaxTraxConstants.VISIT_CHANGE_REPORTB
								+ ".xls");

					wb.write(fileOut);
					fileOut.close();
				}
			}
		} catch (Exception e) {
			PaxTraxLog.logError(
				"Exception caught :SalesReportAction::generateSalesByAssociateReport ",
				e);
			e.printStackTrace();
		}

	}
// 	Added for CR1832- UAT changes starts
	ArrayList getPaxSequencenumbers(String startpaxno, String noOfPax ){
		ArrayList arlPax = new ArrayList();
		try {
			long paxno = Long.parseLong(startpaxno);
			long iNoOfPax = Long.parseLong(noOfPax);
			for(int i=0; i<iNoOfPax;i++){
				arlPax.add(  fillZeroes((paxno+i)+"",10) );
				System.out.println(( fillZeroes((paxno+i)+"",10))+"===============");
			}
		} catch (Exception e){
			System.err.println("Pax Number creation Error");
			e.printStackTrace();
		}
		
		return arlPax;
		
	}
	
	public static String fillZeroes(String id, int fieldLength)
	{
		StringBuffer strBuff = new StringBuffer();
		try {
			for(int index = 0; index < fieldLength - id.length(); index++)
			{
				strBuff.append("0");
	
			}
			strBuff.append(id);
		} catch (Exception e){
			System.err.println("fillZeroes - Pax Number creation Error");
			e.printStackTrace();
		}
		return strBuff.toString();
	}
	
//	Added for CR1832- UAT changes ends

}
