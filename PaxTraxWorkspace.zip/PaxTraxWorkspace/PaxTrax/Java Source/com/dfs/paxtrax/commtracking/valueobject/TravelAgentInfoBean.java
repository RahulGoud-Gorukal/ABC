package com.dfs.paxtrax.commtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


 
/**
 * 
 * The Group value object used for creation of groups.
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 05/12/2004	P.C. Sathish	Created   
 */ 
public class TravelAgentInfoBean extends PaxTraxValueObject {
	private String taCode;
	private String taAgencyName;
	private String taDisplay;
	private ArrayList travelAgentBranchList;

	/**
	 * Returns the taAgencyName.
	 * @return String
	 */
	public String getTaAgencyName() {
		return taAgencyName;
	}

	/**
	 * Returns the taCode.
	 * @return String
	 */
	public String getTaCode() {
		return taCode;
	}

	/**
	 * Returns the travelAgentBranchList.
	 * @return ArrayList
	 */
	public ArrayList getTravelAgentBranchList() {
		return travelAgentBranchList;
	}

	/**
	 * Sets the taAgencyName.
	 * @param taAgencyName The taAgencyName to set
	 */
	public void setTaAgencyName(String taAgencyName) {
		this.taAgencyName = taAgencyName;
	}

	/**
	 * Sets the taCode.
	 * @param taCode The taCode to set
	 */
	public void setTaCode(String taCode) {
		this.taCode = taCode;
	}

	/**
	 * Sets the travelAgentBranchList.
	 * @param travelAgentBranchList The travelAgentBranchList to set
	 */
	public void setTravelAgentBranchList(ArrayList travelAgentBranchList) {
		this.travelAgentBranchList = travelAgentBranchList;
	}

	/**
	 * Returns the taDisplay.
	 * @return String
	 */
	public String getTaDisplay() {
		return taDisplay;
	}

	/**
	 * Sets the taDisplay.
	 * @param taDisplay The taDisplay to set
	 */
	public void setTaDisplay(String taDisplay) {
		this.taDisplay = taDisplay;
	}

}
