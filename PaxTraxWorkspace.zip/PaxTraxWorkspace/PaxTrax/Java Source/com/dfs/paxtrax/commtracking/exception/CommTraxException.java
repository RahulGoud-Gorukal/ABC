package com.dfs.paxtrax.commtracking.exception;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.exception.PaxTraxException;


/**
 * 
 * The Exception class used during exceptions in CommTrax related operations
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/11/2004	Yuvarani			Created   
 */


public class CommTraxException extends PaxTraxException
{
	/**
	 * @see com.dfs.paxtrax.common.exception.PaxTraxException#PaxTraxException(int)
	 */
	/** The constructor for the PAX Exception class with errorCode as parameter  */
	public CommTraxException(int errorCode)
	{
		super(errorCode);
	}

}
