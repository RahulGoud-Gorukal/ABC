package com.dfs.paxtrax.commtracking.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import javax.ejb.CreateException;
import java.rmi.RemoteException;


/**
 * 
 * EJB Home interface for CommTraxBOBean
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/11/2004	Yuvarani			Created   
 */


public interface CommTraxBOHome extends javax.ejb.EJBHome
{
    
	/**
	 * Method create.
	 * 
	 * @return CommTraxBO
	 * @throws CreateException
	 * @throws RemoteException
	 * 
	 */
    public CommTraxBO create() throws CreateException, RemoteException;
}
