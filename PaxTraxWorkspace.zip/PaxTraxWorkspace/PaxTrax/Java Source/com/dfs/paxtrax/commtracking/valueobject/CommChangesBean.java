package com.dfs.paxtrax.commtracking.valueobject;

/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList; 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
** @author Cognizant Technology Solutions
* 
* * @version    1.0
* * MOD HISTORY
* DATE          USER            COMMENTS
* 21/09/2010    Viji		 	Created   
*/

public class CommChangesBean extends PaxTraxValueObject {

	private String seqId = null;
	
	private String taCode = null;
	
	private String purchaseRefID = null;

	private String visitType = null;
	
	private String Old_Commission = null;
	
	private String New_Commission = null;

	private String modifiedUser = null;

	private String modifiedDate = null;

	/**
	 * Default Constructor for CommChangesBean
	 */
	public CommChangesBean()
	{
	}


	/**
	 * @return
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @return
	 */
	public String getModifiedUser() {
		return modifiedUser;
	}

	/**
	 * @return
	 */
	public String getNew_Commission() {
		return New_Commission;
	}

	/**
	 * @return
	 */
	public String getOld_Commission() {
		return Old_Commission;
	}

	/**
	 * @return
	 */
	public String getPurchaseRefID() {
		return purchaseRefID;
	}

	/**
	 * @return
	 */
	public String getSeqId() {
		return seqId;
	}

	/**
	 * @return
	 */
	public String getTaCode() {
		return taCode;
	}

	/**
	 * @return
	 */
	public String getVisitType() {
		return visitType;
	}

	/**
	 * @param string
	 */
	public void setModifiedDate(String string) {
		modifiedDate = string;
	}

	/**
	 * @param string
	 */
	public void setModifiedUser(String string) {
		modifiedUser = string;
	}

	/**
	 * @param string
	 */
	public void setNew_Commission(String string) {
		New_Commission = string;
	}

	/**
	 * @param string
	 */
	public void setOld_Commission(String string) {
		Old_Commission = string;
	}

	/**
	 * @param string
	 */
	public void setPurchaseRefID(String string) {
		purchaseRefID = string;
	}

	/**
	 * @param string
	 */
	public void setSeqId(String string) {
		seqId = string;
	}

	/**
	 * @param string
	 */
	public void setTaCode(String string) {
		taCode = string;
	}

	/**
	 * @param string
	 */
	public void setVisitType(String string) {
		visitType = string;
	}

}