package com.dfs.paxtrax.commtracking.service;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.commtracking.business.CommTraxBO;
import com.dfs.paxtrax.commtracking.business.CommTraxBOHome;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.valueobject.BranchBean;
import com.dfs.paxtrax.commtracking.valueobject.CommBean;
import com.dfs.paxtrax.commtracking.valueobject.GroupBean;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.commtracking.exception.SegmentException;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 *
 * The Delagate that will route requests to the EJB tier of Commtrax
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/11/2004	Yuvarani			Created
 * 5/08/2005    Vani.J 				TA Commission changes
 */

public class CommTraxDelegate
{

	public CommTraxDelegate()
	{
	}

	/**
	 * Method saveVisitPAXDetails.
	 *
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * @throws PaxTraxSystemException
	 * @throws PAXException
	 * Method to save a PAX record
	 */
	public PAXBean saveVisitPAXDetails(PAXBean paxBean)
		throws PaxTraxSystemException, CommTraxException
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::CommTraxDelegate::saveVisitPAXDetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(
					obj,
					CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			paxBean = remote.saveVisitPAXDetails(paxBean);

			PaxTraxLog.logDebug(
				"PaxTrax::CommTraxDelegate::saveVisitPAXDetails::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::saveVisitPAXDetails",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::saveVisitPAXDetails",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::saveVisitPAXDetails",
				ce);
			throw new PaxTraxSystemException(ce);
		}

		return (paxBean);
	}

	public void updateCondVist(ArrayList paxList,PAXBean paxBean)
		throws PaxTraxSystemException, CommTraxException
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::CommTraxDelegate::updateCondVist::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(
					obj,
					CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			remote.updateCondVist(paxList,paxBean);

			PaxTraxLog.logDebug(
				"PaxTrax::CommTraxDelegate::updateCondVist::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::updateCondVist",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::updateCondVist",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::updateCondVist",
				ce);
			throw new PaxTraxSystemException(ce);
		}

	}

	/**
	 * Searches Group.
	 * @param visitBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchGroup(VisitBean visitBean)
		throws PaxTraxSystemException
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::CommTraxDelegate::searchGroup::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(
					obj,
					CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			ArrayList groupList = remote.searchGroup(visitBean);

			PaxTraxLog.logDebug(
				"PaxTrax::CommTraxDelegate::updateCondVist::End");
			return groupList;
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::searchGroup",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::searchGroup",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::searchGroup",
				ce);
			throw new PaxTraxSystemException(ce);
		}
	}

	/**
	 * Add Group.
	 * @param groupBean
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	public void addGroup(GroupBean groupBean)
		throws PaxTraxSystemException, CommTraxException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::addGroup::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(
					obj,
					CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			remote.addGroup(groupBean);

			PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::addGroup::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::addGroup",ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::addGroup",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::addGroup",ce);
			throw new PaxTraxSystemException(ce);
		}

	}


	//Methods added for Travel AGent and Travel Agent Branch Creation


	public boolean createTADetails(CommBean commBean)
		throws PaxTraxSystemException, CommTraxException
	{
		PaxTraxLog.logDebug("CommTrax::COMMDelegate::createTADetails::Begin");
		boolean returnValue = false;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			returnValue = remote.createTADetails(commBean);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommTraxDelegate::createTADetails",ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommTraxDelegate::createTADetails",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommTraxDelegate::createTADetails",ce);
			throw new PaxTraxSystemException(ce);
		}

		return returnValue;
	}

	/*public ArrayList getTADetails(String taCode)
	{
		ArrayList taDetails = new ArrayList();

		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getTADetails::TA-Code :-->"+taCode);

		try
		{
			PaxTraxLog.logDebug("PaxTrax::COMMDelegate::createTADetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			taDetails = remote.getTADetails(taCode);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("Exception PaxTrax::COMMDelegate::getTADetails::Exception",ex);
			ex.printStackTrace();
		}
		return taDetails;
	}*/

	public void removeVisitDetails(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            remote.removeVisitDetails(visitBean);
        }
        catch (RemoteException re)
        {
			throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");
	}

	public void removePaxDetail(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            remote.removePaxDetail(visitBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");
	}

	public ArrayList searchVisitDetails(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;
		ArrayList arlVisitDetails = null;
       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            arlVisitDetails = remote.searchVisitDetails(visitBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");

		return arlVisitDetails;
	}

	public ArrayList getVisitPaxDetails(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;
		ArrayList arlVisitPaxDetails = null;
       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            arlVisitPaxDetails = remote.getVisitPaxDetails(visitBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");
		return arlVisitPaxDetails;
	}

	public ArrayList getTADetails(String taCode, String agencyName, String agencyOwner)
		throws PaxTraxSystemException
	{
		ArrayList taDetails = new ArrayList();

		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getTADetails::TA-Code :-->"+taCode);

		try
		{
			PaxTraxLog.logDebug("PaxTrax::COMMDelegate::createTADetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			taDetails = remote.getTADetails(taCode, agencyName, agencyOwner);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("Exception PaxTrax::COMMDelegate::getTADetails::Exception",ex);
			throw new PaxTraxSystemException(ex);
		}
		return taDetails;
	}

	public boolean updateTADetails(CommBean commBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::updateTADetails::TA-Code :-->"+commBean.getTaCode());
		boolean returnValue = false;
		try
		{
			PaxTraxLog.logDebug("PaxTrax::COMMDelegate::updateTADetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			returnValue = remote.updateTADetails(commBean);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("Exception PaxTrax::COMMDelegate::updateTADetails::Exception",ex);
			throw new PaxTraxSystemException(ex);
		}
		return returnValue;
	}

	//public boolean deleteTADetails(CommBean commBean)
	public String deleteTADetails(CommBean commBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::deleteTADetails::TA-Code :-->"+commBean.getTaCode());
		String returnValue = "failure";
		try
		{
			PaxTraxLog.logDebug("PaxTrax::COMMDelegate::deleteTADetails::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			returnValue = remote.deleteTADetails(commBean);
		}catch(Exception ex)
		{
			PaxTraxLog.logDebug("PaxTrax::COMMDelegate::deleteTADetails::Exception");
			throw new PaxTraxSystemException(ex);
		}
		return returnValue;
	}

	public ArrayList loadTANames()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::loadTANames::Begin");
		ArrayList taNames = null;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/bu//siness/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			taNames = remote.loadTANames();
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::deleteTADetails::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		return taNames;
	}


	public boolean createBranchDetails(BranchBean branchBean)
		throws PaxTraxSystemException, CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::saveBranchDetails::Begin");
		boolean insertStatus = false;

		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			insertStatus = remote.createBranchDetails(branchBean);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommTraxDelegate::createBranchDetails",ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommTraxDelegate::createBranchDetails",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommTraxDelegate::createBranchDetails",ce);
			throw new PaxTraxSystemException(ce);
		}

		return insertStatus;
	}

	public ArrayList getBranchDetails(BranchBean branchBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::saveBranchDetails::Begin");
		ArrayList branchDetails = null;

		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			branchDetails = remote.getBranchDetails(branchBean);
		}
		catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::getBranchDetails::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		return branchDetails;
	}


	public ArrayList getBranch(String taCode, String branchCode)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getBranch::Begin");
		ArrayList branchDetails = null;

		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			branchDetails = remote.getBranch(taCode, branchCode);
		}
		catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::getBranch::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		return branchDetails;
	}

	public boolean saveBranchDetails(BranchBean branchBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::saveBranch::BEGIN");
		boolean saveStatus = false;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			saveStatus = remote.saveBranchDetails(branchBean);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::saveBranchDetails::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		return saveStatus;
	}

	public boolean deleteBranch(BranchBean branchBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::deleteBranch::BEGIN");
		boolean deleteStatus = false;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			//Object obj = locator.getEJBHome("ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome");
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			deleteStatus = remote.deleteBranch(branchBean);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::deleteBranch::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		return deleteStatus;
	}

	//Methods for FTP Activity starts here

	public void createDataFiles() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::createDataFiles::BEGIN");
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			remote.createDataFiles();
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::createDataFiles::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}

	}
	//Method for FTP Activity ends here

	//Methods added for Travel Agent and Travel Agent Branch Creation
	//Methods added for VISIT and TACOMMISSION

	public String saveVisitDetails(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;
		String strVisitCode = null;

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            strVisitCode = remote.saveVisitDetails(visitBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");

        return strVisitCode;
	}

	public void updateVisitDetails(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            remote.updateVisitDetails(visitBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");
	}

	public String getSeqVisitCode() throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::getSeqVisitCode::Begin");
		CommTraxBO remote = null;
		String strSeqVstCode = null;

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            strSeqVstCode = remote.getSeqVisitCode();
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");

		return strSeqVstCode;
	}

	public ArrayList loadTaName() throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;
        ArrayList arlTaName = new ArrayList();

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
          arlTaName = remote.loadTaName();
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");

            return arlTaName;

	}

	public ArrayList loadTaBranchName(String taCode) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;
        ArrayList arlTaBranchName = new ArrayList();
       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            arlTaBranchName = remote.loadTaBranchName(taCode);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");
		return arlTaBranchName;
	}

	public ArrayList getTADetails(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
		CommTraxBO remote = null;
		ArrayList taDetails = new ArrayList();

       //Code addition starts here
            try
            {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			remote = home.create();
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }
            //Code addition ends here
        try
        {
            taDetails = remote.getTADetails(visitBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::VisitDelegate::saveVisitDetails::End");

		return taDetails;
	}
/* Commented by Vani on 06/08/2005
 * This change was done to dynamically populate the
 * leased vendors of a TA and to add RAC classification based commission */


//	public ArrayList getCodeRef() throws PaxTraxSystemException,CommTraxException
//	{
//
//        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
//		CommTraxBO remote = null;
//		ArrayList arlCodeRef = new ArrayList();
//
//       //Code addition starts here
//            try
//            {
//			ServiceLocator locator = ServiceLocator.getInstance();
//			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
//			CommTraxBOHome home =
//				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
//			remote = home.create();
//            }catch(Exception exp)
//            {
//				throw new PaxTraxSystemException(exp);
//            }
//            //Code addition ends here
//        try
//        {
//           arlCodeRef = remote.getCodeRef();
//        }
//        catch (RemoteException re)
//        {
//            throw new PaxTraxSystemException(re);
//        }
//        PaxTraxLog.logDebug(
//            "PaxTrax::VisitDelegate::saveVisitDetails::End");
//
//		return arlCodeRef;
//	}
//	public void insertMaintainTaCommission(VisitBean visitBean) throws PaxTraxSystemException,CommTraxException
//	{
//
//        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
//		CommTraxBO remote = null;
//
//       //Code addition starts here
//            try
//            {
//			ServiceLocator locator = ServiceLocator.getInstance();
//			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
//			CommTraxBOHome home =
//				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
//			remote = home.create();
//            }catch(Exception exp)
//            {
//				throw new PaxTraxSystemException(exp);
//            }
//            //Code addition ends here
//        try
//        {
//            remote.insertMaintainTaCommission(visitBean);
//        }
//        catch (RemoteException re)
//        {
//            throw new PaxTraxSystemException(re);
//        }
//        PaxTraxLog.logDebug(
//            "PaxTrax::VisitDelegate::saveVisitDetails::End");
//	}



//	public VisitBean getMaintainTaCommission(String taCode) throws PaxTraxSystemException,CommTraxException
//	{
//
//        PaxTraxLog.logDebug("PaxTrax::VisitDelegate::saveVisitDetails::Begin");
//		CommTraxBO remote = null;
//		VisitBean visitBean = null;
//       //Code addition starts here
//            try
//            {
//			ServiceLocator locator = ServiceLocator.getInstance();
//			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
//			CommTraxBOHome home =
//				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
//			remote = home.create();
//            }catch(Exception exp)
//            {
//				throw new PaxTraxSystemException(exp);
//            }
//            //Code addition ends here
//        try
//        {
//            visitBean = remote.getMaintainTaCommission(taCode);
//        }
//        catch (RemoteException re)
//        {
//            throw new PaxTraxSystemException(re);
//        }
//        PaxTraxLog.logDebug(
//            "PaxTrax::VisitDelegate::saveVisitDetails::End");
//
//		return visitBean;
//	}


/* Added by Vani on 06/08/2005
		 * This change was done to dynamically populate the
		 * leased vendors of a TA and to add RAC classification based commission */

//Code addition starts here

/**
 * To insert/update TaCommissions.
 * @param TACommissions
 * @param vBean
 * @throws PaxTraxSystemException
 * @throws CommTraxException
 */

	public void insertTaCommissions(ArrayList TACommissions,VisitBean vBean)
		throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::CommDelegate::insertTaCommissions::Begin");
		CommTraxBO remote = null;


            try
            {
				ServiceLocator locator = ServiceLocator.getInstance();
				Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
				CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
				remote = home.create();
				
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }

        try
        {

            remote.insertTaCommissions(TACommissions,vBean);

        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug("PaxTrax::COmmDelegate::insertTaCommissions::End");
	}

	/**
	 * To get TaCommissions.
	 * @param taCode
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */


public ArrayList getTaCommissions(String taCode)
	throws PaxTraxSystemException,CommTraxException
	{

        PaxTraxLog.logDebug("PaxTrax::CommDelegate::getTaCommissions::Begin");
		CommTraxBO remote = null;
		ArrayList taCommissions = null;

            try
            {
				ServiceLocator locator = ServiceLocator.getInstance();
				Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
				CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
				remote = home.create();
				
            }catch(Exception exp)
            {
				throw new PaxTraxSystemException(exp);
            }

        try
        {
            taCommissions = remote.getTaCommissions(taCode);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::CommDelegate::getTaCommissions::End");

		return (taCommissions);
	}

//Code addition ends here

	/**
	 * Searches StartVisitDetails.
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	public ArrayList searchStartVisitDetails(VisitBean visitBean)
		throws PaxTraxSystemException
	{

        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::searchStartVisitDetails"
        	+"::Begin");
		CommTraxBO remote = null;
		ArrayList arlVisitDetails = null;

        try
        {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(
				PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home = (CommTraxBOHome) PortableRemoteObject.
				narrow(obj, CommTraxBOHome.class);
			remote = home.create();
	        arlVisitDetails = remote.searchStartVisitDetails(visitBean);
        }
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::searchStartVisitDetails",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::searchStartVisitDetails",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::searchStartVisitDetails",
				ce);
			throw new PaxTraxSystemException(ce);
		}
        PaxTraxLog.logDebug(
            "PaxTrax::CommTraxDelegate::searchStartVisitDetails::End");

		return arlVisitDetails;
	}

	/**
	 * Starts the visit by providing actual date and time.
	 * @param visitBean
	 * @throws PaxTraxSystemException
	 */
	public void updateStartVisit(VisitBean visitBean)
		throws PaxTraxSystemException,CommTraxException
	{
        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::updateStartVisit::Begin");
		CommTraxBO remote = null;

        try
        {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(
				PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home = (CommTraxBOHome) PortableRemoteObject.
				narrow(obj, CommTraxBOHome.class);
			remote = home.create();
	        remote.updateStartVisit(visitBean);
        }
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::updateStartVisit",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::updateStartVisit",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::updateStartVisit",
				ce);
			throw new PaxTraxSystemException(ce);
		}
        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::updateStartVisit::End");
	}

	/**
	 * Method checkPax.
	 * @param paxList
	 * @param string
	 * @return ArrayList
	 */
	public ArrayList checkPax(ArrayList paxList, String visitCode)
		throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::checkPax::Begin");
		CommTraxBO remote = null;
		ArrayList allPaxList = null;
        try
        {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(
				PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home = (CommTraxBOHome) PortableRemoteObject.
				narrow(obj, CommTraxBOHome.class);
			remote = home.create();
	        allPaxList = remote.checkPax(paxList,visitCode);
        }
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::checkPax",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::checkPax",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::checkPax",
				ce);
			throw new PaxTraxSystemException(ce);
		}
        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::checkPax::End");
		return allPaxList;
	}

	/**
	 * Method getStartVisitTimeDifference.
	 * @return int
	 */
	public int getStartVisitTimeDifference() throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::getStartVisitTimeDifference::Begin");
		CommTraxBO remote = null;
		int timeDifference = 0;
        try
        {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(
				PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home = (CommTraxBOHome) PortableRemoteObject.
				narrow(obj, CommTraxBOHome.class);
			remote = home.create();
	        timeDifference = remote.getStartVisitTimeDifference();
        }
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::getStartVisitTimeDifference",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::getStartVisitTimeDifference",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::getStartVisitTimeDifference",
				ce);
			throw new PaxTraxSystemException(ce);
		}
        PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::getStartVisitTimeDifference::End");
		return timeDifference;
	}

	/**
	 * Method maintainGroup.
	 * @param groupBean
	 */
	public void maintainGroup(GroupBean groupBean)
		throws PaxTraxSystemException, CommTraxException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::maintainGroup::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(
					obj,
					CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			remote.maintainGroup(groupBean);

			PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::maintainGroup::End");
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::maintainGroup",ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::maintainGroup",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::CommTraxDelegate::maintainGroup",ce);
			throw new PaxTraxSystemException(ce);
		}

	}

		/**
		 * Method deleteGroup.
		 * @param groupBean
		 */
		public void deleteGroup(GroupBean groupBean) throws PaxTraxSystemException
		{
			try
			{
				PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::deleteGroup::Begin");
				ServiceLocator locator = ServiceLocator.getInstance();
				Object obj =
					locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
				CommTraxBOHome home =
					(CommTraxBOHome) PortableRemoteObject.narrow(
						obj,
						CommTraxBOHome.class);
				CommTraxBO remote = home.create();
				remote.deleteGroup(groupBean);

				PaxTraxLog.logDebug("PaxTrax::CommTraxDelegate::deleteGroup::End");
			}
			catch (NamingException ne)
			{
				PaxTraxLog.logError(
					"Exception in PaxTrax::CommTraxDelegate::deleteGroup",ne);
				throw new PaxTraxSystemException(ne);
			}
			catch (RemoteException re)
			{
				PaxTraxLog.logError(
					"Exception in PaxTrax::CommTraxDelegate::deleteGroup",re);
				throw new PaxTraxSystemException(re);
			}
			catch (CreateException ce)
			{
				PaxTraxLog.logError(
					"Exception in PaxTrax::CommTraxDelegate::deleteGroup",ce);
				throw new PaxTraxSystemException(ce);
			}
		}

		/**
		 * Method createSegment : To create a new segment for a TA
		 * @param commBean
		 * @return boolean
		 * @throws PaxTraxSystemException
		 */
		public boolean createSegment(CommBean commBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("CommTrax::COMMDelegate::createSegment::Begin");
		boolean returnValue = false;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			returnValue = remote.createSegment(commBean);
		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::createSegment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::createSegment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::createSegment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("CommTrax::COMMDelegate::createSegment::End");
		return returnValue;
	}

	/**
	 * Searches segment details given a tacode, segment code, segment name.
	 * @param commBean bean containing segment details
	 * @return ArrayList list of segment detail beans
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchSegment(CommBean commBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("CommTrax::CommDelegate::createSegmentDetails::Begin");
		ArrayList segmentList = null;
		try {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			segmentList = remote.searchSegment(commBean);

		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::searchSegment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::searchSegment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::searchSegment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("CommTrax::CommDelegate::createSegmentDetails::End");
		return segmentList;
	}

	public CommBean getSegment(CommBean commBean) throws PaxTraxSystemException {
		PaxTraxLog.logDebug("CommTrax::CommDelegate::getSegment::Begin");
		CommBean segmentBean = null;
		try {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			segmentBean = remote.getSegment(commBean);

		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::getSegment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::getSegment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::getSegment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("CommTrax::CommDelegate::getSegment::End");
		return segmentBean;
	}

	public boolean updateSegment(CommBean updateBean)
	throws CommTraxException, PaxTraxSystemException {
		PaxTraxLog.logDebug("CommTrax::CommDelegate::updateSegment::Begin");
		boolean updateStatus = false;
		try {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			updateStatus = remote.updateSegment(updateBean);

		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::updateSegment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::updateSegment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::updateSegment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("CommTrax::CommDelegate::updateSegment::End");
		return updateStatus;
	}

	public boolean deleteSegment(CommBean segmentBean)
		throws SegmentException,PaxTraxSystemException {
		PaxTraxLog.logDebug("CommTrax::CommDelegate::deleteSegment::Begin");
		boolean updateStatus = false;
		try {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			updateStatus = remote.deleteSegment(segmentBean);

		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::deleteSegment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::deleteSegment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::CommTraxDelegate::deleteSegment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("CommTrax::CommDelegate::deleteSegment::End");
		return updateStatus;
	}

	public ArrayList loadSegmentCodes(String taCode)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::loadSegmentCodes::Begin");
		ArrayList segmentCodes = null;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();

			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			segmentCodes = remote.loadSegmentCodes(taCode);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::loadSegmentCodes::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::loadSegmentCodes::End");

		return segmentCodes;
	}
	
//	Added for CR1832 starts
	public ArrayList getTACommChanges()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getTACommChanges::Begin");
		ArrayList taCommChanges = null;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();

			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			taCommChanges = remote.getTACommChanges();
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::getTACommChanges::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getTACommChanges::End");

		return taCommChanges;
	}
//	Added for CR1832 ends
	
//	Added for CR1832 starts
	public ArrayList getVisitChanges(String VisitFlag)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getVisitChanges::Begin");
		ArrayList VisitChanges = null;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();

			Object obj = locator.getEJBHome(PaxTraxConstants.COMMTRAX_BO_HOME_JNDI);
			CommTraxBOHome home =
				(CommTraxBOHome) PortableRemoteObject.narrow(obj, CommTraxBOHome.class);
			CommTraxBO remote = home.create();
			VisitChanges = remote.getVisitChanges(VisitFlag);
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::COMMDelegate::getVisitChanges::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		PaxTraxLog.logDebug("PaxTrax::COMMDelegate::getVisitChanges::End");

		return VisitChanges;
	}
//	Added for CR1832 ends
}
