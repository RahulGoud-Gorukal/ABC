package com.dfs.paxtrax.commtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;
import com.dfs.paxtrax.common.actionform.CommTraxActionForm;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;

/**
 * This is action form which contains Cage attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/05/2004   Joseph Oommen A     Created   
*/

public class VisitForm extends CommTraxActionForm {
    /**
       This attribute holds all the details of a cage
     */
    private VisitBean visitBean = null;

	//This is for start visit page
	private VisitBean startVisitBean = null;
	
	/** The List of all country values */
	private ArrayList arlTaNames = null;
	
	/** The List of all Nationality values */
	private ArrayList arlTaBranchNames = null;

	private ArrayList arlExpVstTimes = null;

	private ArrayList arlActVstTimes = null;

	private ArrayList arlCodeRef = null;
	
	private ArrayList taCollection = null;

	private ArrayList arlVisitPaxDetails = null;
	
	public ArrayList getArlVisitPaxDetails()
	{
		return arlVisitPaxDetails;
	}

	public void setArlVisitPaxDetails(ArrayList arlVisitPaxDetails)
	{
		this.arlVisitPaxDetails = arlVisitPaxDetails;
	}

	public ArrayList getArlExpVstTimes()
	{
		return arlExpVstTimes;
	}

	public void setArlExpVstTimes(ArrayList arlExpVstTimes)
	{
		this.arlExpVstTimes = arlExpVstTimes;
	}

	public ArrayList getArlActVstTimes()
	{
		return arlActVstTimes;
	}

	public void setArlActVstTimes(ArrayList arlActVstTimes)
	{
		this.arlActVstTimes = arlActVstTimes;
	}

	
	/**
	 * Returns the visitBean.
	 * @return VisitBean
	 */
	public VisitBean getVisitBean()
	{
		return visitBean;
	}

	/**
	 * Sets the visitBean.
	 * @param visitBean The visitBean to set
	 */
	public void setVisitBean(VisitBean visitBean)
	{
		this.visitBean = visitBean;
	}

	/**
	 * Returns the arlTaName.
	 * @return ArrayList
	 */
	public ArrayList getArlTaNames()
	{
		return arlTaNames;
	}

	/**
	 * Returns the arlTaBranchName.
	 * @return ArrayList
	 */
	public ArrayList getArlTaBranchNames()
	{
		return arlTaBranchNames;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setArlTaNames(ArrayList arlTaNames)
	{
		this.arlTaNames = arlTaNames;
	}

	/**
	 * Sets the countryList.
	 * @param countryList The countryList to set
	 */
	public void setArlTaBranchNames(ArrayList arlTaBranchNames)
	{
		this.arlTaBranchNames = arlTaBranchNames;
	}

	public ArrayList getTaCollection()
	{
		return taCollection;
	}
	
	public void setTaCollection(ArrayList taCollection)
	{
		this.taCollection = taCollection;
	}

	public ArrayList getArlCodeRef()
	{
		return arlCodeRef;
	}
	
	public void setArlCodeRef(ArrayList arlCodeRef)
	{
		this.arlCodeRef = arlCodeRef;
	}

	/*End TA Commision*/


	/**
	 * Returns the startVisitBean.
	 * @return VisitBean
	 */
	public VisitBean getStartVisitBean()
	{
		return startVisitBean;
	}

	/**
	 * Sets the startVisitBean.
	 * @param startVisitBean The startVisitBean to set
	 */
	public void setStartVisitBean(VisitBean startVisitBean)
	{
		this.startVisitBean = startVisitBean;
	}

	

}