package com.dfs.paxtrax.commtracking.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.action.CommTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.CommForm;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.CommBean;
import com.dfs.paxtrax.commtracking.exception.SegmentException;

/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CommAction extends CommTraxAction{


	public ActionForward createTravelAgent(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response)
	{


			PaxTraxLog.logDebug("CommTrax::COMMAction::createTravelAgent::Begin");
			CommForm commTraxForm = (CommForm) form;

			CommBean commBean = new CommBean();
			commTraxForm.setCommBean(commBean);


			return mapping.findForward("createTravelAgent");
	}


	/**
	 * ConfirmAction for Create TA
	 */
	public ActionForward confirmTravelAgent(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
			PaxTraxLog.logDebug("CommTrax::COMMAction::confirmTravelAgent::Begin");
			CommForm commTraxForm = (CommForm) form;

			CommBean commBean = commTraxForm.getCommBean();
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");

			String fromConfirmation = request.getParameter("fromConfirmPage");
			if (fromConfirmation != null)
			{
				if (fromConfirmation.equalsIgnoreCase("Yes"))
				{
					try
					{
						CommTraxDelegate comDelegate = new CommTraxDelegate();
						boolean createStatus = comDelegate.createTADetails(commBean);
					}
					catch(CommTraxException cex)
					{
						PaxTraxLog.logDebug("CommTrax::COMMAction::confirmTravelAgent::"+cex.getMessage());
 						request.setAttribute(PaxTraxConstants.ERRORCODE,"Yes");
						return mapping.findForward("createTravelAgent");
					}
					
					catch(PaxTraxSystemException sqlExp)
					{
						PaxTraxLog.logDebug("CommTrax::COMMAction::confirmTravelAgent",sqlExp);
						return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
					}

 					request.setAttribute("TAFormValues",commBean);
					commTraxForm.setCommBean(commBean);
					
					return mapping.findForward("confirmTravelAgent");
				}
			}

			String mode = request.getParameter("mode");
			if (mode.equalsIgnoreCase("Modify"))
			{
				CommTraxDelegate commDelegate = new CommTraxDelegate();
				boolean returnValue = commDelegate.updateTADetails(commBean);
				request.setAttribute("KeyExist","Yes");
				request.setAttribute("TACode", commBean.getTaCode());
				request.setAttribute("TAFormValues",commBean);
				commTraxForm.setCommBean(commBean);
				return mapping.findForward("confirmModifyAgent");
			}

			return mapping.findForward("confirmTravelAgent");
	}


	public ActionForward modifyTravelAgent(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	{

			PaxTraxLog.logDebug("CommTrax::COMMAction::modifyTravelAgent::Begin");
			String pageNumber = (String)request.getParameter("pageNumber");
			CommForm commTraxForm = (CommForm) form;

			CommBean commBean = new CommBean();
			String taCode = request.getParameter("taCode");
			String agencyName = request.getParameter("agencyName");
			String agencyOwner = request.getParameter("agencyOwner");

			commBean.setTaCode(taCode);
			commBean.setAgencyName(agencyName);
			commBean.setAgencyOwner(agencyOwner);
			commTraxForm.setCommBean(commBean);
			request.setAttribute("TAValues",commBean);
			
			
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			
			return mapping.findForward("modifyTravelAgent");
	}

	public ActionForward deleteTravelAgent(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
			PaxTraxLog.logDebug("CommTrax::COMMAction::modifyTravelAgent::Begin");
			CommForm commTraxForm = (CommForm) form;

			CommBean commBean = commTraxForm.getCommBean();
			CommTraxDelegate commDelegate = new CommTraxDelegate();
			String returnValue = commDelegate.deleteTADetails(commBean);
			request.setAttribute("KeyExist","Yes");
			request.setAttribute("TACode", commBean.getTaCode());
			request.setAttribute("TAFormValues",commBean);
			commTraxForm.setCommBean(commBean);
			request.setAttribute("Result", returnValue);
			return mapping.findForward("deleteTravelAgent");
	}



	public ActionForward agentMaster(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("CommTrax::COMMAction::agentMaster::Begin");
		CommTraxDelegate commDelegate = new CommTraxDelegate();
		String dataFileType = (String)request.getParameter("fileType");
		commDelegate.createDataFiles();
		return mapping.findForward("agentMaster");
	}


	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		{
		String forward = null;
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String fromMenu = request.getParameter("fromMenu");
		if (fromMenu != null) {
			request.setAttribute("fromMenu","Yes");
		}
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if(page.equals(PaxTraxConstants.SYSTEM_ERROR))
		{
			forward=PaxTraxConstants.SYSTEM_ERROR;
		}
		else
		{
			forward = page;
		}
		
		String errorCode = request.getParameter("errc");
		if (errorCode != null && !errorCode.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE,errorCode);
		}
		String pageNumber = (String)request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		PaxTraxLog.logDebug("PaxTrax success-->"+ (String) request.getAttribute(PaxTraxConstants.RESULT));
		return mapping.findForward(forward);

	}
	

/**
 * Creates a new segment for a TA
 * @param mapping
 * @param form
 * @param request
 * @param response
 * @return ActionForward
 * @throws PaxTraxSystemException
 */
public ActionForward createSegment(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response)
	throws PaxTraxSystemException
	{

			
			PaxTraxLog.logDebug("CommTrax::COMMAction::createSegment::Begin");
			
			CommForm commForm = (CommForm) form;

			CommBean commBean = new CommBean();
			commForm.setCommBean(commBean);

			ArrayList taCodes = new ArrayList();
			commForm.setCommBean(commBean);
			CommTraxDelegate commDelegate = new CommTraxDelegate();
			taCodes = commDelegate.loadTANames();

			commForm.setTaCodes(taCodes);
			
			PaxTraxLog.logDebug("CommTrax::COMMAction::createSegment::End");
			return mapping.findForward("createSegment");

			
			
	}	
	
	/**
	 * Creates a new segment for a TA
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward createSegmentConfirm(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
		{

			PaxTraxLog.logDebug("CommTrax::COMMAction::confirmSegment::Begin");
			CommForm commForm = (CommForm) form;
			CommTraxDelegate commDelegate = new CommTraxDelegate();
			CommBean commBean = null;
			try
			{
				commBean = commForm.getCommBean();
				commBean.setSegmentCode(commBean.getSegmentCode().toUpperCase());
				HttpSession session = request.getSession();
				String userId=(String)session.getAttribute(PaxTraxConstants.USER);
				commBean.setUser(userId);
				boolean returnValue = commDelegate.createSegment(commBean);
				commForm.setCommBean(commBean);
				request.setAttribute("CommFormValues", commBean);
				PaxTraxLog.logDebug("CommTrax::COMMAction::confirmSegment::End");
				return mapping.findForward("createSegmentConfirm");
			}catch(PaxTraxSystemException sqlEx)
			{
				PaxTraxLog.logError("CommTrax::SegmentAction::createSegmentConfirm::SQLException", sqlEx);
				request.setAttribute(PaxTraxConstants.ERRORCODE,"Yes");
				return mapping.findForward("createSegment");
			}
	
	}
	
		
	/**
	 * Searches a segment based on tacode, segment code, segment name as search criteria.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward searchSegment(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException {
			PaxTraxLog.logDebug("CommTrax::CommAction::searchSegment::Begin");

			String fromMenu = (String)request.getParameter("fromMenu");
			String segmentModify = (String) request.getParameter("modify");
			CommForm commForm = (CommForm) form;
			CommTraxDelegate commDelegate = new CommTraxDelegate();
			ArrayList taCodes = commDelegate.loadTANames();
			commForm.setTaCodes(taCodes);

			//Clicked from Segment Search Screen - search button
			if (fromMenu == null) {
				
				CommBean commBean = null;
				
				if (segmentModify != null) {
					// Clicked from Segment modification screen - modify button
					commForm.setCommBean(commForm.getSearchBean());
					commBean = commForm.getCommBean();
					
				} else {
					//Clicked from Segment modification screen - cancel button
					commBean = commForm.getCommBean();
					commBean.setSegmentCode(commBean.getSegmentCode().toUpperCase());
					CommBean searchBean = new CommBean();
					searchBean.setTaCode(commBean.getTaCode());
					searchBean.setSegmentCode(commBean.getSegmentCode());
					searchBean.setSegmentName(commBean.getSegmentName());
					commForm.setSearchBean(searchBean);
				}
				
				/* 
				 * On selecting select("-1") for ta code from the segment search and clicking
				 * Segment search or modify, ta code should be made null
				 */
				if(commBean.getTaCode()!= null && commBean.getTaCode().equals("-1")) {
						commBean.setTaCode(null);
					}
	
				HttpSession session = request.getSession();
				int pageNumber = 0;
				ArrayList totalTARecords = null;
				ArrayList currentPageTARecords = null;

	
				String pageNumberStr =
					request.getParameter(PaxTraxConstants.PAGE_NUMBER);
	
				/* If page number is null or empty it sets null otherwise
				 * it is same
				 */
				pageNumberStr =
					((pageNumberStr == null)
						|| pageNumberStr.equals(SQLConstants.BLANK))
						? null
						: pageNumberStr;
	
				if ((pageNumberStr != null))
					pageNumber = Integer.parseInt(pageNumberStr);
	
				if (pageNumber == 0) {
					int size = 0;
					pageNumber = 1;
					
					
					totalTARecords = commDelegate.searchSegment(commBean);
					if(totalTARecords != null)
					{
						size = totalTARecords.size();
					}
					session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
					session.setAttribute(PaxTraxConstants.ALL_RECORDS, totalTARecords);
					session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
					session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
				}
				else
				{
					totalTARecords = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_RECORDS);
				}
	
				PaginationHelper helper = PaginationHelper.getInstance();
	
				if ((totalTARecords != null) && (totalTARecords.size() !=0))
				{
				    currentPageTARecords = helper.getCurrentTableContent(totalTARecords,
			    	pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
				}
	
				request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
				commForm.setSegmentList(currentPageTARecords);
			    request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			}
			else {//Clicked from Segment Search Menu - menu link
				/* 
				 * Whenever we click menu field we have to initialize the 
				 * commBean. This means we have to set ta code as "-1" in the
				 * commBean.
				 */ 
				CommBean commBean = new CommBean();
				commBean.setTaCode("-1");
				commForm.setCommBean(commBean);
				commForm.setSegmentList(null);
				return mapping.findForward("maintainSegment");
			}
			
			PaxTraxLog.logDebug("CommTrax::CommAction::searchSegment::End");
			return mapping.findForward("maintainSegment");
		}
				
	/**
	 * Method modifySegment.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward modifySegment(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException {
			PaxTraxLog.logDebug("CommTrax::CommAction::modifySegment::Begin");
			CommForm commTraxForm = (CommForm) form;
			CommBean segmentBean = new CommBean();
			String segmentCode = request.getParameter("segmentCode");
			String taCode = request.getParameter("taCode");
			segmentBean.setSegmentCode(segmentCode);
			segmentBean.setTaCode(taCode);
			CommTraxDelegate commDelegate = new CommTraxDelegate();
			CommBean resultBean = commDelegate.getSegment(segmentBean);
			if (resultBean == null) {
				throw new PaxTraxSystemException(PaxTraxErrorMessages.INVALID_SEGMENT_CODE);
			}
			commTraxForm.setCommBean(resultBean);
			PaxTraxLog.logDebug("CommTrax::CommAction::modifySegment::End");
			return mapping.findForward("modifySegment");
	}
	
	/**
	 * Updates a segment
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward updateSegment(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws SegmentException,PaxTraxSystemException {
			PaxTraxLog.logDebug("CommTrax::CommAction::modifySegment::Begin");
			CommForm commTraxForm = (CommForm) form;
			CommBean updateBean = commTraxForm.getCommBean();
			updateBean.setSegmentCode(updateBean.getSegmentCode().toUpperCase());
			
			PaxTraxLog.logDebug("CommTrax::CommAction::updateSegment::TA Code "+updateBean.getTaCode());
			PaxTraxLog.logDebug("CommTrax::CommAction::updateSegment::Segment Code "+updateBean.getSegmentCode());
			PaxTraxLog.logDebug("CommTrax::CommAction::updateSegment::Segment Name "+updateBean.getSegmentName());
			String segmentDelete = request.getParameter(PaxTraxConstants.DELETE);
			String segmentModify = request.getParameter(PaxTraxConstants.MODIFY);
			CommTraxDelegate commDelegate = new CommTraxDelegate();
			HttpSession session = request.getSession();
			String userId=(String)session.getAttribute(PaxTraxConstants.USER);
			updateBean.setUser(userId);
			// Delete the segment
			if (segmentDelete != null && segmentDelete.equals(PaxTraxConstants.TRUE)) {
				try {
					boolean delete = commDelegate.deleteSegment(updateBean);
					request.setAttribute(PaxTraxConstants.ACTIVE, PaxTraxConstants.DELETE);
					request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				} catch (SegmentException se) {
					
					request.setAttribute(PaxTraxConstants.ERROR,PaxTraxConstants.SEGMENT_USED_IN_BRANCH);
					PaxTraxLog.logError("CommTrax::CommAction::updateSegment:: SegmentinBranchError", se);
					
				}
			} else if (segmentModify != null && segmentModify.equals(PaxTraxConstants.TRUE)) {
				// Modify the segment
				try {
					commDelegate.updateSegment(updateBean);
					request.setAttribute(PaxTraxConstants.ACTIVE, PaxTraxConstants.UPDATE);
					request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				} catch (CommTraxException cte) {
					PaxTraxLog.logError("CommTrax::CommAction::updateSegment:: CommTraxError", cte);
				}
			}
			PaxTraxLog.logDebug("CommTrax::CommAction::modifySegment::End");
			return mapping.findForward("modifySegment");
	}

	
}

