package com.dfs.paxtrax.commtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.CommTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxConfigFileException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxConfig;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.VisitForm;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;

/* For Export tro excel option*/
//import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;


/**
* This action class is used for inserting and updating cage records
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Kumaresan.M
* ** @version    1.0
* Modified - Brijesh.D searchMaintainPageExcel,createCell
*
*/
public class VisitAction extends CommTraxAction
{

	String forward = null;

	/**
	* Saves the Visit Details in the database
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Visit Page
	*/
	public ActionForward saveVisitDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::VisitAction::saveVisitDetails::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = visitForm.getVisitBean();
		HttpSession session = request.getSession();
		ArrayList taCodeList = visitForm.getArlTaNames();
		ArrayList taBranchList = visitForm.getArlTaBranchNames();
		
		if (taCodeList != null)
		{
			for (int i = 0;i < taCodeList.size();i++)
			{
				ReferenceDataBean taCode = (ReferenceDataBean)taCodeList.get(i);
				if (taCode.getCodeId().equals(visitBean.getTaCode()))	
				{
					visitBean.setTaName(taCode.getCodeValue());
					break;
				}
			}
		}
		
		if (taBranchList != null)
		{
			for (int i = 0;i < taBranchList.size();i++)
			{
				ReferenceDataBean taBranch = (ReferenceDataBean)taBranchList.get(i);
				if (taBranch.getCodeId().equals(visitBean.getTaBranchCode()))	
				{
					visitBean.setTaBranchName(taBranch.getCodeValue());
					break;
				}
			}
		}

		visitBean.setCreatedUser((String) session.getAttribute(PaxTraxConstants.USER_ID));
		String expVisitTime = visitBean.getExpVisitTime();
		if(expVisitTime != null && expVisitTime.trim().length() != 0 
			&& !expVisitTime.equals("-1"))
		{
			visitBean.setExpVisitTime(changeAmPmTime(expVisitTime));
		}
		else
			visitBean.setExpVisitTime("");
		String actVisitTime = visitBean.getActVisitTime();
		if(actVisitTime != null && actVisitTime.trim().length() != 0 
			&& !actVisitTime.equals("-1"))
			visitBean.setActVisitTime(changeAmPmTime(actVisitTime));
					
		else
			visitBean.setActVisitTime("");
		visitBean.setCurrentStatus("R");
		
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		try
		{
			String strVisitCode = commTraxDelegate.saveVisitDetails(visitBean);
			String pageNumber	  = request.getParameter("pageNumber");
			visitBean.setVisitCode(strVisitCode);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			visitBean.setExpVisitTime(expVisitTime);
			visitBean.setActVisitTime(actVisitTime);
			if (request.getParameter("targetpage").equals("replicate")) {
				request.setAttribute("targetpage","replicate");
				visitBean.setActNoOfPax(null);
				visitBean.setActVisitDate(null);
				visitBean.setActVisitTime(null);
			} else {
				request.setAttribute("targetpage","create");
			}
			
			/*added for CR695 on 06-oct 2008 begin*/
			visitForm.setArlActVstTimes(getDetailTimeList());
			/*added for CR695  on 06-oct 2008 end*/
			
			visitForm.setArlVisitPaxDetails(null);
			visitForm.setVisitBean(visitBean);
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			forward = PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE;
		}
		catch (CommTraxException commTraxException)
		{
			PaxTraxLog.logError("CommTraxException caught saveVisitDetails-VisitAction",commTraxException);
			ActionMessages messages = new ActionMessages();
			messages.add(PaxTraxConstants.LOCATION_ERROR,new ActionMessage("" + commTraxException.getErrorCode()));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE,"" + commTraxException.getErrorCode());
			forward = PaxTraxConstants.CREATE_VISIT_PAGE;
		}
		PaxTraxLog.logDebug("PaxTrax::VisitAction::saveVisitDetails::End");
		return mapping.findForward(forward);
	}

	/**
	* Saves the Visit Details in the database
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Visit Page
	*/
	public ActionForward saveMaintainDetails(ActionMapping mapping,ActionForm form,HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::VisitAction::saveMaintainDetails::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = visitForm.getVisitBean();
		HttpSession session = request.getSession();
		visitBean.setModifiedUser((String) session.getAttribute(PaxTraxConstants.USER_ID));
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		String targetPage = (String)request.getParameter("targetpage");
		String pageNumber = (String)request.getParameter(
			PaxTraxConstants.PAGE_NUMBER);
		if(pageNumber != null && !pageNumber.equals("null"))
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);
		if(targetPage != null && !targetPage.equals("null"))
			request.setAttribute("targetpage",targetPage);
		try
		{
			//Addded on 2006-12-29
			visitBean.setExpVisitTime(changeAmPmTime(visitBean.getExpVisitTime()));
			
			commTraxDelegate.updateVisitDetails(visitBean);
			forward = PaxTraxConstants.MAINTAIN_VISIT_CONFIRM_PAGE;
		}
		catch (CommTraxException commTraxException)
		{
			PaxTraxLog.logError(
				"CommTraxException caught saveVisitDetails-VisitAction",
				commTraxException);
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.LOCATION_ERROR,
				new ActionMessage("" + commTraxException.getErrorCode()));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + commTraxException.getErrorCode());
			forward = PaxTraxConstants.CREATE_VISIT_PAGE;
		}
		PaxTraxLog.logDebug("PaxTrax::VisitAction::saveVisitDetails::End");
		return mapping.findForward(forward);
	}


	/**
	* Forwards to create visit page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Visit Page
	*/
	public ActionForward createVisitPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createVisitPage::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = new VisitBean();
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		ArrayList arlTaName = new ArrayList();
		ArrayList arlTaBranchName = new ArrayList();

		arlTaName = commTraxDelegate.loadTaName();

		visitForm.setArlTaNames(arlTaName);
		visitForm.setArlTaBranchNames(arlTaBranchName);
		visitForm.setArlExpVstTimes(getArrayList());


		visitForm.setVisitBean(visitBean);
		HttpSession session = request.getSession();
		
		//added for CR695 on 06-Oct-2008 
		session.setAttribute("editable","N");
		
		
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);
		forward = PaxTraxConstants.CREATE_VISIT_PAGE;
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createVisitPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward loadTaBranchNames(ActionMapping mapping,ActionForm form,HttpServletRequest request,HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createVisitPage::Begin");
		VisitForm visitForm = (VisitForm) form;
		String strTargetPage = request.getParameter("page");
		VisitBean visitBean = null;
		if (strTargetPage.equals("maintain"))
		{
			visitBean = visitForm.getStartVisitBean();
		}
		else
		{
			visitBean = visitForm.getVisitBean();
		}
		ArrayList arlTaName = new ArrayList();
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		String pageNumber	  = request.getParameter(PaxTraxConstants.PAGE_NUMBER);

		String taCode = visitBean.getTaCode();

		ArrayList arlTaBranchName       = commTraxDelegate.loadTaBranchName(taCode);
		visitForm.setArlTaBranchNames(arlTaBranchName);

		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);

		if (strTargetPage.equals("create"))
		{
			forward = PaxTraxConstants.CREATE_VISIT_PAGE;
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
		}
		else if(strTargetPage.equals("maintain")){
			forward = PaxTraxConstants.MAINTAIN_VISIT_PAGE;
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
		}
		else if(strTargetPage.equals("maintainVisitDetail")){
			forward = PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE;
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		}
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		
		String strIndex = request.getParameter("index");
		request.setAttribute("index", strIndex);
		String index = request.getParameter("indexId");
		request.setAttribute("indexId",index);

		request.setAttribute("targetpage",request.getParameter("targetpage"));

		PaxTraxLog.logDebug("PaxTrax::VisitAction::createVisitPage::End");
		return mapping.findForward(forward);
	}

/**
	* Forwards to create visit page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward createMaintainPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createMaintainPage::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = new VisitBean();
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		ArrayList arlTaName = new ArrayList();
		ArrayList arlTaBranchName = new ArrayList();

		arlTaName = commTraxDelegate.loadTaName();
		visitForm.setArlTaNames(arlTaName);
		visitForm.setArlTaBranchNames(arlTaBranchName);
		visitForm.setStartVisitBean(visitBean);

		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);
		session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_VISIT_RECORDS, Integer.toString(0));
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
		forward = PaxTraxConstants.MAINTAIN_VISIT_PAGE;
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createMaintainPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward searchMaintainPage(ActionMapping mapping,ActionForm form,
		HttpServletRequest request,HttpServletResponse response)throws PaxTraxSystemException,CommTraxException
	{
			PaxTraxLog.logDebug("CommTrax::VisitAction::searchTravelAgent::Begin");
			VisitForm visitForm = (VisitForm) form;
			VisitBean visitBean =  visitForm.getStartVisitBean();
			
			CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
			HttpSession session = request.getSession();
			
			int pageNumber = 0;
			ArrayList totalTARecords = null;
			ArrayList currentPageTARecords = null;
			String pageNumberStr =	request.getParameter(PaxTraxConstants.PAGE_NUMBER);


			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			if (pageNumber == 0)
			{
				int size = 0;
				pageNumber = 1;
				totalTARecords = commTraxDelegate.searchVisitDetails(visitBean);
				if(totalTARecords != null)
				{
					size = totalTARecords.size();
				}
				session.removeAttribute(PaxTraxConstants.VISIT_RECORDS);
				session.setAttribute(PaxTraxConstants.VISIT_RECORDS, totalTARecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_VISIT_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_VISIT_RECORDS, Integer.toString(size));
			}
			else
			{
				totalTARecords = (ArrayList)session.getAttribute(PaxTraxConstants.VISIT_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			if ((totalTARecords != null) && (totalTARecords.size() !=0))
			{
				currentPageTARecords = helper.getCurrentTableContent(totalTARecords,
				pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
			}
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
			visitForm.setTaCollection(currentPageTARecords);
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			request.setAttribute("targetpage","maintain");
			PaxTraxLog.logDebug("CommTrax::VisitAction::searchTravelAgent::Output Records"+totalTARecords);
			return mapping.findForward("searchMaintainVisit");
	}


	public ActionForward showMaintainVisitCode(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createMaintainPage::Begin");
		VisitForm visitForm = (VisitForm) form;
		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute("indexId",index);
		VisitBean visitBean = null;
		
		HttpSession session = request.getSession();
		ArrayList visitRecords = (ArrayList)
			session.getAttribute(PaxTraxConstants.VISIT_RECORDS);
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		ArrayList arlTaName           = new ArrayList();
		ArrayList arlTaBranchName     = new ArrayList();
		ArrayList arlVisitPaxDetails  = new ArrayList();
		
		String pageNumber = (String) request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		
		VisitBean visitBean1 = new VisitBean();
		if (index != null && !index.equals("null"))
		{
			visitBean = 
				(VisitBean)visitRecords.get(Integer.parseInt(index)-1);

			String expVisitTime = visitBean.getExpVisitTime();
			if(expVisitTime != null && expVisitTime.trim().length() != 0 
				&& !expVisitTime.equals("-1"))
				visitBean1.setExpVisitTime(getTime(expVisitTime));

			String actVisitTime = visitBean.getActVisitTime();
			if(actVisitTime != null && actVisitTime.trim().length() != 0 
				&& !actVisitTime.equals("-1"))
				visitBean1.setActVisitTime(getTime(actVisitTime));
			
		}
		else
		{
			visitBean = visitForm.getVisitBean();
			visitBean1.setExpVisitTime(visitBean.getExpVisitTime());
			visitBean1.setActVisitTime(visitBean.getActVisitTime());
		}

		arlTaName			  = commTraxDelegate.loadTaName();
		arlTaBranchName       = commTraxDelegate.loadTaBranchName(
			visitBean.getTaCode());


		visitBean1.setVisitCode(visitBean.getVisitCode());
		visitBean1.setTaCode(visitBean.getTaCode());
		visitBean1.setTaBranchCode(visitBean.getTaBranchCode());
		visitBean1.setTaName(visitBean.getTaName());
		visitBean1.setTaBranchName(visitBean.getTaBranchName());
		visitBean1.setExpVisitDate(visitBean.getExpVisitDate());
		visitBean1.setExpNoOfPax(visitBean.getExpNoOfPax());
		visitBean1.setActVisitDate(visitBean.getActVisitDate());
		visitBean1.setActNoOfPax(visitBean.getActNoOfPax());
		visitBean1.setVisitName(visitBean.getVisitName());
		visitBean1.setTaGuide(visitBean.getTaGuide());
		visitBean1.setTaEscort(visitBean.getTaEscort());
		visitBean1.setTaRemarks(visitBean.getTaRemarks());
		visitBean1.setCurrentStatus(visitBean.getCurrentStatus());
		visitForm.setArlTaNames(arlTaName);
		visitForm.setArlTaBranchNames(arlTaBranchName);
		visitForm.setArlExpVstTimes(getArrayList());
		
		/*modified for CR695 on 07-oct 2008*/
		visitForm.setArlActVstTimes(getDetailTimeList());
		
		// added for CR695 on 07-oct-2008 begin
		if(visitBean.getActVisitDate()!=null && visitBean.getActVisitDate().trim().length() != 0 && !visitBean.getActVisitDate().equals("-1"))
		{
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date d = new Date(new java.util.Date().getTime());
			String dt= dateFormat.format(d);
			String d2=visitBean.getActVisitDate();
			//modified for CR695 on 12-Dec-2008 
			Date d5=  new Date(new Date(d2).getTime()+4*1000*60*60*24);
			d2= dateFormat.format(d5);
	
			if(new Date(dt).compareTo(new Date(d2))==-1)
				session.setAttribute("editable","Y");
			else
				session.setAttribute("editable","N");
		}
		else
			session.setAttribute("editable","N");
		//added for CR695 on 07-oct-2008 end

		arlVisitPaxDetails = commTraxDelegate.getVisitPaxDetails(visitBean1);
		visitForm.setArlVisitPaxDetails(arlVisitPaxDetails);
		visitForm.setVisitBean(visitBean1);
		session.setAttribute("visitPaxDetails",arlVisitPaxDetails);
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);
		if (pageNumber != null)
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		}
		else
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, "0");
		}
		
		String targetpage = request.getParameter("targetpage");
		if (targetpage != null && !targetpage.equals("null"))
		{
			request.setAttribute("targetpage",targetpage);
		}		
		
		request.setAttribute("index", "0");
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		forward = PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE;
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createMaintainPage::End");
		return mapping.findForward(forward);
	}


	public ActionForward deleteVisitDetails(ActionMapping mapping,ActionForm form,HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createVisitPage::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = visitForm.getVisitBean();
		HttpSession session = request.getSession();
		visitBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));		
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		commTraxDelegate.removeVisitDetails(visitBean);

		String targetPage = (String)request.getParameter("targetpage");
		if(targetPage != null && !targetPage.equals("null"))
			request.setAttribute("targetpage",targetPage);

		visitForm.setVisitBean(visitBean);

		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);

		PaxTraxLog.logDebug("PaxTrax::VisitAction::createVisitPage::End");
		return mapping.findForward("deleteVisitPage");
	}

	public ActionForward deletePaxDetail(ActionMapping mapping,ActionForm form,HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::deletePaxDetail::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = visitForm.getVisitBean();
		
		String pageNumber	= request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		String strIndex = request.getParameter("index");
		String index = request.getParameter("indexId");
		request.setAttribute("indexId",index);

		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		ArrayList arlVisitPaxDetails = commTraxDelegate.getVisitPaxDetails(visitBean);
		visitBean = (VisitBean)arlVisitPaxDetails.get(Integer.parseInt(visitBean.getIndex()));
		HttpSession session = request.getSession();
		visitBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));
		commTraxDelegate.removePaxDetail(visitBean);
		
		visitBean = visitForm.getVisitBean();
		arlVisitPaxDetails= commTraxDelegate.getVisitPaxDetails(visitBean);
		visitForm.setArlVisitPaxDetails(arlVisitPaxDetails);

		String targetPage = request.getParameter("targetpage");
		if(targetPage != null && !targetPage.equals("null"))
			request.setAttribute("targetpage",targetPage);

		visitForm.setVisitBean(visitBean);
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		forward = PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE;
		PaxTraxLog.logDebug("PaxTrax::VisitAction::deletePaxDetail::End");
		return mapping.findForward(forward);
	}

/**
	* Forwards to start visit page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding
	*/

	public ActionForward createStartVisitPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createStartVisitPage::Begin");
		
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = new VisitBean();
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		ArrayList taNameList = commTraxDelegate.loadTaName();
		visitForm.setArlTaNames(taNameList);

		
		/*added for CR695 on 01-oct-2008 begin*/
		visitForm.setArlActVstTimes(getDetailTimeList());
		/*added for CR695 on 01-oct-2008 end*/
	
		visitForm.setStartVisitBean(visitBean);
	
		HttpSession session = request.getSession();
		
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);
		
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
		
		PaxTraxLog.logDebug("PaxTrax::VisitAction::createStartVisitPage::End");
		return mapping.findForward(PaxTraxConstants.START_VISIT_PAGE);
	}

	/**
	 * Searches visit details for which tour has not been started
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward performStartVisit(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
			PaxTraxLog.logDebug("CommTrax::VisitAction::performStartVisit::Begin");
			VisitForm visitForm = (VisitForm) form;
			CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
			VisitBean visitBean = visitForm.getStartVisitBean();

			HttpSession session = request.getSession();
			visitBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));

			int pageNumber = 0;
			ArrayList totalRecords = null;
			ArrayList currentPageRecords = null;
			String pageNumberStr =	request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			if (pageNumber == 0)
			{
				int size = 0;
				pageNumber = 1;
				
				// added for CR695 on 03-0ct-2008
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat(("hh:mm a"));
				String ctime=sdf.format(cal.getTime());
		
				ArrayList abc=commTraxDelegate.searchStartVisitDetails(visitBean);
				for(int i=0;i< abc.size();i++)
				{
					VisitBean vb =(VisitBean)abc.get(i);
					String avt=vb.getActVisitTime();
					if(avt!=null && avt.trim().length() != 0 && !avt.equals("-1"))
					{
						vb.setActVisitTime(getTime(vb.getActVisitTime()));
					}
					else
						vb.setActVisitTime(ctime);
				}
								
				//	added for CR695 on 03-0ct-2008 end
				
				totalRecords = abc;//commTraxDelegate.searchStartVisitDetails(visitBean);
				if(totalRecords != null)
				{
					size = totalRecords.size();
				}
				
				session.removeAttribute(PaxTraxConstants.START_VISIT_RECORDS);
				session.setAttribute(PaxTraxConstants.START_VISIT_RECORDS,
					 totalRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_START_VISIT_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_START_VISIT_RECORDS,
					 Integer.toString(size));
			}
			else
			{
				totalRecords = (ArrayList)session.getAttribute(
					PaxTraxConstants.START_VISIT_RECORDS);
			}

			PaginationHelper helper = PaginationHelper.getInstance();
			if ((totalRecords != null) && (totalRecords.size() !=0))
			{
				currentPageRecords = helper.getCurrentTableContent(totalRecords,
					pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
			}

			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));
			visitForm.setTaCollection(currentPageRecords);
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);

			PaxTraxLog.logDebug("CommTrax::VisitAction::performStartVisit::End");
			return mapping.findForward(PaxTraxConstants.START_VISIT_PAGE);
	}

	/**
	 * It forwards to the page where we can view the complete details of a
	 * particular visit code
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public	ActionForward startVisitDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("CommTrax::VisitAction::startVisitDetails::Begin");
		VisitForm visitForm = (VisitForm)form;
		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		HttpSession session = request.getSession();
		ArrayList visitList = (ArrayList)session.
			getAttribute(PaxTraxConstants.START_VISIT_RECORDS);
		if (visitList != null)
		{
			visitForm.setVisitBean((VisitBean)
				visitList.get(Integer.parseInt(index)-1));
		}
		PaxTraxLog.logDebug("CommTrax::VisitAction::startVisitDetails::End");
		return mapping.findForward(PaxTraxConstants.START_VISIT_DETAILS_PAGE);
	}

	/**
	 * Starts the visit by providing actual date and time.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward updateStartVisit(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,PaxTraxConfigFileException
	{
		PaxTraxLog.logDebug("CommTrax::VisitAction::updateStartVisit::Begin");
		VisitForm visitForm = (VisitForm)form;
		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		HttpSession session = request.getSession();
		ArrayList visitList = (ArrayList)session.
			getAttribute(PaxTraxConstants.START_VISIT_RECORDS);

		VisitBean visitBean = new VisitBean();
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		int timeDifferenceValue = commTraxDelegate.getStartVisitTimeDifference();
		if (visitList != null)
		{
			visitBean = (VisitBean)visitList.get(Integer.parseInt(index)-1);
			visitBean.setActNoOfPax(request.getParameter("actualPax"));
	
		// added for CR695 on 03-oct-2008 begin
			visitBean.setActVisitTime(request.getParameter("actualVisitTime"));
			 String actVisitTime = visitBean.getActVisitTime();
			 if(actVisitTime != null && actVisitTime.trim().length() != 0 && !actVisitTime.equals("-1"))
			  visitBean.setActVisitTime(changeAmPmTime(visitBean.getActVisitTime()));
		
		//added for CR695 on 03-oct-2008 end
		
		}
		if (visitBean.getPaxList() == null || visitBean.getPaxList().size() == 0)
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE,PaxTraxConstants.ERRORCODE);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
			return mapping.findForward(PaxTraxConstants.START_VISIT_PAGE);
		}
			

		SimpleDateFormat s = new SimpleDateFormat("yyyy/MM/dd");
		Calendar startCheck = Calendar.getInstance();
		
		int h = s.format(startCheck.getTime()).compareTo(visitBean.getExpVisitDate());
		
		if (h >= 0)
		{
			if (h == 0)
			{
				//long timeInMilli = startCheck.getTime().getTime();
				// added for CR695 on 03-0ct-2008
				Calendar actvt = Calendar.getInstance();
				actvt.set(Calendar.HOUR_OF_DAY,Integer.parseInt(
				visitBean.getActVisitTime().substring(0,2)));
				actvt.set(Calendar.MINUTE,Integer.parseInt(
				visitBean.getActVisitTime().substring(3,5)));
				actvt.set(Calendar.SECOND,Integer.parseInt(
				visitBean.getActVisitTime().substring(6)));
				long timeInMilli = actvt.getTime().getTime();
	
//				added for CR695 on 03-0ct-2008
				
				Calendar n = Calendar.getInstance();
				n.set(Calendar.HOUR_OF_DAY,Integer.parseInt(
					visitBean.getExpVisitTime().substring(0,2)));
				n.set(Calendar.MINUTE,Integer.parseInt(
					visitBean.getExpVisitTime().substring(3,5)));
				n.set(Calendar.SECOND,Integer.parseInt(
					visitBean.getExpVisitTime().substring(6)));
				long expectedTime = n.getTime().getTime();
				
				long timeInMin = (expectedTime - timeInMilli)/(1000*60);
			
				if (timeInMin > timeDifferenceValue)
				{
					// added for CR695 on 03-0ct-2008
					String actVisitTime = visitBean.getActVisitTime();
					if(actVisitTime != null && actVisitTime.trim().length() != 0 && !actVisitTime.equals("-1"))
							visitBean.setActVisitTime(getTime(visitBean.getActVisitTime()));
					// added for CR695 on 03-0ct-2008 end
			
					request.setAttribute(PaxTraxConstants.ERRORCODE,PaxTraxConstants.TIME_MIN);
					request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
					return mapping.findForward(PaxTraxConstants.START_VISIT_PAGE);
				}
			}
		}
		else
		{
			// added for CR695 on 03-0ct-2008
			
			String actVisitTime = visitBean.getActVisitTime();
			if(actVisitTime != null && actVisitTime.trim().length() != 0 && !actVisitTime.equals("-1"))
				visitBean.setActVisitTime(getTime(visitBean.getActVisitTime()));
			// added for CR695 on 03-0ct-2008 end
					
			request.setAttribute(PaxTraxConstants.ERRORCODE,PaxTraxConstants.TIME_MIN);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
			return mapping.findForward(PaxTraxConstants.START_VISIT_PAGE);
		}
		
		try
		{
		visitBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));
		commTraxDelegate.updateStartVisit(visitBean);
		visitList.remove(Integer.parseInt(index)-1);
		session.removeAttribute(PaxTraxConstants.START_VISIT_RECORDS);
		session.setAttribute(PaxTraxConstants.START_VISIT_RECORDS,visitList);
		visitForm.setVisitBean(visitBean);
		forward = PaxTraxConstants.START_VISIT_CONFIRM;
		}
		catch (CommTraxException commTraxException)
		{
			PaxTraxLog.logError("CommTrax::VisitAction::updateStartVisit",commTraxException);
			
			request.setAttribute(PaxTraxConstants.ERRORCODE,
				""+PaxTraxConstants.VISIT_CANNOT_START);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
			return mapping.findForward(PaxTraxConstants.START_VISIT_PAGE);
		}
		PaxTraxLog.logDebug("CommTrax::VisitAction::updateStartVisit::End");
		return mapping.findForward(forward);
	}

	public ActionForward goToNewPax(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::goToNewPax::Begin");
		VisitForm visitForm = (VisitForm)form;
		VisitBean visitBean = visitForm.getVisitBean();
		request.setAttribute(PaxTraxConstants.VISIT_BEAN,
			visitBean);
		request.setAttribute(PaxTraxConstants.INDEX,
			request.getParameter("indexId"));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		PaxTraxLog.logDebug("PaxTrax::VisitAction::goToNewPax::End");
		return mapping.findForward(PaxTraxConstants.CREATE_VISIT_PAX_PAGE);
	}

	public ActionForward goToSearchPax(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::goToSearchPax::Begin");
		VisitForm visitForm = (VisitForm)form;
		VisitBean visitBean = visitForm.getVisitBean();
		request.setAttribute(PaxTraxConstants.VISIT_BEAN,
			visitBean);
		request.setAttribute(PaxTraxConstants.INDEX,
			request.getParameter("indexId"));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		PaxTraxLog.logDebug("PaxTrax::VisitAction::goToSearchPax::End");
		return mapping.findForward("commtraxSearchPAX");
	}

	public ActionForward goToGroup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::goToGroup::Begin");
		VisitForm visitForm = (VisitForm)form;
		request.setAttribute(PaxTraxConstants.VISIT_BEAN,
			visitForm.getVisitBean());
		request.setAttribute(PaxTraxConstants.INDEX,
			request.getParameter("indexId"));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		PaxTraxLog.logDebug("PaxTrax::VisitAction::goToGroup::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_GROUP_PAGE);
	}

	/**
		* change the language
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while changing the language
	*/

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);

		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);

		if (language != null && country != null)
		{
			super.changeLanguage(request, language, country);
		}
		else
		{
			PaxTraxLog.logDebug("Error in Change Language"+language+country);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);
		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
		}

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		String page = request.getParameter(PaxTraxConstants.PAGE);
		String pageNumber = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		forward = page;

		if (page.equals("createVisit"))
		{
			forward = PaxTraxConstants.CREATE_VISIT_PAGE;
		}
		else if (page.equals("maintainVisit"))
		{
			if(pageNumber.equals("-1")){
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
				forward = PaxTraxConstants.MAINTAIN_VISIT_PAGE;
			}
			else{
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				request.setAttribute("pageNumber", pageNumber);
				forward = PaxTraxConstants.MAINTAIN_VISIT_PAGE;
			}
			String targetPage = request.getParameter("targetpage");
			request.setAttribute("targetpage",targetPage);
		}
		else if (page.equals("maintainVisitDetail"))
		{
			String targetPage = request.getParameter("targetpage");
			request.setAttribute("targetpage",targetPage);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			forward = PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE;
			String index = request.getParameter("indexId");
			request.setAttribute("indexId",index);
		}
		else if (page.equals("maintainVisitDelete"))
		{
			String targetPage = request.getParameter("targetpage");
			request.setAttribute("targetpage",targetPage);
			forward = "deleteVisitPage";
			String index = request.getParameter("indexId");
			request.setAttribute("indexId",index);
		}
		else if (page.equals("maintainVisitConfirm"))
		{
			String targetPage = request.getParameter("targetpage");
			request.setAttribute("targetpage",targetPage);
			forward = PaxTraxConstants.MAINTAIN_VISIT_CONFIRM_PAGE;
		}

		pageNumber = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		if (pageNumber != null && !pageNumber.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		}
		else
		{
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);
		}

		String index = request.getParameter(PaxTraxConstants.INDEX);
		if (index != null && !index.equals("null"))
		{
			request.setAttribute(PaxTraxConstants.INDEX,index);
		}
		PaxTraxLog.logDebug("PaxTrax::VisitAction::changeLanguage::End");
		return mapping.findForward(forward);
	}
	private ArrayList getArrayList()
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::getArrayList::Begin");
		ReferenceDataBean commonBean = null;
		ArrayList temp = new ArrayList();
		/*for (int i = 0; i < 10; i++)
		{*/
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:00 AM");
			commonBean.setCodeValue("08:00 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:15 AM");
			commonBean.setCodeValue("08:15 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:30 AM");
			commonBean.setCodeValue("08:30 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:45 AM");
			commonBean.setCodeValue("08:45 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:00 AM");
			commonBean.setCodeValue("09:00 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:15 AM");
			commonBean.setCodeValue("09:15 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:30 AM");
			commonBean.setCodeValue("09:30 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:45 AM");
			commonBean.setCodeValue("09:45 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("10:00 AM");
			commonBean.setCodeValue("10:00 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("10:15 AM");
			commonBean.setCodeValue("10:15 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("10:30 AM");
			commonBean.setCodeValue("10:30 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("10:45 AM");
			commonBean.setCodeValue("10:45 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("11:00 AM");
			commonBean.setCodeValue("11:00 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("11:15 AM");
			commonBean.setCodeValue("11:15 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("11:30 AM");
			commonBean.setCodeValue("11:30 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("11:45 AM");
			commonBean.setCodeValue("11:45 AM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("12:00 PM");
			commonBean.setCodeValue("12:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("12:15 PM");
			commonBean.setCodeValue("12:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("12:30 PM");
			commonBean.setCodeValue("12:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("12:45 PM");
			commonBean.setCodeValue("12:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("01:00 PM");
			commonBean.setCodeValue("01:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("01:15 PM");
			commonBean.setCodeValue("01:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("01:30 PM");
			commonBean.setCodeValue("01:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("01:45 PM");
			commonBean.setCodeValue("01:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("02:00 PM");
			commonBean.setCodeValue("02:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("02:15 PM");
			commonBean.setCodeValue("02:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("02:30 PM");
			commonBean.setCodeValue("02:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("02:45 PM");
			commonBean.setCodeValue("02:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("03:00 PM");
			commonBean.setCodeValue("03:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("03:15 PM");
			commonBean.setCodeValue("03:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("03:30 PM");
			commonBean.setCodeValue("03:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("03:45 PM");
			commonBean.setCodeValue("03:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("04:00 PM");
			commonBean.setCodeValue("04:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("04:15 PM");
			commonBean.setCodeValue("04:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("04:30 PM");
			commonBean.setCodeValue("04:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("04:45 PM");
			commonBean.setCodeValue("04:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("05:00 PM");
			commonBean.setCodeValue("05:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("05:15 PM");
			commonBean.setCodeValue("05:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("05:30 PM");
			commonBean.setCodeValue("05:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("05:45 PM");
			commonBean.setCodeValue("05:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("06:00 PM");
			commonBean.setCodeValue("06:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("06:15 PM");
			commonBean.setCodeValue("06:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("06:30 PM");
			commonBean.setCodeValue("06:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("06:45 PM");
			commonBean.setCodeValue("06:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("07:00 PM");
			commonBean.setCodeValue("07:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("07:15 PM");
			commonBean.setCodeValue("07:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("07:30 PM");
			commonBean.setCodeValue("07:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("07:45 PM");
			commonBean.setCodeValue("07:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:00 PM");
			commonBean.setCodeValue("08:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:15 PM");
			commonBean.setCodeValue("08:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:30 PM");
			commonBean.setCodeValue("08:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("08:45 PM");
			commonBean.setCodeValue("08:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:00 PM");
			commonBean.setCodeValue("09:00 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:15 PM");
			commonBean.setCodeValue("09:15 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:30 PM");
			commonBean.setCodeValue("09:30 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("09:45 PM");
			commonBean.setCodeValue("09:45 PM");
			temp.add(commonBean);
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("10:00 PM");
			commonBean.setCodeValue("10:00 PM");
			temp.add(commonBean);
		PaxTraxLog.logDebug("PaxTrax::VisitAction::getArrayList::End");
		return temp;
	}


/*Added for CR695 on 01-oct-2008 begin */

private ArrayList getDetailTimeList()
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::getDetailTimeList::Begin");
		ReferenceDataBean commonBean = null;
		ArrayList temp = new ArrayList();
	
		for(int i=8;i<=11;i++)
		{
			for(int j=0;j<60;j++)
			{
				commonBean = new ReferenceDataBean();
				if(i<10 && j<10)
				{
					commonBean.setCodeId("0"+i+":0"+j+" AM");
					commonBean.setCodeValue("0"+i+":0"+j+" AM");
					temp.add(commonBean);
				}
				else if(i<10 && j>=10)
				{
					commonBean.setCodeId("0"+i+":"+j+" AM");
					commonBean.setCodeValue("0"+i+":"+j+" AM");
					temp.add(commonBean);
				
				}
				else if(i>=10 && j<10)
				{
					commonBean.setCodeId(""+i+":0"+j+" AM");
					commonBean.setCodeValue(""+i+":0"+j+" AM");
					temp.add(commonBean);
				
				}
				else if(i>=10 && j>=10)
				{
					commonBean.setCodeId(""+i+":"+j+" AM");
					commonBean.setCodeValue(""+i+":"+j+" AM");
					temp.add(commonBean);
				
				}
			}
		}

		for(int i=12;i<=12;i++)
		{
			for(int j=0;j<60;j++)
			{
				commonBean = new ReferenceDataBean();
				if(j<10)
				{
					commonBean.setCodeId(""+i+":0"+j+" PM");
					commonBean.setCodeValue(""+i+":0"+j+" PM");
					temp.add(commonBean);
				}
				else if(j>=10)
				{
					commonBean.setCodeId(""+i+":"+j+" PM");
					commonBean.setCodeValue(""+i+":"+j+" PM");
					temp.add(commonBean);
					
				}
			
			}
		}


		for(int i=1;i<10;i++)
		{
			for(int j=0;j<60;j++)
			{
					commonBean = new ReferenceDataBean();
					if(i<10 && j<10)
					{
						commonBean.setCodeId("0"+i+":0"+j+" PM");
						commonBean.setCodeValue("0"+i+":0"+j+" PM");
						temp.add(commonBean);
					}
					else if(i<10 && j>=10)
					{
						commonBean.setCodeId("0"+i+":"+j+" PM");
						commonBean.setCodeValue("0"+i+":"+j+" PM");
						temp.add(commonBean);
					}
					else if(i>=10 && j<10)
					{
						commonBean.setCodeId(""+i+":0"+j+" PM");
						commonBean.setCodeValue(""+i+":0"+j+" PM");
						temp.add(commonBean);
					}
					else if(i>=10 && j>=10)
					{
						commonBean.setCodeId(""+i+":"+j+" PM");
						commonBean.setCodeValue(""+i+":"+j+" PM");
						temp.add(commonBean);
					}
			}
		}
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId("10:00 PM");
				commonBean.setCodeValue("10:00 PM");
				temp.add(commonBean);

		PaxTraxLog.logDebug("PaxTrax::VisitAction::getDetailTimeList::End");
		return temp;
	}
/*Added for CR695 on 01-oct-2008 end*/

	private String getTime(String strTime)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::getDate::Begin");
		int intHour = Integer.parseInt(strTime.substring(0,2));
		String strValue = "";
		if(intHour > 12)
		{
			String temp = strTime.substring(0,2);
			int hour = Integer.parseInt(temp) - 12;
			//Added on 2006-12-29
			if(hour < 10){
				strValue = "0"+String.valueOf(hour);
			}
			else
				strValue = String.valueOf(hour);
			
			strTime=strValue+strTime.substring(2,5)+" PM";
		}
		else if (intHour==12){
		strValue = String.valueOf(12);
		strTime=strValue+strTime.substring(2,5)+" PM";
		}

		else
		{
			strTime=strTime.substring(0,5).concat(" AM");
		}
		return strTime;
	}


	private String changeAmPmTime(String strTime)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitAction::changeAmPmTime::Begin");
	/*	int hour=0;
		if(strTime.endsWith("PM"))
		{
			String temp = strTime.substring(0,2);
			//Added on 2006-12-29
			if(Integer.parseInt(temp)==12){
				hour=12;
			}
			else{
				hour = 12 + Integer.parseInt(temp);
			}
			
			strTime=hour+strTime.substring(2,5)+":00";	
		}
		else
		{
			
			strTime=strTime.substring(0,5).concat(":00");	
		}

		return strTime;*/
		int hour=0;
		if(strTime.endsWith("PM"))
		{
			String temp = strTime.substring(0,2);
			//Added on 2006-12-29
			if(Integer.parseInt(temp)==12){
				hour=12;
			}
			else{
				hour = 12 + Integer.parseInt(temp);
			}
			
			strTime=hour+strTime.substring(2,5)+":00";	
		}
		else if(strTime.endsWith("AM"))
		{
			String temp = strTime.substring(0,2);
			//Added on 2006-12-29
			if(Integer.parseInt(temp)==12){
				hour=00;
			}
			else{
				hour = Integer.parseInt(temp);
			}
			
			if(hour>=10)

			strTime=hour+strTime.substring(2,5)+":00";	
			else
			strTime="0"+hour+strTime.substring(2,5)+":00";	

		}
		else
		{
			
			strTime=strTime.substring(0,5).concat(":00");	
		}

		return strTime;

	}
	public ActionForward searchMaintainPageExcel(ActionMapping mapping,ActionForm form,
		HttpServletRequest request,HttpServletResponse response)throws PaxTraxSystemException,CommTraxException
	{
			PaxTraxLog.logDebug("CommTrax::VisitAction::searchMaintainPageExcel::Begin");
			
			
			ArrayList totalTARecords = null;
			
		try
		{
			
			int size = 0;
			long totExpNoPax = 0;
			// Modified by David for CR#3563 starts here
			String heads[] = {"Visit Code","Visit Name","Nationality","TA Name","TA Branch","Exp Date of Visit","Exp Time",
				"Exp No of Pax","Act date of Visit","Actual time","Actual No of Pax"};
				
			int colsWidth[] = {3600,10800,6400,6400,6400,5400,5400,3600,5400,5400,5400};
			// Modified by David for CR#3563 ends here
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");
			
			if (user == null) {
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
				
			}
					
			
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("Maintain Visit");
			
			//Create Header Font
			HSSFFont fontHeader = wb.createFont();
			fontHeader.setFontHeightInPoints((short)10);
			fontHeader.setFontName(HSSFFont.FONT_ARIAL);
			fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
							
			//Create font for the workbook Data cells
			HSSFFont font = wb.createFont();
			font.setFontHeightInPoints((short)10);
			font.setFontName(HSSFFont.FONT_ARIAL);
			
			//Style for the Header cells
			HSSFCellStyle styleHeader = wb.createCellStyle();
			styleHeader.setFont(fontHeader);
			styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			HSSFRow rowHead = sheet.createRow((short)0);
			
			HSSFCellStyle styleNum = wb.createCellStyle();
			HSSFDataFormat format = wb.createDataFormat();
			styleNum.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
			styleNum.setDataFormat(format.getFormat("#,##0"));				
			styleNum.setFont(font);
			
			for(int cnt = 0;cnt<heads.length;cnt++)
			createCell(rowHead,styleHeader,heads[cnt],HSSFCell.CELL_TYPE_STRING,cnt);

			HSSFCellStyle style = wb.createCellStyle();
			style.setFont(font);
			
	

			totalTARecords = (ArrayList)session.getAttribute(PaxTraxConstants.VISIT_RECORDS);
			String pageNumber = (String) request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			
			
			if(totalTARecords != null)
			{
				size = totalTARecords.size();
				for(int rows=0;rows < size; rows++)
				{
					HSSFRow row = sheet.createRow((short)(rows+1));
					if(((VisitBean) totalTARecords.get(rows)).getVisitCode()!=null)
					{
						createCell(row,styleNum,((VisitBean)totalTARecords.get(rows)).getVisitCode().toString(),
														HSSFCell.CELL_TYPE_NUMERIC,0);
					}
					if(((VisitBean) totalTARecords.get(rows)).getVisitName()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getVisitName().toString(),
														HSSFCell.CELL_TYPE_STRING,1);
					}
					// Added by David for CR#3563 starts here
					if(((VisitBean) totalTARecords.get(rows)).getNationality()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getNationality().toString(),
														HSSFCell.CELL_TYPE_STRING,2);
					}
					// Added by David for CR#3563 ends here
					// Modified by David for CR#3563 starts here
					//Corresponding column numbers are shifted where the nationality field is inserted
					if(((VisitBean) totalTARecords.get(rows)).getTaName()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getTaName().toString(),
														HSSFCell.CELL_TYPE_STRING,3);
					}
					if(((VisitBean) totalTARecords.get(rows)).getTaBranchName()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getTaBranchName().toString(),
														HSSFCell.CELL_TYPE_STRING,4);
					}
					if(((VisitBean) totalTARecords.get(rows)).getExpVisitDate()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getExpVisitDate().toString(),
														HSSFCell.CELL_TYPE_STRING,5);
					}
					if(((VisitBean) totalTARecords.get(rows)).getExpVisitTime()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getExpVisitTime().toString(),
														HSSFCell.CELL_TYPE_STRING,6);
					}
					if(((VisitBean) totalTARecords.get(rows)).getExpNoOfPax()!=null)
					{
						createCell(row,styleNum,((VisitBean)totalTARecords.get(rows)).getExpNoOfPax().toString(),
														HSSFCell.CELL_TYPE_NUMERIC,7);
						totExpNoPax +=Integer.parseInt(((VisitBean)totalTARecords.get(rows)).getExpNoOfPax().toString());
					}
					if(((VisitBean) totalTARecords.get(rows)).getActVisitDate()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getActVisitDate().toString(),
														HSSFCell.CELL_TYPE_STRING,8);
					}
					if(((VisitBean) totalTARecords.get(rows)).getActVisitTime()!=null)
					{
						createCell(row,style,((VisitBean)totalTARecords.get(rows)).getActVisitTime().toString(),
														HSSFCell.CELL_TYPE_STRING,9);
					}
					if(((VisitBean) totalTARecords.get(rows)).getActNoOfPax()!=null)
					{
						createCell(row,styleNum,((VisitBean)totalTARecords.get(rows)).getActNoOfPax().toString(),
														HSSFCell.CELL_TYPE_NUMERIC,10);
					}
					// Modified by David for CR#3563 ends here
				}
				
			}
			
			HSSFRow rowTotal = sheet.createRow((short)size+1);
			// Added by David for CR#3563 starts here
			createCell(rowTotal,styleHeader,"Total:",HSSFCell.CELL_TYPE_STRING,6);
			createCell(rowTotal,styleHeader,new Long(totExpNoPax).toString(),HSSFCell.CELL_TYPE_NUMERIC,7);
			// Added by David for CR#3563 ends here
			for (int colsRng = 0;colsRng < colsWidth.length;colsRng++)
				sheet.setColumnWidth((short) colsRng, (short) colsWidth[colsRng]);
			sheet.createFreezePane(0,1,0,1);
			
			FileOutputStream fileOut = new FileOutputStream(PaxTraxConstants.SALES_REPORTS_BASE_PATH + 
													PaxTraxConstants.VISIT_REPORTS_FILE_NAME  + user +  ".xls");
			wb.write(fileOut);
			fileOut.close();
			
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);
			request.setAttribute(PaxTraxConstants.SUCCESS, "y");
			request.setAttribute(PaxTraxConstants.FILE_NAME, PaxTraxConstants.VISIT_REPORTS_FILE_NAME  + user + ".xls");
			request.setAttribute(PaxTraxConstants.FILE_TYPE, PaxTraxConstants.MS_EXCEL);
			forward = PaxTraxConstants.SEARCH_MAINTAIN_VISIT_EXCEL;
		}
		catch(Exception e)
		{
			PaxTraxLog.logError("Exception caught :VisitAction::searchMaintainPageExcel ", e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		return mapping.findForward(forward);
	}
	private void createCell(HSSFRow row,HSSFCellStyle style,String value,int cellType,int pos)
	{
		//style.setAlignment((short)cellAlignment);
		org.apache.poi.hssf.usermodel.HSSFCell cell = row.createCell((short) pos);
		cell.setCellType(cellType);
		
		if(cell.getCellType()==HSSFCell.CELL_TYPE_NUMERIC)
		{
			cell.setCellValue((Double.parseDouble(value)));
		}
		else	
		{
			cell.setCellValue(value);
		}
		cell.setCellStyle(style);
		cell.setCellType(cellType);
		
	}

}
