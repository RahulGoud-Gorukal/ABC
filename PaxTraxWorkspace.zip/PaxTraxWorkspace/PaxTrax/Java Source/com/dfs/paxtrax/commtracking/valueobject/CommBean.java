package com.dfs.paxtrax.commtracking.valueobject;


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CommBean extends PaxTraxValueObject {
	
	private String taCode = null;
	
	private String agencyName = null;
	
	private String agencyOwner = null;
	
	private String createdUser = null;
	
	private String modifiedUser = null;
	
	/* Added Segment Code and Segment Name  */
	
	private String segmentCode = null;
	
	private String segmentName = null;
	
	public String getTaCode()
	{
		return taCode;
	}
	
	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}
	
	public String getAgencyName()
	{
		return agencyName;
	}
	
	public void setAgencyName(String agencyName)
	{
		this.agencyName = agencyName;
	}
	
	public String getAgencyOwner()
	{
		return agencyOwner;
	}
	
	public void setAgencyOwner(String agencyOwner)
	{
		this.agencyOwner = agencyOwner;
	}	
	
	public String getCreatedUser()
	{
		return createdUser;
	}
	
	public void setCreatedUser(String createdUser)
	{
		this.createdUser = createdUser;
	}

	public String getModifiedUser()
	{
		return modifiedUser;
	}
	
	public void setModifiedUser(String modifiedUser)
	{
		this.modifiedUser = modifiedUser;
	}

	/**
	 * Returns the segmentCode.
	 * @return String
	 */
	public String getSegmentCode() {
		return segmentCode;
	}

	/**
	 * Returns the segmentName.
	 * @return String
	 */
	public String getSegmentName() {
		return segmentName;
	}

	/**
	 * Sets the segmentCode.
	 * @param segmentCode The segmentCode to set
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	/**
	 * Sets the segmentName.
	 * @param segmentName The segmentName to set
	 */
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}

}
