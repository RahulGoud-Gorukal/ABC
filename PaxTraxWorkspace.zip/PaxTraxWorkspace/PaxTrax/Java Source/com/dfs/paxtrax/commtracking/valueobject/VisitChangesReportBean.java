package com.dfs.paxtrax.commtracking.valueobject;

/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList; 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
** @author Cognizant Technology Solutions
* 
* * @version    1.0
* * MOD HISTORY
* DATE          USER            COMMENTS
* 21/09/2010    Selvam		 	Created   
*/

public class VisitChangesReportBean extends PaxTraxValueObject {

	private String visitCode = null;
	
	
	private String action = null;
	
	private String PaxNumber = null;
	
	private String visitDate = null;
	
	private String groupNumber = null;
	
	private String nationality = null;
	
	private String name = null; //sales_type

	private String oldValue = null;
	
	private String newValue  = null;
	
	private String updatedUser = null;

	private String modifiedDate = null;
	
	private String actnopax = null;
	
	/**
	 * @return
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @return
	 */
	public String getGroupNumber() {
		return groupNumber;
	}

	/**
	 * @return
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return
	 */
	public String getNationality() {
		return nationality;
	}

	/**
	 * @return
	 */
	public String getNewValue() {
		return newValue;
	}

	/**
	 * @return
	 */
	public String getOldValue() {
		return oldValue;
	}

	/**
	 * @return
	 */
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @return
	 */
	public String getVisitCode() {
		return visitCode;
	}

	/**
	 * @return
	 */
	public String getVisitDate() {
		return visitDate;
	}
	// Added for CR1832 starts
	/**
	 * @return
	 */
	public String getActnoPax() {
		return actnopax;
	}
	
	
	/**
		 * @return
		 */
		public String getPaxNumber() {
			return PaxNumber;
		}
	// Added for CR1832 ends
	
	

	/**
	 * @param string
	 */
	public void setAction(String string) {
		action = string;
	}

	/**
	 * @param string
	 */
	public void setGroupNumber(String string) {
		groupNumber = string;
	}

	/**
	 * @param string
	 */
	public void setModifiedDate(String string) {
		modifiedDate = string;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		name = string;
	}

	/**
	 * @param string
	 */
	public void setNationality(String string) {
		nationality = string;
	}

	/**
	 * @param string
	 */
	public void setNewValue(String string) {
		newValue = string;
	}

	/**
	 * @param string
	 */
	public void setOldValue(String string) {
		oldValue = string;
	}

	/**
	 * @param string
	 */
	public void setUpdatedUser(String string) {
		updatedUser = string;
	}

	/**
	 * @param string
	 */
	public void setVisitCode(String string) {
		visitCode = string;
	}

	/**
	 * @param string
	 */
	public void setVisitDate(String string) {
		visitDate = string;
	}
	// Added for CR1832 starts
/**
	 * @return
	 */
	public String setActnoPax() {
		return actnopax;
	}
	
	/**
		 * @return
		 */
		public String setPaxNumber() {
			return PaxNumber;
		}
	
	//Added for CR1832 ends
	
}