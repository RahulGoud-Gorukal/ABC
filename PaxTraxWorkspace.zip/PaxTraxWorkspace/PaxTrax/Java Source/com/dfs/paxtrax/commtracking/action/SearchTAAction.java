package com.dfs.paxtrax.commtracking.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.common.action.CommTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.SearchTAForm;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;

/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SearchTAAction extends CommTraxAction{


	public ActionForward searchTravelAgent(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{

			PaxTraxLog.logDebug("CommTrax::COMMAction::searchTravelAgent::Begin");


			String fromMenu = (String)request.getParameter("fromMenu");

			if (fromMenu == null)
			{

			SearchTAForm searchTAForm = (SearchTAForm) form;
			CommTraxDelegate comDelegate = new CommTraxDelegate();


			HttpSession session = request.getSession();
			int pageNumber = 0;
			ArrayList totalTARecords = null;
			ArrayList currentPageTARecords = null;


			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);



			if (pageNumber == 0)
			{
				int size = 0;
				pageNumber = 1;
				
				totalTARecords = comDelegate.getTADetails(searchTAForm.getTaCode(), searchTAForm.getAgencyName(), searchTAForm.getAgencyOwner());
				if(totalTARecords != null)
				{
					size = totalTARecords.size();
				}
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, totalTARecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
			}
			else
			{
				totalTARecords = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_RECORDS);
			}

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((totalTARecords != null) && (totalTARecords.size() !=0))
			{
			    currentPageTARecords = helper.getCurrentTableContent(totalTARecords,
		    	pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
			}

			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
			searchTAForm.setTaCollection(currentPageTARecords);
		    request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			//PaxTraxLog.logDebug("CommTrax::COMMAction::searchTravelAgent::Output Records"+totalTARecords);
			}
			else
			{
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
				return mapping.findForward("searchTravelAgent");
			}
			return mapping.findForward("searchTravelAgent");
	}




public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchBranchAction::changeLanguage::Begin");			
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		HttpSession session = request.getSession();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if(operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION,operation);
		}			
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page.equals("searchTravelAgent"))
		{			
			forward = "searchTravelAgent";
		}
		SearchTAForm searchTAForm = (SearchTAForm) form;				
		ArrayList currentRecords = searchTAForm.getTaCollection();
		if(currentRecords == null ||  (currentRecords.size() == 0))
		{			
			String noOfRecords = (String)
			session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS) ;
			if(noOfRecords != null)
			{
				ActionMessages messages = new ActionMessages();
	    		messages.add("record", new ActionMessage("" 
	    			+ PaxTraxConstants.NO_RECORDS_FOUND));
		    	request.setAttribute(Globals.MESSAGE_KEY,messages);
			}
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.FAILURE);
			
		}
		else
		{
			String pageNumber = (String)request.getAttribute(PaxTraxConstants.PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);			
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.SUCCESS);
		}				
		
		
		String result = (String)request.getParameter(PaxTraxConstants.RESULT);
		String noOfRecords = (String)request.getParameter(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
		request.setAttribute(PaxTraxConstants.RESULT, result);
		request.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, noOfRecords);
		
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::changeLanguage::End");			
		return mapping.findForward(forward);
	}


}

