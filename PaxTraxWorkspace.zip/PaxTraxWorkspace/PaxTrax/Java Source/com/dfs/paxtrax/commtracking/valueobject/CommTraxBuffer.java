package com.dfs.paxtrax.commtracking.valueobject;

import java.io.Serializable;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 * Bean implementation class for Enterprise Bean: CommTraxBO
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 18/05/2005	Sathish			Created
 */
public class CommTraxBuffer implements Serializable {
	private int count;
	private StringBuffer buffer;
	/**
	 * Returns the buffer.
	 * @return StringBuffer
	 */
	public StringBuffer getBuffer() {
		return buffer;
	}

	/**
	 * Returns the count.
	 * @return int
	 */
	public int getCount() {
		return count;
	}

	/**
	 * Sets the buffer.
	 * @param buffer The buffer to set
	 */
	public void setBuffer(StringBuffer buffer) {
		this.buffer = buffer;
	}

	/**
	 * Sets the count.
	 * @param count The count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

}
