package com.dfs.paxtrax.commtracking.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class BranchBean extends PaxTraxValueObject
{
	private String taName = null;
	private String branchCode = null;
	private String branchName = null;
	private String contactPerson = null;
	private String address1 = null;
	private String address2 = null;
	private String city = null;
	private String country = null;
	private String phone = null;
	private String email = null;
	private String fax = null;
	private String postCode1 = null;
	private String postCode2 = null;
	private String createdUser = null;
	private String modifiedUser = null;
	private String taNameReferenceId = null;
	private String taCode = null;
	
	//Added for segment code 
	private String segmentCode = null;
	
	public String getTaCode()
	{
		return taCode;
	}
	
	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}
	
	public String getTaNameReferenceId()
	{
		return taNameReferenceId;
	}
	
	public void setTaNameReferenceId(String taNameReferenceId)
	{
		this.taNameReferenceId = taNameReferenceId;
	}
	
	public String getTaName()
	{
		return taName;
	}
	
	public void setTaName(String taName)
	{
		this.taName = taName;
	}

	public String getBranchCode()
	{
		return branchCode;
	}
	
	public void setBranchCode(String branchCode)
	{
		this.branchCode = branchCode;
	}
	
	public String getBranchName()
	{
		return branchName;
	}
	
	public void setBranchName(String branchName)
	{
		this.branchName = branchName;
	}
	
	public String getContactPerson()
	{
		return contactPerson;
	}
	
	public void setContactPerson(String contactPerson)
	{
		this.contactPerson = contactPerson;
	}
	
	public String getAddress1()
	{
		return address1;
	}
	
	public void setAddress1(String address1)
	{
		this.address1 = address1;
	}	

	public String getAddress2()
	{
		return address1;
	}
	
	public void setAddress2(String address2)
	{
		this.address2 = address2;
	}
	public String getCity()
	{
		return city;
	}
	
	public void setCity(String city)
	{
		this.city = city;
	}

	public String getCountry()
	{
		return country;
	}
	
	public void setCountry(String country)
	{
		this.country = country;
	}
	public String getPhone()
	{
		return phone;
	}
	
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getEmail()
	{
		return email;
	}
	
	public void setEmail(String email)
	{
		this.email = email;
	}
	public String getFax()
	{
		return fax;
	}
	
	public void setFax(String fax)
	{
		this.fax = fax;
	}
	public String getPostCode1()
	{
		return postCode1;
	}
	
	public void setPostCode1(String postCode1)
	{
		this.postCode1 = postCode1;
	}
	
	public String getPostCode2()
	{
		return postCode2;
	}
	
	public void setPostCode2(String postCode2)
	{
		this.postCode2 = postCode2;
	}	
	
	public String getCreatedUser()
	{
		return createdUser;
	}
	
	public void setCreatedUser(String createdUser)
	{
		this.createdUser = createdUser;
	}
	public String getModifiedUser()
	{
		return modifiedUser;
	}
	
	public void setModifiedUser(String modifiedUser)
	{
		this.modifiedUser = modifiedUser;
	}
	/**
	 * Returns the segmentCode.
	 * @return String
	 */
	public String getSegmentCode() {
		return segmentCode;
	}

	/**
	 * Sets the segmentCode.
	 * @param segmentCode The segmentCode to set
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

}