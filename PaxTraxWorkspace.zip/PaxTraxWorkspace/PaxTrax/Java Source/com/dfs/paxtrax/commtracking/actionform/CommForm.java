package com.dfs.paxtrax.commtracking.actionform;


import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;
import com.dfs.paxtrax.common.actionform.CommTraxActionForm;
import com.dfs.paxtrax.commtracking.valueobject.CommBean;

/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CommForm extends CommTraxActionForm{
	
	private CommBean commBean = null;
	
	private CommBean searchBean;

	private ArrayList taCodes = null;
	
	private ArrayList segmentList;
	/*	
	private String taCode = null;
	
	private String agencyName = null;
	
	private String agencyOwner = null;
	*/
	
	public CommBean getCommBean()
	{
		return commBean;
	}
	
	public void setCommBean(CommBean commBean)
	{
		this.commBean = commBean;
	}

	/*	
	public String getTaCode()
	{
		return taCode;
	}
	
	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}

	public String getAgencyName()
	{
		return agencyName;
	}
	
	public void setAgencyName(String agencyName)
	{
		this.agencyName = agencyName;
	}

	public String getAgencyOwner()
	{
		return agencyOwner;
	}

	public void setAgencyOwner(String agencyOwner)
	{
		this.agencyOwner = agencyOwner;
	}
	*/
	
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
	}
	/**
	 * Returns the taCodes.
	 * @return ArrayList
	 */
	public ArrayList getTaCodes() {
		return taCodes;
	}

	/**
	 * Sets the taCodes.
	 * @param taCodes The taCodes to set
	 */
	public void setTaCodes(ArrayList taCodes) {
		this.taCodes = taCodes;
	}

	/**
	 * Returns the segmentList.
	 * @return ArrayList
	 */
	public ArrayList getSegmentList() {
		return segmentList;
	}

	/**
	 * Sets the segmentList.
	 * @param segmentList The segmentList to set
	 */
	public void setSegmentList(ArrayList segmentList) {
		this.segmentList = segmentList;
	}

	/**
	 * Returns the searchBean.
	 * @return CommBean
	 */
	public CommBean getSearchBean() {
		return searchBean;
	}

	/**
	 * Sets the searchBean.
	 * @param searchBean The searchBean to set
	 */
	public void setSearchBean(CommBean searchBean) {
		this.searchBean = searchBean;
	}

}