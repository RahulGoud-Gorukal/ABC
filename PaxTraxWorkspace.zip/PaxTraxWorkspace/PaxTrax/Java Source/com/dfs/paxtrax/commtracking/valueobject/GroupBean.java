package com.dfs.paxtrax.commtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;


/**
 * 
 * The Group value object used for creation of groups.
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/11/2004	Yuvarani		Created   
 */


public class GroupBean extends PaxTraxValueObject
{
	
	//Holds Visit code
	private PAXBean paxBean = null;
	
	//Holds starting pax number
	private String startingPaxNumber = null;
	
	//Holds number of pax
	private String numberOfPax = null;
	
	//Holds group seq id
	private String groupSeqId = null;
	
	/**
	 * Returns the numberOfPax.
	 * @return String
	 */
	public String getNumberOfPax()
	{
		return numberOfPax;
	}

	/**
	 * Returns the startingPaxNumber.
	 * @return String
	 */
	public String getStartingPaxNumber()
	{
		return startingPaxNumber;
	}

	/**
	 * Sets the numberOfPax.
	 * @param numberOfPax The numberOfPax to set
	 */
	public void setNumberOfPax(String numberOfPax)
	{
		this.numberOfPax = numberOfPax;
	}

	/**
	 * Sets the startingPaxNumber.
	 * @param startingPaxNumber The startingPaxNumber to set
	 */
	public void setStartingPaxNumber(String startingPaxNumber)
	{
		this.startingPaxNumber = startingPaxNumber;
	}


	/**
	 * Returns the paxBean.
	 * @return PAXBean
	 */
	public PAXBean getPaxBean()
	{
		return paxBean;
	}

	/**
	 * Sets the paxBean.
	 * @param paxBean The paxBean to set
	 */
	public void setPaxBean(PAXBean paxBean)
	{
		this.paxBean = paxBean;
	}

	/**
	 * Returns the groupSeqId.
	 * @return String
	 */
	public String getGroupSeqId()
	{
		return groupSeqId;
	}

	/**
	 * Sets the groupSeqId.
	 * @param groupSeqId The groupSeqId to set
	 */
	public void setGroupSeqId(String groupSeqId)
	{
		this.groupSeqId = groupSeqId;
	}

}
