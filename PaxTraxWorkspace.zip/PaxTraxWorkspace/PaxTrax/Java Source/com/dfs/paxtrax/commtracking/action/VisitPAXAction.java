package com.dfs.paxtrax.commtracking.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.VisitPAXForm;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;


/**
 * This is action class which perform create and search PAX details
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 17/11/2004	Yuvarani    	Created
 */


public class VisitPAXAction extends PaxTraxAction
{

	/**
	 * Method createVisitPaxPage.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the create Visit PAX page
	 */
	public ActionForward createVisitPaxPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::VisitPAXAction::createVisiPaxPage::Begin");
			VisitPAXForm paxForm = (VisitPAXForm) form;

			PAXBean paxBean = new PAXBean();
			paxBean = initializePAXBean(paxBean);
			paxBean.getAddress().setCountry(PaxTraxConstants.DEFAULT_COUNTRY);
			paxBean.setNationality(PaxTraxConstants.DEFAULT_NATIONALITY);

			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
//			Added for CR611 changes on Jul 31,2008 --Begin
		   paxForm.setPromotionList(
			   rdDelegate.loadReferenceData(PaxTraxConstants.PROMOTION_CODE));
			paxBean.setPromotionCode("-1");
//			Added for CR611 changes on Jul 31,2008 --End
			HttpSession session = request.getSession();

			ArrayList nationalityList =
				rdDelegate.loadReferenceData(PaxTraxConstants.NATIONALITY);
			nationalityList = formatNationality(nationalityList);

			paxForm.setNationalityList(nationalityList);

			paxForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));

			String index = (String)request.getAttribute(PaxTraxConstants.INDEX);
			PaxTraxLog.logDebug("Index Value"+index);

			request.setAttribute(PaxTraxConstants.INDEX,index);
			request.setAttribute("targetpage",
				request.getAttribute("targetpage"));
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
				request.getAttribute(PaxTraxConstants.PAGE_NUMBER));
			VisitBean visit = (VisitBean)request.getAttribute(
				PaxTraxConstants.VISIT_BEAN);

			paxBean.setTravelAgentCode(visit.getTaCode());
			paxBean.setTravelAgencyName(visit.getTaName());
			paxBean.setTaBranch(visit.getTaBranchCode());
			paxBean.setTaBranchName(visit.getTaBranchName());
			paxBean.setTourCode(visit.getVisitCode());

			paxForm.setPaxBean(paxBean);
			session.setAttribute(
				PaxTraxConstants.MODULE_NAME,
				PaxTraxConstants.PASSENGER);

			PaxTraxLog.logDebug(
				"PaxTrax::VisitPAXAction::createVisiPaxPage::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::VisitPAXAction::createVisiPaxPage",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.CREATE_VISIT_PAX_PAGE);
	}

	public ActionForward searchPAXPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String indexOfRecord = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,indexOfRecord);
		return mapping.findForward("commtraxSearchPAX");
	}
	/**
	 * Method savePAXDetails.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 * The method to create a PAX record
	 */
	public ActionForward savePAXDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::VisitPAXAction::savePAXDetails::Begin");

			VisitPAXForm paxForm = (VisitPAXForm) form;
			PAXBean paxBean = paxForm.getPaxBean();

			paxBean.setAction("C");
			paxBean.setValidate("N");
			HttpSession session = request.getSession();
			String user =
				(String) session.getAttribute(PaxTraxConstants.USER_ID);

			if (user != null)
				paxBean.setUser(user);
			else
				return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);

			String index = request.getParameter(PaxTraxConstants.INDEX);
			request.setAttribute(PaxTraxConstants.INDEX,index);
			request.setAttribute("targetpage",
				request.getParameter("targetpage"));
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
				request.getParameter(PaxTraxConstants.PAGE_NUMBER));

			CommTraxDelegate delegate = new CommTraxDelegate();
			paxBean = delegate.saveVisitPAXDetails(paxBean);
			paxForm.setPaxBean(paxBean);

			PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::savePAXDetails::End");
		}
		catch (CommTraxException pe)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::VisitPAXAction::savePAXDetails",
				pe);
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + pe.getErrorCode());
			return mapping.findForward(PaxTraxConstants.CREATE_VISIT_PAX_PAGE);
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::VisitPAXAction::savePAXDetails",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.SAVE_VISIT_PAX_PAGE);
	}

	/**
	 * Method initializePAXBean.
	 *
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * The method to initialize PAX bean with all the constituent Beans
	 */

	private PAXBean initializePAXBean(PAXBean paxBean)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::VisitPAXAction::initializePAXBean::Begin");
		AddressBean addrBean = new AddressBean();

		FlightDetailsBean deptFlightBean = new FlightDetailsBean();
		deptFlightBean.setFlightType("D");

		FlightDetailsBean arrFlightBean = new FlightDetailsBean();
		arrFlightBean.setFlightType("A");

		paxBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);
		deptFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
		arrFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);

		paxBean.setAddress(addrBean);
		paxBean.setDepartureFlightDetails(deptFlightBean);
		paxBean.setArrivalFlightDetails(arrFlightBean);
		paxBean.setPrimaryFlag("N");

		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::initializePAXBean::End");
		return (paxBean);

	}

	private ArrayList formatNationality(ArrayList nationalityList)
	{
		if (nationalityList.size() > 0)
		{
			for (int i = 0; i < nationalityList.size(); i++)
			{
				ReferenceDataBean rdBean =
					(ReferenceDataBean) nationalityList.get(i);

				rdBean.setCodeValue(
					rdBean.getCodeId() + " - " + rdBean.getCodeValue());
				nationalityList.set(i, rdBean);
			}
		}

		return (nationalityList);
	}

	/**
	 * Method postCodeLookup.
	 *
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to handle the Postcode Lookup
	 */
	public ActionForward postCodeLookup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forwardPage = "";

		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::VisitPAXAction::postCodeLookup::Begin");

			VisitPAXForm paxForm = (VisitPAXForm) form;
			PAXBean paxBean = paxForm.getPaxBean();
			AddressBean addrBean = paxBean.getAddress();

			PAXDelegate delegate = new PAXDelegate();
			addrBean = delegate.postCodeLookup(addrBean);
			paxBean.setAddress(addrBean);
			paxForm.setPaxBean(paxBean);

			String index = request.getParameter(PaxTraxConstants.INDEX);
			request.setAttribute(PaxTraxConstants.INDEX,index);

			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				request.getParameter(PaxTraxConstants.PAGE_NUMBER));
			request.setAttribute("targetpage",
				request.getParameter("targetpage"));
			request.setAttribute("postCodeLookup", "true");

			PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::postCodeLookup::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::VisitPAXAction::postCodeLookup",
				pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward(PaxTraxConstants.CREATE_VISIT_PAX_PAGE));
	}

	public ActionForward confirmVisitPAX(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::confirmVisitPAX::Begin");
		VisitPAXForm visitPAXForm = (VisitPAXForm) form;
		request.setAttribute(PaxTraxConstants.INDEX,
			request.getParameter(PaxTraxConstants.INDEX));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::confirmVisitPAX::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE);
	}


	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::changeLanguage::Begin");

		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country =
			request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String page = request.getParameter(PaxTraxConstants.PAGE);

		if (language != null && country != null && page != null)
			super.changeLanguage(request, language, country);
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		if (page.equals(PaxTraxConstants.CREATE_VISIT_PAX_PAGE))
			forwardPage = PaxTraxConstants.CREATE_VISIT_PAX_PAGE;

		if (page.equals(PaxTraxConstants.SAVE_VISIT_PAX_PAGE))
			forwardPage = PaxTraxConstants.SAVE_VISIT_PAX_PAGE;

		String errorCode = request.getParameter("errc");

		if (errorCode != null)
		{
			if (!(errorCode.equals("-1")))
			{
				request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
			}
		}

		String index = request.getParameter(PaxTraxConstants.INDEX);
		if (index != null && !index.equals("null"))
		{
			request.setAttribute(PaxTraxConstants.INDEX,index);
		}

		request.setAttribute(
			PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));

		PaxTraxLog.logDebug("PaxTrax::VisitPAXAction::changeLanguage::End");
		return (mapping.findForward(forwardPage));
	}

}
