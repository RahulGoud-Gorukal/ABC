package com.dfs.paxtrax.commtracking.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;
import com.dfs.paxtrax.passenger.actionform.PAXSearchForm;
import com.dfs.paxtrax.passenger.exception.PAXException;
import com.dfs.paxtrax.passenger.service.PAXDelegate;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.passenger.valueobject.TelephoneNumberBean;


/**
 * 
 * The Action Class for the PAX Search Flow
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 				COMMENTS
 * 19/11/2004	Joseph Oommen			Created   
 */
public class CommtraxPAXSearch extends PaxTraxAction
{

	/**
	 * Method searchPAXDetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to search for PAX Details
	 */

	public ActionForward searchPAXDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::searchPAXDetails::Begin");
			
			int pageNumber = 0;
			ArrayList allRecords = null;
			ArrayList currentRecords = null;
			PAXSearchForm paxSearchForm = (PAXSearchForm) form;
			HttpSession session = request.getSession();
			String pageNumberStr =
				request.getParameter("visitPageNumber");

			String index = request.getParameter(PaxTraxConstants.INDEX);
			request.setAttribute(PaxTraxConstants.INDEX,index);
			request.setAttribute("targetpage",
				request.getParameter("targetpage"));
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
				request.getParameter(PaxTraxConstants.PAGE_NUMBER));

 			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0))
			{
				int size = 0;
				pageNumber = 1;
				PAXDelegate delegate = new PAXDelegate();

				PAXBean paxBean = new PAXBean();
				if (paxSearchForm.getPaxNumber() != null
					&& !(paxSearchForm.getPaxNumber().equals("")))
					paxBean.setPaxNumber(paxSearchForm.getPaxNumber());

				if (paxSearchForm.getLastName() != null
					&& !(paxSearchForm.getLastName().equals("")))
					paxBean.setLastName(paxSearchForm.getLastName());

				if (paxSearchForm.getFirstName() != null
					&& !(paxSearchForm.getFirstName().equals("")))
					paxBean.setFirstName(paxSearchForm.getFirstName());

				AddressBean addr = new AddressBean();

				if (paxSearchForm.getPostCodePrefix() != null
					&& !(paxSearchForm.getPostCodePrefix().equals("")))
					addr.setPostCodePrefix(paxSearchForm.getPostCodePrefix());

				if (paxSearchForm.getPostCodeSuffix() != null
					&& !(paxSearchForm.getPostCodeSuffix().equals("")))
					addr.setPostCodeSuffix(paxSearchForm.getPostCodeSuffix());

				TelephoneNumberBean teleBean = new TelephoneNumberBean();
				if (paxSearchForm.getTelephoneNumber() != null
					&& !(paxSearchForm.getTelephoneNumber().equals("")))
					teleBean.setTelephoneNumberType(
						paxSearchForm.getTelephoneNumber());

				FlightDetailsBean dept = new FlightDetailsBean();

				if (paxSearchForm.getDepartureAirlineCode() != null
					&& !(paxSearchForm.getDepartureAirlineCode().equals("-1")))
				{
					dept.setAirlineCode(
						paxSearchForm.getDepartureAirlineCode());
					dept.setAirlineCodeRefId(
						paxSearchForm.getDepartureAirlineCodeRefId());
					dept.setFlightType("D");
				}

				if (paxSearchForm.getDepartureFlightNumber() != null
					&& !(paxSearchForm.getDepartureFlightNumber().equals("")))
					dept.setFlightNumber(
						paxSearchForm.getDepartureFlightNumber());

				if (paxSearchForm.getDepartureFlightDate() != null
					&& !(paxSearchForm.getDepartureFlightDate().equals("")))
					dept.setDate(paxSearchForm.getDepartureFlightDate());

				FlightDetailsBean arr = new FlightDetailsBean();

				if (paxSearchForm.getArrivalAirlineCode() != null
					&& !(paxSearchForm.getArrivalAirlineCode().equals("-1")))
				{
					arr.setAirlineCode(paxSearchForm.getArrivalAirlineCode());
					arr.setAirlineCodeRefId(
						paxSearchForm.getArrivalAirlineCodeRefId());
					arr.setFlightType("A");
				}

				if (paxSearchForm.getArrivalFlightNumber() != null
					&& !(paxSearchForm.getArrivalFlightNumber().equals("")))
					arr.setFlightNumber(paxSearchForm.getArrivalFlightNumber());

				if (paxSearchForm.getArrivalFlightDate() != null
					&& !(paxSearchForm.getArrivalFlightDate().equals("")))
					arr.setDate(paxSearchForm.getArrivalFlightDate());

				if (paxSearchForm.getTravelAgentCode() != null
					&& !(paxSearchForm.getTravelAgentCode().equals("")))
					paxBean.setTravelAgentCode(
						paxSearchForm.getTravelAgentCode());

				paxBean.setAddress(addr);
				paxBean.setDepartureFlightDetails(dept);
				paxBean.setArrivalFlightDetails(arr);
				paxBean.setPhone(teleBean);

				CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
				ArrayList paxList = null;
				try
				{
					paxList = delegate.searchPAXDetails(paxBean);
				}
				catch (PAXException paxException)
				{
					PaxTraxLog.logError("PaxTrax::CommtraxPAXSearch::searchPAXDetails()::" 
							+ "Maximum no of records breached", paxException);
					request.setAttribute(PaxTraxConstants.REFINE_SEARCH, PaxTraxConstants.TRUE);
				}
				if (paxList == null || (paxList.size() == 0))
				{
					allRecords = paxList;
				}
				else
				{
					allRecords = commTraxDelegate.checkPax(paxList,
						paxSearchForm.getVisitPax().getTourCode());
					if ((allRecords == null) || (allRecords.size() == 0))
					{
						request.setAttribute(PaxTraxConstants.ERRORCODE,
							PaxTraxConstants.ERROR);
					}
				}
				if (allRecords != null)
					size = allRecords.size();

				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
			}
			else
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((allRecords != null) && (allRecords.size() != 0))
			{
				// Get records to be displayed for the passed page number
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
			}
			request.setAttribute(
				"visitPageNumber",
				Integer.toString(pageNumber));

			//Sets records to be displayed for the page number 
			paxSearchForm.setPaxDetails(currentRecords);

			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			
			PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::searchPAXDetails::End");
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommtraxPAXSearch::searchPAXDetails", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return (mapping.findForward("commtraxPAXSearchPage"));
	}

	/**
	 * Method searchPAXPage.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to go to the PAX Search page
	 */
	public ActionForward searchPAXPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::searchPAXPage::Begin");
			
			PAXSearchForm psForm = (PAXSearchForm) form;

			psForm.setPaxDetails(null);
			VisitBean visitBean = (VisitBean)request.getAttribute(
				PaxTraxConstants.VISIT_BEAN);
			request.setAttribute(PaxTraxConstants.VISIT_BEAN,visitBean);
 			request.setAttribute(PaxTraxConstants.INDEX,
				request.getAttribute(PaxTraxConstants.INDEX));
			request.setAttribute("targetpage",
				request.getAttribute("targetpage"));
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
				request.getAttribute(PaxTraxConstants.PAGE_NUMBER));
			HttpSession session = request.getSession();
			if (!request.getParameter(PaxTraxConstants.OPERATION).equals("maintain"))
			{
				psForm.setArrivalAirlineCode(null);
				psForm.setArrivalFlightDate(null);
				psForm.setArrivalFlightNumber(null);
				psForm.setDepartureAirlineCode(null);
				psForm.setDepartureFlightDate(null);
				psForm.setDepartureFlightNumber(null);
				psForm.setFirstName(null);
				psForm.setLastName(null);
				psForm.setPostCodePrefix(null);
				psForm.setPostCodeSuffix(null);
				psForm.setTelephoneNumber(null);
				psForm.setTravelAgentCode(null);
				psForm.setTravelAgentCode(visitBean.getTaCode());
			}

			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);

			PAXBean paxBean = new PAXBean();
			paxBean.setTourCode(visitBean.getVisitCode());
			paxBean.setTaBranch(visitBean.getTaBranchCode());
			paxBean.setTaBranchName(visitBean.getTaBranchName());
			paxBean.setTravelAgentCode(visitBean.getTaCode());
			paxBean.setTravelAgencyName(visitBean.getTaName());
			psForm.setVisitPax(paxBean);
			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
			psForm.setAirlineCodeList(
				rdDelegate.loadReferenceData(PaxTraxConstants.AIRLINE_CODE));
			psForm.setArrivalAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
			psForm.setDepartureAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);

			PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::searchPAXPage::End");
			
			return (mapping.findForward("commtraxPAXSearchPage"));
		}
		catch (PaxTraxSystemException pse)
		{
			PaxTraxLog.logError("Exception in PaxTrax::CommtraxPAXSearch::searchPAXPage", pse);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}
	}
	
	public ActionForward updateCondVist(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::updateCondVist::Begin");
		PAXSearchForm paxForm = (PAXSearchForm)form;
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		HttpSession session = request.getSession();
		
		/** 
		 * Commented by yuvarani.we have included a check box after each pax.So 
		 * no need to submit each time when they click pax number.Instead,add 
		 * button is provided to add the required pax numbers
		 */
/*		ArrayList allRecords =
			(ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);*/

		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		
/*		String indexOfRecord = request.getParameter("indexId");
		int indexId = 0;

		if (indexOfRecord != null)
		{
			indexId = Integer.parseInt(indexOfRecord);
			indexId = indexId - 1;

			PAXBean paxBean = (PAXBean) allRecords.get(indexId);

			FlightDetailsBean deptFlightBean =
				paxBean.getDepartureFlightDetails();
			deptFlightBean.setFlightType("D");
			FlightDetailsBean arrFlightBean = paxBean.getArrivalFlightDetails();
			arrFlightBean.setFlightType("A");

			paxBean.setNationalityRefId(PaxTraxConstants.NATIONALITY);

			deptFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);
			arrFlightBean.setAirlineCodeRefId(PaxTraxConstants.AIRLINE_CODE);

			paxBean.setGroupRefId(PaxTraxConstants.GROUP);

			paxBean.setDepartureFlightDetails(deptFlightBean);
			paxBean.setArrivalFlightDetails(arrFlightBean);

			paxBean.setTourCode(paxForm.getVisitPax().getTourCode());*/
			PAXBean paxBean = paxForm.getVisitPax();
			paxBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));
			commTraxDelegate.updateCondVist(paxForm.getPaxDetails(),paxBean);

//		}
		request.setAttribute(PaxTraxConstants.OPERATION,PaxTraxConstants.MAINTAIN);
		PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::updateCondVist::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_VISIT_DETAIL_PAGE);
	}
	
	
	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::changeLanguage::Begin");
		
		String forwardPage = "";
		
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String result = request.getParameter("res");
		String pageNumber = request.getParameter("pN");
		
		if(language!=null && country!=null && result!=null)		
		{
			super.changeLanguage(request, language, country);
			forwardPage = "commtraxPAXSearchPage";			
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;					
		
		if(result.equals(PaxTraxConstants.SUCCESS))
		{
			request.setAttribute("visitPageNumber",pageNumber);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		}
		else
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);		
			
		String index = request.getParameter(PaxTraxConstants.INDEX);
		request.setAttribute(PaxTraxConstants.INDEX,index);
		request.setAttribute("targetpage",
			request.getParameter("targetpage"));
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, 
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);
		if (errorCode !=null && !errorCode.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE,errorCode);
		}
		PaxTraxLog.logDebug("PaxTrax::CommtraxPAXSearch::changeLanguage::End");	
		return(mapping.findForward(forwardPage));
	}

}
