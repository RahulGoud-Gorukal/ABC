package com.dfs.paxtrax.commtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.commtracking.valueobject.GroupBean;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;


/**
 * 
 * The Action Form used for the group
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/11/2004	Yuvarani			Created   
 */


public class GroupForm extends PaxTraxActionForm
{
	
	//Holds Group bean
	private GroupBean groupBean = null;
	
	//Holds visit bean
	private VisitBean groupVisitBean = null;
	
	//Holds Group arraylist
	private ArrayList groupList = null;

	/** The List of all Airline Code values */
	private ArrayList airlineCodeList = null;

	/**
	 * Returns the groupBean.
	 * @return GroupBean
	 */
	
	//Added by selvam for Ticket # 283759  starts 
	private ArrayList nationalityList = null;
	//Added by selvam for Ticket # 283759  ends
	public GroupBean getGroupBean()
	{
		return groupBean;
	}

	/**
	 * Returns the groupList.
	 * @return ArrayList
	 */
	public ArrayList getGroupList()
	{
		return groupList;
	}

	/**
	 * Sets the groupBean.
	 * @param groupBean The groupBean to set
	 */
	public void setGroupBean(GroupBean groupBean)
	{
		this.groupBean = groupBean;
	}

	/**
	 * Sets the groupList.
	 * @param groupList The groupList to set
	 */
	public void setGroupList(ArrayList groupList)
	{
		this.groupList = groupList;
	}

	/**
	 * Returns the airlineCodeList.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodeList()
	{
		return airlineCodeList;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setAirlineCodeList(ArrayList airlineCodeList)
	{
		this.airlineCodeList = airlineCodeList;
	}


	/**
	 * Returns the groupVisitBean.
	 * @return VisitBean
	 */
	public VisitBean getGroupVisitBean()
	{
		return groupVisitBean;
	}

	/**
	 * Sets the groupVisitBean.
	 * @param groupVisitBean The groupVisitBean to set
	 */
	public void setGroupVisitBean(VisitBean groupVisitBean)
	{
		this.groupVisitBean = groupVisitBean;
	}

	/**
	 * @return
	 */
	public ArrayList getNationalityList() {
		return nationalityList;
	}

	/**
	 * @param list
	 */
	public void setNationalityList(ArrayList list) {
		nationalityList = list;
	}

}
