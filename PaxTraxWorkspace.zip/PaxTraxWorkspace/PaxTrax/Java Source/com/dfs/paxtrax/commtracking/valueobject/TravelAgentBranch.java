package com.dfs.paxtrax.commtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;



/**
 * 
 * The Group value object used for creation of groups.
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 05/12/2004	P.C. Sathish	Created   
 */ 
public class TravelAgentBranch extends PaxTraxValueObject {
	
	private String taBranchCode;
	private String taBranchName;
	private String displayLabel;


	/**
	 * Returns the taBranchCode.
	 * @return String
	 */
	public String getTaBranchCode() {
		return taBranchCode;
	}

	/**
	 * Returns the taBranchName.
	 * @return String
	 */
	public String getTaBranchName() {
		return taBranchName;
	}

	/**
	 * Sets the taBranchCode.
	 * @param taBranchCode The taBranchCode to set
	 */
	public void setTaBranchCode(String taBranchCode) {
		this.taBranchCode = taBranchCode;
	}

	/**
	 * Sets the taBranchName.
	 * @param taBranchName The taBranchName to set
	 */
	public void setTaBranchName(String taBranchName) {
		this.taBranchName = taBranchName;
	}

	/**
	 * Returns the displayLabel.
	 * @return String
	 */
	public String getDisplayLabel() {
		return displayLabel;
	}

	/**
	 * Sets the displayLabel.
	 * @param displayLabel The displayLabel to set
	 */
	public void setDisplayLabel(String displayLabel) {
		this.displayLabel = displayLabel;
	}

}
