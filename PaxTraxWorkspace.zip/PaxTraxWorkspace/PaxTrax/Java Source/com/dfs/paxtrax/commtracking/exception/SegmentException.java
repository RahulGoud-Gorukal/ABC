package com.dfs.paxtrax.commtracking.exception;

import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxException;

/**
 * @author 116038
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SegmentException extends PaxTraxException{
public SegmentException(int errorCode) {
		super(errorCode);
	}
	  public SegmentException(Exception actualException) {

        super(PaxTraxErrorMessages.PT_SYSEXCEPTION, actualException);
    }

}
