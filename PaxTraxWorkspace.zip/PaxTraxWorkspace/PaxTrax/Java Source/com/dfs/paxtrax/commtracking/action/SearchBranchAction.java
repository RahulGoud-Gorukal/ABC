package com.dfs.paxtrax.commtracking.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.action.CommTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.SearchBranchForm;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.BranchBean;

public class SearchBranchAction extends CommTraxAction
{
	public ActionForward searchBranch(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("CommTrax::SearchBranchAction::searchBranch::Begin");

		String fromMenu = (String)request.getParameter("fromMenu");

		if (fromMenu == null)
		{
		SearchBranchForm searchBranchForm = (SearchBranchForm) form;
		CommTraxDelegate comDelegate = new CommTraxDelegate();


		HttpSession session = request.getSession();
		int pageNumber = 0;
		ArrayList totalBranchRecords = null;
		ArrayList currentPageBranchRecords = null;


		String pageNumberStr =
			request.getParameter(PaxTraxConstants.PAGE_NUMBER);


		/* If page number is null or empty it sets null otherwise
		 * it is same
		 */
		pageNumberStr =
			((pageNumberStr == null)
				|| pageNumberStr.equals(SQLConstants.BLANK))
				? null
				: pageNumberStr;

		if ((pageNumberStr != null))
			pageNumber = Integer.parseInt(pageNumberStr);



		if (pageNumber == 0)
		{
			int size = 0;
			pageNumber = 1;

			BranchBean branchBean = new BranchBean();
			branchBean.setTaCode(searchBranchForm.getTaCode());
			branchBean.setBranchCode(searchBranchForm.getBranchCode());
			branchBean.setBranchName(searchBranchForm.getBranchName());
			branchBean.setCountry(searchBranchForm.getCountry());
			branchBean.setCity(searchBranchForm.getCity());
			branchBean.setSegmentCode(searchBranchForm.getSegmentCode());

			totalBranchRecords = comDelegate.getBranchDetails(branchBean);
			if(totalBranchRecords != null)
			{
				size = totalBranchRecords.size();
			}
			session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
			session.setAttribute(PaxTraxConstants.ALL_RECORDS, totalBranchRecords);
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
			session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
		}
		else
		{
			totalBranchRecords = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_RECORDS);
		}

		PaginationHelper helper = PaginationHelper.getInstance();

		if ((totalBranchRecords != null) && (totalBranchRecords.size() !=0))
		{
		    currentPageBranchRecords = helper.getCurrentTableContent(totalBranchRecords,
		pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
		}



		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
		searchBranchForm.setBranchCollection(currentPageBranchRecords);
	    request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		//PaxTraxLog.logDebug("CommTrax::COMMAction::searchTravelAgent::Output Records"+totalBranchRecords);
		}
		else
		{
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
				return mapping.findForward("searchBranch");
		}
		return mapping.findForward("searchBranch");
	}
	
	
	
	
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		/*
		PaxTraxLog.logDebug("PaxTrax::SearchBranchAction::changeLanguage::Begin");			
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		HttpSession session = request.getSession();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if(operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION,operation);
		}			
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page.equals("searchBranch"))
		{			
			forward = "searchBranch";
		}
		SearchBranchForm searchBranchForm = (SearchBranchForm) form;				
		ArrayList currentRecords = searchBranchForm.getBranchCollection();
		if(currentRecords == null ||  (currentRecords.size() == 0))
		{			
			String noOfRecords = (String)
			session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS) ;
			if(noOfRecords != null)
			{
				ActionMessages messages = new ActionMessages();
	    		messages.add("record", new ActionMessage("" 
	    			+ PaxTraxConstants.NO_RECORDS_FOUND));
		    	request.setAttribute(Globals.MESSAGE_KEY,messages);
			}
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.FAILURE);
			
		}
		else
		{
			String pageNumber = (String)request.getAttribute(PaxTraxConstants.PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);			
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.SUCCESS);
		}				
		
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::changeLanguage::End");			
		return mapping.findForward(forward);
		*/
		
		PaxTraxLog.logDebug("CommTrax::SearchBranchAction::changeLanguage::Begin");

		String forwardPage = "";

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country =
			request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String result = request.getParameter("res");
		String pageNumber = request.getParameter("pageNumber");

		if (language != null && country != null && result != null)
		{
			super.changeLanguage(request, language, country);
			forwardPage = "searchBranch";
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;

		if (result.equals(PaxTraxConstants.SUCCESS))
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		}
		else
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);

		PaxTraxLog.logDebug("CommTrax::SearchBranchAction::changeLanguage::End");
		return (mapping.findForward(forwardPage));
	}
	
}

