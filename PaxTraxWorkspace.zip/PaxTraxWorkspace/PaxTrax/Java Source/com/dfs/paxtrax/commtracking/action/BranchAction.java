package com.dfs.paxtrax.commtracking.action;

import java.util.ArrayList;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.commtracking.valueobject.BranchBean;
import com.dfs.paxtrax.commtracking.actionform.BranchForm;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.CommTraxAction;


public class BranchAction extends CommTraxAction
{
	public ActionForward createBranch(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
		
		PaxTraxLog.logDebug("CommTrax::COMMAction::createBranch::Begin");
		BranchForm branchForm = (BranchForm) form;
		ArrayList taNames = new ArrayList();
		ArrayList segmentCodes = new ArrayList();

		BranchBean branchBean = branchForm.getBranchBean();
		String param = request.getParameter("from");
		if (param == null)
		{	
			branchBean = new BranchBean();
			
					
		}
		branchForm.setBranchBean(branchBean);
		CommTraxDelegate commDelegate = new CommTraxDelegate();
		
		taNames = commDelegate.loadTANames();

		branchForm.setTaNames(taNames);
		String taCode = branchBean.getTaName();
		segmentCodes = commDelegate.loadSegmentCodes(taCode);		
		branchForm.setSegmentCodes(segmentCodes);
		return mapping.findForward("createBranch");
	}


	public ActionForward confirmBranch(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	{
		PaxTraxLog.logDebug("CommTrax::COMMAction::confirmBranch::Begin");
		BranchForm branchForm = (BranchForm) form;
		CommTraxDelegate commDelegate = new CommTraxDelegate();
		BranchBean branchBean = null;
		try
		{
			branchBean = branchForm.getBranchBean();
			String taLabel = branchBean.getTaName()
									 + "-" 
									 + getTravelAgencyName(
											branchBean.getTaName(), 
											branchForm.getTaNames());
			
			branchForm.setTaLabel(taLabel);
			boolean returnValue = commDelegate.createBranchDetails(branchBean);
			if(branchBean.getSegmentCode().equals("-1"))
				branchBean.setSegmentCode("");
			request.setAttribute("BranchFormValues", branchBean);
			branchForm.setBranchBean(branchBean);
			return mapping.findForward("confirmBranch");
		}
		catch(CommTraxException cex)
		{
			PaxTraxLog.logError("CommTrax::BranchAction::confirmBranch::",cex);
			request.setAttribute(PaxTraxConstants.ERRORCODE,"Yes");
			return mapping.findForward("createBranch");
		}
		catch(PaxTraxSystemException sqlEx)
		{
			PaxTraxLog.logError("CommTrax::BranchAction::confirmBranch", sqlEx);
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}
	}

	public ActionForward modifyBranch(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("CommTrax::BranchAction::modifyBranch::BEGIN");
		String pageNumber = (String)request.getParameter("pageNumber");
		
		BranchForm branchForm = (BranchForm) form;
		BranchBean branchBean = new BranchBean();
		String taCode = (String)request.getParameter("taCode");
		String branchCode = (String)request.getParameter("branchCode");
		CommTraxDelegate commDelegate = new CommTraxDelegate();
		ArrayList branchDetails = null;
		branchDetails = commDelegate.getBranch(taCode, branchCode);
		branchBean = (BranchBean)branchDetails.get(0);
		
		
		ArrayList segmentCodes = new ArrayList();
		
		segmentCodes = commDelegate.loadSegmentCodes(taCode);
		branchForm.setSegmentCodes(segmentCodes);
		branchForm.setBranchBean(branchBean);

		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		request.setAttribute("BranchDetails", branchDetails);
		return mapping.findForward("modifyBranch");
	}


	public ActionForward confirmModifyBranch(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("CommTrax::BranchAction::confirmModifyBranch::BEGIN");
		BranchForm branchForm = (BranchForm) form;
		BranchBean branchBean = branchForm.getBranchBean();

		CommTraxDelegate commDelegate = new CommTraxDelegate();
		boolean saveStatus = false;
		String segmentCode = branchBean.getSegmentCode();
		
		saveStatus = commDelegate.saveBranchDetails(branchBean);
		request.setAttribute("BranchFormValues", branchBean);
		if(branchBean.getSegmentCode().equals("-1"))
				branchBean.setSegmentCode("");
		branchForm.setBranchBean(branchBean);
		if(saveStatus)
		{
			PaxTraxLog.logDebug("CommTrax::BranchAction::deleteBranch::ModifiedSuccessfully");
		}
		return mapping.findForward("confirmModifyBranch");
	}


	public ActionForward deleteBranch(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response
	)
	throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("CommTrax::BranchAction::deleteBranch::BEGIN");
		BranchForm branchForm = (BranchForm) form;
		BranchBean branchBean = branchForm.getBranchBean();

		CommTraxDelegate commDelegate = new CommTraxDelegate();
		boolean deleteStatus = false;

			deleteStatus = commDelegate.deleteBranch(branchBean);
			request.setAttribute("BranchFormValues", branchBean);
			if(branchBean.getSegmentCode().equals("-1"))
				branchBean.setSegmentCode("");
			branchForm.setBranchBean(branchBean);
			if(deleteStatus)
			{
				PaxTraxLog.logDebug("CommTrax::BranchAction::deleteBranch::DeletedSuccessfully");
			}
		return mapping.findForward("deleteBranch");
	}
	
	private String getTravelAgencyName(String taCode, ArrayList travelAgentList) {
		for (int i = 0; i < travelAgentList.size(); i++) {
			ReferenceDataBean refBean = (ReferenceDataBean) travelAgentList.get(i);
			if (refBean.getCodeId().equals(taCode))
				return refBean.getCodeValue();
		}
		return null;
	}
		
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		{
		String forward = null;
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if(page.equals(PaxTraxConstants.SYSTEM_ERROR))
		{
			forward=PaxTraxConstants.SYSTEM_ERROR;
		}
		else
		{
			forward = page;
		}
		
		String errorCode = request.getParameter("errc");
		if (errorCode != null && !errorCode.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE,errorCode);
		}
		String pageNumber = (String)request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		return mapping.findForward(forward);

	}
}