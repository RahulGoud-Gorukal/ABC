/*
 * This file is created for Generating a report on the TA commission rate Changes 
 * Created on Sep 23, 2010
 * Create for CR1832 - Viji
 *
 */
package com.dfs.paxtrax.commtracking.action;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

/*import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.apache.commons.collections.comparators.ReverseComparator;
*/
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.passenger.exception.PAXException;


import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.CommChangesReportBean;

/**
 * @author 138182
 *
 */
public class TACommissionTrackingReportGenerator extends TimerTask {

	public TACommissionTrackingReportGenerator() {
	}

	public void init() {
	}

	public void run() {
		try {
			generateTACommChangeReport();
		} catch (PaxTraxSystemException paxtraxSystemException) {
			PaxTraxLog.logError(
				"PaxtraxPurgeScheduler : run()  PaxTrax System Exception ",
				paxtraxSystemException);
		}
	}

	public static void main(String[] args) {
		System.out.println(
			"Starting to generate report!!! - TACommissionTrackingReportGenerator");

		System.out.println(
			"Report is generated!!! - TACommissionTrackingReportGenerator");
	}

	private void createCell(
		HSSFRow row,
		HSSFCell cell,
		int cellPosition,
		boolean newCell,
		int cellAlignment,
		int cellType,
		HSSFCellStyle style,
		String strValue,
		double doubleValue) {
		if (newCell)
			cell = row.createCell((short) cellPosition);

		cell.setCellType(cellType);
		style.setAlignment((short) cellAlignment);

		if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC)
			cell.setCellValue(doubleValue);
		else
			cell.setCellValue(strValue);

		cell.setCellStyle(style);
	}

	void generateTACommChangeReport() throws PaxTraxSystemException {

		ArrayList resultList = new ArrayList();

		CommTraxDelegate commtraxDelegate = new CommTraxDelegate();

	//	String groupColumnArray1[] = { "", "", "", "", "" };
		String columnArray[] =
			{	"Action",
				"TA Agent Code",
				"TA Agent Name",
				"TA Agency Owner",
				"Sales Type",
				"Pax Visit Type",
				"Original Rate(%)",
				"New Rate(%)",
				"Created Effective Date",
				"Modified By User",
				"Updated Date",
				"Time Record of Change" };

		try {

			ArrayList taCommChanges = new ArrayList();
			taCommChanges = commtraxDelegate.getTACommChanges();
			resultList = taCommChanges;
			int size = 0;
			Date today = new Date();

			if (taCommChanges != null)
				size = taCommChanges.size();

			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("TA_Commission_Changes");

			//sheet.setFitToPage(true);
			sheet.setDefaultColumnWidth((short) 16);
			
			sheet.setColumnWidth((short)9,(short) 19);
			
			//Create Header Font
			HSSFFont fontHeader = wb.createFont();
			fontHeader.setFontHeightInPoints((short) 8);
			fontHeader.setFontName(HSSFFont.FONT_ARIAL);
			fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			fontHeader.setColor(HSSFColor.WHITE.index);

			//Create font for Date and Time
			HSSFFont fontWhite = wb.createFont();
			fontWhite.setFontHeightInPoints((short) 8);
			fontWhite.setFontName(HSSFFont.FONT_ARIAL);
			fontWhite.setColor(HSSFColor.DARK_RED.index);

			//Create font for the workbook Data cells
			HSSFFont font = wb.createFont();
			font.setFontHeightInPoints((short) 8);
			font.setFontName(HSSFFont.FONT_ARIAL);

			//Style for the Header cells
			HSSFCellStyle styleHeader = wb.createCellStyle();
			styleHeader.setFont(fontHeader);
			styleHeader.setFillForegroundColor(HSSFColor.DARK_RED.index);
			styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
/*			styleHeader.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			styleHeader.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			styleHeader.setBorderTop(HSSFCellStyle.BORDER_THIN);
			styleHeader.setBorderRight(HSSFCellStyle.BORDER_THIN);
*/
			//Style for the Side Title cells
			HSSFCellStyle styleTitle = wb.createCellStyle();
			styleTitle.setFont(fontWhite);
			/*styleTitle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			styleTitle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			styleTitle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			styleTitle.setBorderRight(HSSFCellStyle.BORDER_THIN);
*/
			//Style for the Data cells
			HSSFCellStyle style = wb.createCellStyle();
			style.setFont(font);
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			
//			Style for the Data cells
//			HSSFCellStyle style_user = wb.createCellStyle();
//			style_user.setFont(font);
//			style_user.setBorderBottom(HSSFCellStyle.BORDER_THIN);
//			style_user.setBorderLeft(HSSFCellStyle.BORDER_THIN);
//			style_user.setBorderTop(HSSFCellStyle.BORDER_THIN);
//			style_user.setBorderRight(HSSFCellStyle.BORDER_THIN);

			
			//Style for numeric data cells
			HSSFCellStyle styleNum = wb.createCellStyle();
			HSSFDataFormat format = wb.createDataFormat();
			styleNum.setDataFormat(format.getFormat("#,##0.00"));
			styleNum.setFont(font);
			styleNum.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			styleNum.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			styleNum.setBorderTop(HSSFCellStyle.BORDER_THIN);
			styleNum.setBorderRight(HSSFCellStyle.BORDER_THIN);

			//Create Title rows
			HSSFRow row = sheet.createRow((short) 0);
			HSSFCell cell = null;
			
			
			sheet.addMergedRegion(new Region(0, (short) 0, 0, (short) 11)); //12 Columns
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.VERTICAL_CENTER,
				HSSFCell.CELL_TYPE_STRING,
				styleHeader,
				PaxTraxConstants.TA_COMMISSION_RATE_CHANGES_REPORT,
				0.0);
			//cell = row.getCell((short)0);
			//cell.setCellStyle(styleHeader);

			row = sheet.createRow((short) 1);
			
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.VERTICAL_CENTER,
				HSSFCell.CELL_TYPE_STRING,
				styleHeader,
				"",
				0.0);
			sheet.addMergedRegion(new Region(0, (short) 0, 1, (short) 11));
			cell = row.getCell((short) 0);
			cell.setCellStyle(styleHeader);

			row = sheet.createRow((short) 2);
			sheet.addMergedRegion(new Region(2, (short) 0, 2, (short) 11));
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.ALIGN_LEFT,
				HSSFCell.CELL_TYPE_STRING,
				styleTitle,
				"Date :" + sdf.format(today),
				0.0);

			row = sheet.createRow((short) 3);
			sheet.addMergedRegion(new Region(3, (short) 0, 3, (short) 11));
			sdf = new SimpleDateFormat("hh:mm:ss a");
			createCell(
				row,
				cell,
				0,
				true,
				HSSFCellStyle.ALIGN_LEFT,
				HSSFCell.CELL_TYPE_STRING,
				styleTitle,
				"Time : " + sdf.format(today),
				0.0);

		//	int groupColnum = 1;
			row = sheet.createRow((short) 4);


			int colnum = 1;
			row = sheet.createRow((short) 5);
			for (colnum = 0; colnum < columnArray.length; colnum++) {

				createCell(
					row,
					cell,
					colnum,
					true,
					HSSFCellStyle.ALIGN_LEFT,
					HSSFCell.CELL_TYPE_STRING,
					styleHeader,
					columnArray[colnum],
					0.0);

			}

			sheet.createFreezePane(0, 6, 0, 6);

			int deptRow = 6;
			int col = 0;
			for (int j = 0; j < size; j++) {
				row = sheet.createRow(deptRow);
				CommChangesReportBean tempBean =
					(CommChangesReportBean) resultList.get(j);

				taCommChanges.add(tempBean);

				createCell(
					row,
					cell,
					col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					"Update Rate",
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getTaCode(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getTaAgencyName(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getTaAgencyOwner(),
					0.0);

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getPurchaseRefID(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getVisitType(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getOriginal_Rate(),
					0.0);

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getNew_Rate(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getCreatedDate(),
					0.0);
				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					tempBean.getModifiedUser(),
					0.0);
								
				Date updatedDate = new Date();

				SimpleDateFormat df =
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				updatedDate = df.parse(tempBean.getModifiedDate());
				df = new SimpleDateFormat("yyyy-MM-dd");
			/*	System.out.println(
					"==================MODIFIED DATE: "
						+ tempBean.getModifiedDate());*/

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					df.format(updatedDate),
					0.0);

				String date = tempBean.getModifiedDate();
				date = date.substring(0,date.lastIndexOf(".")==-1 ? 0:date.lastIndexOf("."));
				df = new SimpleDateFormat("HH:mm:ss");

				createCell(
					row,
					cell,
					++col,
					true,
					HSSFCellStyle.ALIGN_GENERAL,
					HSSFCell.CELL_TYPE_STRING,
					style,
					df.format(updatedDate),
					0.0);

				col = 0;
				deptRow++;

			}
			
			
			if (resultList != null && resultList.size() > 0) {
				
				sdf = new SimpleDateFormat("yyyyMMdd");
				FileOutputStream fileOut =
					new FileOutputStream(
						PaxTraxConstants.SALES_REPORTS_BASE_PATH
							+ sdf.format(today) + "_" 
							+ PaxTraxConstants.TA_COMM_CHANGE_REPORT
							+ ".xls");

				wb.write(fileOut);
				fileOut.close();

			}

		} catch (ParseException pe) {
			PaxTraxLog.logError(
				"ParseException caught :SalesReportAction::generateSalesByAssociateReport ",
				pe);
			pe.printStackTrace();
		} catch (Exception e) {
			PaxTraxLog.logError(
				"Exception caught :SalesReportAction::generateSalesByAssociateReport ",
				e);
			e.printStackTrace();
		}

	}

}
