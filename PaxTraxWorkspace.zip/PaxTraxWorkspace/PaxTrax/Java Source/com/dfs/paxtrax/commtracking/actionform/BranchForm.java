package com.dfs.paxtrax.commtracking.actionform;

import java.util.ArrayList;

import com.dfs.paxtrax.commtracking.valueobject.BranchBean;
import com.dfs.paxtrax.common.actionform.CommTraxActionForm;

public class BranchForm extends CommTraxActionForm
{
	private BranchBean branchBean = null;
	private ArrayList taNames = null;
	private String taNameSelected = null;
	private String taLabel;
	private ArrayList segmentCodes = null;
	
	public BranchBean getBranchBean()
	{
		return branchBean;
	}

	public void setBranchBean(BranchBean branchBean)
	{
		this.branchBean = branchBean;
	}

	public ArrayList getTaNames()
	{
		return taNames;
	}

	public void setTaNames(ArrayList taNames)
	{
		this.taNames = taNames;
	}

	public String getTaNameSelected()
	{
		return taNameSelected;
	}

	public void setTaNameSelected(String taNameSelected)
	{
		this.taNameSelected = taNameSelected;
	}

	/**
	 * Returns the taLabel.
	 * @return String
	 */
	public String getTaLabel() {
		return taLabel;
	}

	/**
	 * Sets the taLabel.
	 * @param taLabel The taLabel to set
	 */
	public void setTaLabel(String taLabel) {
		this.taLabel = taLabel;
	}

	/**
	 * Returns the segmentCodes.
	 * @return ArrayList
	 */
	public ArrayList getSegmentCodes() {
		return segmentCodes;
	}

	/**
	 * Sets the segmentCodes.
	 * @param segmentCodes The segmentCodes to set
	 */
	public void setSegmentCodes(ArrayList segmentCodes) {
		this.segmentCodes = segmentCodes;
	}

}