package com.dfs.paxtrax.commtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;


/**
 *
 * The Action Form used for the PAX Search
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 17/11/2004	Yuvarani			Created
 */


public class VisitPAXForm extends PaxTraxActionForm
{

	/** The PAX Bean on the form - holds all the PAX properties */
	private PAXBean paxBean = null;

	/** The List of all country values */
	private ArrayList countryList = null;

	/** The List of all Nationality values */
	private ArrayList nationalityList = null;

	/** The List of all Airline Code values */
	private ArrayList airlineCodeList = null;

	/** The List of all Group values */
	private ArrayList groupList = null;

	/* The Boolean variable that represents the state of the checkbox in the PAX Screens */
	private boolean primaryPAXCheckbox = false;

	/* The Boolean variable that represents the state of the checkbox in the PAX Screens */
	private boolean outboundPAXCheckbox = false;
//	Added for CR611 changes on Jul 30, 2008 --Begin
	/** The List of all Promotion values */
	private ArrayList promotionList = null;

//	Added for CR611 changes on Jul 30, 2008 --End
	/** The Collection which will hold all the search results */
	private ArrayList paxDetails = null;

	public PAXBean getPaxBean()
	{
		return paxBean;
	}

	public void setPaxBean(PAXBean paxBean)
	{
		this.paxBean = paxBean;
	}

	/**
	 * Returns the airlineCodeList.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodeList()
	{
		return airlineCodeList;
	}

	/**
	 * Returns the countryList.
	 * @return ArrayList
	 */
	public ArrayList getCountryList()
	{
		return countryList;
	}

	/**
	 * Returns the nationalityList.
	 * @return ArrayList
	 */
	public ArrayList getNationalityList()
	{
		return nationalityList;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setAirlineCodeList(ArrayList airlineCodeList)
	{
		this.airlineCodeList = airlineCodeList;
	}

	/**
	 * Sets the countryList.
	 * @param countryList The countryList to set
	 */
	public void setCountryList(ArrayList countryList)
	{
		this.countryList = countryList;
	}

	/**
	 * Sets the nationalityList.
	 * @param nationalityList The nationalityList to set
	 */
	public void setNationalityList(ArrayList nationalityList)
	{
		this.nationalityList = nationalityList;
	}

	/**
	 * Returns the groupList.
	 * @return ArrayList
	 */
	public ArrayList getGroupList()
	{
		return groupList;
	}

	/**
	 * Sets the groupList.
	 * @param groupList The groupList to set
	 */
	public void setGroupList(ArrayList groupList)
	{
		this.groupList = groupList;
	}

	/**
	 * Returns the primaryPAXCheckbox.
	 * @return boolean
	 */
	public boolean getPrimaryPAXCheckbox()
	{
		return primaryPAXCheckbox;
	}

	/**
	 * Sets the primaryPAXCheckbox.
	 * @param primaryPAXCheckbox The primaryPAXCheckbox to set
	 */
	public void setPrimaryPAXCheckbox(boolean primaryPAXCheckbox)
	{
		this.primaryPAXCheckbox = primaryPAXCheckbox;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		primaryPAXCheckbox = false;
		if(paxBean!=null)
			paxBean.setPrimaryPAXNumber(null);
		outboundPAXCheckbox = false;
	}


	/**
	 * Returns the paxDetails.
	 * @return ArrayList
	 */
	public ArrayList getPaxDetails()
	{
		return paxDetails;
	}

	/**
	 * Sets the paxDetails.
	 * @param paxDetails The paxDetails to set
	 */
	public void setPaxDetails(ArrayList paxDetails)
	{
		this.paxDetails = paxDetails;
	}

	/**
	 * Returns the outboundPAXCheckbox.
	 * @return boolean
	 */
	public boolean getOutboundPAXCheckbox() {
		return outboundPAXCheckbox;
	}

	/**
	 * Sets the outboundPAXCheckbox.
	 * @param outboundPAXCheckbox The outboundPAXCheckbox to set
	 */
	public void setOutboundPAXCheckbox(boolean outboundPAXCheckbox) {
		this.outboundPAXCheckbox = outboundPAXCheckbox;
	}

	/**
	 * @return
	 */
	public ArrayList getPromotionList() {
		return promotionList;
	}

	/**
	 * @param list
	 */
	public void setPromotionList(ArrayList list) {
		promotionList = list;
	}

}
