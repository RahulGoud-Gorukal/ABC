package com.dfs.paxtrax.commtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.common.action.CommTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.actionform.VisitForm;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;

/**
* This action class is used for inserting and updating cage records
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 18/05/2004    Joseph Oommen A Created
* 5/08/2005     Vani.J 			TA Commission changes
*/
public class MaintainTaCommAction extends CommTraxAction
{

	String forward = null;

	/**
	* Forwards to create visit page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Visit Page
	*/
	public ActionForward loadMaintainTaCommissionPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::MaintainTaCommAction::loadMaintainTaCommissionPage::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean visitBean = new VisitBean();
		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
		ArrayList arlTaNames = new ArrayList();

		arlTaNames = commTraxDelegate.loadTaName();
		visitForm.setArlTaNames(arlTaNames);
		visitForm.setStartVisitBean(visitBean);

        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.COMMTRAX);
	    request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
		forward = PaxTraxConstants.MAINTAIN_TA_COMMISSION_PAGE;
		PaxTraxLog.logDebug("PaxTrax::MaintainTaCommAction::loadMaintainTaCommissionPage::End");
		return mapping.findForward(forward);
	}

	public ActionForward searchMaintainTaCommission(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
			PaxTraxLog.logDebug("CommTrax::MaintainTaCommAction::"
				+"searchMaintainTaCommission::Begin");
			VisitForm visitForm = (VisitForm) form;
			VisitBean visitBean = visitForm.getStartVisitBean();
			CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
			HttpSession session = request.getSession();
			int pageNumber = 0;
			ArrayList totalTARecords = null;
			ArrayList currentPageTARecords = null;

			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =	((pageNumberStr == null) || pageNumberStr.equals(SQLConstants.BLANK)) ? null : pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			if (pageNumber == 0)
			{
				int size = 0;
				pageNumber = 1;
				totalTARecords = commTraxDelegate.getTADetails(visitBean);
				if(totalTARecords != null)
				{
					size = totalTARecords.size();
				}
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, totalTARecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
			}
			else
			{
				totalTARecords = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_RECORDS);
			}

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((totalTARecords != null) && (totalTARecords.size() !=0))
			{
			    currentPageTARecords = helper.getCurrentTableContent(totalTARecords,
		    	pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
			}

			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
			visitForm.setTaCollection(currentPageTARecords);
		    request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug("CommTrax::MaintainTaCommAction::searchMaintainTaCommission::Output Records"+totalTARecords);
			forward = PaxTraxConstants.SEARCH_TA_COMMISSION_PAGE;
			return mapping.findForward(forward);
	}

	/**
	 * Displays TaCommission.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	public ActionForward insertTaCommission(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
			PaxTraxLog.logDebug("CommTrax::MaintainTaCommAction::"
				+"insertTaCommission::Begin");
			VisitForm visitForm = (VisitForm) form;

			ArrayList arlCodeRef = new ArrayList();
			String taCode = request.getParameter("taCode");
			String agencyName = request.getParameter("agencyName");
			String agencyOwner = request.getParameter("agencyOwner");

			CommTraxDelegate commTraxDelegate = new CommTraxDelegate();
			
			/* Commented by Vani on 06/08/2005
			 * This change was done to dynamically populate the
			 * leased vendors of a TA and to add RAC classification based commission */

			//	VisitBean visitBean = commTraxDelegate.getMaintainTaCommission(taCode);
			//	arlCodeRef = commTraxDelegate.getCodeRef();

			 //Code addition starts here
			arlCodeRef =  commTraxDelegate.getTaCommissions(taCode);
			VisitBean visitBean = new VisitBean();
			 //Code addition ends here

			visitForm.setArlCodeRef(arlCodeRef);
			visitBean.setTaCode(taCode);
			visitBean.setAgencyName(agencyName);
			visitBean.setAgencyOwner(agencyOwner);
			visitForm.setVisitBean(visitBean);

			forward = PaxTraxConstants.INSERT_TA_COMMISSION_PAGE;

			PaxTraxLog.logDebug("CommTrax::MaintainTaCommAction::"
				+"insertTaCommission::End");
			return (mapping.findForward(forward));
	}

	/**
	 * Inserts TaCommission.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	public ActionForward confirmMaintainTaCommission(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,CommTraxException
	{
	
		PaxTraxLog.logDebug("CommTrax::MaintainTaCommAction::"
			+"confirmMaintainTaCommission::Begin");
		VisitForm visitForm = (VisitForm) form;
		VisitBean vBean = visitForm.getVisitBean();

		ArrayList arlCodeRef = new ArrayList();
		arlCodeRef= visitForm.getArlCodeRef();


		CommTraxDelegate commTraxDelegate = new CommTraxDelegate();

		HttpSession session = request.getSession();
		vBean.setUser((String) session.getAttribute(PaxTraxConstants.USER_ID));

		/* Commented by Vani on 06/08/2005
		 * This change was done to dynamically populate the
		 * leased vendors of a TA and to add RAC classification based commission */
		 
		//VisitBean visitBean = commTraxDelegate.insertMaintainTaCommission(visitBean);

		 //Code addition starts here
		commTraxDelegate.insertTaCommissions(arlCodeRef, vBean);

		 //Code addition ends here
		forward = PaxTraxConstants.CONFIRM_TA_COMMISSION_PAGE;
		PaxTraxLog.logDebug("CommTrax::MaintainTaCommAction::"
			+"confirmMaintainTaCommission::End");
		return (mapping.findForward(forward));
	}

	/**
		* change the language
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while changing the language
	*/

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::MaintainTaCommAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);

		ArrayList arlCodeRefNames = null;

		String country = request.getParameter(PaxTraxConstants.COUNTRY);

		super.changeLanguage(request, language, country);

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.SKU_ERROR,
				new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
		}
		String page = request.getParameter(PaxTraxConstants.PAGE);
		String pageNumber = request.getParameter("pageNumber");

		if (page.equals("maintainTaCommission"))
		{
			if(pageNumber.equals("-1")){
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
				request.setAttribute("pageNumber", pageNumber);
				forward = PaxTraxConstants.MAINTAIN_TA_COMMISSION_PAGE;
			}
			else{
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				request.setAttribute("pageNumber", pageNumber);
				forward = PaxTraxConstants.MAINTAIN_TA_COMMISSION_PAGE;
			}
		}
		else if (page.equals("insertTaCommission"))
		{
			HttpSession session = request.getSession();
			arlCodeRefNames = (ArrayList)session.getAttribute("CodeRefNames");
			//String arlCodeRefNames = request.getParameter("CodeRefNames");
			request.setAttribute("CodeRefNames",arlCodeRefNames);
			forward = PaxTraxConstants.INSERT_TA_COMMISSION_PAGE;
		}
		else if (page.equals("confirmTaCommission"))
		{
			HttpSession session = request.getSession();
			arlCodeRefNames = (ArrayList)session.getAttribute("CodeRefNames");

			//String arlCodeRefNames = request.getParameter("CodeRefNames");
			request.setAttribute("CodeRefNames",arlCodeRefNames);
			forward = PaxTraxConstants.CONFIRM_TA_COMMISSION_PAGE;
		}
		PaxTraxLog.logDebug("PaxTrax::MaintainTaCommAction::changeLanguage::End");
		return mapping.findForward(forward);
	}

}
