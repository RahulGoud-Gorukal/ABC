package com.dfs.paxtrax.commtracking.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.commtracking.exception.CommTraxException;
import com.dfs.paxtrax.commtracking.valueobject.BranchBean;
import com.dfs.paxtrax.commtracking.valueobject.CommBean;
import com.dfs.paxtrax.commtracking.valueobject.CommTraxBuffer;
import com.dfs.paxtrax.commtracking.valueobject.GroupBean;
import com.dfs.paxtrax.commtracking.valueobject.VisitBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
import com.dfs.paxtrax.commtracking.exception.SegmentException;

/**
 *
 * The Remote Object for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/11/2004	Yuvarani			Created
 * 17/05/2005   Sathish				Modified (Added methods)
 */

public interface CommTraxBO extends javax.ejb.EJBObject {

	/**
	 * Method saveVisitPAXDetails.
	 *
	 * @param paxBean PAXBean
	 * @return PAXBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws  CommTraxException
	 * The method to create a PAX Record
	 */
	public PAXBean saveVisitPAXDetails(PAXBean paxBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public void updateCondVist(ArrayList paxList, PAXBean paxBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	/**
	 * Searches Group.
	 * @param visitBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public ArrayList searchGroup(VisitBean visitBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Adds Group.
	 * @param groupBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	public void addGroup(GroupBean groupBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	//Methods for Travel Agent and Branch
	public boolean createTADetails(CommBean commBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public boolean updateTADetails(CommBean commBean)
		throws RemoteException, PaxTraxSystemException;

	//public boolean deleteTADetails(CommBean commBean) throws RemoteException;
	public String deleteTADetails(CommBean commBean)
		throws RemoteException, PaxTraxSystemException;

	public ArrayList getTADetails(
		String taCode,
		String agencyName,
		String agencyOwner)
		throws RemoteException, PaxTraxSystemException;

	public ArrayList loadTANames()
		throws RemoteException, PaxTraxSystemException;

	public boolean createBranchDetails(BranchBean branchBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public ArrayList getBranchDetails(BranchBean branchBean)
		throws RemoteException, PaxTraxSystemException;

	public ArrayList getBranch(String taCode, String branchCode)
		throws RemoteException, PaxTraxSystemException;

	public boolean saveBranchDetails(BranchBean branchBean)
		throws RemoteException, PaxTraxSystemException;

	public boolean deleteBranch(BranchBean branchBean)
		throws RemoteException, PaxTraxSystemException;

	public void createDataFiles()
		throws RemoteException, PaxTraxSystemException;

	//Methods for Travel Agent and Branch

	/* FOR COMMTRAX VISIT PAGE AND TA COMMISSION */
	public String saveVisitDetails(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public void updateVisitDetails(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public String getSeqVisitCode()
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public void removeVisitDetails(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public void removePaxDetail(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public ArrayList searchVisitDetails(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public ArrayList getVisitPaxDetails(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public ArrayList loadTaName()
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public ArrayList loadTaBranchName(String taCode)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	public ArrayList getTADetails(VisitBean visitBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

/* Commented by Vani on 06/08/2005
		 * This change was done to dynamically populate the 
		 * leased vendors of a TA and to add RAC classification based commission */

//	public ArrayList getCodeRef()
//		throws RemoteException, PaxTraxSystemException, CommTraxException;


//	public void insertMaintainTaCommission(VisitBean visitBean)
//		throws RemoteException, PaxTraxSystemException, CommTraxException;

//	public VisitBean getMaintainTaCommission(String taCode)
//		throws RemoteException, PaxTraxSystemException, CommTraxException;

/* Added by Vani on 06/08/2005
		 * This change was done to dynamically populate the 
		 * leased vendors of a TA and to add RAC classification based commission */

//Code addition starts here

	/**
	 * To update/insert TaCommissions.
	 * @param TACommissions
	 * @param vBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	
	public void insertTaCommissions(ArrayList TACommissions, VisitBean vBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	/**
	 * To get TaCommissions.
	 * @param taCode
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 * @throws CommTraxException
	 */
	public ArrayList getTaCommissions(String taCode)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	
//Code addition ends here	

	/**
	 * Searches StartVisitDetails.
	 * @param visitBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public ArrayList searchStartVisitDetails(VisitBean visitBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Starts the visit by providing actual date and time.
	 * @param visitBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public void updateStartVisit(VisitBean visitBean)
		throws PaxTraxSystemException, RemoteException, CommTraxException;

	public ArrayList checkPax(ArrayList paxList, String visitCode)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method getStartVisitTimeDifference.
	 * @return int
	 */
	public int getStartVisitTimeDifference()
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method maintainGroup.
	 * @param groupBean
	 */
	public void maintainGroup(GroupBean groupBean)
		throws RemoteException, PaxTraxSystemException, CommTraxException;

	/**
	 * Method deleteGroup.
	 * @param groupBean
	 */
	public void deleteGroup(GroupBean groupBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Returns agent master details
	 * @return CommTraxBuffer the agent master details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getAgentMaster()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns branch master details
	 * @return CommTraxBuffer the branch master details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getBranchMaster()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns commission rate details
	 * @return CommTraxBuffer the commission details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getCommissionRate()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns conducted tour details
	 * @return CommTraxBuffer the conducted tour details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getConductedTour()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns non-conducted tour details
	 * @return CommTraxBuffer the non-conducted tour details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getNonConductedTour()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns Pax master details
	 * @return CommTraxBuffer the pax master details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getPaxMaster()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns visit master details
	 * @return CommTraxBuffer the visit master details and its count
	 * @throws RemoteException thrown on error during remote access
	 * @throws PaxTraxSystemException thrown on paxtrax error
	 */
	public CommTraxBuffer getVisitCodeConductedTour()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Creates a new segment for a TA
	 * @param commBean
	 * @return boolean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public boolean createSegment(CommBean commBean)
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Searches the segment details
	 * @param commBean
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchSegment(CommBean commBean)
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns a segment given a taCode, segmentCode
	 * @param segmentBean
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public CommBean getSegment(CommBean segmentBean)
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Updates a segmentcode, segmentname given a taCode, segmentCode.
	 * @param segmentBean bean to using which segment is updated
	 * @param updateBean bean used to find the segment
	 * @return boolean true if updation succeeds, false otherwise
	 * @throws CommTraxException thrown on Invalid/non-existent Segment
	 * @throws RemoteException
	 * @throws PaxTraxSystemException thrown on error
	 */
	public boolean updateSegment(CommBean updateBean)
		throws CommTraxException, RemoteException, PaxTraxSystemException;

	/**
	 * Deletes a segment given a taCode, segmentCode.
	 * @param segmentBean bean containing segment details
	 * @return boolean true if segment is deleted false otherwise
	 * @throws RemoteException
	 * @throws PaxTraxSystemException thrown on error
	 */
	public boolean deleteSegment(CommBean segmentBean)
		throws RemoteException, SegmentException, PaxTraxSystemException;

	/**
	 * Returns SegmentCodes under a TA 
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList loadSegmentCodes(String taCode)
		throws RemoteException, PaxTraxSystemException;

	//Added for CR1832 starts
	/**
	 * Returns TACommChanges 
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getTACommChanges()
		throws RemoteException, PaxTraxSystemException;
//	Added for CR1832 ends

	//Added for CR1832 starts
	/**
	 * Returns TACommChanges 
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getVisitChanges(String VisitFlag)
		throws RemoteException, PaxTraxSystemException;
//	Added for CR1832 ends



}