package com.dfs.paxtrax.commtracking.actionform;


import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;
import com.dfs.paxtrax.common.actionform.CommTraxActionForm;
import com.dfs.paxtrax.commtracking.valueobject.CommBean;

/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class SearchTAForm extends CommTraxActionForm{
	
	private ArrayList taCollection = null;
	
	private String taCode = null;
	
	private String agencyName = null;
	
	private String agencyOwner = null;
	
	
	public ArrayList getTaCollection()
	{
		return taCollection;
	}
	
	public void setTaCollection(ArrayList taCollection)
	{
		this.taCollection = taCollection;
	}
	
	
	public String getTaCode()
	{
		return taCode;
	}
	
	public void setTaCode(String taCode)
	{
		this.taCode = taCode;
	}

	public String getAgencyName()
	{
		return agencyName;
	}
	
	public void setAgencyName(String agencyName)
	{
		this.agencyName = agencyName;
	}

	public String getAgencyOwner()
	{
		return agencyOwner;
	}

	public void setAgencyOwner(String agencyOwner)
	{
		this.agencyOwner = agencyOwner;
	}
	
	
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
	}
}