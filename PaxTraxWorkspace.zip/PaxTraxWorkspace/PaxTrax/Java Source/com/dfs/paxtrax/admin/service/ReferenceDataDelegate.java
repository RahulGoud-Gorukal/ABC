package com.dfs.paxtrax.admin.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.business.ReferenceDataBO;
import com.dfs.paxtrax.admin.business.ReferenceDataBOHome;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * This is delegate class which performs jndi lookup and it act as a point of 
 * entry for business methods.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Vaikundamurthy	Created   
 */


public class ReferenceDataDelegate
{
	//Holds service locator instance
	private ServiceLocator serviceLocator = null;
	
	/**
	 * Constructor for this class
	 */
	public ReferenceDataDelegate()
	{
	}

	private ReferenceDataBOHome referenceDataBOHome = null;
	private ReferenceDataBO referenceDataBO = null;
	
	private void jndiCall() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			referenceDataBOHome = (ReferenceDataBOHome)
				PortableRemoteObject.narrow(serviceLocator.getEJBHome(
					PaxTraxConstants.REFERENCE_DATA_BO_BEAN_JNDI), 
						ReferenceDataBOHome.class);
		}
		catch (NamingException ne)
		{
			throw  new PaxTraxSystemException(ne);
		}		
		if (referenceDataBOHome == null)
		{
			throw new PaxTraxSystemException(
				PaxTraxConstants.USER_BO_HOME_NOT_FOUND);
		}
		try
		{
			referenceDataBO = referenceDataBOHome.create();			
		}
		catch (CreateException ce)
		{
			throw  new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw  new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::jndiCall::End");
	}

	/**
	 * Saves reference data details into the database by delegating the request 
	 * to manager bean. 
	 * @param referenceDataListBean ReferenceDataListBean object
	 * @throws PaxTraxSystemException
	 */
	public ArrayList saveReferenceData(ReferenceDataListBean referenceDataListBean) 
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::saveReferenceData::Begin");
		ArrayList list = null;
		if (referenceDataBOHome == null)
		{
			jndiCall();
		}
		try
		{
			list = referenceDataBO.saveReferenceData(referenceDataListBean);		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::saveReferenceData::End");
		return list;		
	}
	
	/**
	 * Loads reference data for the given reference type
	 * @param referenceType Reference type for which data is loaded
	 * @return ArrayList - List of reference data bean for the given search
	 * criteria
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in load
	 */
	public ArrayList loadReferenceData(String referenceType)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::loadReferenceData::Begin");
		ArrayList referenceData = null;
		if (referenceDataBOHome == null)
		{
			jndiCall();
		}
		try
		{
			referenceData = referenceDataBO.loadReferenceData(referenceType);		
		}
		catch(RemoteException re)
		{	
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::loadReferenceData::End");
		return referenceData;
	}
	
	/**
	 * Loads reference tpes
	 * @return ArrayList - List of reference data bean 
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in load 
	 */
	public ArrayList loadReferenceType()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::loadReferenceType::Begin");
		ArrayList referenceData = null;
		if (referenceDataBOHome == null)
		{
			jndiCall();
		}
		try
		{
			referenceData = referenceDataBO.loadReferenceType();		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::loadReferenceType::End");
		return referenceData;
	}
	
	public ArrayList getTravelAgentCodes()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::getTravelAgentCodes()::Begin");
		ArrayList travelAgentCodes = null;
		if (referenceDataBOHome == null) {
			jndiCall();
		}
		try {
			travelAgentCodes = referenceDataBO.getTravelAgentCodes();
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::getTravelAgentCodes()::End");
		return travelAgentCodes;
	}	

	public ArrayList getTravelAgentBranches(String travelAgentCode)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::getTravelAgentBranches()::Begin");
		ArrayList travelAgentBranches = null;
		if (referenceDataBOHome == null) {
			jndiCall();
		}
		try {
			travelAgentBranches = referenceDataBO.getTravelAgentBranches(travelAgentCode);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDelegate::getTravelAgentBranches()::End");
		return travelAgentBranches;
	}	
	
}
