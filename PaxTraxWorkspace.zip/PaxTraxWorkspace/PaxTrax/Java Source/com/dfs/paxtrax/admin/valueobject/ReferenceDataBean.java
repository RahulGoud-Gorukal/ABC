package com.dfs.paxtrax.admin.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/03/2004	Vaikundamurthy	Created   
 */


public class ReferenceDataBean extends PaxTraxValueObject
{
	//Holds referenceId 
	private String referenceId = null;
	
	//Holds reference name
	private String referenceName = null;
	
	//Holds the code of the appilcation data
	private String codeId = null;
	
	//Holds the value of the application code
	private String codeValue = null;
	
	//Holds the value for from hour
	private String fromHr = null;
	
	//Holds the value for from minute
	private String fromMin = null;
	
	//Holds the value for to hour
	private String toHr = null;
	
	//Holds the value for to minute
	private String toMin = null;
	
	//Holds flag
	private String codeToFlag = PaxTraxConstants.NO;
	
	//Holds naccs code
	private String naccsCode = null;
	
	private String displayLabel;
	
	/**
	 * Default constructor
	 */
	public ReferenceDataBean() {
	}
	
	/**
	 * Gets the codeId
	 * @return String - Returns the codeId
	 */
	public String getCodeId() {
		return codeId;
	}
	
	/**
	 * Sets the codeId
	 * @param codeId The codeId to set
	 */
	public void setCodeId(String codeId) {
		
		if (codeId != null)
		{
			this.codeId = codeId.trim();
		}
		else
		{
			this.codeId = codeId;
		}
	}

	/**
	 * Gets the codeValue
	 * @return String - Returns a codeValue
	 */
	public String getCodeValue() {
		return codeValue;
	}
	
	/**
	 * Sets the codeValue
	 * @param codeValue The codeValue to set
	 */
	public void setCodeValue(String codeValue) {
		if (codeValue != null)
		{
			this.codeValue = codeValue.trim();
		}
		else
		{
			this.codeValue = codeValue;		
		}
	}
	/**
	 * Returns the referenceId.
	 * @return String
	 */
	public String getReferenceId()
	{
		return referenceId;
	}

	/**
	 * Sets the referenceId.
	 * @param referenceId The referenceId to set
	 */
	public void setReferenceId(String referenceId)
	{
		if (referenceId != null)
		{
			this.referenceId = referenceId.trim();
		}
	}

	/**
	 * Returns the referenceName.
	 * @return String
	 */
	public String getReferenceName()
	{
		return referenceName;
	}

	/**
	 * Sets the referenceName.
	 * @param referenceName The referenceName to set
	 */
	public void setReferenceName(String referenceName)
	{
		if (referenceName != null)
		{
			this.referenceName = referenceName.trim();
		}
	}

	/**
	 * Returns the fromHr.
	 * @return String
	 */
	public String getFromHr()
	{
		return fromHr;
	}

	/**
	 * Returns the fromMin.
	 * @return String
	 */
	public String getFromMin()
	{
		return fromMin;
	}

	/**
	 * Returns the toHr.
	 * @return String
	 */
	public String getToHr()
	{
		return toHr;
	}

	/**
	 * Returns the toMin.
	 * @return String
	 */
	public String getToMin()
	{
		return toMin;
	}

	/**
	 * Sets the fromHr.
	 * @param fromHr The fromHr to set
	 */
	public void setFromHr(String fromHr)
	{
		if (fromHr != null)
		{
			this.fromHr = fromHr.trim();
		}
	}

	/**
	 * Sets the fromMin.
	 * @param fromMin The fromMin to set
	 */
	public void setFromMin(String fromMin)
	{
		if (fromMin != null)
		{
			this.fromMin = fromMin.trim();
		}
	}

	/**
	 * Sets the toHr.
	 * @param toHr The toHr to set
	 */
	public void setToHr(String toHr)
	{
		if (toHr != null)
		{
			this.toHr = toHr.trim();
		}
	}

	/**
	 * Sets the toMin.
	 * @param toMin The toMin to set
	 */
	public void setToMin(String toMin)
	{
		if (toMin != null)
		{
			this.toMin = toMin.trim();
		}
	}

	/**
	 * Returns the codeToFlag.
	 * @return String
	 */
	public String getCodeToFlag()
	{
		return codeToFlag;
	}

	/**
	 * Sets the codeToFlag.
	 * @param codeToFlag The codeToFlag to set
	 */
	public void setCodeToFlag(String codeToFlag)
	{
		if (codeToFlag != null)
		{
			this.codeToFlag = codeToFlag.trim();
		}
	}

	/**
	 * Returns the naccsCode.
	 * @return String
	 */
	public String getNaccsCode()
	{
		return naccsCode;
	}

	/**
	 * Sets the naccsCode.
	 * @param naccsCode The naccsCode to set
	 */
	public void setNaccsCode(String naccsCode)
	{
		if (naccsCode != null)
		{
			this.naccsCode = naccsCode.trim();
		}
	}

	/**
	 * Returns the displayLabel.
	 * @return String
	 */
	public String getDisplayLabel() {
		return displayLabel;
	}

	/**
	 * Sets the displayLabel.
	 * @param displayLabel The displayLabel to set
	 */
	public void setDisplayLabel(String displayLabel) {
		this.displayLabel = displayLabel;
	}

}
