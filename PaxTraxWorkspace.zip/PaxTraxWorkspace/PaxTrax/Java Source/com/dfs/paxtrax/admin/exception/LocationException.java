package com.dfs.paxtrax.admin.exception;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxException;


/**
 * This is security exception class which is thrown if any business exception
 * arises
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 20/04/2004	Joseph Oommen A	Created   
 */


public class LocationException extends PaxTraxException
{
	/**
     * Constructor accepts actual exception object
     *
     * @param actualException Exception   Actual Exception
     */
    public LocationException(Exception actualException) {

        super(PaxTraxErrorMessages.PT_SYSEXCEPTION, actualException);
    }
    
    /**
     * Constructor accepts error code
     *
     * @param actualException Exception   Actual Exception
     */
    public LocationException( int errorCode) {

        super(errorCode);
    }
}	