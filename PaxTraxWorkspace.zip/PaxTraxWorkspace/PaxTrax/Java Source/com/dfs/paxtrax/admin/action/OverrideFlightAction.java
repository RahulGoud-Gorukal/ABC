package com.dfs.paxtrax.admin.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.OverrideFlightForm;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.service.FlightDelegate;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 02/04/2004	Sundarrajan.K.	Created  
 * 07/28/2007 	Uma D			Modified for CR changes 
 */

/**
   This is struts action class which performs override flight operations
 */
public class OverrideFlightAction extends PaxTraxAction
{

	/**
	   Saves override flight schedule by calling delegate method. It throws PaxTraxException if there is any problem in save
	   @roseuid 4045122F02FD
	 */
	public ActionForward saveOverrideFlightSchedule(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::saveOverrideFlightSchedule::Begin");
		HttpSession session = request.getSession();
		String forward = null;
		OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
		FlightBean flightBean = overrideFlightForm.getFlightBean();
		FlightDelegate flightDelegate = new FlightDelegate();
		overrideFlightForm.setFlightBean(flightBean);
		//ArrayList flightDetails = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
		//int index = ((Integer)session.getAttribute(PaxTraxConstants.INDEX)).intValue();		
		//flightDetails.remove(index-1);
		//flightDetails.add(index-1,flightBean);
		
//		Made changes for CR 250 changes on July 28, 2007 --  Begin

		String userId = (String) session.getAttribute(PaxTraxConstants.USER);
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::saveOverrideFlightSchedule::userId"+userId);		
		flightBean.setUser(userId);
		PaxTraxLog.logDebug("PaxTrax::OverrideFlightAction::saveOverrideFlightSchedule::isDeparture"+flightBean.getIsDeparture());
		try
		{
			if(flightBean.getIsDeparture())
			{
				flightDelegate.checkNaccsStatus(flightBean);
			}
			session.removeAttribute(PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
			//session.setAttribute(PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS,flightDetails);	    	

			flightDelegate.insertOverrideFlightDetails(flightBean);
			forward = PaxTraxConstants.SAVE_OVERRIDE_FLIGHT;
		}
		catch (FlightException fe)
		{
			if(fe.getErrorCode()==PaxTraxConstants.NACCS_IN_PROGRESS)
			{
				request.setAttribute(PaxTraxConstants.ERROR,String.valueOf(PaxTraxConstants.NACCS_IN_PROGRESS));	
			}
			else if(fe.getErrorCode()==PaxTraxConstants.NACCS_FILE_GENERATED)
			{
				request.setAttribute(PaxTraxConstants.ERROR,String.valueOf(PaxTraxConstants.NACCS_FILE_GENERATED));	
			}		
			else
			{
				PaxTraxLog.logError("PaxTrax::OverrideFlightAction::saveOverrideFlightSchedule::Exception");
				fe.printStackTrace();
			}
			forward = PaxTraxConstants.LOAD_OVERRIDE_FLIGHT;
//		Made changes for CR 250 changes on July 28, 2007 --  End			
		}
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::saveOverrideFlightSchedule::End");
		return mapping.findForward(forward);
	}

	/**
	   Loads flight schedule details from search page.
	 */
	public ActionForward loadOverrideFlightSchedule(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::loadOverrideFlightSchedule::Begin");
		HttpSession session = request.getSession();
		OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
		FlightBean flightBean = overrideFlightForm.getFlightBean();
		FlightDelegate flightDelegate = new FlightDelegate();
		String index = request.getParameter(PaxTraxConstants.INDEX);
		session.setAttribute(PaxTraxConstants.INDEX, new Integer(index));
		ReferenceDataBean referenceDataBean = null;
		try
		{
			ArrayList flightDetails =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
			PaxTraxLog.logDebug(
				"PaxTrax::OverrideFlightAction::loadOverrideFlightSchedule::listSize"+flightDetails.size());
			if (flightDetails != null && !flightDetails.isEmpty())
			{
				flightBean =
					(FlightBean) flightDetails.get(Integer.parseInt(index) - 1);
				overrideFlightForm.setFlightBean(flightBean);
				setComboAttributes(overrideFlightForm); 
//				Added for CR 250 changes on July 28, 2007 --  Begin	
				PaxTraxLog.logDebug("PaxTrax::OverrideFlightAction::loadOverrideFlightSchedule::isDeparture"+flightBean.getIsDeparture());
				if(flightBean.getIsDeparture())
				{
					flightDelegate.checkNaccsStatus(flightBean);
				}
//				Added for CR 250 changes on July 28, 2007 --  End				
			}	
		}
		catch(FlightException fe)
		{
			if(fe.getErrorCode()==PaxTraxConstants.NACCS_IN_PROGRESS)
			{
				request.setAttribute(PaxTraxConstants.ERROR,String.valueOf(PaxTraxConstants.NACCS_IN_PROGRESS));	
			}
			else if(fe.getErrorCode()==PaxTraxConstants.NACCS_FILE_GENERATED)
			{
				request.setAttribute(PaxTraxConstants.ERROR,String.valueOf(PaxTraxConstants.NACCS_FILE_GENERATED));	
			}		
			else
			{
				PaxTraxLog.logError("PaxTrax::OverrideFlightAction::loadOverrideFlightSchedule::Exception");
				fe.printStackTrace();
			}
		}
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::loadOverrideFlightSchedule::End");
		return mapping.findForward(PaxTraxConstants.LOAD_OVERRIDE_FLIGHT);
	}

	/**
	   Forwards to Search override flight page
	   @roseuid 4051140C017B
	 */
	public ActionForward cancelOverrideFlightPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::cancelOverrideFlightPage::Begin");
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::cancelOverrideFlightPage::End");
		return mapping.findForward(PaxTraxConstants.CANCEL_OVERRIDE_FLIGHT);
	}

	/**
	   Removes override by calling delegate method. It throws PaxTraxException if there is any problem in removing override
	   @roseuid 405114710341
	 */
	public ActionForward removeOverride(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::removeOverride::Begin");
		String forward = null;
		HttpSession session = request.getSession();
		OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
		FlightBean flightBean = overrideFlightForm.getFlightBean();
		FlightDelegate flightDelegate = new FlightDelegate();
		ArrayList flightDetails =
			(ArrayList) session.getAttribute(
				PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
		int index =
			((Integer) session.getAttribute(PaxTraxConstants.INDEX)).intValue();
		try
		{
//			Added for CR 250 changes on July 28, 2007 --  Begin

			String userId = (String) session.getAttribute(PaxTraxConstants.USER);
			PaxTraxLog.logDebug(
				"PaxTrax::OverrideFlightAction::removeOverride::userId"+userId);		
			flightBean.setUser(userId);
//			Added for CR 250 changes on July 28, 2007 --  End
			flightDelegate.removeFlightDetails(flightBean);
			flightBean.setIsFlightCancelled(false);
			flightDetails.remove(index - 1);
			flightDetails.add(index - 1, flightBean);
			session.removeAttribute(
				PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS,
				flightDetails);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.TRUE);
			String removeOverride = request.getParameter("removeoverride");
			request.setAttribute("removeoverride", removeOverride);
			overrideFlightForm.setFlightBean(flightBean);
			forward = PaxTraxConstants.SAVE_OVERRIDE_FLIGHT;
		}
		catch (FlightException fe)
		{
			PaxTraxLog.logError(fe.getMessage());
			ActionMessages messages = new ActionMessages();
			messages.add(
				"flightNumber",
				new ActionMessage("" + fe.getErrorCode()));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			forward = PaxTraxConstants.LOAD_OVERRIDE_FLIGHT;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::removeOverride::End");
		return mapping.findForward(forward);
	}

	private void setComboAttributes(OverrideFlightForm flightForm)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::setComboAttributes::Begin");
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		flightForm.setAirlineCodes(
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.AIRLINE_CODE));
		flightForm.setHours(loadReferenceData("hours"));
		flightForm.setMinutes(loadReferenceData("minutes"));
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::setComboAttributes::End");
	}

	private ArrayList loadReferenceData(String code)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::loadReferenceData::Begin");
		ReferenceDataBean referenceDataBean = null;
		ArrayList flightDetails = null;

		if (code.equals("flighttype"))
		{
			flightDetails = new ArrayList();
			referenceDataBean = new ReferenceDataBean();

			referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId("1");
			referenceDataBean.setCodeValue("Scheduled Flights");
			flightDetails.add(referenceDataBean);

			referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId("2");
			referenceDataBean.setCodeValue("Non Scheduled Flights");
			flightDetails.add(referenceDataBean);

		}
		else if (code.equals("hours"))
		{
			flightDetails = new ArrayList();

			for (int i = 0; i < 24; i++)
			{
				referenceDataBean = new ReferenceDataBean();
				if (i < 10)
				{
					referenceDataBean.setCodeId("0" + String.valueOf(i));
					referenceDataBean.setCodeValue("0" + String.valueOf(i));
				}
				else
				{
					referenceDataBean.setCodeId(String.valueOf(i));
					referenceDataBean.setCodeValue(String.valueOf(i));
				}
				flightDetails.add(referenceDataBean);
			}
		}
 
		else if (code.equals("minutes"))
		{
			flightDetails = new ArrayList();

			for (int i = 0; i < 60; i++) 
			{
				referenceDataBean = new ReferenceDataBean();
				if (i < 10)
				{
					referenceDataBean.setCodeId("0" + String.valueOf(i));
					referenceDataBean.setCodeValue("0" + String.valueOf(i));
				}
				else
				{
					referenceDataBean.setCodeId(String.valueOf(i));
					referenceDataBean.setCodeValue(String.valueOf(i));
				}
				flightDetails.add(referenceDataBean);
			}
		}
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::loadReferenceData::End");
		return flightDetails;
	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::changeLanguage::Begin");
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		HttpSession session = request.getSession();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		String errorCode = request.getParameter("errorCode1");

		if(errorCode != null)
		{
			request.setAttribute(PaxTraxConstants.ERROR_CODE,errorCode);
		}
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if("massFlight".equals(page))
		{
			forward="massFlightChange";
		}
		else if (PaxTraxConstants.SAVE_OVERRIDE_FLIGHT.equals(page))
		{
			forward = PaxTraxConstants.SAVE_OVERRIDE_FLIGHT;
		}
		else
		{
			OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
			FlightBean flightBean = overrideFlightForm.getFlightBean();
			if (flightBean.getFlightOverrideDate() != null
				&& flightBean.getFlightOverrideDate().equals(""))
				flightBean.setFlightOverrideDate(PaxTraxConstants.FALSE);
			else
				flightBean.setFlightOverrideDate(
					flightBean.getFlightOverrideDate());
			if (!flightBean.getIsFlightCancelled())
				flightBean.setIsFlightCancelled(false);
			else
				flightBean.setIsFlightCancelled(true);
			overrideFlightForm.setFlightBean(flightBean);
			//ArrayList flightDetails = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
			//int index = ((Integer)session.getAttribute(PaxTraxConstants.INDEX)).intValue();		
			/*if(flightDetails != null && !flightDetails.isEmpty())
			{
				flightBean = (FlightBean)flightDetails.get(index-1);
				if(flightBean.getFlightOverrideDate() != null &&
				flightBean.getFlightOverrideDate().equals(""))
					flightBean.setFlightOverrideDate(PaxTraxConstants.FALSE);
				if(!flightBean.getIsFlightCancelled())
					flightBean.setIsFlightCancelled(false);
					
				overrideFlightForm.setFlightBean(flightBean);									
			}*/
			String errc = (String) request.getParameter(PaxTraxConstants.ERROR);
			PaxTraxLog.logDebug("PaxTrax::OverrideFlightAction::changeLanguage::error code:"+errc);
			if(errc != null)
			{
				PaxTraxLog.logDebug("PaxTrax::OverrideFlightAction::changeLanguage::errc not null");
				if(errc.equals(String.valueOf(PaxTraxConstants.NACCS_IN_PROGRESS)))
				{
					request.setAttribute(PaxTraxConstants.ERROR,String.valueOf(PaxTraxConstants.NACCS_IN_PROGRESS));
				}
				else if(errc.equals(String.valueOf(PaxTraxConstants.NACCS_FILE_GENERATED)))
				{
					request.setAttribute(PaxTraxConstants.ERROR,String.valueOf(PaxTraxConstants.NACCS_FILE_GENERATED));	
				}
			}
			PaxTraxLog.logDebug(
				"PaxTrax::OverrideFlightAction::changeLanguage::inside else");
			forward = PaxTraxConstants.LOAD_OVERRIDE_FLIGHT;
		}
		String removeOverride = request.getParameter("removeoverride");
		request.setAttribute("removeoverride", removeOverride);
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::changeLanguage::End");
		return mapping.findForward(forward);
	}
	public ActionForward massFlightChangePage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::massFlightChangePage::Begin");
		OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
		FlightDetailsBean flightDetailsBean = new FlightDetailsBean();
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList airlineCodes =
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.AIRLINE_CODE);
		overrideFlightForm.setFlightDetailsBean(flightDetailsBean);
		overrideFlightForm.setAirlineCodes(airlineCodes);

		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::massFlightChangePage::End");
		return mapping.findForward("massFlightChange");
	}

	public ActionForward massFlightSave(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::massFlightSave::Begin");
		OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
		ArrayList paxList = overrideFlightForm.getMassFlightChangeList();

		FlightDelegate flightDelegate = new FlightDelegate();
		String forward=null;	
		try
		{
			ArrayList resultList = flightDelegate.saveFlightDetails(paxList);

			if (resultList != null && resultList.size() > 0)
			
			
			{
				overrideFlightForm.setMassFlightChangeList(null);
				overrideFlightForm.setMassFlightChangeList(resultList);
				request.setAttribute(
					PaxTraxConstants.ERROR_CODE,
					PaxTraxConstants.FAILURE);
					request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);
			
			
			}
			else
			{
				overrideFlightForm.setMassFlightChangeList(null);
				//request.setAttribute(PaxTraxConstants.OPERATION,	PaxTraxConstants.SUCCESS);
				request.setAttribute(PaxTraxConstants.ERROR_CODE,PaxTraxConstants.SUCCESS);
			//overrideFlightForm.setMassFlightChangeList(paxList);		
			//forward ="viewMassFlightChange";
			}
		}
		catch (FlightException flightException)
		{
			
		}

	forward ="massFlightChange";
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::massFlightSave::End");
		return mapping.findForward(forward);
	}
	public ActionForward getPaxDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::getPaxDetails::Begin");
		OverrideFlightForm overrideFlightForm = (OverrideFlightForm) form;
		ArrayList airLineCodeList = overrideFlightForm.getAirlineCodes();
		FlightDetailsBean flightDetailsBean =
			overrideFlightForm.getFlightDetailsBean();
		try
		{
			FlightDelegate flightDelegate = new FlightDelegate();
			ArrayList resultList =
				flightDelegate.massFlightChange(flightDetailsBean);
			HttpSession session = request.getSession();	
			if (resultList != null && resultList.size() > 0)
			{
				for (int i = 0; i < resultList.size(); i++)
				{
					PAXBean paxBean = (PAXBean) resultList.get(i);
					FlightDetailsBean tempBean =
						paxBean.getDepartureFlightDetails();
					tempBean.setAirLineCodeList(airLineCodeList);
					paxBean.setDepartureFlightDetails(tempBean);
					resultList.remove(i);
					resultList.add(i, paxBean);
					paxBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));

				}

				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);
				overrideFlightForm.setMassFlightChangeList(resultList);
			}
			else
			{
				request.setAttribute(
					PaxTraxConstants.ERROR_CODE,
					PaxTraxConstants.NO_RECORDS_FOUND+"");
			}

		}
		catch (FlightException flightException)
		{
			
			
		}
		PaxTraxLog.logDebug(
			"PaxTrax::OverrideFlightAction::getPaxDetails::End");
		return mapping.findForward("massFlightChange");
	}

}