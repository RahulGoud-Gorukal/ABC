package com.dfs.paxtrax.admin.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * This is value object which contains user attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */


public class UserBean extends PaxTraxValueObject
{

	//User id
	private String userId = null;

	// password 
	private String password = null;

	//Last name of the user
	private String lastName = null;

	//First name of the user
	private String firstName = null;

	//Date of birth
	private String dateOfBirth = null;

	//Employee id of the user
	private String employeeId = null;

	//Language bean
	private ReferenceDataBean languageBean = null;
	
	//Maximum number of times user can try with invalid password
	private int invalidTries = 0;

	//Status indicates whether user is active or his password is locked or not
	private String activeStatus = null;

	//Reason for activation/Deactivation or unlock
	private String reason = null;

	//List of transaction ids associated with this user
	private String[] assignedTransactionIds = null;

	//Whether user id is locked or not
	private String lockStatus = null;

	//Indicates never lock for this user
	private String isNeverLock = PaxTraxConstants.NO;
	
	//List of transactions 
	private ArrayList assignedTransactions = null;

	/**
	 * Constructor for this class
	 */
	public UserBean()
	{
	}

	/**
	 * Gets user id 
	 * @return String - user id
	 */
	public String getUserId()
	{
		return userId;
	}

	/**
	 * setUserId
	 * @param userId User id
	 */
	public void setUserId(String userId)
	{
		if (userId != null)
		{
			this.userId = userId.trim();
		}
	}

	/**
	 * Returns the password.
	 * @return String - Password
	 */
	public String getPassword()
	{
		return password;
	}

	/**
	 * Sets the password.
	 * @param password The password to set
	 */
	public void setPassword(String password)
	{
		if (password != null)
		{
			this.password = password.trim();
		}
	}

	/**
	 * Returns the activeStatus.
	 * @return String - Returns Active status
	 */
	public String getActiveStatus()
	{
		return activeStatus;
	}

	/**
	 * Sets the activeStatus.
	 * @param activeStatus The activeStatus to set
	 */
	public void setActiveStatus(String activeStatus)
	{
		if (activeStatus != null)
		{
			this.activeStatus = activeStatus.trim();
		}		
	}
	
	/**
	 * Returns the assignedTransactionIds.
	 * @return ArrayList - List os assigned transaction ids
	 */
	public String[] getAssignedTransactionIds()
	{
		return assignedTransactionIds;
	}

	/**
	 * Sets the assignedTransactionIds.
	 * @param assignedTransactionIds The assignedTransactionIds to set
	 */
	public void setAssignedTransactionIds(String[] assignedTransactionIds)
	{
		this.assignedTransactionIds = assignedTransactionIds;
	}
	
	/**
	 * Returns the dateOfBirth.
	 * @return String - Date of birth
	 */
	public String getDateOfBirth()
	{
		return dateOfBirth;
	}

	/**
	 * Sets the dateOfBirth.
	 * @param dateOfBirth The dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth)
	{
		if (dateOfBirth != null)
		{
			this.dateOfBirth = dateOfBirth.trim();
		}		
	}
	
	/**
	 * Returns the employeeId.
	 * @return String - Employee id
	 */
	public String getEmployeeId()
	{
		return employeeId;
	}

	/**
	 * Sets the employee id.
	 * @param employeeId The employeeId to set
	 */
	public void setEmployeeId(String employeeId)
	{
		if (employeeId != null)
		{
			this.employeeId = employeeId.trim();
		}		
	}
	
	/**
	 * Returns the firstName.
	 * @return String - First name
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Sets the firstName.
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName)
	{
		if (firstName != null)
		{
			this.firstName = firstName.trim();
		}		
	}
	
	/**
	 * Returns the invalidTries.
	 * @return int - Invalid tries
	 */
	public int getInvalidTries()
	{
		return invalidTries;
	}

	/**
	 * Sets the invalidTries.
	 * @param invalidTries The invalidTries to set
	 */
	public void setInvalidTries(int invalidTries)
	{
		this.invalidTries = invalidTries;
	}
	
	/**
	 * Returns the isNeverLock.
	 * @return String - Never lock status
	 */
	public String getIsNeverLock()
	{
		return isNeverLock;
	}

	/**
	 * Sets the isNeverLock.
	 * @param isNeverLock The isNeverLock to set
	 */
	public void setIsNeverLock(String isNeverLock)
	{
		if (isNeverLock != null)
		{
			this.isNeverLock = isNeverLock.trim();
		}		
	}
	
	/**
	 * Returns the lastName.
	 * @return String - Last name
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Sets the lastName.
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName)
	{
		if (lastName != null)
		{
			this.lastName = lastName.trim();
		}		
	}

	/**
	 * Returns the lockStatus.
	 * @return String - Lock status
	 */
	public String getLockStatus()
	{
		return lockStatus;
	}

	/**
	 * Sets the lockStatus.
	 * @param lockStatus The lockStatus to set
	 */
	public void setLockStatus(String lockStatus)
	{
		if (lockStatus != null)
		{
			this.lockStatus = lockStatus.trim();
		}		
	}

	/**
	 * Returns the reason.
	 * @return String - Reason
	 */
	public String getReason()
	{
		return reason;
	}
	
	/**
	 * Sets the reason.
	 * @param reason The reason to set
	 */
	public void setReason(String reason)
	{
		if (reason != null)
		{
			this.reason = reason.trim();
		}		
	}
	
	/**
	 * Returns the assignedTransactions.
	 * @return ArrayList - Assigned transactions
	 */
	public ArrayList getAssignedTransactions()
	{
		return assignedTransactions;
	}

	/**
	 * Sets the assignedTransactions.
	 * @param assignedTransactions The assignedTransactions to set
	 */
	public void setAssignedTransactions(ArrayList assignedTransactions)
	{
		this.assignedTransactions = assignedTransactions;
	}

	/**
	 * Returns the languageBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getLanguageBean()
	{
		return languageBean;
	}

	/**
	 * Sets the languageBean.
	 * @param languageBean The languageBean to set
	 */
	public void setLanguageBean(ReferenceDataBean languageBean)
	{
		this.languageBean = languageBean;
	}

}
