package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
 

/**
 * This is the actionform that will hold the details of reference data bean.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Vaikundamurthy	Created   
 */


public class ReferenceDataForm extends PaxTraxActionForm {
	
	//Holds reference data bean
	private ReferenceDataBean referenceDataBean = null;
	
	//Holds reference data bean
	private ReferenceDataListBean referenceDataListBean = null;
	
	//Holds reference types
	ArrayList referenceTypes = null;
	
	//Holds the value for from hours
	private ArrayList fromHrs = null;
	
	//Holds the value for from minutes
	private ArrayList fromMins = null;
	
	//Holds the value for to hours
	private ArrayList toHrs = null;
	
	//Holds the value for to minutes
	private ArrayList toMins = null;

	/**
	 * Returns the referenceDataBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataListBean getReferenceDataListBean()
	{
		return referenceDataListBean;
	}

	/**
	 * Returns the referenceTypes.
	 * @return ArrayList
	 */
	public ArrayList getReferenceTypes()
	{
		return referenceTypes;
	}

	/**
	 * Sets the referenceDataListBean.
	 * @param referenceDataListBean The referenceDataListBean to set
	 */
	public void setReferenceDataListBean(ReferenceDataListBean referenceDataListBean)
	{
		this.referenceDataListBean = referenceDataListBean;
	}

	/**
	 * Sets the referenceTypes.
	 * @param referenceTypes The referenceTypes to set
	 */
	public void setReferenceTypes(ArrayList referenceTypes)
	{
		this.referenceTypes = referenceTypes;
	}

	/**
	 * Returns the fromHrs.
	 * @return ArrayList
	 */
	public ArrayList getFromHrs()
	{
		return fromHrs;
	}

	/**
	 * Returns the fromMins.
	 * @return ArrayList
	 */
	public ArrayList getFromMins()
	{
		return fromMins;
	}

	
	/**
	 * Sets the fromHrs.
	 * @param fromHrs The fromHrs to set
	 */
	public void setFromHrs(ArrayList fromHrs)
	{
		this.fromHrs = fromHrs;
	}

	/**
	 * Sets the fromMins.
	 * @param fromMins The fromMins to set
	 */
	public void setFromMins(ArrayList fromMins)
	{
		this.fromMins = fromMins;
	}

	/**
	 * Sets the toHrs.
	 * @param toHrs The toHrs to set
	 */
	public void setToHrs(ArrayList toHrs)
	{
		this.toHrs = toHrs;
	}

	/**
	 * Sets the toMins.
	 * @param toMins The toMins to set
	 */
	public void setToMins(ArrayList toMins)
	{
		this.toMins = toMins;
	}

	/**
	 * Returns the referenceDataBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getReferenceDataBean()
	{
		return referenceDataBean;
	}

	/**
	 * Returns the toHrs.
	 * @return ArrayList
	 */
	public ArrayList getToHrs()
	{
		return toHrs;
	}

	/**
	 * Returns the toMins.
	 * @return ArrayList
	 */
	public ArrayList getToMins()
	{
		return toMins;
	}

	/**
	 * Sets the referenceDataBean.
	 * @param referenceDataBean The referenceDataBean to set
	 */
	public void setReferenceDataBean(ReferenceDataBean referenceDataBean)
	{
		this.referenceDataBean = referenceDataBean;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		if(referenceDataListBean != null)
		{
			referenceDataListBean.setCodeIds(new String[0]);
			referenceDataListBean.setCodeValues(new String[0]);
		}
	}
}
