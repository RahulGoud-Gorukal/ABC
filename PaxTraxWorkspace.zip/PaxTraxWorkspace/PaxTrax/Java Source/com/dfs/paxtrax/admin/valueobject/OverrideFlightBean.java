package com.dfs.paxtrax.admin.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 02/04/2004	Sundarrajan.K.	Created   
 */



/**
   This is value object which contains override flight attributes
 */
public class OverrideFlightBean extends PaxTraxValueObject {
	
    /**
       variable to indicate whether flight cancelled or not
     */
    private boolean isFlightCancelled = false;
    
    /**
       Scheduled date
     */
    private String scheduledDate = null;
    
    /**
       Scheduled time
     */
    private String scheduledTime = null;
    
    /**
       Returns true if Flight is cancelled otherwise false will  be returned
       @roseuid 40450D0500DA
     */
    public boolean getIsFlightCancelled() {
    	return isFlightCancelled;
    }
    
    /**
       Sets airline name
       @roseuid 40450D0D031C
     */
    public void setIsFlightCancelled(boolean isFlightCancelled) {
    	this.isFlightCancelled = isFlightCancelled;
    }
    
    /**
       Returns scheduled date for this flight
       @roseuid 40450D19038A
     */
    public String getScheduledDate() {
    	return scheduledDate;
    }
    
    /**
       Sets scheduled date for this flight
       @roseuid 40450D24001F
     */
    public void setScheduledDate(String scheduledDate) {
    	this.scheduledDate = scheduledDate;
    }
    
    /**
       Returns scheduled time for this flight
       @roseuid 40450D2B033C
     */
    public String getScheduledTime() {
    	return scheduledTime;
    }
    
    /**
       Sets scheduled time for this flight
       @roseuid 40450D340148
     */
    public void setScheduledTime(String scheduledTime) {
    	this.scheduledTime = scheduledTime;
    }
}
