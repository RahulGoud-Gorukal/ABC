package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;


/**
 * This is action form which contains selling location attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE 			USER 			COMMENTS
 * 22/03/2004	Joseph Oommen A	    Created   
*/


public class LocationForm extends PaxTraxActionForm
{
	/*
	 * LcationBean location Bean
	 */
	private LocationBean locationBean = null;

	/*
	 * LocationTypes locaionTypes
	 */
	private ArrayList locationTypes = null;

	/*
	 * ArrayList timeHr
	 */
	private ArrayList timeHr = null;

	/*
	 * ArrayList timeMin
	 */
	private ArrayList timeMin = null;

	/*
     * String locationTypeHide
     */
    private String locationTypeHide = null;
    
    /*
     * String locationTypeSelected
     */
    private String locationTypeSelected=null;

	//String[] availableLocations
	private String[] availableLocations = null;
	
	/**
	 * Returns the locationBean.
	 * @return LocationBean
	 */
	public LocationBean getLocationBean()
	{
		return locationBean;
	}
    
    
	/**
	 * Returns the locationTypes.
	 * @return ArrayList
	 */
    
    
	public ArrayList getLocationTypes()
	{
		return locationTypes;
	}
    
    
	/**
	 * Returns the timeHr.
	 * @return ArrayList
	 */
	public ArrayList getTimeHr()
	{
		return timeHr;
	}
    
    
	/**
	 * Returns the timeMin.
	 * @return ArrayList
	 */
	public ArrayList getTimeMin()
	{
		return timeMin;
	}
    
    
	/**
	 * Sets the locationBean.
	 * @param locationBean The locationBean to set
	 */
	public void setLocationBean(LocationBean locationBean)
	{
		this.locationBean = locationBean;
	}
    
    
	/**
	 * Sets the locationTypes.
	 * @param locationTypes The locationTypes to set
	 */
	public void setLocationTypes(ArrayList locationTypes)
	{
		this.locationTypes = locationTypes;
	}
    
    
	/**
	 * Sets the timeHr.
	 * @param timeHr The timeHr to set
	 */
	public void setTimeHr(ArrayList timeHr)
	{
		this.timeHr = timeHr;
	}
    
    
	/**
	 * Sets the timeMin.
	 * @param timeMin The timeMin to set
	 */
	public void setTimeMin(ArrayList timeMin)
	{
		this.timeMin = timeMin;
	}
    
    
	/**
	 * Returns the locationTypeHide.
	 * @return String
	 */
	public String getLocationTypeHide()
	{
		return locationTypeHide;
	}


	/**
	 * Sets the locationTypeHide.
	 * @param locationTypeHide The locationTypeHide to set
	 */
	public void setLocationTypeHide(String locationTypeHide)
	{
		this.locationTypeHide = locationTypeHide;
	}

	/**
	 * Returns the locationTypeSelected.
	 * @return String
	 */
	public String getLocationTypeSelected()
	{
		return locationTypeSelected;
	}

	/**
	 * Sets the locationTypeSelected.
	 * @param locationTypeSelected The locationTypeSelected to set
	 */
	public void setLocationTypeSelected(String locationTypeSelected)
	{
		this.locationTypeSelected = locationTypeSelected;
	}

	/**
	 * Returns the availableLocations.
	 * @return String[]
	 */
	public String[] getAvailableLocations()
	{
		return availableLocations;
	}

	/**
	 * Sets the availableLocations.
	 * @param availableLocations The availableLocations to set
	 */
	public void setAvailableLocations(String[] availableLocations)
	{
		this.availableLocations = availableLocations;
	}

	public void reset(ActionMapping mapping,HttpServletRequest request)
	{
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
		{
			if (!page.equals(PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE) 
				&& !page.equals(PaxTraxConstants.SEARCH_LOGICAL_LOCATION_PAGE))
			{
				availableLocations = new String[0];
				if (locationBean != null)
				{
					locationBean.setAddedLocations(new String[0]);
				}
			}
			else if (page.equals(PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE))
			{
				if (!request.getParameter(PaxTraxConstants.FROM_PAGE).equals("null"))
				{
					availableLocations = new String[0];
					if (locationBean != null)
					{
						locationBean.setAddedLocations(new String[0]);
					}
				}
			}
		}
	}
	
}