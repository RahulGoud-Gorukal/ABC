package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/03/2004	Sundarrajan.K.	Created   
 */


/**
   This is the action form that holds flight attributes
 */
public class SearchOverrideFlightForm extends PaxTraxActionForm {

	//Flight Bean for setting all the values
    private FlightBean flightBean = null;

	//Airline Codes
	private ArrayList airlineCodes = null;
	
 	//Flight Number
    private String flightNumber = null;

	//Is Departure / Arrival
	private boolean isDeparture = false;
	
	//Flight Date
	private String flightDate = null;
	
	//Flight Hour
	private String flightHour = null;
	
	//Flight Minute
	private String flightMinute = null;	
	
    // Flight Type
    private String flightType = null;
    
    //Origin Airport    
    private String originAirport = null;
    
    //Destination Airport
    private String destinationAirport = null;
    
    //Override Flight collection
    private ArrayList overrideFlightCollection = null;
    
    

	/**
	 * Returns the destinationAirport.
	 * @return String
	 */
	public String getDestinationAirport() {
		return destinationAirport;
	}

	/**
	 * Returns the flightDate.
	 * @return String
	 */
	public String getFlightDate() {
		return flightDate;
	}

	/**
	 * Returns the flightHour.
	 * @return String
	 */
	public String getFlightHour() {
		return flightHour;
	}

	/**
	 * Returns the flightMinute.
	 * @return String
	 */
	public String getFlightMinute() {
		return flightMinute;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * Returns the flightType.
	 * @return String
	 */
	public String getFlightType() {
		return flightType;
	}

	/**
	 * Returns the isDeparture.
	 * @return boolean
	 */
	public boolean isDeparture() {
		return isDeparture;
	}

	/**
	 * Returns the originAirport.
	 * @return String
	 */
	public String getOriginAirport() {
		return originAirport;
	}

	/**
	 * Returns the overrideFlightCollection.
	 * @return ArrayList
	 */
	public ArrayList getOverrideFlightCollection() {
		return overrideFlightCollection;
	}

	/**
	 * Sets the destinationAirport.
	 * @param destinationAirport The destinationAirport to set
	 */
	public void setDestinationAirport(String destinationAirport) {
		this.destinationAirport = destinationAirport;
	}

	/**
	 * Sets the flightDate.
	 * @param flightDate The flightDate to set
	 */
	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	/**
	 * Sets the flightHour.
	 * @param flightHour The flightHour to set
	 */
	public void setFlightHour(String flightHour) {
		this.flightHour = flightHour;
	}

	/**
	 * Sets the flightMinute.
	 * @param flightMinute The flightMinute to set
	 */
	public void setFlightMinute(String flightMinute) {
		this.flightMinute = flightMinute;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the flightType.
	 * @param flightType The flightType to set
	 */
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	/**
	 * Sets the isDeparture.
	 * @param isDeparture The isDeparture to set
	 */
	public void setIsDeparture(boolean isDeparture) {
		this.isDeparture = isDeparture;
	}

	/**
	 * Sets the originAirport.
	 * @param originAirport The originAirport to set
	 */
	public void setOriginAirport(String originAirport) {
		this.originAirport = originAirport;
	}

	/**
	 * Sets the overrideFlightCollection.
	 * @param overrideFlightCollection The overrideFlightCollection to set
	 */
	public void setOverrideFlightCollection(ArrayList overrideFlightCollection) {
		this.overrideFlightCollection = overrideFlightCollection;
	}

	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes() {
		return airlineCodes;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes) {
		this.airlineCodes = airlineCodes;
	}

	/**
	 * Returns the flightBean.
	 * @return FlightBean
	 */
	public FlightBean getFlightBean() {
		return flightBean;
	}

	/**
	 * Sets the flightBean.
	 * @param flightBean The flightBean to set
	 */
	public void setFlightBean(FlightBean flightBean) {
		this.flightBean = flightBean;
	}

}
