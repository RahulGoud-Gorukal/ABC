package com.dfs.paxtrax.admin.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.admin.valueobject.OverrideFlightBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 02/04/2004	Sundarrajan.K.	Created   
 */

/**
   This is action form which contains override flight attributes
 */

public class OverrideFlightForm extends PaxTraxActionForm
{
	/**
	   List of flying days and time
	 */
	private ArrayList overrideFlightBeanCollection = null;

	FlightDetailsBean flightDetailsBean = null;
	/**
	   Flight Bean having all the details
	 */
	private FlightBean flightBean = null;

	/** Contains attributes of override flight details
	 */
	private OverrideFlightBean overrideFlightBean = null;

	/** Contains attributes of airline codes
	 */
	private ArrayList airlineCodes = null;

	/** Contains attributes of hour cut off time
	 */
	private ArrayList hours = null;

	/** Contains attributes of minutes cut off time
	 */
	private ArrayList minutes = null;

	private ArrayList massFlightChangeList = null;

	PAXBean paxBean = null;

	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes()
	{
		return airlineCodes;
	}

	/**
	 * Returns the flightBean.
	 * @return FlightBean
	 */
	public FlightBean getFlightBean()
	{
		return flightBean;
	}

	/**
	 * Returns the hours.
	 * @return ArrayList
	 */
	public ArrayList getHours()
	{
		return hours;
	}

	/**
	 * Returns the minutes.
	 * @return ArrayList
	 */
	public ArrayList getMinutes()
	{
		return minutes;
	}

	/**
	 * Returns the overrideFlightBean.
	 * @return OverrideFlightBean
	 */
	public OverrideFlightBean getOverrideFlightBean()
	{
		return overrideFlightBean;
	}

	/**
	 * Returns the overrideFlightBeanCollection.
	 * @return ArrayList
	 */
	public ArrayList getOverrideFlightBeanCollection()
	{
		return overrideFlightBeanCollection;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes)
	{
		this.airlineCodes = airlineCodes;
	}

	/**
	 * Sets the flightBean.
	 * @param flightBean The flightBean to set
	 */
	public void setFlightBean(FlightBean flightBean)
	{
		this.flightBean = flightBean;
	}

	/**
	 * Sets the hours.
	 * @param hours The hours to set
	 */
	public void setHours(ArrayList hours)
	{
		this.hours = hours;
	}

	/**
	 * Sets the minutes.
	 * @param minutes The minutes to set
	 */
	public void setMinutes(ArrayList minutes)
	{
		this.minutes = minutes;
	}

	/**
	 * Sets the overrideFlightBean.
	 * @param overrideFlightBean The overrideFlightBean to set
	 */
	public void setOverrideFlightBean(OverrideFlightBean overrideFlightBean)
	{
		this.overrideFlightBean = overrideFlightBean;
	}

	/**
	 * Sets the overrideFlightBeanCollection.
	 * @param overrideFlightBeanCollection The overrideFlightBeanCollection to set
	 */
	public void setOverrideFlightBeanCollection(ArrayList overrideFlightBeanCollection)
	{
		this.overrideFlightBeanCollection = overrideFlightBeanCollection;
	}

	/**
	 * Returns the flightDetailsBean.
	 * @return FlightDetailsBean
	 */
	public FlightDetailsBean getFlightDetailsBean()
	{
		return flightDetailsBean;
	}

	/**
	 * Sets the flightDetailsBean.
	 * @param flightDetailsBean The flightDetailsBean to set
	 */
	public void setFlightDetailsBean(FlightDetailsBean flightDetailsBean)
	{
		this.flightDetailsBean = flightDetailsBean;
	}

	/**
	 * Returns the massFlightChangeList.
	 * @return ArrayList
	 */
	public ArrayList getMassFlightChangeList()
	{
		return massFlightChangeList;
	}

	/**
	 * Sets the massFlightChangeList.
	 * @param massFlightChangeList The massFlightChangeList to set
	 */
	public void setMassFlightChangeList(ArrayList massFlightChangeList)
	{
		this.massFlightChangeList = massFlightChangeList;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request)
	{

		if (massFlightChangeList != null)
		{

			for (int i = 0; i < massFlightChangeList.size(); i++)
			{
				PAXBean temp = (PAXBean) massFlightChangeList.get(i);
				FlightDetailsBean flightDetailsBean =
					temp.getDepartureFlightDetails();
				flightDetailsBean.setFlightChange("F");
				temp.setDepartureFlightDetails(flightDetailsBean);
				massFlightChangeList.remove(i);
				massFlightChangeList.add(i, temp);

			}
		}
	}

	/**
	 * Returns the paxBean.
	 * @return PAXBean
	 */
	public PAXBean getPaxBean()
	{
		return paxBean;
	}

	
	/**
	 * Sets the paxBean.
	 * @param paxBean The paxBean to set
	 */
	public void setPaxBean(PAXBean paxBean)
	{
		this.paxBean = paxBean;
	}

}
