package com.dfs.paxtrax.admin.exception;

import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxException;

/**
 * This is security exception class which is thrown if any business exception
 * arises
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 14/04/2005	P.C.Sathish		Created   
 */
public class RacPreAssignmentException  extends PaxTraxException {
	/**
     * Constructor accepts actual exception object
     *
     * @param actualException Exception   Actual Exception
     */
    public RacPreAssignmentException(Exception actualException) {

        super(PaxTraxErrorMessages.PT_SYSEXCEPTION, actualException);
    }
    
    /**
     * Constructor accepts error code
     *
     * @param actualException Exception   Actual Exception
     */
    public RacPreAssignmentException( int errorCode) {

        super(errorCode);
    }

}
