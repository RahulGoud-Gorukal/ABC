package com.dfs.paxtrax.admin.service;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.business.LocationBO;
import com.dfs.paxtrax.admin.business.LocationBOHome;
import com.dfs.paxtrax.admin.exception.LocationException;
import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

/**
 * This is delegate class which performs 
 * jndi lookup and it act as a point
 * of entry for business methods.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE 			USER 			COMMENTS
 * 22/03/2004	Joseph Oommen A	    Created   
*/

public class LocationDelegate
{
	/*
	 * Holds service locator instance
	 */
	private ServiceLocator serviceLocator = null;
	/*
	 * Holds the Home interface
	 */
	private LocationBOHome locationBOHome = null;
	/*
	 * Hold the remote interface
	 */
	private LocationBO locationBO = null;
	/*
	 *Default Construtor for LocationDelegate
	 */

	public LocationDelegate()
	{
	}

	/*
	 * Jndi look up is performed here
	 */
	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::LocationDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			locationBOHome =
				(LocationBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						PaxTraxConstants.LOCATION_BO_BEAN_JNDI),
					LocationBOHome.class);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}
		if (locationBOHome == null)
		{
			throw new PaxTraxSystemException(
				PaxTraxConstants.LOCATION_BO_HOME_NOT_FOUND);
		}
		try
		{
			locationBO = locationBOHome.create();
		}
		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDelegate::jndiCall::End");
	}
	/**
	 * Saves location details into the database by 
	 * delegating the request to  manager bean. 
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException
	 */
	public void saveLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationDelegate::saveLocationDetails::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBO.saveLocationDetails(locationBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::LocationDelegate::saveLocationDetails::End");
	}

	/**
	 * Marks this location details as deleted by delegating the
	 * request to bean. 
	 * @param locationBean Locationbean object
	 * @throws PaxTraxSystemException
	 */
	public void removeLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationDelegate::removeLocationDetails::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBO.removeLocationDetails(locationBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::LocationDelegate::removeLocationDetails::End");
	}

	/**
	 * Updates  location details by delegating the request to manager bean.
	 * @param LocationBean - locationBean
	 * @throws PaxTraxException This exception is thrown if there is any problem in update
	*/
	public void updateLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationDelegate::updateLocationDetails::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBO.updateLocationDetails(locationBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::LocationDelegate::updateLocationDetails::End");
	}

	/**
	 * Searches  location details by delegating the request to bean.
	 * @param LocationBean - locationBean
	 * @throws PaxTraxException This exception is thrown 
	 * if there is any problem in search
	 */
	public ArrayList searchLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException
	{
		 PaxTraxLog.logDebug("PaxTrax::LocationDelegate::searchLocationDetails::Begin");
        ArrayList locationBeanCollection = null;
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBeanCollection =
				locationBO.searchLocationDetails(locationBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::searchLocationDetails::End");
		return locationBeanCollection;
	}

	/**
	 * Loads location details from the database by 
	 * @param  location int
	 * @return locationBean LocationBean  object
	 * @throws PaxTraxSystemException
	 */
	public LocationBean loadLocationDetails(String location)
		throws PaxTraxSystemException, LocationException
	{
		         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::loadLocationDetails::Begin");
        LocationBean locationBean = null;
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBean = locationBO.loadLocationDetails(location);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::loadLocationDetails::End");
		return locationBean;
	}

	/**
	 * Gets all Physical Locations.
	 * @return ArrayList
	 */
	public String[] getAvailableLocations() throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::getAvailableLocations::Begin");
		String[] locationList = null;
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationList = locationBO.getAvailableLocations();
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::getAvailableLocations::End");
		return locationList;
	}

	/**
	 * Method saveLogicalLocation.
	 * @param locationBean
	 */
	public void saveLogicalLocation(LocationBean locationBean) 
		throws PaxTraxSystemException,LocationException
	{
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::saveLogicalLocation::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBO.saveLogicalLocation(locationBean);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::saveLogicalLocation::End");
	}

	/**
	 * Method getLogicalLocation.
	 * @param locationBean
	 * @return LocationBean
	 */
	public LocationBean getLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException,LocationException
	{
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::getLogicalLocation::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBean = locationBO.getLogicalLocation(locationBean);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::getLogicalLocation::End");
		return locationBean;
	}

	/**
	 * Method searchLogicalLocationDetails.
	 * @return ArrayList
	 */
	public ArrayList searchLogicalLocationDetails() throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::"
        	+"searchLogicalLocationDetails::Begin");
        ArrayList locationList = null;
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationList = locationBO.searchLogicalLocationDetails();
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::"
        	+"searchLogicalLocationDetails::End");
		return locationList;
	}

	/**
	 * Method updateLogicalLocation.
	 * @param locationBean
	 */
	public void updateLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::updateLogicalLocation::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBO.updateLogicalLocation(locationBean);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::updateLogicalLocation::End");
	}

	/**
	 * Method removeLogicalLocationDetails.
	 * @param locationBean
	 */
	public void removeLogicalLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug("PaxTrax::LocationDelegate::removeLogicalLocationDetails::Begin");
		if (locationBOHome == null)
		{
			jndiCall();
		}
		try
		{
			locationBO.removeLogicalLocationDetails(locationBean);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
         PaxTraxLog.logDebug("PaxTrax::LocationDelegate::removeLogicalLocationDetails::End");
	}

}