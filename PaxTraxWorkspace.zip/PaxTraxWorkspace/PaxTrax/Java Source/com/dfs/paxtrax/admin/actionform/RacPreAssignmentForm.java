package com.dfs.paxtrax.admin.actionform;

import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * Form bean for a Struts application.
 * @version 	1.0
 * @author
 */
public class RacPreAssignmentForm extends PaxTraxActionForm {

	private RacPreAssignmentBean racPreAssignmentBean;
	private ArrayList racCodeList = null;
	private ArrayList preAssignmentRacList;
	private RacPreAssignmentBean racPreAssignmentSearchBean;

	/**
	 * Returns the racPreAssignmentBean.
	 * @return RacPreAssignmentBean
	 */
	public RacPreAssignmentBean getRacPreAssignmentBean() {
		return racPreAssignmentBean;
	}

	/**
	 * Sets the racPreAssignmentBean.
	 * @param racPreAssignmentBean The racPreAssignmentBean to set
	 */
	public void setRacPreAssignmentBean(RacPreAssignmentBean racPreAssignmentBean) {
		this.racPreAssignmentBean = racPreAssignmentBean;
	}

	/**
	 * Returns the racCodeList.
	 * @return ArrayList
	 */
	public ArrayList getRacCodeList() {
		return racCodeList;
	}

	/**
	 * Sets the racCodeList.
	 * @param racCodeList The racCodeList to set
	 */
	public void setRacCodeList(ArrayList racCodeList) {
		this.racCodeList = racCodeList;
	}

	/**
	 * Returns the racPreAssignmentSearchBean.
	 * @return RacPreAssignmentBean
	 */
	public RacPreAssignmentBean getRacPreAssignmentSearchBean() {
		return racPreAssignmentSearchBean;
	}

	/**
	 * Sets the racPreAssignmentSearchBean.
	 * @param racPreAssignmentSearchBean The racPreAssignmentSearchBean to set
	 */
	public void setRacPreAssignmentSearchBean(RacPreAssignmentBean racPreAssignmentSearchBean) {
		this.racPreAssignmentSearchBean = racPreAssignmentSearchBean;
	}

	/**
	 * Returns the preAssignmentRacList.
	 * @return ArrayList
	 */
	public ArrayList getPreAssignmentRacList() {
		return preAssignmentRacList;
	}

	/**
	 * Sets the preAssignmentRacList.
	 * @param preAssignmentRacList The preAssignmentRacList to set
	 */
	public void setPreAssignmentRacList(ArrayList preAssignmentRacList) {
		this.preAssignmentRacList = preAssignmentRacList;
	}

}
