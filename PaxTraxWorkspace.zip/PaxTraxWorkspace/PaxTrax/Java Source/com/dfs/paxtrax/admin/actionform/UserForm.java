package com.dfs.paxtrax.admin.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * This is the actionform that will hold the details of user.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */

public class UserForm extends PaxTraxActionForm
{

	//UserBean object
	private UserBean userBean = null;

	//List of languages
	private ArrayList languages = null;

	//List of selected Transaction ids
	private String[] selectedTransactionIds = null;

	//List of available transaction ids
	private ArrayList availableTransactionIds = null;

	public UserForm()
	{
	}

	/**
	 * Returns the availableTransactionIds.
	 * @return ArrayList List of available transactin ids
	 */
	public ArrayList getAvailableTransactionIds()
	{
		return availableTransactionIds;
	}

	/**
	 * Sets the availableTransactionIds.
	 * @param availableTransactionIds The availableTransactionIds to set
	 */
	public void setAvailableTransactionIds(ArrayList availableTransactionIds)
	{
		this.availableTransactionIds = availableTransactionIds;
	}

	/**
	 * Returns the languages.
	 * @return ArrayList List of languages
	 */
	public ArrayList getLanguages()
	{
		return languages;
	}

	/**
	 * Sets the languages.
	 * @param languages The languages to set
	 */
	public void setLanguages(ArrayList languages)
	{
		this.languages = languages;
	}

	/**
	 * Returns the userBean.
	 * @return UserBean User bean object
	 */
	public UserBean getUserBean()
	{
		return userBean;
	}

	/**
	 * Sets the userBean.
	 * @param userBean The userBean to set
	 */
	public void setUserBean(UserBean userBean)
	{
		this.userBean = userBean;
	}

	/**
	 * Returns the selectedTransactionIds.
	 * @return ArrayList List of seleceted transaction ids
	 */
	public String[] getSelectedTransactionIds()
	{
		return selectedTransactionIds;
	}

	/**
	 * Sets the selectedTransactionIds.
	 * @param selectedTransactionIds The selected transaction ids to set
	 */
	public void setSelectedTransactionIds(String[] selectedTransactionIds)
	{
		this.selectedTransactionIds = selectedTransactionIds;
	}
	
}
