package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;


/**
 * Remote interface for Enterprise Bean: UserBOManager
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Sundarrajan.k.	Created   
 * 07/28/2007	Uma D			Added method for CR 250 changes 
 **/	


public interface FlightBO extends EJBObject
{
	/**
	 * Saves flight details by invoking BO method.
	 * @param flightBean FlightBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving flight details
	 */
	public void saveFlightDetails(FlightBean flightBean) 
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	/**
	 * Updates flight details by invoking BO method.
	 * @param flightBean FlightBean 
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating flight details
	 */
	public void updateFlightDetails(FlightBean flightBean)
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	
	/**
	 * Deletes the flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in deleting flight details
	 */
	public void deleteFlightDetails(FlightBean flightBean) 
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	/**
	 * Insert override flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting override flight details
	 */
	public void insertOverrideFlightDetails(FlightBean flightBean) 
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	/**
	 * Removes the override flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in removing override flight details
	 */
	public void removeOverrideFlightDetails(FlightBean flightBean) 
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	/**
	 * Searches Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectFlightDetails(FlightBean flightBean)
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	
	/**
	 * Searches Override Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectOverrideFlightDetails(FlightBean flightBean)
		throws RemoteException, PaxTraxSystemException,FlightException;
	


	/**
	 * Searches Flight details based on the tab values and returns the 
	 * result. 
	 * @param flightBean
	 * @return FlightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public FlightBean selectMaintainFlightDetails(FlightBean flightBean)
		throws RemoteException, PaxTraxSystemException,FlightException;
	
	public ArrayList massFlightChange(FlightDetailsBean flightDetailsBean)
		throws PaxTraxSystemException,RemoteException;
	
	public ArrayList saveFlightDetails(ArrayList  flightpaxList)
		throws PaxTraxSystemException,RemoteException;	
		
//	Added on July 28, 2007 for CR 250 changes-- Begin		
	/**
	 * Checks whether Naccs is generated for the flight  
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxException is thrown if there is 
	 * any problem
	 * @throws FlightException
	 */		
	public void checkNaccsStatus(FlightBean flightBean)
		throws RemoteException, PaxTraxSystemException,FlightException;

//	Added on July 28, 2007 for CR 250 changes-- End

}
