package com.dfs.paxtrax.admin.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.actionform.RacPreAssignmentForm;
import com.dfs.paxtrax.admin.exception.RacPreAssignmentException;
import com.dfs.paxtrax.admin.service.RacPreAssignmentDelegate;
import com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * @version 	1.0
 * @author
 */
public class RacPreAssignmentAction extends PaxTraxAction {

	/**
	 * Loads the RAC Code in Create RAC Preassignment
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward createRacPreAssignment(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response)
	throws PaxTraxSystemException
	{

			
			PaxTraxLog.logDebug("PAXTrax::RacPreAssignmentAction::createRacPreAssignment::Begin");
			
			RacPreAssignmentForm racPreAssignmentForm =(RacPreAssignmentForm) form;
			RacPreAssignmentDelegate racPreAssignmentDelegate = new RacPreAssignmentDelegate();
			RacPreAssignmentBean racPreAssignmentBean =  null;
			ArrayList racCodes = null;
			
			
			racPreAssignmentBean = new RacPreAssignmentBean();
			racPreAssignmentForm.setRacPreAssignmentBean(racPreAssignmentBean);
				
			racCodes = racPreAssignmentDelegate.loadRacCodes();
			racPreAssignmentForm.setRacCodeList(racCodes);
				
						
			PaxTraxLog.logDebug("PAXTrax::RacPreAssignmentAction::createRacPreAssignment::End");
			
			return mapping.findForward("createRacPreAssignment");
	
			
	}
	
	/**
	 * Creates a RAC PreAssignment.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward createRacPreAssignmentConfirm(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response)
	throws PaxTraxSystemException
	{

			PaxTraxLog.logDebug("PAXTrax::RacPreAssignmentAction::createRacPreAssignment::Begin");
			
			RacPreAssignmentForm racPreAssignmentForm =(RacPreAssignmentForm) form;
			RacPreAssignmentDelegate racPreAssignmentDelegate = new RacPreAssignmentDelegate();
			RacPreAssignmentBean racPreAssignmentBean =  null;
			ArrayList racCodes = null;
			
			try
			{
				racPreAssignmentBean = racPreAssignmentForm.getRacPreAssignmentBean();

				HttpSession session = request.getSession();
				String userId=(String)session.getAttribute(PaxTraxConstants.USER);
				racPreAssignmentBean.setUser(userId);
				racPreAssignmentDelegate.createRacPreAssignment(racPreAssignmentBean );
				racPreAssignmentForm.setRacPreAssignmentBean(racPreAssignmentBean);
				request.setAttribute("racPreAssignmentFormValues", racPreAssignmentBean);
				PaxTraxLog.logDebug("PAXTrax::RacPreAssignmentAction::createRacPreAssignment::End");
				return mapping.findForward("createRacPreAssignmentConfirm");
				
			}
			catch (RacPreAssignmentException e) 
			{
					PaxTraxLog.logError("PAXTrax::RacPreAssignmentAction::createRacPreAssignment:: PAXTraxError", e);
							
					request.setAttribute(PaxTraxConstants.ERRORCODE,PaxTraxConstants.YES);
					return mapping.findForward("createRacPreAssignment");
			}
	
	}
		public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		{
		String forward = null;
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String fromMenu = request.getParameter("fromMenu");
		if (fromMenu != null) {
			request.setAttribute("fromMenu","Yes");
		}
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if(page.equals(PaxTraxConstants.SYSTEM_ERROR))
		{
			forward=PaxTraxConstants.SYSTEM_ERROR;
		}
		else
		{
			forward = page;
		}
		
		String errorCode = request.getParameter("errc");
		if (errorCode != null && !errorCode.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE,errorCode);
		}
		String pageNumber = (String)request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		PaxTraxLog.logDebug("RacPreAssignmentAction::changeLanguage::PaxTrax success-->"+ (String) request.getAttribute(PaxTraxConstants.RESULT));
		System.out.println("RacPreAssignmentAction::changeLanguage:: Forward Page "+ forward);
		return mapping.findForward(forward);

	}
	
	/**
	 * Searches for Rac Pre-Assignments given a rac code
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward searchRacPreAssignment(
										ActionMapping mapping,
										ActionForm form,
										HttpServletRequest request,
										HttpServletResponse response)
										throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentAction::searchRacPreAssignment::Begin");
		
		String fromMenu = (String)request.getParameter("fromMenu");
		String racModify = (String) request.getParameter("modify");
		RacPreAssignmentForm racForm = (RacPreAssignmentForm) form;
		RacPreAssignmentBean racPreAssignmentBean = racForm.getRacPreAssignmentBean();
		if (racPreAssignmentBean != null) {
			racPreAssignmentBean.setRacCode(request.getParameter("racCode"));
			if (racPreAssignmentBean.getRacCode()!= null 
				&& racPreAssignmentBean.getRacCode().equals("-1")) {
				racPreAssignmentBean.setRacCode(null);
			}
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentAction::searchRacPreAssignment::rac code"+ racForm.getRacPreAssignmentBean().getRacCode());
		}
		RacPreAssignmentDelegate racDelegate = new RacPreAssignmentDelegate();
		ArrayList racCodes = racDelegate.loadRacCodes();
		racForm.setRacCodeList(racCodes);

		if (fromMenu == null) {
			
			if (racModify != null) {
				PaxTraxLog.logDebug("Modify");
				PaxTraxLog.logDebug("Modify Bean set - Rac Code "+ racForm.getRacPreAssignmentBean().getRacCode());
				PaxTraxLog.logDebug("Modify Bean set - StartPax "+ racForm.getRacPreAssignmentBean().getStartPaxNumber());
				PaxTraxLog.logDebug("Modify Bean set - EndPax "+ racForm.getRacPreAssignmentBean().getEndPaxNumber());
				racForm.setRacPreAssignmentBean(racForm.getRacPreAssignmentSearchBean());
				racPreAssignmentBean = racForm.getRacPreAssignmentBean();
				PaxTraxLog.logDebug("Search List is " + racForm.getRacCodeList());
			} else {
				PaxTraxLog.logDebug("Search");
				racPreAssignmentBean = racForm.getRacPreAssignmentBean();
				PaxTraxLog.logDebug("Search Bean set - Rac Code "+ racForm.getRacPreAssignmentBean().getRacCode());
				PaxTraxLog.logDebug("Search Bean set - StartPax "+ racForm.getRacPreAssignmentBean().getStartPaxNumber());
				PaxTraxLog.logDebug("Search Bean set - EndPax "+ racForm.getRacPreAssignmentBean().getEndPaxNumber());
				RacPreAssignmentBean racSearchBean = new RacPreAssignmentBean();
				racSearchBean.setRacCode(racPreAssignmentBean.getRacCode());
				racForm.setRacPreAssignmentSearchBean(racSearchBean);
				PaxTraxLog.logDebug("Search List is " + racForm.getRacCodeList());
			}

			HttpSession session = request.getSession();
			int pageNumber = 0;
			ArrayList totalTARecords = null;
			ArrayList currentPageTARecords = null;


			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			if (pageNumber == 0)
			{
				int size = 0;
				pageNumber = 1;
				
				totalTARecords = racDelegate.searchRacPreAssignment(racPreAssignmentBean.getRacCode());
				if(totalTARecords != null)
				{
					size = totalTARecords.size();
				}
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, totalTARecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
			}
			else
			{
				totalTARecords = (ArrayList)session.getAttribute(PaxTraxConstants.ALL_RECORDS);
			}

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((totalTARecords != null) && (totalTARecords.size() !=0))
			{
			    currentPageTARecords = helper.getCurrentTableContent(totalTARecords,
		    	pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
			}

			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
			racForm.setPreAssignmentRacList(currentPageTARecords);
			//commForm.setCommBean(new CommBean());
		    request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			//PaxTraxLog.logDebug("CommTrax::COMMAction::searchTravelAgent::Output Records"+totalTARecords);
		}
		else
		{
			//request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
			/*
			 * On clicking Pre Assignment - menu link
			 */
			RacPreAssignmentBean racBean = new RacPreAssignmentBean();
			racBean.setRacCode("-1");
			racForm.setRacPreAssignmentBean(racBean);
			racForm.setPreAssignmentRacList(null);
			
			return mapping.findForward("searchRacPreAssignment");
		}
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentAction::searchRacPreAssignment:: "+ PaxTraxConstants.RESULT);
		
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentAction::searchRacPreAssignment::End");
		
		return mapping.findForward("searchRacPreAssignment");
	}
	
	/**
	 * Method modifySegment.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward modifyRacPreAssignment(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException {
			PaxTraxLog.logDebug("CommTrax::CommAction::modifyRacPreAssignment::Begin");
			RacPreAssignmentForm racForm = (RacPreAssignmentForm) form;
			RacPreAssignmentBean racBean = new RacPreAssignmentBean();
			RacPreAssignmentBean racFormBean = new RacPreAssignmentBean();
			String racCode = request.getParameter("racCode");
			String startPaxNo = request.getParameter("startPax");
			String endPaxNo = request.getParameter("endPax");
			
			//Added Remarks for CR1859
			RacPreAssignmentDelegate racDelegate = new RacPreAssignmentDelegate();
			String remarks = racDelegate.getRemarksFromDB(racCode, startPaxNo, endPaxNo);
			
			racFormBean.setRacCode(racCode);
			racFormBean.setStartPaxNumber(startPaxNo);
			racFormBean.setEndPaxNumber(endPaxNo);
			racFormBean.setRemarks(remarks);
			
			racBean.setRacCode(racCode);
			racBean.setStartPaxNumber(startPaxNo);
			racBean.setEndPaxNumber(endPaxNo);
			racBean.setRemarks(remarks);
			
			racForm.setRacPreAssignmentBean(racFormBean);
			HttpSession session = request.getSession();
			session.setAttribute(PaxTraxConstants.OLD_RAC_PREASSIGNMENT, racBean);
			RacPreAssignmentDelegate racPreAssignmentDelegate = new RacPreAssignmentDelegate();
			PaxTraxLog.logDebug("CommTrax::CommAction::modifyRacPreAssignment::End");
			return mapping.findForward("modifyRacPreAssignment");
	}
	
	/**
	 * Updates a segment
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward updateRacPreAssignment(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException {
			PaxTraxLog.logDebug("CommTrax::CommAction::updateRacPreAssignment::Begin");
			RacPreAssignmentForm racForm = (RacPreAssignmentForm) form;
			RacPreAssignmentBean updateRacBean = racForm.getRacPreAssignmentBean();
			String racPreAssignmentDelete = request.getParameter(PaxTraxConstants.DELETE);
			String racPreAssignmentModify = request.getParameter(PaxTraxConstants.MODIFY);
			RacPreAssignmentDelegate racPreAssignmentDelegate = new RacPreAssignmentDelegate();
			HttpSession session = request.getSession();
			String userId=(String)session.getAttribute(PaxTraxConstants.USER);
			updateRacBean.setUser(userId);

			try {
				RacPreAssignmentBean racBean = (RacPreAssignmentBean) 
										session.getAttribute(PaxTraxConstants.OLD_RAC_PREASSIGNMENT);
				racBean.setUser(userId);
				// Delete the Rac Pre-Assignment
				if (racPreAssignmentDelete != null && racPreAssignmentDelete.equals(PaxTraxConstants.TRUE)) {

					racPreAssignmentDelegate.deleteRacPreAssignment(racBean);
					request.setAttribute(PaxTraxConstants.ACTIVE, PaxTraxConstants.DELETE);
					request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);

				} else if (racPreAssignmentModify != null && racPreAssignmentModify.equals(PaxTraxConstants.TRUE)) {
					// Modify the Rac Pre-Assignment
					
					
					PaxTraxLog.logDebug("old start pax"+ racBean.getStartPaxNumber());
					PaxTraxLog.logDebug("old end pax"+ racBean.getEndPaxNumber());
					PaxTraxLog.logDebug("new start pax"+ updateRacBean.getStartPaxNumber());
					PaxTraxLog.logDebug("new end pax"+ updateRacBean.getEndPaxNumber());
		
					racPreAssignmentDelegate.modifyRacPreAssignment(racBean, updateRacBean);
					request.setAttribute(PaxTraxConstants.ACTIVE, PaxTraxConstants.UPDATE);
					request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				}
			} catch (RacPreAssignmentException e) {
				PaxTraxLog.logError("CommTrax::CommAction::updateSegment:: CommTraxError", e);
				request.setAttribute(PaxTraxConstants.ERROR, PaxTraxConstants.UPDATE_FAILURE);
			}
			PaxTraxLog.logDebug("CommTrax::CommAction::modifySegment::End");
			return mapping.findForward("modifyRacPreAssignment");
	}

}
