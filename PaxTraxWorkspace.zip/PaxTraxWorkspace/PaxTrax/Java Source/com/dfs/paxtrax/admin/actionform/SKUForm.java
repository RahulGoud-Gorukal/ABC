package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.SKUBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;


/**
 * This is the actionform that holds user sku attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/04/2004	Yuvarani    	Created
 */

public class SKUForm extends PaxTraxActionForm
{
	
	// SKUBean
	private SKUBean skuBean = null;

	// List of duty types
	private ArrayList dutyTypes = null;

	// List of locations
	private ArrayList locationList = null;

	// Disabling Field Values
	private String disableText = null;

	// Disabling Field Values
	private String disableSizeText = null;
	
	//Disabling page
	private String itemCheck = null;
	
	/**
	 * Constructor for this class
	 */
	public SKUForm()
	{
	}

	/**
	 * Returns the locationList.
	 * @return ArrayList
	 */
	public ArrayList getLocationList()
	{
		return locationList;
	}

	/**
	 * Sets the locationList.
	 * @param locationList The locationList to set
	 */
	public void setLocationList(ArrayList locationList)
	{
		this.locationList = locationList;
	}

	/**
	 * Returns the dutyTypes.
	 * @return ArrayList
	 */
	public ArrayList getDutyTypes()
	{
		return dutyTypes;
	}

	/**
	 * Sets the dutyTypes.
	 * @param dutyTypes The dutyTypes to set
	 */
	public void setDutyTypes(ArrayList dutyTypes)
	{
		this.dutyTypes = dutyTypes;
	}

	/**
	 * Returns the skuBean.
	 * @return SKUBean
	 */
	public SKUBean getSkuBean()
	{
		return skuBean;
	}

	/**
	 * Sets the skuBean.
	 * @param skuBean The skuBean to set
	 */
	public void setSkuBean(SKUBean skuBean)
	{
		this.skuBean = skuBean;
	}

	/**
	 * Returns the disableText.
	 * @return String
	 */
	public String getDisableText()
	{
		return disableText;
	}

	/**
	 * Sets the disableText.
	 * @param disableText The disableText to set
	 */
	public void setDisableText(String disableText)
	{
		this.disableText = disableText;
	}

	/**
	 * Returns the disableSizeText.
	 * @return String
	 */
	public String getDisableSizeText()
	{
		return disableSizeText;
	}

	/**
	 * Sets the disableSizeText.
	 * @param disableSizeText The disableSizeText to set
	 */
	public void setDisableSizeText(String disableSizeText)
	{
		this.disableSizeText = disableSizeText;
	}

	/**
	 * Returns the itemCheck.
	 * @return String
	 */
	public String getItemCheck()
	{
		return itemCheck;
	}

	/**
	 * Sets the itemCheck.
	 * @param itemCheck The itemCheck to set
	 */
	public void setItemCheck(String itemCheck)
	{
		this.itemCheck = itemCheck;
	}

	public void reset(ActionMapping mapping,HttpServletRequest request)
	{
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
		{
			if (page.equals(PaxTraxConstants.MAINTAIN_SKU_JSP))
			{
				if (skuBean != null)
				{
					skuBean.setGiftWithPurchase("N");
				}
			}
		}
	}

}
