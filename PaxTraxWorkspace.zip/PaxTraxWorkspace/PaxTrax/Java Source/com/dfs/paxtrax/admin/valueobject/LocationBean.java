package com.dfs.paxtrax.admin.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;



/**
* This is valueobject class which contains selling location attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 22/03/2004    Joseph Oommen A Created   
*/

public class LocationBean extends PaxTraxValueObject
{
    /*
     * location name
     */
    private String location = null;

    /*
     * Description about the location
     */
    private String description = null;
    
    /*
     *String isBagTrackingRequired 
     */
    private String isBagTrackingRequired = null;
    
    /*
     * String isOverideRefundRequired
     */
    /*private String isOverideRefundRequired =null;*/
    
   /*Flag used for checking whether spend limit tracking 
    *is required or not.
    */
    private String isSpendLimitTrackingRequired = null;
    
    /*
     * Duty free spending limit
     */
    private int dutyFreeSpendingLimit = 0;
    
    /*
     * Cut off time specified in hour
     */
    private String hrCutOffTime = null;
    
    /*
     * Cut off time specified in minutes
     */
    private String minCutOffTime = null;

    /*
     * String locationType
     */
    private String locationType = null;
    
    /*
     * String locationTypeReferenceId
     */
    private String locationTypeReferenceId=null;
    
    
    /*
     *String locationTypeFlag
     */
    private String locationTypeFlag =null;
    
    /* Property to decide if auto PAX Number generation is required */
    private String isAutoPAXRequired = null;
    
    /* Property that will hold the bonded warehouse code */
    private String bondedWarehouseCode = null;
    
    //ArrayList addedLocations
    private String[] addedLocations = null;
    
    
    /**
     * Default Constructor for the LocationBean Class
     */
    public LocationBean()
    {
    }
    
    /**
     * Gets location 
     * @return String - location
     */
    public String getLocation()
    {
        return location;
    }
    
    /**
     * Set location
     * @param String location
     */
    public void setLocation(String location)
    {
        this.location = location;
    }
    
    /**
     * Gets description
     * @return String - description
     */
    public String getDescription()
    {
        return description;
    }
    
    /**
     * Set description
     * @param String description
     */
    public void setDescription(String description)
    {
        this.description = description;
    }
    
    /**
     * Gets description
     * @return String - locationType
     */
    public String getLocationType()
    {
        return locationType;
    }
    
    /**
     * Set description
     * @param String location
     */
    public void setLocationType(String locationType)
    {
        this.locationType = locationType;
    }
    
    /**
     * Gets isSpendLimitTrackingRequired
     * @return boolean - isSpendLimitTrackingRequired
     */
    public String getIsSpendLimitTrackingRequired()
    {
        return isSpendLimitTrackingRequired;
    }
    
    /**
     * Set isSpendLimitTrackingRequired
     * @param boolean isSpendLimitTrackingRequired
     */
    public void setIsSpendLimitTrackingRequired(String isSpendLimitTrackingRequired)
    {
        this.isSpendLimitTrackingRequired = isSpendLimitTrackingRequired;
    }
    
    /**
     * Gets dutyFreeSpendingLimit
     * @return int - dutyFreeSpendingLimit
     */
    public int getDutyFreeSpendingLimit()
    {
        return dutyFreeSpendingLimit;
    }
    
    /**
     * Set dutyFreeSpendingLimit
     * @param int dutyFreeSpendingLimit
     */
    public void setDutyFreeSpendingLimit(int dutyFreeSpendingLimit)
    {
        this.dutyFreeSpendingLimit = dutyFreeSpendingLimit;
    }
    
    /**
     * Gets hrCutOffTime
     * @return int - hrCutOffTime
     */
    public String getHrCutOffTime()
    {
        return hrCutOffTime;
    }
    
    /**
     * Set hrCutOffTime
     * @param int hrCutOffTime
     */
    public void setHrCutOffTime(String hrCutOffTime)
    {
        this.hrCutOffTime = hrCutOffTime;
    }
    
    /**
     * Gets minCutOffTime
     * @return int - minCutOffTime
     */
    public String getMinCutOffTime()
    {
        return minCutOffTime;
    }
    
    /**
     * Set minCutOffTime
     * @param int minCutOffTime
     */
    public void setMinCutOffTime(String minCutOffTime)
    {
        this.minCutOffTime = minCutOffTime;
    }
    
    /**
     * Returns the locationTypeReferenceId.
     * @return String
     */
    public String getLocationTypeReferenceId()
    {
        return locationTypeReferenceId;
    }

    
    /**
     * Sets the locationTypeReferenceId.
     * @param locationTypeReferenceId The locationTypeReferenceId to set
     */
    public void setLocationTypeReferenceId(String locationTypeReferenceId)
    {
        this.locationTypeReferenceId = locationTypeReferenceId;
    }

    
    /**
     * Returns the isBagTrackingRequired.
     * @return String
     */
    public String getIsBagTrackingRequired()
    {
        return isBagTrackingRequired;
    }

    
    /**
     * Returns the isOverideRefundRequired.
     * @return String
     */
    /*public String getIsOverideRefundRequired()
    {
        return isOverideRefundRequired;
    }*/

    /**
     * Sets the isBagTrackingRequired.
     * @param isBagTrackingRequired The isBagTrackingRequired to set
     */
     public void setIsBagTrackingRequired(String isBagTrackingRequired)
    {
        this.isBagTrackingRequired = isBagTrackingRequired;
    }

    
    /**
     * Sets the isOverideRefundRequired.
     * @param isOverideRefundRequired The isOverideRefundRequired to set
     */
    /*public void setIsOverideRefundRequired(String isOverideRefundRequired)
    {
        this.isOverideRefundRequired = isOverideRefundRequired;
    }*/

    
    /**
     * Returns the locationTypeFlag.
     * @return String
     */
    public String getLocationTypeFlag()
    {
        return locationTypeFlag;
    }

    /**
     * Sets the locationTypeFlag.
     * @param locationTypeFlag The locationTypeFlag to set
     */
    public void setLocationTypeFlag(String locationTypeFlag)
    {
        this.locationTypeFlag = locationTypeFlag;
    }

    
    /**
     * Returns the bondedWarehouseCode.
     * @return String
     */
    public String getBondedWarehouseCode()
    {
        return bondedWarehouseCode;
    }

    /**
     * Returns the isAutoPAXRequired.
     * @return String
     */
    public String getIsAutoPAXRequired()
    {
        return isAutoPAXRequired;
    }

    /**
     * Sets the bondedWarehouseCode.
     * @param bondedWarehouseCode The bondedWarehouseCode to set
     */
    public void setBondedWarehouseCode(String bondedWarehouseCode)
    {
        this.bondedWarehouseCode = bondedWarehouseCode;
    }

    /**
     * Sets the isAutoPAXRequired.
     * @param isAutoPAXRequired The isAutoPAXRequired to set
     */
    public void setIsAutoPAXRequired(String isAutoPAXRequired)
    {
        this.isAutoPAXRequired = isAutoPAXRequired;
    }

	/**
	 * Returns the addedLocations.
	 * @return ArrayList
	 */
	public String[] getAddedLocations()
	{
		return addedLocations;
	}

	/**
	 * Sets the addedLocations.
	 * @param addedLocations The addedLocations to set
	 */
	public void setAddedLocations(String [] addedLocations)
	{
		this.addedLocations = addedLocations;
	}

}