package com.dfs.paxtrax.admin.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.SearchLocationForm;
import com.dfs.paxtrax.admin.service.LocationDelegate;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is action class which performs search location details
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
* 			DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE 			USER 			COMMENTS
* 22/03/2004	Joseph Oommen A	Created
*/

public class SearchLocationAction extends PaxTraxAction
{
	/*
	 * LocationDelegate locationDelgate
	 */
	private LocationDelegate locationDelegate = null;
	/*
	 * LocationBean locationBeanId
	 */
	private LocationBean locationBeanId = null;

	/**
	 * Searches  location by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in search location details
	 */

	public ActionForward searchLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::searchLocation::Begin");
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		operation = operation.trim();

		int pageNumber = 0;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		SearchLocationForm searchLocationForm = (SearchLocationForm) form;
		HttpSession session = request.getSession();
		String pageNumberStr = null;
		locationBeanId = searchLocationForm.getLocationBeanId();
		if (operation != ""
			&& operation != null
			&& ((PaxTraxConstants.UPDATE_SEARCH).equals(operation)
				|| (PaxTraxConstants.UPDATE_DELETE).equals(operation)))
			pageNumberStr =
				(String) session.getAttribute(PaxTraxConstants.PAGE_NUMBER);
		else
		{
			pageNumberStr = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			session.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumberStr);
		}

		/* If page number is null or empty it sets null otherwise
		 * it is same
		 */
		pageNumberStr =
			((pageNumberStr == null)
				|| pageNumberStr.equals(SQLConstants.BLANK))
				? null
				: pageNumberStr;
		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */
		if ((pageNumber == 0)
			|| ((PaxTraxConstants.UPDATE_SEARCH).equals(operation)
				|| (PaxTraxConstants.UPDATE_DELETE).equals(operation)))
		{
			int size = 0;
			if (pageNumber == 0)
				pageNumber = 1;

			locationDelegate = new LocationDelegate();

			allRecords = locationDelegate.searchLocationDetails(locationBeanId);
			ArrayList LocationTypes =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.LOCATION_TYPES);

			if (allRecords != null)
			{
				size = allRecords.size();
			}
			session.removeAttribute(PaxTraxConstants.ALL_LOCATION_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_LOCATION_RECORDS,
				allRecords);
			session.removeAttribute(
				PaxTraxConstants.SIZE_OF_ALL_LOCATION_RECORDS);
			session.setAttribute(
				PaxTraxConstants.SIZE_OF_ALL_LOCATION_RECORDS,
				Integer.toString(size));
		}
		else
		{

			allRecords =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_LOCATION_RECORDS);
		}
		PaginationHelper helper = PaginationHelper.getInstance();
		if ((allRecords != null) && (allRecords.size() != 0))
		{
			//Get records to be displayed for the passed page number
			currentRecords =
				(ArrayList) helper.getCurrentTableContent(
					allRecords,
					pageNumber,
					PaxTraxConstants.RECORDS_PER_PAGE);
		}
		request.setAttribute(
			PaxTraxConstants.PAGE_NUMBER,
			Integer.toString(pageNumber));
		if (currentRecords != null)
		{

		}
		searchLocationForm.setLocationCollection(currentRecords);
		if ((currentRecords == null) || (currentRecords.size() == 0))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.RECORD,
				new ActionMessage("" + PaxTraxConstants.NO_RECORDS_FOUND));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + PaxTraxConstants.NO_RECORDS_FOUND);
		}
		ArrayList locationTypes =
			(ArrayList) session.getAttribute(PaxTraxConstants.LOCATION_TYPES);
		String locationType = locationBeanId.getLocationType();
		for (int i = 0; i < locationTypes.size(); i++)
		{
			ReferenceDataBean referenceDataBean =
				(ReferenceDataBean) locationTypes.get(i);
			if (referenceDataBean.getCodeId().equals(locationType))
			{

				locationBeanId.setLocationTypeFlag(
					referenceDataBean.getCodeToFlag());
				break;
			}
		}
		searchLocationForm.setLocationBeanId(locationBeanId);
		String locationTypeFlag = locationBeanId.getLocationTypeFlag();

		// session.setAttribute(PaxTraxConstants.LOCATION_TYPE_FLAG,locationTypeFlag);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.SEARCH);
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::searchLocation::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_LOCATION_PAGE);
	}

	/**
	 * Forwards to search  location page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward searchLocationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::searchLocationPage::Begin");
		HttpSession session = request.getSession();
		SearchLocationForm searchLocationForm = (SearchLocationForm) form;
		locationBeanId = new LocationBean();
		searchLocationForm.setLocationBeanId(locationBeanId);
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList locationTypes = new ArrayList();
		locationTypes =
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.LOCATION_TYPE);
		int size = 0;
		StringBuffer locationTypeHide = new StringBuffer();
		if (locationTypes != null)
		{
			size = locationTypes.size();

			for (int i = 0; i < size; i++)
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) locationTypes.get(i);
				locationTypeHide.append(referenceDataBean.getCodeToFlag());
				locationTypeHide.append('~');
			}
			if (size > 0)
			{
				locationTypeHide.deleteCharAt(locationTypeHide.length() - 1);
			}
		}

		searchLocationForm.setLocationTypeHide(locationTypeHide.toString());
		//   session.setAttribute(PaxTraxConstants.LOCATION_TYPE_FLAG,PaxTraxConstants.YES);
		session.setAttribute(PaxTraxConstants.LOCATION_TYPES, locationTypes);
		session.setAttribute(
			PaxTraxConstants.HOUR_ARRAY,
			getArrayList(PaxTraxConstants.TIME_HR));
		session.setAttribute(
			PaxTraxConstants.MINUTE_ARRAY,
			getArrayList(PaxTraxConstants.TIME_MIN));
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::searchLocationPage::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_LOCATION_PAGE);
	}

	public ActionForward searchLogicalLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::searchLogicalLocation::Begin");

		int pageNumber = 0;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		SearchLocationForm searchLocationForm = (SearchLocationForm) form;
		HttpSession session = request.getSession();
		String pageNumberStr = null;

		pageNumberStr = request.getParameter(PaxTraxConstants.PAGE_NUMBER);

		/* If page number is null or empty it sets null otherwise
		 * it is same
		 */
		pageNumberStr =
			((pageNumberStr == null)
				|| pageNumberStr.equals(SQLConstants.BLANK))
				? null
				: pageNumberStr;
		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}

		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */
		if ((pageNumber == 0))
		{
			int size = 0;
			if (pageNumber == 0)
				pageNumber = 1;

			locationDelegate = new LocationDelegate();

			allRecords = locationDelegate.searchLogicalLocationDetails();

			if (allRecords != null)
			{
				size = allRecords.size();
			}
			session.removeAttribute(PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS,allRecords);
			session.removeAttribute(
				PaxTraxConstants.SIZE_OF_ALL_LOGICAL_LOCATION_RECORDS);
			session.setAttribute(
				PaxTraxConstants.SIZE_OF_ALL_LOGICAL_LOCATION_RECORDS,
				Integer.toString(size));
		}
		else
		{
			allRecords =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS);
		}
		
		PaginationHelper helper = PaginationHelper.getInstance();
		if ((allRecords != null) && (allRecords.size() != 0))
		{
			//Get records to be displayed for the passed page number
			currentRecords =
				(ArrayList) helper.getCurrentTableContent(
					allRecords,
					pageNumber,
					PaxTraxConstants.RECORDS_PER_PAGE);
		}
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
			Integer.toString(pageNumber));

		searchLocationForm.setLocationCollection(currentRecords);
		request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		request.setAttribute(PaxTraxConstants.FROM_PAGE,
			PaxTraxConstants.SEARCH_LOGICAL_LOCATION_PAGE);

		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::searchLogicalLocation::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_LOGICAL_LOCATION_PAGE);
	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::changeLanguage::Begin");

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
			page = page.trim();

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);
		String pageNumber =
			(String) request.getParameter(PaxTraxConstants.PAGE_NUMBER);

		request.setAttribute(PaxTraxConstants.FROM_PAGE,
			request.getParameter(PaxTraxConstants.FROM_PAGE));
		if (page != null && !pageNumber.equals("-1"))
		{
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		}
		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.SKU_ERROR,
				new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::changeLanguage::End");
		return mapping.findForward(page);

	}

	/**
	* Returns a temporary ArrayList with  values for Time Array
	* @param String type
	* @return ArrayList temp
	*/
	private ArrayList getArrayList(String type)
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SearchLocationAction::getArrayList::Begin");
		ReferenceDataBean commonBean = null;
		LocationBean locationBean = null;
		ArrayList temp = new ArrayList();
		for (int i = 0; i < 10; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}
		if (type.equals(PaxTraxConstants.TIME_HR))
		{
			for (int i = 10; i < 24; i++)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		else
			if (type.equals(PaxTraxConstants.TIME_MIN))
			{
				for (int i = 10; i < 60; i++)
				{
					commonBean = new ReferenceDataBean();
					commonBean.setCodeId(i + "");
					commonBean.setCodeValue(i + "");
					temp.add(commonBean);
				}
			}
		PaxTraxLog.logDebug("PaxTrax::SearchLocationAction::getArrayList::End");
		return temp;
	}
}