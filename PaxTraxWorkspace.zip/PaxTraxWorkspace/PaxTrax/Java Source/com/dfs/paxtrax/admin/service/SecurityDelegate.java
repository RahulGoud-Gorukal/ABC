package com.dfs.paxtrax.admin.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.business.UserBO;
import com.dfs.paxtrax.admin.business.UserBOHome;
import com.dfs.paxtrax.admin.exception.SecurityException;
import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * This is delegate class which performs jndi lookup and it act as a point of 
 * entry for business methods.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */


public class SecurityDelegate
{
	//Holds service locator instance
	private ServiceLocator serviceLocator = null;
	
	/**
	 * Constructor for this class
	 */
	public SecurityDelegate()
	{
	}

	private UserBOHome userBOHome = null;
	private UserBO userBO = null;
	
	private void jndiCall() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			userBOHome = (UserBOHome)PortableRemoteObject
				.narrow(serviceLocator.getEJBHome(PaxTraxConstants
					.USER_BO_BEAN_JNDI), UserBOHome.class);
		}
		catch (NamingException ne)
		{
			throw  new PaxTraxSystemException(ne);
		}		
		if (userBOHome == null)
		{
			throw new PaxTraxSystemException(
				PaxTraxConstants.USER_BO_HOME_NOT_FOUND);
		}
		try
		{
			userBO = userBOHome.create();			
		}
		catch (CreateException ce)
		{
			throw  new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw  new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::jndiCall::End");
	}

	/**
	 * Returns list of transactions
	 * @return ArrayList List of transactions
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in searching transactions
	 */
	public ArrayList searchTransactions()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::searchTransactions::Begin");
		ArrayList userList = null;
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userList = userBO.searchTransactions();		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::searchTransactions::End");		
		return userList;
	}
	
	/**
	 * Saves user details into the database by delegating the request to 
	 * manager bean. 
	 * @param userBean User bean object
	 * @throws PaxTraxSystemException
	 */
	public void saveUserDetails(UserBean userBean) 
		throws SecurityException, PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::saveUserDetails::Begin");
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userBO.saveUserDetails(userBean);		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}		
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::saveUserDetails::End");
	}

	/**
	 * Updates the status of the user whether it is active or deactive by 
	 * delegating the request to manager bean. 
	 * @param userBean User bean object
	 * @throws PaxTraxSystemException
	 */
	public void updateActicateStatus(UserBean userBean) 
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::updateActicateStatus::Begin");
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userBO.updateActivateStatus(userBean);		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}		
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::updateActicateStatus::End");
	}
	
	/**
	 * Updates the status of the user whether it is lock or unlock by 
	 * delegating the request to manager bean. 
	 * @param userBean User bean object
	 * @throws PaxTraxSystemException
	 */
	public void updateLockStatus(UserBean userBean) 
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::updateLockStatus::Begin");
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userBO.updateLockStatus(userBean);		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}		
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::updateLockStatus::End");
	}

	/**
	 * Returns user details based on search criteria by delegating the request 
	 * to manager bean. 
	 * @param userBean User bean object
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchUserDetails(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::searchUserDetails::Begin");
		ArrayList userList = null;
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userList = userBO.searchUserDetails(userBean);		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}		
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::searchUserDetails::End");
		return userList;
	}

	/**
	 * Marks this user details as deleted by delegating the request to manager 
	 * bean. 
	 * @param userBean User bean object
	 * @throws PaxTraxSystemException
	 */
	public void removeUserDetails(UserBean userBean) 
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::removeUserDetails::Begin");
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userBO.removeUserDetails(userBean);		
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}		
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::removeUserDetails::End");
		
	}

	/**
	 * Updates user details by delegating the request to manager bean. 
	 * @param userBean User bean object
	 * @throws PaxTraxSystemException
	 */
	public void updateUserDetails(UserBean userBean) 
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::updateUserDetails::Begin");
		if (userBOHome == null)
		{
			jndiCall();
		}
		try
		{
			userBO.updateUserDetails(userBean);
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}	
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::updateUserDetails::End");	
	}
    
    /**
     * Updates user password by delegating the request to the bean. 
     * @param userBean User bean object
     * @throws PaxTraxSystemException
     */
    
    public void changePassword(UserBean userBean)throws PaxTraxSystemException
    {
		PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::changePassword::Begin");       
        if (userBOHome == null)
        {
            jndiCall();
        }
        try
        {
            userBO.changePassword(userBean);
        }
        catch(RemoteException re)
        {
           	throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug("PaxTrax::SecurityDelegate::changePassword::End");              
    }
}
