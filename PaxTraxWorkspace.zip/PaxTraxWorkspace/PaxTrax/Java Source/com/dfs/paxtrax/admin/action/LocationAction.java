package com.dfs.paxtrax.admin.action;

/* *
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.LocationForm;
import com.dfs.paxtrax.admin.exception.LocationException;
import com.dfs.paxtrax.admin.service.LocationDelegate;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
* This is action class which performs insert, delete and update operations
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
* 			DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE 			USER 			COMMENTS
* 22/03/2004	Joseph Oommen A	Created
*/

public class LocationAction extends PaxTraxAction
{
	/**
	 * Forward page
	 */
	private String forward = null;
	/**
	 * LocationBean value Object
	 */
	private LocationBean locationBean = null;
	/**
	 * HttpSession Object
	 */
	private HttpSession session = null;
	/**
	 * LocationDelegate Object
	 */
	private LocationDelegate locationDelegate = null;

	/**
	 * Saves  location by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in save location details
	 */
	public ActionForward saveLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::saveLocation::Begin");

		LocationForm locationForm = (LocationForm) form;
		locationBean = locationForm.getLocationBean();

		String loctionTypeHide = locationForm.getLocationTypeSelected();
		if ((PaxTraxConstants.NO).equals(loctionTypeHide))
		{
			locationBean.setDutyFreeSpendingLimit(0);
			locationBean.setHrCutOffTime("00");
			locationBean.setIsBagTrackingRequired(null);
			locationBean.setIsAutoPAXRequired(null);
            locationBean.setBondedWarehouseCode(null);
			locationBean.setIsSpendLimitTrackingRequired(null);
			locationBean.setMinCutOffTime("00");

		}

		/* if Spend Limit Tracking is not required then duty free
		 * Spending limit should be zero
		 */
		String isSpendLimitTrackingRequired =
			locationBean.getIsSpendLimitTrackingRequired();
		if (isSpendLimitTrackingRequired != null
			&& isSpendLimitTrackingRequired.equals(PaxTraxConstants.NO))
			locationBean.setDutyFreeSpendingLimit(0);

		locationBean.setLocationTypeReferenceId(PaxTraxConstants.LOCATION_TYPE);
		locationDelegate = new LocationDelegate();
		try
		{
			session = request.getSession();
			locationBean.setUser(
				(String) session.getAttribute(PaxTraxConstants.USER_ID));
			locationDelegate.saveLocationDetails(locationBean);
			forward = PaxTraxConstants.VIEW_LOCATION_PAGE;
			ArrayList locationTypes = locationForm.getLocationTypes();
			String locationType = locationBean.getLocationType();
			for (int i = 0; i < locationTypes.size(); i++)
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) locationTypes.get(i);
				if (referenceDataBean.getCodeId().equals(locationType))
				{
					locationBean.setLocationType(
						referenceDataBean.getCodeValue());
					locationBean.setLocationTypeFlag(
						referenceDataBean.getCodeToFlag());
					break;
				}
			}
		}
		/*
		 * Catching the business Exception User Already Exists
		 */
		catch (LocationException locationException)
		{
			PaxTraxLog.logError(locationException.getMessage());
			ActionMessages messages = new ActionMessages();
			//messages.add(
			//	PaxTraxConstants.LOCATION_ERROR,
			//	new ActionMessage("" + locationException.getErrorCode()));
			//request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.PRESENT,
				String.valueOf(PaxTraxConstants.LOCATION_ALREADY_EXISTS));
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + locationException.getErrorCode());
			ArrayList locationTypes = new ArrayList();
			ReferenceDataDelegate referenceDataDelegate =
				new ReferenceDataDelegate();
			locationTypes =
				referenceDataDelegate.loadReferenceData(
					PaxTraxConstants.LOCATION_TYPE);
			int size = 0;
			StringBuffer locationTypeHide = new StringBuffer();
			if (locationTypes != null)
			{
				size = locationTypes.size();

				for (int i = 0; i < size; i++)
				{
					ReferenceDataBean referenceDataBean =
						(ReferenceDataBean) locationTypes.get(i);
					locationTypeHide.append(referenceDataBean.getCodeToFlag());
					locationTypeHide.append('~');
				}
				if (size > 0)
				{
					locationTypeHide.deleteCharAt(
						locationTypeHide.length() - 1);
				}
			}
			locationForm.setLocationTypeHide(locationTypeHide.toString());
			locationForm.setLocationTypes(locationTypes);
			locationForm.setTimeHr(getArrayList(PaxTraxConstants.TIME_HR));
			locationForm.setTimeMin(getArrayList(PaxTraxConstants.TIME_MIN));
			forward = PaxTraxConstants.CREATE_LOCATION_PAGE;
		}

		locationForm.setLocationBean(locationBean);

		/*
		 * Setting the operation as create
		 */
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.CREATE);
		session = request.getSession();
		session.setAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE, PaxTraxConstants.CREATE);
		PaxTraxLog.logDebug("PaxTrax::LocationAction::saveLocation::End");
		return mapping.findForward(forward);
	}

	/**
	 * Forwards to create location page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in forwarding to create location page
	 */

	public ActionForward createLocationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationAction::createLocationPage::Begin");
		session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.ADMIN);
		LocationForm locationForm = (LocationForm) form;
		locationBean = new LocationBean();
		locationForm.setLocationBean(locationBean);
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList locationTypes = new ArrayList();
		locationTypes =
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.LOCATION_TYPE);
		int size = 0;
		StringBuffer locationTypeHide = new StringBuffer();
		if (locationTypes != null)
		{
			size = locationTypes.size();

			for (int i = 0; i < size; i++)
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) locationTypes.get(i);
				locationTypeHide.append(referenceDataBean.getCodeToFlag());
				locationTypeHide.append('~');
			}
			if (size > 0)
			{
				locationTypeHide.deleteCharAt(locationTypeHide.length() - 1);
			}
		}

		locationForm.setLocationTypeHide(locationTypeHide.toString());
		locationForm.setLocationTypes(locationTypes);
		locationForm.setTimeHr(getArrayList(PaxTraxConstants.TIME_HR));
		locationForm.setTimeMin(getArrayList(PaxTraxConstants.TIME_MIN));
		/*request.setAttribute(
			PaxTraxConstants.CREATE_LOCATION,
			PaxTraxConstants.CREATE_LOCATION_PAGE_LOAD);*/
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation == null
			|| operation.equals("")
			|| (PaxTraxConstants.CREATE).equals(operation))
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.CREATE);
		else
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE);

		PaxTraxLog.logDebug("PaxTrax::LocationAction::createLocationPage::End");
		return mapping.findForward(PaxTraxConstants.CREATE_LOCATION_PAGE);
	}

	/**
	 * Forwards to Forwards to maintain location page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in forwading to maintainLocationPage
	 */

	public ActionForward maintainLocationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationAction::maintainLocationPage::Begin");
		session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.ADMIN);
		LocationForm locationForm = (LocationForm) form;
		LocationBean locationBean = new LocationBean();
		locationForm.setLocationBean(locationBean);
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList locationTypes = new ArrayList();
		locationTypes =
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.LOCATION_TYPE);
		int size = 0;

		StringBuffer locationTypeHide = new StringBuffer();
		if (locationTypes != null)
		{
			size = locationTypes.size();

			for (int i = 0; i < size; i++)
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) locationTypes.get(i);
				locationTypeHide.append(referenceDataBean.getCodeToFlag());
				locationTypeHide.append('~');
			}
			if (size > 0)
			{
				locationTypeHide.deleteCharAt(locationTypeHide.length() - 1);
			}
		}

		locationForm.setLocationTypeHide(locationTypeHide.toString());
		locationForm.setLocationTypes(locationTypes);
		locationForm.setTimeHr(getArrayList(PaxTraxConstants.TIME_HR));
		locationForm.setTimeMin(getArrayList(PaxTraxConstants.TIME_MIN));
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.UPDATE);
		PaxTraxLog.logDebug(
			"PaxTrax::LocationAction::maintainLocationPage::End");
		return mapping.findForward(PaxTraxConstants.CREATE_LOCATION_PAGE);
	}

	/**
	 * Load location details from search location or from tabout operation
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward loadLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::loadLocation::Begin");
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			operation = operation.trim();
		}
		LocationBean locationBean = null;
		LocationForm locationForm = null;

		/*
		 * if the user pressed tab , then
		 * LocationBean object should be loaded from the database
		 */
		if ((PaxTraxConstants.UPDATE).equals(operation)
			|| (PaxTraxConstants.UPDATE_DELETE).equals(operation))
		{
			locationForm = (LocationForm) form;
			locationBean = locationForm.getLocationBean();
			String location = locationBean.getLocation();
			location = location.trim();
			/*
			 * if location is null, then no Database Operation is required
			 */
			if (location == null || location.equals(""))
			{

				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.UPDATE);
			}
			/*
			 * if location is not null, then
			 * LocationBean should be loaded from the DataBase
			 */
			else
			{

				try
				{
					locationDelegate = new LocationDelegate();
					locationBean =
						locationDelegate.loadLocationDetails(location);
					locationBean.setLocation(location);
					locationForm.setLocationBean(locationBean);
					request.setAttribute(
						PaxTraxConstants.OPERATION,
						PaxTraxConstants.UPDATE_RELOAD);
				}
				/*
				 * if location not found
				 * Then Business Exception should be thrown
				 */
				catch (LocationException locationException)
				{
					PaxTraxLog.logError(locationException.getMessage());
					ActionMessages messages = new ActionMessages();

					messages.add(
						PaxTraxConstants.LOCATION_ERROR,
						new ActionMessage(
							"" + locationException.getErrorCode()));

					request.setAttribute(Globals.MESSAGE_KEY, messages);
					request.setAttribute(
						PaxTraxConstants.PRESENT,
						String.valueOf(PaxTraxConstants.LOCATION_NOT_FOUND));
					request.setAttribute(PaxTraxConstants.ERRORCODE,""+locationException.getErrorCode());
					request.setAttribute(
						PaxTraxConstants.OPERATION,
						PaxTraxConstants.UPDATE);

				}
			}
		}
		/*
		 * if the user is coming from the search page then
		 * LocationBean object should be retrievd from the session,
		 * ALL_LOCATION_RECORDS ,ArrayList with index
		 * same as one less than the serial number
		 */
		else
		{
			locationForm = (LocationForm) form;
			/*
			 * index value is passing as query String
			 */
			String index = request.getParameter(PaxTraxConstants.INDEX);
			index = index.trim();
			session = request.getSession();
			ArrayList locationCurrentRecords =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_LOCATION_RECORDS);
			locationBean =
				(LocationBean) locationCurrentRecords.get(
					Integer.parseInt(index) - 1);
			locationForm.setLocationBean(locationBean);
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE_SEARCH);
		}
		PaxTraxLog.logDebug("PaxTrax::LocationAction::loadLocation::End");
		return mapping.findForward(PaxTraxConstants.CREATE_LOCATION_PAGE);
	}

	/**
	 * Updates location by calling delegate method
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in update
	 */
	public ActionForward updateLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::updateLocation::Begin");
		String operation = request.getParameter("operation");

		if (operation != null)
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		LocationForm locationForm = (LocationForm) form;
		locationBean = locationForm.getLocationBean();
		String loctionTypeHide = locationForm.getLocationTypeSelected();
		if ((PaxTraxConstants.NO).equals(loctionTypeHide))
		{
			locationBean.setDutyFreeSpendingLimit(0);
			locationBean.setHrCutOffTime("00");
			locationBean.setIsBagTrackingRequired(null);
			locationBean.setIsAutoPAXRequired(null);
                   locationBean.setBondedWarehouseCode(null);
			locationBean.setIsSpendLimitTrackingRequired(null);
			locationBean.setMinCutOffTime("00");

		}

		String isSpendLimitTrackingRequired =
			locationBean.getIsSpendLimitTrackingRequired();
		if (isSpendLimitTrackingRequired != null
			&& isSpendLimitTrackingRequired.equals(PaxTraxConstants.NO))
			locationBean.setDutyFreeSpendingLimit(0);

		locationDelegate = new LocationDelegate();
		session = request.getSession();
		locationBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		locationDelegate.updateLocationDetails(locationBean);
		/*
		 * Updating  location in the  Session if
		 * control is transfered from search
		 */
		if ((PaxTraxConstants.UPDATE_SEARCH).equals(operation))
		{
			session = request.getSession();
			ArrayList locationCollection =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_LOCATION_RECORDS);
			int size;
			if (locationCollection != null)
				size = locationCollection.size();
			else
				size = 0;
			for (int i = 0; i < size; i++)
			{
				LocationBean locationBeanTemp =
					(LocationBean) locationCollection.get(i);
				if ((locationBeanTemp.getLocation())
					.equals(locationBean.getLocation()))
				{
					locationCollection.remove(i);
					locationCollection.add(i, locationBean);
					session.removeAttribute(
						PaxTraxConstants.ALL_LOCATION_RECORDS);
					session.setAttribute(
						PaxTraxConstants.ALL_LOCATION_RECORDS,
						locationCollection);
					break;
				}
			}
		}
		String locationType = locationForm.getLocationBean().getLocationType();
		ArrayList locationTypes = locationForm.getLocationTypes();
		int size;
		if (locationTypes != null)
			size = locationTypes.size();
		else
			size = 0;
		for (int i = 0; i < size; i++)
		{
			ReferenceDataBean referenceDataBean =
				(ReferenceDataBean) locationTypes.get(i);
			if (referenceDataBean.getCodeId().equals(locationType))
			{
				locationBean.setLocationType(referenceDataBean.getCodeValue());
				locationBean.setLocationTypeFlag(
					referenceDataBean.getCodeToFlag());
				break;
			}
		}
		locationForm.setLocationBean(locationBean);
		session = request.getSession();
		session.setAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE, PaxTraxConstants.UPDATE);
		PaxTraxLog.logDebug("PaxTrax::LocationAction::updateLocation::End");
		return mapping.findForward(PaxTraxConstants.VIEW_LOCATION_PAGE);
	}

	/**
	 * removes selling location by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in remove
	 */
	public ActionForward removeLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::removeLocation::Begin");
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		LocationForm locationForm = (LocationForm) form;
		locationBean = locationForm.getLocationBean();
		int size;

		try
		{
			locationDelegate = new LocationDelegate();
			session = request.getSession();
			locationBean.setUser(
				(String) session.getAttribute(PaxTraxConstants.USER_ID));
			locationDelegate.removeLocationDetails(locationBean);

			/*
			 * Removing  location in the  Session if
			 * control is transfered from search
			 */
			if ((PaxTraxConstants.UPDATE_SEARCH).equals(operation))
			{
				session = request.getSession();
				ArrayList locationCollection =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_LOCATION_RECORDS);
				if (locationCollection != null)
					size = locationCollection.size();
				else
					size = 0;
				int i;
				for (i = 0; i < size; i++)
				{
					LocationBean locationBeanTemp =
						(LocationBean) locationCollection.get(i);
					if ((locationBeanTemp.getLocation())
						.equals(locationBean.getLocation()))
					{
						locationCollection.remove(i);
						session.removeAttribute(
							PaxTraxConstants.ALL_LOCATION_RECORDS);
						session.setAttribute(
							PaxTraxConstants.ALL_LOCATION_RECORDS,
							locationCollection);
						break;
					}
				}
				/*
				* Adjusting the Page number
				*/
				if (size == 1)
				{
					/*
					 * if there was only one record and
					 * that got deleted then page number attribute
					 * should be removed from the session
					 */
					session.removeAttribute(PaxTraxConstants.PAGE_NUMBER);
				}
				else
					if ((size % 10) == 1 && (i == (size - 1)))
					{
						String pageNumber =
							(String) session.getAttribute(
								PaxTraxConstants.PAGE_NUMBER);
						int page = Integer.parseInt(pageNumber);
                        page =page-1;
						/*StringBuffer pageNumberString =
							new StringBuffer(page - 1);*/
                         String newString = ""+page;   
						session.setAttribute(
							PaxTraxConstants.PAGE_NUMBER,
							newString);
					}
			}
			locationForm.setLocationBean(locationBean);
			session = request.getSession();
			session.setAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE, PaxTraxConstants.DELETE);
			forward = PaxTraxConstants.VIEW_LOCATION_PAGE;
		}
		catch (LocationException locationException)
		{

			PaxTraxLog.logError(locationException.getMessage());
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.LOCATION_ERROR,
				new ActionMessage("" + locationException.getErrorCode()));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + locationException.getErrorCode());
			forward = PaxTraxConstants.VIEW_LOCATION_PAGE;
			session.removeAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE);
		}
		String locationType = locationBean.getLocationType();
		ArrayList locationTypes = locationForm.getLocationTypes();
		if (locationTypes != null)
			size = locationTypes.size();
		else
			size = 0;
		for (int i = 0; i < size; i++)
		{
			ReferenceDataBean referenceDataBean =
				(ReferenceDataBean) locationTypes.get(i);
			if (referenceDataBean.getCodeId().equals(locationType))
			{
				locationBean.setLocationType(referenceDataBean.getCodeValue());
				locationBean.setLocationTypeFlag(
					referenceDataBean.getCodeToFlag());
				break;
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationAction::removeLocation::End");
		return mapping.findForward(forward);
	}

	/**
	 * Forwards to selling location home page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward cancel(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::cancel::Begin");
		/*
		 * Removes All the values from the Session
		 * Control Transfers to Admin Home
		 */
		session = request.getSession();
		session.removeAttribute(PaxTraxConstants.LOCATION_TYPES);
		session.removeAttribute(PaxTraxConstants.HOUR_ARRAY);
		session.removeAttribute(PaxTraxConstants.MINUTE_ARRAY);
		session.removeAttribute(PaxTraxConstants.ALL_LOCATION_RECORDS);
		session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_LOCATION_RECORDS);
		PaxTraxLog.logDebug("PaxTrax::LocationAction::cancel::End");
		return mapping.findForward(PaxTraxConstants.ADMIN_HOME_PAGE);
	}

	public ActionForward createLogicalLocationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::createLogicalLocationPage"
			+"::Begin");
		LocationForm locationForm = (LocationForm)form;
		locationBean = new LocationBean();
		locationBean.setAddedLocations(new String[0]);
		locationForm.setLocationBean(locationBean);
		locationDelegate = new LocationDelegate();
		String[] availableList = locationDelegate.getAvailableLocations();
		locationForm.setAvailableLocations(availableList);
		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.ADMIN);
		return mapping.findForward(PaxTraxConstants.CREATE_LOGICAL_LOCATION_PAGE);
	}

	public ActionForward saveLogicalLocation(	
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::saveLogicalLocation"
			+"::Begin");
		LocationForm locationForm = (LocationForm)form;
		locationBean = locationForm.getLocationBean();
		locationDelegate = new LocationDelegate();
		try
		{
			locationDelegate.saveLogicalLocation(locationBean);
			forward = PaxTraxConstants.VIEW_LOGICAL_LOCATION_PAGE;	
		}
		catch (LocationException locationException)
		{
			PaxTraxLog.logError(locationException.getMessage());
			ActionMessages messages = new ActionMessages();
			request.setAttribute(
				PaxTraxConstants.PRESENT,
				String.valueOf(PaxTraxConstants.LOCATION_ALREADY_EXISTS));
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + locationException.getErrorCode());
			forward = PaxTraxConstants.CREATE_LOGICAL_LOCATION_PAGE;
		}	
		PaxTraxLog.logDebug("PaxTrax::LocationAction::saveLogicalLocation"
			+"::End");
		return mapping.findForward(forward);
	}

	public ActionForward maintainLogicalLocationPage(	
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::maintainLogicalLocationPage::Begin");
		LocationForm locationForm = (LocationForm)form;
		locationBean = new LocationBean();
		locationBean.setAddedLocations(new String[0]);
		locationForm.setLocationBean(locationBean);
		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.ADMIN);
		locationDelegate = new LocationDelegate();
		String[] availableList = locationDelegate.getAvailableLocations();
		locationForm.setAvailableLocations(availableList);
		PaxTraxLog.logDebug("PaxTrax::LocationAction::maintainLogicalLocationPage::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE);
	}

	public ActionForward getLogicalLocation(	
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::getLogicalLocation::Begin");
		LocationForm locationForm = (LocationForm)form;
		locationBean = locationForm.getLocationBean();
		locationDelegate = new LocationDelegate();
		try
		{
			locationBean = locationDelegate.getLogicalLocation(locationBean);
			String [] availableLocations = locationForm.getAvailableLocations();
			String [] addedLocations = locationBean.getAddedLocations();
			
			ArrayList addArray = new ArrayList();
			int availLength = availableLocations.length;
			for (int j = 0;j < availLength;j++)
			{
				addArray.add(availableLocations[j]);
			}
			
			int addLength = addedLocations.length;
			for (int i = 0;i < addLength;i++)
			{
				if (addArray.contains(addedLocations[i]))
					addArray.remove(addedLocations[i]);
			}
		
			availableLocations = new String[addArray.size()];
			if (addArray != null)
			{
				for (int k = 0;k < addArray.size();k++)
				{
					availableLocations[k] = (String)addArray.get(k);
				}
			}
			request.setAttribute(PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE);
			locationForm.setAvailableLocations(availableLocations);
			locationForm.setLocationBean(locationBean);
			request.setAttribute(PaxTraxConstants.SUCCESS,PaxTraxConstants.TRUE);
		}
		catch (LocationException locationException)
		{
			PaxTraxLog.logError(locationException.getMessage());
			ActionMessages messages = new ActionMessages();
			request.setAttribute(
				PaxTraxConstants.PRESENT,
				String.valueOf(PaxTraxConstants.LOCATION_NOT_FOUND));
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + locationException.getErrorCode());
		}	
		PaxTraxLog.logDebug("PaxTrax::LocationAction::getLogicalLocation::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE);
	}
	
	public ActionForward loadLogicalLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::loadLogicalLocationDetails::Begin");
		LocationForm locationForm = (LocationForm) form;
		HttpSession session = request.getSession();
		ArrayList allRecords =
			(ArrayList) session.getAttribute(PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS);
		int index = Integer.parseInt((String) request.getParameter("indexId"));
		LocationBean locationBean =
			(LocationBean) allRecords.get(index - 1);

		String[] availableLocations = locationDelegate.getAvailableLocations();
		String [] addedLocations = locationBean.getAddedLocations();

		ArrayList addArray = new ArrayList();
		int availLength = availableLocations.length;
		for (int j = 0;j < availLength;j++)
		{
			addArray.add(availableLocations[j]);
		}
		
		int addLength = addedLocations.length;
		for (int i = 0;i < addLength;i++)
		{
			if (addArray.contains(addedLocations[i]))
				addArray.remove(addedLocations[i]);
		}
	
		availableLocations = new String[addArray.size()];
		if (addArray != null)
		{
			for (int k = 0;k < addArray.size();k++)
			{
				availableLocations[k] = (String)addArray.get(k);
			}
		}

		locationForm.setAvailableLocations(availableLocations);
		locationForm.setLocationBean(locationBean);
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);
		request.setAttribute(
			PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute(PaxTraxConstants.SUCCESS, PaxTraxConstants.TRUE);
		PaxTraxLog.logDebug("PaxTrax::LocationAction::loadLogicalLocationDetails::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE);
	}
	
	public ActionForward updateLogicalLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::updateLogicalLocation"
			+"::Begin");
		LocationForm locationForm = (LocationForm)form;
		locationBean = locationForm.getLocationBean();
		String fromPage =
			(String) request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);

		String fromPageNumber =
			request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, fromPageNumber);

		locationDelegate = new LocationDelegate();
		locationDelegate.updateLogicalLocation(locationBean);
		forward = PaxTraxConstants.VIEW_MAINTAIN_LOGICAL_LOCATION_PAGE;	
		request.setAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE,
			PaxTraxConstants.UPDATE);
		PaxTraxLog.logDebug("PaxTrax::LocationAction::updateLogicalLocation"
			+"::End");
		return mapping.findForward(forward);
	}
	
	public ActionForward removeLogicalLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::removeLogicalLocation::Begin");
		LocationForm locationForm = (LocationForm) form;
		locationBean = locationForm.getLocationBean();
		int size;

		String fromPage =
			(String) request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);

		String fromPageNumber =
			request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, fromPageNumber);

		locationDelegate = new LocationDelegate();
		locationDelegate.removeLogicalLocationDetails(locationBean);

		/*
		 * Removing  location in the  Session if
		 * control is transfered from search
		 */
		if ((PaxTraxConstants.SEARCH_LOGICAL_LOCATION_PAGE).equals(fromPage))
		{
			session = request.getSession();
			ArrayList locationCollection =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS);
			if (locationCollection != null)
				size = locationCollection.size();
			else
				size = 0;
			int i;
			for (i = 0; i < size; i++)
			{
				LocationBean locationBeanTemp =
					(LocationBean) locationCollection.get(i);
				if ((locationBeanTemp.getLocation())
					.equals(locationBean.getLocation()))
				{
					locationCollection.remove(i);
					session.removeAttribute(
						PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS);
					session.setAttribute(
						PaxTraxConstants.ALL_LOGICAL_LOCATION_RECORDS,
						locationCollection);
					session.removeAttribute(
						PaxTraxConstants.SIZE_OF_ALL_LOGICAL_LOCATION_RECORDS);
					session.setAttribute(
						PaxTraxConstants.SIZE_OF_ALL_LOGICAL_LOCATION_RECORDS,
						Integer.toString(locationCollection.size()));
					break;
				}
			}

			/*
			* Adjusting the Page number
			*/
			if (size == 1)
			{
				/*
				 * if there was only one record and
				 * that got deleted then page number attribute
				 * should be removed from the session
				 */
				session.removeAttribute(PaxTraxConstants.PAGE_NUMBER);
			}
			else
				if ((size % 10) == 1 && (i == (size - 1)))
				{
					String pageNumber =
						(String) session.getAttribute(
							PaxTraxConstants.PAGE_NUMBER);
					if(pageNumber!=null && !"".equals(pageNumber))
					{
						int page = Integer.parseInt(pageNumber);
						page =page-1;
						/*StringBuffer pageNumberString =
							new StringBuffer(page - 1);*/
						 String newString = ""+page;   
						session.setAttribute(
							PaxTraxConstants.PAGE_NUMBER,
							newString);
					}
					if(fromPageNumber!=null && !"".equals(fromPageNumber))
					{
						int newPageNumber = Integer.parseInt(fromPageNumber)-1;
						request.setAttribute(PaxTraxConstants.PAGE_NUMBER, String.valueOf(newPageNumber));
					}
				}
		}
		locationForm.setLocationBean(locationBean);
		request.setAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE, PaxTraxConstants.DELETE);
		forward = PaxTraxConstants.VIEW_MAINTAIN_LOGICAL_LOCATION_PAGE;
		PaxTraxLog.logDebug("PaxTrax::LocationAction::removeLogicalLocation::End");
		return mapping.findForward(forward);
	}
	
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{

		PaxTraxLog.logDebug("PaxTrax::LocationAction::changeLanguage::Begin");

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
			page = page.trim();
		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);
        
        
      /*String presentValue =(String)request.getAttribute(PaxTraxConstants.PRESENT);
        if(presentValue !=null)*/
      
		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.SKU_ERROR,
				new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
               request.setAttribute(
                PaxTraxConstants.PRESENT,errorCode);
           
		}

		if ((PaxTraxConstants.VIEW_LOCATION).equals(page))
			forward = PaxTraxConstants.VIEW_LOCATION_PAGE;
		else if (PaxTraxConstants.CREATE_LOGICAL_LOCATION_PAGE.equals(page))
			forward = page;
		else if (PaxTraxConstants.VIEW_LOGICAL_LOCATION_PAGE.equals(page))
			forward = page;
		else if (PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE.equals(page))
		{
			String fromPage =
				request.getParameter(PaxTraxConstants.FROM_PAGE);
			String fromPageNumber =
				request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				fromPageNumber);
			request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);
			if (!fromPage.equals("null") && errorCode.equals("-1"))
			{
				request.setAttribute(PaxTraxConstants.SUCCESS,PaxTraxConstants.TRUE);
			}			
			forward = PaxTraxConstants.MAINTAIN_LOGICAL_LOCATION_PAGE;
		}
		else if (PaxTraxConstants.VIEW_MAINTAIN_LOGICAL_LOCATION_PAGE.equals(page))
		{
			String fromPage =
				request.getParameter(PaxTraxConstants.FROM_PAGE);
			String fromPageNumber =
				request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				fromPageNumber);
			request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);
			request.setAttribute(PaxTraxConstants.CONFIRMATION_MESSAGE,
				request.getParameter(PaxTraxConstants.CONFIRMATION_MESSAGE));
			forward = page;
		}
		else
			forward = PaxTraxConstants.CREATE_LOCATION_PAGE;
		PaxTraxLog.logDebug("PaxTrax::LocationAction::changeLanguage::End");
		return mapping.findForward(forward);

	}

	/**
	 * Returns a temporary ArrayList with  values for Time Array
	 * @param String type
	 * @return ArrayList temp
	 */
	private ArrayList getArrayList(String type)
	{
		PaxTraxLog.logDebug("PaxTrax::LocationAction::getArrayList::Begin");
		ReferenceDataBean commonBean = null;
		LocationBean locationBean = null;
		ArrayList temp = new ArrayList();
		for (int i = 0; i < 10; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}
		if (type.equals(PaxTraxConstants.TIME_HR))
		{
			for (int i = 10; i < 24; i++)
			{
				commonBean = new ReferenceDataBean();
				commonBean.setCodeId(i + "");
				commonBean.setCodeValue(i + "");
				temp.add(commonBean);
			}
		}
		else
			if (type.equals(PaxTraxConstants.TIME_MIN))
			{
				for (int i = 10; i < 60; i++)
				{
					commonBean = new ReferenceDataBean();
					commonBean.setCodeId(i + "");
					commonBean.setCodeValue(i + "");
					temp.add(commonBean);
				}
			}
		PaxTraxLog.logDebug("PaxTrax::LocationAction::getArrayList::End");
		return temp;
	}

}