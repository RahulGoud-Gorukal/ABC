package com.dfs.paxtrax.admin.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.SearchFlightForm;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.service.FlightDelegate;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This action class handles the user search by calling delegate
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 08/04/2004	Sundarrajan.K.	Created   
 */


public class SearchFlightAction extends PaxTraxAction
{

	//Forward page
	private String forward = null;	


	/**
	 * Searches user details for the given search criteria by calling 
	 * delegate method. 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in searching user details
	 */
	public ActionForward searchFlightDetails(ActionMapping mapping,
		ActionForm form, HttpServletRequest request, 
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::searchFlightDetails::Begin");			
		HttpSession session = request.getSession();   		
		int pageNumber = 0;
		String pageNumberStr = null;
		SearchFlightForm searchFlightForm = (SearchFlightForm) form;		
		FlightBean flightBean = searchFlightForm.getFlightBean();		
		ReferenceDataBean referenceDataBean = null;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		ReferenceDataBean airlineReferenceBean = null;
		ReferenceDataBean originAirportReferenceBean = null;
		ReferenceDataBean destinationAirportReferenceBean = null;
		ReferenceDataBean pickupLocationReferenceBean = null;
		
		airlineReferenceBean = flightBean.getAirlineBean();
		airlineReferenceBean.setReferenceId(PaxTraxConstants.AIRLINE_CODE);
		flightBean.setAirlineBean(airlineReferenceBean);
		
		originAirportReferenceBean = flightBean.getOriginAirportBean();
		originAirportReferenceBean.setReferenceId(PaxTraxConstants.AIRPORT);
		flightBean.setOriginAirportBean(originAirportReferenceBean);
		
		destinationAirportReferenceBean = flightBean.getDestinationAirportBean();
		destinationAirportReferenceBean.setReferenceId(PaxTraxConstants.AIRPORT);		
		flightBean.setDestinationAirportBean(destinationAirportReferenceBean);
		
		pickupLocationReferenceBean = flightBean.getPickupLocationBean();
		pickupLocationReferenceBean.setReferenceId(PaxTraxConstants.PICK_UP_LOCATION);
		flightBean.setPickupLocationBean(pickupLocationReferenceBean);
		String backToSearchUserPage = (String)request.getAttribute(
			PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE);
		
		if ((PaxTraxConstants.TRUE).equals(backToSearchUserPage))
		{
			pageNumberStr = (String) request.getAttribute(
				PaxTraxConstants.FLIGHT_PAGE_NUMBER);				
		}
		else
		{
			pageNumberStr = 
				request.getParameter(PaxTraxConstants.FLIGHT_PAGE_NUMBER);
		}
		 /* If page number is null or empty it sets null otherwise 
		  * it is same
		  */
		pageNumberStr = ((pageNumberStr == null) 
			|| pageNumberStr.equals(SQLConstants.BLANK)) ? null : pageNumberStr;
		
		if ((pageNumberStr != null)) {
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */
		if ((pageNumber == 0)) {
			int size = 0;
			pageNumber = 1;
			FlightDelegate flightDelegate = new FlightDelegate();
			try{
				allRecords = flightDelegate.selectFlightDetails(flightBean);
				
			}
			catch(FlightException fe)
			{
				PaxTraxLog.logError(fe.getMessage());
				ActionMessages messages = new ActionMessages();
    			messages.add("flightNumber", new ActionMessage("" + fe.getErrorCode()));
		    	request.setAttribute(Globals.MESSAGE_KEY,messages);		    			    	
			}
			//allRecords = getFlightDetails();	
			if (allRecords != null) 
			{
				size = allRecords.size();
			}
			session.removeAttribute(PaxTraxConstants.ALL_FLIGHT_RECORDS);
			session.setAttribute(PaxTraxConstants.ALL_FLIGHT_RECORDS, allRecords);
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_FLIGHT_RECORDS);
			session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_FLIGHT_RECORDS, 
			Integer.toString(size));
		}
		else 
		{
			allRecords = (ArrayList)
			session.getAttribute(PaxTraxConstants.ALL_FLIGHT_RECORDS);
		}	
		PaginationHelper helper = PaginationHelper.getInstance();
	
		if ((allRecords != null) && (allRecords.size() !=0)) {
	
		    currentRecords = helper.getCurrentTableContent(allRecords, 
	    	pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
	    	request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		}		
		request.setAttribute(PaxTraxConstants.FLIGHT_PAGE_NUMBER,Integer.toString(pageNumber));
	
		//Sets records to be displayed for the page number 
		searchFlightForm.setFlightCollection(currentRecords);	
		request.setAttribute(PaxTraxConstants.OPERATION,PaxTraxConstants.SEARCH);
		
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::searchFlightDetails::End");			
		return mapping.findForward(PaxTraxConstants.SEARCH_FLIGHT_PAGE);
	}
	
		

	/**
	 * Displays search user page
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward searchFlightPage(ActionMapping mapping,ActionForm form, HttpServletRequest request,HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::searchFlightPage::Begin");			
		SearchFlightForm searchFlightForm = (SearchFlightForm) form;
		FlightBean flightBean = new FlightBean();
		flightBean.setIsDeparture(true);
		//searchFlightForm.setIsDeparture(true);
		/*searchFlightForm.setAirlineCode("-1");		
		searchFlightForm.setDestinationAirport("-1");
		searchFlightForm.setOriginAirport("-1");
		searchFlightForm.setFlightType("1");
		searchFlightForm.setPickupLocation("-1");*/
		flightBean.setAirlineBean(new ReferenceDataBean());
    	flightBean.setOriginAirportBean(new ReferenceDataBean());
    	flightBean.setDestinationAirportBean(new ReferenceDataBean());
    	flightBean.setPickupLocationBean(new ReferenceDataBean());
		flightBean.setFlightNumber("");
		searchFlightForm.setFlightBean(flightBean);
		request.setAttribute(PaxTraxConstants.OPERATION,PaxTraxConstants.SEARCH);
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.UPDATE_FAILURE);		
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::searchFlightPage::End");			
		return mapping.findForward(PaxTraxConstants.SEARCH_FLIGHT_PAGE);
	}
	
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::changeLanguage::Begin");			
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		HttpSession session = request.getSession();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if(operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION,operation);
		}			
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page.equals(PaxTraxConstants.SEARCH_FLIGHT_PAGE))
		{			
			forward = PaxTraxConstants.SEARCH_FLIGHT_PAGE;
		}
		SearchFlightForm searchFlightForm = (SearchFlightForm) form;				
		ArrayList currentRecords = searchFlightForm.getFlightCollection();			
		if(currentRecords == null ||  (currentRecords.size() == 0))
		{			
			String noOfRecords = (String)
			session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_FLIGHT_RECORDS) ;
			if(noOfRecords != null)
			{
				ActionMessages messages = new ActionMessages();
	    		messages.add("record", new ActionMessage("" 
	    			+ PaxTraxConstants.NO_RECORDS_FOUND));
		    	request.setAttribute(Globals.MESSAGE_KEY,messages);
			}
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.UPDATE_FAILURE);
			
		}
		else
		{
			String pageNumber = (String)request.getAttribute(PaxTraxConstants.FLIGHT_PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.FLIGHT_PAGE_NUMBER,pageNumber);			
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.SUCCESS);
		}				
		
		PaxTraxLog.logDebug("PaxTrax::SearchFlightAction::changeLanguage::End");			
		return mapping.findForward(forward);
	}
	
}
