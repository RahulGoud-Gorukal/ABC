package com.dfs.paxtrax.admin.service;

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.business.RacPreAssignmentBO;
import com.dfs.paxtrax.admin.business.RacPreAssignmentBOHome;
import com.dfs.paxtrax.admin.exception.RacPreAssignmentException;
import com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

/**
 * @author 116038
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class RacPreAssignmentDelegate {


/**
 * Loads the list of RacCodes.
 * @return ArrayList
 * @throws PaxTraxSystemException
 */
public ArrayList loadRacCodes()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDelegate::loadRACCodes::Begin");
		ArrayList racCodes = null;
		try
		{
			
			ServiceLocator locator = ServiceLocator.getInstance();
			
			Object obj = locator.getEJBHome(PaxTraxConstants.RAC_PREASSIGNMENT_HOME_JNDI);
			RacPreAssignmentBOHome home =
				(RacPreAssignmentBOHome) PortableRemoteObject.narrow(obj, RacPreAssignmentBOHome.class);
			RacPreAssignmentBO remote = home.create();
			racCodes = remote.loadRacCodes();
		}catch(Exception ex)
		{
			PaxTraxLog.logError("PaxTrax::RacPreAssignmentDelegate::loadRACCodes::Exception", ex);
			throw new PaxTraxSystemException(ex);
		}
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDelegate::loadRACCodes::End");
		
		return racCodes;
	}
	
	//Added for CR1859
	/**
	 * Returns remarks for selected RacCode, startPaxNo and endPaxNo
	 * @return String
	 * @throws PaxTraxSystemException
	 */
	public String getRemarksFromDB(String racCode, String startPaxNo, String endPaxNo)
			throws PaxTraxSystemException
		{
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDelegate::getRemarksFromDB:Begin");
			String remarks = null;
			try
			{
			
				ServiceLocator locator = ServiceLocator.getInstance();
			
				Object obj = locator.getEJBHome(PaxTraxConstants.RAC_PREASSIGNMENT_HOME_JNDI);
				RacPreAssignmentBOHome home =
					(RacPreAssignmentBOHome) PortableRemoteObject.narrow(obj, RacPreAssignmentBOHome.class);
				RacPreAssignmentBO remote = home.create();
				remarks = remote.getRemarksFromDB(racCode, startPaxNo, endPaxNo);
			}catch(Exception ex)
			{
				PaxTraxLog.logError("PaxTrax::RacPreAssignmentDelegate::getRemarksFromDB::Exception", ex);
				throw new PaxTraxSystemException(ex);
			}
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDelegate::getRemarksFromDB::End");
		
			return remarks;
		}
	
	/**
	 * Createa a RacPreAssignment.
	 * @param racPreAssignmentBean
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void createRacPreAssignment(RacPreAssignmentBean racPreAssignmentBean) 
		throws RacPreAssignmentException, PaxTraxSystemException
	{
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::createRacPreAssignment::Begin");
		boolean returnValue = false;
		try
		{

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.RAC_PREASSIGNMENT_HOME_JNDI);
			RacPreAssignmentBOHome home =
				(RacPreAssignmentBOHome) PortableRemoteObject.narrow(obj, RacPreAssignmentBOHome.class);
			RacPreAssignmentBO remote = home.create();
			remote.createRacPreAssignment(racPreAssignmentBean);
		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::createRacPreAssignment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::createRacPreAssignment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::createRacPreAssignment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::createRacPreAssignment::End");
		
	}
	
	/**
	 * Searches for Rac Pre-Assignment given a rac company code.
	 * @param racCode rac company code
	 * @throws PaxTraxSystemException thrown on system error
	 */
	public ArrayList searchRacPreAssignment(String racCode) throws PaxTraxSystemException {
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::searchRacPreAssignment::Begin");
		ArrayList preAssignedRacList = null;
		try {

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.RAC_PREASSIGNMENT_HOME_JNDI);
			RacPreAssignmentBOHome home =
				(RacPreAssignmentBOHome) PortableRemoteObject.narrow(obj, RacPreAssignmentBOHome.class);
			RacPreAssignmentBO racPreAssignmentBO = home.create();
			preAssignedRacList = racPreAssignmentBO.searchRacPreAssignment(racCode);
			//returnValue = remote.createSegment(commBean);
		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::searchRacPreAssignment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::searchRacPreAssignment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::searchRacPreAssignment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::searchRacPreAssignment::End");
		return preAssignedRacList;
	}

	/**
	 * Searches for Rac Pre-Assignment given a rac company code.
	 * @param racCode rac company code
	 * @throws PaxTraxSystemException thrown on system error
	 */
	public void modifyRacPreAssignment(RacPreAssignmentBean racBean,
										RacPreAssignmentBean updateRacBean) 
		throws RacPreAssignmentException, PaxTraxSystemException {
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::modifyRacPreAssignment::Begin");
		try {
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.RAC_PREASSIGNMENT_HOME_JNDI);
			RacPreAssignmentBOHome home =
				(RacPreAssignmentBOHome) PortableRemoteObject.narrow(obj, RacPreAssignmentBOHome.class);
			RacPreAssignmentBO racPreAssignmentBO = home.create();
			racPreAssignmentBO.modifyRacPreAssignment(racBean, updateRacBean);
		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::modifyRacPreAssignment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::modifyRacPreAssignment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::modifyRacPreAssignment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::modifyRacPreAssignment::End");
	}

	/**
	 * Searches for Rac Pre-Assignment given a rac company code.
	 * @param racCode rac company code
	 * @throws PaxTraxSystemException thrown on system error
	 */
	public void deleteRacPreAssignment(RacPreAssignmentBean racBean) 
		throws RacPreAssignmentException, PaxTraxSystemException {
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::deleteRacPreAssignment::Begin");
		try {

			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.RAC_PREASSIGNMENT_HOME_JNDI);
			RacPreAssignmentBOHome home =
				(RacPreAssignmentBOHome) PortableRemoteObject.narrow(obj, RacPreAssignmentBOHome.class);
			RacPreAssignmentBO racPreAssignmentBO = home.create();
			racPreAssignmentBO.deleteRacPreAssignment(racBean);
		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::deleteRacPreAssignment",ne);
			throw new PaxTraxSystemException(ne);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::deleteRacPreAssignment",re);
			throw new PaxTraxSystemException(re);
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"PaxTrax::RacPreAssignmentDelegate::deleteRacPreAssignment",ce);
			throw new PaxTraxSystemException(ce);
		}
		PaxTraxLog.logDebug("RacPreAssignment::RacPreAssignmentDelegate::deleteRacPreAssignment::End");
	}

}
