package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;
import java.util.HashMap;

import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/03/2004	Sundarrajan.K.	Created   
 */


/**
   This is the action form that holds flight attributes
 */
public class SearchFlightForm extends PaxTraxActionForm{

	//Flight Bean
	FlightBean flightBean = null;
	
 	//Flight Number
    private String flightNumber = null;

	//Airline Code
	private String airlineCode = null;
	
	// Air line Number
    private String airlineName = null;  	
    
    // Flight Type
    private String flightType = null;
    
    //Origin Airport    
    private String originAirport = null;
    
    //Destination Airport
    private String destinationAirport = null;
    
    //Pickup Location
    private String pickupLocation = null;
    
    //Flight Schedule    
    private HashMap flightSchedule = null;
    
    //flight collection
    private ArrayList flightCollection = null;
   
   	//isDeparture
   	private boolean isDeparture = false; 
   
	/**
	 * Returns the airlineName.
	 * @return String
	 */
	public String getAirlineName() {
		return airlineName;
	}

	/**
	 * Returns the destinationAirport.
	 * @return String
	 */
	public String getDestinationAirport() {
		return destinationAirport;
	}

	/**
	 * Returns the flightCollection.
	 * @return ArrayList
	 */
	public ArrayList getFlightCollection() {
		return flightCollection;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * Returns the flightSchedule.
	 * @return HashMap
	 */
	public HashMap getFlightSchedule() {
		return flightSchedule;
	}

	/**
	 * Returns the flightType.
	 * @return String
	 */
	public String getFlightType() {
		return flightType;
	}

	/**
	 * Returns the originAirport.
	 * @return String
	 */
	public String getOriginAirport() {
		return originAirport;
	}

	/**
	 * Sets the airlineName.
	 * @param airlineName The airlineName to set
	 */
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	/**
	 * Sets the destinationAirport.
	 * @param destinationAirport The destinationAirport to set
	 */
	public void setDestinationAirport(String destinationAirport) {
		this.destinationAirport = destinationAirport;
	}

	/**
	 * Sets the flightCollection.
	 * @param flightCollection The flightCollection to set
	 */
	public void setFlightCollection(ArrayList flightCollection) {
		this.flightCollection = flightCollection;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the flightSchedule.
	 * @param flightSchedule The flightSchedule to set
	 */
	public void setFlightSchedule(HashMap flightSchedule) {
		this.flightSchedule = flightSchedule;
	}

	/**
	 * Sets the flightType.
	 * @param flightType The flightType to set
	 */
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	/**
	 * Sets the originAirport.
	 * @param originAirport The originAirport to set
	 */
	public void setOriginAirport(String originAirport) {
		this.originAirport = originAirport;
	}

	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode() {
		return airlineCode;
	}
	
	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation() {
		return pickupLocation;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Returns the isDeparture.
	 * @return boolean
	 */
	public boolean getIsDeparture() {
		return isDeparture;
	}

	/**
	 * Sets the isDeparture.
	 * @param isDeparture The isDeparture to set
	 */
	public void setIsDeparture(boolean isDeparture) {
		this.isDeparture = isDeparture;
	}

	/**
	 * Returns the flightBean.
	 * @return FlightBean
	 */
	public FlightBean getFlightBean() {
		return flightBean;
	}

	/**
	 * Sets the flightBean.
	 * @param flightBean The flightBean to set
	 */
	public void setFlightBean(FlightBean flightBean) {
		this.flightBean = flightBean;
	}

}
