package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;


/**
 * Remote interface for Enterprise Bean: ReferenceDataBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Vaikundamurthy	Created   
 */	


public interface ReferenceDataBO extends EJBObject
{
	/**
	 * Saves ReferenceData details by invoking BO method.
	 * @param referenceDataBO ReferenceDataBO object
	 * @return ArrayList Returns list if reference exists for particular data
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving ReferenceData details
	 */
	public ArrayList saveReferenceData(ReferenceDataListBean referenceDataListBean) 
		throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Loads reference data for the given reference type
	 * @param referenceType Reference type for which data is loaded
	 * @return ArrayList List of reference data
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in loading reference data
	 */
	public ArrayList loadReferenceData(String referenceType)
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Loads reference types
	 * @return ArrayList List of reference type
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in loading reference type
	 */
	public ArrayList loadReferenceType() 
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Loads travel agent information.
	 * @return ArrayList list of travel agent info beans
	 * @throws RemoteException thrown on bean creation.
	 * @throws PaxTraxSystemException thrown on sql error
	 */
	public ArrayList getTravelAgentCodes()
		throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Method getTravelAgentBranch.
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getTravelAgentBranches(String travelAgentCode)
		throws RemoteException, PaxTraxSystemException;
}
