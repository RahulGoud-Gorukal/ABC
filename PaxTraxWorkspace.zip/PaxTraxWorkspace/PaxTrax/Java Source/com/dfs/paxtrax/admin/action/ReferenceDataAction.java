package com.dfs.paxtrax.admin.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
/**
 * This action class handles reference databean creation and updation
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.ReferenceDataForm;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

public class ReferenceDataAction extends PaxTraxAction
{
	/**
	 * Forwards to MaintainReferencePage.
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward maintainReferenceDataPage(
		ActionMapping mapping, ActionForm form, HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::maintainReferenceDataPage::Begin");
		ReferenceDataDelegate referenceDataDelegate 
			= new ReferenceDataDelegate();	
		ReferenceDataForm referenceDataForm	= (ReferenceDataForm) form;
		ReferenceDataBean referenceDataBean = new ReferenceDataBean();
		ReferenceDataListBean referenceDataListBean 
			= new ReferenceDataListBean();
		referenceDataListBean.setCodeIds(new String[0]);
		referenceDataListBean.setCodeValues(new String[0]);
		referenceDataForm.setReferenceDataBean(referenceDataBean);	
		referenceDataForm.setReferenceDataListBean(referenceDataListBean);
		
		ArrayList referenceData = referenceDataDelegate.loadReferenceType();	
			
		referenceDataForm.setReferenceTypes(referenceData);
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::maintainReferenceDataPage::End");
		return mapping.findForward(
			PaxTraxConstants.MAINTAIN_REFERENCE_DATA_PAGE);	
	}
	
	
	/**
	 * Loads reference data for the reference id
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward loadReferenceData(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::loadReferenceData::Begin");
		ReferenceDataForm referenceDataForm = (ReferenceDataForm) form;
		ReferenceDataListBean referenceDataListBean 
			= referenceDataForm.getReferenceDataListBean();
		String refId = 	referenceDataListBean.getRefId();
		if(!refId.equals("-1"))
		{
			ReferenceDataDelegate referenceDataDelegate 
				= new ReferenceDataDelegate();	
			ArrayList referenceData = referenceDataDelegate.loadReferenceData(
				refId);		
			setLoadReferenceData(referenceDataForm, request, referenceData);
		}
		
		
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::loadReferenceData::End");	
		return mapping.findForward(
			PaxTraxConstants.MAINTAIN_REFERENCE_DATA_PAGE);	
	}
	
	
	/**
	 * Saves reference data
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward saveReferenceData(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::saveReferenceData::Begin");
		String forward = null;
		ReferenceDataBean referenceDataBean = null;
		ArrayList referenceDataBeanList = null;
		String[] fromTime = null;
		String[] toTime = null;
		String[] flags = null;
		String[] naccsCodes = null;
		boolean shift = false;
		boolean store = false;
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */
		boolean pickup = false;
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */

		boolean airlineCode = false;
		
		ReferenceDataForm referenceDataForm	= (ReferenceDataForm) form;
		ReferenceDataListBean referenceDataListBean 
			= referenceDataForm.getReferenceDataListBean();
		
		ReferenceDataDelegate referenceDataDelegate 
			= new ReferenceDataDelegate();	
		
		String[] codeIds =	referenceDataListBean.getCodeIds();
		String[] codeValues = referenceDataListBean.getCodeValues();
		if(codeIds != null)
		{
			int size = codeIds.length;
			if(size != 0 )
			{
				if(codeIds[0].equals("-1"))
				{
					referenceDataListBean.setCodeIds(null);
					referenceDataListBean.setCodeValues(null);
					referenceDataListBean.setFlags(null);
					referenceDataListBean.setNaccsCodes(null);	
					referenceDataListBean.setFromTime(null);
					referenceDataListBean.setToTime(null);
					referenceDataListBean.setReferenceDataBeanList(null);
				}
			}	
		}	
		ArrayList list 
			= referenceDataDelegate.saveReferenceData(referenceDataListBean);
		
		String refId = referenceDataListBean.getRefId();
		
		codeIds =	referenceDataListBean.getCodeIds();
		codeValues = referenceDataListBean.getCodeValues();
		if (PaxTraxConstants.SHIFT.equals(refId))
		{
			shift =true;
		}
		else if (PaxTraxConstants.LOCATION_TYPE.equals(refId))
		{
			store =true;
		}
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */

		else if (PaxTraxConstants.PICK_UP_LOCATION.equals(refId))
		{
					pickup =true;
		}
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */

		else if (PaxTraxConstants.AIRLINE_CODE.equals(refId))
		{
			airlineCode = true;		
		}
		ArrayList referenceTypes = referenceDataForm.getReferenceTypes();
		referenceDataListBean.setRefId(getRefValue(referenceTypes, refId));
		
		if (shift)
		{
			fromTime = referenceDataListBean.getFromTime();
			toTime = referenceDataListBean.getToTime();
		}
		if (store)
		{
			flags = referenceDataListBean.getFlags();
		}
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */

		if (pickup)
		{
			flags = referenceDataListBean.getFlags();
		}
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */

		if (airlineCode)
		{
			naccsCodes = referenceDataListBean.getNaccsCodes();
		}
		if (codeIds != null)
		{
			referenceDataBeanList = new ArrayList();	
			int size = codeIds.length;
			for (int i = 0; i < size; i++)
			{
				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setCodeId(codeIds[i]);
				referenceDataBean.setCodeValue(codeValues[i]);
				if (shift)
				{
					String time = fromTime[i];
					int position = time.indexOf(':');	
					referenceDataBean.setFromHr(time.substring(0,position));
					referenceDataBean.setFromMin(time.substring(position+1, 
						time.length()));
					time = toTime[i];
					position = time.indexOf(':');	
					referenceDataBean.setToHr(time.substring(0,position));
					referenceDataBean.setToMin(time.substring(position+1, 
						time.length()));	
				}
				if (store)
				{
					referenceDataBean.setCodeToFlag(flags[i]);
				}
				/*Modified on 28th June 2006 - Starts
				 *SR 1042 International DF Sale */
				if (pickup)
				{
					referenceDataBean.setCodeToFlag(flags[i]);
				}
				/*Modified on 28th June 2006 - Ends
				 *SR 1042 International DF Sale */

				if (airlineCode)
				{
					referenceDataBean.setNaccsCode(naccsCodes[i]);
				}
				referenceDataBeanList.add(referenceDataBean);
			}
			referenceDataListBean
				.setReferenceDataBeanList(referenceDataBeanList);
		}
		if	((list == null) || (list.size() == 0))
		{
			
			referenceDataForm.setReferenceDataListBean(referenceDataListBean);
			if (shift)
			{
				request.setAttribute(PaxTraxConstants.REFERENCE_TYPE, 
					PaxTraxConstants.SHIFT);
			}
			if (store)
			{
				request.setAttribute(PaxTraxConstants.REFERENCE_TYPE, 
					PaxTraxConstants.LOCATION_TYPE);	
			}
			/*Modified on 28th June 2006 - Starts
			 *SR 1042 International DF Sale */

			if (pickup)
			{
				request.setAttribute(PaxTraxConstants.REFERENCE_TYPE, 
					PaxTraxConstants.PICK_UP_LOCATION);	
			}
			
			/*Modified on 28th June 2006 - Ends
			 *SR 1042 International DF Sale */

			if (airlineCode)
			{
				request.setAttribute(PaxTraxConstants.REFERENCE_TYPE, 
					PaxTraxConstants.AIRLINE_CODE);		
			}
			forward = PaxTraxConstants.VIEW_REFERENCE_DATA_PAGE;
			request.setAttribute(PaxTraxConstants.RESULT, 
					PaxTraxConstants.SUCCESS);
		}
		else
		{
			referenceDataBeanList 
				=  referenceDataListBean.getReferenceDataBeanList();
			
			if(referenceDataBeanList  == null)
			{
				referenceDataBeanList = new ArrayList();		
			}
			
			int size = list.size();
			for (int i = 0; i < size; i++)
			{
				referenceDataBeanList.add(list.get(i));
			}
			
				
			referenceDataListBean.setReferenceDataBeanList(
				referenceDataBeanList);
			
			referenceDataListBean.setRefId(refId);
			ReferenceDataBean refDataBean = null;
			
			refDataBean = referenceDataForm.getReferenceDataBean();	
			refDataBean.setCodeId(null);
			refDataBean.setCodeValue(null);
			referenceDataForm.setReferenceDataBean(refDataBean);
			
					
			setLoadReferenceData(referenceDataForm, request, 
				referenceDataBeanList);
			ActionMessages messages = new ActionMessages();
    			messages.add("delete", new ActionMessage("" 
    				+ PaxTraxConstants.REFERENCE_ALREADY_EXISTS));
	    		request.setAttribute(Globals.MESSAGE_KEY,messages);
				request.setAttribute(PaxTraxConstants.RESULT, 
					PaxTraxConstants.FAILURE);	
			
			forward = PaxTraxConstants.MAINTAIN_REFERENCE_DATA_PAGE;
		}	
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::saveReferenceData::End");
		return mapping.findForward(forward);
	}
	
	private void setLoadReferenceData(ReferenceDataForm referenceDataForm, 
		HttpServletRequest request, ArrayList referenceData)
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::setLoadReferenceData::Begin");
		String[] codeIds = null;
		String[] codeValues = null;
		String[] fromTime = null;
		String[] toTime = null;
		String[] flags = null;
		String[] naccsCodes = null;
		ArrayList time = null;
		boolean shift = false;
		boolean store = false;
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */

		boolean pickup = false;
		
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */

		boolean airlineCode = false;
				
		ReferenceDataBean referenceDataBean = null;
		
		
		ReferenceDataListBean referenceDataListBean 
			= referenceDataForm.getReferenceDataListBean();
		String referenceType = referenceDataListBean.getRefId();		
		
		if (PaxTraxConstants.SHIFT.equals(referenceType))
		{
			shift =true;
		}
		else if (PaxTraxConstants.LOCATION_TYPE.equals(referenceType))
		{
			store = true;
		}
		/*Modified on 28th June 2006 - Starts
		 *SR 1042 International DF Sale */

		else if (PaxTraxConstants.PICK_UP_LOCATION.equals(referenceType))
		{
			pickup = true;
		}
		/*Modified on 28th June 2006 - Ends
		 *SR 1042 International DF Sale */

		else if (PaxTraxConstants.AIRLINE_CODE.equals(referenceType))
		{
			airlineCode = true;
		}
		
		
		if (shift)
		{
			
			time = new ArrayList();
			for (int i = 0; i < 24; i++)
			{
				if (i < 10)
				{
					time.add("0"+i);
				}
				else
				{
					time.add(""+i);
				}
			}
			referenceDataForm.setFromHrs(time);
			referenceDataForm.setToHrs(time);
			time = new ArrayList();
			for (int i = 0; i < 60; i++)
			{
				if (i < 10)
				{
					time.add("0"+i);
				}
				else
				{
					time.add(""+i);
				}
			}
			referenceDataForm.setFromMins(time);
			referenceDataForm.setToMins(time);
		}
		
		
		if (referenceData != null)
		{
			int size = referenceData.size();
			codeIds = new String[size];
			codeValues = new String[size];
			if (shift)
			{
				fromTime = new String[size];
				toTime = new String[size];	
			}
			else if (store)
			{
				flags = new String[size];
			}
			/*Modified on 28th June 2006 - Starts
			 *SR 1042 International DF Sale */

			else if (pickup)
			{
				flags = new String[size];
			}
			/*Modified on 28th June 2006 - Ends
			 *SR 1042 International DF Sale */

			else if (airlineCode)
			{
				naccsCodes = new String[size];
			}
			
			for(int i = 0; i < size; i++)
			{
				referenceDataBean = (ReferenceDataBean)	referenceData.get(i);
				codeIds[i] = referenceDataBean.getCodeId();
				codeValues[i] = referenceDataBean.getCodeValue();		
				if (shift)
				{
					fromTime[i] = referenceDataBean.getFromHr() 
						+ ":" + referenceDataBean.getFromMin();
					toTime[i] = referenceDataBean.getToHr() 
						+ ":" + referenceDataBean.getToMin();	
				}
				if (store)
				{
					flags[i] = referenceDataBean.getCodeToFlag();					
				}
				/*Modified on 28th June 2006 - Starts
				 *SR 1042 International DF Sale */

				if (pickup)
				{
					flags[i] = referenceDataBean.getCodeToFlag();					
				}
				/*Modified on 28th June 2006 - Ends
				 *SR 1042 International DF Sale */
		
				if (airlineCode)
				{
					naccsCodes[i] = referenceDataBean.getNaccsCode();
				}
			}
		}	
		referenceDataListBean.setCodeIds(codeIds);
		referenceDataListBean.setCodeValues(codeValues);
		if (shift)
		{
			referenceDataListBean.setFromTime(fromTime);
			referenceDataListBean.setToTime(toTime);
		}
		if (store)
		{
			referenceDataListBean.setFlags(flags);	
		}
		if (pickup)
		{
			referenceDataListBean.setFlags(flags);	
		}
		if (airlineCode)
		{
			referenceDataListBean.setNaccsCodes(naccsCodes);
		}
		referenceDataListBean.setRefId(referenceType);
		referenceDataListBean.setReferenceDataBeanList(referenceData);
		referenceDataForm.setReferenceDataListBean(referenceDataListBean);				
		
		request.setAttribute(PaxTraxConstants.OPERATION, 
			PaxTraxConstants.SUCCESS);
		
		request.setAttribute(PaxTraxConstants.REFERENCE_TYPE, 
			referenceType);
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::setLoadReferenceData::End");	
	}
	
	private String getRefValue(ArrayList refList, String codeId)
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::getRefValue::Begin");
		ReferenceDataBean referenceDataBean = null;
		String value = null;
		if(refList != null)
		{
			int size = refList.size();
			for (int i = 0; i < size; i++)
			{
				referenceDataBean = (ReferenceDataBean)	refList.get(i);
				if (codeId.equals(referenceDataBean.getCodeId()))
				{
					value = referenceDataBean.getCodeValue();			
				}
			}			
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::getRefValue::End");
		return value;
	}
	
	/**
	 * Used for language toggle
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::changeLanguage::Begin");
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		boolean flag = false;
		String selectedType = request.getParameter(PaxTraxConstants.REFERENCE_TYPE);
		request.setAttribute(PaxTraxConstants.REFERENCE_TYPE, selectedType);	
		String success = request.getParameter(PaxTraxConstants.RESULT);
		request.setAttribute(PaxTraxConstants.RESULT,success);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page.equals(PaxTraxConstants.MAINTAIN_REFERENCE_DATA_PAGE)) 
		{	
			ReferenceDataForm referenceDataForm	= (ReferenceDataForm) form;
			ReferenceDataListBean referenceDataListBean 
				= referenceDataForm.getReferenceDataListBean();
			String codeId = request.getParameter("codeId");				
			ReferenceDataBean referenceDataBean 
				= referenceDataForm.getReferenceDataBean();
			referenceDataBean.setCodeId(codeId);
			referenceDataForm.setReferenceDataBean(referenceDataBean);
			String[] codeIds =	referenceDataListBean.getCodeIds();			
			
			if (codeIds != null)
			{	ArrayList finalList = new ArrayList();		
				int length = codeIds.length;
				for (int i = 0; i < length; i++)				
				{				
					
					int size = 0;
					ArrayList beanList = referenceDataListBean
						.getReferenceDataBeanList();
					if (beanList != null && !beanList.isEmpty())
					{
						size = beanList.size();						
						for (int j = 0; j < size; j++)
						{
							
							referenceDataBean 
								= (ReferenceDataBean) beanList.get(j);							
							if(codeIds[i].equals(referenceDataBean.getCodeId()))
							{
								finalList.add(referenceDataBean);
								flag = true;
								break;
							}								
						}																	
					}					
				}			
				referenceDataListBean.setReferenceDataBeanList(finalList);
				referenceDataForm.setReferenceDataListBean(referenceDataListBean);
			}
			request.setAttribute(PaxTraxConstants.OPERATION, 
				PaxTraxConstants.SUCCESS);
			forward = PaxTraxConstants.MAINTAIN_REFERENCE_DATA_PAGE;
		}
		else
		{
			request.setAttribute(PaxTraxConstants.OPERATION, 
				PaxTraxConstants.SUCCESS);
			forward = PaxTraxConstants.VIEW_REFERENCE_DATA_PAGE;
		}
		String codeSelected = request.getParameter("codeSelected");
		request.setAttribute("codeSelected",codeSelected);
		String result = request.getParameter(PaxTraxConstants.RESULT);
		request.setAttribute(PaxTraxConstants.RESULT,result);		
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataAction::changeLanguage::End");
		return mapping.findForward(forward);
	}
}