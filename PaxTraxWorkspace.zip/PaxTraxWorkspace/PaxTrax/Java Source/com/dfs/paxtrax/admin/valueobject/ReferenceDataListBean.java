package com.dfs.paxtrax.admin.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * Class for storing code value pairs used for insertion 
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 14/04/2004	Vaikundamurthy	Created   
 */


public class ReferenceDataListBean extends PaxTraxValueObject
{
	//Holds refId
	private String refId = null;
	
	//Holds codeId
	private String codeId = null;
	
	//Holds codeValue
	private String codeValue = null;
	
	//Holds flag
	private String codeToFlag = PaxTraxConstants.NO;
	
	//Holds naccscode
	private String naccsCode = null;
	
	//Holds reference data bean
	private ArrayList referenceDataBeanList = null;
	
	//Holds list of code ids
	private String[] codeIds = null;
	
	//Holds list of code values
	private String[] codeValues = null;
	
	//Holds from time 
	private String[] fromTime = null;
	
	//Holds to time
	private String[] toTime = null;
	
	//Holds flags
	private String[] flags = null;
	
	//Holds naccs codes
	private String[] naccsCodes = null;
	
	/**
	 * Default constructor
	 */
	public ReferenceDataListBean() {
	}
	
	/**
	 * Gets the codeId
	 * @return String - Returns the codeId
	 */
	public String getCodeId() {
		return codeId;
	}
	
	/**
	 * Sets the codeId
	 * @param codeId The codeId to set
	 */
	public void setCodeId(String codeId) {
		if (codeId != null)
		{
			this.codeId = codeId.trim();
		}
	}

	/**
	 * Gets the codeValue
	 * @return String - Returns a codeValue
	 */
	public String getCodeValue() {
		return codeValue;
	}
	
	/**
	 * Sets the codeValue
	 * @param codeValue The codeValue to set
	 */
	public void setCodeValue(String codeValue) {
		if (codeValue != null)
		{
			this.codeValue = codeValue.trim();
		}		
	}
	/**
	 * Returns the codeIds.
	 * @return ArrayList
	 */
	public String[] getCodeIds()
	{
		return codeIds;
	}

	/**
	 * Returns the codeValues.
	 * @return String[]
	 */
	public String[] getCodeValues()
	{
		return codeValues;
	}

	/**
	 * Sets the codeIds.
	 * @param codeIds The codeIds to set
	 */
	public void setCodeIds(String[] codeIds)
	{
		this.codeIds = codeIds;
	}

	/**
	 * Sets the codeValues.
	 * @param codeValues The codeValues to set
	 */
	public void setCodeValues(String[] codeValues)
	{
		this.codeValues = codeValues;
	}

	/**
	 * Returns the referenceDataBeanList.
	 * @return ArrayList
	 */
	public ArrayList getReferenceDataBeanList()
	{
		return referenceDataBeanList;
	}

	/**
	 * Sets the referenceDataBeanList.
	 * @param referenceDataBeanList The referenceDataBeanList to set
	 */
	public void setReferenceDataBeanList(ArrayList referenceDataBeanList)
	{
		this.referenceDataBeanList = referenceDataBeanList;
	}

	/**
	 * Returns the refId.
	 * @return String
	 */
	public String getRefId()
	{
		return refId;
	}

	/**
	 * Sets the refId.
	 * @param refId The refId to set
	 */
	public void setRefId(String refId)
	{
		if (refId != null)
		{
			this.refId = refId.trim();
		}
	}

	/**
	 * Returns the fromTime.
	 * @return String[]
	 */
	public String[] getFromTime()
	{
		return fromTime;
	}

	/**
	 * Returns the toTime.
	 * @return String[]
	 */
	public String[] getToTime()
	{
		return toTime;
	}

	/**
	 * Sets the fromTime.
	 * @param fromTime The fromTime to set
	 */
	public void setFromTime(String[] fromTime)
	{
		this.fromTime = fromTime;
	}

	/**
	 * Sets the toTime.
	 * @param toTime The toTime to set
	 */
	public void setToTime(String[] toTime)
	{
		this.toTime = toTime;
	}

	/**
	 * Returns the codeToFlag.
	 * @return String
	 */
	public String getCodeToFlag()
	{
		return codeToFlag;
	}

	/**
	 * Returns the flags.
	 * @return String[]
	 */
	public String[] getFlags()
	{
		return flags;
	}

	/**
	 * Sets the codeToFlag.
	 * @param codeToFlag The codeToFlag to set
	 */
	public void setCodeToFlag(String codeToFlag)
	{
		if (codeToFlag != null)
		{
			this.codeToFlag = codeToFlag.trim();
		}
	}

	/**
	 * Sets the flags.
	 * @param flags The flags to set
	 */
	public void setFlags(String[] flags)
	{
		this.flags = flags;
	}

	/**
	 * Returns the naccsCode.
	 * @return String
	 */
	public String getNaccsCode()
	{
		return naccsCode;
	}

	/**
	 * Returns the naccsCodes.
	 * @return String[]
	 */
	public String[] getNaccsCodes()
	{
		return naccsCodes;
	}

	/**
	 * Sets the naccsCode.
	 * @param naccsCode The naccsCode to set
	 */
	public void setNaccsCode(String naccsCode)
	{
		if (naccsCode != null)
		{
			this.naccsCode = naccsCode.trim();
		}
	}

	/**
	 * Sets the naccsCodes.
	 * @param naccsCodes The naccsCodes to set
	 */
	public void setNaccsCodes(String[] naccsCodes)
	{
		this.naccsCodes = naccsCodes;
	}

}
