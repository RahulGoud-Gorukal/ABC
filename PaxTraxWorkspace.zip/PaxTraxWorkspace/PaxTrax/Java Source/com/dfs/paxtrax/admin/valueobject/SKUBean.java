package com.dfs.paxtrax.admin.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * This is value object which contains SKU attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/04/2004	Yuvarani    	Created      
 */

public class SKUBean extends PaxTraxValueObject {
	
    /**
       Selling location
     */
    private String sellingLocation = null;
    
    /**
       Item number
     */
    private String itemNumber = null;
    
    /**
       Item description
     */
    private String itemDescription = null;
    
    /**
       department
     */
    private String department = null;
    
    /**
       Unit price
     */
    private float unitPrice = 0;
    
    /**
       Duty type
     */
    private String dutyType = null;
    
    /**
       Promotion price
     */
    private float promotionPrice = 0;
    
    /**
       Promotion start date
     */
    private String promotionStartDate = null;
    
    /**
       Promotion end date
     */
    private String promotionEndDate = null;
    
    /**
       Harmonized code
     */
    private String harmonizedCode = null;
    
    /**
       Country of origin
     */
    private String countryOfOrigin = null;
    
    /**
       Tax type
     */
    private String taxType = null;
    
    /**
     * Upc Code
     */
    private String[] upcCodeList = null;
    
    /**
     * Deleted UPC Codes
     */
    private ArrayList deletedUpc = null;

    /**
     * size
     */
    private int size = 0;
    
    /**
     * Alcohol Strength
     */
    private int alcoholStrength = 0;
    
    /**
     * new price
     */
    private float newPrice = 0;
    
    /**
     * new price effective date
     */
    private String newPriceEffectiveDate = null;
    
	/**
	 * Gift with purchase
	 */
	private String giftWithPurchase = "N";
	
	/**
	 * LocationSkuList
	 */
	private ArrayList skuLocationList = null;

	/**
	 * Constructor for this class
	 */
    public SKUBean() {
    }
    
	/**
	 * Returns the sellingLocation.
	 * @return String
	 */
	public String getSellingLocation() {
		return sellingLocation;
	}

	/**
	 * Sets the sellingLocation.
	 * @param sellingLocation The sellingLocation to set
	 */
	public void setSellingLocation(String sellingLocation) {
		this.sellingLocation = sellingLocation;
	}
    
	/**
	 * Returns the itemNumber.
	 * @return String
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * Sets the itemNumber.
	 * @param itemNumber The itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
    
	/**
	 * Returns the itemDescription.
	 * @return String
	 */
	public String getItemDescription() {
		return itemDescription;
	}

	/**
	 * Sets the itemDescription.
	 * @param itemDescription The itemDescription to set
	 */
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
    
	/**
	 * Returns the department.
	 * @return String
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * Sets the department.
	 * @param department The department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
    
	/**
	 * Returns the dutyType.
	 * @return String
	 */
	public String getDutyType() {
		return dutyType;
	}

	/**
	 * Sets the dutyType.
	 * @param dutyType The dutyType to set
	 */
	public void setDutyType(String dutyType) {
		this.dutyType = dutyType;
	}
    
	/**
	 * Returns the promotionStartDate.
	 * @return String
	 */
	public String getPromotionStartDate() {
		return promotionStartDate;
	}

	/**
	 * Sets the promotionStartDate.
	 * @param promotionStartDate The promotionStartDate to set
	 */
	public void setPromotionStartDate(String promotionStartDate) {
		this.promotionStartDate = promotionStartDate;
	}
    
	/**
	 * Returns the promotionEndDate.
	 * @return String
	 */
	public String getPromotionEndDate() {
		return promotionEndDate;
	}

	/**
	 * Sets the promotionEndDate.
	 * @param promotionEndDate The promotionEndDate to set
	 */
	public void setPromotionEndDate(String promotionEndDate) {
		this.promotionEndDate = promotionEndDate;
	}
    
	/**
	 * Returns the harmonizedCode.
	 * @return String
	 */
	public String getHarmonizedCode() {
		return harmonizedCode;
	}

	/**
	 * Sets the harmonizedCode.
	 * @param harmonizedCode The harmonizedCode to set
	 */
	public void setHarmonizedCode(String harmonizedCode) {
		this.harmonizedCode = harmonizedCode;
	}
    
	/**
	 * Returns the countryOfOrigin.
	 * @return String
	 */
	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}

	/**
	 * Sets the countryOfOrigin.
	 * @param countryOfOrigin The countryOfOrigin to set
	 */
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}
    
	/**
	 * Returns the taxType.
	 * @return String
	 */
	public String getTaxType() {
		return taxType;
	}

	/**
	 * Sets the taxType.
	 * @param taxType The taxType to set
	 */
	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	/**
	 * Returns the upcCodeList.
	 * @return String[]
	 */
	public String[] getUpcCodeList() {
		return upcCodeList;
	}

	/**
	 * Sets the upcCodeList.
	 * @param upcCodeList The upcCodeList to set
	 */
	public void setUpcCodeList(String[] upcCodeList) {
		this.upcCodeList = upcCodeList;
	}

	/**
	 * Returns the size.
	 * @return int
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Sets the size.
	 * @param size The size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * Returns the alcoholStrength.
	 * @return int
	 */
	public int getAlcoholStrength() {
		return alcoholStrength;
	}

	/**
	 * Sets the alcoholStrength.
	 * @param alcoholStrength The alcoholStrength to set
	 */
	public void setAlcoholStrength(int alcoholStrength) {
		this.alcoholStrength = alcoholStrength;
	}
	
	/**
	 * Returns the newPriceEffectiveDate.
	 * @return String
	 */
	public String getNewPriceEffectiveDate() {
		return newPriceEffectiveDate;
	}

	/**
	 * Sets the newPriceEffectiveDate.
	 * @param newPriceEffectiveDate The newPriceEffectiveDate to set
	 */
	public void setNewPriceEffectiveDate(String newPriceEffectiveDate) {
		this.newPriceEffectiveDate = newPriceEffectiveDate;
	}

	/**
	 * Returns the newPrice.
	 * @return float
	 */
	public float getNewPrice()
	{
		return newPrice;
	}

	/**
	 * Sets the newPrice.
	 * @param newPrice The newPrice to set
	 */
	public void setNewPrice(float newPrice)
	{
		this.newPrice = newPrice;
	}

	/**
	 * Returns the promotionPrice.
	 * @return float
	 */
	public float getPromotionPrice()
	{
		return promotionPrice;
	}

	/**
	 * Sets the promotionPrice.
	 * @param promotionPrice The promotionPrice to set
	 */
	public void setPromotionPrice(float promotionPrice)
	{
		this.promotionPrice = promotionPrice;
	}

	/**
	 * Returns the unitPrice.
	 * @return float
	 */
	public float getUnitPrice()
	{
		return unitPrice;
	}

	/**
	 * Sets the unitPrice.
	 * @param unitPrice The unitPrice to set
	 */
	public void setUnitPrice(float unitPrice)
	{
		this.unitPrice = unitPrice;
	}


	/**
	 * Returns the deletedUpc.
	 * @return ArrayList
	 */
	public ArrayList getDeletedUpc()
	{
		return deletedUpc;
	}

	/**
	 * Sets the deletedUpc.
	 * @param deletedUpc The deletedUpc to set
	 */
	public void setDeletedUpc(ArrayList deletedUpc)
	{
		this.deletedUpc = deletedUpc;
	}

	/**
	 * Returns the giftWithPurchase.
	 * @return String
	 */
	public String getGiftWithPurchase()
	{
		return giftWithPurchase;
	}

	/**
	 * Sets the giftWithPurchase.
	 * @param giftWithPurchase The giftWithPurchase to set
	 */
	public void setGiftWithPurchase(String giftWithPurchase)
	{
		this.giftWithPurchase = giftWithPurchase;
	}

	/**
	 * Returns the skuLocationList.
	 * @return ArrayList
	 */
	public ArrayList getSkuLocationList()
	{
		return skuLocationList;
	}

	/**
	 * Sets the skuLocationList.
	 * @param skuLocationList The skuLocationList to set
	 */
	public void setSkuLocationList(ArrayList skuLocationList)
	{
		this.skuLocationList = skuLocationList;
	}

}
