package com.dfs.paxtrax.admin.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.dfs.paxtrax.admin.actionform.UserForm;
import com.dfs.paxtrax.admin.exception.SecurityException;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.service.SecurityDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.service.PurgeDelegate;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This action class handles user creation, updation and search by calling 
 * delegate
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */

public class UserAction extends PaxTraxAction
{
	//Forward page
	private String forward = null;

	private boolean updateFlag;

	/**
	 * Forwards to createUserPage.
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward createUserPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::createUserPage::Begin");
		HttpSession moduleSession = request.getSession();
		moduleSession.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.ADMIN);
		UserForm userForm = (UserForm) form;
		UserBean userBean = new UserBean();
		userBean.setUserId(null);
		userBean.setEmployeeId(null);
		userBean.setLastName(null);
		userBean.setFirstName(null);
		userBean.setDateOfBirth(null);
		//userBean.setLanguageBean(new ReferenceDataBean());
		//Random random = new Random();
		//userBean.setPassword(random.nextInt()+"");
			//PaxTraxConstants.DUMMY_PASSWORD + random.nextInt());
		/*ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList languages =
			referenceDataDelegate.loadReferenceData(PaxTraxConstants.LANUGAGES);
		userForm.setLanguages(languages);*/
		userForm.setUserBean(userBean);
		SecurityDelegate securityDelegate = new SecurityDelegate();
		userForm.setAvailableTransactionIds(
			securityDelegate.searchTransactions());
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.CREATE);
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.FALSE);
		PaxTraxLog.logDebug("PaxTrax::UserAction::createUserPage::End");
		return mapping.findForward(PaxTraxConstants.CREATE_USER_PAGE);
	}

	/**
	 * Performs actions related to user creation, updation, 
	 * mapping transaction etc.
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in saving user details
	 */
	public ActionForward saveUserDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::saveUserDetails::Begin");
		UserForm userForm = (UserForm) form;
		HttpSession session = request.getSession();
		UserBean userBean = userForm.getUserBean();
		userBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		String[] assignedTransactionIds = userBean.getAssignedTransactionIds();

		/*ReferenceDataBean languageBean = userBean.getLanguageBean();
		String languageId = languageBean.getCodeId();
		ArrayList languages = userForm.getLanguages();
		if ("-1".equals(languageId))
		{
			languageBean.setCodeId(null);
			languageBean.setCodeValue(null);
			languageBean.setReferenceId(null);
			userBean.setLanguageBean(languageBean);
		}
		else
		{
			if (languages != null)
			{
				int size = languages.size();
				for (int i = 0; i < size; i++)
				{
					ReferenceDataBean referenceDataBean =
						(ReferenceDataBean) languages.get(i);
					if (languageId.equals(referenceDataBean.getCodeId()))
					{
						languageBean.setReferenceId(
							referenceDataBean.getReferenceId());
						languageBean.setCodeValue(referenceDataBean.getCodeValue());
						userBean.setLanguageBean(languageBean);
						break;
					}
				}
			}
		}*/

		userBean.setActiveStatus(PaxTraxConstants.YES);
		userBean.setLockStatus(PaxTraxConstants.NO);

		SecurityDelegate securityDelegate = new SecurityDelegate();
		try
		{
			securityDelegate.saveUserDetails(userBean);
			assignedTransactionIds = userBean.getAssignedTransactionIds();
			if ((assignedTransactionIds == null)
				|| (assignedTransactionIds.length == 0))
			{
				request.setAttribute(PaxTraxConstants.PRESENT,
					PaxTraxConstants.FALSE);
			}
			updateFlag = true;
			setInputParameters(userForm);
			request.setAttribute(
				PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.CREATE_USER_PAGE);
			request.setAttribute(
				PaxTraxConstants.CONFIRM_MESSAGE,
				PaxTraxConstants.TRUE);
			ActionMessages messages = new ActionMessages();
			messages.add(
				"Save",
				new ActionMessage("" + PaxTraxConstants.SAVE_MESSAGE));
			request.setAttribute(
				PaxTraxConstants.RESULT,
				String.valueOf(PaxTraxConstants.SAVE_MESSAGE));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			forward = PaxTraxConstants.VIEW_USER_PAGE;
		}
		catch (SecurityException se)
		{
			PaxTraxLog.logError(se.getMessage());
			ActionMessages messages = new ActionMessages();
			messages.add("userId", new ActionMessage("" + se.getErrorCode()));
			request.setAttribute(
				PaxTraxConstants.RESULT,
				String.valueOf(PaxTraxConstants.USER_ALREADY_EXISTS));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.CREATE);
			forward = PaxTraxConstants.CREATE_USER_PAGE;
		}

		PaxTraxLog.logDebug("PaxTrax::UserAction::saveUserDetails::End");
		return mapping.findForward(forward);
	}
	
	/**
	 * Forwards to maintain user page
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward maintainUserPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::maintainUserPage::Begin");
		HttpSession moduleSession = request.getSession();
		moduleSession.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.ADMIN);
		UserForm userForm = (UserForm) form;

		UserBean userBean = new UserBean();
		userBean.setUserId(null);
		userBean.setEmployeeId(null);
		userBean.setPassword(null);
		userBean.setLastName(null);
		userBean.setFirstName(null);
		userBean.setDateOfBirth(null);

//		userBean.setLanguageBean(new ReferenceDataBean());
		userBean.setAssignedTransactions(new ArrayList());
/*		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList languages =
			referenceDataDelegate.loadReferenceData(PaxTraxConstants.LANUGAGES);
		userForm.setLanguages(languages);*/
		userForm.setUserBean(userBean);
		SecurityDelegate securityDelegate = new SecurityDelegate();
		userForm.setAvailableTransactionIds(
			securityDelegate.searchTransactions());
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.UPDATE);
		request.setAttribute(
			PaxTraxConstants.USER_DETAILS,
			PaxTraxConstants.FALSE);
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.FALSE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, PaxTraxConstants.TRUE);
		PaxTraxLog.logDebug("PaxTrax::UserAction::maintainUserPage::End");
		return mapping.findForward(PaxTraxConstants.CREATE_USER_PAGE);
	}
	/**
	 * Updates user details by calling delegate method. 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in updating user details
	 */
	public ActionForward updateUserDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::updateUserDetails::Begin");
		UserForm userForm = (UserForm) form;
		HttpSession session = request.getSession();
		UserBean userBean = userForm.getUserBean();
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		
		if (fromPage != null
			&& fromPage.equals(PaxTraxConstants.MAINTAIN_USER_PAGE))
		{	
			request.setAttribute(PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.MAINTAIN_USER_PAGE);
		}
		else
		{
			request.setAttribute(PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.SEARCH_USER_PAGE);
		}		
		
		userBean.setUser((String) 
			session.getAttribute(PaxTraxConstants.USER_ID));
		String[] assignedTransactionIds = userBean.getAssignedTransactionIds();
		String tries = request.getParameter("tries");
		
		if ((tries != null) && (tries.length() != 0))
		{
			userBean.setInvalidTries(Integer.parseInt(tries));
		}
		else
		{
			userBean.setInvalidTries(0);
		}
		
		userBean.setIsNeverLock(request.getParameter("locked"));
/*		ArrayList languages = userForm.getLanguages();
		ReferenceDataBean languageBean = userBean.getLanguageBean();

		if ("-1".equals(languageBean.getCodeId()))
		{
			ReferenceDataBean langBean = new ReferenceDataBean();
			langBean.setReferenceId(null);
			langBean.setCodeId(null);
			userBean.setLanguageBean(langBean);
		}
		else
		{
			if (languages != null)
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) languages.get(0);
				languageBean.setReferenceId(referenceDataBean.getReferenceId());
				userBean.setLanguageBean(languageBean);
			}
		}
		languageBean = userBean.getLanguageBean();*/
		SecurityDelegate securityDelegate = new SecurityDelegate();
		securityDelegate.updateUserDetails(userBean);
//		languageBean = userBean.getLanguageBean();
		
		updateFlag = false;
		setInputParameters(userForm);
		assignedTransactionIds = userBean.getAssignedTransactionIds();
		if ((assignedTransactionIds == null)
			|| (assignedTransactionIds.length == 0))
		{
			request.setAttribute(
				PaxTraxConstants.PRESENT,
				PaxTraxConstants.TRUE);
		}
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.PRESENT);

		ActionMessages messages = new ActionMessages();
		messages.add(
			"Update",
			new ActionMessage("" + PaxTraxConstants.UPDATE_MESSAGE));
		request.setAttribute(
			PaxTraxConstants.RESULT,
			String.valueOf(PaxTraxConstants.UPDATE_MESSAGE));
		request.setAttribute(Globals.MESSAGE_KEY, messages);
		PaxTraxLog.logDebug("PaxTrax::UserAction::updateUserDetails::End");
		return mapping.findForward(PaxTraxConstants.VIEW_USER_PAGE);
	}
	private void setInputParameters(UserForm userForm)
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::setInputParameters::Begin");
		ArrayList list = null;
		ArrayList availableTransactions = null;
		ArrayList assignList = null;
		ReferenceDataBean referenceDataBean = null;
		ReferenceDataBean assignedTransactionBean = null;
		UserBean userBean = userForm.getUserBean();
//		ReferenceDataBean languageBean = userBean.getLanguageBean();/
//		String language = languageBean.getCodeId();
//		list = userForm.getLanguages();
		//if (list != null)
		//{
/*			int listSize = list.size();
			if ((language == null) || ("".equals(language)))
			{
				languageBean.setCodeValue("");
				userBean.setLanguageBean(languageBean);
			}
			else
			{
				for (int i = 0; i < listSize; i++)
				{
					referenceDataBean = (ReferenceDataBean) list.get(i);
					if (language.equals(referenceDataBean.getCodeId()))
					{
						languageBean.setCodeValue(referenceDataBean.getCodeValue());
						userBean.setLanguageBean(languageBean);
						break;
					}
				}
			}*/
			String[] assignedTransactionIds =
				userBean.getAssignedTransactionIds();

			ArrayList assignedTransactions = userBean.getAssignedTransactions();

			if ((assignedTransactionIds != null)
				&& (assignedTransactionIds.length != 0))
			{
				availableTransactions = userForm.getAvailableTransactionIds();
				assignList = new ArrayList();
				int length = assignedTransactionIds.length;
				
				int size = 0;
				if (availableTransactions != null)
				{
					size = availableTransactions.size();					
				}
				int assignedSize = 0;
				if (assignedTransactions != null)
				{
					assignedSize = assignedTransactions.size();
				}
				
				for (int i = 0; i < length; i++)
				{
					for (int j = 0; j < size; j++)
					{
						referenceDataBean =
							(ReferenceDataBean) availableTransactions.get(j);
						if (assignedTransactionIds[i]
							.equals(referenceDataBean.getCodeId()))
						{
							assignList.add(referenceDataBean);
						}
					}
					for (int k = 0; k < assignedSize; k++)
					{
						assignedTransactionBean =
							(ReferenceDataBean) assignedTransactions.get(k);
						if (assignedTransactionIds[i]
							.equals(assignedTransactionBean.getCodeId()))
						{
							assignList.add(assignedTransactionBean);
						}
					}
				}
			}
			else
			{
				if (assignedTransactions != null)
				{
					assignList = new ArrayList();
					int size = assignedTransactions.size();

					if (updateFlag)
					{
						for (int i = 0; i < size; i++)
						{
							assignList.add(assignedTransactions.get(i));
						}
					}
				}
			}
			userBean.setAssignedTransactions(assignList);
			userForm.setUserBean(userBean);
		//}
		PaxTraxLog.logDebug("PaxTrax::UserAction::setInputParameters::End");
	}

	/**
	 * Removes user detail by calling delegate method. 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in removing user details
	 */
	public ActionForward removeUserDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::removeUserDetails::Begin");
		HttpSession session = request.getSession();
		UserForm userForm = (UserForm) form;
		UserBean userBean = userForm.getUserBean();
		String userId = userBean.getUserId();
		SecurityDelegate securityDelegate = new SecurityDelegate();
		securityDelegate.removeUserDetails(userBean);
		userBean = new UserBean();
		userBean.setAssignedTransactions(new ArrayList());
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
//		ArrayList languages =
//			referenceDataDelegate.loadReferenceData(PaxTraxConstants.LANUGAGES);
//		userForm.setLanguages(languages);
		userForm.setUserBean(userBean);
		userForm.setAvailableTransactionIds(
			securityDelegate.searchTransactions());
		ArrayList allRecords =
			(ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);
		if (allRecords != null)
		{
			int size = allRecords.size();
			for (int i = 0; i < size; i++)
			{
				UserBean recordBean = (UserBean) allRecords.get(i);
				if (userId.equals(recordBean.getUserId()))
				{
					allRecords.remove(recordBean);
					session.setAttribute(
						PaxTraxConstants.ALL_RECORDS,
						allRecords);
					break;
				}
			}
		}
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		if ((fromPage).equals(PaxTraxConstants.MAINTAIN_USER_PAGE))
		{
			userBean.setLanguageBean(new ReferenceDataBean());
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE);
			forward = PaxTraxConstants.CREATE_USER_PAGE;
			//forward = PaxTraxConstants.VIEW_USER_PAGE;
		}
		else
			if ((fromPage).equals(PaxTraxConstants.SEARCH_USER_PAGE))
			{
				request.setAttribute(
					PaxTraxConstants.PAGE_NUMBER,
					request.getParameter(PaxTraxConstants.PAGE_NUMBER));
				request.setAttribute(
					PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE,
					PaxTraxConstants.TRUE);
				forward = PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE;
				//forward = PaxTraxConstants.VIEW_USER_PAGE;
			}
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.TRUE);
		request.setAttribute(PaxTraxConstants.USER_ID, userId);
		ActionMessages messages = new ActionMessages();
		messages.add(
			"Delete",
			new ActionMessage("" + PaxTraxConstants.DELETE_MESSAGE));
		request.setAttribute(
			PaxTraxConstants.RESULT,
			String.valueOf(PaxTraxConstants.DELETE_MESSAGE));
		request.setAttribute(PaxTraxConstants.FROM_PAGE, PaxTraxConstants.TRUE);
		request.setAttribute(Globals.MESSAGE_KEY, messages);
		PaxTraxLog.logDebug("PaxTrax::UserAction::removeUserDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * Cancels this page and home page for admin is displayed. 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in cancel
	 */
	public ActionForward cancelPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::cancelPage::Begin");
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		if ((fromPage == null)
			|| (fromPage.equals("null"))
			|| (PaxTraxConstants.MAINTAIN_USER_PAGE.equals(fromPage))
			|| (fromPage.equals("true")))
		{
			forward = PaxTraxConstants.ADMIN_HOME_PAGE;
		}
		else
			if ((fromPage).equals(PaxTraxConstants.SEARCH_USER_PAGE))
			{
				request.setAttribute(
					PaxTraxConstants.PAGE_NUMBER,
					request.getParameter(PaxTraxConstants.PAGE_NUMBER));
				request.setAttribute(
					PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE,
					PaxTraxConstants.TRUE);
				forward = PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE;
			}
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.FALSE);
		PaxTraxLog.logDebug("PaxTrax::UserAction::cancelPage::End");
		return mapping.findForward(forward);
	}

	/**
	 * Loads user details from the search user page
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in loading user details
	 */
	public ActionForward loadUserDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::loadUserDetails::Begin");
		String availableTransactionId = null;
		ReferenceDataBean availableTransactionBean = null;
		ReferenceDataBean assignedTransactionBean = null;
		ArrayList availableTransactions = null;
		ArrayList assignedTransactions = null;
		ArrayList transactions = null;
		ArrayList userList = null;
		SecurityDelegate securityDelegate = null;
		int assignedTransactionSize = 0;
		int availableTransactionSize = 0;
		boolean isPresent = false;
		UserForm userForm = (UserForm) form;
		UserBean userBean = userForm.getUserBean();
		HttpSession session = request.getSession();
		String pageNumber =
			(String) request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		String userId = null;
		if (PaxTraxConstants
			.MAINTAIN_USER_PAGE
			.equals(request.getParameter(PaxTraxConstants.FROM_PAGE)))
		{
			securityDelegate = new SecurityDelegate();
			userList = securityDelegate.searchUserDetails(userBean);
			request.setAttribute(
				PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.MAINTAIN_USER_PAGE);
			if ((userList != null) && (userList.size() != 0))
			{
				userBean = (UserBean) userList.get(0);
				userId = userBean.getUserId();
			}
			else
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					"record",
					new ActionMessage("" + PaxTraxConstants.NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.RESULT,
					String.valueOf(PaxTraxConstants.USERID_NOT_FOUND));
				request.setAttribute(
					PaxTraxConstants.FROM_PAGE,
					PaxTraxConstants.TRUE);
			}

		}
		else
			if (PaxTraxConstants
				.SEARCH_USER_PAGE
				.equals(request.getParameter(PaxTraxConstants.FROM_PAGE)))
			{
				userId = request.getParameter(PaxTraxConstants.USER_ID);
				userList =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
				request.setAttribute(
					PaxTraxConstants.FROM_PAGE,
					PaxTraxConstants.SEARCH_USER_PAGE);
			}

		if (userList != null)
		{

			securityDelegate = new SecurityDelegate();
			availableTransactions = securityDelegate.searchTransactions();
			if (availableTransactions != null)
			{
				availableTransactionSize = availableTransactions.size();
			}
			int size = userList.size();
			for (int i = 0; i < size; i++)
			{
				userBean = (UserBean) userList.get(i);
				String id = userBean.getUserId();
				if (id.equals(userId))
				{
					transactions = new ArrayList();
					assignedTransactions =
						(ArrayList) userBean.getAssignedTransactions();
					for (int j = 0; j < availableTransactionSize; j++)
					{
						availableTransactionBean =
							(ReferenceDataBean) availableTransactions.get(j);
						availableTransactionId =
							availableTransactionBean.getCodeId();
						if (assignedTransactions != null)
						{
							assignedTransactionSize =
								assignedTransactions.size();
							for (int k = 0; k < assignedTransactionSize; k++)
							{
								assignedTransactionBean =
									(
										ReferenceDataBean) assignedTransactions
											.get(
										k);
								if (availableTransactionId
									.equals(
										assignedTransactionBean.getCodeId()))
								{
									isPresent = true;
								}
								else
								{
									isPresent = false;
								}
								if (isPresent)
								{
									break;
								}
							}
							if (!isPresent)
							{
								transactions.add(availableTransactionBean);
							}
						}
					}
					userBean.setAssignedTransactions(assignedTransactions);
//					ReferenceDataDelegate referenceDataDelegate =
//						new ReferenceDataDelegate();
//					userForm.setLanguages(
//						referenceDataDelegate.loadReferenceData(
//							PaxTraxConstants.LANUGAGES));
					userForm.setUserBean(userBean);
					userForm.setAvailableTransactionIds(transactions);

					request.setAttribute(
						PaxTraxConstants.USER_DETAILS,
						PaxTraxConstants.TRUE);
				}
			}
		}
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.FALSE);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.UPDATE);
		PaxTraxLog.logDebug("PaxTrax::UserAction::loadUserDetails::End");
		return mapping.findForward(PaxTraxConstants.CREATE_USER_PAGE);
	}

	/**
	 * updates user detail by calling delegate method. 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in unlocking user 
	 */
	public ActionForward unLockUser(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::unLockUser::Begin");
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		UserForm userForm = (UserForm) form;
		UserBean userBean = userForm.getUserBean();
		userBean.setLockStatus(PaxTraxConstants.NO);
		SecurityDelegate securityDelegate = new SecurityDelegate();
		securityDelegate.updateLockStatus(userBean);
		if ((fromPage).equals(PaxTraxConstants.MAINTAIN_USER_PAGE))
		{
			forward = PaxTraxConstants.VIEW_USER_PAGE;
			request.setAttribute(
				PaxTraxConstants.FROM_PAGE,
				PaxTraxConstants.MAINTAIN_USER_PAGE);
		}
		else
			if ((fromPage).equals(PaxTraxConstants.SEARCH_USER_PAGE))
			{
				request.setAttribute(
					PaxTraxConstants.PAGE_NUMBER,
					request.getParameter(PaxTraxConstants.PAGE_NUMBER));
				request.setAttribute(
					PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE,
					PaxTraxConstants.TRUE);
				request.setAttribute(
					PaxTraxConstants.FROM_PAGE,
					PaxTraxConstants.SEARCH_USER_PAGE);
				forward = PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE;
			}

		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.TRUE);
		ActionMessages messages = new ActionMessages();
		messages.add(
			"Unlock",
			new ActionMessage("" + PaxTraxConstants.UNLOCK_MESSAGE));
		request.setAttribute(
			PaxTraxConstants.RESULT,
			String.valueOf(PaxTraxConstants.UNLOCK_MESSAGE));
		request.setAttribute(Globals.MESSAGE_KEY, messages);
		PaxTraxLog.logDebug("PaxTrax::UserAction::unLockUser::End");
		return mapping.findForward(forward);
	}
	/**
	 * Loads reason page
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward loadReason(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::loadReason::Begin");
		String result = request.getParameter(PaxTraxConstants.RESULT);
		request.setAttribute(PaxTraxConstants.RESULT, result);
		request.setAttribute(
			PaxTraxConstants.CONFIRM_MESSAGE,
			PaxTraxConstants.FALSE);
		PaxTraxLog.logDebug("PaxTrax::UserAction::loadReason::End");
		return mapping.findForward(PaxTraxConstants.LOAD_REASON_PAGE);
	}
	/**
	 * Change user activate status
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in unlocking user 
	 */
	public ActionForward activateUser(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::activateUser::Begin");
		UserForm userForm = (UserForm) form;
		UserBean userBean = userForm.getUserBean();

		if ((PaxTraxConstants.TRUE)
			.equals(request.getParameter(PaxTraxConstants.SAVE_REASON)))
		{
			SecurityDelegate securityDelegate = new SecurityDelegate();
			String status = userBean.getActiveStatus();
			if ((PaxTraxConstants.YES).equals(status))
			{
				userBean.setActiveStatus(PaxTraxConstants.NO);
				request.setAttribute(
					PaxTraxConstants.RESULT,
					String.valueOf(PaxTraxConstants.DEACTIVATE_MESSAGE));

			}
			else
				if ((PaxTraxConstants.NO).equals(status))
				{
					userBean.setActiveStatus(PaxTraxConstants.YES);
					request.setAttribute(
						PaxTraxConstants.RESULT,
						String.valueOf(PaxTraxConstants.ACTIVATE_MESSAGE));
				}
			securityDelegate.updateActicateStatus(userBean);
			request.setAttribute(
				PaxTraxConstants.UPDATE,
				PaxTraxConstants.TRUE);
			request.setAttribute(
				PaxTraxConstants.CONFIRM_MESSAGE,
				PaxTraxConstants.FALSE);

			forward = PaxTraxConstants.LOAD_REASON_PAGE;
		}
		else
		{
			String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
			if ((fromPage).equals(PaxTraxConstants.MAINTAIN_USER_PAGE))
			{
				updateFlag = true;
				setInputParameters(userForm);
				request.setAttribute(
					PaxTraxConstants.FROM_PAGE,
					PaxTraxConstants.MAINTAIN_USER_PAGE);
				forward = PaxTraxConstants.VIEW_USER_PAGE;
			}
			else
				if ((fromPage).equals(PaxTraxConstants.SEARCH_USER_PAGE))
				{
					request.setAttribute(
						PaxTraxConstants.PAGE_NUMBER,
						request.getParameter(PaxTraxConstants.PAGE_NUMBER));
					request.setAttribute(
						PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE,
						PaxTraxConstants.TRUE);
					forward = PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE;
				}
			String status = userBean.getActiveStatus();
			ActionMessages messages = new ActionMessages();
			if ((PaxTraxConstants.YES).equals(status))
			{
				messages.add(
					"Activate",
					new ActionMessage("" + PaxTraxConstants.ACTIVATE_MESSAGE));
				request.setAttribute(
					PaxTraxConstants.RESULT,
					String.valueOf(PaxTraxConstants.ACTIVATE_MESSAGE));
			}
			else
			{
				messages.add(
					"Deactivate",
					new ActionMessage(
						"" + PaxTraxConstants.DEACTIVATE_MESSAGE));
				request.setAttribute(
					PaxTraxConstants.RESULT,
					String.valueOf(PaxTraxConstants.DEACTIVATE_MESSAGE));
			}
			request.setAttribute(
				PaxTraxConstants.CONFIRM_MESSAGE,
				PaxTraxConstants.TRUE);
			request.setAttribute(Globals.MESSAGE_KEY, messages);

		}
		PaxTraxLog.logDebug("PaxTrax::UserAction::activateUser::End");
		return mapping.findForward(forward);
	}

	/**
	 * upadates user Password
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in updating the password 
	 */
	public ActionForward changePassword(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::changePassword::Begin");
		UserForm userForm = (UserForm) form;
		UserBean userBean = userForm.getUserBean();
		String oldPassword =
			request.getParameter(PaxTraxConstants.OLD_PASSWORD);
		oldPassword = oldPassword.trim();

		HttpSession session = request.getSession();
		String currentPassword =
			(String) session.getAttribute(PaxTraxConstants.PASSWORD);
		currentPassword = currentPassword.trim();

		userBean.setUserId(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		String newPassword = userBean.getPassword();

		if (currentPassword.equals(oldPassword))
		{

			SecurityDelegate securityDelegate = new SecurityDelegate();
			securityDelegate.changePassword(userBean);
			session.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE);

			session.setAttribute(PaxTraxConstants.PASSWORD, newPassword);

		}
		else
		{
			session.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.INCORRECT_PASSWORD);
		}
		userBean.setPassword("");
		userForm.setUserBean(userBean);
		PaxTraxLog.logDebug("PaxTrax::UserAction::changePassword::End");
		return mapping.findForward(PaxTraxConstants.CHANGE_PASSWORD_PAGE);
	}
	/**
	 * Creates create Change Password
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward createChangePasswordPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::UserAction::createChangePasswordPage::Begin");
		UserForm userForm = (UserForm) form;
		UserBean userBean = new UserBean();
		userForm.setUserBean(userBean);

		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.CREATE);
		if (session.getAttribute(PaxTraxConstants.MODULE_NAME) != null)
			session.removeAttribute(PaxTraxConstants.MODULE_NAME);
		PaxTraxLog.logDebug(
			"PaxTrax::UserAction::createChangePasswordPage::End");
		return mapping.findForward(PaxTraxConstants.CHANGE_PASSWORD_PAGE);
	}
	
	public ActionForward startPurge(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::UserAction::startPurge::Begin");
		PurgeDelegate purgeDelegate = new PurgeDelegate();
		purgeDelegate.purgeData();
		PaxTraxLog.logDebug(
			"PaxTrax::UserAction::startPurge::End");
		return mapping.findForward(null);
	}

	/**
	 * Used for language toggle
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::UserAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		String forward = null;
		String userId = request.getParameter(PaxTraxConstants.USER_ID);
		super.changeLanguage(request, language, country);
		String operation =
			(String) request.getParameter(PaxTraxConstants.OPERATION);
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);			
		String page = request.getParameter(PaxTraxConstants.PAGE);
		String presentValue = request.getParameter(PaxTraxConstants.PRESENT);
       
		request.setAttribute(PaxTraxConstants.PRESENT, presentValue);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}
		else
		{
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.CREATE);			
			
		}
		if ((page.equals(PaxTraxConstants.CREATE_USER_PAGE))
			|| (page.equals(PaxTraxConstants.MAINTAIN_USER_PAGE)))
		{			
			forward = PaxTraxConstants.CREATE_USER_PAGE;
			
		}
		else if ((PaxTraxConstants.CHANGE_PASSWORD_PAGE).equals(page))
		{
			forward = PaxTraxConstants.CHANGE_PASSWORD_PAGE;
		}
		else
		{

				if (PaxTraxConstants.CREATE_USER_PAGE.equals(fromPage))
				{
					ActionMessages messages = new ActionMessages();
					messages.add(
						"Update",
						new ActionMessage("" + PaxTraxConstants.SAVE_MESSAGE));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
					request.setAttribute(
						PaxTraxConstants.RESULT,
						String.valueOf(PaxTraxConstants.SAVE_MESSAGE));
					forward = PaxTraxConstants.VIEW_USER_PAGE;
				}				
				else
				{
					ActionMessages messages = new ActionMessages();
					messages.add(
						"Update",
						new ActionMessage(
							"" + PaxTraxConstants.UPDATE_MESSAGE));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
					request.setAttribute(
						PaxTraxConstants.RESULT,
						String.valueOf(PaxTraxConstants.UPDATE_MESSAGE));
					forward = PaxTraxConstants.VIEW_USER_PAGE;
				}				
		}

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);
		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.SKU_ERROR,
				new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE ,errorCode);
		}
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);
		String userDetails =
			request.getParameter(PaxTraxConstants.USER_DETAILS);
		if (PaxTraxConstants.TRUE.equals(userDetails))
		{
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE);
			request.setAttribute(
				PaxTraxConstants.USER_DETAILS,
				PaxTraxConstants.TRUE);
		}		
		String pageNumber = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);
		request.setAttribute(PaxTraxConstants.USER_ID, userId);
		PaxTraxLog.logDebug("PaxTrax::UserAction::changeLanguage::End");
		return mapping.findForward(forward);
	}
}
