package com.dfs.paxtrax.admin.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.SearchUserForm;
import com.dfs.paxtrax.admin.service.SecurityDelegate;
import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
 * This action class handles the user search by calling delegate
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */


public class SearchUserAction extends PaxTraxAction
{

	//Forward page
	private String forward = null;	


	/**
	 * Searches user details for the given search criteria by calling 
	 * delegate method. 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in searching user details
	 */
	public ActionForward searchUserDetails(ActionMapping mapping,
		ActionForm form, HttpServletRequest request, 
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SearchUserAction::searchUserDetails::Begin");
		int pageNumber = 0;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		String pageNumberStr = null;
		SearchUserForm searchUserForm = (SearchUserForm) form;
		UserBean searchUserBean = searchUserForm.getSearchUserBean();
		HttpSession session = request.getSession();
		String backToSearchUserPage = (String)request.getAttribute(
			PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE);
		String result = (String) request.getAttribute(PaxTraxConstants.RESULT);
		String userId = (String) request.getAttribute(PaxTraxConstants.USER_ID);
		request.setAttribute(PaxTraxConstants.FAILURE,result);	
		request.setAttribute(PaxTraxConstants.USER_ID,userId);
		if ((PaxTraxConstants.TRUE).equals(backToSearchUserPage))
		{				
			pageNumberStr = (String) request.getAttribute(
				PaxTraxConstants.PAGE_NUMBER);								
		}
		else
		{
			pageNumberStr = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		}
	
		 /* If page number is null or empty it sets null otherwise 
		  * it is same
		  */
		pageNumberStr = ((pageNumberStr == null) 
			|| pageNumberStr.equals(SQLConstants.BLANK)) ? null : pageNumberStr;
		
		if ((pageNumberStr != null)) {
			pageNumber = Integer.parseInt(pageNumberStr);
		}
			
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */
		if ((pageNumber == 0)) {
			int size = 0;
			pageNumber = 1;
			SecurityDelegate securityDelegate = new SecurityDelegate();
			allRecords = securityDelegate.searchUserDetails(searchUserBean);	
			if (allRecords != null) 
			{
				size = allRecords.size();
			}
			session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
			session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
			session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, 
				Integer.toString(size));
		}
		else 
		{

			allRecords = (ArrayList)
				session.getAttribute(PaxTraxConstants.ALL_RECORDS);
		}	
		PaginationHelper helper = PaginationHelper.getInstance();
	
		if ((allRecords != null) && (allRecords.size() !=0)) {
	
		    // Get records to be displayed for the passed page number
		    currentRecords = helper.getCurrentTableContent(allRecords, 
		    	pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);		    	
		}
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, 
			Integer.toString(pageNumber));
		
		//Sets records to be displayed for the page number 
		searchUserForm.setUserCollection(currentRecords);		
				
		if (!((PaxTraxConstants.TRUE).equals(backToSearchUserPage)))
		{	
			if((currentRecords == null) || (currentRecords.size() == 0))
			{
				ActionMessages messages = new ActionMessages();
	    		messages.add("record", new ActionMessage("" 
	    			+ PaxTraxConstants.NO_RECORDS_FOUND));
		    	request.setAttribute(Globals.MESSAGE_KEY,messages);
		    	request.setAttribute(PaxTraxConstants.FAILURE,
		    	String.valueOf(PaxTraxConstants.NO_RECORDS_FOUND));
				request.setAttribute(PaxTraxConstants.RESULT, 
					PaxTraxConstants.UPDATE_FAILURE);
			}
			else
			{				
				request.setAttribute(PaxTraxConstants.RESULT, 
					PaxTraxConstants.SUCCESS);
			}
		}	
		else
		{
			request.setAttribute(PaxTraxConstants.RESULT, 
					PaxTraxConstants.SUCCESS);	
		}
		request.setAttribute(PaxTraxConstants.CONFIRM_MESSAGE, 
				PaxTraxConstants.FALSE);
		
		PaxTraxLog.logDebug("PaxTrax::SearchUserAction::searchUserDetails::End");			
		return mapping.findForward(PaxTraxConstants.SEARCH_USER_PAGE);
	}
	
	/**
	 * Displays search user page
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward searchUserPage(ActionMapping mapping,
		ActionForm form, HttpServletRequest request,	
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchUserAction::searchUserPage::Begin");
		SearchUserForm searchUserForm = (SearchUserForm) form;
		searchUserForm.setUserCollection(null);
		HttpSession session = request.getSession();
		if(session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS)!=null)
		{
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);			
		}
		UserBean userBean = new UserBean();
		searchUserForm.setSearchUserBean(userBean);
		request.setAttribute(PaxTraxConstants.CONFIRM_MESSAGE, 
				PaxTraxConstants.FALSE);	
		PaxTraxLog.logDebug("PaxTrax::SearchUserAction::searchUserPage::End");		
		return mapping.findForward(PaxTraxConstants.SEARCH_USER_PAGE);
	}
	
	/**
	 * Used for language toggle
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchUserAction::changeLanguage::Begin");
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		
		super.changeLanguage(request, language, country);
		SearchUserForm searchUserForm = (SearchUserForm) form;
		ArrayList currentRecords = searchUserForm.getUserCollection();
		String result = request.getParameter(PaxTraxConstants.FAILURE);		
		String userId = request.getParameter(PaxTraxConstants.USER_ID);
		if((currentRecords == null) || (currentRecords.size() == 0))
		{
			HttpSession session = request.getSession();
			String sizeOfAllRecords 
				= (String) session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
			if (sizeOfAllRecords != null)
			{	
				ActionMessages messages = new ActionMessages();
	    		messages.add("record", new ActionMessage("" 
	    			+ PaxTraxConstants.NO_RECORDS_FOUND));
		    	request.setAttribute(Globals.MESSAGE_KEY,messages);
		    	request.setAttribute(PaxTraxConstants.FAILURE,
		    	String.valueOf(PaxTraxConstants.NO_RECORDS_FOUND));
			}
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.UPDATE_FAILURE);
			
		}
		else
		{
			
			String pageNumber 
				=  request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);	
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.SUCCESS);
			request.setAttribute(PaxTraxConstants.FAILURE,result);	
			request.setAttribute(PaxTraxConstants.USER_ID,userId);	
		}
		PaxTraxLog.logDebug("PaxTrax::SearchUserAction::changeLanguage::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_USER_PAGE);
	}

}
