package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.admin.exception.SecurityException;
import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;


/**
 * Remote interface for Enterprise Bean: UserBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 7/04/2004	Vaikundamurthy	Created   
 */	


public interface UserBO extends EJBObject
{
	/**
	 * Saves user details by invoking BO method.
	 * @param userBean UserBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving user details
	 */
	public void saveUserDetails(UserBean userBean) 
		throws RemoteException, SecurityException, PaxTraxSystemException;
	
	/**
	 * Updates user details by invoking BO method.
	 * @param userBean UserBean 
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating user details
	 */
	public void updateUserDetails(UserBean userBean)
		throws RemoteException, PaxTraxSystemException;
	
	
	/**
	 * Updates activate status by invoking BO method.
	 * @param userBean UserBean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating activate status
	 */
	public void updateActivateStatus(UserBean userBean)
		throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Updates lock status by invoking BO method.
	 * @param userBean UserBean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating lock status
	 */
	public void updateLockStatus(UserBean userBean)
		throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Removes user details by invoking BO method.
	 * @param userBean UserBean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in removing user details
	 */
	public void removeUserDetails(UserBean userBean)
		throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Retunrn user list for the given search criteria by invoking BO method.
	 * @param userBean UserBean
	 * @return ArrayList List of user details
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in search
	 */
	public ArrayList searchUserDetails(UserBean userBean)
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Returns list of transactions
	 * @return ArrayList List of transactions
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in searching transactions
	 */
	public ArrayList searchTransactions() 
		throws RemoteException, PaxTraxSystemException;
     
      
    /**
     * Changes the Password in the database
     * @param userBean UserBean
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in updating the User Table
     */   
    public void changePassword(UserBean userBean) 
        throws RemoteException, PaxTraxSystemException;
	
}
