package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is the actionform that holds user search attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */


public class SearchUserForm extends PaxTraxActionForm
{
	//employee id
	private String employeeId = null;

	//First name
	private String firstName = null;

	//Last name
	private String lastName = null;

	//Holds userBean
	private UserBean searchUserBean = null;
	
	//List of user bean
	private ArrayList userCollection = null;

	public SearchUserForm()
	{
	}
	
	/**
	 * Returns the employeeId.
	 * @return String Employee id
	 */
	public String getEmployeeId()
	{
		return employeeId;
	}

	/**
	 * Sets the employeeId.
	 * @param employeeId The employeeId to set
	 */
	public void setEmployeeId(String employeeId)
	{
		this.employeeId = employeeId;
	}
	
	/**
	 * Returns the firstName.
	 * @return String First name
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Sets the firstName.
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Returns the lastName.
	 * @return String Last name
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Sets the lastName.
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	
	/**
	 * Returns the userCollection.
	 * @return ArrayList List of user details
	 */
	public ArrayList getUserCollection()
	{
		return userCollection;
	}

	/**
	 * Sets the userCollection.
	 * @param userCollection The userCollection to set
	 */
	public void setUserCollection(ArrayList userCollection)
	{
		this.userCollection = userCollection;
	}
	
	/**
	 * Returns the searchUserBean.
	 * @return UserBean
	 */
	public UserBean getSearchUserBean()
	{
		return searchUserBean;
	}

	/**
	 * Sets the searchUserBean.
	 * @param searchUserBean The searchUserBean to set
	 */
	public void setSearchUserBean(UserBean searchUserBean)
	{
		this.searchUserBean = searchUserBean;
	}

}
