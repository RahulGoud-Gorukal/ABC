package com.dfs.paxtrax.admin.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 116038
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class RacPreAssignmentBean extends PaxTraxValueObject{
	 private String racCode = null;
	 private String startPaxNumber = null;
	 private String endPaxNumber = null;
	 private String remarks = null;

	/**
	 * Returns the endPaxNumber.
	 * @return String
	 */
	public String getEndPaxNumber() {
		return endPaxNumber;
	}

	/**
	 * Returns the racCode.
	 * @return String
	 */
	public String getRacCode() {
		return racCode;
	}

	/**
	 * Returns the startPaxNumber.
	 * @return String
	 */
	public String getStartPaxNumber() {
		return startPaxNumber;
	}

	/** Added for CR1859
	* Returns the remarks.
	* @return String
	*/
	public String getRemarks() {
			return remarks;
	}
	
	/**
	 * Sets the endPaxNumber.
	 * @param endPaxNumber The endPaxNumber to set
	 */
	public void setEndPaxNumber(String endPaxNumber) {
		this.endPaxNumber = endPaxNumber;
	}

	/**
	 * Sets the racCode.
	 * @param racCode The racCode to set
	 */
	public void setRacCode(String racCode) {
		this.racCode = racCode;
	}

	/**
	 * Sets the startPaxNumber.
	 * @param startPaxNumber The startPaxNumber to set
	 */
	public void setStartPaxNumber(String startPaxNumber) {
		this.startPaxNumber = startPaxNumber;
	}
	
	/**Added for CR1859
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
