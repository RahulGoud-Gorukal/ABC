package com.dfs.paxtrax.admin.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.SearchOverrideFlightForm;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.service.FlightDelegate;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.admin.valueobject.OverrideFlightBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 02/04/2004	Sundarrajan.K.	Created   
 */

/**
   This is struts action class which performs override flight operations
 */
public class SearchOverrideFlightAction extends PaxTraxAction
{

	/**
	   Forwards to Override flight page
	   @roseuid 4045134E0128
	 */
	public ActionForward searchOverrideFlightPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchOverrideFlightAction::searchOverrideFlightPage::Begin");
		HttpSession session = request.getSession();
		ReferenceDataBean referenceDataBean = null;
		SearchOverrideFlightForm searchOverrideFlightForm =
			(SearchOverrideFlightForm) form;
		searchOverrideFlightForm.setOverrideFlightCollection(null);
		if(session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS)!=null)
		{
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS);
			session.removeAttribute(PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
			session.removeAttribute(PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER);
		}
		ArrayList flightDetails = new ArrayList();

		FlightBean flightBean = new FlightBean();
		OverrideFlightBean overrideFlightBean = new OverrideFlightBean();
		flightBean.setAirlineBean(new ReferenceDataBean());
		flightBean.setOriginAirportBean(new ReferenceDataBean());
		flightBean.setDestinationAirportBean(new ReferenceDataBean());
		flightBean.setPickupLocationBean(new ReferenceDataBean());

		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		searchOverrideFlightForm.setAirlineCodes(
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.AIRLINE_CODE));

		//searchOverrideFlightForm.setAirlineCodes(loadReferenceData("airlinecode"));			
		searchOverrideFlightForm.setFlightBean(flightBean);
		if (session.getAttribute("flightDetails") != null)
			session.removeAttribute("flightDetails");
		PaxTraxLog.logDebug(
			"PaxTrax::SearchOverrideFlightAction::searchOverrideFlightPage::End");
		return mapping.findForward(
			PaxTraxConstants.SEARCH_OVERRIDE_FLIGHT_PAGE);
	}

	/**
	   Searches override flight by calling delegate method. It throws PaxTraxException if there is any problem in search
	   @roseuid 404513CC02EE
	 */
	public ActionForward searchOverrideFlightDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchOverrideFlightAction::searchOverrideFlightDetails::Begin");
		int pageNumber = 0;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		SearchOverrideFlightForm searchOverrideFlightForm =
			(SearchOverrideFlightForm) form;
		FlightBean flightBean = searchOverrideFlightForm.getFlightBean();

		ReferenceDataBean airlineReferenceBean = null;
		ReferenceDataBean originAirportReferenceBean = null;
		ReferenceDataBean destinationAirportReferenceBean = null;
		ReferenceDataBean pickupLocationReferenceBean = null;

		airlineReferenceBean = flightBean.getAirlineBean();
		airlineReferenceBean.setReferenceId(PaxTraxConstants.AIRLINE_CODE);
		flightBean.setAirlineBean(airlineReferenceBean);

		originAirportReferenceBean = flightBean.getOriginAirportBean();
		originAirportReferenceBean.setReferenceId(PaxTraxConstants.AIRPORT);
		flightBean.setOriginAirportBean(originAirportReferenceBean);

		destinationAirportReferenceBean =
			flightBean.getDestinationAirportBean();
		destinationAirportReferenceBean.setReferenceId(
			PaxTraxConstants.AIRPORT);
		flightBean.setDestinationAirportBean(destinationAirportReferenceBean);

		pickupLocationReferenceBean = flightBean.getPickupLocationBean();
		pickupLocationReferenceBean.setReferenceId(
			PaxTraxConstants.PICK_UP_LOCATION);
		flightBean.setPickupLocationBean(pickupLocationReferenceBean);

		HttpSession session = request.getSession();
		String pageNumberStr =
			request.getParameter(PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER);

		/* If page number is null or empty it sets null otherwise 
		 * it is same
		 */
		pageNumberStr =
			((pageNumberStr == null)
				|| pageNumberStr.equals(SQLConstants.BLANK))
				? null
				: pageNumberStr;

		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}

		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */
		if ((pageNumber == 0))
		{
			int size = 0;
			pageNumber = 1;
			FlightDelegate flightDelegate = new FlightDelegate();
			try
			{
				allRecords =
					flightDelegate.selectOverrideFlightDetails(flightBean);
			}
			catch (FlightException fe)
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					"flightNumber",
					new ActionMessage("" + fe.getErrorCode()));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
			}
			//allRecords = getFlightDetails();	
			if (allRecords != null)
			{
				size = allRecords.size();
			}
			session.removeAttribute(
				PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS,
				allRecords);
			session.removeAttribute(
				PaxTraxConstants.SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS);
			session.setAttribute(
				PaxTraxConstants.SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS,
				Integer.toString(size));
		}
		else
		{
			allRecords =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_FLIGHT_OVERRIDE_RECORDS);
		}
		PaginationHelper helper = PaginationHelper.getInstance();

		if ((allRecords != null) && (allRecords.size() != 0))
		{
			// Get records to be displayed for the passed page number
			currentRecords =
				helper.getCurrentTableContent(
					allRecords,
					pageNumber,
					PaxTraxConstants.RECORDS_PER_PAGE);
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);					
			request.setAttribute(
			PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER,
			Integer.toString(pageNumber));
		}		

		//Sets records to be displayed for the page number 
		searchOverrideFlightForm.setOverrideFlightCollection(currentRecords);
		//session.setAttribute("flightCollection",currentRecords);	

		
		PaxTraxLog.logDebug(
			"PaxTrax::SearchOverrideFlightAction::searchOverrideFlightDetails::End");
		return mapping.findForward(
			PaxTraxConstants.SEARCH_OVERRIDE_FLIGHT_PAGE);
	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchOverrideFlightAction::changeLanguage::Begin");
		SearchOverrideFlightForm searchOverrideFlightForm =
			(SearchOverrideFlightForm) form;
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page.equals(PaxTraxConstants.SEARCH_OVERRIDE_FLIGHT_PAGE))
		{
			forward = PaxTraxConstants.SEARCH_OVERRIDE_FLIGHT_PAGE;
		}		
		PaxTraxLog.logDebug(
			"PaxTrax::SearchOverrideFlightAction::changeLanguage::End");
		ArrayList currentRecords = searchOverrideFlightForm.getOverrideFlightCollection();			
		if(currentRecords == null ||  (currentRecords.size() == 0))
		{
			HttpSession session = request.getSession();
			String sizeOfFlight = (String)
			session.getAttribute(PaxTraxConstants.SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS) ;
			if(sizeOfFlight != null)
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					"flightNumber",
					new ActionMessage("" + PaxTraxConstants.NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);		    	
			}
			String pageNumber = request.getParameter(PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER,pageNumber);			
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.UPDATE_FAILURE);
			
		}
		else
		{
			String pageNumber = request.getParameter(PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.FLIGHT_OVERRIDE_PAGE_NUMBER,pageNumber);			
			request.setAttribute(PaxTraxConstants.RESULT, 
				PaxTraxConstants.SUCCESS);
		}				
		return mapping.findForward(forward);
	}

}