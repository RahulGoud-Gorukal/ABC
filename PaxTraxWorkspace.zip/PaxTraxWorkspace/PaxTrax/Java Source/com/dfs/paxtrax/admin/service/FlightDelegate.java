package com.dfs.paxtrax.admin.service;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.business.FlightBO;
import com.dfs.paxtrax.admin.business.FlightBOHome;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;

/**
 * Bean implementation class for Enterprise Bean: UserBOManager
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Sundarrajan.K.	Created  
 * 07/28/2007	Uma D			Added a method for CR 250 changes   
 */

public class FlightDelegate
{

	/**
	* Default Construtor for LocationDelegate
	*/
	public FlightDelegate()
	{
	}

	//Holds service locator instance

	private ServiceLocator serviceLocator = null;

	private FlightBOHome flightBOHome = null;
	private FlightBO flightBO = null;

	private void jndiCall() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			flightBOHome =
				(FlightBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						PaxTraxConstants.FLIGHT_BO_BEAN_JNDI),
					FlightBOHome.class);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}
		if (flightBOHome == null)
		{
			//throw new PaxTraxSystemException(PaxTraxConstants.FLIGHT_BO_HOME_NOT_FOUND);
		}
		try
		{
			flightBO = flightBOHome.create();
		}
		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::jndiCall::End");
	}

	/**
	 * Saves flight details by invoking BO method.
	 * @param flightBean FlightBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving flight details
	 */
	public void saveFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::saveFlightDetails::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBO.saveFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::saveFlightDetails::End");
	}

	/**
	 * Updates the flight details after modification. 
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in updating flight details
	 */
	public void updateFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::updateFlightDetails::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBO.updateFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::updateFlightDetails::End");

	}

	/**
	 * Deletes the flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in deleting flight details
	 */
	public void deleteFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::deleteFlightDetails::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBO.deleteFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::deleteFlightDetails::End");

	}

	/**
	 * Insert override flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting override flight details
	 */
	public void insertOverrideFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::insertOverrideFlightDetails::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBO.insertOverrideFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::insertOverrideFlightDetails::End");
	}

	/**
	 * Removes the override flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in removing override flight details
	 */
	public void removeFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::removeFlightDetails::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBO.removeOverrideFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::removeFlightDetails::End");
	}

	/**
	 * Searches Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::selectFlightDetails::Begin");
		ArrayList flightList = null;
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightList = flightBO.selectFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::selectFlightDetails::End");
		return flightList;
	}

	/**
	 * Searches Flight Override details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectOverrideFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::selectOverrideFlightDetails::Begin");
		ArrayList flightList = null;
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightList = flightBO.selectOverrideFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::selectOverrideFlightDetails::End");
		return flightList;
	}

	/**
	 * Searches Flight details based on the tab pressed in the maintain page and returns the 
	 * result. 
	 * @param flightBean
	 * @return FlightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public FlightBean selectMaintainFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::selectMaintainFlightDetails::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBean = flightBO.selectMaintainFlightDetails(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::selectMaintainFlightDetails::End");
		return flightBean;
	}

	/**
	 * Searches Flight details based on the tab pressed in the maintain page and returns the 
	 * result. 
	 * @param flightBean
	 * @return FlightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList massFlightChange(FlightDetailsBean flightDetailsBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::massFlightChange::Begin");
		ArrayList resultList = null;
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			resultList = flightBO.massFlightChange(flightDetailsBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::massFlightChange::End");
		return resultList;
	}

	public ArrayList saveFlightDetails(ArrayList paxList)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::saveFlightDetails::Begin");
		ArrayList resultList = null;
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			resultList = flightBO.saveFlightDetails(paxList);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::saveFlightDetails::End");
		return resultList;
	}
//	Made changes for CR 250 changes on July 28, 2007 --  Begin
	/**
	 * Searches whether naccs is generated for the flight or not
	 * @param flightBean
	 * @return FlightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */	
	public void checkNaccsStatus(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightDelegate::checkNaccsStatus::Begin");
		if (flightBOHome == null)
		{
			jndiCall();
		}

		try
		{
			flightBO.checkNaccsStatus(flightBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDelegate::checkNaccsStatus::End");
	}
//	Made changes for CR 250 changes on July 28, 2007 --  End
}
