package com.dfs.paxtrax.admin.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.FlightForm;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.service.FlightDelegate;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This action class handles the user search by calling delegate
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/04/2004	Sundarrajan.K.	Created
 */

/**
   This is struts action class which performs insert, delete and update flight details by calling delegate class
 */
public class FlightAction extends PaxTraxAction
{

	/**
	  Saves flight details by calling delegate method. It throws PaxTraxException if there is any problem in save
	*/
	public ActionForward saveFlight(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::saveFlight::Begin");
		HttpSession session = request.getSession();
		FlightForm flightForm = (FlightForm) form;
		FlightBean flightBean = flightForm.getFlightBean();
		flightBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		String forward = null;
		ReferenceDataBean referenceDataBean = null;
		ReferenceDataBean airlineReferenceBean = null;
		ReferenceDataBean originAirportReferenceBean = null;
		ReferenceDataBean destinationAirportReferenceBean = null;
		ReferenceDataBean pickupLocationReferenceBean = null;
		ArrayList airlineCodes = flightForm.getAirlineCodes();
		ArrayList airports = flightForm.getAirports();
		ArrayList pickupLocations = flightForm.getPickupLocations();
		boolean isDeparture = flightBean.getIsDeparture();
		String flightDate = flightBean.getFlightDate();
		String fdate = null;
		
		//added for CA#290863 by vignesh starts here
		boolean vesselMode = flightBean.isVesselMode();
		if(vesselMode)
		{
			request.setAttribute(PaxTraxConstants.VESSEL_MODE_CHECKED,"true");
		}
		//added for CA#290863 by vignesh ends here
		if (airlineCodes != null && !airlineCodes.isEmpty())
		{
			airlineReferenceBean = flightBean.getAirlineBean();
			for (int i = 0; i < airlineCodes.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airlineCodes.get(i);
				if (airlineReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					airlineReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					airlineReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					airlineReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setAirlineBean(airlineReferenceBean);
					break;
				}
			}
		}

		if (airports != null && !airports.isEmpty())
		{
			originAirportReferenceBean = flightBean.getOriginAirportBean();
			for (int i = 0; i < airports.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airports.get(i);
				if (originAirportReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					originAirportReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					originAirportReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					originAirportReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setOriginAirportBean(originAirportReferenceBean);
					break;
				}
			}
		}

		if (airports != null && !airports.isEmpty())
		{
			destinationAirportReferenceBean =
				flightBean.getDestinationAirportBean();
			for (int i = 0; i < airports.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airports.get(i);
				if (destinationAirportReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					destinationAirportReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					destinationAirportReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					destinationAirportReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setDestinationAirportBean(
						destinationAirportReferenceBean);
					break;
				}
			}
		}

		if (pickupLocations != null && !pickupLocations.isEmpty())
		{
			pickupLocationReferenceBean = flightBean.getPickupLocationBean();
			for (int i = 0; i < pickupLocations.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) pickupLocations.get(i);
				if (pickupLocationReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					pickupLocationReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					pickupLocationReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					pickupLocationReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setPickupLocationBean(
						pickupLocationReferenceBean);
					break;
				}
			}
		}
		if (PaxTraxConstants
			.TRUE
			.equals(request.getParameter("dailyCheckBox")))
			flightBean.setIsDailyCheckBox(true);
		else
			flightBean.setIsDailyCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("sunCheckBox")))
			flightBean.setIsSunCheckBox(true);
		else
			flightBean.setIsSunCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("monCheckBox")))
			flightBean.setIsMonCheckBox(true);
		else
			flightBean.setIsMonCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("tueCheckBox")))
			flightBean.setIsTueCheckBox(true);
		else
			flightBean.setIsTueCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("wedCheckBox")))
			flightBean.setIsWedCheckBox(true);
		else
			flightBean.setIsWedCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("thuCheckBox")))
			flightBean.setIsThuCheckBox(true);
		else
			flightBean.setIsThuCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("friCheckBox")))
			flightBean.setIsFriCheckBox(true);
		else
			flightBean.setIsFriCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("satCheckBox")))
			flightBean.setIsSatCheckBox(true);
		else
			flightBean.setIsSatCheckBox(false);
		FlightDelegate flightDelegate = new FlightDelegate();
		flightBean.setIsDeparture(isDeparture);
		try
		{
			flightBean.setFlightType(flightBean.getFlightType());
			//added for CA#290863 by vignesh starts here
			if(flightBean.getVesselName()!=null)
			{
				flightBean.setVesselName(flightBean.getVesselName().trim());
			}
			else
			{
				flightBean.setVesselName(flightBean.getVesselName());
			}
			//added for CA#290863 by vignesh ends here
			flightForm.setFlightBean(flightBean);
			flightDelegate.saveFlightDetails(flightBean);
			forward = PaxTraxConstants.SAVE_FLIGHT;
		}
		catch (FlightException fe)
		{
			/*Modified on 28th June 2006 - Starts
			 *SR 1042 International DF Sale */
			if (fe.getErrorCode() == PaxTraxConstants.FLIGHT_ALREADY_EXISTS)
			{

				request.setAttribute(
					PaxTraxConstants.FLIGHT,
					String.valueOf(PaxTraxConstants.FLIGHT_ALREADY_EXISTS));
				flightBean.setFlightType(flightBean.getFlightType());
				flightForm.setFlightBean(flightBean);
				PaxTraxLog.logError(fe.getMessage());
			}
			else
			{
				request.setAttribute(
					PaxTraxConstants.FLIGHT,
					String.valueOf(PaxTraxConstants.FLIGHT_PICKUP_MISMATCH));
				flightBean.setFlightType(flightBean.getFlightType());
				flightForm.setFlightBean(flightBean);
				PaxTraxLog.logError(fe.getMessage());
			}
			/*Modified on 28th June 2006 - Ends
			 *SR 1042 International DF Sale */
			request.setAttribute(
				PaxTraxConstants.PRESENT,
				String.valueOf(PaxTraxConstants.FLIGHT_ALREADY_EXISTS));
			forward = PaxTraxConstants.FLIGHT_CREATE;
		}
		flightBean = reAssignCodeValue(flightForm, flightBean);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.CREATE);
		request.setAttribute(
			PaxTraxConstants.FLIGHT_TYPE,
			flightBean.getFlightType());
		PaxTraxLog.logDebug("PaxTrax::FlightAction::saveFlight::End");
		return mapping.findForward(forward);
	}

	/**
	   Forwards to Create Flight page
	 */
	public ActionForward createFlightPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::createFlightPage::Begin");
		//PaxTraxConstants cons = new PaxTraxConstants();
		HttpSession moduleSession = request.getSession();
		moduleSession.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.ADMIN);
		FlightForm flightForm = (FlightForm) form;
		flightForm = setComboAttributes(flightForm);
		FlightBean flightBean = new FlightBean();
		flightBean.setAirlineBean(new ReferenceDataBean());
		flightBean.setOriginAirportBean(new ReferenceDataBean());
		flightBean.setDestinationAirportBean(new ReferenceDataBean());
		flightBean.setPickupLocationBean(new ReferenceDataBean());
		flightBean.setIsDeparture(true);
		flightBean.setFlightType("1");
		flightForm.setFlightBean(flightBean);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.CREATE);
		request.setAttribute(
			PaxTraxConstants.FLIGHT_TYPE,
			flightBean.getFlightType());
		PaxTraxLog.logDebug("PaxTrax::FlightAction::createFlightPage::End");
		return mapping.findForward(PaxTraxConstants.FLIGHT_CREATE);
	}

	/**
	   Forwards to Maintains Flight page
	*/
	public ActionForward maintainFlightPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::maintainFlightPage::Begin");
		HttpSession moduleSession = request.getSession();
		moduleSession.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.ADMIN);
		HttpSession session = request.getSession();
		FlightForm flightForm = (FlightForm) form;
		flightForm = setComboAttributes(flightForm);
		FlightBean flightBean = new FlightBean();
		flightBean.setAirlineBean(new ReferenceDataBean());
		flightBean.setOriginAirportBean(new ReferenceDataBean());
		flightBean.setDestinationAirportBean(new ReferenceDataBean());
		flightBean.setPickupLocationBean(new ReferenceDataBean());
		flightBean.setIsDeparture(true);
		flightBean.setFlightType("1");
		flightForm.setFlightBean(flightBean);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.FAILURE);
		request.setAttribute(
			PaxTraxConstants.FLIGHT_TYPE,
			flightBean.getFlightType());
		PaxTraxLog.logDebug("PaxTrax::FlightAction::maintainFlightPage::End");
		return mapping.findForward(PaxTraxConstants.FLIGHT_CREATE);
	}

	/**
	   Loads flight details from search flight page
	 */
	public ActionForward loadFlightDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::loadFlightDetails::Begin");
		HttpSession session = request.getSession();
		
		ArrayList flightDetails =
			(ArrayList) session.getAttribute(
				PaxTraxConstants.ALL_FLIGHT_RECORDS);
		ArrayList checkList = null;
		ReferenceDataBean referenceDataBean = null;
		ReferenceDataBean airlineReferenceBean = null;
		ReferenceDataBean originAirportBean = null;
		ReferenceDataBean destinationAirportBean = null;
		FlightDelegate flightDelegate = null;
		FlightForm flightForm = (FlightForm) form;
		FlightBean flightBean = null;
		String flightNumber = null;
		String flightDate = null;
		String forward = null;
		boolean isDeparture = false;
		String index = null;
		String operation =
			(String) request.getParameter(PaxTraxConstants.OPERATION);
		String pageNumber =
			request.getParameter(PaxTraxConstants.FLIGHT_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.FLIGHT_PAGE_NUMBER, pageNumber);
		if (request.getParameter(PaxTraxConstants.INDEX) != null)
		{
			index = request.getParameter(PaxTraxConstants.INDEX);
			session.setAttribute(PaxTraxConstants.INDEX, new Integer(index));
		}
		else
		{
			flightDetails = null;
			flightBean = flightForm.getFlightBean();
			airlineReferenceBean = flightBean.getAirlineBean();
			airlineReferenceBean.setReferenceId(PaxTraxConstants.AIRLINE_CODE);
			flightBean.setAirlineBean(airlineReferenceBean);
			flightNumber = flightBean.getFlightNumber();
			isDeparture = flightBean.getIsDeparture();
			flightDate = flightBean.getFlightDate();
		}

		if (flightDetails == null)
		{
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE_RELOAD);
			flightForm = setComboAttributes(flightForm);
			flightDelegate = new FlightDelegate();
			forward = PaxTraxConstants.FLIGHT_CREATE;
			try
			{
				flightBean =
					flightDelegate.selectMaintainFlightDetails(flightBean);
				flightForm.setFlightBean(flightBean);
			}
			catch (FlightException fe)
			{
				request.setAttribute(
					PaxTraxConstants.FLIGHT,
					String.valueOf(PaxTraxConstants.FLIGHT_NOT_FOUND));
				ActionMessages messages = new ActionMessages();
				//messages.add(
				//	"flightNumber",
				//	new ActionMessage("" + fe.getErrorCode()));
				//request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.FAILURE);

				checkList = flightForm.getAirlineCodes();
				airlineReferenceBean = flightBean.getAirlineBean();
				for (int i = 0; i < checkList.size(); i++)
				{
					referenceDataBean = (ReferenceDataBean) checkList.get(i);

					if (referenceDataBean
						.getCodeId()
						.equals(airlineReferenceBean.getCodeId()))
					{
						airlineReferenceBean.setReferenceId(
							PaxTraxConstants.AIRLINE_CODE);
						airlineReferenceBean.setCodeValue(
							referenceDataBean.getCodeValue());
						flightBean.setAirlineBean(airlineReferenceBean);
					}
				}

				flightForm.setFlightBean(flightBean);
				forward = PaxTraxConstants.FLIGHT_CREATE;

			}

		}
		else
			if (flightDetails != null && !flightDetails.isEmpty())
			{
				forward = PaxTraxConstants.FLIGHT_CREATE;
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.UPDATE_SEARCH);
				flightForm = setComboAttributes(flightForm);
				flightBean =
					(FlightBean) flightDetails.get(Integer.parseInt(index) - 1);
				flightBean.setFlightNumber(flightBean.getFlightNumber());
				checkList = flightForm.getAirlineCodes();
				airlineReferenceBean = flightBean.getAirlineBean();
				for (int i = 0; i < checkList.size(); i++)
				{
					referenceDataBean = (ReferenceDataBean) checkList.get(i);
					if (referenceDataBean
						.getCodeValue()
						.equals(airlineReferenceBean.getCodeValue()))
					{
						airlineReferenceBean.setReferenceId(
							PaxTraxConstants.AIRLINE_CODE);
						airlineReferenceBean.setCodeId(
							referenceDataBean.getCodeId());
						flightBean.setAirlineBean(airlineReferenceBean);
					}
				}
				flightBean.setIsDeparture(flightBean.getIsDeparture());
				flightBean.setHrFlightCutOffTime(
					flightBean.getHrFlightCutOffTime());
				flightBean.setMinFlightCutOffTime(
					flightBean.getMinFlightCutOffTime());
				checkList = flightForm.getPickupLocations();
				airlineReferenceBean = flightBean.getPickupLocationBean();
				for (int i = 0; i < checkList.size(); i++)
				{
					referenceDataBean = (ReferenceDataBean) checkList.get(i);
					if (referenceDataBean
						.getCodeValue()
						.equals(airlineReferenceBean.getCodeValue()))
					{
						airlineReferenceBean.setReferenceId(
							PaxTraxConstants.PICK_UP_LOCATION);
						airlineReferenceBean.setCodeId(
							referenceDataBean.getCodeId());
						flightBean.setPickupLocationBean(airlineReferenceBean);
					}
				}
				checkList = flightForm.getFlightTypes();
				for (int i = 0; i < checkList.size(); i++)
				{
					referenceDataBean = (ReferenceDataBean) checkList.get(i);
					if (referenceDataBean
						.getCodeValue()
						.startsWith(flightBean.getFlightType()))
					{
						flightBean.setFlightType(referenceDataBean.getCodeId());
					}
				}
				checkList = flightForm.getAirports();

				originAirportBean = flightBean.getOriginAirportBean();
				for (int i = 0; i < checkList.size(); i++)
				{
					referenceDataBean = (ReferenceDataBean) checkList.get(i);
					if (referenceDataBean
						.getCodeValue()
						.equals(originAirportBean.getCodeValue()))
					{
						originAirportBean.setReferenceId(
							PaxTraxConstants.AIRPORT);
						originAirportBean.setCodeId(
							referenceDataBean.getCodeId());
						flightBean.setOriginAirportBean(originAirportBean);
					}
				}
				destinationAirportBean = flightBean.getDestinationAirportBean();
				for (int i = 0; i < checkList.size(); i++)
				{

					if (referenceDataBean
						.getCodeValue()
						.equals(destinationAirportBean.getCodeValue()))
					{
						destinationAirportBean.setReferenceId(
							PaxTraxConstants.AIRPORT);
						destinationAirportBean.setCodeId(
							referenceDataBean.getCodeId());
						flightBean.setDestinationAirportBean(
							destinationAirportBean);
					}
				}
				flightForm.setFlightBean(flightBean);
			}
		request.setAttribute(
			PaxTraxConstants.FLIGHT_TYPE,
			flightBean.getFlightType());

		PaxTraxLog.logDebug("PaxTrax::FlightAction::loadFlightDetails::End");
		return mapping.findForward(forward);
	}

	/**
	   Updates flight details by calling delegate method. It throws PaxTraxException if there is any problem in update
	 */
	public ActionForward updateFlight(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::updateFlight::Begin");
		HttpSession session = request.getSession();
		FlightForm flightForm = (FlightForm) form;
		boolean pickupLocationFound = false;
		FlightBean flightBean = flightForm.getFlightBean();
		/*Modified on 28th June 2006 - Starts
		*SR 1042 International DF Sale */
		String intlStatus = request.getParameter("inter");
		if ("true".equals(intlStatus))
			flightBean.setIsInternational(true);
		else
			flightBean.setIsInternational(false);
		/*Modified on 28th June 2006 - Ends
		* SR 1042 International DF Sale */

		flightBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		ReferenceDataBean referenceDataBean = null;
		ReferenceDataBean airlineReferenceBean = null;
		ReferenceDataBean originAirportReferenceBean = null;
		ReferenceDataBean destinationAirportReferenceBean = null;
		ReferenceDataBean pickupLocationReferenceBean = null;
		ArrayList airlineCodes = flightForm.getAirlineCodes();
		ArrayList airports = flightForm.getAirports();
		ArrayList pickupLocations = flightForm.getPickupLocations();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);

		if (airlineCodes != null && !airlineCodes.isEmpty())
		{
			airlineReferenceBean = flightBean.getAirlineBean();
			for (int i = 0; i < airlineCodes.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airlineCodes.get(i);
				if (airlineReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					airlineReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					airlineReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					airlineReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setAirlineBean(airlineReferenceBean);
					break;
				}
			}
		}

		if (airports != null && !airports.isEmpty())
		{
			originAirportReferenceBean = flightBean.getOriginAirportBean();
			for (int i = 0; i < airports.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airports.get(i);
				if (originAirportReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					originAirportReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					originAirportReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					originAirportReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setOriginAirportBean(originAirportReferenceBean);
					break;
				}
			}
		}

		if (airports != null && !airports.isEmpty())
		{
			destinationAirportReferenceBean =
				flightBean.getDestinationAirportBean();
			for (int i = 0; i < airports.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airports.get(i);
				if (destinationAirportReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					destinationAirportReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					destinationAirportReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					destinationAirportReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setDestinationAirportBean(
						destinationAirportReferenceBean);
					break;
				}
			}
		}

		if (pickupLocations != null && !pickupLocations.isEmpty())
		{
			pickupLocationReferenceBean = flightBean.getPickupLocationBean();
			for (int i = 0; i < pickupLocations.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) pickupLocations.get(i);
				if (pickupLocationReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					pickupLocationFound = true;
					pickupLocationReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					pickupLocationReferenceBean.setCodeId(
						referenceDataBean.getCodeId());
					pickupLocationReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setPickupLocationBean(
						pickupLocationReferenceBean);
					break;
				}
			}
		}
		if (!pickupLocationFound)
		{
			pickupLocationReferenceBean = new ReferenceDataBean();
			pickupLocationReferenceBean.setReferenceId(
				PaxTraxConstants.PICK_UP_LOCATION);
			pickupLocationReferenceBean.setCodeId("0");
			flightBean.setPickupLocationBean(pickupLocationReferenceBean);
		}
		if (PaxTraxConstants
			.TRUE
			.equals(request.getParameter("dailyCheckBox")))
			flightBean.setIsDailyCheckBox(true);
		else
			flightBean.setIsDailyCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("sunCheckBox")))
			flightBean.setIsSunCheckBox(true);
		else
			flightBean.setIsSunCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("monCheckBox")))
			flightBean.setIsMonCheckBox(true);
		else
			flightBean.setIsMonCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("tueCheckBox")))
			flightBean.setIsTueCheckBox(true);
		else
			flightBean.setIsTueCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("wedCheckBox")))
			flightBean.setIsWedCheckBox(true);
		else
			flightBean.setIsWedCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("thuCheckBox")))
			flightBean.setIsThuCheckBox(true);
		else
			flightBean.setIsThuCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("friCheckBox")))
			flightBean.setIsFriCheckBox(true);
		else
			flightBean.setIsFriCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("satCheckBox")))
			flightBean.setIsSatCheckBox(true);
		else
			flightBean.setIsSatCheckBox(false);

		FlightDelegate flightDelegate = new FlightDelegate();
		try
		{
			flightDelegate.updateFlightDetails(flightBean);
		}
		catch (FlightException fe)
		{
			/*Modified on 28th June 2006 - Starts
			*SR 1042 International DF Sale */

			if (fe.getErrorCode() == PaxTraxConstants.FLIGHT_ALREADY_EXISTS)
			{
				request.setAttribute(
					PaxTraxConstants.FLIGHT,
					String.valueOf(PaxTraxConstants.FLIGHT_ALREADY_EXISTS));
				//flightBean = reAssignCodeValue(flightForm, flightBean);
				//flightBean.setFlightType(flightBean.getFlightType());
				request.setAttribute(
					PaxTraxConstants.FLIGHT_TYPE,
					flightBean.getFlightType());
				flightForm.setFlightBean(flightBean);
			}
			else
			{
				request.setAttribute(
					PaxTraxConstants.FLIGHT,
					String.valueOf(PaxTraxConstants.FLIGHT_PICKUP_MISMATCH));
				flightBean.setFlightType(flightBean.getFlightType());
				flightForm.setFlightBean(flightBean);
			}
			
			/*Modified on 28th June 2006 - Ends
			*SR 1042 International DF Sale */


			PaxTraxLog.logError(fe.getMessage());
			//ActionMessages messages = new ActionMessages();
			//messages.add(
			//	"flightNumber",
			//	new ActionMessage("" + fe.getErrorCode()));
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE_RELOAD);

			//request.setAttribute(PaxTraxConstants.FLIGHT_TYPE,flightBean.getFlightType());

			return mapping.findForward(PaxTraxConstants.FLIGHT_CREATE);
		}
		if (operation != null
			&& operation.equals(PaxTraxConstants.UPDATE_SEARCH))
		{
			ArrayList flightDetails =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_FLIGHT_RECORDS);
			int index =
				((Integer) session.getAttribute(PaxTraxConstants.INDEX))
					.intValue();
			//session.removeAttribute(PaxTraxConstants.INDEX);
			flightDetails.remove(index - 1);
			flightDetails.add(index - 1, flightBean);
			session.removeAttribute(PaxTraxConstants.ALL_FLIGHT_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_FLIGHT_RECORDS,
				flightDetails);
		}
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.UPDATE);
		flightBean = reAssignCodeValue(flightForm, flightBean);
		request.setAttribute(
			PaxTraxConstants.FLIGHT_TYPE,
			flightBean.getFlightType());
		//added for CA#290863 by vignesh starts here
		  if(flightBean.isVesselMode())
		  {
			  request.setAttribute(PaxTraxConstants.VESSEL_MODE_CHECKED,PaxTraxConstants.TRUE);
		  }
		  else
			  request.setAttribute(PaxTraxConstants.VESSEL_MODE_CHECKED,PaxTraxConstants.FALSE);
		//added for CA#290863 by vignesh ends here
		PaxTraxLog.logDebug("PaxTrax::FlightAction::updateFlight::End");
		return mapping.findForward(PaxTraxConstants.SAVE_FLIGHT);
	}

	/**
	   Removes flight by calling delegate method. It throws PaxTraxException if there is any problem in remove
	 */
	public ActionForward removeFlight(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::removeFlight::Begin");
		HttpSession session = request.getSession();
		FlightForm flightForm = (FlightForm) form;
		FlightBean flightBean = flightForm.getFlightBean();
		flightBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		ReferenceDataBean referenceDataBean = null;
		ReferenceDataBean airlineReferenceBean = null;
		ReferenceDataBean originAirportReferenceBean = null;
		ReferenceDataBean destinationAirportReferenceBean = null;
		ReferenceDataBean pickupLocationReferenceBean = null;
		ArrayList airlineCodes = flightForm.getAirlineCodes();
		ArrayList airports = flightForm.getAirports();
		ArrayList pickupLocations = flightForm.getPickupLocations();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		int size = 0;

		if (airlineCodes != null && !airlineCodes.isEmpty())
		{
			airlineReferenceBean = flightBean.getAirlineBean();
			for (int i = 0; i < airlineCodes.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airlineCodes.get(i);
				if (airlineReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					airlineReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					airlineReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setAirlineBean(airlineReferenceBean);
					break;
				}
			}
		}

		if (airports != null && !airports.isEmpty())
		{
			originAirportReferenceBean = flightBean.getOriginAirportBean();
			for (int i = 0; i < airports.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airports.get(i);
				if (originAirportReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					originAirportReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					originAirportReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setOriginAirportBean(originAirportReferenceBean);
					break;
				}
			}
		}

		if (airports != null && !airports.isEmpty())
		{
			destinationAirportReferenceBean =
				flightBean.getDestinationAirportBean();
			for (int i = 0; i < airports.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) airports.get(i);
				if (destinationAirportReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					destinationAirportReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					destinationAirportReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setDestinationAirportBean(
						destinationAirportReferenceBean);
					break;
				}
			}
		}

		if (pickupLocations != null && !pickupLocations.isEmpty())
		{
			pickupLocationReferenceBean = flightBean.getPickupLocationBean();
			for (int i = 0; i < pickupLocations.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) pickupLocations.get(i);
				if (pickupLocationReferenceBean
					.getCodeId()
					.equals(referenceDataBean.getCodeId()))
				{
					pickupLocationReferenceBean.setReferenceId(
						referenceDataBean.getReferenceId());
					pickupLocationReferenceBean.setCodeValue(
						referenceDataBean.getCodeValue());
					flightBean.setPickupLocationBean(
						pickupLocationReferenceBean);
					break;
				}
			}
		}

		if (PaxTraxConstants
			.TRUE
			.equals(request.getParameter("dailyCheckBox")))
			flightBean.setIsDailyCheckBox(true);
		else
			flightBean.setIsDailyCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("sunCheckBox")))
			flightBean.setIsSunCheckBox(true);
		else
			flightBean.setIsSunCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("monCheckBox")))
			flightBean.setIsMonCheckBox(true);
		else
			flightBean.setIsMonCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("tueCheckBox")))
			flightBean.setIsTueCheckBox(true);
		else
			flightBean.setIsTueCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("wedCheckBox")))
			flightBean.setIsWedCheckBox(true);
		else
			flightBean.setIsWedCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("thuCheckBox")))
			flightBean.setIsThuCheckBox(true);
		else
			flightBean.setIsThuCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("friCheckBox")))
			flightBean.setIsFriCheckBox(true);
		else
			flightBean.setIsFriCheckBox(false);

		if (PaxTraxConstants.TRUE.equals(request.getParameter("satCheckBox")))
			flightBean.setIsSatCheckBox(true);
		else
			flightBean.setIsSatCheckBox(false);

		FlightDelegate flightDelegate = new FlightDelegate();
		flightDelegate.deleteFlightDetails(flightBean);
		if (operation != null
			&& operation.equals(PaxTraxConstants.UPDATE_SEARCH))
		{

			ArrayList flightDetails =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_FLIGHT_RECORDS);
			int index =
				((Integer) session.getAttribute(PaxTraxConstants.INDEX))
					.intValue();
			session.removeAttribute(PaxTraxConstants.INDEX);
			flightDetails.remove(index - 1);
			session.removeAttribute(PaxTraxConstants.ALL_FLIGHT_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_FLIGHT_RECORDS,
				flightDetails);

			/*
			 * Adjusting the Page number
			 */
			if (size == 1)
			{
				/*
				 * if there was only one record and
				 * that got deleted then page number attribute
				 * should be removed from the session
				 */
				session.removeAttribute(PaxTraxConstants.FLIGHT_PAGE_NUMBER);
			}
			else
				if ((size % 10) == 1 && (index == (size - 1)))
				{
					String pageNumber =
						(String) session.getAttribute(
							PaxTraxConstants.FLIGHT_PAGE_NUMBER);
					int page = Integer.parseInt(pageNumber);
					StringBuffer pageNumberString = new StringBuffer(page - 1);
					session.setAttribute(
						PaxTraxConstants.FLIGHT_PAGE_NUMBER,
						pageNumberString.toString());
				}
		}
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.UPDATE_DELETE);
		flightBean = reAssignCodeValue(flightForm, flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightAction::removeFlight::End");
		return mapping.findForward(PaxTraxConstants.SAVE_FLIGHT);
	}

	/**
	   Forwards to flight home page
	 */
	public ActionForward cancelFlightPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::cancelFlightPage::Begin");
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		String forward = null;
		HttpSession session = request.getSession();
		FlightForm flightForm = (FlightForm) form;

		ArrayList checkList = null;
		ReferenceDataBean referenceDataBean = null;
		checkList = flightForm.getFlightTypes();

		if (operation != null
			&& operation.equals(PaxTraxConstants.UPDATE_SEARCH))
		{
			ArrayList flightDetails =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_FLIGHT_RECORDS);
			int index =
				((Integer) session.getAttribute(PaxTraxConstants.INDEX))
					.intValue();
			session.removeAttribute(PaxTraxConstants.INDEX);
			FlightBean flightBean = (FlightBean) flightDetails.get(index - 1);

			for (int i = 0; i < checkList.size(); i++)
			{
				referenceDataBean = (ReferenceDataBean) checkList.get(i);
				if (referenceDataBean
					.getCodeId()
					.startsWith(flightBean.getFlightType()))
				{
					if (referenceDataBean.getCodeId().equals("1"))
						flightBean.setFlightType(PaxTraxConstants.SCHEDULED);
					else
						flightBean.setFlightType(
							PaxTraxConstants.NON_SCHEDULED);
				}
			}
			flightDetails.remove(index - 1);
			flightDetails.add(index - 1, flightBean);
			session.removeAttribute(PaxTraxConstants.ALL_FLIGHT_RECORDS);
			session.setAttribute(
				PaxTraxConstants.ALL_FLIGHT_RECORDS,
				flightDetails);
			request.setAttribute(
				PaxTraxConstants.FLIGHT_PAGE_NUMBER,
				request.getParameter(PaxTraxConstants.FLIGHT_PAGE_NUMBER));
			request.setAttribute(
				PaxTraxConstants.BACK_TO_SEARCH_USER_PAGE,
				PaxTraxConstants.TRUE);
			forward = PaxTraxConstants.CANCEL_FLIGHT_SEARCH;
		}
		else
		{
			forward = PaxTraxConstants.CANCEL_FLIGHT_HOME;
		}
		PaxTraxLog.logDebug("PaxTrax::FlightAction::cancelFlightPage::End");
		return mapping.findForward(forward);
	}

	/**
	 *  This sets the combo values in the form
	 */
	private FlightForm setComboAttributes(FlightForm flightForm)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::setComboAttributes::Begin");
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		flightForm.setAirlineCodes(
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.AIRLINE_CODE));
		flightForm.setFlightTypes(loadReferenceData("flighttype"));
		flightForm.setAirports(
			referenceDataDelegate.loadReferenceData(PaxTraxConstants.AIRPORT));
		flightForm.setPickupLocations(
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.PICK_UP_LOCATION));
		flightForm.setHours(loadReferenceData("hours"));
		flightForm.setMinutes(loadReferenceData("minutes"));
	
		PaxTraxLog.logDebug("PaxTrax::FlightAction::setComboAttributes::End");
		return flightForm;
	}

	/**
	 *  This generates the combo values based on the code
	 */
	private ArrayList loadReferenceData(String code)
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::loadReferenceData::Begin");
		ReferenceDataBean referenceDataBean = null;
		ArrayList flightDetails = null;

		if (code.equals("flighttype"))
		{
			flightDetails = new ArrayList();
			referenceDataBean = new ReferenceDataBean();

			referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId("1");
			referenceDataBean.setCodeValue("Scheduled Flights");
			flightDetails.add(referenceDataBean);

			referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId("2");
			referenceDataBean.setCodeValue("Non Scheduled Flights");
			flightDetails.add(referenceDataBean);

		}
		else
			if (code.equals("hours"))
			{
				flightDetails = new ArrayList();

				for (int i = 0; i < 24; i++)
				{
					referenceDataBean = new ReferenceDataBean();
					if (i < 10)
					{
						referenceDataBean.setCodeId("0" + String.valueOf(i));
						referenceDataBean.setCodeValue("0" + String.valueOf(i));
					}
					else
					{
						referenceDataBean.setCodeId(String.valueOf(i));
						referenceDataBean.setCodeValue(String.valueOf(i));
					}
					flightDetails.add(referenceDataBean);
				}
			}
			else
				if (code.equals("minutes"))
				{
					flightDetails = new ArrayList();

					for (int i = 0; i < 60; i++)
					{
						referenceDataBean = new ReferenceDataBean();
						if (i < 10)
						{
							referenceDataBean.setCodeId(
								"0" + String.valueOf(i));
							referenceDataBean.setCodeValue(
								"0" + String.valueOf(i));
						}
						else
						{
							referenceDataBean.setCodeId(String.valueOf(i));
							referenceDataBean.setCodeValue(String.valueOf(i));
						}
						flightDetails.add(referenceDataBean);
					}
				} 
		PaxTraxLog.logDebug("PaxTrax::FlightAction::loadReferenceData::End");
		return flightDetails;
	}

	/**
	 *  This Reassigns the selected code of the combo to its corresponding value
	 */
	private FlightBean reAssignCodeValue(
		FlightForm flightForm,
		FlightBean flightBean)
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::reAssignCodeValue::Begin");
		ReferenceDataBean referenceDataBean = null;
		String originAirport = flightBean.getOriginAirport();
		String destinationAirport = flightBean.getDestinationAirport();
		String pickupLocation = flightBean.getPickupLocation();
		String flightType = flightBean.getFlightType();
		String airlineCode = flightBean.getAirlineCode();
		ArrayList airports = flightForm.getAirports();
		ArrayList pickupLocations = flightForm.getPickupLocations();
		ArrayList flightTypes = flightForm.getFlightTypes();
		ArrayList airlineCodes = flightForm.getAirlineCodes();
		for (int i = 0; i < airlineCodes.size(); i++)
		{
			referenceDataBean = (ReferenceDataBean) airlineCodes.get(i);
			if (referenceDataBean.getCodeId().equals(airlineCode))
			{
				flightBean.setAirlineCode(referenceDataBean.getCodeValue());
				break;
			}
		}
		for (int i = 0; i < airports.size(); i++)
		{
			referenceDataBean = (ReferenceDataBean) airports.get(i);
			if (referenceDataBean.getCodeId().equals(originAirport))
			{
				flightBean.setOriginAirport(referenceDataBean.getCodeValue());
				break;
			}
		}
		for (int i = 0; i < airports.size(); i++)
		{
			referenceDataBean = (ReferenceDataBean) airports.get(i);
			if (referenceDataBean.getCodeId().equals(destinationAirport))
			{
				flightBean.setDestinationAirport(
					referenceDataBean.getCodeValue());
				break;
			}
		}
		for (int i = 0; i < pickupLocations.size(); i++)
		{
			referenceDataBean = (ReferenceDataBean) pickupLocations.get(i);
			if (referenceDataBean.getCodeId().equals(pickupLocation))
			{
				flightBean.setPickupLocation(referenceDataBean.getCodeValue());
				break;
			}
		}
		for (int i = 0; i < flightTypes.size(); i++)
		{
			referenceDataBean = (ReferenceDataBean) flightTypes.get(i);
			if (referenceDataBean.getCodeId().equals(flightType))
			{
				flightBean.setFlightType(referenceDataBean.getCodeValue());
				break;
			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightAction::reAssignCodeValue::End");
		return flightBean;
	}

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::FlightAction::changeLanguage::Begin");
		String flightBean = request.getParameter(PaxTraxConstants.FLIGHT_TYPE);
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String forward = null;
		super.changeLanguage(request, language, country);
		FlightForm flightForm = (FlightForm) form;
		HttpSession session = request.getSession();
		String page = request.getParameter(PaxTraxConstants.PAGE);
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}
		if (page.equals(PaxTraxConstants.FLIGHT_CREATE))
		{
			forward = PaxTraxConstants.FLIGHT_CREATE;
			String errorCode = request.getParameter(PaxTraxConstants.FLIGHT);
			if (errorCode
				.equals(String.valueOf(PaxTraxConstants.FLIGHT_ALREADY_EXISTS)))
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					"flightNumber",
					new ActionMessage(
						"" + PaxTraxConstants.FLIGHT_ALREADY_EXISTS));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.FLIGHT,
					String.valueOf(PaxTraxConstants.FLIGHT_ALREADY_EXISTS));
				forward = PaxTraxConstants.FLIGHT_CREATE;

			}
			else
			/*Modified on 28th June 2006 - Starts
			*SR 1042 International DF Sale */

				if (errorCode
					.equals(String.valueOf(PaxTraxConstants.FLIGHT_NOT_FOUND)))
				{
					ActionMessages messages = new ActionMessages();
					messages.add(
						"flightNumber",
						new ActionMessage(
							"" + PaxTraxConstants.FLIGHT_NOT_FOUND));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
					request.setAttribute(
						PaxTraxConstants.FLIGHT,
						String.valueOf(PaxTraxConstants.FLIGHT_NOT_FOUND));
					forward = PaxTraxConstants.FLIGHT_CREATE;
				}
				else
					if (errorCode
						.equals(
							String.valueOf(
								PaxTraxConstants.FLIGHT_PICKUP_MISMATCH)))
					{
						ActionMessages messages = new ActionMessages();
						messages.add(
							"flightNumber",
							new ActionMessage(
								"" + PaxTraxConstants.FLIGHT_PICKUP_MISMATCH));
						request.setAttribute(Globals.MESSAGE_KEY, messages);
						request.setAttribute(
							PaxTraxConstants.FLIGHT,
							String.valueOf(
								PaxTraxConstants.FLIGHT_PICKUP_MISMATCH));
						forward = PaxTraxConstants.FLIGHT_CREATE;
					}
			/*Modified on 28th June 2006 - Ends
			*SR 1042 International DF Sale */
	
		}
		else
			if (page.equals(PaxTraxConstants.SAVE_FLIGHT))
			{
				forward = PaxTraxConstants.SAVE_FLIGHT;
			}

		request.setAttribute(
			PaxTraxConstants.FLIGHT_PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.FLIGHT_PAGE_NUMBER));

		PaxTraxLog.logDebug("PaxTrax::FlightAction::changeLanguage::End");
		request.setAttribute(PaxTraxConstants.FLIGHT_TYPE, flightBean);
		return mapping.findForward(forward);
	}

}
