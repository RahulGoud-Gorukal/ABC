package com.dfs.paxtrax.admin.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.HashMap;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/03/2004	Sundarrajan.K.	Created   
 */

/**
   This is value object class contains the flight attributes
 */
public class FlightBean extends PaxTraxValueObject {

	/**
	 * scheduleDetails
	 */
	private ArrayList scheduleDetails = null;

	/**
	*  airlineBean 
	*/
	private ReferenceDataBean airlineBean = null;

	/**
	* originAirportBean
	*/
	private ReferenceDataBean originAirportBean = null;

	/**
	* destinationAirportBean
	*/
	private ReferenceDataBean destinationAirportBean = null;

	/**
	* pickupLocationBean
	*/
	private ReferenceDataBean pickupLocationBean = null;

	/** dailyCheckBox checks for daily
	*/
	private boolean isDailyCheckBox;

	/** monCheckBox checks for monday 
	 */
	private boolean isMonCheckBox;

	/** tueCheckBox checks for tuesday
	 */
	private boolean isTueCheckBox;

	/** wedCheckBox checks for wednesday
	 */
	private boolean isWedCheckBox;

	/** thuCheckBox checks for thursday 
	 */
	private boolean isThuCheckBox;

	/** friCheckBox checks for friday
	 */
	private boolean isFriCheckBox;

	/** satCheckBox checks for saturday 
	 */
	private boolean isSatCheckBox;

	/** sunCheckBox checks for sunday
	 */
	private boolean isSunCheckBox;

	/**
		Date time hour
	*/
	private String dateTimeInHr = null;

	/**
		Date time minute
	*/
	private String dateTimeInMin = null;

	/**
		Override Date time hour
	*/
	private String overrideDateTimeInHr = null;

	/**
		Override Date time minute
	*/
	private String overrideDateTimeInMin = null;

	/**
		Daily time hour
	*/
	private String dailyTimeInHr = null;

	/**
		Daily time minute
	 */
	private String dailyTimeInMin = null;

	/**
	   Monday hour time
	 */
	private String monTimeInHr = null;

	/**
	   Monday minute time
	 */
	private String monTimeInMin = null;

	/**
	   Tue hour time
	 */
	private String tueTimeInHr = null;

	/**
	   Tuesday min time
	 */
	private String tueTimeInMin = null;

	/**
	   Wednesday hour time
	 */
	private String wedTimeInHr = null;

	/**
	   Wednesday minute time
	 */
	private String wedTimeInMin = null;

	/**
	   Thursday hour time
	 */
	private String thuTimeInHr = null;

	/**
	   Thursday minute time
	 */
	private String thuTimeInMin = null;

	/**
	   Friday hour time
	 */
	private String friTimeInHr = null;

	/**
	   Friday minute time
	 */
	private String friTimeInMin = null;

	/**
	   Saturday hour time
	 */
	private String satTimeInHr = null;

	/**
	   Saturday minute time
	 */
	private String satTimeInMin = null;

	/**
	   Sunday hour time
	 */
	private String sunTimeInHr = null;

	/**
	   Sunday minute time
	 */
	private String sunTimeInMin = null;

	/**
	   Flight number
	 */
	private String flightNumber = null;
	/**
	   Indicates departure or arrival
	 */
	private boolean isDeparture = false;

	/**
	   variable to indicate whether flight cancelled or not
	 */
	private boolean isFlightCancelled = false;

	/**
	   Origin airport for the flight
	 */
	private String originAirport = null;

	/**
	   Destination airport for a flight
	 */
	private String destinationAirport = null;

	/**
	   Flight Type
	 */
	private String flightType = null;

	/**
	   Hour cutoff time 
	 */
	private String hrFlightCutOffTime = null;

	/**
	   Minute cutoff time 
	 */
	private String minFlightCutOffTime = null;

	/**
	   flightSchedule contains all the selected hours and minutes 
	 */
	private HashMap flightSchedule = null;

	/**
	   pickupLocation
	 */
	private String pickupLocation = null;

	/**
		airlineCode   
	 */
	private String airlineCode = null;

	/**
	 *  airlineRef
	 */
	private String airlineRefId = null;

	/**
	   airlineName
	 */
	private String airlineName = null;

	/**
	   flightDate
	 */
	private String flightDate = null;

	private String oldFlightDate = null;

	/**
		flightOverrideDate
	  */
	private String flightOverrideDate = null;
	
	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */


	private boolean isInternational = false;
	
	/* Added on 08th June 2012 - starts 
	 *  Vessel field in create/maintain flight page
	 * */
//	added for CA#290863 by vignesh starts here
	private boolean isVesselMode = false;
	
	private String vesselName = null;

//	added for CA#290863 by vignesh ends here
	
	/* Added on 08th June 2012 - Ends 
		 *  Vessel field in create/maintain flight page
		 * */
	private String travelType = null;
	
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

	/**
	   Returns flightNumber
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	   Sets flightNumber
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	   Returns origin airport for flight
	 */
	public String getOriginAirport() {
		return originAirport;
	}

	/**
	   Sets origin airport for flight
	 */
	public void setOriginAirport(String originAirport) {
		this.originAirport = originAirport;
	}

	/**
	   Returns destination airport for flight
	 */
	public String getDestinationAirport() {
		return destinationAirport;
	}

	/**
	   Sets destination airport for flight
	 */
	public void setDestinationAirport(String destinationAirport) {
		this.destinationAirport = destinationAirport;
	}

	/**
	   Returns flight type indicating scheduled or non-scheduled
	 */
	public String getFlightType() {
		return flightType;
	}

	/**
	   Sets flight type indicating scheduled or non-scheduled
	 */
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	/**
	   Returns flight date indicating non-scheduled flights
	 */
	public String getFlightDate() {
		return flightDate;
	}

	/**
	   Sets flight date indicating non-scheduled flights
	 */
	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	/**
	   Returns hour flight cutoff time
	 */
	public String getHrFlightCutOffTime() {
		return hrFlightCutOffTime;
	}

	/**
	   Sets hour flight cutoff time
	*/
	public void setHrFlightCutOffTime(String hrFlightCutOffTime) {
		this.hrFlightCutOffTime = hrFlightCutOffTime;
	}

	/**
	   Returns list of flying days and time
	 */
	public HashMap getFlightSchedule() {
		return flightSchedule;
	}

	/**
	   Sets list of flying days with time
	 */
	public void setFlightSchedule(HashMap flightSchedule) {
		this.flightSchedule = flightSchedule;
	}

	/**
	   Returns minute flight cutoff time
	 */
	public String getMinFlightCutOffTime() {
		return minFlightCutOffTime;
	}

	/**
	   Sets min flight cutoff time
	 */
	public void setMinFlightCutOffTime(String minFlightCutOffTime) {
		this.minFlightCutOffTime = minFlightCutOffTime;
	}

	/**
	   Returns pickupLocation 
	 */
	public String getPickupLocation() {
		return pickupLocation;
	}

	/**
		Sets pickupLocation
	 */
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	/**
	   returns the airline code
	 */
	public String getAirlineCode() {
		return airlineCode;
	}

	/**
	   Sets airlineCode
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	   returns the airline code
	*/
	public String getAirlineName() {
		return airlineName;
	}

	/**
	   Sets airlineName	   
	 */
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	/**
	 * Returns the dailyCheckBox.
	 */
	public boolean getIsDailyCheckBox() {
		return isDailyCheckBox;
	}

	/**
	 * Returns the friCheckBox.
	 * @return boolean
	 */
	public boolean getIsFriCheckBox() {
		return isFriCheckBox;
	}

	/**
	 * Returns the monCheckBox.
	 * @return boolean
	 */
	public boolean getIsMonCheckBox() {
		return isMonCheckBox;
	}

	/**
	 * Returns the satCheckBox.
	 * @return boolean
	 */
	public boolean getIsSatCheckBox() {
		return isSatCheckBox;
	}

	/**
	 * Returns the sunCheckBox.
	 * @return boolean
	 */
	public boolean getIsSunCheckBox() {
		return isSunCheckBox;
	}

	/**
	 * Returns the thuCheckBox.
	 * @return boolean
	 */
	public boolean getIsThuCheckBox() {
		return isThuCheckBox;
	}

	/**
	 * Returns the tueCheckBox.
	 * @return boolean
	 */
	public boolean getIsTueCheckBox() {
		return isTueCheckBox;
	}

	/**
	 * Returns the wedCheckBox.
	 * @return boolean
	 */
	public boolean getIsWedCheckBox() {
		return isWedCheckBox;
	}

	/**
	 * Sets the dailyCheckBox.
	 * @param dailyCheckBox The dailyCheckBox to set
	 */
	public void setIsDailyCheckBox(boolean isDailyCheckBox) {
		this.isDailyCheckBox = isDailyCheckBox;
	}

	/**
	 * Sets the friCheckBox.
	 * @param friCheckBox The friCheckBox to set
	 */
	public void setIsFriCheckBox(boolean isFriCheckBox) {
		this.isFriCheckBox = isFriCheckBox;
	}

	/**
	 * Sets the monCheckBox.
	 * @param monCheckBox The monCheckBox to set
	 */
	public void setIsMonCheckBox(boolean isMonCheckBox) {
		this.isMonCheckBox = isMonCheckBox;
	}

	/**
	 * Sets the satCheckBox.
	 * @param satCheckBox The satCheckBox to set
	 */
	public void setIsSatCheckBox(boolean isSatCheckBox) {
		this.isSatCheckBox = isSatCheckBox;
	}

	/**
	 * Sets the sunCheckBox.
	 * @param sunCheckBox The sunCheckBox to set
	 */
	public void setIsSunCheckBox(boolean isSunCheckBox) {
		this.isSunCheckBox = isSunCheckBox;
	}

	/**
	 * Sets the thuCheckBox.
	 * @param thuCheckBox The thuCheckBox to set
	 */
	public void setIsThuCheckBox(boolean isThuCheckBox) {
		this.isThuCheckBox = isThuCheckBox;
	}

	/**
	 * Sets the tueCheckBox.
	 * @param tueCheckBox The tueCheckBox to set
	 */
	public void setIsTueCheckBox(boolean isTueCheckBox) {
		this.isTueCheckBox = isTueCheckBox;
	}

	/**
	 * Sets the wedCheckBox.
	 * @param wedCheckBox The wedCheckBox to set
	 */
	public void setIsWedCheckBox(boolean isWedCheckBox) {
		this.isWedCheckBox = isWedCheckBox;
	}

	/**
	 * Returns the dailyTimeInHr.
	 * @return String
	 */
	public String getDailyTimeInHr() {
		return dailyTimeInHr;
	}

	/**
	 * Returns the dailyTimeInMin.
	 * @return String
	 */
	public String getDailyTimeInMin() {
		return dailyTimeInMin;
	}

	/**
	 * Returns the dateTimeInHr.
	 * @return String
	 */
	public String getDateTimeInHr() {
		return dateTimeInHr;
	}

	/**
	 * Returns the dateTimeInMin.
	 * @return String
	 */
	public String getDateTimeInMin() {
		return dateTimeInMin;
	}

	/**
	 * Returns the friTimeInHr.
	 * @return String
	 */
	public String getFriTimeInHr() {
		return friTimeInHr;
	}

	/**
	 * Returns the friTimeInMin.
	 * @return String
	 */
	public String getFriTimeInMin() {
		return friTimeInMin;
	}

	/**
	 * Returns the monTimeInHr.
	 * @return String
	 */
	public String getMonTimeInHr() {
		return monTimeInHr;
	}

	/**
	 * Returns the monTimeInMin.
	 * @return String
	 */
	public String getMonTimeInMin() {
		return monTimeInMin;
	}

	/**
	 * Returns the satTimeInHr.
	 * @return String
	 */
	public String getSatTimeInHr() {
		return satTimeInHr;
	}

	/**
	 * Returns the satTimeInMin.
	 * @return String
	 */
	public String getSatTimeInMin() {
		return satTimeInMin;
	}

	/**
	 * Returns the sunTimeInHr.
	 * @return String
	 */
	public String getSunTimeInHr() {
		return sunTimeInHr;
	}

	/**
	 * Returns the sunTimeInMin.
	 * @return String
	 */
	public String getSunTimeInMin() {
		return sunTimeInMin;
	}

	/**
	 * Returns the thuTimeInHr.
	 * @return String
	 */
	public String getThuTimeInHr() {
		return thuTimeInHr;
	}

	/**
	 * Returns the thuTimeInMin.
	 * @return String
	 */
	public String getThuTimeInMin() {
		return thuTimeInMin;
	}

	/**
	 * Returns the tueTimeInHr.
	 * @return String
	 */
	public String getTueTimeInHr() {
		return tueTimeInHr;
	}

	/**
	 * Returns the tueTimeInMin.
	 * @return String
	 */
	public String getTueTimeInMin() {
		return tueTimeInMin;
	}

	/**
	 * Returns the wedTimeInHr.
	 * @return String
	 */
	public String getWedTimeInHr() {
		return wedTimeInHr;
	}

	/**
	 * Returns the wedTimeInMin.
	 * @return String
	 */
	public String getWedTimeInMin() {
		return wedTimeInMin;
	}

	/**
	 * Sets the dailyTimeInHr.
	 * @param dailyTimeInHr The dailyTimeInHr to set
	 */
	public void setDailyTimeInHr(String dailyTimeInHr) {
		this.dailyTimeInHr = dailyTimeInHr;
	}

	/**
	 * Sets the dailyTimeInMin.
	 * @param dailyTimeInMin The dailyTimeInMin to set
	 */
	public void setDailyTimeInMin(String dailyTimeInMin) {
		this.dailyTimeInMin = dailyTimeInMin;
	}

	/**
	 * Sets the dateTimeInHr.
	 * @param dateTimeInHr The dateTimeInHr to set
	 */
	public void setDateTimeInHr(String dateTimeInHr) {
		this.dateTimeInHr = dateTimeInHr;
	}

	/**
	 * Sets the dateTimeInMin.
	 * @param dateTimeInMin The dateTimeInMin to set
	 */
	public void setDateTimeInMin(String dateTimeInMin) {
		this.dateTimeInMin = dateTimeInMin;
	}

	/**
	 * Sets the friTimeInHr.
	 * @param friTimeInHr The friTimeInHr to set
	 */
	public void setFriTimeInHr(String friTimeInHr) {
		this.friTimeInHr = friTimeInHr;
	}

	/**
	 * Sets the friTimeInMin.
	 * @param friTimeInMin The friTimeInMin to set
	 */
	public void setFriTimeInMin(String friTimeInMin) {
		this.friTimeInMin = friTimeInMin;
	}

	/**
	 * Sets the monTimeInHr.
	 * @param monTimeInHr The monTimeInHr to set
	 */
	public void setMonTimeInHr(String monTimeInHr) {
		this.monTimeInHr = monTimeInHr;
	}

	/**
	 * Sets the monTimeInMin.
	 * @param monTimeInMin The monTimeInMin to set
	 */
	public void setMonTimeInMin(String monTimeInMin) {
		this.monTimeInMin = monTimeInMin;
	}

	/**
	 * Sets the satTimeInHr.
	 * @param satTimeInHr The satTimeInHr to set
	 */
	public void setSatTimeInHr(String satTimeInHr) {
		this.satTimeInHr = satTimeInHr;
	}

	/**
	 * Sets the satTimeInMin.
	 * @param satTimeInMin The satTimeInMin to set
	 */
	public void setSatTimeInMin(String satTimeInMin) {
		this.satTimeInMin = satTimeInMin;
	}

	/**
	 * Sets the sunTimeInHr.
	 * @param sunTimeInHr The sunTimeInHr to set
	 */
	public void setSunTimeInHr(String sunTimeInHr) {
		this.sunTimeInHr = sunTimeInHr;
	}

	/**
	 * Sets the sunTimeInMin.
	 * @param sunTimeInMin The sunTimeInMin to set
	 */
	public void setSunTimeInMin(String sunTimeInMin) {
		this.sunTimeInMin = sunTimeInMin;
	}

	/**
	 * Sets the thuTimeInHr.
	 * @param thuTimeInHr The thuTimeInHr to set
	 */
	public void setThuTimeInHr(String thuTimeInHr) {
		this.thuTimeInHr = thuTimeInHr;
	}

	/**
	 * Sets the thuTimeInMin.
	 * @param thuTimeInMin The thuTimeInMin to set
	 */
	public void setThuTimeInMin(String thuTimeInMin) {
		this.thuTimeInMin = thuTimeInMin;
	}

	/**
	 * Sets the tueTimeInHr.
	 * @param tueTimeInHr The tueTimeInHr to set
	 */
	public void setTueTimeInHr(String tueTimeInHr) {
		this.tueTimeInHr = tueTimeInHr;
	}

	/**
	 * Sets the tueTimeInMin.
	 * @param tueTimeInMin The tueTimeInMin to set
	 */
	public void setTueTimeInMin(String tueTimeInMin) {
		this.tueTimeInMin = tueTimeInMin;
	}

	/**
	 * Sets the wedTimeInHr.
	 * @param wedTimeInHr The wedTimeInHr to set
	 */
	public void setWedTimeInHr(String wedTimeInHr) {
		this.wedTimeInHr = wedTimeInHr;
	}

	/**
	 * Sets the wedTimeInMin.
	 * @param wedTimeInMin The wedTimeInMin to set
	 */
	public void setWedTimeInMin(String wedTimeInMin) {
		this.wedTimeInMin = wedTimeInMin;
	}

	/**
	 * Returns the isMonCheckBox.
	 * @return boolean
	 */
	public boolean isMonCheckBox() {
		return isMonCheckBox;
	}

	/**
	 * Returns the isSatCheckBox.
	 * @return boolean
	 */
	public boolean isSatCheckBox() {
		return isSatCheckBox;
	}

	/**
	 * Returns the isSunCheckBox.
	 * @return boolean
	 */
	public boolean isSunCheckBox() {
		return isSunCheckBox;
	}

	/**
	 * Returns the isThuCheckBox.
	 * @return boolean
	 */
	public boolean isThuCheckBox() {
		return isThuCheckBox;
	}

	/**
	 * Returns the isTueCheckBox.
	 * @return boolean
	 */
	public boolean isTueCheckBox() {
		return isTueCheckBox;
	}

	/**
	 * Returns the isWedCheckBox.
	 * @return boolean
	 */
	public boolean isWedCheckBox() {
		return isWedCheckBox;
	}

	/**
	 * Returns the isDeparture.
	 * @return boolean
	 */
	public boolean getIsDeparture() {
		return isDeparture;
	}

	/**
	 * Sets the isDeparture.
	 * @param isDeparture The isDeparture to set
	 */
	public void setIsDeparture(boolean isDeparture) {
		this.isDeparture = isDeparture;
	}

	/**
	 * Returns the scheduleDetails.
	 * @return ArrayList
	 */
	public ArrayList getScheduleDetails() {
		return scheduleDetails;
	}

	/**
	 * Sets the scheduleDetails.
	 * @param scheduleDetails The scheduleDetails to set
	 */
	public void setScheduleDetails(ArrayList scheduleDetails) {
		this.scheduleDetails = scheduleDetails;
	}

	/**
	 * Returns the airlineBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getAirlineBean() {
		return airlineBean;
	}

	/**
	 * Returns the destinationAirportBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getDestinationAirportBean() {
		return destinationAirportBean;
	}

	/**
	 * Returns the originAirportBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getOriginAirportBean() {
		return originAirportBean;
	}

	/**
	 * Returns the pickupLocationBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getPickupLocationBean() {
		return pickupLocationBean;
	}

	/**
	 * Sets the airlineBean.
	 * @param airlineBean The airlineBean to set
	 */
	public void setAirlineBean(ReferenceDataBean airlineBean) {
		this.airlineBean = airlineBean;
	}

	/**
	 * Sets the destinationAirportBean.
	 * @param destinationAirportBean The destinationAirportBean to set
	 */
	public void setDestinationAirportBean(ReferenceDataBean destinationAirportBean) {
		this.destinationAirportBean = destinationAirportBean;
	}

	/**
	 * Sets the originAirportBean.
	 * @param originAirportBean The originAirportBean to set
	 */
	public void setOriginAirportBean(ReferenceDataBean originAirportBean) {
		this.originAirportBean = originAirportBean;
	}

	/**
	 * Sets the pickupLocationBean.
	 * @param pickupLocationBean The pickupLocationBean to set
	 */
	public void setPickupLocationBean(ReferenceDataBean pickupLocationBean) {
		this.pickupLocationBean = pickupLocationBean;
	}

	/**
	 * Returns the flightOverrideDate.
	 * @return String
	 */
	public String getFlightOverrideDate() {
		return flightOverrideDate;
	}

	/**
	 * Returns the overrideDateTimeInHr.
	 * @return String
	 */
	public String getOverrideDateTimeInHr() {
		return overrideDateTimeInHr;
	}

	/**
	 * Returns the overrideDateTimeInMin.
	 * @return String
	 */
	public String getOverrideDateTimeInMin() {
		return overrideDateTimeInMin;
	}

	/**
	 * Sets the flightOverrideDate.
	 * @param flightOverrideDate The flightOverrideDate to set
	 */
	public void setFlightOverrideDate(String flightOverrideDate) {
		this.flightOverrideDate = flightOverrideDate;
	}

	/**
	 * Sets the overrideDateTimeInHr.
	 * @param overrideDateTimeInHr The overrideDateTimeInHr to set
	 */
	public void setOverrideDateTimeInHr(String overrideDateTimeInHr) {
		this.overrideDateTimeInHr = overrideDateTimeInHr;
	}

	/**
	 * Sets the overrideDateTimeInMin.
	 * @param overrideDateTimeInMin The overrideDateTimeInMin to set
	 */
	public void setOverrideDateTimeInMin(String overrideDateTimeInMin) {
		this.overrideDateTimeInMin = overrideDateTimeInMin;
	}

	/**
	 * Returns the isFlightCancelled.
	 * @return boolean
	 */
	public boolean getIsFlightCancelled() {
		return isFlightCancelled;
	}

	/**
	 * Sets the isFlightCancelled.
	 * @param isFlightCancelled The isFlightCancelled to set
	 */
	public void setIsFlightCancelled(boolean isFlightCancelled) {
		this.isFlightCancelled = isFlightCancelled;
	}

	/**
	 * Returns the oldFlightDate.
	 * @return String
	 */
	public String getOldFlightDate() {
		return oldFlightDate;
	}

	/**
	 * Sets the oldFlightDate.
	 * @param oldFlightDate The oldFlightDate to set
	 */
	public void setOldFlightDate(String oldFlightDate) {
		this.oldFlightDate = oldFlightDate;
	}

	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */
	/**
	 * @return
	 */
	public boolean getIsInternational() {
		return isInternational;
	}

	/**
	 * @param b
	 */
	public void setIsInternational(boolean isInternational) {
		this.isInternational = isInternational;
	}

	/**
	 * @return
	 */
	

	/**
	 * @return
	 */
	public String getTravelType() {
		return travelType;
	}

	/**
	 * @param string
	 */
	public void setTravelType(String string) {
		travelType = string;
	}
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

	/**
	 * @return
	 */
	/* Added on 08th June 2012 - starts 
		 *  Vessel field in create/maintain flight page
		 * */
//	added for CA#290863 by vignesh starts here
	public boolean getisVesselMode() {
		return isVesselMode;
	}

	/**
	 * @param b
	 */
	public void setIsVesselMode(boolean b) {
		isVesselMode = b;
	}
	
	public boolean isVesselMode()
	{
		return isVesselMode;
	}
	/**
		 * @return
		 */
		public String getVesselName() {
			return vesselName;
		}

		/**
		 * @param string
		 */
		public void setVesselName(String string) {
			vesselName = string;
		}
	/* Added on 08th June 2012 - ends 
		 *  Vessel field in create/maintain flight page
		 * */
//	added for CA#290863 by vignesh starts here
	

}
