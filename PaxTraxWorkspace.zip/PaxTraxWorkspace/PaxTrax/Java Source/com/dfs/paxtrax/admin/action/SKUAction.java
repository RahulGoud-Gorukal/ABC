package com.dfs.paxtrax.admin.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.actionform.SKUForm;
import com.dfs.paxtrax.admin.exception.SkuException;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.service.SKUDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.admin.valueobject.SKUBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
 * This is action class which perform create, search and edit SKU details
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 19/04/2004	Yuvarani    	Created   
 */

public class SKUAction extends PaxTraxAction
{

	/**
	 *  Performs create, search and modify SKU details
	 *
	 * @param mapping  Action mapping
	 * @param form     Action form
	 * @param request  HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException when there is a problem in save.
	 */
	public ActionForward saveSKUDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUAction::saveSKUDetails::Begin");
		SKUForm skuform = (SKUForm) form;
		SKUDelegate skudelegate = new SKUDelegate();
		SKUBean skubean = skuform.getSkuBean();
		String forward = null;
		request.setAttribute(
			PaxTraxConstants.ITEM_NUMBER_SKIP,
			PaxTraxConstants.FALSE);
		String disableText = skuform.getDisableText();
		String disableSizeText = skuform.getDisableSizeText();
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute(PaxTraxConstants.USER_ID);
		
		if (disableText.equals(PaxTraxConstants.YES))
		{
			skubean.setHarmonizedCode("");
			skubean.setTaxType("");
			skubean.setSize(0);
			skubean.setAlcoholStrength(0);
		}
		
		if (disableSizeText.equals(PaxTraxConstants.YES))
		{
			skubean.setSize(0);
			skubean.setAlcoholStrength(0);
		}

		ArrayList deletedUpc = skubean.getDeletedUpc();
		String[] upc = skubean.getUpcCodeList();

		if (deletedUpc != null)
		{
			for (int i = 0;i < upc.length;i++)
			{
				String upcElement = upc[i];
				if (deletedUpc.contains(upcElement))				
				{
					deletedUpc.remove(upcElement);
				}
			}

		}
		skubean.setDeletedUpc(deletedUpc);
		
		try
		{
			String[] upcReturn = skudelegate.saveSKUDetails(skubean, userId);
			if (upcReturn[0] != null)
			{
				request.setAttribute(PaxTraxConstants.UPC_RETURN, upcReturn[0]);
				request.setAttribute(PaxTraxConstants.SKU_NUMBER,upcReturn[1]);
				request.setAttribute(
					PaxTraxConstants.SKU_APPEND,
					PaxTraxConstants.SKU_APPEND);
				skuform.setSkuBean(skubean);
				forward = PaxTraxConstants.MAINTAIN_SKU_PAGE;
			}
			else
			{
				skudelegate.sendEmergencySku(skubean);
				String dutyType = skubean.getDutyType();
				if (dutyType.equals("1"))
				{
					skubean.setDutyType("Duty Free");
				}
				else
				{
					skubean.setDutyType("Duty Paid");
				}
/*				ArrayList dutyTypes = skuform.getDutyTypes();
				ReferenceDataBean referencedataBean = null;
				if (dutyTypes != null)
				{
					for (int i = 0; i < dutyTypes.size(); i++)
					{
						referencedataBean =
							(ReferenceDataBean) dutyTypes.get(i);
						if (referencedataBean
								.getCodeId()
								.equals(skubean.getDutyType()))
						{
							skubean.setDutyType(
								referencedataBean.getCodeValue());
						}
					}
				}*/
				forward = PaxTraxConstants.VIEW_SKU_PAGE;
			}
		}
		catch (SkuException skuexception)
		{
			PaxTraxLog.logError(skuexception.getMessage());
			request.setAttribute(PaxTraxConstants.ERROR_CODE,"" + 
											skuexception.getErrorCode());
			skuform.setSkuBean(skubean);
			forward = PaxTraxConstants.MAINTAIN_SKU_PAGE;
		}
		
		PaxTraxLog.logDebug("PaxTrax::SKUAction::saveSKUDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * Obtains the value for dutytypes and location and 
	 * forwards to Maintain SKU page
	 *
	 * @param mapping  Action mapping
	 * @param form     Action form
	 * @param request  HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException when there is a problem in loading.
	 */
	public ActionForward maintainSKUPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUAction::maintainSKUPage::Begin");
		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,
												PaxTraxConstants.ADMIN);
		SKUForm skuform = (SKUForm) form;
		SKUBean skubean = new SKUBean();
		SKUDelegate skudelegate = new SKUDelegate();
		String[] upcCode = new String[0];
		skubean.setUpcCodeList(upcCode);

		ArrayList locationList = skudelegate.loadSkuPage();
/*		ReferenceDataDelegate referenceData = new ReferenceDataDelegate();
		ArrayList dutytypes =
			referenceData.loadReferenceData(PaxTraxConstants.DUTY_TYPE);*/
		skuform.setSkuBean(skubean);
		skuform.setLocationList(locationList);
/*		skuform.setDutyTypes(dutytypes);*/
		request.setAttribute(
			PaxTraxConstants.INITIAL_STATUS,
			PaxTraxConstants.INITIAL_STATUS);
			
		PaxTraxLog.logDebug("PaxTrax::SKUAction::maintainSKUPage::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_SKU_PAGE);
	}

	/**
	 * Gets LocationDetails.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward getLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUAction::getLocationDetails::Begin");
		SKUForm skuform = (SKUForm) form;
		SKUBean skubean = skuform.getSkuBean();
		SKUDelegate skudelegate = new SKUDelegate();
		skubean = skudelegate.getLocationDetails(skubean);
		if (skubean.getSkuLocationList() != null && skubean.
											getSkuLocationList().size() != 0)
		{
			request.setAttribute(PaxTraxConstants.OPERATION,
														PaxTraxConstants.TRUE);
		}
		request.setAttribute(
			PaxTraxConstants.ITEM_NUMBER_SKIP,
			PaxTraxConstants.FALSE);

		if (skubean.getUpcCodeList() == null)
		{
			String[] upcList = new String[0];
			skubean.setUpcCodeList(upcList);
		}
		skuform.setSkuBean(skubean);

		PaxTraxLog.logDebug("PaxTrax::SKUAction::getLocationDetails::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_SKU_PAGE);
	}

	public ActionForward popSkuList(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		return mapping.findForward(PaxTraxConstants.SKU_LOOKUP);
	}
	
	/**
	 * Method changeLanguage
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward ActionForward
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SKUAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.
													CHANGE_LANGUAGE_COUNTRY);
		String forward = null;
		String upc = request.getParameter("upc");
		String errorCode = request.getParameter("erc");
		String sku = request.getParameter("sku");
		
		if (language != null && country != null)
		{
		super.changeLanguage(request, language, country);
		}
		else
		{
			forward = PaxTraxConstants.SYSTEM_ERROR;					
		}
		
		HttpSession session = request.getSession();
		String page = (String)session.getAttribute(PaxTraxConstants.PAGE);
		String item = null;
		String location = null;
		if (page.equals(PaxTraxConstants.MAINTAIN_SKU_JSP))
		{
			SKUForm skuForm = (SKUForm)form;
			SKUBean skuBean = skuForm.getSkuBean();
			if (!skuBean.getItemNumber().equals(""))
			{
				try
				{
					int y = Integer.parseInt(skuBean.getItemNumber());
					if (skuForm.getItemCheck().equals("submit"))
					{
					request.setAttribute(PaxTraxConstants.ITEM_NUMBER_SKIP,
												PaxTraxConstants.FALSE);
					}
					else
					{
						location = skuBean.getSellingLocation();
						item = skuBean.getItemNumber();
						skuBean = null;
						skuBean = new SKUBean();
						skuBean.setSellingLocation(location);
						skuBean.setItemNumber(item);
						skuBean.setUpcCodeList(new String[0]);
						skuForm.setSkuBean(skuBean);
					}
				}
				catch (NumberFormatException number)
				{
				location = skuBean.getSellingLocation();
				item = skuBean.getItemNumber();
				skuBean = null;
				skuBean = new SKUBean();
				skuBean.setSellingLocation(location);
				skuBean.setItemNumber(item);
				skuBean.setUpcCodeList(new String[0]);
				skuForm.setSkuBean(skuBean);
				}
			}
			else
			{
				request.setAttribute(PaxTraxConstants.INITIAL_STATUS,
											PaxTraxConstants.INITIAL_STATUS);
				location = skuBean.getSellingLocation();
				skuBean = null;
				skuBean = new SKUBean();
				skuBean.setSellingLocation(location);
				skuBean.setUpcCodeList(new String[0]);
				skuForm.setSkuBean(skuBean);
			}
			if (!upc.equals("null"))
			{
				request.setAttribute(PaxTraxConstants.UPC_RETURN, upc);
				request.setAttribute(PaxTraxConstants.SKU_NUMBER,sku);
				request.setAttribute(
					PaxTraxConstants.SKU_APPEND,
					PaxTraxConstants.SKU_APPEND);
			}
			if (!errorCode.equals("-1"))
			{
				request.setAttribute(PaxTraxConstants.ERROR_CODE,errorCode);
			}
			forward = PaxTraxConstants.MAINTAIN_SKU_PAGE;
		}
		else
		{
			forward = PaxTraxConstants.VIEW_SKU_PAGE;
		}
		PaxTraxLog.logDebug("PaxTrax::SKUAction::changeLanguage::End");
		return mapping.findForward(forward);
	}

}
