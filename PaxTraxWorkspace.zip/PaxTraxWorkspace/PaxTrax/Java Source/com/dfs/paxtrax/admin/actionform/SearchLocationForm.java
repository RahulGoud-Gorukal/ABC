package com.dfs.paxtrax.admin.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * This is action form which contains search attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE 			USER 			COMMENTS
 * 22/03/2004	Joseph Oommen A	    Created   
*/

public class SearchLocationForm extends PaxTraxActionForm
{

	/**
	 * LocationBean object locationBeanId
	 */
	private LocationBean locationBeanId = null;

	/**
	 * Collection of LocationBeans
	 */
	private ArrayList locationCollection = null;

	/**
	 * Collection of locationTypeHide
	 */
	private String locationTypeHide = null;
	/**
	 * Set locationCollection 
	 * @param ArrayList locationCollection 
	 */
	public void setLocationCollection(ArrayList locationCollection)
	{
		this.locationCollection = locationCollection;
	}

	/**
	 * Gets locationCollection 
	 * @return ArrayList - locationCollection
	 */
	public ArrayList getLocationCollection()
	{
		return locationCollection;
	}

	/**
	 * Set locationBean 
	 * @param LocationBean locationBean 
	 */
	public void setLocationBeanId(LocationBean locationBeanId)
	{
		this.locationBeanId = locationBeanId;
	}

	/**
	 * Gets locationBean 
	 * @return LocationBean - locationBean
	 */
	public LocationBean getLocationBeanId()
	{
		return locationBeanId;
	}
	/**
	 * Returns the locationTypeHide.
	 * @return String
	 */
	public String getLocationTypeHide()
	{
		return locationTypeHide;
	}

	/**
	 * Sets the locationTypeHide.
	 * @param locationTypeHide The locationTypeHide to set
	 */
	public void setLocationTypeHide(String locationTypeHide)
	{
		this.locationTypeHide = locationTypeHide;
	}

}