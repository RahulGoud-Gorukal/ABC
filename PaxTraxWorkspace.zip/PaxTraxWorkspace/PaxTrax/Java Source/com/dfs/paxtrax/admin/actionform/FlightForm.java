package com.dfs.paxtrax.admin.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/03/2004	Sundarrajan.K.	Created   
 */


/**
   This is the action form that holds flight attributes
 */
public class FlightForm extends PaxTraxActionForm {
	
   
   
   /** flightBean to get all the attributes of flight
    */ 	   
   FlightBean flightBean = null;       
   
	/**
       List of airline codes
     */
	private ArrayList airlineCodes = null;
    /**
       List of airports
     */
    private ArrayList airports = null;
    
	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

    private ArrayList travelTypes = null;    
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */
    
   
   /** flightTypes list of flight types available
    */ 	   
   private ArrayList flightTypes = null;
   
   /**
      Hours ArrayList
   */   
   private ArrayList hours = null;
   
   /**
      Minutes ArrayList
   */
   private ArrayList minutes = null;
   
   /**
    * pickup locations
    */
	private ArrayList pickupLocations = null;
	
    /**
       Returns flight bean
       @return ArrayList
     */
    public FlightBean getFlightBean() {
    	return flightBean;
    }
    
    /**
       Sets flight bean
       @param flightBean The flightBean to set
     */
    public void setFlightBean(FlightBean flightBean) {
    	this.flightBean = flightBean;
    }
    
	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes() {
		return airlineCodes;
	}

	/**
	 * Returns the flightTypes.
	 * @return ArrayList
	 */
	public ArrayList getFlightTypes() {
		return flightTypes;
	}
	
	/**
	 * Returns the pickupLocations.
	 * @return ArrayList
	 */
	public ArrayList getPickupLocations() {
		return pickupLocations;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes) {
		this.airlineCodes = airlineCodes;
	}

	/**
	 * Sets the flightTypes.
	 * @param flightTypes The flightTypes to set
	 */
	public void setFlightTypes(ArrayList flightTypes) {
		this.flightTypes = flightTypes;
	}
	
	/**
	 * Sets the pickupLocations.
	 * @param pickupLocations The pickupLocations to set
	 */
	public void setPickupLocations(ArrayList pickupLocations) {
		this.pickupLocations = pickupLocations;
	}

	/**
	 * Returns the hours.
	 * @return ArrayList
	 */
	public ArrayList getHours() {
		return hours;
	}
	
	/**
	 * Returns the minutes.
	 * @return ArrayList
	 */
	public ArrayList getMinutes() {
		return minutes;
	}
	
	/**
	 * Sets the hours.
	 * @param hours The hours to set
	 */
	public void setHours(ArrayList hours) {
		this.hours = hours;
	}
	
	/**
	 * Sets the minutes.
	 * @param minutes The minutes to set
	 */
	public void setMinutes(ArrayList minutes) {
		this.minutes = minutes;
	}

	/**
	 * Returns the airports.
	 * @return ArrayList
	 */
	public ArrayList getAirports() {
		return airports;
	}

	/**
	 * Sets the airports.
	 * @param airports The airports to set
	 */
	public void setAirports(ArrayList airports) {
		this.airports = airports;
	}
	
	
	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

	/**
	 * @return
	 */
	public ArrayList getTravelTypes() {
		return travelTypes;
	}

	/**
	 * @param list
	 */
	public void setTravelTypes(ArrayList list) {
		travelTypes = list;
	}
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

}
