package com.dfs.paxtrax.admin.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.business.SKUBO;
import com.dfs.paxtrax.admin.business.SKUBOHome;
import com.dfs.paxtrax.admin.exception.SkuException;
import com.dfs.paxtrax.admin.valueobject.SKUBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * This is delegate class which performs jndi lookup and act as a point of
 * entry for business layer
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 20/04/2004	Yuvarani    	Created   
 */

public class SKUDelegate
{

	//Holds service locator instance
	private ServiceLocator locator = null;

	//Holds skubo home
	private SKUBOHome home = null;
	
	//Holds skubo
	private SKUBO remote = null;

	/**
	 * Constructor for this class
	 */
	public SKUDelegate()
	{
	}

	/**
	 * Method jndiCall.
	 * @throws PaxTraxSystemException
	 */
	private void jndiCall() throws PaxTraxSystemException
	{
		try
		{
			locator = ServiceLocator.getInstance();
			Object object =
				locator.getEJBHome(PaxTraxConstants.SKU_BO_BEAN_JNDI);
			home = (SKUBOHome) PortableRemoteObject.narrow(object,
					SKUBOHome.class);
		}
		catch (NamingException namingException)
		{
			throw new PaxTraxSystemException(namingException);
		}
		if (home == null)
		{
			throw new PaxTraxSystemException(
				PaxTraxConstants.SKU_BO_HOME_NOT_FOUND);
		}
		try
		{
			remote = home.create();
		}
		catch (CreateException createException)
		{
			throw new PaxTraxSystemException(createException);
		}
		catch (RemoteException remoteException)
		{
			throw new PaxTraxSystemException(remoteException);
		}
	}

	/**
	 * Saves SKU details by delegating request manager bean.
	 * @param SKUBean skuBean
	 * @throws PaxTraxSystemException if there is problem in saving SKU details
	 */
	public String[] saveSKUDetails(SKUBean skuBean,String userId) 
		throws PaxTraxSystemException,SkuException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::saveSKUDetails::Begin");
		String[] upcReturn = null;
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			upcReturn = remote.saveSKUDetails(skuBean,userId);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::saveSKUDetails::End");
		return upcReturn;
	}

	/**
	 * loads SKU details by delegating request manager bean.
	 * @throws PaxTraxSystemException if there is problem in loading 
	 * SKU details
	 */
	public ArrayList loadSkuPage() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::loadSkuPage::Begin");
		ArrayList locationList = null;
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			locationList = remote.loadSkuPage();

		}
		catch (RemoteException e)
		{
			throw new PaxTraxSystemException(e);
		}
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::loadSkuPage::End");
		return locationList;
	}
	
	/**
	 * Method getLocationDetails.
	 * @param skubean
	 * @return SKUBean
	 * @throws PaxTraxSystemException
	 */
	public SKUBean getLocationDetails(SKUBean skubean) 
			throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::getLocationDetails::Begin");
		SKUBean skuBean = null;
         if (home == null)
         {
         	jndiCall();
         }   
         try
         {   		
         skuBean = remote.getLocationDetails(skubean);
         }
         catch (RemoteException re)
         {
         	throw new PaxTraxSystemException(re);
         }
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::getLocationDetails::End");
        return skuBean;
	}

	/**
	 * Sends the details of Sku to Triversity
	 * @param SKUBean skuBean
	 * @throws PaxTraxSystemException when there is any problem in sending
	 * the details
	 */
	public void sendEmergencySku(SKUBean skuBean)
			throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::sendEmergencySku::Begin");
         if (home == null)
         {
         	jndiCall();
         }   
         try
         {   		
         remote.sendEmergencySku(skuBean);
         }
         catch (RemoteException re)
         {
         	throw new PaxTraxSystemException(re);
         }
		PaxTraxLog.logDebug("PaxTrax::SKUDelegate::sendEmergencySku::End");
		
	}

}