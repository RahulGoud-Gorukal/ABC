package com.dfs.paxtrax.customs.exception;

import com.dfs.paxtrax.common.exception.PaxTraxException;

/**
 * @author Pankaj Dubey
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class BankRecordNotFoundException extends PaxTraxException {

	/**
	 * Constructor for BankRecordNotFoundException.
	 * @param errorCode
	 */
	public BankRecordNotFoundException(int errorCode) {
		super(errorCode);
	}

	/**
	 * Constructor for BankRecordNotFoundException.
	 * @param errorCode
	 * @param actualException
	 */
	public BankRecordNotFoundException(
		int errorCode,
		Exception actualException) {
		super(errorCode, actualException);
	}

}
