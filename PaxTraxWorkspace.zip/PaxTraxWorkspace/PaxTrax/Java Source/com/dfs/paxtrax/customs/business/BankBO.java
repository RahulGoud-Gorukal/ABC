// Source file: com/dfs/paxtrax/customs/business/BankBO.java

package com.dfs.paxtrax.customs.business;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.customs.exception.BankRecordNotFoundException;
import com.dfs.paxtrax.customs.valueobject.BankDetailsVO;

public interface BankBO extends EJBObject{

    /**
       @roseuid 404CCBE1003F
     */
    public BankDetailsVO getBankDeatils()throws RemoteException,PaxTraxSystemException, BankRecordNotFoundException;;

    /**
       @roseuid 404CCBE1003F
     */
    public boolean saveBankDeatils( BankDetailsVO banksDetailsVO)throws RemoteException,PaxTraxSystemException;
    
    public BankDetailsVO postCodeLookup(BankDetailsVO bankBean)throws RemoteException, PaxTraxSystemException;
}
