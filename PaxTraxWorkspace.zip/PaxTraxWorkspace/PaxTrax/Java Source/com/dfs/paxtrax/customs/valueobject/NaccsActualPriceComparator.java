package com.dfs.paxtrax.customs.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.Comparator;


/**
 * Comparator class for sorting based on naccs unit actual price.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 31/08/2004	P.C. Sathish	Created 
 */
public class NaccsActualPriceComparator implements Comparator {
	public int compare(Object o1, Object o2) {			
		ItemBean item1 = (ItemBean) o1;			
		ItemBean item2 = (ItemBean) o2;
		if (item1.getNaccsActualUnitPrice() > item2.getNaccsActualUnitPrice()) {		
			return 1;
		} else if (item1.getNaccsActualUnitPrice() < item2.getNaccsActualUnitPrice()) {
			return -1;
		} else {
			return 0;
		}			
	}
}
