package com.dfs.paxtrax.customs.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.customs.valueobject.NACCSFileSearchBean;

/**
 * This is the actionform that will hold the details of file generation search
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Vaikundamurthy	Created   
 */


public class NACCSFileGenerationForm extends PaxTraxActionForm 
{
	//Holds NACCS file search bean
	private NACCSFileSearchBean naccsFileSearchBean = null;
	
	//Holds list of airline codes
	private ArrayList airlineCodes = null;
	
	//Holds departure hour time
	private ArrayList hours = null;
	
	//Holds departure minute time
	private ArrayList minutes = null;
	
	//Holds search results
	private ArrayList flightCollection = null;
	
	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes()
	{
		return airlineCodes;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes)
	{
		this.airlineCodes = airlineCodes;
	}

	
	/**
	 * Returns the hours.
	 * @return ArrayList
	 */
	public ArrayList getHours()
	{
		return hours;
	}

	/**
	 * Returns the minutes.
	 * @return ArrayList
	 */
	public ArrayList getMinutes()
	{
		return minutes;
	}

	/**
	 * Sets the hours.
	 * @param hours The hours to set
	 */
	public void setHours(ArrayList hours)
	{
		this.hours = hours;
	}

	/**
	 * Sets the minutes.
	 * @param minutes The minutes to set
	 */
	public void setMinutes(ArrayList minutes)
	{
		this.minutes = minutes;
	}

	/**
	 * Returns the naccsFileSearchBean.
	 * @return NACCSFileSearchBean
	 */
	public NACCSFileSearchBean getNaccsFileSearchBean()
	{
		return naccsFileSearchBean;
	}

	/**
	 * Sets the naccsFileSearchBean.
	 * @param naccsFileSearchBean The naccsFileSearchBean to set
	 */
	public void setNaccsFileSearchBean(NACCSFileSearchBean naccsFileSearchBean)
	{
		this.naccsFileSearchBean = naccsFileSearchBean;
	}

	/**
	 * Returns the flightCollection.
	 * @return ArrayList
	 */
	public ArrayList getFlightCollection()
	{
		return flightCollection;
	}

	/**
	 * Sets the flightCollection.
	 * @param flightCollection The flightCollection to set
	 */
	public void setFlightCollection(ArrayList flightCollection)
	{
		this.flightCollection = flightCollection;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		if(flightCollection!=null)
		{
			if(flightCollection.size()>0)
			{
				for(int k=0; k<flightCollection.size();k++)
				{
					NACCSFileSearchBean naccsBean = (NACCSFileSearchBean)flightCollection.get(k);
					naccsBean.setChecked("N");
					flightCollection.set(k,naccsBean);
				}				
			} 	
		}
	}	
}
