package com.dfs.paxtrax.customs.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * This is a value object used by Nabco report.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 03/09/2004	P.C.Sathish		Created
 */
public class NabcoReportBean extends PaxTraxValueObject {
	private String storeName;
	private int sellingLocation;
	private String departureDate;
	private ArrayList nabcoStoreBeanList;
	private int nationalConsumptionTaxSalesPercent;
	private int nationalConsumptionTaxPercent;
	private int localConsumptionTaxPercent;
	private long sku=0;
	private int qty=0;
	private double naccsUnitPrice=0;
	private String tariffIdentifier=null;
	private int location=0;
	private int terminalNumber=0;	
	private String fileName=null;
	private int divisionNO=0;
	private int size=0;
//	Modified for CR 37 changes on Oct 03, 2007 
	private float alcoholStrength=0.0f;
	private String taxType=null;
	private long harmonizeCode =0;
	private String leasedVendor="F";
	private String leasedVendorName;
	
	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Returns the fileName.
	 * @return String
	 */
	public String getFileName()
	{
		return fileName;
	}

	/**
	 * Returns the localConsumptionTaxPercent.
	 * @return int
	 */
	public int getLocalConsumptionTaxPercent()
	{
		return localConsumptionTaxPercent;
	}

	/**
	 * Returns the location.
	 * @return int
	 */
	public int getLocation()
	{
		return location;
	}

	/**
	 * Returns the nabcoStoreBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNabcoStoreBeanList()
	{
		return nabcoStoreBeanList;
	}

	/**
	 * Returns the naccsUnitPrice.
	 * @return double
	 */
	public double getNaccsUnitPrice()
	{
		return naccsUnitPrice;
	}

	/**
	 * Returns the nationalConsumptionTaxPercent.
	 * @return int
	 */
	public int getNationalConsumptionTaxPercent()
	{
		return nationalConsumptionTaxPercent;
	}

	/**
	 * Returns the nationalConsumptionTaxSalesPercent.
	 * @return int
	 */
	public int getNationalConsumptionTaxSalesPercent()
	{
		return nationalConsumptionTaxSalesPercent;
	}

	/**
	 * Returns the qty.
	 * @return int
	 */
	public int getQty()
	{
		return qty;
	}

	/**
	 * Returns the sellingLocation.
	 * @return int
	 */
	public int getSellingLocation()
	{
		return sellingLocation;
	}

	/**
	 * Returns the sku.
	 * @return long
	 */
	public long getSku()
	{
		return sku;
	}

	/**
	 * Returns the storeName.
	 * @return String
	 */
	public String getStoreName()
	{
		return storeName;
	}

	/**
	 * Returns the tariffIdentifier.
	 * @return String
	 */
	public String getTariffIdentifier()
	{
		return tariffIdentifier;
	}

	/**
	 * Returns the terminalNumber.
	 * @return int
	 */
	public int getTerminalNumber()
	{
		return terminalNumber;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the fileName.
	 * @param fileName The fileName to set
	 */
	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	/**
	 * Sets the localConsumptionTaxPercent.
	 * @param localConsumptionTaxPercent The localConsumptionTaxPercent to set
	 */
	public void setLocalConsumptionTaxPercent(int localConsumptionTaxPercent)
	{
		this.localConsumptionTaxPercent = localConsumptionTaxPercent;
	}

	/**
	 * Sets the location.
	 * @param location The location to set
	 */
	public void setLocation(int location)
	{
		this.location = location;
	}

	/**
	 * Sets the nabcoStoreBeanList.
	 * @param nabcoStoreBeanList The nabcoStoreBeanList to set
	 */
	public void setNabcoStoreBeanList(ArrayList nabcoStoreBeanList)
	{
		this.nabcoStoreBeanList = nabcoStoreBeanList;
	}

	/**
	 * Sets the naccsUnitPrice.
	 * @param naccsUnitPrice The naccsUnitPrice to set
	 */
	public void setNaccsUnitPrice(double naccsUnitPrice)
	{
		this.naccsUnitPrice = naccsUnitPrice;
	}

	/**
	 * Sets the nationalConsumptionTaxPercent.
	 * @param nationalConsumptionTaxPercent The nationalConsumptionTaxPercent to set
	 */
	public void setNationalConsumptionTaxPercent(int nationalConsumptionTaxPercent)
	{
		this.nationalConsumptionTaxPercent = nationalConsumptionTaxPercent;
	}

	/**
	 * Sets the nationalConsumptionTaxSalesPercent.
	 * @param nationalConsumptionTaxSalesPercent The nationalConsumptionTaxSalesPercent to set
	 */
	public void setNationalConsumptionTaxSalesPercent(int nationalConsumptionTaxSalesPercent)
	{
		this.nationalConsumptionTaxSalesPercent = nationalConsumptionTaxSalesPercent;
	}

	/**
	 * Sets the qty.
	 * @param qty The qty to set
	 */
	public void setQty(int qty)
	{
		this.qty = qty;
	}

	/**
	 * Sets the sellingLocation.
	 * @param sellingLocation The sellingLocation to set
	 */
	public void setSellingLocation(int sellingLocation)
	{
		this.sellingLocation = sellingLocation;
	}

	/**
	 * Sets the sku.
	 * @param sku The sku to set
	 */
	public void setSku(long sku)
	{
		this.sku = sku;
	}

	/**
	 * Sets the storeName.
	 * @param storeName The storeName to set
	 */
	public void setStoreName(String storeName)
	{
		this.storeName = storeName;
	}

	/**
	 * Sets the tariffIdentifier.
	 * @param tariffIdentifier The tariffIdentifier to set
	 */
	public void setTariffIdentifier(String tariffIdentifier)
	{
		this.tariffIdentifier = tariffIdentifier;
	}

	/**
	 * Sets the terminalNumber.
	 * @param terminalNumber The terminalNumber to set
	 */
	public void setTerminalNumber(int terminalNumber)
	{
		this.terminalNumber = terminalNumber;
	}


	/**
	 * Returns the divisionNO.
	 * @return int
	 */
	public int getDivisionNO()
	{
		return divisionNO;
	}

	/**
	 * Returns the harmonizeCode.
	 * @return long
	 */
	public long getHarmonizeCode()
	{
		return harmonizeCode;
	}

	/**
	 * Returns the size.
	 * @return int
	 */
	public int getSize()
	{
		return size;
	}

	/**
	 * Returns the taxType.
	 * @return String
	 */
	public String getTaxType()
	{
		return taxType;
	}

	/**
	 * Sets the divisionNO.
	 * @param divisionNO The divisionNO to set
	 */
	public void setDivisionNO(int divisionNO)
	{
		this.divisionNO = divisionNO;
	}

	/**
	 * Sets the harmonizeCode.
	 * @param harmonizeCode The harmonizeCode to set
	 */
	public void setHarmonizeCode(long harmonizeCode)
	{
		this.harmonizeCode = harmonizeCode;
	}

	/**
	 * Sets the size.
	 * @param size The size to set
	 */
	public void setSize(int size)
	{
		this.size = size;
	}

	/**
	 * Sets the taxType.
	 * @param taxType The taxType to set
	 */
	public void setTaxType(String taxType)
	{
		this.taxType = taxType;
	}

	/**
	 * Returns the leasedVendor.
	 * @return String
	 */
	public String getLeasedVendor()
	{
		return leasedVendor;
	}

	/**
	 * Sets the leasedVendor.
	 * @param leasedVendor The leasedVendor to set
	 */
	public void setLeasedVendor(String leasedVendor)
	{
		this.leasedVendor = leasedVendor;
	}

	/**
	 * Returns the leasedVendorName.
	 * @return String
	 */
	public String getLeasedVendorName()
	{
		return leasedVendorName;
	}

	/**
	 * Sets the leasedVendorName.
	 * @param leasedVendorName The leasedVendorName to set
	 */
	public void setLeasedVendorName(String leasedVendorName)
	{
		this.leasedVendorName = leasedVendorName;
	}

	/**
	 * @return
	 */
	public float getAlcoholStrength() {
		return alcoholStrength;
	}

	/**
	 * @param f
	 */
	public void setAlcoholStrength(float f) {
		alcoholStrength = f;
	}

	}
