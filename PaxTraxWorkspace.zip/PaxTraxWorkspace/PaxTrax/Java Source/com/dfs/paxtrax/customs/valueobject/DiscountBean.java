package com.dfs.paxtrax.customs.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * ValueObject class holds discount details information.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 17/06/2004	P.C.Sathish		Created
 */
public class DiscountBean extends PaxTraxValueObject {
	private int discountCode;
	private double discountAmount;
	/**
	 * Returns the discountAmount.
	 * @return long
	 */
	public double getDiscountAmount() {
		return discountAmount;
	}

	/**
	 * Returns the discountCode.
	 * @return int
	 */
	public int getDiscountCode() {
		return discountCode;
	}

	/**
	 * Sets the discountAmount.
	 * @param discountAmount The discountAmount to set
	 */
	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	/**
	 * Sets the discountCode.
	 * @param discountCode The discountCode to set
	 */
	public void setDiscountCode(int discountCode) {
		this.discountCode = discountCode;
	}

}
