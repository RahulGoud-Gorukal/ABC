package com.dfs.paxtrax.customs.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class NACCSSearchBean extends PaxTraxValueObject {
    // NACCSSubmission
	private boolean nonAcknowledged=false;
    private String fromDate=null;
    private String toDate=null;
    private String airlineCode=null;
    private String flightNo = null;   

	// NACCSSummary 
    private boolean nonReconciled=false;
    private String fromDepDate=null;
    private String toDepDate=null;
    private String departureDate=null;
    private String fromPAXNo;
    private String toPAXNo;
    private ReferenceDataBean airlineBean=null;
    
    /**
	 * Returns the flightNo.
	 * @return String
	 */
	public String getFlightNo()
	{
		return flightNo;
	}


	/**
	 * Sets the flightNo.
	 * @param flightNo The flightNo to set
	 */
	public void setFlightNo(String flightNo)
	{
		this.flightNo = flightNo;
	}

	/**
	 * Returns the fromDepDate.
	 * @return String
	 */
	public String getFromDepDate()
	{
		return fromDepDate;
	}

	/**
	 * Returns the nonReconciled.
	 * @return boolean
	 */
	public boolean isNonReconciled()
	{
		return nonReconciled;
	}

	/**
	 * Returns the toDepDate.
	 * @return String
	 */
	public String getToDepDate()
	{
		return toDepDate;
	}

	/**
	 * Sets the fromDepDate.
	 * @param fromDepDate The fromDepDate to set
	 */
	public void setFromDepDate(String fromDepDate)
	{
		this.fromDepDate = fromDepDate;
	}

	/**
	 * Sets the nonReconciled.
	 * @param nonReconciled The nonReconciled to set
	 */
	public void setNonReconciled(boolean nonReconciled)
	{
		this.nonReconciled = nonReconciled;
	}

	/**
	 * Sets the toDepDate.
	 * @param toDepDate The toDepDate to set
	 */
	public void setToDepDate(String toDepDate)
	{
		this.toDepDate = toDepDate;
	}

	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode()
	{
		return airlineCode;
	}

	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate()
	{
		return fromDate;
	}

	/**
	 * Returns the nonAcknowledged.
	 * @return boolean
	 */
	public boolean isNonAcknowledged()
	{
		return nonAcknowledged;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate()
	{
		return toDate;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode)
	{
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate)
	{
		this.fromDate = fromDate;
	}

	/**
	 * Sets the nonAcknowledged.
	 * @param nonAcknowledged The nonAcknowledged to set
	 */
	public void setNonAcknowledged(boolean nonAcknowledged)
	{
		this.nonAcknowledged = nonAcknowledged;
	}

	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate)
	{
		this.toDate = toDate;
	}

	/**
	 * Returns the airlineBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getAirlineBean()
	{
		return airlineBean;
	}

	/**
	 * Sets the airlineBean.
	 * @param airlineBean The airlineBean to set
	 */
	public void setAirlineBean(ReferenceDataBean airlineBean)
	{
		this.airlineBean = airlineBean;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Returns the fromPAXNo.
	 * @return String
	 */
	public String getFromPAXNo() {
		return fromPAXNo;
	}

	/**
	 * Returns the toPAXNo.
	 * @return String
	 */
	public String getToPAXNo() {
		return toPAXNo;
	}

	/**
	 * Sets the fromPAXNo.
	 * @param fromPAXNo The fromPAXNo to set
	 */
	public void setFromPAXNo(String fromPAXNo) {
		this.fromPAXNo = fromPAXNo;
	}

	/**
	 * Sets the toPAXNo.
	 * @param toPAXNo The toPAXNo to set
	 */
	public void setToPAXNo(String toPAXNo) {
		this.toPAXNo = toPAXNo;
	}

}

