package com.dfs.paxtrax.customs.business;

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.exception.NACCSException;
import com.dfs.paxtrax.customs.valueobject.NACCSFileSearchBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.NACCSFileBean;
import com.dfs.paxtrax.customs.valueobject.NaccsParameterBean;
import com.dfs.paxtrax.customs.valueobject.DailyNACCSGenerationBean;

/**
 * Remote interface for Enterprise Bean: NACCSBO
 */
public interface NACCSBO extends javax.ejb.EJBObject
{
	/**
	 * Returns NACCS submission details 
	 * @param naccsSearchBean Search criteria bean
	 * @return ArrayList List of submission details
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in getting details
	 */
	public ArrayList getNaccsSubmissionDetails(NACCSSearchBean naccsSearchBean)
				throws RemoteException,PaxTraxSystemException;
	
	/**
	 * Returns NACCS summary details
	 * @param naccsSearchBean Search criteria bean
	 * @return ArrayList List of summary results
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in getting details
	 * is problem in search
	 */ 			
	public ArrayList getNaccsSummaryDetails(NACCSSearchBean naccsSearchBean)
				throws RemoteException,PaxTraxSystemException;
	
	/**
	 * NACCS entry no upload process
	 * @param alList List of entry numbers
	 * @return boolean Indicates true or false
	 * @throws PaxTraxSystemException This exception is thrown if there
	 * is any problem
	 */
	public boolean naccsEntryNumberUpload(String essrcDir,String esmvDir)
			throws RemoteException,PaxTraxSystemException;
			
			
	/**
	 * Method LTSUpload.
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public boolean LTSUpload() throws RemoteException,PaxTraxSystemException;
	
	
	/**
	 * Returns flight list for the given search criteria.
	 * @param searchBean NACCSFileSearchBean
	 * @return ArrayList List of flight details
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in search
	 */
	public ArrayList searchFlight(NACCSFileSearchBean searchBean)
			 throws RemoteException,PaxTraxSystemException;

	/**
	 * Generates NACCS File for the given flights
	 * @param flightList List of flights for which NACCS File has to be 
	 * generated
	 * @return ArrayList - List of flights for which naccs is generated
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * a problem in generating NACCS File
	 */
	public ArrayList generateNACCSFile(ArrayList flightList) 
		throws RemoteException,PaxTraxSystemException;
	
	/**
	 * Selects all flights for the current date for naccs file generation
	 * @param generationFrequency Frequency at which NACCS file is generated
	 * @return ArrayList List of selected flights
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in retrieving flights
	 */
	public ArrayList generateNACCSForScheduler(int generationFrequency)
		throws RemoteException,PaxTraxSystemException;
		
	/**
	 * Returns FTPConfig parameters
	 * @return FTPConfig Ftp config object
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in getting ftp parameters
	 */
	public FTPConfig getNACCSFTPParameters() 
		throws RemoteException,PaxTraxSystemException;
		
	/**
	 * Updates status for the given pax file
	 * @param fileName Pax file for which transaction status needs to be 
	 * updated
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in updating status
	 */
	public void updateStatus(String fileName)
		throws RemoteException,PaxTraxSystemException;	

	/**
	 * Returns the list of Nabco report beans used to calculate sales before
	 * tax, consumption tax, net sales.
	 * @return ArrayList list of NabcoReportBeans
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in updating status
	 */
	public ArrayList getNabcoReportDetails(String departureDate)
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Returns the list of Naccs Duplicate Pax Result beans 
	 * @return ArrayList list of NACCSDuplicatePaxResultBeans
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in updating status
	 */
	public ArrayList searchDuplicatePaxDetails(NACCSSearchBean naccsSearchBean)
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Method mergePax.
	 * @param naccsSearchBean
	 * @return boolean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public void mergePax(NACCSSearchBean naccsSearchBean)
		throws RemoteException, NACCSException, PaxTraxSystemException;
		
	/**
	 * Method getDutyFreePaidMonthlySummaryDetails.
	 * @param dutyFreePaindMonthlyRptBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getDutyFreePaidMonthlySummaryDetails(String salesMonth)
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Copy Data by invoking BO method.
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in copying data
	 */
	public void ltsuploadCopyData() throws RemoteException, PaxTraxSystemException;	
	
	/**
	 * Check if Pax number exists for the given fileName in naccs file header table.
	 * @param fileName the name of the file extracted from the to_be_sent folder.
	 * @return boolean true or false
	 */
	public boolean checkPaxExists(String fileName) throws RemoteException, PaxTraxSystemException;
	
	
	/**
	 * Returns Naccs parameters
	 * @return NaccsParameterBean
	 * @throws PaxTraxSystemException
	 */
	public NaccsParameterBean getNaccsParameters() throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Method getPostCodeAddress.
	 * @param paxBean
	 * @return NACCSFileBean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public NACCSFileBean getPostCodeAddress(NACCSFileBean paxBean) throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Method getNaccsFileName.
	 * @param paxNo
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getNaccsFileName(String paxNo) throws RemoteException, PaxTraxSystemException;

	/**
	 * Method updateNACCS.
	 * @param naccsList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public void updateNACCS(ArrayList naccsList) throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Method updateTransactions.
	 * @param paxList
	 * @param status
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public void updateTransactions(ArrayList paxList, String status) 
	throws RemoteException, PaxTraxSystemException;

	/* Code added as part of SR 1042 - International DF Sale Enhancement */
	/* Code added on July 21, 2006 */
	/* Scheduled Flight query changed to filter out International Flights */
	//International DF Sale, LTS Import Declaration Number Upload Scheduler
	
	/**
	 * Method sendIntlImportDeclarationNumbersToAS400.
	 * @param 
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public void sendIntlImportDeclarationNumbersToAS400() 
	throws RemoteException, PaxTraxSystemException;
	
	/* Code added on July 21, 2006 ends */
	
//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report
	  /**
		   * Returns getDailyNACCSGenerationDetails
		   * @param naccsSearchBean Search criteria bean
		   * @return DailyNACCSGenerationBean 
		   * @throws PaxTraxSystemException This exception is thrown if there is
		   * any problem in getting details
		   */
		  public DailyNACCSGenerationBean getDailyNACCSGenerationDetails(NACCSSearchBean naccsSearchBean)
					  throws RemoteException,PaxTraxSystemException;
	
	//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report

//	Added on July 28, 2007 for CR 250 changes -- Begin

	/**
	 * To update the naccs file generation status for the flights.
	 * @param flightList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public void updateFlightStatus(ArrayList flightList,String status,String userId) throws RemoteException, PaxTraxSystemException;
   
//	  Added on July 28, 2007 for CR 250 changes -- End

}
