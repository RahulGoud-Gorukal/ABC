package com.dfs.paxtrax.customs.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */
import java.util.ArrayList;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * Form class for Daily NACCS Generation Report.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant -  Sankaranarayanan srinivasan 
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 01/06/2007	Vijay		    Created
 */
public class DailyNACCSGenerationBean extends PaxTraxValueObject{
	
	private NACCSSubmissionResultBean naccsSubmissionResultBean=null;
		private String galleriaSkuCount=null;
		private String airPortSkuCount=null;
		private ArrayList naccsSubmissionResultBeanList=null;		
		/**
		 * Returns the AP sku count
		 * @return AirPortSkuCount
		 */
		public String getAirPortSkuCount() {
			return airPortSkuCount;
		}

		/**
		 * Returns the Galleria sku count
		 * @return galleriaSkuCount
		 */
		public String getGalleriaSkuCount() {
			return galleriaSkuCount;
		}

		/**
		 * Returns the NACCSSubmissionResultBean
		 * @return naccsSubmissionResultBean
		 */
		public NACCSSubmissionResultBean getNaccsSubmissionResultBean() {
			return naccsSubmissionResultBean;
		}

		/**
		 * Sets the AirPortSkuCount
		 * @param string the airportskucount
		 */
		public void setAirPortSkuCount(String string) {
			airPortSkuCount = string;
		}

		/**
		 * Sets the GalleraiaSkuCount
		 * @param string the galleriaSkuCount 
		 */
		public void setGalleriaSkuCount(String string) {
			galleriaSkuCount = string;
		}

		/**
		 * Sets the NACCSSubmissionResultBean
		 * @param bean the naccsSubmissionResultBean
		 */
		public void setNaccsSubmissionResultBean(NACCSSubmissionResultBean bean) {
			naccsSubmissionResultBean = bean;
		}

		/**
		 * Returns the NaccsSubmissionResultBeanList
		 * @return  naccsSubmissionResultBeanList
		 */
		public ArrayList getNaccsSubmissionResultBeanList() {
			return naccsSubmissionResultBeanList;
		}

		/**
		 * Sets the NaccsSubmissionResultBeanList
		 * @param list naccsSubmissionResultBeanList
		 */
		public void setNaccsSubmissionResultBeanList(ArrayList list) {
			naccsSubmissionResultBeanList = list;
		}

}
