package com.dfs.paxtrax.customs.actionform;

import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;


public class NACCSDuplicatePaxReportForm extends PaxTraxActionForm
{	
	private ArrayList naccsDuplicatePaxResultBeanList=null;
	private NACCSSearchBean naccsSearchBean =null;
	private ArrayList airlineCodes =null;
	private String fromPax;
	private String toPax;

	
	/**
	 * Returns the naccsDuplicatePaxResultBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNaccsDuplicatePaxResultBeanList()
	{
		return naccsDuplicatePaxResultBeanList;
	}

	/**
	 * Returns the naccsSearchBean.
	 * @return NACCSSearchBean
	 */
	public NACCSSearchBean getNaccsSearchBean()
	{
		return naccsSearchBean;
	}

	/**
	 * Sets the naccsDuplicatePaxResultBeanList.
	 * @param naccsDuplicatePaxResultBeanList The naccsDuplicatePaxResultBeanList to set
	 */
	public void setNaccsDuplicatePaxResultBeanList(ArrayList naccsDuplicatePaxResultBeanList)
	{
		this.naccsDuplicatePaxResultBeanList = naccsDuplicatePaxResultBeanList;
	}

	/**
	 * Sets the naccsSearchBean.
	 * @param naccsSearchBean The naccsSearchBean to set
	 */
	public void setNaccsSearchBean(NACCSSearchBean naccsSearchBean)
	{
		this.naccsSearchBean = naccsSearchBean;
	}

	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes()
	{
		return airlineCodes;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes)
	{
		this.airlineCodes = airlineCodes;
	}

	/**
	 * Returns the fromPax.
	 * @return String
	 */
	public String getFromPax() {
		return fromPax;
	}

	/**
	 * Returns the toPax.
	 * @return String
	 */
	public String getToPax() {
		return toPax;
	}

	/**
	 * Sets the fromPax.
	 * @param fromPax The fromPax to set
	 */
	public void setFromPax(String fromPax) {
		this.fromPax = fromPax;
	}

	/**
	 * Sets the toPax.
	 * @param toPax The toPax to set
	 */
	public void setToPax(String toPax) {
		this.toPax = toPax;
	}

}
