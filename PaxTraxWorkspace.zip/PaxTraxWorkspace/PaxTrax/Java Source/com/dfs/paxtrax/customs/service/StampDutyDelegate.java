package com.dfs.paxtrax.customs.service;

/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.customs.business.StampDutyBO;
import com.dfs.paxtrax.customs.business.StampDutyBOHome;
import com.dfs.paxtrax.customs.exception.StampDutyException;
import com.dfs.paxtrax.customs.valueobject.StampDutyBean;

/**
* This Delegate  class is used for inserting and updating cage records
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 29/05/2004    Joseph Oommen A Created
*/
public class StampDutyDelegate
{

	/*
	 * Holds service locator instance
	 */
	private ServiceLocator serviceLocator = null;
	/*
	 * Holds the Home interface
	 */
	private StampDutyBOHome stampDutyBOHome = null;
	/*
	 * Hold the remote interface
	 */
	private StampDutyBO stampDutyBO = null;
	/*
	 *Default Construtor for StampDutyDelegate
	 */

	public StampDutyDelegate()
	{
	}

	/*
	 * Jndi look up is performed here
	 */
	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::StampDutyDelegate::jndiCall::Begin");
		try
		{
			PaxTraxLog.logDebug("StampDutyDelegate: jndiCall() : Looking for JNDI PaxTraxConstants.STAMP_DUTY_BO_JNDI" 
									+ PaxTraxConstants.STAMP_DUTY_BO_JNDI);
			serviceLocator = ServiceLocator.getInstance();
			stampDutyBOHome =
				(StampDutyBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						PaxTraxConstants.STAMP_DUTY_BO_JNDI),
					StampDutyBOHome.class);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}
		if (stampDutyBOHome == null)
		{
			throw new PaxTraxSystemException(PaxTraxConstants.STAMP_DUTY_BO_HOME_NOT_FOUND);
		}
		try
		{
			stampDutyBO = stampDutyBOHome.create();
		}
		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::StampDutyDelegate::jndiCall::End");
	}

	/**
	 * Saves details details into the database by 
	 * delegating the request to  the cage  bean. 
	 * @param cageBean CageBean object
	 * @throws PaxTraxSystemException,CageException
	 */
	public ArrayList generateStampDuty(StampDutyBean stampDutyBean)
		throws PaxTraxSystemException, StampDutyException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::StampDutyDelegate::generateStampDuty::Begin");
		ArrayList stampDutyList = null;
		if (stampDutyBOHome == null)
		{
			jndiCall();
		}
		try
		{
		PaxTraxLog.logDebug(
			"***PaxTrax::StampDutyDelegate::generateStampDuty::Before Getting stamp duty list");
			stampDutyList = stampDutyBO.generateStampDuty(stampDutyBean);
		PaxTraxLog.logDebug(
			"***PaxTrax::StampDutyDelegate::generateStampDuty::After Getting stamp duty list");

		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("StampDutyDelegate: generateStampDuty() : Remote Exception happened ", re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::StampDutyDelegate::generateStampDuty::End");
		return stampDutyList;
	}

}
