package com.dfs.paxtrax.customs.action;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.NACCSDuplicatePaxReportForm;
import com.dfs.paxtrax.customs.exception.NACCSException;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;

/**
 * @author 114514
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
/**
 *Action class for NACCSubmission Report 
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 15/10/2004	Karumanchi Hari	Created
 * 27/11/2004	P.C. Sathish	Modified
 */
/**
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class NACCSDuplicatePaxReportAction extends PaxTraxAction
{

	String forward = null;
	/**
	 * Method generateNACCSDuplicatePaxReport.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward generateNACCSDuplicatePaxReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSDuplicatePaxReportAction::generateNACCSDuplicatePaxReport::Begin");
			NACCSDuplicatePaxReportForm naccsDuplicatePaxReportForm = 
				(NACCSDuplicatePaxReportForm) form;

			PaxTraxLog.logDebug("Form Type cast occured");
			ReferenceDataDelegate referenceDataDelegate =
				new ReferenceDataDelegate();
			PaxTraxLog.logDebug("Reference Delegate Declared");
			NACCSSearchBean naccsSearchBean = new NACCSSearchBean();
			PaxTraxLog.logDebug("Naccs Search Bean  Declared ");
			
			/*Code added on 2006-11-27 to set current day date in the departure date field of Duplicate PAX Report*/ 
				Calendar cal = Calendar.getInstance();
				int day = cal.get(Calendar.DATE);
				int month = cal.get(Calendar.MONTH) + 1;
				int year = cal.get(Calendar.YEAR);								
				String currentDate = "" + year + "/" + (month<10 ? "0" + month : "" +
								   month) + "/" + (day<10 ? "0" + day : "" + day);
				naccsSearchBean.setDepartureDate(currentDate);
			/*Code Ends*/

			naccsDuplicatePaxReportForm.setNaccsSearchBean(naccsSearchBean);
			PaxTraxLog.logDebug(
				"NaccsBean assigned to naccsSubmissionReportForm");
			naccsDuplicatePaxReportForm.setAirlineCodes(
				referenceDataDelegate.loadReferenceData(
					PaxTraxConstants.AIRLINE_CODE));
			PaxTraxLog.logDebug(
				"Airloine Code is assigned by calling the delegate method of refence data delegate");
			forward = PaxTraxConstants.NACCS_DUPLICATE_PAX_REPORT_PAGE;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);

		}
		catch (Exception pte)
		{
			PaxTraxLog.logError(
				"Exception Caught - NACCSDuplicatePaxReportAction - generateNACCSDuplicatePaxReport",
				pte);
			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction::generateNACCSDuplicatePaxReport::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method searchNACCSDuplicatePaxDetails.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward searchNACCSDuplicatePaxDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction::searchNACCSDuplicatePaxDetails::Begin");
		try
		{

			int pageNumber = 0;
			ArrayList currentRecords = null;
			ArrayList allRecords = null;
			HttpSession session = request.getSession();
			PaxTraxLog.logDebug("Session is created");
			NACCSDuplicatePaxReportForm naccsDuplicatePaxReportForm = 
				(NACCSDuplicatePaxReportForm) form;
			NACCSSearchBean naccsSearchBean = 
								naccsDuplicatePaxReportForm.getNaccsSearchBean();
			PaxTraxLog.logDebug(
				"NACCSSearchBean  naccsSearchBean is getting from naccsDuplicatePaxReportForm");
			/*searchbeanId.setAirlineCode(
				searchbeanId.getAirlineBean().getCodeId());

			PaxTraxLog.logDebug(
				"NACCSSubmission Report Action the values are AirlineCode "
					+ searchbeanId.getAirlineCode()
					+ "& FlightNo :"
					+ searchbeanId.getFlightNo()
					+ "&FromDate :"
					+ searchbeanId.getFromDate()
					+ "& ToDate :"
					+ searchbeanId.getToDate());
			naccsSubmissionReportForm.setNaccsSearchBean(searchbeanId);
			PaxTraxLog.logDebug(
				"NACCSSearchBean  searchBeanId is asigning back to naccsSubmissionReportForm");*/
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug("Page Number Value" + pageNumberStr);
			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;
			PaxTraxLog.logDebug("pageNumberStr is " + pageNumberStr);
			if ((pageNumberStr != null))
			{
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			PaxTraxLog.logDebug("page number is " + pageNumber);
			if (pageNumber == 0)
			{
				PaxTraxLog.logDebug("Inside If loop");
				int size = 0;
				pageNumber = 1;
				NACCSDelegate naccsDelegate = new NACCSDelegate();
				allRecords = 
					naccsDelegate.searchNACCSDuplicatePaxDetails(naccsSearchBean);

				PaxTraxLog.logDebug(
					"size of alrecords before if  " + allRecords.size());
				if (allRecords != null)
				{
					size = allRecords.size();
				}
				PaxTraxLog.logDebug("The Size of all Record after If" + size);
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
				PaxTraxLog.logDebug("Session is updated");
			}
			else
			{
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			PaxTraxLog.logDebug("Pagination Helper Class instance is got");
			if ((allRecords != null) && (allRecords.size() != 0))
			{
				PaxTraxLog.logDebug("All records not null inside if loop");
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
				PaxTraxLog.logDebug(
					"current records size is" + currentRecords.size());
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));
			PaxTraxLog.logDebug("request.Attribute  is set for page number");
			if (currentRecords != null)
			{
				PaxTraxLog.logDebug(
					"size of current recors is" + currentRecords.size());
			}
			PaxTraxLog.logDebug("B4 Setting Values in NACCSDuplicatePaxREPORTForm ");
			naccsDuplicatePaxReportForm.setNaccsDuplicatePaxResultBeanList(
				currentRecords);
			PaxTraxLog.logDebug("After Setting Values in NACCSDuplicatePaxREPORTForm ");
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug("Request.Attribute  is set for result");
			forward = PaxTraxConstants.NACCS_DUPLICATE_PAX_REPORT_PAGE;
			PaxTraxLog.logDebug("Forward value is " + forward);
		}
		catch (Exception pte)
		{
			PaxTraxLog.logError(
				"Exception Caught - NACCSDuplicatePaxReportAction - searchNACCSDuplicatePaxDetails",
				pte);

			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("Forward value is " + forward);

		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction::searchNACCSDuplicatePaxDetails::End");
		return mapping.findForward(forward);
	}
	
	/**
	 * Method printNACCSDuplicatePaxReport - Displays Print NACCS Duplicate Pax Report popup
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward printNACCSDuplicatePaxReport(ActionMapping mapping,
		ActionForm form, HttpServletRequest request, 
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::printNACCSDuplicatePaxReport::Begin");
		NACCSDuplicatePaxReportForm naccsDuplicatePaxReportForm = 
				(NACCSDuplicatePaxReportForm) form;
		NACCSSearchBean naccsSearchBean = naccsDuplicatePaxReportForm.getNaccsSearchBean();
		String airlineCode = naccsSearchBean.getAirlineCode(); 
		String airlineValue = null;
		ArrayList airlineCodes = naccsDuplicatePaxReportForm.getAirlineCodes();
		ReferenceDataBean flightDetails = null;
		for( int i = 0; i< airlineCodes.size(); i++)
		{
			flightDetails = (ReferenceDataBean) airlineCodes.get(i);
			if((flightDetails.getCodeId()).equals(airlineCode))
			{
				airlineValue = flightDetails.getCodeValue();
				break;
			}
		}
		request.setAttribute("airlineValue", airlineValue);	
		forward = PaxTraxConstants.PRINT_NACCS_DUPLICATE_PAX_REPORT_PAGE;
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::printNACCSDuplicatePaxReport::End");			
		return mapping.findForward(forward);
	}
	
	/**
	 * Method naccsMergePaxReport.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward naccsCreateMergePaxReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::naccsCreateMergePaxReport::Start");
		NACCSDuplicatePaxReportForm naccsDuplicatePaxReportForm = 
									(NACCSDuplicatePaxReportForm) form;
		NACCSSearchBean naccsSearchBean = new NACCSSearchBean();
		naccsDuplicatePaxReportForm.setNaccsSearchBean(naccsSearchBean);
		
		forward = PaxTraxConstants.NACCS_MERGE_PAX_PAGE;
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::naccsCreateMergePaxReport::End");
		return mapping.findForward(forward);
	}
	
	public ActionForward naccsMergePaxReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::naccsMergePaxReport::Start");
		NACCSDuplicatePaxReportForm naccsDuplicatePaxReportForm = 
									(NACCSDuplicatePaxReportForm) form;
		NACCSSearchBean naccsSearchBean = naccsDuplicatePaxReportForm.getNaccsSearchBean();
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::naccsMergePaxReport:: From PAX "
						+ naccsSearchBean.getFromPAXNo());
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::naccsMergePaxReport:: To PAX "
						+ naccsSearchBean.getToPAXNo());
		HttpSession session = request.getSession();
		String userid = (String)session.getAttribute(PaxTraxConstants.USER_ID);
		naccsSearchBean.setUser(userid);
		try {
			NACCSDelegate naccsDelegate = new NACCSDelegate();
			naccsDelegate.mergePAX(naccsSearchBean);
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		} catch (NACCSException e) {
			PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction:: NACCSException occured ", e);
			request.setAttribute(PaxTraxConstants.ERROR, PaxTraxConstants.TRUE);
			request.setAttribute("errorCode", ""+e.getErrorCode());
		}
		forward = PaxTraxConstants.NACCS_MERGE_PAX_PAGE;
		PaxTraxLog.logDebug("PaxTrax::NACCSDuplicatePaxReportAction::naccsMergePaxReport::End");
		return mapping.findForward(forward);
	}
	
	/**
	 * @see com.dfs.paxtrax.common.action.PaxTraxAction#changeLanguage(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction:: changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		super.changeLanguage(request, language, country);
		forward = request.getParameter("forward");
		PaxTraxLog.logDebug("Forward value is " + forward);
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction:: changeLanguage::End");
		return mapping.findForward(forward);
	}

}
