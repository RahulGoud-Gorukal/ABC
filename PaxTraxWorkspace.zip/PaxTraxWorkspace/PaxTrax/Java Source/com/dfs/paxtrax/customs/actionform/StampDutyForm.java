package com.dfs.paxtrax.customs.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.customs.valueobject.StampDutyBean;

/**
 * This is action form which contains Cage attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 29/06/2004   Joseph Oommen A     Created   
*/

public class StampDutyForm extends PaxTraxActionForm
{
	
	private ArrayList monthList = null;
    private ArrayList stampDutyList = null;
    private StampDutyBean stampDutyBean = null;
    private int totalNumberOfStamps =0;
    private double totalTaxAmount =0.0;
    private String departureDate;
    private ArrayList nabcoReportList = null;
    private String totalSalesBeforeTax;
    private String totalConsumptionTax;
    private String totalNetSales;
    private String month;
    private ArrayList dfdpMonthlyRptBeanList;
    private ArrayList locationList = null;
    private String locationDescription =null; 
    private long totalGrossDFSales;
    private long totalGrossDPSales;
    private long totalCTOnDFSales;
    private long totalCTOnDPSales;
    private long totalDFNetSales;
    private long totalDPNetSales;

	
	/**
	 * Returns the monthList.
	 * @return ArrayList
	 */
	public ArrayList getMonthList()
	{
		return monthList;
	}

	/**
	 * Returns the stampDutyList.
	 * @return ArrayList
	 */
	public ArrayList getStampDutyList()
	{
		return stampDutyList;
	}

	/**
	 * Sets the monthList.
	 * @param monthList The monthList to set
	 */
	public void setMonthList(ArrayList monthList)
	{
		this.monthList = monthList;
	}

	/**
	 * Sets the stampDutyList.
	 * @param stampDutyList The stampDutyList to set
	 */
	public void setStampDutyList(ArrayList stampDutyList)
	{
		this.stampDutyList = stampDutyList;
	}

	/**
	 * Returns the stampDutyBean.
	 * @return StampDutyBean
	 */
	public StampDutyBean getStampDutyBean()
	{
		return stampDutyBean;
	}

	/**
	 * Sets the stampDutyBean.
	 * @param stampDutyBean The stampDutyBean to set
	 */
	public void setStampDutyBean(StampDutyBean stampDutyBean)
	{
		this.stampDutyBean = stampDutyBean;
	}

	/**
	 * Returns the totalNumberOfStamps.
	 * @return int
	 */
	public int getTotalNumberOfStamps()
	{
		return totalNumberOfStamps;
	}

	/**
	 * Returns the totalTaxAmount.
	 * @return int
	 */
	public double getTotalTaxAmount()
	{
		return totalTaxAmount;
	}

	/**
	 * Sets the totalNumberOfStamps.
	 * @param totalNumberOfStamps The totalNumberOfStamps to set
	 */
	public void setTotalNumberOfStamps(int totalNumberOfStamps)
	{
		this.totalNumberOfStamps = totalNumberOfStamps;
	}

	/**
	 * Sets the totalTaxAmount.
	 * @param totalTaxAmount The totalTaxAmount to set
	 */
	public void setTotalTaxAmount(double totalTaxAmount)
	{
		this.totalTaxAmount = totalTaxAmount;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * Returns the nabcoReportList.
	 * @return ArrayList
	 */
	public ArrayList getNabcoReportList() {
		return nabcoReportList;
	}

	/**
	 * Sets the nabcoReportList.
	 * @param nabcoReportList The nabcoReportList to set
	 */
	public void setNabcoReportList(ArrayList nabcoReportList) {
		this.nabcoReportList = nabcoReportList;
	}

	/**
	 * Returns the totalConsumptionTax.
	 * @return long
	 */
	public String getTotalConsumptionTax() {
		return totalConsumptionTax;
	}

	/**
	 * Returns the totalNetSales.
	 * @return double
	 */
	public String getTotalNetSales() {
		return totalNetSales;
	}

	/**
	 * Returns the totalSalesBeforeTax.
	 * @return double
	 */
	public String getTotalSalesBeforeTax() {
		return totalSalesBeforeTax;
	}

	/**
	 * Sets the totalConsumptionTax.
	 * @param totalConsumptionTax The totalConsumptionTax to set
	 */
	public void setTotalConsumptionTax(String totalConsumptionTax) {
		this.totalConsumptionTax = totalConsumptionTax;
	}

	/**
	 * Sets the totalNetSales.
	 * @param totalNetSales The totalNetSales to set
	 */
	public void setTotalNetSales(String totalNetSales) {
		this.totalNetSales = totalNetSales;
	}

	/**
	 * Sets the totalSalesBeforeTax.
	 * @param totalSalesBeforeTax The totalSalesBeforeTax to set
	 */
	public void setTotalSalesBeforeTax(String totalSalesBeforeTax) {
		this.totalSalesBeforeTax = totalSalesBeforeTax;
	}

	/**
	 * Returns the month.
	 * @return String
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * Sets the month.
	 * @param month The month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}


	/**
	 * Returns the dfdpMonthlyRptBeanList.
	 * @return ArrayList
	 */
	public ArrayList getDfdpMonthlyRptBeanList() {
		return dfdpMonthlyRptBeanList;
	}

	/**
	 * Sets the dfdpMonthlyRptBeanList.
	 * @param dfdpMonthlyRptBeanList The dfdpMonthlyRptBeanList to set
	 */
	public void setDfdpMonthlyRptBeanList(ArrayList dfdpMonthlyRptBeanList) {
		this.dfdpMonthlyRptBeanList = dfdpMonthlyRptBeanList;
	}

	/**
	 * Returns the locationList.
	 * @return ArrayList
	 */
	public ArrayList getLocationList()
	{
		return locationList;
	}

	/**
	 * Sets the locationList.
	 * @param locationList The locationList to set
	 */
	public void setLocationList(ArrayList locationList)
	{
		this.locationList = locationList;
	}

	/**
	 * Returns the locationDescription.
	 * @return String
	 */
	public String getLocationDescription()
	{
		return locationDescription;
	}

	/**
	 * Sets the locationDescription.
	 * @param locationDescription The locationDescription to set
	 */
	public void setLocationDescription(String locationDescription)
	{
		this.locationDescription = locationDescription;
	}

	/**
	 * Returns the totalCTOnDFSales.
	 * @return long
	 */
	public long getTotalCTOnDFSales() {
		return totalCTOnDFSales;
	}

	/**
	 * Returns the totalCTOnDPSales.
	 * @return long
	 */
	public long getTotalCTOnDPSales() {
		return totalCTOnDPSales;
	}

	/**
	 * Returns the totalDFNetSales.
	 * @return long
	 */
	public long getTotalDFNetSales() {
		return totalDFNetSales;
	}

	/**
	 * Returns the totalDPNetSales.
	 * @return long
	 */
	public long getTotalDPNetSales() {
		return totalDPNetSales;
	}

	/**
	 * Returns the totalGrossDFSales.
	 * @return long
	 */
	public long getTotalGrossDFSales() {
		return totalGrossDFSales;
	}

	/**
	 * Returns the totalGrossDPSales.
	 * @return long
	 */
	public long getTotalGrossDPSales() {
		return totalGrossDPSales;
	}

	/**
	 * Sets the totalCTOnDFSales.
	 * @param totalCTOnDFSales The totalCTOnDFSales to set
	 */
	public void setTotalCTOnDFSales(long totalCTOnDFSales) {
		this.totalCTOnDFSales = totalCTOnDFSales;
	}

	/**
	 * Sets the totalCTOnDPSales.
	 * @param totalCTOnDPSales The totalCTOnDPSales to set
	 */
	public void setTotalCTOnDPSales(long totalCTOnDPSales) {
		this.totalCTOnDPSales = totalCTOnDPSales;
	}

	/**
	 * Sets the totalDFNetSales.
	 * @param totalDFNetSales The totalDFNetSales to set
	 */
	public void setTotalDFNetSales(long totalDFNetSales) {
		this.totalDFNetSales = totalDFNetSales;
	}

	/**
	 * Sets the totalDPNetSales.
	 * @param totalDPNetSales The totalDPNetSales to set
	 */
	public void setTotalDPNetSales(long totalDPNetSales) {
		this.totalDPNetSales = totalDPNetSales;
	}

	/**
	 * Sets the totalGrossDFSales.
	 * @param totalGrossDFSales The totalGrossDFSales to set
	 */
	public void setTotalGrossDFSales(long totalGrossDFSales) {
		this.totalGrossDFSales = totalGrossDFSales;
	}

	/**
	 * Sets the totalGrossDPSales.
	 * @param totalGrossDPSales The totalGrossDPSales to set
	 */
	public void setTotalGrossDPSales(long totalGrossDPSales) {
		this.totalGrossDPSales = totalGrossDPSales;
	}

}