package com.dfs.paxtrax.customs.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class NACCSSubmissionResultBean extends PaxTraxValueObject {
	private String airLineCode = null;
	private String flightNo = null;
	private String paxFileName = null;
	private String generatedDateTime = null;
	private String submittedDateTime = null;
	private String acknowledgementDateTime = null;
	private NACCSSearchBean naccsSearchBean = null;
	private ArrayList transList = null;
	private String skuCount = null; //For DailyNACCSGeneration report
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */
	private String departureDateTime = null;
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
	public NACCSSubmissionResultBean() {
	}

	/**
	 * Returns the acknowledgementDateTime.
	 * @return String
	 */
	public String getAcknowledgementDateTime() {
		return acknowledgementDateTime;
	}

	/**
	 * Returns the flightNo.
	 * @return String
	 */
	public String getFlightNo() {
		return flightNo;
	}

	/**
	 * Returns the generatedDateTime.
	 * @return String
	 */
	public String getGeneratedDateTime() {
		return generatedDateTime;
	}

	/**
	 * Returns the paxFileName.
	 * @return String
	 */
	public String getPaxFileName() {
		return paxFileName;
	}

	/**
	 * Returns the submittedDateTime.
	 * @return String
	 */
	public String getSubmittedDateTime() {
		return submittedDateTime;
	}

	/**
	 * Sets the acknowledgementDateTime.
	 * @param acknowledgementDateTime The acknowledgementDateTime to set
	 */
	public void setAcknowledgementDateTime(String acknowledgementDateTime) {
		this.acknowledgementDateTime = acknowledgementDateTime;
	}

	/**
	 * Sets the flightNo.
	 * @param flightNo The flightNo to set
	 */
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	/**
	 * Sets the generatedDateTime.
	 * @param generatedDateTime The generatedDateTime to set
	 */
	public void setGeneratedDateTime(String generatedDateTime) {
		this.generatedDateTime = generatedDateTime;
	}

	/**
	 * Sets the paxFileName.
	 * @param paxFileName The paxFileName to set
	 */
	public void setPaxFileName(String paxFileName) {
		this.paxFileName = paxFileName;
	}

	/**
	 * Sets the submittedDateTime.
	 * @param submittedDateTime The submittedDateTime to set
	 */
	public void setSubmittedDateTime(String submittedDateTime) {
		this.submittedDateTime = submittedDateTime;
	}

	/**
	 * Returns the naccsSearchBean.
	 * @return NACCSSearchBean
	 */
	public NACCSSearchBean getNaccsSearchBean() {
		return naccsSearchBean;
	}

	/**
	 * Sets the naccsSearchBean.
	 * @param naccsSearchBean The naccsSearchBean to set
	 */
	public void setNaccsSearchBean(NACCSSearchBean naccsSearchBean) {
		this.naccsSearchBean = naccsSearchBean;
	}

	/**
	 * Returns the airLineCode.
	 * @return String
	 */
	public String getAirLineCode() {
		return airLineCode;
	}

	/**
	 * Sets the airLineCode.
	 * @param airLineCode The airLineCode to set
	 */
	public void setAirLineCode(String airLineCode) {
		this.airLineCode = airLineCode;
	}

	/**
	 * Returns the transList.
	 * @return ArrayList
	 */
	public ArrayList getTransList() {
		return transList;
	}

	/**
	 * Sets the transList.
	 * @param transList The transList to set
	 */
	public void setTransList(ArrayList transList) {
		this.transList = transList;
	}

	//	Added on 1-Jun-2007 For DailyNACCSGeneration Report starts.
	/**
		 * Returns the skuCount
		 * @return skuCount
		 */
	public String getSkuCount() {
		return skuCount;
	}

	/**
	 * Sets string the SkuCount
	 * @param string the skuCountt
	 */
	public void setSkuCount(String string) {
		skuCount = string;
	}
	//	Added on 1-Jun-2007 For DailyNACCSGeneration Report ends.

	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */

	/**
	 * Returns Flight Departure time
	 */
	public String getDepartureDateTime() {
		return departureDateTime;
	}

	/**
	 * Sets Flight Departure time
	 */
	public void setDepartureDateTime(String string) {
		departureDateTime = string;
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
}
