package com.dfs.paxtrax.customs.action;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.NACCSSubmissionReportForm;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSubmissionResultBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSummaryResultBean;

/**
 * @author 114919
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
/**
 *Action class for NACCSubmission Report 
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Ramesh	Created
 */
/**
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class NACCSSubmissionReportAction extends PaxTraxAction {

	String forward = null;
	/**
	 * Method generateNACCSSubmissionReport.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward generateNACCSSubmissionReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {

		try {

			PaxTraxLog.logDebug(
				"PaxTrax::NACCSSubmissionReportAction::generateNACCSSubmissionReport::Begin");
			NACCSSubmissionReportForm naccsSubmissionReportForm =
				(NACCSSubmissionReportForm) form;

			PaxTraxLog.logDebug("Form Type cast occured");
			ReferenceDataDelegate referenceDataDelegate =
				new ReferenceDataDelegate();
			PaxTraxLog.logDebug("Reference Delegate Declared");
			NACCSSearchBean naccsSearchBean = new NACCSSearchBean();
			PaxTraxLog.logDebug("Naccs Search Bean  Declared ");
			naccsSubmissionReportForm.setNaccsSearchBean(naccsSearchBean);

			PaxTraxLog.logDebug(
				"NaccsBean assigned to naccsSubmissionReportForm");
			naccsSearchBean.setAirlineBean(new ReferenceDataBean());
			PaxTraxLog.logDebug(
				"Airline Bean is initilaized to naccs Search Bean");
			NACCSSearchBean searchbeanId =
				naccsSubmissionReportForm.getNaccsSearchBean();

			PaxTraxLog.logDebug(
				"searchBeanId is received from submission report form");
			/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */
//Setting today's date in both from and to date of the report
			String currentDate = getCurrentDate();
			searchbeanId.setFromDate(currentDate);
			searchbeanId.setToDate(currentDate);
			PaxTraxLog.logDebug(
				"Current date is set in the NACCSGenerationForm : "
					+ currentDate);
			/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
			naccsSubmissionReportForm.setAirlineCodes(
				referenceDataDelegate.loadReferenceData(
					PaxTraxConstants.AIRLINE_CODE));
			PaxTraxLog.logDebug(
				"Airline Code is assigned by calling the delegate method of refence data delegate");
			naccsSubmissionReportForm.setNaccsSearchBean(searchbeanId);
			PaxTraxLog.logDebug(
				"Naccs searchbeanId is  assigned to the naccsSubmissionReportForm");
			forward = PaxTraxConstants.ENQUIRY_SUBMISSION_SEARCH_PAGE;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);

		} catch (Exception pte) {
			PaxTraxLog.logError(
				"Exception Caught - NACCSSubmissionReportAction - generateNACCSSubmissionReport",
				pte);
			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::generateNACCSSubmissionReport::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method searchFileStatusEnquiry.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward searchFileStatusEnquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::searchFileStatusEnquiry::Begin");
		try {

			int pageNumber = 0;
			ArrayList currentRecords = null;
			ArrayList allRecords = null;
			HttpSession session = request.getSession();
			PaxTraxLog.logDebug("Session is created");
			NACCSSubmissionReportForm naccsSubmissionReportForm =
				(NACCSSubmissionReportForm) form;
			NACCSSearchBean searchbeanId =
				naccsSubmissionReportForm.getNaccsSearchBean();
			PaxTraxLog.logDebug(
				"NACCSSearchBean  searchBeanId is getting from naccsSubmissionReportForm");
			searchbeanId.setAirlineCode(
				searchbeanId.getAirlineBean().getCodeId());

			PaxTraxLog.logDebug(
				"NACCSSubmission Report Action the values are AirlineCode "
					+ searchbeanId.getAirlineCode()
					+ "& FlightNo :"
					+ searchbeanId.getFlightNo()
					+ "&FromDate :"
					+ searchbeanId.getFromDate()
					+ "& ToDate :"
					+ searchbeanId.getToDate());
			naccsSubmissionReportForm.setNaccsSearchBean(searchbeanId);
			PaxTraxLog.logDebug(
				"NACCSSearchBean  searchBeanId is asigning back to naccsSubmissionReportForm");
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug("Page Number Value" + pageNumberStr);
			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;
			PaxTraxLog.logDebug("pageNumberStr is " + pageNumberStr);
			if ((pageNumberStr != null)) {
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			PaxTraxLog.logDebug("page number is " + pageNumber);
			if (pageNumber == 0) {
				PaxTraxLog.logDebug("Inside If loop");
				int size = 0;
				pageNumber = 1;
				allRecords =
					getFileStatusDetails(
						naccsSubmissionReportForm.getNaccsSearchBean());
				PaxTraxLog.logDebug(
					"size of alrecords before if  " + allRecords.size());
				if (allRecords != null) {
					size = allRecords.size();
				}
				PaxTraxLog.logDebug("The Size of all Record after If" + size);
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
				PaxTraxLog.logDebug("Session is updated");
			} else {
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			PaxTraxLog.logDebug("Pagination Helper Class instance is got");
			if ((allRecords != null) && (allRecords.size() != 0)) {
				PaxTraxLog.logDebug("All records not null inside if loop");
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
				PaxTraxLog.logDebug(
					"current records size is" + currentRecords.size());
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));
			PaxTraxLog.logDebug("request.Attribute  is set for page number");
			if (currentRecords != null) {
				PaxTraxLog.logDebug(
					"size of current recors is" + currentRecords.size());
			}
			PaxTraxLog.logDebug("B4 Setting Values in NACCSREPORTForm ");
			naccsSubmissionReportForm.setNaccsSubmissionResultBeanList(
				currentRecords);
			PaxTraxLog.logDebug("After Setting Values in NACCSREPORTForm ");
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug("Request.Attribute  is set for result");
			forward = PaxTraxConstants.ENQUIRY_SUBMISSION_SEARCH_PAGE;
			PaxTraxLog.logDebug("Forward value is " + forward);
		} catch (Exception pte) {
			PaxTraxLog.logError(
				"Exception Caught - NACCSSubmissionReportAction - searchFileStatusEnquiry",
				pte);

			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("Forward value is " + forward);

		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::searchFileStatusEnquiry::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method getFileStatusDetails.
	 * @param naccsSearchBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	private ArrayList getFileStatusDetails(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::getFileStatusDetails::Begin");

		PaxTraxLog.logDebug(
			"AirLine Code  is " + naccsSearchBean.getAirlineCode());
		PaxTraxLog.logDebug("FlightNo  is " + naccsSearchBean.getFlightNo());
		PaxTraxLog.logDebug("From Date  is " + naccsSearchBean.getFromDate());
		PaxTraxLog.logDebug("To Date  is " + naccsSearchBean.getToDate());
		PaxTraxLog.logDebug(
			"Non Acknowledged  is " + naccsSearchBean.isNonAcknowledged());
		ArrayList fileStatusDetails = new ArrayList();
		NACCSDelegate naccsDelegateObj = new NACCSDelegate();
		NACCSSubmissionResultBean naccsBeanObj =
			new NACCSSubmissionResultBean();
		fileStatusDetails =
			naccsDelegateObj.getNaccsSubmissionRecords(naccsSearchBean);
		PaxTraxLog.logDebug(
			"getFileStatusDetails  size is " + fileStatusDetails.size());
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::getFileStatusDetails::End");

		return (fileStatusDetails);
	}

	/**
	 * Method loadFlightDetails.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward loadFlightDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::loadFlightDetails::Begin");

		try {
			String flightNo = request.getParameter("flightNumber");
			PaxTraxLog.logDebug(
				"NaccsSubmission Action() : loadFlightDetails() FlightNo ->"
					+ flightNo);
			String strairlineCode = flightNo.substring(0, 2);
			PaxTraxLog.logDebug(
				"NAACSSubmission Action(): loadFlightDetails() airline code "
					+ strairlineCode);
			String strflightNo = flightNo.substring(2, flightNo.length());
			String depDate = request.getParameter("depDate");
			PaxTraxLog.logDebug(
				"The FlightNO is " + request.getParameter("flightNumber"));
			PaxTraxLog.logDebug(
				"The Dep Date is " + request.getParameter("depDate"));
			int pageNumber = 0;
			ArrayList currentRecords = null;
			ArrayList allRecords = null;
			HttpSession session = request.getSession();
			String index = null;
			NACCSSubmissionReportForm naccsSubmissionReportForm =
				(NACCSSubmissionReportForm) form;
			NACCSSearchBean searchbeanId =
				naccsSubmissionReportForm.getNaccsSearchBean();

			PaxTraxLog.logDebug("SearchBean Id is " + searchbeanId);
			NACCSSearchBean naccsSearchBean = new NACCSSearchBean();
			ReferenceDataDelegate referenceDataDelegate =
				new ReferenceDataDelegate();
			naccsSearchBean.setAirlineBean(new ReferenceDataBean());
			naccsSubmissionReportForm.setAirlineCodes(
				referenceDataDelegate.loadReferenceData(
					PaxTraxConstants.AIRLINE_CODE));
			PaxTraxLog.logDebug(
				"Refernce Data Delegate is called for getting Airline Codes ");

			ArrayList naccsSubmissionResultBeanList =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_SUMMARY_RECORDS);
			NACCSSummaryResultBean obj = null;
			naccsSearchBean.setFlightNo(strflightNo);
			naccsSearchBean.setDepartureDate(depDate);

			ReferenceDataBean referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId(strairlineCode);
			referenceDataBean.setReferenceId(strairlineCode);
			naccsSearchBean.setAirlineBean(referenceDataBean);

			ArrayList airlineCodes =
				naccsSubmissionReportForm.getAirlineCodes();

			if (airlineCodes != null && !airlineCodes.isEmpty()) {
				referenceDataBean = naccsSearchBean.getAirlineBean();
				for (int i = 0; i < airlineCodes.size(); i++) {
					referenceDataBean = (ReferenceDataBean) airlineCodes.get(i);
					if (referenceDataBean
						.getCodeId()
						.equals(referenceDataBean.getCodeId())) {
						PaxTraxLog.logDebug(
							"Airline Code Id is " + strairlineCode);
						referenceDataBean.setReferenceId(strairlineCode);
						PaxTraxLog.logDebug(
							"Airline Code value is " + strairlineCode);
						referenceDataBean.setCodeValue(strairlineCode);

						naccsSearchBean.setAirlineBean(referenceDataBean);
						break;
					}
				}
			}

			PaxTraxLog.logDebug(
				"After Setting it Bean using ReferenceDataBean codeId "
					+ naccsSearchBean.getAirlineBean().getCodeId());
			PaxTraxLog.logDebug(
				"After Setting it Bean using ReferenceDataBean referenceid "
					+ naccsSearchBean.getAirlineBean().getReferenceId());

			naccsSubmissionReportForm.setNaccsSearchBean(naccsSearchBean);

			/* Starts Here */

			PaxTraxLog.logDebug("B4 PageNumber str");
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug(" after page number " + pageNumberStr);

			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;
			PaxTraxLog.logDebug("pageNumberStr is " + pageNumberStr);
			if ((pageNumberStr != null)) {
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			PaxTraxLog.logDebug("page number is " + pageNumber);
			if (pageNumber == 0) {
				PaxTraxLog.logDebug("Inside If loop");
				int size = 0;
				pageNumber = 1;
				allRecords =
					getFileStatusDetails(
						naccsSubmissionReportForm.getNaccsSearchBean());
				PaxTraxLog.logDebug("size of alrecords " + allRecords.size());
				if (allRecords != null) {
					size = allRecords.size();
				}
				PaxTraxLog.logDebug("The Size of all Record after If" + size);
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
				PaxTraxLog.logDebug("Session is updated");
			} else {
				PaxTraxLog.logDebug("getting from session");
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_SUMMARY_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			if ((allRecords != null) && (allRecords.size() != 0)) {
				PaxTraxLog.logDebug("All records not null inside if loop");
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
				PaxTraxLog.logDebug(
					"current records size is" + currentRecords.size());
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));
			PaxTraxLog.logDebug("Request attribute is set for Page Number");
			if (currentRecords != null) {
				PaxTraxLog.logDebug("size " + currentRecords.size());
			}
			PaxTraxLog.logDebug("B4 Setting Values in NACCSREPORTForm ");

			naccsSubmissionReportForm.setNaccsSubmissionResultBeanList(
				currentRecords);
			PaxTraxLog.logDebug("After Setting Values in NACCSREPORTForm ");
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug("Result Attribute set");

			forward = PaxTraxConstants.ENQUIRY_SUBMISSION_SEARCH_PAGE;

			PaxTraxLog.logDebug("Forward value is " + forward);

		} catch (Exception pte) {
			PaxTraxLog.logError(
				"Exception Caught - NACCSSubmissionReportAction - loadFlightDetails",
				pte);

			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("Forward value is " + forward);

		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction::loadFlightDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * @see com.dfs.paxtrax.common.action.PaxTraxAction#changeLanguage(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction:: changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		super.changeLanguage(request, language, country);
		forward = PaxTraxConstants.ENQUIRY_SUBMISSION_SEARCH_PAGE;
		PaxTraxLog.logDebug("Forward value is " + forward);
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSubmissionReportAction:: changeLanguage::End");
		return mapping.findForward(forward);
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */

	/**
			 * It gets current date  
			 * Method getCurrentDate.
			 * @param 
			 * @return String 
			 * @throws 
			 */
	private String getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE);
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);

		String currentDate = "";
		currentDate =
			""
				+ year
				+ "/"
				+ (month < 10 ? "0" + month : "" + month)
				+ "/"
				+ (day < 10 ? "0" + day : "" + day);

		return (currentDate);
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
}
