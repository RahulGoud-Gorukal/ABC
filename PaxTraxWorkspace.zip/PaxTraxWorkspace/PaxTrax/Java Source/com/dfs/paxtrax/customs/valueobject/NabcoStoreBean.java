package com.dfs.paxtrax.customs.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * This is a value object used by Nabco report containing
 * details for a store.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 21/09/2004	P.C.Sathish		Created
 */
public class NabcoStoreBean extends PaxTraxValueObject {
	private String store;
	private double salesBeforeTax;
	private long consumptionTax;
	private double netSales;

	/**
	 * Returns the consumptionTax.
	 * @return long
	 */
	public long getConsumptionTax() {
		return consumptionTax;
	}

	/**
	 * Returns the netSales.
	 * @return double
	 */
	public double getNetSales() {
		return netSales;
	}

	/**
	 * Returns the salesBeforeTax.
	 * @return double
	 */
	public double getSalesBeforeTax() {
		return salesBeforeTax;
	}

	/**
	 * Sets the consumptionTax.
	 * @param consumptionTax The consumptionTax to set
	 */
	public void setConsumptionTax(long consumptionTax) {
		this.consumptionTax = consumptionTax;
	}

	/**
	 * Sets the netSales.
	 * @param netSales The netSales to set
	 */
	public void setNetSales(double netSales) {
		this.netSales = netSales;
	}

	/**
	 * Sets the salesBeforeTax.
	 * @param salesBeforeTax The salesBeforeTax to set
	 */
	public void setSalesBeforeTax(double salesBeforeTax) {
		this.salesBeforeTax = salesBeforeTax;
	}

	/**
	 * Returns the store.
	 * @return String
	 */
	public String getStore() {
		return store;
	}

	/**
	 * Sets the store.
	 * @param store The store to set
	 */
	public void setStore(String store) {
		this.store = store;
	}

}
