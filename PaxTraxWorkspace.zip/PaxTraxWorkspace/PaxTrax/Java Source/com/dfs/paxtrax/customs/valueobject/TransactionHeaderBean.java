package com.dfs.paxtrax.customs.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 /**
 * This is the valueobject class which stores the 
 * of sales transaction header data.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 04/08/2004   P.C.Sathish		    Created
*/

public class TransactionHeaderBean extends PaxTraxValueObject{
	private int sellingLocation;
	private int terminalNumber;
	private int transactionNumber;
	private String salesRekeyTransaction;
	private int originalSellingLocation;
	private int originalTerminalNumber;
	private int originalTransactionNumber;	
	
	/**
	 * Returns the originalSellingLocation.
	 * @return int
	 */
	public int getOriginalSellingLocation() {
		return originalSellingLocation;
	}

	/**
	 * Returns the originalTerminalNumber.
	 * @return int
	 */
	public int getOriginalTerminalNumber() {
		return originalTerminalNumber;
	}

	/**
	 * Returns the originalTransactionNumber.
	 * @return int
	 */
	public int getOriginalTransactionNumber() {
		return originalTransactionNumber;
	}

	/**
	 * Returns the salesRekeyTransaction.
	 * @return String
	 */
	public String getSalesRekeyTransaction() {
		return salesRekeyTransaction;
	}

	/**
	 * Returns the sellingLocation.
	 * @return int
	 */
	public int getSellingLocation() {
		return sellingLocation;
	}

	/**
	 * Returns the terminalNumber.
	 * @return int
	 */
	public int getTerminalNumber() {
		return terminalNumber;
	}

	/**
	 * Returns the transactionNumber.
	 * @return int
	 */
	public int getTransactionNumber() {
		return transactionNumber;
	}

	/**
	 * Sets the originalSellingLocation.
	 * @param originalSellingLocation The originalSellingLocation to set
	 */
	public void setOriginalSellingLocation(int originalSellingLocation) {
		this.originalSellingLocation = originalSellingLocation;
	}

	/**
	 * Sets the originalTerminalNumber.
	 * @param originalTerminalNumber The originalTerminalNumber to set
	 */
	public void setOriginalTerminalNumber(int originalTerminalNumber) {
		this.originalTerminalNumber = originalTerminalNumber;
	}

	/**
	 * Sets the originalTransactionNumber.
	 * @param originalTransactionNumber The originalTransactionNumber to set
	 */
	public void setOriginalTransactionNumber(int originalTransactionNumber) {
		this.originalTransactionNumber = originalTransactionNumber;
	}

	/**
	 * Sets the salesRekeyTransaction.
	 * @param salesRekeyTransaction The salesRekeyTransaction to set
	 */
	public void setSalesRekeyTransaction(String salesRekeyTransaction) {
		this.salesRekeyTransaction = salesRekeyTransaction;
	}

	/**
	 * Sets the sellingLocation.
	 * @param sellingLocation The sellingLocation to set
	 */
	public void setSellingLocation(int sellingLocation) {
		this.sellingLocation = sellingLocation;
	}

	/**
	 * Sets the terminalNumber.
	 * @param terminalNumber The terminalNumber to set
	 */
	public void setTerminalNumber(int terminalNumber) {
		this.terminalNumber = terminalNumber;
	}

	/**
	 * Sets the transactionNumber.
	 * @param transactionNumber The transactionNumber to set
	 */
	public void setTransactionNumber(int transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

}
