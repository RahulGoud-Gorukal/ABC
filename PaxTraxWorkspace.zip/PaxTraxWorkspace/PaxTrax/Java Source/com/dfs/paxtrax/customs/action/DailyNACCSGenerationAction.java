package com.dfs.paxtrax.customs.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.NACCSSubmissionReportForm;
import com.dfs.paxtrax.customs.actionform.DailyNACCSGenerationForm;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.DailyNACCSGenerationBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSubmissionResultBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSummaryResultBean;

/**
 * Action class for Daily NACCS Generation Report.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant -  Sankaranarayanan srinivasan 
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 01/06/2007	Vijay		    Created
 */
public class DailyNACCSGenerationAction extends PaxTraxAction {

	String forward = null;
	/**
	 * Forwards to DailyNAACSGeneration List report 
	 * Method dailyNACCSGenerationReport.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward dailyNACCSGenerationReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {

		try {

			PaxTraxLog.logDebug(
				"PaxTrax::DailyNACCSGenerationAction::dailyNACCSGenerationReport::Begin");
			DailyNACCSGenerationForm dailyNACCSGenerationForm =
				(DailyNACCSGenerationForm) form;

			PaxTraxLog.logDebug("Form Type cast occured");
			ReferenceDataDelegate referenceDataDelegate =
				new ReferenceDataDelegate();
			PaxTraxLog.logDebug("Reference Delegate Declared");
			NACCSSearchBean naccsSearchBean = new NACCSSearchBean();

			naccsSearchBean.setAirlineBean(new ReferenceDataBean());

			dailyNACCSGenerationForm.setAirlineCodes(
				referenceDataDelegate.loadReferenceData(
					PaxTraxConstants.AIRLINE_CODE));
			String currentDate = getCurrentDate();
			naccsSearchBean.setFromDate(currentDate);
			naccsSearchBean.setToDate(currentDate);
			PaxTraxLog.logDebug(
				"Current date is set in the DailyNACCSGenerationForm : "
					+ currentDate);
			PaxTraxLog.logDebug(
				"Airline Code is assigned by calling the delegate method of refence data delegate");
			dailyNACCSGenerationForm.setNaccsSearchBean(naccsSearchBean);
			PaxTraxLog.logDebug(
				"Naccs searchbeanId is  assigned to the dailyNACCSGenerationForm");
			forward = PaxTraxConstants.DAILY_NACCS_GENERATION_PAGE;
			PaxTraxLog.logDebug("forward Value is assigned as " + forward);

		} catch (Exception pte) {
			PaxTraxLog.logError(
				"Exception Caught - DailyNACCSGenerationAction - dailyNACCSGenerationReport",
				pte);
			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::DailyNACCSGenerationAction::dailyNACCSGenerationReport::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method searchFileStatusEnquiry.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward searchFileStatusEnquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::DailyNACCSGenerationAction::searchFileStatusEnquiry::Begin");
		try {

			int pageNumber = 0;
			ArrayList currentRecords = null;

			DailyNACCSGenerationBean allRecords = null;
			HttpSession session = request.getSession();
			PaxTraxLog.logDebug("Session is created");
			DailyNACCSGenerationForm dailyNACCSGenerationForm =
				(DailyNACCSGenerationForm) form;
			NACCSSearchBean searchbeanId =
				dailyNACCSGenerationForm.getNaccsSearchBean();
			PaxTraxLog.logDebug(
				"NACCSSearchBean  searchBeanId is getting from dailyNACCSGenerationForm");
			searchbeanId.setAirlineCode(
				searchbeanId.getAirlineBean().getCodeId());

			PaxTraxLog.logDebug(
				"dailyNACCSGenerationForm the values are AirlineCode "
					+ searchbeanId.getAirlineCode()
					+ "& FlightNo :"
					+ searchbeanId.getFlightNo()
					+ "&FromDate :"
					+ searchbeanId.getFromDate()
					+ "& ToDate :"
					+ searchbeanId.getToDate());
			dailyNACCSGenerationForm.setNaccsSearchBean(searchbeanId);
			PaxTraxLog.logDebug(
				"NACCSSearchBean  searchBeanId is asigning back to DailyNACCSGenerationForm");
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug("Page Number Value" + pageNumberStr);
			/* If page number is null or empty it sets null otherwise
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;
			PaxTraxLog.logDebug("pageNumberStr is " + pageNumberStr);
			if ((pageNumberStr != null)) {
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			PaxTraxLog.logDebug("page number is " + pageNumber);
			if (pageNumber == 0) {
				PaxTraxLog.logDebug("Inside If loop");
				int size = 0;
				pageNumber = 1;
				allRecords =
					getFileStatusDetails(
						dailyNACCSGenerationForm.getNaccsSearchBean());
				PaxTraxLog.logDebug(
					"size of alrecords before if  "
						+ allRecords.getNaccsSubmissionResultBeanList().size());
				if (allRecords != null) {
					size = allRecords.getNaccsSubmissionResultBeanList().size();
				}
				PaxTraxLog.logDebug(
					"The Size of all Record after If : " + size);

				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				//session.removeAttribute(PaxTraxConstants.GALLERIA_SKU_COUNT);
				//session.removeAttribute(PaxTraxConstants.AIRPORT_SKU_COUNT);

//				session.setAttribute(
//					PaxTraxConstants.GALLERIA_SKU_COUNT,
//					allRecords.getGalleriaSkuCount());
//				session.setAttribute(
//					PaxTraxConstants.AIRPORT_SKU_COUNT,
//					allRecords.getAirPortSkuCount());
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
				PaxTraxLog.logDebug("Session is updated");
			} else {

				allRecords =
					(DailyNACCSGenerationBean) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			PaxTraxLog.logDebug("Pagination Helper Class instance is got");
			if ((allRecords != null)
				&& (allRecords.getNaccsSubmissionResultBeanList().size() != 0)) {
				PaxTraxLog.logDebug("All records not null inside if loop ");
				currentRecords =
					helper.getCurrentTableContent(
						allRecords.getNaccsSubmissionResultBeanList(),
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
				PaxTraxLog.logDebug(
					"current records size is " + currentRecords.size());
				PaxTraxLog.logDebug(
					"Galleria SKU  count "
						+ allRecords.getGalleriaSkuCount()
						+ " AP SKU Count"
						+ allRecords.getAirPortSkuCount());
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));
			PaxTraxLog.logDebug("request.Attribute  is set for page number");
			if (currentRecords != null) {
				PaxTraxLog.logDebug(
					"size of current recors is" + currentRecords.size());
			}
			PaxTraxLog.logDebug(
				"B4 Setting Values in DailyNACCSGenerationForm ");
			dailyNACCSGenerationForm.setNaccsSubmissionResultBeanList(
				currentRecords);

			dailyNACCSGenerationForm.setAirPortSkuCount(
				allRecords.getAirPortSkuCount());
			dailyNACCSGenerationForm.setGalleriaSkuCount(
				allRecords.getGalleriaSkuCount());
			PaxTraxLog.logDebug(
				"After Setting Values in DailyNACCSGenerationForm ");
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug("Request.Attribute  is set for result");
			forward = PaxTraxConstants.DAILY_NACCS_GENERATION_PAGE;
			PaxTraxLog.logDebug("Forward value is " + forward);
		} catch (Exception pte) {
			PaxTraxLog.logError(
				"Exception Caught - DailyNACCSGenerationAction - searchFileStatusEnquiry",
				pte);

			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("Forward value is " + forward);

		}
		PaxTraxLog.logDebug(
			"PaxTrax::DailyNACCSGenerationAction::searchFileStatusEnquiry::End");
		return mapping.findForward(forward);
	}

	/**
	 * It gets the NACCS File Records 
	 * Method getFileStatusDetails.
	 * @param naccsSearchBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	private DailyNACCSGenerationBean getFileStatusDetails(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::DailyNACCSGenerationAction::getFileStatusDetails::Begin");

		PaxTraxLog.logDebug(
			"AirLine Code  is " + naccsSearchBean.getAirlineCode());
		PaxTraxLog.logDebug("FlightNo  is " + naccsSearchBean.getFlightNo());
		PaxTraxLog.logDebug("From Date  is " + naccsSearchBean.getFromDate());
		PaxTraxLog.logDebug("To Date  is " + naccsSearchBean.getToDate());
		PaxTraxLog.logDebug(
			"Non Acknowledged  is " + naccsSearchBean.isNonAcknowledged());
		DailyNACCSGenerationBean fileStatusDetails =
			new DailyNACCSGenerationBean();
		NACCSDelegate naccsDelegateObj = new NACCSDelegate();

		fileStatusDetails =
			naccsDelegateObj.getDailyNACCSGenerationRecords(naccsSearchBean);
		PaxTraxLog.logDebug(
			"getFileStatusDetails  size is "
				+ fileStatusDetails.getNaccsSubmissionResultBeanList().size());
		PaxTraxLog.logDebug(
			"PaxTrax::DailyNACCSGenerationAction::getFileStatusDetails::End");

		return (fileStatusDetails);
	}

	/**
		 * It gets current date  
		 * Method getCurrentDate.
		 * @param 
		 * @return String 
		 * @throws 
		 */
	private String getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE);
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);

		String currentDate = "";
		currentDate =
			""
				+ year
				+ "/"
				+ (month < 10 ? "0" + month : "" + month)
				+ "/"
				+ (day < 10 ? "0" + day : "" + day);

		return (currentDate);
	}

}
