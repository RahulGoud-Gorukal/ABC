package com.dfs.paxtrax.customs.service;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.business.NACCSBO;
import com.dfs.paxtrax.customs.business.NACCSBOHome;
import com.dfs.paxtrax.customs.exception.NACCSException;
import com.dfs.paxtrax.customs.valueobject.NACCSFileBean;
import com.dfs.paxtrax.customs.valueobject.NACCSFileSearchBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.NaccsParameterBean;
import com.dfs.paxtrax.customs.valueobject.DailyNACCSGenerationBean;

/**
 * This is delegate class which performs jndi lookup and it act as a point of 
 * entry for business methods.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 * 06/06/2007	Vijay			Added a new method for CR changes
 * 06/14/2007  	Uma D			Added a new method for CR changes 
 * 07/28/2007 	Uma D			Added a new method for CR changes 
 */

public class NACCSDelegate {
	private ServiceLocator serviceLocator = null;
	private NACCSBOHome naccsBOHome = null;
	private NACCSBO naccsBO = null;

	public NACCSDelegate() {
	}

	/**
	* Method getNaccsSubmissionRecords.
	* @param searchBean
	* @return ArrayList
	* @throws PaxTraxSystemException
	*/
	public ArrayList getNaccsSubmissionRecords(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate:getNaccsSubmissionRecords()::Begin");
		ArrayList searchRecordList = new ArrayList();
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate::getNaccsSubmissionRecords(): B4 Calling Business Method -- searchRecordList =naccsBO.getNaccsSubmissionDetails(naccsSearchBean);");
			searchRecordList =
				naccsBO.getNaccsSubmissionDetails(naccsSearchBean);
			PaxTraxLog.logDebug(
				"NACCSDelegate:getNaccsSubmissionRecords(): After Calling Business Method -- searchRecordList =naccsBO.getNaccsSubmissionDetails(naccsSearchBean);");
			if (searchRecordList != null) {
				PaxTraxLog.logDebug(
					"NACCSDelegate:getNaccsSubmissionRecords(): Generated List Size is "
						+ searchRecordList.size());
			}
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:getNaccsSubmissionRecords(): Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate:getNaccsSubmissionRecords()::End");
		return searchRecordList;
	}

	/**
	 * Method getNaccsSummaryRecords.
	 * @param searchBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getNaccsSummaryRecords(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::getNaccsSummaryRecords::Begin");
		ArrayList searchRecordList = new ArrayList();

		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate:getNaccsSummaryRecords():B4 Calling Business Method -- searchRecordList = naccsBO.getNaccsSummaryDetails(naccsSearchBean);");
			searchRecordList = naccsBO.getNaccsSummaryDetails(naccsSearchBean);
			PaxTraxLog.logDebug(
				"NACCSDelegate:getNaccsSummaryRecords():After Calling Business Method -- searchRecordList = naccsBO.getNaccsSummaryDetails(naccsSearchBean);");

			if (searchRecordList != null) {
				PaxTraxLog.logDebug(
					"NACCSDelegate:getNaccsSummaryRecords():Generated List Size is "
						+ searchRecordList.size());
			}
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:getNaccsSummaryRecords():Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::getNaccsSummaryRecords::End");
		return searchRecordList;
	}

	/*
	 * Jndi call to get NACCSBOHome
	 */
	private void jndiCall() throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax:NACCSDelegate:jndiCall()::Begin");
		try {
			serviceLocator = ServiceLocator.getInstance();
			PaxTraxLog.logDebug(
				"NACCSDelegate:jndiCall():Service Locator Instance Got");
			naccsBOHome =
				(NACCSBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						PaxTraxConstants.NACCS_BO_BEAN_JNDI),
					NACCSBOHome.class);
			PaxTraxLog.logDebug("NACCSDelegate:jndiCall():Home Object Got");
		} catch (NamingException ne) {
			PaxTraxLog.logError(
				"NACCSDelegate:jndiCall(): Naming Exception Caught",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		if (naccsBOHome == null) {
			throw new PaxTraxSystemException(
				PaxTraxConstants.NACCS_BO_HOME_NOT_FOUND);
		}
		try {
			naccsBO = naccsBOHome.create();
		} catch (CreateException ce) {
			PaxTraxLog.logError(
				"NACCSDelegate:jndiCall(): Create Exception Caught - ",
				ce);
			throw new PaxTraxSystemException(ce);
		} catch (RemoteException re) {

			PaxTraxLog.logError(
				"NACCSDelegate:jndiCall():Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::jndiCall::End");
	}

	/**
	 * Method searchFlight.
	 * @param searchBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchFlight(NACCSFileSearchBean searchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::searchFlight::Begin");
		ArrayList searchResults = null;
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate:searchFlight():B4 Calling Business Method -- searchResults = naccsBO.searchFlight(searchBean);");
			searchResults = naccsBO.searchFlight(searchBean);
			PaxTraxLog.logDebug(
				"NACCSDelegate:searchFlight():After Calling Business Method -- searchResults = naccsBO.searchFlight(searchBean);");
			if (searchResults != null) {
				PaxTraxLog.logDebug(
					"NACCSDelegate:searchFlight():Generated List Size is "
						+ searchResults.size());
			}
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:searchFlight():Remote Exception Caught -",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::searchFlight::End");
		return searchResults;
	}

	/**
	 * Generates NACCS File for the flights
	 * @param flightBeanList List of flights for which NACCS file has to 
	 * be generated
	 * @return ArrayList - List of generated flight details
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * a problem in generating NACCS file
	 */
	public ArrayList generateNACCSFile(ArrayList flightList)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::generateNACCSFile()::Begin");
		ArrayList generatedList = null;
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate:generateNACCSFile(): B4 Calling Business Method -- generatedList = naccsBO.generateNACCSFile(flightList);");

			generatedList = naccsBO.generateNACCSFile(flightList);
			PaxTraxLog.logDebug(
				"NACCSDelegate:generateNACCSFile(): After Calling Business Method -- generatedList = naccsBO.generateNACCSFile(flightList);");
			if (generatedList != null) {
				PaxTraxLog.logDebug(
					"NACCSDelegate:generateNACCSFile(): Generated List Size is "
						+ generatedList.size());
			}

		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:generateNACCSFile(): Remote Exception Caught -  ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::generateNACCSFile::End");
		return generatedList;
	}

	/**
	 * Selects all flights for the current date for naccs file generation
	 * @param generationFrequency Frequency at which NACCS file is generated
	 * @return ArrayList List of selected flights
	 * @throws RemoteException This exception is thrown if there is problem
	 * in invoking bean
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in retrieving flights
	 */
	public ArrayList generateNACCSForScheduler(int generationFrequency)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::generateNACCSForScheduler::Begin");
		ArrayList generatedList = null;
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate:generateNACCSForScheduler(): B4 Calling Business Method -- generatedList = naccsBO.generateNACCSForScheduler(generationFrequency);");

			generatedList =
				naccsBO.generateNACCSForScheduler(generationFrequency);
			PaxTraxLog.logDebug(
				"NACCSDelegate:generateNACCSForScheduler(): After Calling Business Method -- generatedList = naccsBO.generateNACCSForScheduler(generationFrequency);");

			if (generatedList != null) {
				PaxTraxLog.logDebug(
					"NACCSDelegate:generateNACCSForScheduler(): Generated List Size is "
						+ generatedList.size());
			}

		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:generateNACCSForScheduler(): Remote Exception Caught -",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::generateNACCSForScheduler::End");
		return generatedList;
	}
	/**
	 * Method naccsEntryNumberUpload.
	 * @param searchBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public boolean naccsEntryNumberUpload(String essrcDir, String esmvDir)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::naccsEntryNumberUpload::Begin");
		boolean success = false;

		jndiCall();

		try {

			PaxTraxLog.logDebug(
				"NACCSDelegate:naccsEntryNumberUpload(): B4 Calling Business Method --success = naccsBO.naccsEntryNumberUpload(essrcDir, esmvDir); ");
			success = naccsBO.naccsEntryNumberUpload(essrcDir, esmvDir);
			PaxTraxLog.logDebug(
				"NACCSDelegate:naccsEntryNumberUpload(): After Calling Business Method --success = naccsBO.naccsEntryNumberUpload(essrcDir, esmvDir); Sucess Value is  "
					+ success);

		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:naccsEntryNumberUpload(): Remote Exception Caught -",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::naccsEntryNumberUpload::End");
		return success;
	}

	/**
	 * Method LTSUpload.
	 * @throws PaxTraxSystemException
	 */
	public void LTSUpload() throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate: LTSUpload(): Begin ");
		boolean flag = false;

		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate: LTSUpload(): B4 Calling Business Method --flag = naccsBO.LTSUpload(); ");
			flag = naccsBO.LTSUpload();
			PaxTraxLog.logDebug(
				"NACCSDelegate: LTSUpload(): After Calling Business Method --flag = naccsBO.LTSUpload(); flag Value is "
					+ flag);
		} catch (RemoteException rex) {
			PaxTraxLog.logError(
				"NACCSDelegate: LTSUpload(): Remote Exception - ",
				rex);
		}

	}

	/**
	 * Returns FTP parameters
	 * @return FTPConfig object
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * a problem in getting ftp parameters
	 */
	public FTPConfig getNACCSFTPParameters() throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::getNACCSFTPParameters::Begin");
		FTPConfig ftpConfig = null;
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate:getNACCSFTPParameters(): B4 Calling Business Method --ftpConfig = naccsBO.getNACCSFTPParameters() ");
			ftpConfig = naccsBO.getNACCSFTPParameters();
			PaxTraxLog.logDebug(
				"NACCSDelegate:getNACCSFTPParameters(): After Calling Business Method --ftpConfig = naccsBO.getNACCSFTPParameters() ");
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:getNACCSFTPParameters(): Exception Caught - NACCSDelegate - getNACCSFTPParameters",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDelegate::getNACCSFTPParameters::End");
		return ftpConfig;
	}

	/**
	 * Updates status for the given pax file
	 * @param fileName Pax file for which transaction status needs to be 
	 * updated
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in updating status
	 */
	public void updateStatus(String fileName) throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::updateStatus::Begin");
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"NACCSDelegate:updateStatus(): B4 Calling Business Method --naccsBO.updateStatus(fileName) ");
			naccsBO.updateStatus(fileName);
			PaxTraxLog.logDebug(
				"NACCSDelegate:updateStatus(): After Calling Business Method --naccsBO.updateStatus(fileName) ");
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:updateStatus(): Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::updateStatus::End");
	}

	public boolean checkPaxExists(String fileName)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::checkPaxExists::Begin");
		jndiCall();
		boolean paxExists = false;

		try {
			paxExists = naccsBO.checkPaxExists(fileName);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate:checkPaxExists(): Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::checkPaxExists::End");
		return paxExists;
	}

	/**
	 * Returns a list of nabco summary report beans.
	 * @param departureDate the flight departure date
	 * @return ArrayList the list of nabco summary report beans
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList getNabcoSummaryReport(String departureDate)
		throws PaxTraxSystemException {

		PaxTraxLog.logDebug("NACCSDelegate: getNabcoSummaryReport() : Begin");
		jndiCall();
		ArrayList nabcoReportList = null;
		try {
			nabcoReportList = naccsBO.getNabcoReportDetails(departureDate);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate: getNabcoSummaryReport(): Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate: getNabcoSummaryReport() : End");
		return nabcoReportList;
	}

	/**
	 * Returns a list of naccs Duplicate Pax Report Beans.
	 * @param NACCSSearchBean which contains search criteria
	 * @return ArrayList the list of naccs duplicate Pax Result Beans
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList searchNACCSDuplicatePaxDetails(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {

		PaxTraxLog.logDebug(
			"NACCSDelegate: searchNACCSDuplicatePaxDetails() : Begin");
		jndiCall();
		ArrayList naccsDuplicatePaxReportList = null;
		try {
			naccsDuplicatePaxReportList =
				naccsBO.searchDuplicatePaxDetails(naccsSearchBean);
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"NACCSDelegate: searchNACCSDuplicatePaxDetails(): Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"NACCSDelegate: searchNACCSDuplicatePaxDetails() : End");
		return naccsDuplicatePaxReportList;
	}

	public void mergePAX(NACCSSearchBean naccsSearchBean)
		throws NACCSException, PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate: mergePAX() : Begin");
		jndiCall();
		try {
			naccsBO.mergePax(naccsSearchBean);
		} catch (RemoteException e) {
			PaxTraxLog.logError(
				"NACCSDelegate: mergePAX()::Remote Exception Caught - ",
				e);
			throw new PaxTraxSystemException(e);
		}
		PaxTraxLog.logDebug("NACCSDelegate: mergePAX() : End");
	}

	/**
		 * Copy details into the database by 
		 * delegating the request to  manager bean. 
		 * @param locationBean LocationBean object
		 * @throws PaxTraxSystemException
		 */
	public void ltsuploadCopyData() throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate::ltsuploadCopyData()::Begin");
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsBO.ltsuploadCopyData();
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate::ltsuploadCopyData()::End");
	}

	public ArrayList getDutyFreePaidMonthlySummaryDetails(String salesMonth)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"NACCSDelegate::getDutyFreePaidMonthlySummaryDetails()::Start");
		ArrayList monthlySummaryList = null;
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			monthlySummaryList =
				naccsBO.getDutyFreePaidMonthlySummaryDetails(salesMonth);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"NACCSDelegate::getDutyFreePaidMonthlySummaryDetails()::End");
		return monthlySummaryList;
	}

	public ArrayList getNaccsFileName(String paxNumber)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate::getNaccsFileName()::Start");
		ArrayList naccsFileList = null;
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsFileList = naccsBO.getNaccsFileName(paxNumber);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate::getNaccsFileName()::End");
		return naccsFileList;
	}

	public NACCSFileBean getPostCodeAddress(NACCSFileBean paxBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate::getPostCodeAddress()::Start");
		NACCSFileBean naccsFileBean = null;
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsFileBean = naccsBO.getPostCodeAddress(paxBean);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate::getPostCodeAddress()::End");
		return naccsFileBean;
	}

	public NaccsParameterBean getNaccsParameters()
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate::getNaccsParameters()::Start");
		NaccsParameterBean naccsParameterBean = null;
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsParameterBean = naccsBO.getNaccsParameters();
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate::getNaccsParameters()::End");
		return naccsParameterBean;
	}

	public void updateNACCS(ArrayList naccsList)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate::updateNACCS()::Start");
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsBO.updateNACCS(naccsList);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate::updateNACCS()::End");
	}

	public void updateTransactions(ArrayList paxList, String status)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("NACCSDelegate::updateTransactions()::Start");
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsBO.updateTransactions(paxList, status);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("NACCSDelegate::updateTransactions()::End");
	}

	/* Code added as part of SR 1042 - International DF Sale Enhancement */
	/* Code added on July 21, 2006 */
	/* Scheduled Flight query changed to filter out International Flights */
	//International DF Sale, LTS Import Declaration Number Upload Scheduler

	/**
	 * Send International DF Sale Import Declaration Numbers to LTS (AS400) 
	 * delegating the request to  manager bean. 
	 * @param
	 * @throws PaxTraxSystemException
	 */
	public void sendIntlImportDeclarationNumbersToAS400()
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"NACCSDelegate::sendIntlImportDeclarationNumbersToAS400()::Begin");
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsBO.sendIntlImportDeclarationNumbersToAS400();
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"NACCSDelegate::sendIntlImportDeclarationNumbersToAS400()::End");
	}

	/* Code added on July 21, 2006 ends */

	//	Added  for CR-251 on 6-Jun-2007	 For DailyNACCSGeneration Report

			/** gets the NACCS File Details
			* Method getDailyNACCSGenerationRecords.
			* @param searchBean
			* @return ArrayList
			* @throws PaxTraxSystemException
			*/
	public DailyNACCSGenerationBean getDailyNACCSGenerationRecords(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax:NACCSDelegate:getDailyNACCSGenerationRecords()::Begin");
		DailyNACCSGenerationBean searchRecordList =
			new DailyNACCSGenerationBean();
		jndiCall();

		try {
			PaxTraxLog.logDebug(
				"PaxTrax:NACCSDelegate::getDailyNACCSGenerationRecords(): B4 Calling Business Method -- searchRecordList =naccsBO.getDailyNACCSGenerationDetails(naccsSearchBean);");
			searchRecordList =
				naccsBO.getDailyNACCSGenerationDetails(naccsSearchBean);
			PaxTraxLog.logDebug(
				"PaxTrax:NACCSDelegate:getDailyNACCSGenerationRecords(): After Calling Business Method -- searchRecordList =naccsBO.getDailyNACCSGenerationDetails(naccsSearchBean);");
			if (searchRecordList != null) {
				PaxTraxLog.logDebug(
					"PaxTrax:NACCSDelegate:getDailyNACCSGenerationRecords(): Generated List Size is "
						+ searchRecordList
							.getNaccsSubmissionResultBeanList()
							.size());
			}
		} catch (RemoteException re) {
			PaxTraxLog.logError(
				"PaxTrax:NACCSDelegate:getDailyNACCSGenerationRecords(): Remote Exception Caught - ",
				re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax:NACCSDelegate:getDailyNACCSGenerationRecords()::End");
		return searchRecordList;
	}

	//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report
	
	
	/* Method added on July 28, 2007 for CR 250 changes Begin*/
	
	/** update the Naccs file generation status for the flights
	* Method updateFlightStatus.
	* @param flightList
	* @throws PaxTraxSystemException
	*/
	public void updateFlightStatus(ArrayList flightList,String status,String userId)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::updateFlightStatus()::Start");
		if (naccsBOHome == null) {
			jndiCall();
		}
		try {
			naccsBO.updateFlightStatus(flightList,status,userId);
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::NACCSDelegate::updateFlightStatus()::End");
	}
	/* Method added on July 28, 2007 for CR 250 changes End*/	
}
