// Source file: com/dfs/paxtrax/customs/valueobject/BankWorkingHoursVO.java

package com.dfs.paxtrax.customs.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class BankWorkingHoursVO extends PaxTraxValueObject{
    private boolean dayOfTheWeek = false;
    private String bankOpenHrs = null;
    private String bankOpenMins = null;
    private String bankCloseHrs = null;
    private String bankCloseMins = null;

	/**
	 * Returns the bankCloseHrs.
	 * @return int
	 */
	public String getBankCloseHrs() {
		return bankCloseHrs;
	}

	/**
	 * Returns the bankCloseMins.
	 * @return int
	 */
	public String getBankCloseMins() {
		return bankCloseMins;
	}

	/**
	 * Returns the bankOpenHrs.
	 * @return int
	 */
	public String getBankOpenHrs() {		
		return bankOpenHrs;
	}

	/**
	 * Returns the bankOpenMins.
	 * @return int
	 */
	public String getBankOpenMins() {
		return bankOpenMins;
	}

	/**
	 * Returns the dayOfTheWeek.
	 * @return String
	 */
	public boolean getDayOfTheWeek() {
		return dayOfTheWeek;
	}

	/**
	 * Sets the bankCloseHrs.
	 * @param bankCloseHrs The bankCloseHrs to set
	 */
	public void setBankCloseHrs(String bankCloseHrs) {
		this.bankCloseHrs = bankCloseHrs;
	}

	/**
	 * Sets the bankCloseMins.
	 * @param bankCloseMins The bankCloseMins to set
	 */
	public void setBankCloseMins(String bankCloseMins) {
		this.bankCloseMins = bankCloseMins;
	}

	/**
	 * Sets the bankOpenHrs.
	 * @param bankOpenHrs The bankOpenHrs to set
	 */
	public void setBankOpenHrs(String bankOpenHrs) {
		this.bankOpenHrs = bankOpenHrs;
	}

	/**
	 * Sets the bankOpenMins.
	 * @param bankOpenMins The bankOpenMins to set
	 */
	public void setBankOpenMins(String bankOpenMins) {
		this.bankOpenMins = bankOpenMins;
	}

	/**
	 * Sets the dayOfTheWeek.
	 * @param dayOfTheWeek The dayOfTheWeek to set
	 */
	public void setDayOfTheWeek(boolean dayOfTheWeek) {
		this.dayOfTheWeek = dayOfTheWeek;
	}

}
