package com.dfs.paxtrax.customs.action;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.NACCSReportForm;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NACCSSubmissionResultBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSummaryResultBean;
/**
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class NACCSReportAction extends PaxTraxAction
{
	/**
	 * Forwards to search  inquriesReportsPage
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward inquiriesReportsPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
    	PaxTraxLog.logDebug("PaxTrax::NACCSReportAction::inquiriesReportsPage::Begin");
        PaxTraxLog.logDebug("PaxTrax::NACCSReportAction::inquiriesReportsPage::End");
		return mapping.findForward(PaxTraxConstants.ENQUIRY_REPORT_PAGE);
	}
	
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::NACCSReportAction::changeLanguage::Begin");
      
        String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		super.changeLanguage(request, language, country);
          PaxTraxLog.logDebug("PaxTrax::NACCSReportAction::changeLanguage::End");
		return mapping.findForward(PaxTraxConstants.ENQUIRY_REPORT_PAGE);
	}

}
