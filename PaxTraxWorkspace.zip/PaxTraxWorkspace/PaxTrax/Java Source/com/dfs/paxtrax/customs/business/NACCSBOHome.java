package com.dfs.paxtrax.customs.business;
/**
 * Home interface for Enterprise Bean: NACCSBO
 */
public interface NACCSBOHome extends javax.ejb.EJBHome
{
	/**
	 * Creates a default instance of Session Bean: NACCSBO
	 */
	public com.dfs.paxtrax.customs.business.NACCSBO create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
