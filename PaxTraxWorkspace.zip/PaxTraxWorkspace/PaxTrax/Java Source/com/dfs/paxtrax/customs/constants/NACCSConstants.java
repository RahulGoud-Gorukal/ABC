package com.dfs.paxtrax.customs.constants;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


/**
 * NACCS related constants.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 09/06/2004	P.C.Sathish		Created
 * 12/06/2008	Ajit			Modified for CR 708
 */

public class NACCSConstants {
	/* Change for CR 708 on 12-jun-2008 begin . remove string other than "OTA"  */
	public static final String FILE_HEADER = "   OTA                                                                                                                                                                                                                                                                                                                                                                                                        ";
	/* Change for CR 708 on 12-jun-2008 end  */
	public static final String TRANSACTION_IDENTIFIER = "C";
	public static final String BONDED_WARE_HOUSE_CODE = "9IW10";
	public static final String BP_APPLICATION_CODE = "9X";
	public static final String FLIGHT_TYPE = "D";
	public static final String BASIS_OF_TARIFF_IDENTIFIER = "Y";
	public static final String CLASSIFICATION_OF_COO = "R";
	//added for CA#422982 by David starts here
	 public static final String IDENTIFICATION_CODE_BANK_ACC_NO = "R";
	//added for CA#422982 by David ends here
	//added for CA#405297 by David starts here
	//public static final String TAX_CONSUMPTION_CODE = "F1";
	public static final String TAX_CONSUMPTION_CODE = "F2";
	//added for CA#405297 by David ends here
	public static final String QUANTITY_UNIT_CODE_1 = "ml";
	public static final String NON_SCHEDULED_YES = "Y";
	public static final String NON_SCHEDULED_NO = "N";
	//added for CA#290863 by vignesh starts here
	public static final String VESSEL_NON_SCHEDULED_YES = "Y";
	public static final String VESSEL_NON_SCHEDULED_NO = "N";
	public static final String VESSEL_NON_SCHEDULED_AIRLINE_CODE = "SHP";
	//added for CA#290863 by vignesh ends here
	public static final String NON_SCHEDULED_AIRLINE_CODE = "ZZZ";
	public static final String NON_SCHEDULED_FLIGHT_NO = "999";
	public static final String PAXTRAX_DATE_FORMAT = "yyyy-MM-dd";
	public static final String PLU_DATE_FORMAT = "yyMMdd";
	public static final String DUTY_TYPE = "1";
	public static final int PAX_NO_START_INDEX = 10;
	public static final int PAX_NO_END_INDEX = 19;
	public static final int PAX_NO_LENGTH = 10;
	public static final int NACCS_FILE_NAME_LENGTH = 21;
	public static final int LESS_THAN =  1;
	public static final int LESS_THAN_OR_EQUAL = 2;
	public static final int GREATER_THAN = 3;
	public static final int GREATER_THAN_OR_EQUAL = 4;
	public static final String STR_LESS_THAN = "LT";
	public static final String STR_LESS_THAN_OR_EQUAL = "LE";
	public static final String STR_GREATER_THAN = "GT";
	public static final String STR_GREATER_THAN_OR_EQUAL = "GE";	
	public static final String TAX_TYPE_CHAR = "L";
	public static final int ALCOHOL_STRGTH_MULTIPLICATION_FACTOR = 10;
	public static final int FLOOR_HUNDRED = 100;
	public static final int FLOOR_THOUSAND = 1000;
	public static final int CONSUMPTION_CODE_NUMERAL = 0;
	public static final String PRODUCT_DESCRIPTION_TYPE = "P";
	public static final String SUBDIVISION_DESCRIPTION_TYPE = "S";
	public static final int SALES_SKU_DEPARTMENT = 11;
	public static final int SALES_SKU_CLASS = 104;
	public static final String WINE_CONSUMPTION_CODE = "L061100000";
	public static final int ADDRESS_LENGTH = 73;
	public static final String PICKED_UP_BY_CUSTOMER = "2";
	public static final String DUTY_FREE_SALE = "1";
	public static final int STATUS_PICKED_UP_BY_CUSTOMER = 2;
	public static final int STATUS_SOLD = 1;
	public static final String TRANSACTION_TYPE_SALE = "Sale";
	public static final String TRANSACTION_TYPE_REFUND = "Refund";
	public static final String TRANSACTION_TYPE_SALE_CONSTANT = "S";
	public static final String TRANSACTION_TYPE_REFUND_CONSTANT1 = "F";
	public static final String TRANSACTION_TYPE_REFUND_CONSTANT2 = "P";
	public static final int REKEY_LOCATION=999;

	//public static final String NACBO_AMOUNT_FORMAT= "#,###";
}
