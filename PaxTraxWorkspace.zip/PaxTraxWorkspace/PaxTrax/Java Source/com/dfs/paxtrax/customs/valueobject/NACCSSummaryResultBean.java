package com.dfs.paxtrax.customs.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class NACCSSummaryResultBean extends PaxTraxValueObject {

	private String flightNo = null;
	private int noofFilesSubmitted = 0;
	private int noofFilesGenerated = 0;
	private int noofFilesAcnowledged = 0;
	private String departureDate = null;
	private String airLineCodeId = null;
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */
	private String departureDateTime = null;
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */

	/**
	 * Returns the flightNo.
	 * @return String
	 */
	public String getFlightNo() {
		return flightNo;
	}

	/**
	 * Returns the noofFilesAcnowledged.
	 * @return int
	 */
	public int getNoofFilesAcnowledged() {
		return noofFilesAcnowledged;
	}

	/**
	 * Returns the noofFilesGenerated.
	 * @return int
	 */
	public int getNoofFilesGenerated() {
		return noofFilesGenerated;
	}

	/**
	 * Returns the noofFilesSubmitted.
	 * @return int
	 */
	public int getNoofFilesSubmitted() {
		return noofFilesSubmitted;
	}

	/**
	 * Sets the flightNo.
	 * @param flightNo The flightNo to set
	 */
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	/**
	 * Sets the noofFilesAcnowledged.
	 * @param noofFilesAcnowledged The noofFilesAcnowledged to set
	 */
	public void setNoofFilesAcnowledged(int noofFilesAcnowledged) {
		this.noofFilesAcnowledged = noofFilesAcnowledged;
	}

	/**
	 * Sets the noofFilesGenerated.
	 * @param noofFilesGenerated The noofFilesGenerated to set
	 */
	public void setNoofFilesGenerated(int noofFilesGenerated) {
		this.noofFilesGenerated = noofFilesGenerated;
	}

	/**
	 * Sets the noofFilesSubmitted.
	 * @param noofFilesSubmitted The noofFilesSubmitted to set
	 */
	public void setNoofFilesSubmitted(int noofFilesSubmitted) {
		this.noofFilesSubmitted = noofFilesSubmitted;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * Returns the airLineCodeId.
	 * @return String
	 */
	public String getAirLineCodeId() {
		return airLineCodeId;
	}

	/**
	 * Sets the airLineCodeId.
	 * @param airLineCodeId The airLineCodeId to set
	 */
	public void setAirLineCodeId(String airLineCodeId) {
		this.airLineCodeId = airLineCodeId;
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */

	/**
	 * Returns Flight Departure time
	 */
	public String getDepartureDateTime() {
		return departureDateTime;
	}

	/**
	 * Sets Flight Departure time
	 */
	public void setDepartureDateTime(String string) {
		departureDateTime = string;
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
}
