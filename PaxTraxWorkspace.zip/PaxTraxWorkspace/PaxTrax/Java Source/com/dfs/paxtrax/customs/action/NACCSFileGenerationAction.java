package com.dfs.paxtrax.customs.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxConfigFileException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxConfig;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.NACCSFileGenerationForm;
import com.dfs.paxtrax.customs.constants.NACCSConstants;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.ItemBean;
import com.dfs.paxtrax.customs.valueobject.NACCSFileBean;
import com.dfs.paxtrax.customs.valueobject.NACCSFileSearchBean;
import com.dfs.paxtrax.customs.valueobject.NaccsActualPriceComparator;
import com.dfs.paxtrax.customs.valueobject.NaccsParameterBean;

/**
 * This action class handles flight search and NACCS file generation
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Vaikundamurthy	Created
 * 06/14/2006	Uma D			Modified for CR changes
 * 07/28/2007 	Uma D			Modified for CR changes
 * 06/12/2008 	Ajit			Modified for CR 708 changes 
 */

public class NACCSFileGenerationAction extends PaxTraxAction {
	//Forward page
	private String forward = null;

	/**
	 * Forwards to naccsFileGenerationPage.
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward naccsFileGenerationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		NACCSFileGenerationForm naccsFileGenerationForm =
			(NACCSFileGenerationForm) form;
		NACCSFileSearchBean searchBean = new NACCSFileSearchBean();
		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.CUSTOMS);

		searchBean.setFlightNumber(null);
		searchBean.setDepartureDate(null);
		naccsFileGenerationForm.setNaccsFileSearchBean(searchBean);
		ReferenceDataDelegate referenceDataDelegate =
			new ReferenceDataDelegate();
		ArrayList airlineCodes =
			referenceDataDelegate.loadReferenceData(
				PaxTraxConstants.AIRLINE_CODE);
		naccsFileGenerationForm.setAirlineCodes(airlineCodes);
		ArrayList time = new ArrayList();
		for (int i = 0; i < 24; i++) {
			if (i < 10) {
				time.add("0" + i);
			} else {
				time.add("" + i);
			}
		}
		naccsFileGenerationForm.setHours(time);
		time = new ArrayList();
		for (int i = 0; i < 60; i++) {
			if (i < 10) {
				time.add("0" + i);
			} else {
				time.add("" + i);
			}
		}
		naccsFileGenerationForm.setMinutes(time);
		return mapping.findForward(PaxTraxConstants.NACCS_FILE_GENERATION_PAGE);
	}

	/**
	 * Forwards to naccsFileGenerationPage.
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward searchFlight(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		try {
			int pageNumber = 0;
			ArrayList allNaccsRecords = null;
			ArrayList currentRecords = null;
			String pageNumberStr = null;
			NACCSFileGenerationForm naccsFileGenerationForm =
				(NACCSFileGenerationForm) form;
			NACCSFileSearchBean searchBean =
				naccsFileGenerationForm.getNaccsFileSearchBean();
			if (searchBean.getAirlineCodeId().equals("-1")) {
				searchBean.setAirlineCodeId("");
			}
			if (searchBean.getDepartureTimeInHour().equals("-1")) {
				searchBean.setDepartureTimeInHour("");
			}
			if (searchBean.getDepartureTimeInMin().equals("-1")) {
				searchBean.setDepartureTimeInMin("");
			}
			HttpSession session = request.getSession();

			pageNumberStr =
				request.getParameter(PaxTraxConstants.NACCS_PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;
			if ((pageNumberStr != null)) {
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0)) {
				int size = 0;
				pageNumber = 1;

				NACCSDelegate naccsDelegate = new NACCSDelegate();
				allNaccsRecords = naccsDelegate.searchFlight(searchBean);

				/* To be commented later  */

				if (allNaccsRecords != null) {
					size = allNaccsRecords.size();
				}
				session.removeAttribute(PaxTraxConstants.ALL_NACCS_RECORDS);
				session.setAttribute(
					PaxTraxConstants.ALL_NACCS_RECORDS,
					allNaccsRecords);
				session.removeAttribute(
					PaxTraxConstants.SIZE_OF_ALL_NACCS_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_NACCS_RECORDS,
					Integer.toString(size));

			} else {
				allNaccsRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_NACCS_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			if ((allNaccsRecords != null) && (allNaccsRecords.size() != 0)) {

				// Get records to be displayed for the passed page number
				currentRecords =
					helper.getCurrentTableContent(
						allNaccsRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
			}
			request.setAttribute(
				PaxTraxConstants.NACCS_PAGE_NUMBER,
				Integer.toString(pageNumber));

			//Sets records to be displayed for the page number 
			naccsFileGenerationForm.setFlightCollection(currentRecords);

			if ((currentRecords == null) || (currentRecords.size() == 0)) {
				request.setAttribute(
					PaxTraxConstants.RESULT,
					PaxTraxConstants.UPDATE_FAILURE);
			} else {
				request.setAttribute(
					PaxTraxConstants.RESULT,
					PaxTraxConstants.SUCCESS);
				request.setAttribute(
					"recordSize",
					Integer.toString(currentRecords.size()));

			}
		} catch (Exception e) {
			throw new PaxTraxSystemException(e);
		}
		return mapping.findForward(PaxTraxConstants.NACCS_FILE_GENERATION_PAGE);
	}

	/**
	 * Generates NACCS File for the given flights
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown if there is a
	 * problem in generating NACCS File
	 */
	public ActionForward generateNACCSFile(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		PaxTraxLog.logError(
			"INFORMATION::PaxTrax::NACCSFileGenerationAction::"
				+ "generateNACCSFile::Naccs file generation has been enabled in Error for information only");
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::generateNACCSFile::Begin");
		PaxTraxLog.logError(
			"INFORMATION::PaxTrax::NACCSFileGenerationAction::generateNACCSFile::Naccs File generation Starts");
		ArrayList selectedList = null;
		ArrayList naccsList = null;
		NACCSFileSearchBean naccsBean = null;
		ArrayList flightNumberList = null;

		HttpSession session = request.getSession();
		String pageNumber =
			request.getParameter(PaxTraxConstants.NACCS_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.NACCS_PAGE_NUMBER, pageNumber);

		NACCSFileGenerationForm generationForm = (NACCSFileGenerationForm) form;
		ArrayList flightList = generationForm.getFlightCollection();

		if (flightList != null) {
			selectedList = new ArrayList();
			int size = flightList.size();
			int recordSize = size;
			for (int i = 0; i < size; i++) {
				naccsBean = (NACCSFileSearchBean) flightList.get(i);
				if (PaxTraxConstants.YES.equals(naccsBean.getChecked())) {
					selectedList.add(naccsBean);
				}
			}

			NACCSDelegate naccsDelegate = new NACCSDelegate();
			PaxTraxLog.logError(
				"INFORMATION::NACCSFileGenerationAction::generateNACCSFile():: Selected Flight List");

			for (int i = 0; i < selectedList.size(); i++) {
				NACCSFileSearchBean searchBean =
					(NACCSFileSearchBean) flightList.get(i);
				PaxTraxLog.logError(
					"INFORMATION::NACCSFileGenerationAction::generateNACCSFile():  flight - "
						+ searchBean.getAirlineCodeValue()
						+ searchBean.getFlightNumber());
			}

			//			Added on July 28, 2007 for CR 250 changes -- Begin
			String userId =
				(String) session.getAttribute(PaxTraxConstants.USER);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 updating file generated status");
			naccsDelegate.updateFlightStatus(
				selectedList,
				PaxTraxConstants.IN_PROGRESS,
				userId);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After updating file generated status");
			//			Added on July 28, 2007 for CR 250 changes -- End			

			naccsList = naccsDelegate.generateNACCSFile(selectedList);

			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: naccs List"
					+ naccsList);

			int dutyFreeSpendingLimit = 0;
			int hamonizeDenominator = 0;

			try {
				dutyFreeSpendingLimit =
					Integer.parseInt(
						PaxTraxConfig.getProperty(
							"paxtrax.naccs.dutyfree.spendinglimit"));
				hamonizeDenominator =
					Integer.parseInt(
						PaxTraxConfig.getProperty(
							"paxtrax.naccs.hamonizecode.denominator"));
			} catch (PaxTraxConfigFileException e) {
				PaxTraxLog.logError(
					"NACCSFileGenerationAction::generate::Exception "
						+ "while getting property for duty free limit",
					e);
				throw new PaxTraxSystemException(e);
			}
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 groupItems()");
			ArrayList paxList = groupItems(naccsList, dutyFreeSpendingLimit);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After groupItems() paxList"
					+ paxList);
			NaccsParameterBean naccsParameterBean =
				naccsDelegate.getNaccsParameters();
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 Naccs file generation process");
			ArrayList naccsHeaderList =
				generate(
					paxList,
					naccsParameterBean,
					dutyFreeSpendingLimit,
					hamonizeDenominator);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After Naccs file generation process");
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 Nabco consolidation starts");
			getNabcoConsolidatedList(naccsHeaderList, paxList);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After nabco consolidation");
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 insertion of naccs header and naccs details");
			naccsDelegate.updateNACCS(naccsHeaderList);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After insertion of naccs header and naccs details");
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 updating sales transaction status");
			naccsDelegate.updateTransactions(
				paxList,
				PaxTraxConstants.GENERATED);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After updating sales transaction status");

			//			Added on July 28, 2007 for CR 250 changes -- Begin
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: B4 updating file generated status");
			naccsDelegate.updateFlightStatus(
				selectedList,
				PaxTraxConstants.NACCS_GENERATED,
				userId);
			PaxTraxLog.logDebug(
				"NACCSFileGenerationAction::generateNACCSFile():: After updating file generated status");
			//			Added on July 28, 2007 for CR 250 changes -- End

			PaxTraxLog.logError(
				"INFORMATION::NACCSFileGenerationAction::generateNACCSFile():: Generated flight List");
			if (naccsHeaderList != null) {
				flightNumberList = new ArrayList();
				size = naccsHeaderList.size();

				for (int i = 0; i < size; i++) {
					NACCSFileBean headerBean =
						(NACCSFileBean) naccsHeaderList.get(i);
					NACCSFileSearchBean searchBean = new NACCSFileSearchBean();
					searchBean.setAirlineRefId(headerBean.getAirlineRefId());
					searchBean.setFlightNumber(headerBean.getFlightNumber());
					searchBean.setAirlineCodeId(headerBean.getAirlineCodeId());
					searchBean.setAirlineCodeValue(
						headerBean.getAirlineCodeValue());
					searchBean.setDepartureDate(headerBean.getDepartureDate());
					String flight =
						headerBean.getAirlineCodeValue()
							+ headerBean.getFlightNumber();
					if (!flightNumberList.contains(flight)) {
						flightNumberList.add(flight);
						PaxTraxLog.logError(
							"INFORMATION:NACCSFileGenerationAction: generateNACCSFile(): flight - "
								+ flight);
					}
				}

			}

			PaxTraxLog.logError(
				"INFORMATION::NACCSFileGenerationAction::generateNACCSFile(): Total flights for which naccs is generated "
					+ flightNumberList.size());

			if (flightNumberList != null) {
				size = flightNumberList.size();

				session.setAttribute(
					PaxTraxConstants.GENERATED_LIST,
					flightNumberList);
				PaxTraxLog.logDebug(
					"NACCSFileGenerationAction: generateNACCSFile() : "
						+ "flight number list size "
						+ size);
				if (size != 0) {
					ActionMessages messages = new ActionMessages();
					messages.add(
						"record",
						new ActionMessage(
							"" + PaxTraxConstants.NACCS_GENERATED_MESSAGE));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
					request.setAttribute(
						PaxTraxConstants.NACCS_STATUS_MSG,
						"403");
				} else {
					ActionMessages messages = new ActionMessages();
					messages.add(
						"record",
						new ActionMessage(
							"" + PaxTraxConstants.NACCS_FAILURE_MESSAGE));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
					request.setAttribute(
						PaxTraxConstants.NACCS_STATUS_MSG,
						"404");
				}
			} else {
				session.setAttribute(
					PaxTraxConstants.GENERATED_LIST,
					new ArrayList());
				ActionMessages messages = new ActionMessages();
				messages.add(
					"record",
					new ActionMessage(
						"" + PaxTraxConstants.NACCS_FAILURE_MESSAGE));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(PaxTraxConstants.NACCS_STATUS_MSG, "404");
			}
			request.setAttribute(
				PaxTraxConstants.CONFIRM_MESSAGE,
				PaxTraxConstants.TRUE);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			request.setAttribute("recordSize", Integer.toString(recordSize));
		}
		PaxTraxLog.logError(
			"INFORMATION::PaxTrax::NACCSFileGenerationAction::generateNACCSFile::Naccs file generation Ends");
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::generateNACCSFile::End");
		return mapping.findForward(PaxTraxConstants.NACCS_FILE_GENERATION_PAGE);

	}

	/**
	 * Used for language toggle
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::changeLanguage::Begin");
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String pageNumber = request.getParameter("pno");
		String result = request.getParameter("res");
		String confirm = request.getParameter(PaxTraxConstants.CONFIRM_MESSAGE);
		HttpSession session = request.getSession();
		if (confirm != null) {
			if (PaxTraxConstants.TRUE.equals(confirm)) {
				ArrayList generatedList =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.GENERATED_LIST);
				if ((generatedList != null) && (generatedList.size() != 0)) {
					ActionMessages messages = new ActionMessages();
					messages.add(
						"record",
						new ActionMessage(
							"" + PaxTraxConstants.NACCS_GENERATED_MESSAGE));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
												  request.setAttribute(

									PaxTraxConstants.NACCS_STATUS_MSG,

									"403");

				} else {
					ActionMessages messages = new ActionMessages();
					messages.add(
						"record",
						new ActionMessage(
							"" + PaxTraxConstants.NACCS_FAILURE_MESSAGE));
					request.setAttribute(Globals.MESSAGE_KEY, messages);
												  request.setAttribute(

									PaxTraxConstants.NACCS_STATUS_MSG,

									"404");

				}
				request.setAttribute(
					PaxTraxConstants.CONFIRM_MESSAGE,
					PaxTraxConstants.TRUE);
			}
		}
		if (language != null && country != null && result != null) {
			super.changeLanguage(request, language, country);
			forward = PaxTraxConstants.NACCS_FILE_GENERATION_PAGE;
		} else {
			forward = PaxTraxConstants.SYSTEM_ERROR;
		}
		NACCSFileGenerationForm naccsForm = (NACCSFileGenerationForm) form;
		ArrayList currentRecords = naccsForm.getFlightCollection();
		if (result.equals(PaxTraxConstants.SUCCESS)) {
			request.setAttribute(
				PaxTraxConstants.NACCS_PAGE_NUMBER,
				pageNumber);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			//request.setAttribute(PaxTraxConstants.CONFIRM_MESSAGE, "false");
			request.setAttribute(
				"recordSize",
				Integer.toString(currentRecords.size()));
		} else if (result.equals(PaxTraxConstants.UPDATE_FAILURE)) {
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.UPDATE_FAILURE);
		}

		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::changeLanguage::End");
		return mapping.findForward(forward);
	}

	/*
	 * Generates NACCS File
	 */
	private ArrayList generate(
		ArrayList paxList,
		NaccsParameterBean naccsParameterBean,
		int dutyFreeSpendingLimit,
		int hamonizeDenominator)
		throws PaxTraxSystemException {
		NACCSDelegate naccsDelegate = new NACCSDelegate();
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::generate::Begin");
		ArrayList naccsHeaderList = null;
		if (paxList != null) {
			int itemPerFile = 0;
			int itemSize = 0;
			int seqId = 1;
			int index = 1;
			int naccsSeqId = 1;
			int noOfFiles = 0;
			long amountOfTariffFreeGoods = 0;
			long totalAmount = 0;
			long dutyFreeAmount = 0;
			String paxNo = null;
			String toBeSentDir = null;
			String fileExtension = null;
			String paxFileName = null;
			String systemDate = null;
			String currentDate = "";
			StringBuffer fileName = null;
			PrintWriter out = null;
			NACCSFileBean paxBean = null;
			NACCSFileBean naccsBean=null;
			NACCSFileBean naccsHeaderBean = null;
			ItemBean naccsDetailBean = null;
			ItemBean itemBean = null;
			ArrayList itemList = null;
			ArrayList naccsDetailList = null;

			// array contains dutyFree amount totals for calculated each file
			long dutyFreeAmountTotals[] = null;

			if (naccsParameterBean != null) {
				itemPerFile = naccsParameterBean.getItemPerFile();
				toBeSentDir = naccsParameterBean.getToBeSentDir();
				fileExtension = naccsParameterBean.getFileExtension();
				currentDate = naccsParameterBean.getCurrentDate();

				naccsHeaderList = new ArrayList();
				naccsDetailList = new ArrayList();

				int size = paxList.size();
				
				for (int i = 0; i < size; i++) {
					amountOfTariffFreeGoods = 0;
					noOfFiles = 0;
					seqId = 1;
					index = 1;
					naccsSeqId = 1;
					
					fileName = new StringBuffer();
					paxBean = (NACCSFileBean) paxList.get(i);
					// Sets the actual price based on the discount list
					//naccsDaoHelper.setActualPrice(itemList);
					itemList = paxBean.getItemDetails();
					itemList = arrangeBasisofIdentifier(itemList);
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: generate():Printing out items after consolidation ");
					//naccsHelper.printItems(itemList);
					if (itemList != null) {
						itemSize = itemList.size();
					}
					if ((itemSize % itemPerFile) == 0) {
						noOfFiles = itemSize / itemPerFile;
					} else {
						noOfFiles = (itemSize / itemPerFile) + 1;
					}

					if (itemSize == 0) {
						continue;
					}
					
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: generate(): File details - No of Files : "
							+ itemSize
							+ "/ itemPerFile : "
							+ itemPerFile
							+ " = "
							+ noOfFiles);
					
					dutyFreeAmountTotals = new long[noOfFiles];
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: generate(): dutyFreeAmountTotals length "
							+ dutyFreeAmountTotals.length
							+ " item size = "
							+ itemSize);
					
					final int DUTY_FREE_AMOUNT = dutyFreeSpendingLimit;
					totalAmount = 0;
					//							getPaxTotals(
					//								Long.parseLong(paxBean.getPaxSeqId()),
					//								paxBean.getPaxNumber());
					ArrayList naccsFileNameList =
						naccsDelegate.getNaccsFileName(paxBean.getPaxNumber());
					seqId = getMaximumSequenceId(naccsFileNameList);
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: generate():Got Sequence id "
							+ seqId);
					seqId++;

					int dutyFreeAmountCount = 0;
					long price = 0l;
					
					for (int j = 0; j < itemSize; j++) {
						itemBean = (ItemBean) itemList.get(j);
						// In generate method
						if (!NACCSConstants
							.BASIS_OF_TARIFF_IDENTIFIER
							.equals(itemBean.getBasisOfTariffIdentifier())) {
							price = itemBean.getNaccsActualUnitPrice();
							totalAmount =
								totalAmount
									+ (price * itemBean.getItemQuantity());

							// Code added on 2005/12/08. Change made to declare correct tariff total in the naccs file.
							if (((j + 1) % itemPerFile) == 0) {
								//System.out.println(
									//"File Amount " + totalAmount);
								dutyFreeAmountTotals[dutyFreeAmountCount] =
									totalAmount;
								dutyFreeAmountCount++;
							}
							
	/*commented added for CR708*/ 						
	//						itemBean.setIsoCountryCode("");
	
						} else if (
							NACCSConstants.BASIS_OF_TARIFF_IDENTIFIER.equals(
								itemBean.getBasisOfTariffIdentifier())) {
							//totalAmount = DUTY_FREE_AMOUNT;
							dutyFreeAmountTotals[dutyFreeAmountCount] =
								totalAmount;
							break;
						}
					}

					for (int count = dutyFreeAmountCount;
						count < dutyFreeAmountTotals.length;
						count++) {
						dutyFreeAmountTotals[count] = totalAmount;
					}

					dutyFreeAmountCount = 0;
					paxNo = formatPaxNo(paxBean.getPaxNumber());
					
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: generate(): PAX NO = "
							+ paxBean.getPaxNumber()
							+ ",  formatted PAX NO = "
							+ paxNo);

					paxFileName =
						paxBean.getAirlineCodeValue()
							+ paxBean.getFlightNumber()
							+ currentDate
							+ paxNo;
					
					String formattedFileName = paxFileName + seqId;
					paxBean.setStoreComents(paxFileName + seqId);
					fileName.append(toBeSentDir);
					fileName.append("/");
					fileName.append(paxFileName);
					fileName.append(seqId);
					fileName.append(".");
					fileName.append(fileExtension);
					PaxTraxLog.logError(
						"INFORMATION::PaxTrax::NACCSFileGenerationAction: generate() : Naccs File name "
							+ paxFileName
							+ seqId);
					try {
						out =
							new PrintWriter(
								new BufferedWriter(
									new FileWriter(fileName.toString())));
						paxBean.setPaxFileName(fileName.toString());
					} catch (IOException ioe) {
						PaxTraxLog.logError(
							"PaxTrax::NACCSFileGenerationAction: generate() : IOException occured ",
							ioe);
						throw new PaxTraxSystemException(ioe);
					}

					out.println(paxBean.getCommonItem()); // line 1
					out.println(paxBean.getImportDeclarationNo());
					// line 2
					out.println(paxBean.getTransactionIdentifier());
					// line 3
					out.println(paxBean.getCustomOfficeCode()); // line 4
					out.println(paxBean.getDepartmentCode()); // line 5
					out.println(paxBean.getPassengerName()); // line 6
					out.println(paxBean.getPostCode()); // line 7
					paxBean = naccsDelegate.getPostCodeAddress(paxBean);
					boolean postCodeExists = paxBean.isPostCodeExists();
					
					
					/*String address =
						getFormattedAddress(paxBean, postCodeExists);
						out.println(address); // line 8*/
						
					/* Added for CR 708 on 12 jun 2008 begin*/							
					if (postCodeExists) {
						out.println(paxBean.getPrefectureCode()); //line 8
						out.println(paxBean.getCity()); //line 9
						out.println(paxBean.getArea()); //line 10
						out.println(paxBean.getAddressLine1()); //line 11
					} else {
							String cityPre=paxBean.getCity();
							String city="";
							cityPre=cityPre.trim();
		
							if(cityPre.indexOf(" ")!=-1)
							{
								city=cityPre.substring(0,cityPre.indexOf(" "));
								cityPre=cityPre.substring(cityPre.indexOf(" "),cityPre.length());
							}
							else
							 city=cityPre;

							if(cityPre.indexOf(" ")!=-1)
							{
								out.println(cityPre.substring(cityPre.indexOf(" ")+1,cityPre.length())); //line 8
							}
							else
							out.println("");	 //line 8
		
						out.println(city); //line 9
						out.println(paxBean.getAddressLine2()); //line 10
						out.println(paxBean.getAddressLine1()); //line 11

							}
					/* Added for CR 708 on 12 jun 2008 end*/		
				//added for CA#290863 by vignesh starts here
					if (paxBean
						.getNonScheduled()
						.equals(NACCSConstants.NON_SCHEDULED_YES)) {
							if(paxBean.getVesselNonScheduled().equals("Y"))
							{
								
								out.println(NACCSConstants.VESSEL_NON_SCHEDULED_AIRLINE_CODE);
							}
							else
							{
								out.println(NACCSConstants.NON_SCHEDULED_AIRLINE_CODE);
							}
						// line 12
					} else {
						out.println(paxBean.getAirlineCode()); // line 12
					}
					//added for CA#290863 by vignesh ends here
					if (paxBean
						.getNonScheduled()
						.equals(NACCSConstants.NON_SCHEDULED_YES)) {
								out.println(NACCSConstants.NON_SCHEDULED_FLIGHT_NO);
						// line 13
					} else {
						out.println(paxBean.getFlightNumber()); // line 13
					}
					out.println(paxBean.getBondedWarehouseCode()); // line 14
					//out.println(""); // line 15
					//added for CA#422982 by David starts here
					out.println(NACCSConstants.IDENTIFICATION_CODE_BANK_ACC_NO); // line 15
                   //added for CA#422982 by David ends here

					//out.println(paxBean.getPrefectureCode()); // line 16
					out.println(paxBean.getBankAccountNo()); // line 16
					out.println(paxBean.getBpApplicationCode()); // line 17
					out.println(paxBean.getSecurityRegistrationCode());	// line 18

										
					out.println(""); // line 19
					if (paxBean
						.getNonScheduled()
						.equals(NACCSConstants.NON_SCHEDULED_YES)) {
							if(paxBean.getVesselNonScheduled().equals("Y"))
							{
								
								out.println(paxBean.getVesselName());
							}
							else
							{
								out.println(paxBean.getAirlineCode() + paxBean.getFlightNumber());
							}
						// line 20
					} else {
						out.println(paxBean.getCustomsComments());
						// line 20
					}

					out.println(paxBean.getStoreComents()); // line 21
					out.println(paxBean.getOtherComments()); // line 22
					out.println(paxBean.getPaxNumber()); // line 23

					//For naccs header table
					naccsHeaderBean = new NACCSFileBean();
					naccsHeaderBean.setPaxFileName(paxFileName + seqId);
					naccsHeaderBean.setPaxNumber(paxBean.getPaxNumber());
					naccsHeaderBean.setAirlineRefId(paxBean.getAirlineRefId());
					naccsHeaderBean.setAirlineCodeId(
						paxBean.getAirlineCodeId());
					naccsHeaderBean.setAirlineCodeValue(
						paxBean.getAirlineCodeValue());
					naccsHeaderBean.setFlightNumber(paxBean.getFlightNumber());
					naccsHeaderBean.setFlightType(NACCSConstants.FLIGHT_TYPE);
					naccsHeaderBean.setImportDeclarationNo(
						paxBean.getImportDeclarationNo());
					naccsHeaderBean.setDepartureDate(
						paxBean.getDepartureDate());

					/* CR 253 Added to display Flight Departure time in Customs Report : starts  */

					naccsHeaderBean.setFlightDepartureTime(
						paxBean.getFlightDepartureTime());

					/* CR 253 Added to display Flight Departure time in Customs Report : ends  */

					naccsHeaderBean.setTransactionNoList(
						paxBean.getTransactionNoList());

					for (int j = 0; j < itemSize; j++) {
						itemBean = (ItemBean) itemList.get(j);
						PaxTraxLog.logDebug(
							"PaxTrax::NACCSFileGenerationAction: generate() : index>itemPerFile "
								+ index
								+ " > "
								+ itemPerFile);
						if (index > itemPerFile) {
							// Multiple files

							out.flush();
							out.close();
							seqId++;
							formattedFileName = paxFileName + seqId;
							fileName = new StringBuffer();
							fileName.append(toBeSentDir);
							fileName.append("/");
							fileName.append(paxFileName);
							fileName.append(seqId);
							fileName.append(".");
							fileName.append(fileExtension);
							PaxTraxLog.logError(
								"INFORMATION::PaxTrax::NACCSFileGenerationAction: generate() : Naccs File name "
									+ paxFileName
									+ seqId);
							//added for CA#290863 by vignesh starts here
							/*	StringBuffer fileName2 = new StringBuffer();
										fileName2.append("C:\\Users\\221219\\Desktop\\xmls\\"+paxFileName+seqId+"."+fileExtension);
					
												System.out.println("file name:"+fileName2.toString());
												 */
							//added for CA#290863 by vignesh starts here
							try {
								out =
									new PrintWriter(
										new BufferedWriter(
											new FileWriter(
								fileName.toString())));
							} catch (IOException ioe) {
								throw new PaxTraxSystemException(ioe);
							}
							paxBean.setStoreComents(paxFileName + seqId);
							out.println(paxBean.getCommonItem()); // line 1
							out.println(paxBean.getImportDeclarationNo());
							// line 2
							out.println(paxBean.getTransactionIdentifier());
							// line 3
							out.println(paxBean.getCustomOfficeCode());
							// line 4
							out.println(paxBean.getDepartmentCode());
							// line 5
							out.println(paxBean.getPassengerName());
							// line 6
							out.println(paxBean.getPostCode()); // line 7
							paxBean = naccsDelegate.getPostCodeAddress(paxBean);
							postCodeExists = paxBean.isPostCodeExists();
									
							/*String address =
								getFormattedAddress(paxBean, postCodeExists);
							out.println(address); // line 8*/
		
							/* Added for CR 708 on 12 jun 2008 begin*/							
							if (postCodeExists) {
								out.println(paxBean.getPrefectureCode()); //line 8
								out.println(paxBean.getCity()); //line 9
								out.println(paxBean.getArea()); //line 10
								out.println(paxBean.getAddressLine1()); //line 11
							} else {
									String cityPre=paxBean.getCity();
									String city="";
									cityPre=cityPre.trim();
		
									if(cityPre.indexOf(" ")!=-1)
									{
										city=cityPre.substring(0,cityPre.indexOf(" "));
										cityPre=cityPre.substring(cityPre.indexOf(" "),cityPre.length());
									}
									else
									city=cityPre;

									if(cityPre.indexOf(" ")!=-1)
									{
										out.println(cityPre.substring(cityPre.indexOf(" ")+1,cityPre.length())); //line 8
									}
									else
									out.println("");	 //line 8
		
								out.println(city); //line 9
								out.println(paxBean.getAddressLine2()); //line 10
								out.println(paxBean.getAddressLine1()); //line 11

									}
							/* Added for CR 708 on 12 jun 2008 end*/	
							
							
							

							if (paxBean
								.getNonScheduled()
								.equals(NACCSConstants.NON_SCHEDULED_YES)) {
								out.println(
									NACCSConstants.NON_SCHEDULED_AIRLINE_CODE);
								// line 12
							} else {
								out.println(paxBean.getAirlineCode());
								// line 12
							}
							if (paxBean
								.getNonScheduled()
								.equals(NACCSConstants.NON_SCHEDULED_YES)) {
								out.println(
									NACCSConstants.NON_SCHEDULED_FLIGHT_NO);
								// line 13

							} else {
								out.println(paxBean.getFlightNumber());
								// line 13
							}

							out.println(paxBean.getBondedWarehouseCode());
							// line 14

							//out.println(paxBean.getPrefectureCode());
					//out.println(""); // line 15
					//added for CA#422982 by David starts here
					out.println(NACCSConstants.IDENTIFICATION_CODE_BANK_ACC_NO); // line 15
                   //added for CA#422982 by David ends here
							out.println(paxBean.getBankAccountNo()); // line 16
							out.println(paxBean.getBpApplicationCode());
							// line 17
							out.println(paxBean.getSecurityRegistrationCode());
							// line 18
							
							if (dutyFreeAmountCount
								< dutyFreeAmountTotals.length) {
								totalAmount =
									dutyFreeAmountTotals[dutyFreeAmountCount];
								if (totalAmount == 0) {
									PaxTraxLog.logDebug("PaxTrax::NACCSFileGenerationAction: generate() : pagenext: if 0"+totalAmount);
									out.println(""); // line 19
								} else {
									PaxTraxLog.logDebug("PaxTrax::NACCSFileGenerationAction: generate() : pagenext: if "+totalAmount);
									out.println(									
										formatTariffFreeAmount(totalAmount));
									// line 19
								}

								dutyFreeAmountCount++;
							} else {
								totalAmount = DUTY_FREE_AMOUNT;
								if (totalAmount == 0) {
									PaxTraxLog.logDebug("PaxTrax::NACCSFileGenerationAction: generate() : pagenext: else 0"+totalAmount);
									out.println(""); // line 19
								} else {
									PaxTraxLog.logDebug("PaxTrax::NACCSFileGenerationAction: generate() : pagenext: else"+totalAmount);
									out.println(formatTariffFreeAmount(totalAmount)); // line 19 
								}
							}
							
							
							//added for CA#290863 by vignesh starts here
							if (paxBean
									.getNonScheduled()
									.equals(NACCSConstants.NON_SCHEDULED_YES)) {
										if(paxBean.getAirlineCodeValue().equals("SH"))
										{
											out.println(paxBean.getVesselName());
										}
										else
										{
											out.println(paxBean.getAirlineCode() + paxBean.getFlightNumber());
										}
									// line 20
							} else {
									out.println(paxBean.getCustomsComments());
									// line 20

								}
							//added for CA#290863 by vignesh ends here
							
							out.println(paxBean.getStoreComents()); // line 21
							out.println(paxBean.getOtherComments()); // line 22
							out.println(paxBean.getPaxNumber()); // line 23

							//For naccs header table
							naccsHeaderBean.setItemDetails(naccsDetailList);
							naccsHeaderList.add(naccsHeaderBean);

							naccsDetailList = new ArrayList();
							naccsHeaderBean = new NACCSFileBean();
							naccsHeaderBean.setPaxFileName(paxFileName + seqId);
							naccsHeaderBean.setPaxNumber(
								paxBean.getPaxNumber());
							naccsHeaderBean.setAirlineRefId(
								paxBean.getAirlineRefId());
							naccsHeaderBean.setAirlineCodeId(
								paxBean.getAirlineCodeId());
							naccsHeaderBean.setAirlineCodeValue(
								paxBean.getAirlineCodeValue());
							naccsHeaderBean.setFlightNumber(
								paxBean.getFlightNumber());
							naccsHeaderBean.setFlightType(
								NACCSConstants.FLIGHT_TYPE);
							naccsHeaderBean.setImportDeclarationNo(
								paxBean.getImportDeclarationNo());
							naccsHeaderBean.setDepartureDate(
								paxBean.getDepartureDate());
							/* CR 253 Added to display Flight Departure time in Customs Report : starts  */

							naccsHeaderBean.setFlightDepartureTime(
								paxBean.getFlightDepartureTime());

							/* CR 253 Added to display Flight Departure time in Customs Report : ends  */
							naccsHeaderBean.setTransactionNoList(
								paxBean.getTransactionNoList());

							index = 1;
						}
						out.println(itemBean.getBasisOfTariffIdentifier());
						// line 24
						//out.println(itemBean.getMerchandiseControlCode()); // line 25
						out.println(naccsSeqId); // line 25
						out.println(
							itemBean.getMerchandiseControlCode()
								+ " "
								+ itemBean.getDescription());
						// line 26
						out.println(
							formatRetailPrice(
								itemBean.getNaccsActualUnitPrice()));
						// line 27
						out.println(
							formatItemQuantity(itemBean.getItemQuantity()));
						// line 28
						//out.println(itemBean.getArticleCode()); // line 29
						/* Change made to avoid the calculation of the 10th digit of HS code if the item is 
						 * already setup with 10 digit HS code */
					
					 /*change for CR 708 on 12-jun-2008 ,display 9 digits in one line and 10th digit in second line*/					
						if (itemBean.getArticleCode() >= 1000000000)
						{
							PaxTraxLog.logDebug("PaxTrax::NACCSFileGenerationAction::generate() : Harmonise Code "
															+ itemBean.getArticleCode());
							out.println(Long.toString(itemBean.getArticleCode()).substring(0,9)); //line 29
							out.println(Long.toString(itemBean.getArticleCode()).substring(9,10));//line 30
						}
						else {
							out.println(itemBean.getArticleCode());//line 29
							out.println(getNaccsHarmonizeCode(itemBean.getArticleCode(),hamonizeDenominator));//line 30	
					/*change for CR 708 on 12-jun-2008 end*/											
						}
						PaxTraxLog.logDebug(
							"PaxTrax::NACCSFileGenerationAction::generate() : ISO country code "
								+ itemBean.getIsoCountryCode());
						out.println(itemBean.getIsoCountryCode()); // line 31
						out.println(itemBean.getClassificatinOfCOO());
						// line 32
						
						//Added by priya Starts for CO# 13449 - Adding New line "INN" - (International Nonproprietary Name)
						out.println(SQLConstants.BLANK);  //line 33
						//Added by priya Ends for CO# 13449 - Adding New line "INN" - (International Nonproprietary Name)
						
						// itemBean.getQuantity1() gives itemSize
						if (itemBean.getQuantity1().trim().length() > 0) {
							out.println(
								Integer.parseInt(itemBean.getQuantity1())
									* itemBean.getItemQuantity());
							// line 33 //Modified by priya to line 34
						} else {
							out.println(SQLConstants.BLANK); // line 33 //Modified by priya to line 34
						}
						out.println(itemBean.getQuantityUnitCode1());
						// line 34 //Modified by priya to line 35
						out.println(itemBean.getQuantity2()); // line 35 //Modified by priya to line 36
						out.println(itemBean.getQuantityUnitCode2());
						// line 36 //Modified by priya to line 37
						out.println(itemBean.getBasisOfTariff()); // line 37 //Modified by priya to line 38
						out.println(itemBean.getConsumptionTaxCodeClass());
						// line 38 //Modified by priya to line 39
						if (itemBean.getTaxType() != null) {
							//Commented by lakshmy as part of CO20563
							//out.println(NACCSConstants.TAX_CONSUMPTION_CODE);
							//Added by lakshmy as part of CO20563
							out.println(itemBean.getTaxCodeClass());
							// line 39 //Modified by priya to line 40
						} else {
							out.println(""); // line 39 //Modified by priya to line 40
						}

						amountOfTariffFreeGoods =
							amountOfTariffFreeGoods
								+ itemBean.getNaccsActualUnitPrice();

						if (amountOfTariffFreeGoods >= DUTY_FREE_AMOUNT) {
							amountOfTariffFreeGoods = DUTY_FREE_AMOUNT;
						}

						//For naccs file detail table
						naccsDetailBean = new ItemBean();
						naccsDetailBean.setSellingLocation(
							itemBean.getSellingLocation());
						naccsDetailBean.setMerchandiseControlCode(
							itemBean.getMerchandiseControlCode());
						naccsDetailBean.setItemQuantity(
							itemBean.getItemQuantity());
						naccsDetailBean.setNaccsActualUnitPrice(
							itemBean.getNaccsActualUnitPrice());
						naccsDetailBean.setBasisOfTariffIdentifier(
							itemBean.getBasisOfTariffIdentifier());

						naccsDetailList.add(naccsDetailBean);
						index++;
						naccsSeqId++;
					} /** item list **/
					out.flush();
					out.close();
					naccsHeaderBean.setItemDetails(naccsDetailList);
					naccsHeaderList.add(naccsHeaderBean);
					naccsDetailList = new ArrayList();

					// Set the paxTotals
					//						setPaxTotals(
					//							Long.parseLong(paxBean.getPaxSeqId()),
					//							paxBean.getPaxNumber(),
					//							totalAmount);
				} /** pax list */
			}
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::generate()::End");
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::Header end size "
				+ naccsHeaderList.size());
		return naccsHeaderList;
	}

	/**
	 * Arranges basis of identifier with blank identifiers followed by
	 * non blank identifiers
	 * @param itemList the list of items
	 * @return ArrayList the arranged list based on basis of identifier
	 */
	private ArrayList arrangeBasisofIdentifier(ArrayList itemList) {
		ArrayList blankIdentifiers = new ArrayList();
		ArrayList nonblankIdentifiers = new ArrayList();
		int length = itemList.size();
		ItemBean itemBean = null;

		for (int i = 0; i < length; i++) {
			itemBean = (ItemBean) itemList.get(i);
			if (NACCSConstants
				.BASIS_OF_TARIFF_IDENTIFIER
				.equals(itemBean.getBasisOfTariffIdentifier())) {
				nonblankIdentifiers.add(itemBean);
			} else {
				blankIdentifiers.add(itemBean);
			}
		}

		ArrayList fullList = new ArrayList();
		fullList.addAll(blankIdentifiers);
		fullList.addAll(nonblankIdentifiers);

		return fullList;

	}

	/**
	 * Returns the maximum sequence id from a given naccs file list.
	 * @param naccsFileNameList the list of naccs file names
	 * @return int the maximum sequence number.  -1 is returned if the 
	 * 				sequence number should start from 1. This happens if
	 * 				the date is different for the same pax.
	 */
	private int getMaximumSequenceId(ArrayList naccsFileNameList)
		throws PaxTraxSystemException {

		int length = 0;
		int seqNos[] = null;
		if (naccsFileNameList == null) {
			return 0;
		} else {
			length = naccsFileNameList.size();
			if (length == 0) {
				return 0;
			}

			seqNos = new int[length];
			try {
				for (int i = 0; i < length; i++) {
					String naccsFileName = (String) naccsFileNameList.get(i);
					String dateFromNaccsFileName =
						naccsFileName.substring(4, 10);
					Calendar cal1 = Calendar.getInstance();
					SimpleDateFormat dateFormat =
						new SimpleDateFormat("yyyy/MM/dd");
					dateFormat.setCalendar(cal1);

					String currentDate = dateFormat.format(cal1.getTime());
					dateFormat = new SimpleDateFormat("yyMMdd");
					Date formattedDate =
						dateFormat.parse(dateFromNaccsFileName);
					dateFormat = new SimpleDateFormat("yyyy/MM/dd");
					String generatedFileDate = dateFormat.format(formattedDate);

					if (!currentDate.equals(generatedFileDate)) {
						return 0;
					}

					seqNos[i] =
						Integer.parseInt(
							naccsFileName.substring(
								naccsFileName.length() - 1));
					//PaxTraxLog.logDebug("NACCSDAOHelper : getMaximumSequenceId() : got seqNo "+ seqNos[i]);
				}
				Arrays.sort(seqNos);
			} catch (ParseException e) {
				PaxTraxLog.logError(
					"PaxTrax::NACCSFileGenerationAction::getMaximumSequenceId() : "
						+ "ParseException happened while parsing date from naccs file",
					e);
				throw new PaxTraxSystemException(e);
			}
		}

		return (seqNos[seqNos.length - 1]);
	}

	/**
	 * Returns the formatted address based on post code flag.
	 * @param naccsBean the naccs file details bean
	 * @param postCodeExists post code flag
	 * @return String formatted address
	 */
	private String getFormattedAddress(
		NACCSFileBean naccsBean,
		boolean postCodeExists) {
		StringBuffer address = new StringBuffer();
		String formattedAddress = null;
		if (postCodeExists) {
			address.append(naccsBean.getAddressLine1());
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getArea());
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getCity());
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getPrefectureCode());
			/* Code starts-Change done to display the country field in the NACCS File */
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getCountry());
			/* Code ends */
		} else {
			address.append(naccsBean.getAddressLine1());
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getAddressLine2());
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getCity());
			/* Code starts-Change done to display the country field in the NACCS File */
			address.append(SQLConstants.SPACE);
			address.append(naccsBean.getCountry());
			/* Code ends */
		}
		if (address.length() > NACCSConstants.ADDRESS_LENGTH) {
			formattedAddress =
				address.substring(0, NACCSConstants.ADDRESS_LENGTH);
		} else {
			formattedAddress = address.toString();
		}

		return formattedAddress;
	}

	/**
	 * Formats pax no to nine characters.
	 * @param paxNo the pax no
	 * @return String the formatted string
	 * @throws NACCSException
	 */
	private String formatPaxNo(String paxNo) {
		String data = paxNo;
		int length = data.length();
		String formattedString = "";
		boolean failure = false;

		switch (length) {
			case 1 :
				formattedString = "000000000" + data;
				break;
			case 2 :
				formattedString = "00000000" + data;
				break;
			case 3 :
				formattedString = "0000000" + data;
				break;
			case 4 :
				formattedString = "000000" + data;
				break;
			case 5 :
				formattedString = "00000" + data;
				break;
			case 6 :
				formattedString = "0000" + data;
				break;
			case 7 :
				formattedString = "000" + data;
				break;
			case 8 :
				formattedString = "00" + data;
				break;
			case 9 :
				formattedString = "0" + data;
				break;
			case 10 :
				formattedString = data;
				break;

			default :
				failure = true;
				break;
		}

		if (failure) {
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction::formatPaxNo() : Invalid paxNo "
					+ paxNo);
		}
		return formattedString;

	}

	private String formatTariffFreeAmount(long tariffFreeAmount) {
		String data = Long.toString(tariffFreeAmount);
		int length = data.length();
		String formattedString = "";
		/*changed for CR 708 on 12-jun-2008 begin
		 * two spaces added in all cases and case 8 and 9 is newly added
		 *  change from data.substring(0, 7) to data.substring(0, 9) for 9 char amount of Duty free   
		 * */
		
		switch (length) {
			case 1 :
				formattedString = "        " + data;
				break;
			case 2 :
				formattedString = "       " + data;
				break;
			case 3 :
				formattedString = "      " + data;
				break;
			case 4 :
				formattedString = "     " + data;
				break;
			case 5 :
				formattedString = "    " + data;
				break;
			case 6 :
				formattedString = "   " + data;
				break;
			case 7 :
				formattedString = "  "+ data;
				break;
			case 8 :
				formattedString = " "+ data;
				break;
			case 9 :
				formattedString = data;
				break;


			default :
				formattedString = data.substring(0, 9);
				break;
		}
		/*changed  for CR 708 on 12-jun-2008 end*/
		return formattedString;

	}

	private String formatRetailPrice(long retailPrice) {
		String data = Long.toString(retailPrice);
		int length = data.length();
		String formattedString = "";
		/*Changed for CR 708 on 12-jun-2008 begin
		 * single space added in all cases and case 8: is newly added
		 *  change from data.substring(0, 7) to data.substring(0, 8) for 8 char Unit Price   
		 * */
		switch (length) {
			case 1 :
				formattedString = "       " + data;
				break;
			case 2 :
				formattedString = "      " + data;
				break;
			case 3 :
				formattedString = "     " + data;
				break;
			case 4 :
				formattedString = "    " + data;
				break;
			case 5 :
				formattedString = "   " + data;
				break;
			case 6 :
				formattedString = "  " + data;
				break;
			case 7 :
				formattedString = " "+ data;
				break;
			case 8 :
				formattedString = data;
				break;
				
			default :
				formattedString = data.substring(0, 8);
				break;
		}
/*Changed for CR 708 on 12-jun-2008 end*/
		return formattedString;
	}

	private String formatItemQuantity(int quantity) {
		String data = Integer.toString(quantity);
		int length = data.length();
		String formattedString = "";
		/*Changed for CR 708 on 12-jun-2008 begin
		 * single space removed in all cases and case 5,6,7 and 8 are commented
		 *  change from data.substring(0, 8) to data.substring(0, 4) for 4 char Amount   
		 * */

		switch (length) {
			case 1 :
				formattedString = "   " + data;
				break;
			case 2 :
				formattedString = "  " + data;
				break;
			case 3 :
				formattedString = " " + data;
				break;
			case 4 :
				formattedString = data;
				break;
			
		/*	case 5 :
				formattedString = "   " + data;
				break;
			case 6 :
				formattedString = "  " + data;
				break;
			case 7 :
				formattedString = " " + data;
				break;
			case 8 :
				formattedString = data;
				break;*/
				
			default :
				formattedString = data.substring(0, 4);
				break;
/*Changed for CR 708 on 12-jun-2008 end*/				
		}

		return formattedString;
	}

	private long getNaccsHarmonizeCode(
		long harmonizeCode,
		int hamonizeDenominator) {
		double value = ((double) harmonizeCode) / hamonizeDenominator;
		long truncValue = (long) value;
		double diff = value - truncValue;
		long result = Math.round(diff * hamonizeDenominator);
		return result;
	}

	/*
	 * Group items to fit in duty free limit
	 */
	public ArrayList groupItems(
		ArrayList naccsList,
		int dutyFreeSpendingLimit) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::groupItems::Begin");
		NACCSFileBean naccsBean = null;
		ArrayList itemList = null;
		ArrayList formattedItemList = null;
		ItemBean itemBean = null;
		ArrayList groupedItemList = null;
		long totalPrice = 0;
		long price = 0;
		int itemSize = 0;
		long dutyFreeLimit = 0l;
				
		if (naccsList != null) {
			int size = naccsList.size();
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction::groupItems() : naccslist size"
					+ size);
			for (int i = 0; i < size; i++) {
				naccsBean = (NACCSFileBean) naccsList.get(i);
				itemList = naccsBean.getItemDetails();
				totalPrice = 0;

				dutyFreeLimit = dutyFreeSpendingLimit;

				if (itemList != null) {
					//itemList = setItemDiscount(itemList, naccsDiscountList);
					groupedItemList =
						arrangeItems(itemList, dutyFreeSpendingLimit);
					naccsBean.setItemDetails(groupedItemList);
					itemList = naccsBean.getItemDetails();

					itemSize = itemList.size();
					for (int j = 0; j < itemSize; j++) {
						itemBean = (ItemBean) itemList.get(j);
						//
						//						if (itemBean.getDutyAmount() == 0)
						//						{
						//							price = 0;
						//						}
						//						else
						//						{
						//							price = itemBean.getNaccsActualUnitPrice();
						//						}
						price = itemBean.getNaccsActualUnitPrice();
						totalPrice = totalPrice + price;

						//Checks if the total price is within duty free limit

						if (totalPrice > dutyFreeLimit) {
							totalPrice = totalPrice - price;
							itemBean.setBasisOfTariffIdentifier(
								NACCSConstants.BASIS_OF_TARIFF_IDENTIFIER);
							itemBean.setClassificatinOfCOO(
								NACCSConstants.CLASSIFICATION_OF_COO);
						} else {
							/*commented for CR 708*/
							//itemBean.setClassificatinOfCOO(SQLConstants.BLANK);
							/* added for CR 708 begin*/
							itemBean.setClassificatinOfCOO(
								NACCSConstants.CLASSIFICATION_OF_COO);
							/* added for CR 708 end */	
							itemBean.setCountryOfOriginCode(SQLConstants.BLANK);
						}
					}
					naccsBean.setAmountOfTariffFreeGoods(totalPrice);
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: groupItems() : Amount of Tariff FreeGoods "
							+ naccsBean.getAmountOfTariffFreeGoods());
					naccsBean.setUnitItemDetails(naccsBean.getItemDetails());
					formattedItemList = formatItems(naccsBean.getItemDetails());
					naccsBean.setItemDetails(formattedItemList);
				}
			}
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::groupItems::End");
		return naccsList;
	}

	/*
	 * Arranges item by duty in descending order
	 */
	private ArrayList arrangeItems(
		ArrayList itemList,
		int dutyFreeSpendingLimit) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::arrangeItems::Begin");

		int refundSkuNumber = 0;
		ItemBean itemBean = null;
		ItemBean refundItem = null;
		ItemBean unitItem = null;
		ItemBean tempBean1 = null;
		ItemBean tempBean2 = null;
		long refundValue = 0;
		long itemValue = 0;
		ArrayList groupedItemList = null;
		ArrayList refundList = null;
		ArrayList dutyList = null;
		ArrayList descendingList = null;
		ArrayList orderedList = null;
		int index = 1;
		int itemSize = 0;
		int quantity = 0;
		String duty = null;

		if (itemList != null) {
			dutyList = new ArrayList();
			refundList = new ArrayList();
			groupedItemList = new ArrayList();
			orderedList = new ArrayList();

			itemSize = itemList.size();
			for (int j = 0; j < itemSize; j++) {

				itemBean = (ItemBean) itemList.get(j);
				itemValue = itemBean.getItemQuantity();

				try {

					if (itemValue < 0) {

						refundList.add(itemBean.clone());
					} else {
						quantity = itemBean.getItemQuantity();
						//seperate into individual item with quantity one
						for (int i = 0; i < quantity; i++) {
							ItemBean itemBeanCopy = (ItemBean) itemBean.clone();
							itemBeanCopy.setItemQuantity(1);
							groupedItemList.add(itemBeanCopy);
						}
					}

				} catch (CloneNotSupportedException e) {
					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction::arrangeItems() : cloning problem ",
						e);
				}
			}

			//Arranging the items by duty in descending order
			itemSize = groupedItemList.size();
			for (int i = (itemSize - 1); i > 0; i--) {
				itemBean = (ItemBean) groupedItemList.get(i);

				for (int j = 0; j <= i; j++) {
					unitItem = (ItemBean) groupedItemList.get(j);
					if ((itemBean.getDutyAmount())
						> (unitItem.getDutyAmount())) {
						tempBean1 = new ItemBean();
						tempBean2 = new ItemBean();
						tempBean1 = itemBean;
						tempBean2 = unitItem;
						itemBean = tempBean2;
						unitItem = tempBean1;
						groupedItemList.set(i, itemBean);
						groupedItemList.set(j, unitItem);
					}
				}
			}

			itemSize = groupedItemList.size();

			for (int i = 0; i < itemSize; i++) {
				itemBean = (ItemBean) groupedItemList.get(i);

				//Adding distinct duty amount
				if (!dutyList.contains("" + itemBean.getDutyAmount())) {
					dutyList.add("" + itemBean.getDutyAmount());
				}
			}

			quantity = dutyList.size();

			descendingList = new ArrayList();
			NaccsActualPriceComparator naccsPriceComparator =
				new NaccsActualPriceComparator();

			for (int j = 0; j < quantity; j++) {
				duty = (String) dutyList.get(j);
				descendingList.clear();

				for (int i = 0; i < itemSize; i++) {
					itemBean = (ItemBean) groupedItemList.get(i);
					if (("" + itemBean.getDutyAmount()).equals(duty)) {
						descendingList.add(itemBean);
					}
				}

				// Descending by naccs unit price
				Collections.sort(descendingList, naccsPriceComparator);
				Collections.reverse(descendingList);
				orderedList.addAll(descendingList);
				// Ascending by unit price
				//				arrangeInDescending(ascendingList);
				//				index = ascendingList.size();
				//				for (int k = 0; k < index; k++)
				//				{
				//					orderedList.add((ItemBean) ascendingList.get(k));
				//				}
			}

			/* New code added to handle the NACCS File logic revision - April 22, 2005 */
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction::Before getting into the new code");
			if (orderedList != null) {
				PaxTraxLog.logDebug(
					"PaxTrax::NACCSFileGenerationAction::The size of the orderedList is :"
						+ orderedList.size());

				long dutyFreeLimit = dutyFreeSpendingLimit;

				int i = 0;
				long sumOfDutyOfLeft = 0;

				while (i < orderedList.size()) {
					orderedList =
						doNewNACCSGrouping(orderedList, i, dutyFreeLimit);
					sumOfDutyOfLeft = 0; // Avoids unnecessary looping

					for (int j = i + 1; j < orderedList.size(); j++) {
						ItemBean nfc2 = (ItemBean) orderedList.get(j);
						sumOfDutyOfLeft =
							sumOfDutyOfLeft + nfc2.getDutyAmount();
					}

					ItemBean nfc1 = (ItemBean) orderedList.get(i);
					if (sumOfDutyOfLeft <= nfc1.getCalculatedDuty())
						break;

					i++;
				}

				int indexOfBestChoice = findBestChoice(orderedList);
				PaxTraxLog.logDebug(
					"The index of the best choice is :" + indexOfBestChoice);

				if (indexOfBestChoice != -1 && indexOfBestChoice != 0) {
					ItemBean nfc1 =
						(ItemBean) orderedList.get(indexOfBestChoice);
					String bestOrder = nfc1.getOrder();
					StringTokenizer st1 = new StringTokenizer(bestOrder, ",");
					PaxTraxLog.logDebug("The best order is :" + bestOrder);
					PaxTraxLog.logDebug(
						"The accumulated duty is :" + nfc1.getCalculatedDuty());

					int tokenIndex = 0;

					while (st1.hasMoreTokens()) {
						tokenIndex = Integer.parseInt(st1.nextToken());
						ItemBean nfc2 = (ItemBean) orderedList.get(tokenIndex);
						itemBean = null;
						try {
							itemBean = (ItemBean) nfc2.clone();
							orderedList.remove(tokenIndex);
							orderedList.add(0, itemBean);
						} catch (CloneNotSupportedException e) {
							PaxTraxLog.logDebug(
								"PaxTrax::NACCSFileGenerationAction::arrangeItems() : cloning problem ",
								e);
						}

					}

					PaxTraxLog.logDebug(
						"PaxTrax::NACCSFileGenerationAction:: End of new naccs file logic");
				}
			}
		}

		return orderedList;
	}

	/*
	 * Formats the items based on basis of tariff identifier
	 */
	public ArrayList formatItems(ArrayList itemList) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::formatItems::Begin");
		ArrayList formattedList = null;
		ArrayList skuList = null;
		ItemBean itemBean = null;
		ItemBean item = null;
		ItemBean unitItem = null;
		String key = null;
		String skuNumber = null;
		String basisOfTariffIdentifier = null;
		String merchandiseCode = null;
		int quantity1 = 0;
		int quantity2 = 0;
		int pos = 0;
		long price = 0;
		long itemPrice = 0;
		boolean present = true;
		boolean dutyItem = false;
		boolean dutyFreeItem = false;
		if (itemList != null) {
			formattedList = new ArrayList();
			skuList = new ArrayList();
			int size = itemList.size();
			for (int i = 0; i < size; i++) {
				itemBean = (ItemBean) itemList.get(i);
				key =
					itemBean.getMerchandiseControlCode()
						+ "_"
						+ itemBean.getNaccsActualUnitPrice();
				if (key != null) {
					key = key.trim();
				}
				if (!skuList.contains(key)) {
					skuList.add(key);
				}
			}
			int sizeOfSKU = skuList.size();

			for (int i = 0; i < sizeOfSKU; i++) {
				key = (String) skuList.get(i);
				if (key != null) {
					pos = key.indexOf("_");
					skuNumber = key.substring(0, pos);
					price =
						Long.parseLong(key.substring(pos + 1, key.length()));
				}

				for (int j = 0; j < size; j++) {
					item = (ItemBean) itemList.get(j);
					merchandiseCode = "" + item.getMerchandiseControlCode();
					if (merchandiseCode != null) {
						merchandiseCode = merchandiseCode.trim();
					}
					itemPrice = item.getNaccsActualUnitPrice();

					if ((skuNumber.equals(merchandiseCode))
						&& (price == itemPrice)) {

						if (present) {
							itemBean = item;
							present = false;
						}
						basisOfTariffIdentifier =
							item.getBasisOfTariffIdentifier();

						if ((basisOfTariffIdentifier == null)
							|| (!"Y".equals(basisOfTariffIdentifier))) {
							dutyFreeItem = true;
							quantity1++;
		/*Added for CR708 begin*/					
							itemBean.setIsoCountryCode(
								item.getIsoCountryCode());
		/*Added for CR708 end*/							
							
						} else if ("Y".equals(basisOfTariffIdentifier)) {
							itemBean.setCountryOfOriginCode(
								item.getCountryOfOriginCode());
							itemBean.setIsoCountryCode(
								item.getIsoCountryCode());
							dutyItem = true;
							quantity2++;
						}
					}
				}

				if (!present) {
					if (dutyFreeItem) {
						unitItem = new ItemBean();
						unitItem.setSellingLocation(
							itemBean.getSellingLocation());
						unitItem.setArticleCode(itemBean.getArticleCode());
						unitItem.setBasisOfTariff(itemBean.getBasisOfTariff());
						unitItem.setBasisOfTariffIdentifier("");
						unitItem.setConsumptionTaxCodeClass(
							itemBean.getConsumptionTaxCodeClass());
						unitItem.setTaxCodeClass(itemBean.getTaxCodeClass()); //Added by lakshmy as part of CO20563
						unitItem.setMerchandiseControlCode(
							itemBean.getMerchandiseControlCode());
						unitItem.setDescription(itemBean.getDescription());
						unitItem.setNaccsActualUnitPrice(
							itemBean.getNaccsActualUnitPrice());
						unitItem.setItemQuantity(quantity1);
						unitItem.setQuantity1(itemBean.getQuantity1());
						unitItem.setQuantityUnitCode1(
							itemBean.getQuantityUnitCode1());
						unitItem.setQuantity2(itemBean.getQuantity2());
						unitItem.setQuantityUnitCode2(
							itemBean.getQuantityUnitCode2());
						unitItem.setDutyAmount(itemBean.getDutyAmount());
						unitItem.setCountryOfOriginCode(SQLConstants.BLANK);
						unitItem.setIsoCountryCode(
							itemBean.getIsoCountryCode());
						/* commented for CR 708*/
						//unitItem.setClassificatinOfCOO(SQLConstants.BLANK);
						/* Added for CR 708 begin*/
						unitItem.setClassificatinOfCOO(NACCSConstants.CLASSIFICATION_OF_COO);
						/*Added for CR 708 end*/
						unitItem.setTransactionLineNumber(
							itemBean.getTransactionLineNumber());
						unitItem.setTransactionNumber(
							itemBean.getTransactionNumber());
						unitItem.setTaxType(itemBean.getTaxType());
						formattedList.add(unitItem);
					}
					if (dutyItem) {
						unitItem = new ItemBean();
						unitItem.setSellingLocation(
							itemBean.getSellingLocation());
						unitItem.setArticleCode(itemBean.getArticleCode());
						unitItem.setBasisOfTariff(itemBean.getBasisOfTariff());
						unitItem.setBasisOfTariffIdentifier("Y");
						unitItem.setConsumptionTaxCodeClass(
							itemBean.getConsumptionTaxCodeClass());
						unitItem.setTaxCodeClass(itemBean.getTaxCodeClass()); //Added by lakshmy as part of CO20563
						unitItem.setMerchandiseControlCode(
							itemBean.getMerchandiseControlCode());
						unitItem.setDescription(itemBean.getDescription());
						unitItem.setNaccsActualUnitPrice(
							itemBean.getNaccsActualUnitPrice());
						unitItem.setItemQuantity(quantity2);
						unitItem.setQuantity1(itemBean.getQuantity1());
						unitItem.setQuantityUnitCode1(
							itemBean.getQuantityUnitCode1());
						unitItem.setQuantity2(itemBean.getQuantity2());
						unitItem.setQuantityUnitCode2(
							itemBean.getQuantityUnitCode2());
						unitItem.setDutyAmount(itemBean.getDutyAmount());

						unitItem.setCountryOfOriginCode(
							itemBean.getCountryOfOriginCode());
						unitItem.setIsoCountryCode(
							itemBean.getIsoCountryCode());
						unitItem.setClassificatinOfCOO("R");
						unitItem.setTransactionLineNumber(
							itemBean.getTransactionLineNumber());
						unitItem.setTransactionNumber(
							itemBean.getTransactionNumber());
						unitItem.setTaxType(itemBean.getTaxType());
						formattedList.add(unitItem);
					}
					dutyItem = false;
					dutyFreeItem = false;
					present = true;
					quantity1 = 0;
					quantity2 = 0;
				}
			}
		}

		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction::formatItems::End");
		return formattedList;
	}

	/* New Method added to get the best item grouping - New Logic - April 22, 2005 */
	public ArrayList doNewNACCSGrouping(
		ArrayList orderedList,
		int index,
		long dutyFreeLimit) {
		ItemBean nfc1 = (ItemBean) orderedList.get(index);
		long accumulatedPrice = nfc1.getNaccsActualUnitPrice();
		long accumulatedDuty = 0;
		String order = null;

		int j = index;
		PaxTraxLog.logDebug(
			"In the doNewNACCSGrouping method for index :" + index);
		PaxTraxLog.logDebug("The duty free limit is :" + dutyFreeLimit);

		if (accumulatedPrice <= dutyFreeLimit) {
			accumulatedPrice = 0;

			while (j < orderedList.size()) {
				ItemBean nfc2 = (ItemBean) orderedList.get(j);
				//printPropertiesOfItem(nfc2);

				accumulatedPrice =
					accumulatedPrice + nfc2.getNaccsActualUnitPrice();

				if (accumulatedPrice <= dutyFreeLimit) {
					accumulatedDuty = accumulatedDuty + nfc2.getDutyAmount();
					if (order != null)
						order = order + "," + j;
					else
						order = "" + j;
				} else
					accumulatedPrice =
						accumulatedPrice - nfc2.getNaccsActualUnitPrice();

				j++;
			}

			PaxTraxLog.logDebug(
				"The Accumulated duty amount is :" + accumulatedDuty);

			nfc1.setCalculatedDuty(accumulatedDuty);
			nfc1.setOrder(order);
			orderedList.set(index, nfc1);
		}

		return (orderedList);
	}

	/* Method to find the ItemBean which when taken as base will provide the best duty amount */
	public int findBestChoice(ArrayList orderedList) {
		long maxDuty = 0;
		int indexOfBestChoice = -1;

		for (int j = 0; j < orderedList.size(); j++) {
			ItemBean nfc2 = (ItemBean) orderedList.get(j);
			if (nfc2.getCalculatedDuty() > maxDuty) {
				maxDuty = nfc2.getCalculatedDuty();
				indexOfBestChoice = j;
			}
		}

		return (indexOfBestChoice);
	}

	public void printPropertiesOfItem(ItemBean i1) {
		PaxTraxLog.logDebug("Selling Location :" + i1.getSellingLocation());
		PaxTraxLog.logDebug("Terminal Number :" + i1.getTerminalNumber());
		PaxTraxLog.logDebug("Transaction Number :" + i1.getTransactionNumber());
		PaxTraxLog.logDebug(
			"Original Selling Location" + i1.getSellingLocation());
		PaxTraxLog.logDebug("Orig ter num :" + i1.getOriginalTerminalNumber());
		PaxTraxLog.logDebug(
			"Orig Tran Num :" + i1.getOriginalTransactionNumber());
		PaxTraxLog.logDebug(
			"Basis OF Tariff Identifier :" + i1.getBasisOfTariffIdentifier());
		PaxTraxLog.logDebug(
			"Merchandise Control Code :" + i1.getMerchandiseControlCode());
		PaxTraxLog.logDebug("Description :" + i1.getDescription());
		PaxTraxLog.logDebug("Regular Price :" + i1.getRegularPrice());
		PaxTraxLog.logDebug("Actual Price :" + i1.getActualPrice());
		PaxTraxLog.logDebug("Item Quantity :" + i1.getItemQuantity());
		PaxTraxLog.logDebug("Article Code :" + i1.getArticleCode());
		PaxTraxLog.logDebug(
			"Country Of Origin Code :" + i1.getCountryOfOriginCode());
		PaxTraxLog.logDebug(
			"Classification of COO :" + i1.getClassificatinOfCOO());
		PaxTraxLog.logDebug("Quantity 1 :" + i1.getQuantity1());
		PaxTraxLog.logDebug(
			"Quantity Unit Code 1 :" + i1.getQuantityUnitCode1());
		PaxTraxLog.logDebug("Quantity 2 :" + i1.getQuantity2());
		PaxTraxLog.logDebug(
			"Quantity Unit Code 2 :" + i1.getQuantityUnitCode2());
		PaxTraxLog.logDebug("Basis Of tariff :" + i1.getBasisOfTariff());
		PaxTraxLog.logDebug(
			"Consumption Tax Code Class :" + i1.getConsumptionTaxCodeClass());
		PaxTraxLog.logDebug("Duty Amount :" + i1.getDutyAmount());
		PaxTraxLog.logDebug("Discount List" + i1.getDiscountList());
		PaxTraxLog.logDebug(
			"Tran line number :" + i1.getTransactionLineNumber());
		PaxTraxLog.logDebug("ISO Country Code :" + i1.getIsoCountryCode());
		PaxTraxLog.logDebug(
			"NACCS Actual Unit Price :" + i1.getNaccsActualUnitPrice());
		PaxTraxLog.logDebug("Size :" + i1.getSize());
		PaxTraxLog.logDebug("Tax Type :" + i1.getTaxType());
		PaxTraxLog.logDebug("Alcohol Strength :" + i1.getAlcoholStrength());
		PaxTraxLog.logDebug("Tarif Rate :" + i1.getTariffRate());
		PaxTraxLog.logDebug(
			"harmonize tax Denominator :" + i1.getHarmonizeTaxDenominator());
		PaxTraxLog.logDebug("Consumption Tax :" + i1.getConcumptionTax());
		PaxTraxLog.logDebug(
			"tax Rate Denominator :" + i1.getTaxRateDenominator());
		PaxTraxLog.logDebug("Division Number :" + i1.getDivisionNumber());
		PaxTraxLog.logDebug("Item Unique Key :" + i1.getItemUniqueKey());
		PaxTraxLog.logDebug("Item Department :" + i1.getItemDepartment());
		PaxTraxLog.logDebug("Item Class :" + i1.getItemClass());
		PaxTraxLog.logDebug("PAX Number :" + i1.getPaxNo());
		PaxTraxLog.logDebug("Calculated Duty :" + i1.getCalculatedDuty());
		PaxTraxLog.logDebug("Order :" + i1.getOrder());
	}

	/**
	 * Return nabco consolidated list.
	 * @param naccsHeaderList the naccs header list along with naccs details
	 * @param paxList the list of pax with all item details per pax
	 * @return ArrayList the nabco consolidated list
	 */
	public void getNabcoConsolidatedList(
		ArrayList naccsHeaderList,
		ArrayList paxList)
		throws PaxTraxSystemException {
		try {
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : start ");

			ArrayList paxItemList = consolidateList(paxList);
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : *** Printing pax List ** start");
			printItems(paxItemList);
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : *** Printing pax List ** End");

			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : ***Printing naccs List **Start");
			printNaccsList(naccsHeaderList);
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : ***Printing naccs List ** End");

			ArrayList locationList = new ArrayList();
			int length = paxItemList.size();
			for (int i = 0; i < length; i++) {
				ItemBean unitItemBean = (ItemBean) paxItemList.get(i);
				String location = "" + unitItemBean.getSellingLocation();
				if (!locationList.contains(location)) {
					locationList.add(location);
				}
			}
			PaxTraxLog.logDebug("Locations --> " + locationList);

			int headerCount = naccsHeaderList.size();
			for (int i = 0; i < headerCount; i++) {
				NACCSFileBean fileBean = (NACCSFileBean) naccsHeaderList.get(i);
				ArrayList itemList = fileBean.getItemDetails();
				int quantity = itemList.size();
				int itemCount = itemList.size();

				ArrayList itemDetailsList = new ArrayList();
				boolean debug = false;
				// get the items
				for (int l = 0; l < itemCount; l++) {
					ItemBean itemBean = (ItemBean) itemList.get(l);
					itemBean.setPaxNo(fileBean.getPaxNumber());
					itemDetailsList.addAll(
						getTransactionIdFromUnitItems(
							itemBean,
							paxItemList,
							locationList));
				}
				fileBean.setItemDetails(itemDetailsList);

			} // header list

			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : ***Printing naccs List **Start");
			printNaccsList(naccsHeaderList);
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : ***Printing naccs List ** End");

			PaxTraxLog.logDebug(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : End ");
		} catch (Exception e) {
			PaxTraxLog.logError(
				"PaxTrax::NACCSFileGenerationAction:: getNabcoConsolidatedList() : ",
				e);
			throw new PaxTraxSystemException(e);
		}
	}

	/**
	 * Splits the naccs item if required to fit a 
	 * trasaction id (selling location, terminal no, transaction no)
	 * by comparing with the unit items.
	 * @param itemBean the naccs item
	 * @param unitItemList the unit item list
	 * @param locationList the list of individual locations found in this 
	 * 						unit item list
	 * @return ArrayList
	 */
	public ArrayList getTransactionIdFromUnitItems(
		ItemBean itemBean,
		ArrayList unitItemList,
		ArrayList locationList) {
		/* Code added on December 14, 2005 as part of a bug-fix.
		 * This method is used to associate sales transaction numbers to lines that are declared
		 * on the NACCS files. The way in which TB_NACCS_FILE_DETAIL table was being populated was 
		 * incorrect and hence it necessitated this fix */
		int quantity = 0;
		ArrayList itemDetailsList = new ArrayList();

		String paxNo = itemBean.getPaxNo();
		int sku = itemBean.getMerchandiseControlCode();
		int itemQuantity = itemBean.getItemQuantity();
		long naccsPrice = itemBean.getNaccsActualUnitPrice();
		boolean found = false;
		ItemBean matchItemBean = null;
		int matchQuantity = 0;

		Iterator unitItemIterator = unitItemList.iterator();
		while (unitItemIterator.hasNext()) {
			ItemBean unitItemBean = (ItemBean) unitItemIterator.next();

			if (sku == unitItemBean.getMerchandiseControlCode()
				&& naccsPrice == unitItemBean.getNaccsActualUnitPrice()
				&& (paxNo != null
					&& unitItemBean.getPaxNo() != null
					&& paxNo.equals(unitItemBean.getPaxNo()))) {
				found = false;

				for (int loopCnt = 0;
					loopCnt < itemDetailsList.size();
					loopCnt++) {
					matchItemBean = (ItemBean) itemDetailsList.get(loopCnt);

					if (matchItemBean.getSellingLocation()
						== unitItemBean.getSellingLocation()
						&& matchItemBean.getTerminalNumber()
							== unitItemBean.getTerminalNumber()
						&& matchItemBean.getTransactionNumber()
							== unitItemBean.getTransactionNumber()) {
						found = true;
						matchQuantity = matchItemBean.getItemQuantity();
						matchQuantity++;
						matchItemBean.setItemQuantity(matchQuantity);
						itemDetailsList.set(loopCnt, matchItemBean);
						break;
					}
				}

				if (!found) {
					try {
						ItemBean itemBeanCopy = (ItemBean) itemBean.clone();
						itemBeanCopy.setSellingLocation(
							unitItemBean.getSellingLocation());
						itemBeanCopy.setTerminalNumber(
							unitItemBean.getTerminalNumber());
						itemBeanCopy.setTransactionNumber(
							unitItemBean.getTransactionNumber());
						itemBeanCopy.setItemQuantity(1);
						itemDetailsList.add(itemBeanCopy);
					} catch (CloneNotSupportedException e) {
						PaxTraxLog.logDebug(
							"PaxTrax::NACCSFileGenerationAction::getTransactionIdFromUnitItems():: Clone not supported",
							e);
					}
				}

				unitItemIterator.remove();
				quantity++;

				if (quantity == itemQuantity)
					break;
			}
		}

		/* This code was commented on December 14, 2005 as part of the above mentioned bug-fix.
		int quantity = 0;
		int itemQuantity = itemBean.getItemQuantity();
		ArrayList itemDetailsList = new ArrayList();
		int sku = itemBean.getMerchandiseControlCode();
		int location = 0;
		int terminal = 0;
		int transaction = 0;
		long naccsPrice = itemBean.getNaccsActualUnitPrice();
		String paxNo = itemBean.getPaxNo();
		
		for (int i = 0; i < locationList.size(); i++) {
		
			int sellingLocation = Integer.parseInt((String) locationList.get(i));
			quantity = 0;
			Iterator unitItemIterator = unitItemList.iterator();
			while (unitItemIterator.hasNext()) {
				ItemBean unitItemBean = (ItemBean) unitItemIterator.next();
				int unitSku = unitItemBean.getMerchandiseControlCode();
				long unitNaccsPrice = unitItemBean.getNaccsActualUnitPrice();
				
				if ((sku == unitSku) 
					&& (naccsPrice == unitNaccsPrice) 
					&& (sellingLocation == unitItemBean.getSellingLocation())
					&& (paxNo!=null && unitItemBean.getPaxNo()!=null && paxNo.equals(unitItemBean.getPaxNo()))) {
					location = unitItemBean.getSellingLocation();
					terminal = unitItemBean.getTerminalNumber();
					transaction = unitItemBean.getTransactionNumber();
					quantity++;
					unitItemIterator.remove();
				}
				
				if (itemQuantity == quantity) {
					break;
				}
			}
			if (quantity > 0) {
				try {
					ItemBean itemBeanCopy = (ItemBean) itemBean.clone();
					itemBeanCopy.setSellingLocation(location);
					itemBeanCopy.setTerminalNumber(terminal);
					itemBeanCopy.setTransactionNumber(transaction);
					itemBeanCopy.setItemQuantity(quantity);
					
					itemDetailsList.add(itemBeanCopy);
				} catch (CloneNotSupportedException e) {
					PaxTraxLog.logDebug("PaxTrax::NACCSFileGenerationAction::getTransactionIdFromUnitItems():: Clone not supported", e);
				}
			}
		}
		
		*/

		return itemDetailsList;
	}

	private ArrayList consolidateList(ArrayList naccsList) {
		ArrayList consolidatedList = new ArrayList();

		for (int i = 0; i < naccsList.size(); i++) {
			NACCSFileBean naccsFileBean = (NACCSFileBean) naccsList.get(i);
			String paxNo = naccsFileBean.getPaxNumber();
			ArrayList itemList = naccsFileBean.getUnitItemDetails();
			for (int j = 0; j < itemList.size(); j++) {
				ItemBean itemBean = copyItemBean((ItemBean) itemList.get(j));
				itemBean.setPaxNo(paxNo);
				consolidatedList.add(itemBean);
			}
		}

		return consolidatedList;
	}

	/**
	 * Copies a item bean sku, quantity, tariff identifier, selling location,
	 * terminal number, transaction number properties only.
	 */
	private ItemBean copyItemBean(ItemBean itemBean) {
		ItemBean naccsDetailBean = new ItemBean();
		naccsDetailBean.setMerchandiseControlCode(
			itemBean.getMerchandiseControlCode());
		// set the consolidated quantity
		naccsDetailBean.setItemQuantity(itemBean.getItemQuantity());
		naccsDetailBean.setNaccsActualUnitPrice(
			itemBean.getNaccsActualUnitPrice());
		naccsDetailBean.setBasisOfTariffIdentifier(
			itemBean.getBasisOfTariffIdentifier());
		naccsDetailBean.setSellingLocation(itemBean.getSellingLocation());
		naccsDetailBean.setTerminalNumber(itemBean.getTerminalNumber());
		naccsDetailBean.setTransactionNumber(itemBean.getTransactionNumber());
		return naccsDetailBean;

	}

	public void printItems(ArrayList itemList) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction:: printItems() : Items Start");
		for (int i = 0; i < itemList.size(); i++) {
			ItemBean itemBean = (ItemBean) itemList.get(i);
			PaxTraxLog.logDebug(
				"SKU - "
					+ itemBean.getMerchandiseControlCode()
					+ ", Selling Location "
					+ itemBean.getSellingLocation()
					+ ", Terminal No "
					+ itemBean.getTerminalNumber()
					+ ", transaction number "
					+ itemBean.getTransactionNumber()
					+ ", transaction line "
					+ itemBean.getTransactionLineNumber()
					+ ", Basis of Tariff "
					+ itemBean.getBasisOfTariffIdentifier()
					+ ", Naccs Price "
					+ itemBean.getNaccsActualUnitPrice()
					+ ", item quantity "
					+ itemBean.getItemQuantity()
					+ ", unique key = "
					+ itemBean.getItemUniqueKey());
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction:: printItems() : Items End");
	}

	public void printNaccsList(ArrayList naccsList) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction:: printNaccsList() :*** NaccsList Start");
		for (int i = 0; i < naccsList.size(); i++) {
			NACCSFileBean naccsBean = (NACCSFileBean) naccsList.get(i);
			PaxTraxLog.logDebug(
				"****NACCSDAOHelper: printNaccsList() : File Name "
					+ naccsBean.getPaxFileName());
			PaxTraxLog.logDebug(
				"NACCSDAOHelper: printNaccsList() : Pax Number "
					+ naccsBean.getPaxNumber());
			ArrayList itemList = naccsBean.getItemDetails();
			for (int j = 0; j < itemList.size(); j++) {
				ItemBean itemBean = (ItemBean) itemList.get(j);
				PaxTraxLog.logDebug(
					"NACCSDAOHelper: printNaccsList() : "
						+ " selling location "
						+ itemBean.getSellingLocation()
						+ ", TerminalNumber "
						+ itemBean.getTerminalNumber()
						+ ", Transaction Number "
						+ itemBean.getTransactionNumber()
						+ ", Transaction Line Number "
						+ itemBean.getTransactionLineNumber()
						+ ", Item is "
						+ itemBean.getMerchandiseControlCode()
						+ ", Naccs Price "
						+ itemBean.getNaccsActualUnitPrice()
						+ ", Basis of Tariff "
						+ itemBean.getBasisOfTariffIdentifier()
						+ ", item quantity "
						+ itemBean.getItemQuantity());
			}
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSFileGenerationAction:: printNaccsList() :*** NaccsList End");
	}

}