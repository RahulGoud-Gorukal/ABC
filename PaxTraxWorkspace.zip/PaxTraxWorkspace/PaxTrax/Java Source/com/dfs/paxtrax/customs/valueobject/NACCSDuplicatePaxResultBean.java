package com.dfs.paxtrax.customs.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class NACCSDuplicatePaxResultBean extends PaxTraxValueObject implements Cloneable {
	private String paxSeqId ;
	private String paxNumber;
	private String lastName;
	private String firstName;
	private String transactionType;
	private String transactionNumber;
	private String transactionAmount;
	private String cashierNumber;
	private String transactionDate;
	private String transactionTime;
	private String postCode;
	
	public NACCSDuplicatePaxResultBean() {
	}

	/**
	 * Returns the cashierNumber.
	 * @return String
	 */
	public String getCashierNumber()
	{
		return cashierNumber;
	}

	/**
	 * Returns the firstName.
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Returns the lastName.
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Returns the paxNumber.
	 * @return String
	 */
	public String getPaxNumber()
	{
		return paxNumber;
	}

	/**
	 * Returns the paxSeqId.
	 * @return String
	 */
	public String getPaxSeqId()
	{
		return paxSeqId;
	}

	/**
	 * Returns the transactionAmount.
	 * @return String
	 */
	public String getTransactionAmount()
	{
		return transactionAmount;
	}

	/**
	 * Returns the transactionDate.
	 * @return String
	 */
	public String getTransactionDate()
	{
		return transactionDate;
	}

	/**
	 * Returns the transactionNumber.
	 * @return String
	 */
	public String getTransactionNumber()
	{
		return transactionNumber;
	}

	/**
	 * Returns the transactionTime.
	 * @return String
	 */
	public String getTransactionTime()
	{
		return transactionTime;
	}

	/**
	 * Returns the transactionType.
	 * @return String
	 */
	public String getTransactionType()
	{
		return transactionType;
	}

	/**
	 * Sets the cashierNumber.
	 * @param cashierNumber The cashierNumber to set
	 */
	public void setCashierNumber(String cashierNumber)
	{
		this.cashierNumber = cashierNumber;
	}

	/**
	 * Sets the firstName.
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Sets the lastName.
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Sets the paxNumber.
	 * @param paxNumber The paxNumber to set
	 */
	public void setPaxNumber(String paxNumber)
	{
		this.paxNumber = paxNumber;
	}

	/**
	 * Sets the paxSeqId.
	 * @param paxSeqId The paxSeqId to set
	 */
	public void setPaxSeqId(String paxSeqId)
	{
		this.paxSeqId = paxSeqId;
	}

	/**
	 * Sets the transactionAmount.
	 * @param transactionAmount The transactionAmount to set
	 */
	public void setTransactionAmount(String transactionAmount)
	{
		this.transactionAmount = transactionAmount;
	}

	/**
	 * Sets the transactionDate.
	 * @param transactionDate The transactionDate to set
	 */
	public void setTransactionDate(String transactionDate)
	{
		this.transactionDate = transactionDate;
	}

	/**
	 * Sets the transactionNumber.
	 * @param transactionNumber The transactionNumber to set
	 */
	public void setTransactionNumber(String transactionNumber)
	{
		this.transactionNumber = transactionNumber;
	}

	/**
	 * Sets the transactionTime.
	 * @param transactionTime The transactionTime to set
	 */
	public void setTransactionTime(String transactionTime)
	{
		this.transactionTime = transactionTime;
	}

	/**
	 * Sets the transactionType.
	 * @param transactionType The transactionType to set
	 */
	public void setTransactionType(String transactionType)
	{
		this.transactionType = transactionType;
	}

	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}	

	/**
	 * Returns the postCode.
	 * @return String
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * Sets the postCode.
	 * @param postCode The postCode to set
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

}
