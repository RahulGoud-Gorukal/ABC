package com.dfs.paxtrax.customs.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.StampDutyForm;
import com.dfs.paxtrax.customs.exception.StampDutyException;
import com.dfs.paxtrax.customs.service.StampDutyDelegate;
import com.dfs.paxtrax.customs.valueobject.StampDutyBean;
import com.dfs.paxtrax.sales.service.SalesReportDelegate;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
* This action class is used for calculating stamp duty and printing the report
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 29/06/2004    Joseph Oommen A Created
*/
public class StampDutyAction extends PaxTraxAction
{

	String forward = null;

	/**
	* Forwards to create stamp duty page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to stamp duty page
	*/
	public ActionForward createStampDutyPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		StampDutyForm stampDutyForm = (StampDutyForm) form;
		Calendar cal = Calendar.getInstance(Locale.US);
		SimpleDateFormat formatter = new SimpleDateFormat("MMM yyyy");
		ArrayList monthList = new ArrayList();
		ArrayList locationList = new ArrayList();
		SalesReportDelegate salesReportDelegate = new SalesReportDelegate();
		locationList=salesReportDelegate.listLocations();
		stampDutyForm.setLocationList(locationList);
		for (int i = 0; i < 12; i++)
		{
			ReferenceDataBean referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId(
				(cal.get(Calendar.MONTH) + 1) + "~" + cal.get(Calendar.YEAR));
			referenceDataBean.setCodeValue(formatter.format(cal.getTime()));
			monthList.add(referenceDataBean);
			cal.add(Calendar.MONTH, -1);
		}
		stampDutyForm.setMonthList(monthList);
		StampDutyBean stampDutyBean = new StampDutyBean();
		stampDutyForm.setStampDutyBean(stampDutyBean);
		stampDutyForm.setLocationDescription(null);
		return mapping.findForward(PaxTraxConstants.STAMP_DUTY_REPORT_PAGE);
	}

	/**
	* Forwards to returns stamp duty page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in calculating stamp duty
	*/
	public ActionForward getStampDuty(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		StampDutyForm stampDutyForm = (StampDutyForm) form;
		
		stampDutyForm.setLocationDescription(request.getParameter("location"));

		StampDutyDelegate stampDutyDelegate = new StampDutyDelegate();
		try
		{
			ArrayList stampDutyList =
				stampDutyDelegate.generateStampDuty(
					stampDutyForm.getStampDutyBean());
                    
                    
			if (stampDutyList != null && stampDutyList.size() > 0)
			{
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);
				int totalNumberOfStamps = 0;
				double totalTaxAmount = 0.0;
				for (int i = 0; i < stampDutyList.size(); i++)
				{
					StampDutyBean tempBean =
						(StampDutyBean) stampDutyList.get(i);
					totalNumberOfStamps =
						totalNumberOfStamps + tempBean.getNumberOfStamps();
					totalTaxAmount = totalTaxAmount + tempBean.getTaxAmount();
				}
				stampDutyForm.setStampDutyList(stampDutyList);
				stampDutyForm.setTotalNumberOfStamps(totalNumberOfStamps);
				stampDutyForm.setTotalTaxAmount(totalTaxAmount);
				stampDutyForm.getStampDutyBean().setMonth(
					stampDutyForm.getStampDutyBean().getMonth());

			}
			else
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.LOCATION_ERROR,
					new ActionMessage(
						"" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.ERRORCODE,
					"" + PaxTraxConstants.STAMP_DUTY__NO_RECORDS_FOUND);
			}
			forward = PaxTraxConstants.STAMP_DUTY_REPORT_PAGE;
		}
		catch (StampDutyException stampDutyException)
		{
			stampDutyException.printStackTrace();
		}
		catch (Exception ex)
		{
			PaxTraxLog.logError("Exacption caught ", ex);
			forward = PaxTraxConstants.REPORT_ERROR;

		}
		return mapping.findForward(forward);
	}

	/**
	* Forwards to print stamp duty page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to printing stamp duty page
	*/
	public ActionForward printStampDutyPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		StampDutyForm stampDutyForm = (StampDutyForm) form;
		ArrayList stampDutyList = stampDutyForm.getStampDutyList();
		try
		{
			if (stampDutyList != null)
			{
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);
				StampDutyBean stampDutyBean = stampDutyForm.getStampDutyBean();
				if (stampDutyBean != null)
				{
					String month = request.getParameter("month");

					String yearId = null;
					if (month != null)
					{
						
						StringTokenizer tokenizer =
							new StringTokenizer(month, "~");
						String monthId = (String) tokenizer.nextToken();
						if (tokenizer.hasMoreTokens())
						{
							yearId = (String) tokenizer.nextToken();
						}
						Calendar cal = Calendar.getInstance();
						SimpleDateFormat formatter =
							new SimpleDateFormat("MMM yyyy");

						cal.set(Calendar.MONTH, Integer.parseInt(monthId) - 1);
						cal.set(Calendar.YEAR, Integer.parseInt(yearId));
						month = formatter.format(cal.getTime());

					}
					
					StampDutyBean newBean = new StampDutyBean();
					newBean.setLocation(stampDutyBean.getLocation());
					newBean.setMonth(month);
					stampDutyForm.setStampDutyBean(newBean);
				}
			}
			stampDutyForm.setStampDutyList(stampDutyList);
			forward = PaxTraxConstants.STAMP_DUTY_PRINT_PAGE;
		}

		catch (NoSuchElementException pax)
		{
			
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}
}
