// Source file: com/dfs/paxtrax/customs/service/BankDelegate.java

package com.dfs.paxtrax.customs.service;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.customs.business.BankBO;
import com.dfs.paxtrax.customs.business.BankBOHome;
import com.dfs.paxtrax.customs.exception.BankRecordNotFoundException;
import com.dfs.paxtrax.customs.valueobject.BankDetailsVO;

public class BankDelegate
{

	public BankDelegate()
	{
	}

	/**
	   @roseuid 404CCAE101B6
	 */
	public BankDetailsVO getBankDetails()
		throws PaxTraxSystemException, BankRecordNotFoundException
	{
		BankDetailsVO bankDetails = null;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.BANK_BO_HOME_JNDI);
			BankBOHome home =
				(BankBOHome) PortableRemoteObject.narrow(obj, BankBOHome.class);
			BankBO remote = home.create();
			bankDetails = remote.getBankDeatils();
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}

		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		return bankDetails;
	}
	/**
	   @roseuid 404CCAE101B6
	 */
	public boolean saveBankDetails(BankDetailsVO banksDetailsVO)
		throws PaxTraxSystemException
	{
		boolean success = false;
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.BANK_BO_HOME_JNDI);
			BankBOHome home =
				(BankBOHome) PortableRemoteObject.narrow(obj, BankBOHome.class);
			BankBO remote = home.create();
			success = remote.saveBankDeatils(banksDetailsVO);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}

		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		return success;
	}

	public BankDetailsVO postCodeLookup(BankDetailsVO bankBean)
		throws PaxTraxSystemException
	{
        BankDetailsVO resultBean = new BankDetailsVO();
		try
		{
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.BANK_BO_HOME_JNDI);
			BankBOHome home =
				(BankBOHome) PortableRemoteObject.narrow(obj, BankBOHome.class);
			BankBO remote = home.create();
			resultBean = remote.postCodeLookup(bankBean);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}

		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}

		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
        return(resultBean);
		
	}
}
