package com.dfs.paxtrax.customs.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 115157
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class NaccsParameterBean extends PaxTraxValueObject {
	private String toBeSentDir;
	private int itemPerFile;
	private String fileExtension;
	private String currentDate;

	/**
	 * Returns the currentDate.
	 * @return String
	 */
	public String getCurrentDate() {
		return currentDate;
	}

	/**
	 * Returns the fileExtension.
	 * @return String
	 */
	public String getFileExtension() {
		return fileExtension;
	}

	/**
	 * Returns the itemPerFile.
	 * @return int
	 */
	public int getItemPerFile() {
		return itemPerFile;
	}

	/**
	 * Returns the toBeSentDir.
	 * @return String
	 */
	public String getToBeSentDir() {
		return toBeSentDir;
	}

	/**
	 * Sets the currentDate.
	 * @param currentDate The currentDate to set
	 */
	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}

	/**
	 * Sets the fileExtension.
	 * @param fileExtension The fileExtension to set
	 */
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	/**
	 * Sets the itemPerFile.
	 * @param itemPerFile The itemPerFile to set
	 */
	public void setItemPerFile(int itemPerFile) {
		this.itemPerFile = itemPerFile;
	}

	/**
	 * Sets the toBeSentDir.
	 * @param toBeSentDir The toBeSentDir to set
	 */
	public void setToBeSentDir(String toBeSentDir) {
		this.toBeSentDir = toBeSentDir;
	}

}
