package com.dfs.paxtrax.customs.actionform;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import java.util.ArrayList;

/**
   Form class for Invalid PAX search
 */
public class NACCSReportForm extends PaxTraxActionForm{
    private String fromDate = null;
    private String toDate=null;
    private String airlineCode=null;
    private String flightNo=null;
    private boolean nonAcknowledged=false;
    private String fromDepDate=null;
    private String toDepDate=null;
    private boolean nonReconciled=false;
    private ArrayList naccsSubmissionResultBeanList = null;
    private ArrayList naccsSummaryResultBeanList = null;
    
	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode() {
		return airlineCode;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNo() {
		return flightNo;
	}

	/**
	 * Returns the naccsSubmissionResultBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNaccsSubmissionResultBeanList() {
		return naccsSubmissionResultBeanList;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNo(String flightNumber) {
		this.flightNo = flightNumber;
	}

	/**
	 * Sets the naccsSubmissionResultBeanList.
	 * @param naccsSubmissionResultBeanList The naccsSubmissionResultBeanList to set
	 */
	public void setNaccsSubmissionResultBeanList(ArrayList naccsSubmissionResultBeanList) {
		this.naccsSubmissionResultBeanList = naccsSubmissionResultBeanList;
	}

//summary begins here
	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * Returns the naccsSummaryResultBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNaccsSummaryResultBeanList() {
		return naccsSummaryResultBeanList;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * Sets the naccsSummaryResultBeanList.
	 * @param naccsSummaryResultBeanList The naccsSummaryResultBeanList to set
	 */
	public void setNaccsSummaryResultBeanList(ArrayList naccsSummaryResultBeanList) {
		this.naccsSummaryResultBeanList = naccsSummaryResultBeanList;
	}
	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	 * Returns the nonAcknowledged.
	 * @return boolean
	 */
	public boolean isNonAcknowledged()
	{
		return nonAcknowledged;
	}

	/**
	 * Sets the nonAcknowledged.
	 * @param nonAcknowledged The nonAcknowledged to set
	 */
	public void setNonAcknowledged(boolean nonAcknowledged)
	{
		this.nonAcknowledged = nonAcknowledged;
	}

	/**
	 * Returns the fromDepDate.
	 * @return String
	 */
	public String getFromDepDate()
	{
		return fromDepDate;
	}

	/**
	 * Returns the nonReconciled.
	 * @return boolean
	 */
	public boolean isNonReconciled()
	{
		return nonReconciled;
	}

	/**
	 * Returns the toDepDate.
	 * @return String
	 */
	public String getToDepDate()
	{
		return toDepDate;
	}

	/**
	 * Sets the fromDepDate.
	 * @param fromDepDate The fromDepDate to set
	 */
	public void setFromDepDate(String fromDepDate)
	{
		this.fromDepDate = fromDepDate;
	}

	/**
	 * Sets the nonReconciled.
	 * @param nonReconciled The nonReconciled to set
	 */
	public void setNonReconciled(boolean nonReconciled)
	{
		this.nonReconciled = nonReconciled;
	}

	/**
	 * Sets the toDepDate.
	 * @param toDepDate The toDepDate to set
	 */
	public void setToDepDate(String toDepDate)
	{
		this.toDepDate = toDepDate;
	}

}
