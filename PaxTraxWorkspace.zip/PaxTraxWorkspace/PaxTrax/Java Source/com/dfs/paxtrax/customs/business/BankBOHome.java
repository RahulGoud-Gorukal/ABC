// Source file: com/dfs/paxtrax/customs/business/BankBOHome.java

package com.dfs.paxtrax.customs.business;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface BankBOHome extends EJBHome{
    
    /**
       @roseuid 404CCD28010A
     */
    public BankBO create( )throws CreateException, RemoteException;
}
