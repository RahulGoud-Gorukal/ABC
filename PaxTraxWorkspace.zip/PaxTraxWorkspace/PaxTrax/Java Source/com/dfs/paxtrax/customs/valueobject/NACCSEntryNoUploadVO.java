package com.dfs.paxtrax.customs.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.math.BigDecimal;
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class NACCSEntryNoUploadVO extends PaxTraxValueObject {
	
	private String paxFileName=null;
	private long importDeclartionNo;
	private String flightNo=null;
	private String airlineCode=null;
	private ArrayList naccsEntryNoUploadVOResult =null;
	
	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode()
	{
		return airlineCode;
	}

	/**
	 * Returns the flightNo.
	 * @return String
	 */
	public String getFlightNo()
	{
		return flightNo;
	}

	/**
	 * Returns the importDeclartionNo.
	 * @return String
	 */
	public long getImportDeclartionNo()
	{
		return importDeclartionNo;
	}

	/**
	 * Returns the paxFileName.
	 * @return String
	 */
	public String getPaxFileName()
	{
		return paxFileName;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode)
	{
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the flightNo.
	 * @param flightNo The flightNo to set
	 */
	public void setFlightNo(String flightNo)
	{
		this.flightNo = flightNo;
	}

	/**
	 * Sets the importDeclartionNo.
	 * @param importDeclartionNo The importDeclartionNo to set
	 */
	public void setImportDeclartionNo(long importDeclartionNo)
	{
		this.importDeclartionNo = importDeclartionNo;
	}

	/**
	 * Sets the paxFileName.
	 * @param paxFileName The paxFileName to set
	 */
	public void setPaxFileName(String paxFileName)
	{
		this.paxFileName = paxFileName;
	}

	/**
	 * Returns the naccsEntryNoUploadVOResult.
	 * @return ArrayList
	 */
	public ArrayList getNaccsEntryNoUploadVOResult()
	{
		return naccsEntryNoUploadVOResult;
	}

	/**
	 * Sets the naccsEntryNoUploadVOResult.
	 * @param naccsEntryNoUploadVOResult The naccsEntryNoUploadVOResult to set
	 */
	public void setNaccsEntryNoUploadVOResult(ArrayList naccsEntryNoUploadVOResult)
	{
		this.naccsEntryNoUploadVOResult = naccsEntryNoUploadVOResult;
	}

}
