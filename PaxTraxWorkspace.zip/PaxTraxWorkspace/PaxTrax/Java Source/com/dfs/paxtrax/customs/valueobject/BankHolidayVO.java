package com.dfs.paxtrax.customs.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 107646
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class BankHolidayVO extends PaxTraxValueObject{
	
	private String date = "";
	private String remark = "";
    private String holidayStartHrs = "";
    private String holidayStartMins = "";
    private String holidayEndHrs = "";
    private String holidayEndMins = "";	
	

	/**
	 * Returns the date.
	 * @return String
	 */
	public String getDate() {
		return date;
	}

	/**
	 * Returns the remark.
	 * @return String
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * Sets the date.
	 * @param date The date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * Sets the remark.
	 * @param remark The remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}	

	/**
	 * Returns the holidayEndHrs.
	 * @return String
	 */
	public String getHolidayEndHrs() {
		return holidayEndHrs;
	}

	/**
	 * Returns the holidayEndMins.
	 * @return String
	 */
	public String getHolidayEndMins() {
		return holidayEndMins;
	}

	/**
	 * Returns the holidayStartHrs.
	 * @return String
	 */
	public String getHolidayStartHrs() {
		return holidayStartHrs;
	}

	/**
	 * Returns the holidayStartMins.
	 * @return String
	 */
	public String getHolidayStartMins() {
		return holidayStartMins;
	}

	/**
	 * Sets the holidayEndHrs.
	 * @param holidayEndHrs The holidayEndHrs to set
	 */
	public void setHolidayEndHrs(String holidayEndHrs) {
		this.holidayEndHrs = holidayEndHrs;
	}

	/**
	 * Sets the holidayEndMins.
	 * @param holidayEndMins The holidayEndMins to set
	 */
	public void setHolidayEndMins(String holidayEndMins) {
		this.holidayEndMins = holidayEndMins;
	}

	/**
	 * Sets the holidayStartHrs.
	 * @param holidayStartHrs The holidayStartHrs to set
	 */
	public void setHolidayStartHrs(String holidayStartHrs) {
		this.holidayStartHrs = holidayStartHrs;
	}

	/**
	 * Sets the holidayStartMins.
	 * @param holidayStartMins The holidayStartMins to set
	 */
	public void setHolidayStartMins(String holidayStartMins) {
		this.holidayStartMins = holidayStartMins;
	}

}
