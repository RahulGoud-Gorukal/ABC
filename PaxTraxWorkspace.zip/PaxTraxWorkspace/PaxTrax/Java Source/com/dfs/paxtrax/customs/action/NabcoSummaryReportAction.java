package com.dfs.paxtrax.customs.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.StampDutyForm;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NabcoMonthlySummaryRptBean;
import com.dfs.paxtrax.customs.valueobject.NabcoReportBean;
import com.dfs.paxtrax.customs.valueobject.NabcoStoreBean;

/**
 * Action class for Nabco Report.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 03/09/2004	P.C.Sathish		Created
 */
public class NabcoSummaryReportAction extends PaxTraxAction {


	public ActionForward createNabcoSummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction : createNabcoSummaryReport() : Start ");
		StampDutyForm nabcoReportForm 
			= (StampDutyForm) form;
		nabcoReportForm.setDepartureDate("");
		nabcoReportForm.setNabcoReportList(null);
		nabcoReportForm.setTotalConsumptionTax(null);
		nabcoReportForm.setTotalNetSales(null);
		nabcoReportForm.setTotalSalesBeforeTax(null);
		request.setAttribute(
			PaxTraxConstants.NABCO_IN_PROGRESS,
			PaxTraxConstants.NO);

		PaxTraxLog.logDebug("NabcoSummaryReportAction : createNabcoSummaryReport() : End ");
		return mapping.findForward("displayNabcoSummary");
	}

	public ActionForward displayNabcoSummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction : displayNabcoSummaryReport() : Start ");
		double totalSalesBeforeTax = 0.0;
		long totalConsumptionTax = 0l;
		double totalNetSales = 0.0;
		StampDutyForm nabcoReportForm 
			= (StampDutyForm) form;
		String departureDate = nabcoReportForm.getDepartureDate();		
		HttpSession session = request.getSession();
		NACCSDelegate naccsDelegate = new NACCSDelegate();
		DecimalFormat formatter = new DecimalFormat(PaxTraxConstants.NACBO_AMT_DISP_FORMAT);
		ArrayList reportList = naccsDelegate.getNabcoSummaryReport(departureDate);
		
		if (reportList!= null && reportList.size() > 0) {
			int reportCount = reportList.size();
			for (int i = 0 ; i < reportCount; i++ ) {
				NabcoReportBean nabcoReportBean = (NabcoReportBean) reportList.get(i);
				ArrayList storeBeanList = nabcoReportBean.getNabcoStoreBeanList();
				int storesCount = storeBeanList.size();
				for (int j = 0; j < storesCount; j++) {
					NabcoStoreBean nabcoStoreBean = (NabcoStoreBean) storeBeanList.get(j);					 
					totalSalesBeforeTax += nabcoStoreBean.getSalesBeforeTax();
					totalConsumptionTax += nabcoStoreBean.getConsumptionTax();
					totalNetSales += nabcoStoreBean.getNetSales();
				}
			}
			
			nabcoReportForm.setTotalSalesBeforeTax(formatter.format(totalSalesBeforeTax));
			nabcoReportForm.setTotalConsumptionTax(formatter.format(totalConsumptionTax));
			nabcoReportForm.setTotalNetSales(formatter.format(totalNetSales));
			
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.SUCCESS);
			request.setAttribute(
				PaxTraxConstants.NABCO_IN_PROGRESS,
				PaxTraxConstants.NO);
		}
		nabcoReportForm.setNabcoReportList(reportList);
		PaxTraxLog.logDebug("NabcoSummaryReportAction : displayNabcoSummaryReport() : End ");
		return mapping.findForward("displayNabcoSummary");
	}
	
	public ActionForward printNabcoSummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction : printNabcoSummaryReport() : Start ");
		StampDutyForm nabcoReportForm 
			= (StampDutyForm) form;
		String departureDate = nabcoReportForm.getDepartureDate();
		HttpSession session = request.getSession();
		NACCSDelegate naccsDelegate = new NACCSDelegate();
		ArrayList reportList = nabcoReportForm.getNabcoReportList();
		if (reportList == null) {
			reportList = naccsDelegate.getNabcoSummaryReport(departureDate);
		}
		nabcoReportForm.setNabcoReportList(reportList);
		PaxTraxLog.logDebug("NabcoSummaryReportAction : printNabcoSummaryReport() : End ");
		return mapping.findForward("printNabcoSummary");
	}

	public ActionForward printNabcoNetSummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction : printNabcoSummaryReport() : Start ");
		StampDutyForm nabcoReportForm 
			= (StampDutyForm) form;
		String departureDate = nabcoReportForm.getDepartureDate();
		HttpSession session = request.getSession();
		NACCSDelegate naccsDelegate = new NACCSDelegate();
		ArrayList reportList = nabcoReportForm.getNabcoReportList();
		if (reportList == null) {
			reportList = naccsDelegate.getNabcoSummaryReport(departureDate);
		}
		nabcoReportForm.setNabcoReportList(reportList);
		PaxTraxLog.logDebug("NabcoSummaryReportAction : printNabcoSummaryReport() : End ");
		return mapping.findForward("printNabcoNetSummary");
	}
	
	public ActionForward createDFDPMonthlySummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction::createDFDPMonthlySummaryReport(): Start ");
		StampDutyForm nabcoReportForm = (StampDutyForm) form;
		ArrayList dfdpMonthlyRptBeanList = new ArrayList();
		//DutyFreePaidMonthlyRptBean dfdpMonthlyReportBean = new DutyFreePaidMonthlyRptBean();
		nabcoReportForm.setDfdpMonthlyRptBeanList(dfdpMonthlyRptBeanList);
		Calendar cal = Calendar.getInstance(Locale.US);
		SimpleDateFormat formatter = new SimpleDateFormat("MMM yyyy");
		ArrayList monthList = new ArrayList();
		for (int i = 0; i < 12; i++)
		{
			ReferenceDataBean referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId(
				(cal.get(Calendar.MONTH) + 1) + "~" + cal.get(Calendar.YEAR));
			referenceDataBean.setCodeValue(formatter.format(cal.getTime()));
			monthList.add(referenceDataBean);
			cal.add(Calendar.MONTH, -1);
		}
		nabcoReportForm.setTotalGrossDFSales(0);
		nabcoReportForm.setTotalGrossDPSales(0);
		nabcoReportForm.setTotalCTOnDFSales(0);
		nabcoReportForm.setTotalCTOnDPSales(0);
		nabcoReportForm.setTotalDFNetSales(0);
		nabcoReportForm.setTotalDPNetSales(0);
		
		nabcoReportForm.setMonthList(monthList);
		
		PaxTraxLog.logDebug("NabcoSummaryReportAction::createDFDPMonthlySummaryReport(): End ");
		return mapping.findForward("dfdpMonthlySummaryReportPage");
	}
	
	public ActionForward generateDFDPMonthlySummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction::createDFDPMonthlySummaryReport(): Start ");
		StampDutyForm nabcoReportForm = (StampDutyForm) form;
		NACCSDelegate naccsDelegate = new NACCSDelegate();
		ArrayList summaryRptMonthlyList = 
				naccsDelegate.getDutyFreePaidMonthlySummaryDetails(nabcoReportForm.getMonth());
		nabcoReportForm.setDfdpMonthlyRptBeanList(summaryRptMonthlyList );
		if (summaryRptMonthlyList != null && 
			summaryRptMonthlyList.size() > 0) {
			long totalGrossDFSales = 0l;
			long totalGrossDPSales = 0l;
			long totalCTOnDFSales = 0l;
			long totalCTOnDPSales = 0l;
			long totalDFNetSales = 0l;
			long totalDPNetSales = 0l;
			for (int i = 0; i < summaryRptMonthlyList .size(); i++) {
				NabcoMonthlySummaryRptBean nabcoMonthlySummaryRptBean =
							(NabcoMonthlySummaryRptBean) summaryRptMonthlyList.get(i);
				if (nabcoMonthlySummaryRptBean.getLeasedVendor().equals("F")) {
					totalGrossDFSales += nabcoMonthlySummaryRptBean.getGrossDutyFreeSales();
					totalGrossDPSales += nabcoMonthlySummaryRptBean.getGrossDutyPaidSales();
					totalCTOnDFSales += nabcoMonthlySummaryRptBean.getDutyFreeConsumptionTax();
					totalCTOnDPSales += nabcoMonthlySummaryRptBean.getDutyPaidConsumptionTax();
					totalDFNetSales += nabcoMonthlySummaryRptBean.getDutyFreeNetSales();
					totalDPNetSales += nabcoMonthlySummaryRptBean.getDutyPaidNetSales();
				}
			}
			nabcoReportForm.setTotalGrossDFSales(totalGrossDFSales);
			nabcoReportForm.setTotalGrossDPSales(totalGrossDPSales);
			nabcoReportForm.setTotalCTOnDFSales(totalCTOnDFSales);
			nabcoReportForm.setTotalCTOnDPSales(totalCTOnDPSales);
			nabcoReportForm.setTotalDFNetSales(totalDFNetSales);
			nabcoReportForm.setTotalDPNetSales(totalDPNetSales);
			request.setAttribute(
				PaxTraxConstants.NABCO_IN_PROGRESS,
				PaxTraxConstants.NO);
			request.setAttribute(PaxTraxConstants.OPERATION, 
				PaxTraxConstants.SUCCESS);
		}
		PaxTraxLog.logDebug("NabcoSummaryReportAction::createDFDPMonthlySummaryReport(): End ");
		return mapping.findForward("dfdpMonthlySummaryReportPage");
	}
	
	public ActionForward printDFDPMonthlySummaryReport(
			ActionMapping mapping,
			ActionForm form, 
			HttpServletRequest request, 
			HttpServletResponse response) 
				throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("NabcoSummaryReportAction::printDFDPMonthlySummaryReport(): Start ");
		StampDutyForm nabcoReportForm = (StampDutyForm) form;
		String month = nabcoReportForm.getMonth();
		ArrayList monthList = nabcoReportForm.getMonthList();
		int length = monthList.size();
		for (int i = 0; i < length; i++) {
			ReferenceDataBean referenceDataBean = (ReferenceDataBean) monthList.get(i);
			if (referenceDataBean.getCodeId().equals(month)) {
				request.setAttribute("MonthDisplay", referenceDataBean.getCodeValue());
			}
		}
		
		PaxTraxLog.logDebug("NabcoSummaryReportAction::printDFDPMonthlySummaryReport(): End ");
		return mapping.findForward("printdfdpMonthlySummaryReportPage");
	}
	
}
