package com.dfs.paxtrax.customs.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * This is value object which contains NACCS file attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Vaikundamurthy	Created 
 * 20/06/2004	P.C. Sathish	Modified
 */

public class NACCSFileBean extends PaxTraxValueObject {
	//Holds pax file name
	private String paxFileName = null;

	//Holds pax number
	private String paxNumber = null;

	//Holds common item
	private String commonItem = null;

	//Holds import declartion no
	private String importDeclarationNo = null;

	//Holds transaction identifier
	private String transactionIdentifier = null;

	//Holds customs office code
	private String customOfficeCode = null;

	//Holds department code
	private String departmentCode = null;

	//Holds passenger name
	private String passengerName = null;

	//Holds post code
	private String postCode = null;

	//Holds passenger address
	private String addressLine1;

	private String addressLine2;

	private String area;

	private String city;

	//Holds airline refid
	private String airlineRefId = null;

	//Holds airline code id
	private String airlineCodeId = null;

	//Holds airline code value
	private String airlineCodeValue = null;

	//Holds airline code
	private String airlineCode = null;

	//Holds flight number
	private String flightNumber = null;

	//Holds departure date
	private String departureDate = null;

	//Holds flight type
	private String flightType = null;

	//Holds bonded warehouse code
	private String bondedWarehouseCode = null;

	//Holds prefecture code
	private String prefectureCode = null;

	//Holds bank account number
	private String bankAccountNo = null;

	//Holds bp application code
	private String bpApplicationCode = null;

	//Holds security registration code
	private String securityRegistrationCode = null;

	//Holds amount of tariff free goods
	private long amountOfTariffFreeGoods = 0;

	//Holds customs comments
	private String customsComments = null;

	//Holds store comments
	private String storeComents = null;

	//Holds other comments
	private String otherComments = null;

	//Holds transaction no
	private String transactionNo = null;

	//Holds item bean
	private ArrayList itemDetails = null;

	//Holds transaction number list
	private ArrayList transactionNoList = null;

	private String nonScheduled;

	// the selling location
	private String sellingLocation;

	// the pax sequence id from TB_PAX_MSTR table
	private String paxSeqId;

	private ArrayList unitItemDetails = null;

	boolean postCodeExists = false;

	//	Holds Country field
	private String country = null;

	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */
	private String flightDepartureTime = null;

	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	//added for CA#290863 by vignesh starts here
	private String vesselNonScheduled = null;
	private String vesselName = null;
	//added for CA#290863 by vignesh ends here
	public String getAirlineCode() {
		return airlineCode;
	}

	/**
	 * Returns the amountOfTariffFreeGoods.
	 * @return long
	 */
	public long getAmountOfTariffFreeGoods() {
		return amountOfTariffFreeGoods;
	}

	/**
	 * Returns the bondedWarehouseCode.
	 * @return String
	 */
	public String getBondedWarehouseCode() {
		return bondedWarehouseCode;
	}

	/**
	 * Returns the bpApplicationCode.
	 * @return String
	 */
	public String getBpApplicationCode() {
		return bpApplicationCode;
	}

	/**
	 * Returns the commonItem.
	 * @return String
	 */
	public String getCommonItem() {
		return commonItem;
	}

	/**
	 * Returns the customOfficeCode.
	 * @return String
	 */
	public String getCustomOfficeCode() {
		return customOfficeCode;
	}

	/**
	 * Returns the customsComments.
	 * @return String
	 */
	public String getCustomsComments() {
		return customsComments;
	}

	/**
	 * Returns the departmentCode.
	 * @return String
	 */
	public String getDepartmentCode() {
		return departmentCode;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * Returns the importDeclarationNo.
	 * @return String
	 */
	public String getImportDeclarationNo() {
		return importDeclarationNo;
	}

	/**
	 * Returns the otherComments.
	 * @return String
	 */
	public String getOtherComments() {
		return otherComments;
	}

	/**
	 * Returns the passengerName.
	 * @return String
	 */
	public String getPassengerName() {
		return passengerName;
	}

	/**
	 * Returns the postCode.
	 * @return String
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * Returns the prefectureCode.
	 * @return String
	 */
	public String getPrefectureCode() {
		return prefectureCode;
	}

	/**
	 * Returns the storeComents.
	 * @return String
	 */
	public String getStoreComents() {
		return storeComents;
	}

	/**
	 * Returns the transactionIdentifier.
	 * @return String
	 */
	public String getTransactionIdentifier() {
		return transactionIdentifier;
	}

	/**
	 * Returns the transactionNo.
	 * @return String
	 */
	public String getTransactionNo() {
		return transactionNo;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the amountOfTariffFreeGoods.
	 * @param amountOfTariffFreeGoods The amountOfTariffFreeGoods to set
	 */
	public void setAmountOfTariffFreeGoods(long amountOfTariffFreeGoods) {
		this.amountOfTariffFreeGoods = amountOfTariffFreeGoods;
	}

	/**
	 * Sets the bondedWarehouseCode.
	 * @param bondedWarehouseCode The bondedWarehouseCode to set
	 */
	public void setBondedWarehouseCode(String bondedWarehouseCode) {
		this.bondedWarehouseCode = bondedWarehouseCode;
	}

	/**
	 * Sets the bpApplicationCode.
	 * @param bpApplicationCode The bpApplicationCode to set
	 */
	public void setBpApplicationCode(String bpApplicationCode) {
		this.bpApplicationCode = bpApplicationCode;
	}

	/**
	 * Sets the commonItem.
	 * @param commonItem The commonItem to set
	 */
	public void setCommonItem(String commonItem) {
		this.commonItem = commonItem;
	}

	/**
	 * Sets the customOfficeCode.
	 * @param customOfficeCode The customOfficeCode to set
	 */
	public void setCustomOfficeCode(String customOfficeCode) {
		this.customOfficeCode = customOfficeCode;
	}

	/**
	 * Sets the customsComments.
	 * @param customsComments The customsComments to set
	 */
	public void setCustomsComments(String customsComments) {
		this.customsComments = customsComments;
	}

	/**
	 * Sets the departmentCode.
	 * @param departmentCode The departmentCode to set
	 */
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the importDeclarationNo.
	 * @param importDeclarationNo The importDeclarationNo to set
	 */
	public void setImportDeclarationNo(String importDeclarationNo) {
		this.importDeclarationNo = importDeclarationNo;
	}

	/**
	 * Sets the otherComments.
	 * @param otherComments The otherComments to set
	 */
	public void setOtherComments(String otherComments) {
		this.otherComments = otherComments;
	}

	/**
	 * Sets the passengerName.
	 * @param passengerName The passengerName to set
	 */
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	/**
	 * Sets the postCode.
	 * @param postCode The postCode to set
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	/**
	 * Sets the prefectureCode.
	 * @param prefectureCode The prefectureCode to set
	 */
	public void setPrefectureCode(String prefectureCode) {
		this.prefectureCode = prefectureCode;
	}

	/**
	 * Sets the storeComents.
	 * @param storeComents The storeComents to set
	 */
	public void setStoreComents(String storeComents) {
		this.storeComents = storeComents;
	}

	/**
	 * Sets the transactionIdentifier.
	 * @param transactionIdentifier The transactionIdentifier to set
	 */
	public void setTransactionIdentifier(String transactionIdentifier) {
		this.transactionIdentifier = transactionIdentifier;
	}

	/**
	 * Sets the transactionNo.
	 * @param transactionNo The transactionNo to set
	 */
	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}

	/**
	 * Returns the itemDetails.
	 * @return ArrayList
	 */
	public ArrayList getItemDetails() {
		return itemDetails;
	}

	/**
	 * Sets the itemDetails.
	 * @param itemDetails The itemDetails to set
	 */
	public void setItemDetails(ArrayList itemDetails) {
		this.itemDetails = itemDetails;
	}

	/**
	 * Returns the bankAccountNo.
	 * @return int
	 */
	public String getBankAccountNo() {
		return bankAccountNo;
	}

	/**
	 * Sets the bankAccountNo.
	 * @param bankAccountNo The bankAccountNo to set
	 */
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	/**
	 * Returns the paxNumber.
	 * @return String
	 */
	public String getPaxNumber() {
		return paxNumber;
	}

	/**
	 * Sets the paxNumber.
	 * @param paxNumber The paxNumber to set
	 */
	public void setPaxNumber(String paxNumber) {
		this.paxNumber = paxNumber;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * Returns the flightType.
	 * @return String
	 */
	public String getFlightType() {
		return flightType;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * Sets the flightType.
	 * @param flightType The flightType to set
	 */
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	/**
	 * Returns the transactionNoList.
	 * @return ArrayList
	 */
	public ArrayList getTransactionNoList() {
		return transactionNoList;
	}

	/**
	 * Sets the transactionNoList.
	 * @param transactionNoList The transactionNoList to set
	 */
	public void setTransactionNoList(ArrayList transactionNoList) {
		this.transactionNoList = transactionNoList;
	}

	/**
	 * Returns the paxFileName.
	 * @return String
	 */
	public String getPaxFileName() {
		return paxFileName;
	}

	/**
	 * Sets the paxFileName.
	 * @param paxFileName The paxFileName to set
	 */
	public void setPaxFileName(String paxFileName) {
		this.paxFileName = paxFileName;
	}

	/**
	 * Returns the airlineRefId.
	 * @return String
	 */
	public String getAirlineRefId() {
		return airlineRefId;
	}

	/**
	 * Sets the airlineRefId.
	 * @param airlineRefId The airlineRefId to set
	 */
	public void setAirlineRefId(String airlineRefId) {
		this.airlineRefId = airlineRefId;
	}

	/**
	 * Returns the airlineCodeId.
	 * @return String
	 */
	public String getAirlineCodeId() {
		return airlineCodeId;
	}

	/**
	 * Sets the airlineCodeId.
	 * @param airlineCodeId The airlineCodeId to set
	 */
	public void setAirlineCodeId(String airlineCodeId) {
		this.airlineCodeId = airlineCodeId;
	}

	/**
	 * Returns the airlineCodeValue.
	 * @return String
	 */
	public String getAirlineCodeValue() {
		return airlineCodeValue;
	}

	/**
	 * Sets the airlineCodeValue.
	 * @param airlineCodeValue The airlineCodeValue to set
	 */
	public void setAirlineCodeValue(String airlineCodeValue) {
		this.airlineCodeValue = airlineCodeValue;
	}

	/**
	 * Returns the securityRegistrationCode.
	 * @return String
	 */
	public String getSecurityRegistrationCode() {
		return securityRegistrationCode;
	}

	/**
	 * Sets the securityRegistrationCode.
	 * @param securityRegistrationCode The securityRegistrationCode to set
	 */
	public void setSecurityRegistrationCode(String securityRegistrationCode) {
		this.securityRegistrationCode = securityRegistrationCode;
	}

	/**
	 * Returns "Y" if nonScheduled flight else "N" is returned.
	 * @return String
	 */
	public String getNonScheduled() {
		return nonScheduled;
	}

	/**
	 * Sets the "Y" for nonScheduled and "N" otherwise.
	 * @param nonScheduled The nonScheduled to set
	 */
	public void setNonScheduled(String nonScheduled) {
		this.nonScheduled = nonScheduled;
	}

	/**
	 * Returns the sellingLocation.
	 * @return String
	 */
	public String getSellingLocation() {
		return sellingLocation;
	}

	/**
	 * Sets the sellingLocation.
	 * @param sellingLocation The sellingLocation to set
	 */
	public void setSellingLocation(String sellingLocation) {
		this.sellingLocation = sellingLocation;
	}

	/**
	 * Returns the paxSeqId.
	 * @return String
	 */
	public String getPaxSeqId() {
		return paxSeqId;
	}

	/**
	 * Sets the paxSeqId.
	 * @param paxSeqId The paxSeqId to set
	 */
	public void setPaxSeqId(String paxSeqId) {
		this.paxSeqId = paxSeqId;
	}

	/**
	 * Returns the addressLine1.
	 * @return String
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * Returns the addressLine2.
	 * @return String
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * Returns the area.
	 * @return String
	 */
	public String getArea() {
		return area;
	}

	/**
	 * Returns the city.
	 * @return String
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the addressLine1.
	 * @param addressLine1 The addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * Sets the addressLine2.
	 * @param addressLine2 The addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * Sets the area.
	 * @param area The area to set
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 * Sets the city.
	 * @param city The city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Returns the unitItemDetails.
	 * @return ArrayList
	 */
	public ArrayList getUnitItemDetails() {
		return unitItemDetails;
	}

	/**
	 * Sets the unitItemDetails.
	 * @param unitItemDetails The unitItemDetails to set
	 */
	public void setUnitItemDetails(ArrayList unitItemDetails) {
		this.unitItemDetails = unitItemDetails;
	}

	/**
	 * Returns the postCodeExists.
	 * @return boolean
	 */
	public boolean isPostCodeExists() {
		return postCodeExists;
	}

	/**
	 * Sets the postCodeExists.
	 * @param postCodeExists The postCodeExists to set
	 */
	public void setPostCodeExists(boolean postCodeExists) {
		this.postCodeExists = postCodeExists;
	}

	/**
	 * Returns the Country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * Sets the Country
	 */
	public void setCountry(String string) {
		country = string;
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */
	/**
	 * Returns flight Departure time
	 */
	public String getFlightDepartureTime() {
		return flightDepartureTime;
	}

	/**
	 * Sets Flight Departure time
	 */
	public void setFlightDepartureTime(String string) {
		flightDepartureTime = string;
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
	/**
	 * @return
	 */
//	added for CA#290863 by vignesh starts here
	public String getVesselName() {
		return vesselName;
	}

	/**
	 * @param string
	 */
	public void setVesselName(String string) {
		vesselName = string;
	}

	/**
	 * @return
	 */
	public String getVesselNonScheduled() {
		return vesselNonScheduled;
	}

	/**
	 * @param string
	 */
	public void setVesselNonScheduled(String string) {
		vesselNonScheduled = string;
	}
//	added for CA#290863 by vignesh ends here
}