// Source file: com/dfs/paxtrax/customs/valueobject/BankDeatailsVO.java

package com.dfs.paxtrax.customs.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
   Value object for bank details. 
   Used in save bank details.
 */
public class BankDetailsVO extends PaxTraxValueObject{
    private String accountNumber = "";
    private String bankName = "";
    private String branch = "";
    private String postCodePrefix = "";
    private String postCodeSuffix = "";
    private String addressLine1 = "";
    private String addressLine2 = "";
    private String city = "";
    private String country = "";   
    private BankWorkingHoursVO mondayNonWorkingHourVO = null;
    private BankWorkingHoursVO tuesdayNonWorkingHourVO = null;
    private BankWorkingHoursVO wednesdayNonWorkingHourVO = null;
    private BankWorkingHoursVO thursdayNonWorkingHourVO = null;
    private BankWorkingHoursVO fridayNonWorkingHourVO = null;
    private BankWorkingHoursVO saturdayNonWorkingHourVO = null;
    private BankWorkingHoursVO sundayNonWorkingHourVO = null;    
    private String[] bankHolidayDateList = null;    
	private String[] bankHolidayRemarkList = null;
    private String[] holidayStartHrsList = null;
    private String[] holidayStartMinsList = null;
    private String[] holidayEndHrsList = null;
    private String[] holidayEndMinsList = null;	
    private String secAccountNumber = "";
    private String secAccountDesc = "";
	//Added by David for CA #313423 starts
	private String vesselSecuritySeqID = ""; 
	private String vesselAccountNumber = "";
	private String vesselAccountDesc = "";
	//Added by David for CA #313423 ends   
	//Necessary getters and setters are generated for the above three variables
    private ArrayList holidayList = null;
    private String savingSeqID = "";
    private String securitySeqID = "";    
    
    
	/**
	 * Returns the accountNumber.
	 * @return String
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Returns the addressLine1.
	 * @return String
	 */
	public String getAddressLine1() {
		return addressLine1;
	}

	/**
	 * Returns the addressLine2.
	 * @return String
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * Returns the bankName.
	 * @return String
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * Returns the branch.
	 * @return String
	 */
	public String getBranch() {
		return branch;
	}

	/**
	 * Returns the city.
	 * @return String
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Returns the country.
	 * @return String
	 */
	public String getCountry() {
		return country;
	}


	/**
	 * Returns the postCodePrefix.
	 * @return String
	 */
	public String getPostCodePrefix() {
		return postCodePrefix;
	}

	/**
	 * Returns the postCodeSuffix.
	 * @return String
	 */
	public String getPostCodeSuffix() {
		return postCodeSuffix;
	}

	/**
	 * Sets the accountNumber.
	 * @param accountNumber The accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Sets the addressLine1.
	 * @param addressLine1 The addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * Sets the addressLine2.
	 * @param addressLine2 The addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * Sets the bankName.
	 * @param bankName The bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Sets the branch.
	 * @param branch The branch to set
	 */
	public void setBranch(String branch) {
		this.branch = branch;
	}

	/**
	 * Sets the city.
	 * @param city The city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Sets the country.
	 * @param country The country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Sets the postCodePrefix.
	 * @param postCodePrefix The postCodePrefix to set
	 */
	public void setPostCodePrefix(String postCodePrefix) {
		this.postCodePrefix = postCodePrefix;
	}

	/**
	 * Sets the postCodeSuffix.
	 * @param postCodeSuffix The postCodeSuffix to set
	 */
	public void setPostCodeSuffix(String postCodeSuffix) {
		this.postCodeSuffix = postCodeSuffix;
	}

	
	/**
	 * Returns the bankHolidayDateList.
	 * @return String[]
	 */
	public String[] getBankHolidayDateList() {
		return bankHolidayDateList;
	}

	/**
	 * Sets the bankHolidayDateList.
	 * @param bankHolidayDateList The bankHolidayDateList to set
	 */
	public void setBankHolidayDateList(String[] bankHolidayDateList) {
		this.bankHolidayDateList = bankHolidayDateList;
	}

	/**
	 * Returns the bankHolidayRemarkList.
	 * @return String[]
	 */
	public String[] getBankHolidayRemarkList() {
		return bankHolidayRemarkList;
	}

	/**
	 * Sets the bankHolidayRemarkList.
	 * @param bankHolidayRemarkList The bankHolidayRemarkList to set
	 */
	public void setBankHolidayRemarkList(String[] bankHolidayRemarkList) {
		this.bankHolidayRemarkList = bankHolidayRemarkList;
	}

	/**
	 * Returns the secAccountDesc.
	 * @return String
	 */
	public String getSecAccountDesc() {
		return secAccountDesc;
	}

	/**
	 * Returns the secAccountNumber.
	 * @return String
	 */
	public String getSecAccountNumber() {
		return secAccountNumber;
	}

	/**
	 * Sets the secAccountDesc.
	 * @param secAccountDesc The secAccountDesc to set
	 */
	public void setSecAccountDesc(String secAccountDesc) {
		this.secAccountDesc = secAccountDesc;
	}

	/**
	 * Sets the secAccountNumber.
	 * @param secAccountNumber The secAccountNumber to set
	 */
	public void setSecAccountNumber(String secAccountNumber) {
		this.secAccountNumber = secAccountNumber;
	}

	/**
	 * Returns the holidayList.
	 * @return ArrayList
	 */
	public ArrayList getHolidayList() {		
		holidayList = new ArrayList();	
		if(bankHolidayDateList != null){
			int listLength = bankHolidayDateList.length;		
			for(int k =0; k < listLength; k++){		
				
				BankHolidayVO bankHolidayVO = new BankHolidayVO();	
				bankHolidayVO.setDate(bankHolidayDateList[k]);
				bankHolidayVO.setRemark(bankHolidayRemarkList[k]);	
				bankHolidayVO.setHolidayStartHrs(holidayStartHrsList[k]);
				bankHolidayVO.setHolidayStartMins(holidayStartMinsList[k]);
				bankHolidayVO.setHolidayEndHrs(holidayEndHrsList[k]);
				bankHolidayVO.setHolidayEndMins(holidayEndMinsList[k]);		
				holidayList.add(bankHolidayVO);
				
			}	
		}				
		return holidayList;
	}	
	
	/**
	 * Sets the holidayList.
	 * @param holidayList The holidayList to set
	 */
	public void setHolidayList(ArrayList holidayList) {
		this.holidayList = holidayList;
	}

	/**
	 * Returns the holidayEndHrsList.
	 * @return String[]
	 */
	public String[] getHolidayEndHrsList() {
		return holidayEndHrsList;
	}

	/**
	 * Returns the holidayEndMinsList.
	 * @return String[]
	 */
	public String[] getHolidayEndMinsList() {
		return holidayEndMinsList;
	}

	/**
	 * Returns the holidayStartHrsList.
	 * @return String[]
	 */
	public String[] getHolidayStartHrsList() {
		return holidayStartHrsList;
	}

	/**
	 * Returns the holidayStartMinsList.
	 * @return String[]
	 */
	public String[] getHolidayStartMinsList() {
		return holidayStartMinsList;
	}

	/**
	 * Sets the holidayEndHrsList.
	 * @param holidayEndHrsList The holidayEndHrsList to set
	 */
	public void setHolidayEndHrsList(String[] holidayEndHrsList) {
		this.holidayEndHrsList = holidayEndHrsList;
	}

	/**
	 * Sets the holidayEndMinsList.
	 * @param holidayEndMinsList The holidayEndMinsList to set
	 */
	public void setHolidayEndMinsList(String[] holidayEndMinsList) {
		this.holidayEndMinsList = holidayEndMinsList;
	}

	/**
	 * Sets the holidayStartHrsList.
	 * @param holidayStartHrsList The holidayStartHrsList to set
	 */
	public void setHolidayStartHrsList(String[] holidayStartHrsList) {
		this.holidayStartHrsList = holidayStartHrsList;
	}

	/**
	 * Sets the holidayStartMinsList.
	 * @param holidayStartMinsList The holidayStartMinsList to set
	 */
	public void setHolidayStartMinsList(String[] holidayStartMinsList) {
		this.holidayStartMinsList = holidayStartMinsList;
	}

	/**
	 * Returns the fridayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getFridayNonWorkingHourVO() {
		return fridayNonWorkingHourVO;
	}

	/**
	 * Returns the mondayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getMondayNonWorkingHourVO() {
		return mondayNonWorkingHourVO;
	}

	/**
	 * Returns the saturdayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getSaturdayNonWorkingHourVO() {
		return saturdayNonWorkingHourVO;
	}

	/**
	 * Returns the sundayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getSundayNonWorkingHourVO() {
		return sundayNonWorkingHourVO;
	}

	/**
	 * Returns the thursdayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getThursdayNonWorkingHourVO() {
		return thursdayNonWorkingHourVO;
	}

	/**
	 * Returns the tuesdayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getTuesdayNonWorkingHourVO() {
		return tuesdayNonWorkingHourVO;
	}

	/**
	 * Returns the wednesdayNonWorkingHourVO.
	 * @return BankWorkingHoursVO
	 */
	public BankWorkingHoursVO getWednesdayNonWorkingHourVO() {
		return wednesdayNonWorkingHourVO;
	}

	/**
	 * Sets the fridayNonWorkingHourVO.
	 * @param fridayNonWorkingHourVO The fridayNonWorkingHourVO to set
	 */
	public void setFridayNonWorkingHourVO(BankWorkingHoursVO fridayNonWorkingHourVO) {
		this.fridayNonWorkingHourVO = fridayNonWorkingHourVO;
	}

	/**
	 * Sets the mondayNonWorkingHourVO.
	 * @param mondayNonWorkingHourVO The mondayNonWorkingHourVO to set
	 */
	public void setMondayNonWorkingHourVO(BankWorkingHoursVO mondayNonWorkingHourVO) {
		this.mondayNonWorkingHourVO = mondayNonWorkingHourVO;
	}

	/**
	 * Sets the saturdayNonWorkingHourVO.
	 * @param saturdayNonWorkingHourVO The saturdayNonWorkingHourVO to set
	 */
	public void setSaturdayNonWorkingHourVO(BankWorkingHoursVO saturdayNonWorkingHourVO) {
		this.saturdayNonWorkingHourVO = saturdayNonWorkingHourVO;
	}

	/**
	 * Sets the sundayNonWorkingHourVO.
	 * @param sundayNonWorkingHourVO The sundayNonWorkingHourVO to set
	 */
	public void setSundayNonWorkingHourVO(BankWorkingHoursVO sundayNonWorkingHourVO) {
		this.sundayNonWorkingHourVO = sundayNonWorkingHourVO;
	}

	/**
	 * Sets the thursdayNonWorkingHourVO.
	 * @param thursdayNonWorkingHourVO The thursdayNonWorkingHourVO to set
	 */
	public void setThursdayNonWorkingHourVO(BankWorkingHoursVO thursdayNonWorkingHourVO) {
		this.thursdayNonWorkingHourVO = thursdayNonWorkingHourVO;
	}

	/**
	 * Sets the tuesdayNonWorkingHourVO.
	 * @param tuesdayNonWorkingHourVO The tuesdayNonWorkingHourVO to set
	 */
	public void setTuesdayNonWorkingHourVO(BankWorkingHoursVO tuesdayNonWorkingHourVO) {
		this.tuesdayNonWorkingHourVO = tuesdayNonWorkingHourVO;
	}

	/**
	 * Sets the wednesdayNonWorkingHourVO.
	 * @param wednesdayNonWorkingHourVO The wednesdayNonWorkingHourVO to set
	 */
	public void setWednesdayNonWorkingHourVO(BankWorkingHoursVO wednesdayNonWorkingHourVO) {
		this.wednesdayNonWorkingHourVO = wednesdayNonWorkingHourVO;
	}

	/**
	 * Returns the savingSeqID.
	 * @return String
	 */
	public String getSavingSeqID() {
		return savingSeqID;
	}

	/**
	 * Sets the savingSeqID.
	 * @param savingSeqID The savingSeqID to set
	 */
	public void setSavingSeqID(String savingSeqID) {
		this.savingSeqID = savingSeqID;
	}

	/**
	 * Returns the securitySeqID.
	 * @return String
	 */
	public String getSecuritySeqID() {
		return securitySeqID;
	}

	/**
	 * Sets the securitySeqID.
	 * @param securitySeqID The securitySeqID to set
	 */
	public void setSecuritySeqID(String securitySeqID) {
		this.securitySeqID = securitySeqID;
	}

	/**
	 * @return
	 */
	public String getVesselAccountDesc() {
		return vesselAccountDesc;
	}

	/**
	 * @return
	 */
	public String getVesselAccountNumber() {
		return vesselAccountNumber;
	}

	/**
	 * @param string
	 */
	public void setVesselAccountDesc(String string) {
		vesselAccountDesc = string;
	}

	/**
	 * @param string
	 */
	public void setVesselAccountNumber(String string) {
		vesselAccountNumber = string;
	}

	/**
	 * @return
	 */
	public String getVesselSecuritySeqID() {
		return vesselSecuritySeqID;
	}

	/**
	 * @param string
	 */
	public void setVesselSecuritySeqID(String string) {
		vesselSecuritySeqID = string;
	}

}

