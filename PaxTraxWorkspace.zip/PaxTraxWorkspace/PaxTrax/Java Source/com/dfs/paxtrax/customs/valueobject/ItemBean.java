package com.dfs.paxtrax.customs.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * This is value object which contains  item attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Vaikundamurthy	Created  
 * 25/07/2004	P.C. Sathish	Modified (implemented cloneable , comparable) 
 */


public class ItemBean extends PaxTraxValueObject implements Cloneable
{
	private int sellingLocation;
	
	private int terminalNumber;
	
	//Holds transaction number
	private int transactionNumber;
	
	private int originalSellingLocation;
	
	private int originalTerminalNumber;
	
	private int originalTransactionNumber;
	
	//Holds basis of tariff identifier
	private String basisOfTariffIdentifier = null;
	
	//Holds merchandise control code
	private int merchandiseControlCode = 0;
	
	//Holds item description
	private String description = null;
	
	//Holds regular price
	private long regularPrice = 0;
	
	//Holds actual price
	private double actualPrice = 0;
	
	//Holds item quantity
	private int itemQuantity = 0;
	
	//Holds article code
	private long articleCode = 0;
	
	//Holds country of origin code
	private String countryOfOriginCode = null;
	
	//Holds classification of COO
	private String classificatinOfCOO = null;
	
	//Holds quantity 1
	private String quantity1 = null;
	
	//Holds quantity unit code 1
	private String quantityUnitCode1 = null;
	
	//Holds quantity 2
	private String quantity2 = null;
	
	//Holds quantity unit code 2
	private String quantityUnitCode2 = null;
	
	//Holds basis of tariff
	private String basisOfTariff = null;
	
	private String consumptionTaxCodeClass = null;
	
	private String taxCodeClass = null; //Added by lakshmy as part of CO20563
	
	//Holds harmonize tariff rate
	private long dutyAmount = 0;
	
	private ArrayList discountList;
	
	//private transaction line no
	private int transactionLineNumber = 0;
	
	// Holds ISO country code
	private String isoCountryCode;
	
	// used by mix n match to calculate floor price
	private long naccsActualUnitPrice = 0l;
	
	private int size;
	
	// Holds tax type
	private String taxType;
//	Modified for CR 37 changes on Oct 03, 2007
	private float alcoholStrength;
	
	private double tariffRate;
	
	private int harmonizeTaxDenominator;
	
	private double concumptionTax;
	
	private int taxRateDenominator;
	
	private int divisionNumber;
	
	private int itemUniqueKey;
	
	private int itemDepartment;	
	
	private int itemClass;
	
	private String paxNo;
	
	/* Members added as a part of the NACCS File logic revision  - April 22, 2005 */
	// Holds the duty amount that can be grouped within the 200,000 limit with the current line as base
	private long calculatedDuty = 0;
	
	//Holds the order of lines which gives the best option of duty computation within 200,000 limit
	private String order = null;
	
	/**
	 * Returns the basisOfTariffIdentifier.
	 * @return String
	 */
	public String getBasisOfTariffIdentifier()
	{
		return basisOfTariffIdentifier;
	}

	/**
	 * Returns the classificatinOfCOO.
	 * @return String
	 */
	public String getClassificatinOfCOO()
	{
		return classificatinOfCOO;
	}

	
	/**
	 * Returns the countryOfOriginCode.
	 * @return String
	 */
	public String getCountryOfOriginCode()
	{
		return countryOfOriginCode;
	}

	/**
	 * Returns the description.
	 * @return String
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * Returns the itemQuantity.
	 * @return int
	 */
	public int getItemQuantity()
	{
		return itemQuantity;
	}

	/**
	 * Returns the quantityUnitCode1.
	 * @return String
	 */
	public String getQuantityUnitCode1()
	{
		return quantityUnitCode1;
	}

	/**
	 * Returns the quantityUnitCode2.
	 * @return String
	 */
	public String getQuantityUnitCode2()
	{
		return quantityUnitCode2;
	}

	/**
	 * Sets the basisOfTariffIdentifier.
	 * @param basisOfTariffIdentifier The basisOfTariffIdentifier to set
	 */
	public void setBasisOfTariffIdentifier(String basisOfTariffIdentifier)
	{
		this.basisOfTariffIdentifier = basisOfTariffIdentifier;
	}

	/**
	 * Sets the classificatinOfCOO.
	 * @param classificatinOfCOO The classificatinOfCOO to set
	 */
	public void setClassificatinOfCOO(String classificatinOfCOO)
	{
		this.classificatinOfCOO = classificatinOfCOO;
	}

	
	/**
	 * Sets the countryOfOriginCode.
	 * @param countryOfOriginCode The countryOfOriginCode to set
	 */
	public void setCountryOfOriginCode(String countryOfOriginCode)
	{
		this.countryOfOriginCode = countryOfOriginCode;
	}

	/**
	 * Sets the description.
	 * @param description The description to set
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * Sets the itemQuantity.
	 * @param itemQuantity The itemQuantity to set
	 */
	public void setItemQuantity(int itemQuantity)
	{
		this.itemQuantity = itemQuantity;
	}

	/**
	 * Sets the quantityUnitCode1.
	 * @param quantityUnitCode1 The quantityUnitCode1 to set
	 */
	public void setQuantityUnitCode1(String quantityUnitCode1)
	{
		this.quantityUnitCode1 = quantityUnitCode1;
	}

	/**
	 * Sets the quantityUnitCode2.
	 * @param quantityUnitCode2 The quantityUnitCode2 to set
	 */
	public void setQuantityUnitCode2(String quantityUnitCode2)
	{
		this.quantityUnitCode2 = quantityUnitCode2;
	}

	/**
	 * Returns the merchandiseControlCode.
	 * @return int
	 */
	public int getMerchandiseControlCode()
	{
		return merchandiseControlCode;
	}

	/**
	 * Sets the merchandiseControlCode.
	 * @param merchandiseControlCode The merchandiseControlCode to set
	 */
	public void setMerchandiseControlCode(int merchandiseControlCode)
	{
		this.merchandiseControlCode = merchandiseControlCode;
	}

	/**
	 * Returns the articleCode.
	 * @return long
	 */
	public long getArticleCode()
	{
		return articleCode;
	}

	/**
	 * Sets the articleCode.
	 * @param articleCode The articleCode to set
	 */
	public void setArticleCode(long articleCode)
	{
		this.articleCode = articleCode;
	}

	/**
	 * Returns the basisOfTariff.
	 * @return String
	 */
	public String getBasisOfTariff()
	{
		return basisOfTariff;
	}

	/**
	 * Returns the quantity1.
	 * @return String
	 */
	public String getQuantity1()
	{
		return quantity1;
	}

	/**
	 * Returns the quantity2.
	 * @return String
	 */
	public String getQuantity2()
	{
		return quantity2;
	}

	/**
	 * Sets the basisOfTariff.
	 * @param basisOfTariff The basisOfTariff to set
	 */
	public void setBasisOfTariff(String basisOfTariff)
	{
		this.basisOfTariff = basisOfTariff;
	}

	/**
	 * Sets the quantity1.
	 * @param quantity1 The quantity1 to set
	 */
	public void setQuantity1(String quantity1)
	{
		this.quantity1 = quantity1;
	}

	/**
	 * Sets the quantity2.
	 * @param quantity2 The quantity2 to set
	 */
	public void setQuantity2(String quantity2)
	{
		this.quantity2 = quantity2;
	}

	/**
	 * Returns the consumptionTaxCodeClass.
	 * @return String
	 */
	public String getConsumptionTaxCodeClass()
	{
		return consumptionTaxCodeClass;
	}

	/**
	 * Sets the consumptionTaxCodeClass.
	 * @param consumptionTaxCodeClass The consumptionTaxCodeClass to set
	 */
	public void setConsumptionTaxCodeClass(String consumptionTaxCodeClass)
	{
		this.consumptionTaxCodeClass = consumptionTaxCodeClass;
	}
	

	/**
	 * Returns the dutyAmount.
	 * @return long
	 */
	public long getDutyAmount()
	{
		return dutyAmount;
	}

	/**
	 * Sets the dutyAmount.
	 * @param dutyAmount The dutyAmount to set
	 */
	public void setDutyAmount(long dutyAmount)
	{
		this.dutyAmount = dutyAmount;
	}


	/**
	 * Returns the transactionLineNumber.
	 * @return int
	 */
	public int getTransactionLineNumber()
	{
		return transactionLineNumber;
	}

	/**
	 * Sets the transactionLineNumber.
	 * @param transactionLineNumber The transactionLineNumber to set
	 */
	public void setTransactionLineNumber(int transactionLineNumber)
	{
		this.transactionLineNumber = transactionLineNumber;
	}

	/**
	 * Returns the transactionNumber.
	 * @return String
	 */
	public int getTransactionNumber()
	{
		return transactionNumber;
	}

	/**
	 * Sets the transactionNumber.
	 * @param transactionNumber The transactionNumber to set
	 */
	public void setTransactionNumber(int transactionNumber)
	{
		this.transactionNumber = transactionNumber;
	}

	/**
	 * Returns the regularPrice.
	 * @return long
	 */
	public long getRegularPrice() {
		return regularPrice;
	}

	/**
	 * Sets the regularPrice.
	 * @param regularPrice The regularPrice to set
	 */
	public void setRegularPrice(long regularPrice) {
		this.regularPrice = regularPrice;
	}

	/**
	 * Returns the isoCountryCode.
	 * @return String
	 */
	public String getIsoCountryCode() {
		return isoCountryCode;
	}

	/**
	 * Sets the isoCountryCode.
	 * @param isoCountryCode The isoCountryCode to set
	 */
	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}

	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}	
	/**
	 * Returns the actualPrice.
	 * @return long
	 */
	public double getActualPrice() {
		return actualPrice;
	}

	/**
	 * Sets the actualPrice.
	 * @param actualPrice The actualPrice to set
	 */
	public void setActualPrice(double actualPrice) {
		this.actualPrice = actualPrice;
	}

	/**
	 * Returns the naccsActualUnitPrice.
	 * @return long
	 */
	public long getNaccsActualUnitPrice() {
		return naccsActualUnitPrice;
	}

	/**
	 * Sets the naccsActualUnitPrice.
	 * @param naccsActualUnitPrice The naccsActualUnitPrice to set
	 */
	public void setNaccsActualUnitPrice(long naccsActualUnitPrice) {
		this.naccsActualUnitPrice = naccsActualUnitPrice;
	}

	/**
	 * Returns the taxType.
	 * @return String
	 */
	public String getTaxType() {
		return taxType;
	}

	/**
	 * Sets the taxType.
	 * @param taxType The taxType to set
	 */
	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	/**
	 * Returns the tariffRate.
	 * @return double
	 */
	public double getTariffRate() {
		return tariffRate;
	}

	/**
	 * Sets the tariffRate.
	 * @param tariffRate The tariffRate to set
	 */
	public void setTariffRate(double tariffRate) {
		this.tariffRate = tariffRate;
	}

	/**
	 * Returns the harmonizeTaxDenominator.
	 * @return int
	 */
	public int getHarmonizeTaxDenominator() {
		return harmonizeTaxDenominator;
	}

	/**
	 * Sets the harmonizeTaxDenominator.
	 * @param harmonizeTaxDenominator The harmonizeTaxDenominator to set
	 */
	public void setHarmonizeTaxDenominator(int harmonizeTaxDenominator) {
		this.harmonizeTaxDenominator = harmonizeTaxDenominator;
	}

	/**
	 * Returns the concumptionTax.
	 * @return double
	 */
	public double getConcumptionTax() {
		return concumptionTax;
	}

	/**
	 * Returns the taxRateDenominator.
	 * @return int
	 */
	public int getTaxRateDenominator() {
		return taxRateDenominator;
	}

	/**
	 * Sets the concumptionTax.
	 * @param concumptionTax The concumptionTax to set
	 */
	public void setConcumptionTax(double concumptionTax) {
		this.concumptionTax = concumptionTax;
	}

	/**
	 * Sets the taxRateDenominator.
	 * @param taxRateDenominator The taxRateDenominator to set
	 */
	public void setTaxRateDenominator(int taxRateDenominator) {
		this.taxRateDenominator = taxRateDenominator;
	}

	/**
	 * Returns the divisionNumber.
	 * @return int
	 */
	public int getDivisionNumber() {
		return divisionNumber;
	}

	/**
	 * Sets the divisionNumber.
	 * @param divisionNumber The divisionNumber to set
	 */
	public void setDivisionNumber(int divisionNumber) {
		this.divisionNumber = divisionNumber;
	}

	/**
	 * Returns the itemUniqueKey.
	 * @return int
	 */
	public int getItemUniqueKey() {
		return itemUniqueKey;
	}

	/**
	 * Sets the itemUniqueKey.
	 * @param itemUniqueKey The itemUniqueKey to set
	 */
	public void setItemUniqueKey(int itemUniqueKey) {
		this.itemUniqueKey = itemUniqueKey;
	}

	/**
	 * Returns the discountList.
	 * @return ArrayList
	 */
	public ArrayList getDiscountList() {
		return discountList;
	}

	/**
	 * Sets the discountList.
	 * @param discountList The discountList to set
	 */
	public void setDiscountList(ArrayList discountList) {
		this.discountList = discountList;
	}

	/**
	 * Returns the size.
	 * @return int
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Sets the size.
	 * @param size The size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * Returns the originalSellingLocation.
	 * @return int
	 */
	public int getOriginalSellingLocation() {
		return originalSellingLocation;
	}

	/**
	 * Returns the originalTerminalNumber.
	 * @return int
	 */
	public int getOriginalTerminalNumber() {
		return originalTerminalNumber;
	}

	/**
	 * Returns the originalTransactionNumber.
	 * @return int
	 */
	public int getOriginalTransactionNumber() {
		return originalTransactionNumber;
	}

	/**
	 * Returns the sellingLocation.
	 * @return int
	 */
	public int getSellingLocation() {
		return sellingLocation;
	}

	/**
	 * Returns the terminalNumber.
	 * @return int
	 */
	public int getTerminalNumber() {
		return terminalNumber;
	}

	/**
	 * Sets the originalSellingLocation.
	 * @param originalSellingLocation The originalSellingLocation to set
	 */
	public void setOriginalSellingLocation(int originalSellingLocation) {
		this.originalSellingLocation = originalSellingLocation;
	}

	/**
	 * Sets the originalTerminalNumber.
	 * @param originalTerminalNumber The originalTerminalNumber to set
	 */
	public void setOriginalTerminalNumber(int originalTerminalNumber) {
		this.originalTerminalNumber = originalTerminalNumber;
	}

	/**
	 * Sets the originalTransactionNumber.
	 * @param originalTransactionNumber The originalTransactionNumber to set
	 */
	public void setOriginalTransactionNumber(int originalTransactionNumber) {
		this.originalTransactionNumber = originalTransactionNumber;
	}

	/**
	 * Sets the sellingLocation.
	 * @param sellingLocation The sellingLocation to set
	 */
	public void setSellingLocation(int sellingLocation) {
		this.sellingLocation = sellingLocation;
	}

	/**
	 * Sets the terminalNumber.
	 * @param terminalNumber The terminalNumber to set
	 */
	public void setTerminalNumber(int terminalNumber) {
		this.terminalNumber = terminalNumber;
	}

	/**
	 * Returns the itemClass.
	 * @return int
	 */
	public int getItemClass() {
		return itemClass;
	}

	/**
	 * Returns the itemDepartment.
	 * @return int
	 */
	public int getItemDepartment() {
		return itemDepartment;
	}

	/**
	 * Sets the itemClass.
	 * @param itemClass The itemClass to set
	 */
	public void setItemClass(int itemClass) {
		this.itemClass = itemClass;
	}

	/**
	 * Sets the itemDepartment.
	 * @param itemDepartment The itemDepartment to set
	 */
	public void setItemDepartment(int itemDepartment) {
		this.itemDepartment = itemDepartment;
	}

	/**
	 * Returns the paxNo.
	 * @return String
	 */
	public String getPaxNo() {
		return paxNo;
	}

	/**
	 * Sets the paxNo.
	 * @param paxNo The paxNo to set
	 */
	public void setPaxNo(String paxNo) {
		this.paxNo = paxNo;
	}

	/**
	 * Returns the calculatedDuty.
	 * @return long
	 */
	public long getCalculatedDuty() {
		return calculatedDuty;
	}

	/**
	 * Returns the order.
	 * @return String
	 */
	public String getOrder() {
		return order;
	}

	/**
	 * Sets the calculatedDuty.
	 * @param calculatedDuty The calculatedDuty to set
	 */
	public void setCalculatedDuty(long calculatedDuty) {
		this.calculatedDuty = calculatedDuty;
	}

	/**
	 * Sets the order.
	 * @param order The order to set
	 */
	public void setOrder(String order) {
		this.order = order;
	}

	/**
	 * @return
	 */
	public float getAlcoholStrength() {
		return alcoholStrength;
	}

	/**
	 * @param f
	 */
	public void setAlcoholStrength(float f) {
		alcoholStrength = f;
	}

	//	Added by lakshmy as part of CO20563 starts

	/**
	 * @return
	 */
	public String getTaxCodeClass() {
		return taxCodeClass;
	}

	/**
	 * @param string
	 */
	public void setTaxCodeClass(String taxCodeClass) {
		this.taxCodeClass = taxCodeClass;
	}
	
	//	Added by lakshmy as part of CO20563 ends
}