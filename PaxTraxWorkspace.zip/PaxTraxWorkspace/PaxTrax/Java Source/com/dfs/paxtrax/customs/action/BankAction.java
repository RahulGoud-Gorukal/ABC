package com.dfs.paxtrax.customs.action;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxConfig;
import com.dfs.paxtrax.customs.actionform.MaintainBankForm;
import com.dfs.paxtrax.customs.exception.BankRecordNotFoundException;
import com.dfs.paxtrax.customs.service.BankDelegate;
import com.dfs.paxtrax.customs.valueobject.BankDetailsVO;
import com.dfs.paxtrax.customs.valueobject.BankWorkingHoursVO;
public class BankAction extends PaxTraxAction
{
	public ActionForward bankAccountPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{

		BankDetailsVO bankDetailVO = new BankDetailsVO();
		MaintainBankForm bankForm = (MaintainBankForm) form;		
		BankDelegate bankDelegate = new BankDelegate();
		try
		{
			bankDetailVO = bankDelegate.getBankDetails();
		}
		catch (BankRecordNotFoundException brnfe)
		{
            bankDetailVO = new BankDetailsVO();
            bankDetailVO.setCountry("Japan");
			ActionMessages messages = new ActionMessages();
			messages.add("bankMsg", new ActionMessage("E401"));
		}		
		String bankAcc = bankDetailVO.getAccountNumber();
		String secBankAcc = bankDetailVO.getSecAccountNumber();
		String country = bankDetailVO.getCountry();
		//Added by David for CA #313423 starts
		String vessel=bankDetailVO.getVesselAccountNumber();
		//Added by David for CA #313423 ends

		if (country == null || country.equals("") || country.equals("null"))
			bankDetailVO.setCountry("");
		if ("0".equals(bankAcc))
			bankAcc = "";
		if ("0".equals(secBankAcc))
			secBankAcc = "";
		//Added by David for CA #313423 starts
		if ("0".equals(vessel))
			vessel = "";
		//Added by David for CA #313423 ends
		bankDetailVO.setAccountNumber(bankAcc);
		bankDetailVO.setSecAccountNumber(secBankAcc);
		//Added by David for CA #313423 starts
		bankDetailVO.setVesselAccountNumber(vessel);
		//Added by David for CA #313423 ends
		bankForm.setBankDetailsVO(bankDetailVO);
		bankForm.setHourList(populateHourList());
		bankForm.setMinuteList(populateMinuteList());

		return mapping.findForward(PaxTraxConstants.BANK_ACCOUNT_PAGE);
	}
	public ActionForward savebankDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{

		MaintainBankForm bankForm = (MaintainBankForm) form;
		BankDetailsVO bankDetailVO = bankForm.getBankDetailsVO();

		BankDelegate bankDelegate = new BankDelegate();
		boolean success = false;

		String country = bankDetailVO.getCountry();
		

		try
		{
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute(PaxTraxConstants.USER);
			bankDetailVO.setUser(user);
			success = bankDelegate.saveBankDetails(bankDetailVO);
			if (!success)
			{
				ActionMessages messages = new ActionMessages();
				messages.add("bankMsg2", new ActionMessage("E402"));
				return mapping.findForward(PaxTraxConstants.BANK_ACCOUNT_PAGE);
			}
			bankDetailVO = bankDelegate.getBankDetails();
			bankDetailVO.setCountry(country);

			ArrayList bankHolidaysList = bankDetailVO.getHolidayList();
			if (bankHolidaysList != null)
			{

				if (bankHolidaysList.size() < 1)
				{

					session.setAttribute(
						PaxTraxConstants.HOLIDAY_EMPTY,
						PaxTraxConstants.TRUE);
				}
				else
					session.setAttribute(
						PaxTraxConstants.HOLIDAY_EMPTY,
						PaxTraxConstants.FALSE);
			}
			else
				session.setAttribute(
					PaxTraxConstants.HOLIDAY_EMPTY,
					PaxTraxConstants.TRUE);
		}
		catch (BankRecordNotFoundException brnfe)
		{
			throw new PaxTraxSystemException(brnfe);
		}

		bankForm.setBankDetailsVO(bankDetailVO);
		return mapping.findForward(PaxTraxConstants.BANK_ACCOUNT_CONF_PAGE);
	}
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);

		String postCodeLookUp = request.getParameter(PaxTraxConstants.POSTCODE);

		if (page.equals(PaxTraxConstants.BANK_ACCOUNT_PAGE))
		{
			forward = PaxTraxConstants.BANK_ACCOUNT_PAGE;
		}
		if (page.equals(PaxTraxConstants.SYSTEM_ERROR))
		{
			forward = PaxTraxConstants.SYSTEM_ERROR;
		}
		if (page.equals(PaxTraxConstants.BANK_ACCOUNT_CONF_PAGE))
		{
			MaintainBankForm bankForm = (MaintainBankForm) form;
			BankDetailsVO bankDetailVO = bankForm.getBankDetailsVO();
			String countryValue = bankDetailVO.getCountry();
			BankDelegate bankDelegate = new BankDelegate();
			try
			{
				bankDetailVO = bankDelegate.getBankDetails();
				bankDetailVO.setCountry(countryValue);
			}
			catch (PaxTraxSystemException e)
			{
				e.printStackTrace();
			}
			catch (BankRecordNotFoundException e)
			{
				e.printStackTrace();
			}
			bankForm.setBankDetailsVO(bankDetailVO);
			forward = PaxTraxConstants.BANK_ACCOUNT_CONF_PAGE;
		}

		return mapping.findForward(forward);
	}

	/**
	 * Method postCodeLookup.
	 * 
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * The method to handle the Postcode Lookup
	 */
	public ActionForward postCodeLookup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{

		try
		{
			MaintainBankForm bankForm = (MaintainBankForm) form;
			BankDetailsVO bankBean = bankForm.getBankDetailsVO();
			BankDetailsVO resultBean = new BankDetailsVO();
			BankDelegate bankDelegate = new BankDelegate();

			resultBean = bankDelegate.postCodeLookup(bankBean);
			String countryValue = bankBean.getCountry();
			String addressLine2 = resultBean.getAddressLine2();
			
				bankBean.setAddressLine2(resultBean.getAddressLine2());
				bankBean.setCity(resultBean.getCity());
				bankBean.setCountry(resultBean.getCountry());				
			
			bankForm.setBankDetailsVO(bankBean);
			request.setAttribute(
				PaxTraxConstants.POSTCODE_LOOKUP,
				PaxTraxConstants.SUCCESS);
		}
		catch (PaxTraxSystemException pse)
		{
			return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
		}

		return mapping.findForward(PaxTraxConstants.BANK_ACCOUNT_PAGE);
	}

	/** 
	 * Method populateHourList
	 * @return ArrayList
	 * The method to handle the Postcode Lookup
	 * */
	private ArrayList populateHourList()
	{
		ReferenceDataBean commonBean = null;

		ArrayList temp = new ArrayList();
		for (int i = 0; i < 10; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}
		for (int i = 10; i < 24; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId(i + "");
			commonBean.setCodeValue(i + "");
			temp.add(commonBean);
		}
		return (temp);

	}
	private ArrayList populateMinuteList()
	{
		ReferenceDataBean commonBean = null;

		ArrayList temp = new ArrayList();
		for (int i = 0; i < 10; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId("0" + i);
			commonBean.setCodeValue("0" + i);
			temp.add(commonBean);
		}
		for (int i = 10; i < 60; i++)
		{
			commonBean = new ReferenceDataBean();
			commonBean.setCodeId(i + "");
			commonBean.setCodeValue(i + "");
			temp.add(commonBean);
		}
		return (temp);

	}
}
