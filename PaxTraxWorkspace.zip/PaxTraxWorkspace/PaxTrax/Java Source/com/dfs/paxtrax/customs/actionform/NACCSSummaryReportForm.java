package com.dfs.paxtrax.customs.actionform;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;

public class NACCSSummaryReportForm extends PaxTraxActionForm{
	
	private ArrayList naccsSummaryResultBeanList=null;
	private NACCSSearchBean naccsSearchBean =new NACCSSearchBean();	
	
	
	/**
	 * Returns the naccsSearchBean.
	 * @return NACCSSearchBean
	 */
	public NACCSSearchBean getNaccsSearchBean()
	{
		return naccsSearchBean;
	}

	/**
	 * Returns the naccsSummaryResultBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNaccsSummaryResultBeanList()
	{
		return naccsSummaryResultBeanList;
	}

	/**
	 * Sets the naccsSearchBean.
	 * @param naccsSearchBean The naccsSearchBean to set
	 */
	public void setNaccsSearchBean(NACCSSearchBean naccsSearchBean)
	{
		this.naccsSearchBean = naccsSearchBean;
	}

	/**
	 * Sets the naccsSummaryResultBeanList.
	 * @param naccsSummaryResultBeanList The naccsSummaryResultBeanList to set
	 */
	public void setNaccsSummaryResultBeanList(ArrayList naccsSummaryResultBeanList)
	{
		this.naccsSummaryResultBeanList = naccsSummaryResultBeanList;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request)		
	{
		if(naccsSearchBean!=null) {
		naccsSearchBean.setNonReconciled(false);
		naccsSearchBean.setFromDepDate(null);
		naccsSearchBean.setToDepDate(null);
		}		
	}

}
