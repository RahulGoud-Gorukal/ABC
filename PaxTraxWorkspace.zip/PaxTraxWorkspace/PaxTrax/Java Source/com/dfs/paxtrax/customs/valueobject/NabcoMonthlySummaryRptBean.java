package com.dfs.paxtrax.customs.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


 
/**
 * This is a value object used by Nabco report containing
 * details for a store.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 17/12/2004	P.C.Sathish		Created
 */
public class NabcoMonthlySummaryRptBean extends PaxTraxValueObject {
	private int location;
	private String locationDescription;
	private long grossDutyFreeSales;
	private long grossDutyPaidSales;
	private long dutyFreeConsumptionTax;
	private long dutyPaidConsumptionTax;
	private long dutyFreeNetSales;
	private long dutyPaidNetSales;
	private int terminalNumber;
	private String leasedVendor = "F";
	private String leasedVendorName;

	/**
	 * Returns the dutyFreeConsumptionTax.
	 * @return long
	 */
	public long getDutyFreeConsumptionTax() {
		return dutyFreeConsumptionTax;
	}

	/**
	 * Returns the dutyFreeNetSales.
	 * @return long
	 */
	public long getDutyFreeNetSales() {
		return dutyFreeNetSales;
	}

	/**
	 * Returns the dutyPaidConsumptionTax.
	 * @return long
	 */
	public long getDutyPaidConsumptionTax() {
		return dutyPaidConsumptionTax;
	}

	/**
	 * Returns the dutyPaidNetSales.
	 * @return long
	 */
	public long getDutyPaidNetSales() {
		return dutyPaidNetSales;
	}

	/**
	 * Returns the grossDutyFreeSales.
	 * @return long
	 */
	public long getGrossDutyFreeSales() {
		return grossDutyFreeSales;
	}

	/**
	 * Returns the grossDutyPaidSales.
	 * @return long
	 */
	public long getGrossDutyPaidSales() {
		return grossDutyPaidSales;
	}

	/**
	 * Returns the location.
	 * @return String
	 */
	public int getLocation() {
		return location;
	}

	/**
	 * Returns the locationDescription.
	 * @return String
	 */
	public String getLocationDescription() {
		return locationDescription;
	}

	/**
	 * Sets the dutyFreeConsumptionTax.
	 * @param dutyFreeConsumptionTax The dutyFreeConsumptionTax to set
	 */
	public void setDutyFreeConsumptionTax(long dutyFreeConsumptionTax) {
		this.dutyFreeConsumptionTax = dutyFreeConsumptionTax;
	}

	/**
	 * Sets the dutyFreeNetSales.
	 * @param dutyFreeNetSales The dutyFreeNetSales to set
	 */
	public void setDutyFreeNetSales(long dutyFreeNetSales) {
		this.dutyFreeNetSales = dutyFreeNetSales;
	}

	/**
	 * Sets the dutyPaidConsumptionTax.
	 * @param dutyPaidConsumptionTax The dutyPaidConsumptionTax to set
	 */
	public void setDutyPaidConsumptionTax(long dutyPaidConsumptionTax) {
		this.dutyPaidConsumptionTax = dutyPaidConsumptionTax;
	}

	/**
	 * Sets the dutyPaidNetSales.
	 * @param dutyPaidNetSales The dutyPaidNetSales to set
	 */
	public void setDutyPaidNetSales(long dutyPaidNetSales) {
		this.dutyPaidNetSales = dutyPaidNetSales;
	}

	/**
	 * Sets the grossDutyFreeSales.
	 * @param grossDutyFreeSales The grossDutyFreeSales to set
	 */
	public void setGrossDutyFreeSales(long grossDutyFreeSales) {
		this.grossDutyFreeSales = grossDutyFreeSales;
	}

	/**
	 * Sets the grossDutyPaidSales.
	 * @param grossDutyPaidSales The grossDutyPaidSales to set
	 */
	public void setGrossDutyPaidSales(long grossDutyPaidSales) {
		this.grossDutyPaidSales = grossDutyPaidSales;
	}

	/**
	 * Sets the location.
	 * @param location The location to set
	 */
	public void setLocation(int location) {
		this.location = location;
	}

	/**
	 * Sets the locationDescription.
	 * @param locationDescription The locationDescription to set
	 */
	public void setLocationDescription(String locationDescription) {
		this.locationDescription = locationDescription;
	}

	/**
	 * Returns the leasedVendor.
	 * @return String
	 */
	public String getLeasedVendor()
	{
		return leasedVendor;
	}

	/**
	 * Returns the leasedVendorName.
	 * @return String
	 */
	public String getLeasedVendorName()
	{
		return leasedVendorName;
	}

	/**
	 * Returns the terminalNumber.
	 * @return int
	 */
	public int getTerminalNumber()
	{
		return terminalNumber;
	}

	/**
	 * Sets the leasedVendor.
	 * @param leasedVendor The leasedVendor to set
	 */
	public void setLeasedVendor(String leasedVendor)
	{
		this.leasedVendor = leasedVendor;
	}

	/**
	 * Sets the leasedVendorName.
	 * @param leasedVendorName The leasedVendorName to set
	 */
	public void setLeasedVendorName(String leasedVendorName)
	{
		this.leasedVendorName = leasedVendorName;
	}

	/**
	 * Sets the terminalNumber.
	 * @param terminalNumber The terminalNumber to set
	 */
	public void setTerminalNumber(int terminalNumber)
	{
		this.terminalNumber = terminalNumber;
	}

}
