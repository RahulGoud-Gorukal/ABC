// Source file: com/dfs/paxtrax/customs/actionform/MaintainBankForm.java

package com.dfs.paxtrax.customs.actionform;

import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.customs.valueobject.BankDetailsVO;
import org.apache.struts.action.ActionMapping;
import javax.servlet.http.HttpServletRequest;


public class MaintainBankForm extends PaxTraxActionForm {
    private BankDetailsVO bankDeatailsVO = null;
	private ArrayList hourList = null;
    private ArrayList minuteList = null;



	/**
	 * Returns the bankDeatailsVO.
	 * @return BankDeatailsVO
	 */
	public BankDetailsVO getBankDetailsVO() {
		return bankDeatailsVO;
	}

	/**
	 * Sets the bankDeatailsVO.
	 * @param bankDeatailsVO The bankDeatailsVO to set
	 */
	public void setBankDetailsVO(BankDetailsVO bankDeatailsVO) {
		this.bankDeatailsVO = bankDeatailsVO;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request){
		if(bankDeatailsVO != null){
	    	bankDeatailsVO.getMondayNonWorkingHourVO().setDayOfTheWeek(false);
	    	bankDeatailsVO.getTuesdayNonWorkingHourVO().setDayOfTheWeek(false);
	    	bankDeatailsVO.getWednesdayNonWorkingHourVO().setDayOfTheWeek(false);
	    	bankDeatailsVO.getThursdayNonWorkingHourVO().setDayOfTheWeek(false);
	    	bankDeatailsVO.getFridayNonWorkingHourVO().setDayOfTheWeek(false);
	    	bankDeatailsVO.getSaturdayNonWorkingHourVO().setDayOfTheWeek(false);
	    	bankDeatailsVO.getSundayNonWorkingHourVO().setDayOfTheWeek(false);
			bankDeatailsVO.setBankHolidayDateList(null);
			bankDeatailsVO.setBankHolidayRemarkList(null);
			bankDeatailsVO.setHolidayStartHrsList(null);
			bankDeatailsVO.setHolidayStartMinsList(null);
			bankDeatailsVO.setHolidayEndHrsList(null);
			bankDeatailsVO.setHolidayEndMinsList(null);
	    	bankDeatailsVO.getMondayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getMondayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getMondayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getMondayNonWorkingHourVO().setBankCloseMins("00");
	    	
	    	bankDeatailsVO.getTuesdayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getTuesdayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getTuesdayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getTuesdayNonWorkingHourVO().setBankCloseMins("00");
	    	
	    	bankDeatailsVO.getWednesdayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getWednesdayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getWednesdayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getWednesdayNonWorkingHourVO().setBankCloseMins("00");	    		    				
	    	
	    	bankDeatailsVO.getThursdayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getThursdayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getThursdayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getThursdayNonWorkingHourVO().setBankCloseMins("00");
	    	
	    	bankDeatailsVO.getFridayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getFridayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getFridayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getFridayNonWorkingHourVO().setBankCloseMins("00");
	    	
	    	bankDeatailsVO.getSaturdayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getSaturdayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getSaturdayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getSaturdayNonWorkingHourVO().setBankCloseMins("00");	    		    		    	

	    	bankDeatailsVO.getSundayNonWorkingHourVO().setBankOpenHrs("00");
			bankDeatailsVO.getSundayNonWorkingHourVO().setBankOpenMins("00");
	    	bankDeatailsVO.getSundayNonWorkingHourVO().setBankCloseHrs("00");
	    	bankDeatailsVO.getSundayNonWorkingHourVO().setBankCloseMins("00");	    		    		    		    	
		}
    }

	/**
	 * Returns the hourList.
	 * @return ArrayList
	 */
	public ArrayList getHourList() {
		return hourList;
	}

	/**
	 * Returns the minuteList.
	 * @return ArrayList
	 */
	public ArrayList getMinuteList() {
		return minuteList;
	}

	/**
	 * Sets the hourList.
	 * @param hourList The hourList to set
	 */
	public void setHourList(ArrayList hourList) {
		this.hourList = hourList;
	}

	/**
	 * Sets the minuteList.
	 * @param minuteList The minuteList to set
	 */
	public void setMinuteList(ArrayList minuteList) {
		this.minuteList = minuteList;
	}

}
