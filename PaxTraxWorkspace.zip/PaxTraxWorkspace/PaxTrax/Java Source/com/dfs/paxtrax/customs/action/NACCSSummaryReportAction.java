package com.dfs.paxtrax.customs.action;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.customs.actionform.NACCSSummaryReportForm;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSummaryResultBean;
/**
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class NACCSSummaryReportAction extends PaxTraxAction {

	private String forward = null;
	/**
	 * Forwards to search  naccssubmissionReportpage
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward generateNACCSSummaryReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::generateNACCSSummaryReport::Begin");
		NACCSSummaryReportForm naccsReportForm = (NACCSSummaryReportForm) form;
		/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */
		//To display current date in the Report 
		String currentDate = getCurrentDate();
		NACCSSearchBean naccsSearchBean = new NACCSSearchBean();
		naccsSearchBean.setFromDepDate(currentDate);
		naccsSearchBean.setToDepDate(currentDate);
		naccsReportForm.setNaccsSearchBean(naccsSearchBean);
		/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
		forward = PaxTraxConstants.ENQUIRY_SUMMARY_SEARCH_PAGE;
		PaxTraxLog.logDebug("forward Value is assigned as" + forward);
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::generateNACCSSummaryReport::End");

		return mapping.findForward(forward);
	}

	public ActionForward searchFileSummaryEnquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		try {
			PaxTraxLog.logDebug(
				"PaxTrax::NACCSSummaryReportAction::searchFileSummaryEnquiry::Begin");
			int pageNumber = 0;
			ArrayList currentRecords = null;
			ArrayList allRecords = null;
			HttpSession session = request.getSession();
			PaxTraxLog.logDebug("session is created");
			NACCSSummaryReportForm naccsSummaryReportForm =
				(NACCSSummaryReportForm) form;
			PaxTraxLog.logDebug("Naccs Summary report Form is Upadetd");
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug(
				"page number searchFileSummaryEnquiry " + pageNumberStr);
			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;
			PaxTraxLog.logDebug("pageNumberStr is " + pageNumberStr);
			if ((pageNumberStr != null)) {
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */

			if (pageNumber == 0) {
				PaxTraxLog.logDebug("Inside If loop");
				int size = 0;
				pageNumber = 1;
				allRecords =
					getSummaryDetails(
						naccsSummaryReportForm.getNaccsSearchBean());

				if (allRecords != null) {
					size = allRecords.size();
				}
				PaxTraxLog.logDebug(
					"size of alrecords from data base searchFileSummaryEnquiry "
						+ allRecords.size());

				session.removeAttribute(PaxTraxConstants.ALL_SUMMARY_RECORDS);
				session.setAttribute(
					PaxTraxConstants.ALL_SUMMARY_RECORDS,
					allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_RECORDS,
					Integer.toString(size));
				PaxTraxLog.logDebug("Session is updated");
			} else {
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_SUMMARY_RECORDS);
			}
			PaginationHelper helper = PaginationHelper.getInstance();
			PaxTraxLog.logDebug("Pagination Helper is Created");
			if ((allRecords != null) && (allRecords.size() != 0)) {
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
				PaxTraxLog.logDebug(
					"current records size is" + currentRecords.size());
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));

			PaxTraxLog.logDebug("Page Number Attribute is set in the request");
			if (currentRecords != null) {
				PaxTraxLog.logDebug("size " + currentRecords.size());
			}
			PaxTraxLog.logDebug("B4 Setting Values in NACCSREPORTForm ");
			naccsSummaryReportForm.setNaccsSummaryResultBeanList(
				currentRecords);
			PaxTraxLog.logDebug("After Setting Values in NACCSREPORTForm ");
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug(" Request Attribute is Set For Result ");
			forward = PaxTraxConstants.ENQUIRY_SUMMARY_SEARCH_PAGE;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);

		} catch (Exception pte) {

			PaxTraxLog.logError(
				"Exception Caught - NACCSSummaryReportAction - searchFileSummaryEnquiry",
				pte);
			forward = PaxTraxConstants.REPORT_ERROR;
			PaxTraxLog.logDebug("forward Value is assigned as" + forward);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::searchFileSummaryEnquiry::End");
		return mapping.findForward(forward);
	}

	/**
	 * searches NaccsSummaryEnquiry values for the given search criteria by calling 
	 * delegate method. 
	 * @param form Action form
	 * @return ArrayList
	 * @throws PaxTraxSystemException This exception is thrown if there is any 
	 * problem in searching Naccs Summary Enquiry
	 */
	private ArrayList getSummaryDetails(NACCSSearchBean naccsSearchBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::getSummaryDetails::Begin");
		ArrayList summaryDetails = new ArrayList();
		NACCSSummaryResultBean naccsSummaryResultBean =
			new NACCSSummaryResultBean();

		NACCSDelegate naccsDelegateObj = new NACCSDelegate();
		summaryDetails =
			naccsDelegateObj.getNaccsSummaryRecords(naccsSearchBean);
		PaxTraxLog.logDebug("summaryDetails size is " + summaryDetails.size());
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::getSummaryDetails::End");
		return (summaryDetails);
	}
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		super.changeLanguage(request, language, country);
		forward = PaxTraxConstants.ENQUIRY_SUMMARY_SEARCH_PAGE;
		PaxTraxLog.logDebug("forward Value is assigned as" + forward);
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSSummaryReportAction::changeLanguage::End");
		return mapping.findForward(forward);
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */

	/**
			 * It gets current date  
			 * Method getCurrentDate.
			 * @param 
			 * @return String 
			 * @throws 
			 */
	private String getCurrentDate() {
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE);
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);

		String currentDate = "";
		currentDate =
			""
				+ year
				+ "/"
				+ (month < 10 ? "0" + month : "" + month)
				+ "/"
				+ (day < 10 ? "0" + day : "" + day);

		return (currentDate);
	}
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */
}
