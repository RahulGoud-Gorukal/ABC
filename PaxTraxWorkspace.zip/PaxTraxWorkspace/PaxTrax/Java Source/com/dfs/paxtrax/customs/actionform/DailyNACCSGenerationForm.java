package com.dfs.paxtrax.customs.actionform;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.DailyNACCSGenerationBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSubmissionResultBean;
/**
 * Form class for Daily NACCS Generation Report.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant -  Sankaranarayanan srinivasan 
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 01/06/2007	Vijay		    Created
 */
public class DailyNACCSGenerationForm extends PaxTraxActionForm {

	private ArrayList naccsSubmissionResultBeanList = null;
	private NACCSSearchBean naccsSearchBean = null;
	private ArrayList airlineCodes = null;

	private String galleriaSkuCount = null;
	private String airPortSkuCount = null;
	private DailyNACCSGenerationBean dailyNACCSGenerationBean = null;

	/**
	 * Returns the naccsSearchBean.
	 * @return NACCSSearchBean
	 */
	public NACCSSearchBean getNaccsSearchBean() {
		return naccsSearchBean;
	}

	/**
	 * Returns the naccsSubmissionResultBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNaccsSubmissionResultBeanList() {
		return naccsSubmissionResultBeanList;
	}

	/**
	 * Sets the naccsSearchBean.
	 * @param naccsSearchBean The naccsSearchBean to set
	 */
	public void setNaccsSearchBean(NACCSSearchBean naccsSearchBean) {
		this.naccsSearchBean = naccsSearchBean;
	}

	/**
	 * Sets the naccsSubmissionResultBeanList.
	 * @param naccsSubmissionResultBeanList The naccsSubmissionResultBeanList to set
	 */
	public void setNaccsSubmissionResultBeanList(ArrayList naccsSubmissionResultBeanList) {
		this.naccsSubmissionResultBeanList = naccsSubmissionResultBeanList;
	}

	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes() {
		return airlineCodes;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes) {
		this.airlineCodes = airlineCodes;
	}
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		if (naccsSearchBean != null) {
			naccsSearchBean.setNonAcknowledged(false);
			naccsSearchBean.setDepartureDate(null);

		}
	}

	/**
	 * Returns the AP SKU Count 
	 * @return airPortSkuCount
	 */
	public String getAirPortSkuCount() {
		return airPortSkuCount;
	}

	/**
	 * Returns the Galleria SKU Count
	 * @return galleriaSkuCount
	 */
	public String getGalleriaSkuCount() {
		return galleriaSkuCount;
	}

	/**
	 * Sets the AP SKU Count
	 * @param string  airPortSkuCount
	 */
	public void setAirPortSkuCount(String string) {
		airPortSkuCount = string;
	}

	/**
	 * Sets the Galleria SKU Count
	 * @param string galleriaSkuCount
	 */
	public void setGalleriaSkuCount(String string) {
		galleriaSkuCount = string;
	}

	/**
	 * Returns the DailyNAACSGeneration Bean
	 * @return  dailyNACCSGenerationBean
	 */
	public DailyNACCSGenerationBean getDailyNACCSGenerationBean() {
		return dailyNACCSGenerationBean;
	}

	/**
	 * Sets the DailyNAACSGeneration bean
	 * @param bean the dailyNACCSGenerationBean
	 */
	public void setDailyNACCSGenerationBean(DailyNACCSGenerationBean bean) {
		dailyNACCSGenerationBean = bean;
	}

}
