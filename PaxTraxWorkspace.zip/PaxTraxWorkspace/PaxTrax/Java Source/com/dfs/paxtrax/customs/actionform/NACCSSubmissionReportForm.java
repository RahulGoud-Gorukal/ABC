package com.dfs.paxtrax.customs.actionform;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.customs.valueobject.NACCSSearchBean;
import com.dfs.paxtrax.customs.valueobject.NACCSSubmissionResultBean;

public class NACCSSubmissionReportForm extends PaxTraxActionForm
{	
	private ArrayList naccsSubmissionResultBeanList=null;
	private NACCSSearchBean naccsSearchBean =null;
	private ArrayList airlineCodes=null;
	private NACCSSubmissionResultBean  naccsSubmissionResultBean=null;		

	/**
	 * Returns the naccsSearchBean.
	 * @return NACCSSearchBean
	 */
	public NACCSSearchBean getNaccsSearchBean()
	{
		return naccsSearchBean;
	}

	/**
	 * Returns the naccsSubmissionResultBeanList.
	 * @return ArrayList
	 */
	public ArrayList getNaccsSubmissionResultBeanList()
	{
		return naccsSubmissionResultBeanList;
	}

	/**
	 * Sets the naccsSearchBean.
	 * @param naccsSearchBean The naccsSearchBean to set
	 */
	public void setNaccsSearchBean(NACCSSearchBean naccsSearchBean)
	{
		this.naccsSearchBean = naccsSearchBean;
	}

	/**
	 * Sets the naccsSubmissionResultBeanList.
	 * @param naccsSubmissionResultBeanList The naccsSubmissionResultBeanList to set
	 */
	public void setNaccsSubmissionResultBeanList(ArrayList naccsSubmissionResultBeanList)
	{
		this.naccsSubmissionResultBeanList = naccsSubmissionResultBeanList;
	}

	/**
	 * Returns the naccsSubmissionResultBean.
	 * @return NACCSSubmissionResultBean
	 */
	public NACCSSubmissionResultBean getNaccsSubmissionResultBean()
	{
		return naccsSubmissionResultBean;
	}

	/**
	 * Sets the naccsSubmissionResultBean.
	 * @param naccsSubmissionResultBean The naccsSubmissionResultBean to set
	 */
	public void setNaccsSubmissionResultBean(NACCSSubmissionResultBean naccsSubmissionResultBean)
	{
		this.naccsSubmissionResultBean = naccsSubmissionResultBean;
	}

	/**
	 * Returns the airlineCodes.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodes()
	{
		return airlineCodes;
	}

	/**
	 * Sets the airlineCodes.
	 * @param airlineCodes The airlineCodes to set
	 */
	public void setAirlineCodes(ArrayList airlineCodes)
	{
		this.airlineCodes = airlineCodes;
	}
	public void reset(ActionMapping mapping, HttpServletRequest request)		
	{
		if(naccsSearchBean!=null) {
		naccsSearchBean.setNonAcknowledged(false);
		naccsSearchBean.setDepartureDate(null);
//		naccsSearchBean.setAirlineCode(null);
//		naccsSearchBean.setFlightNo(null);
		}		
	}
}
