package com.dfs.paxtrax.customs.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * This is value object which contains  flight search attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Vaikundamurthy	Created   
 * 23/06/2004	P.C. Sathish	Modified
 */


public class NACCSFileSearchBean extends PaxTraxValueObject
{
	//Holds airline ref id
	private String airlineRefId = null;
	
	//Holds airline code
	private String airlineCodeId = null;
	
	//HOlds airline code value
	private String airlineCodeValue = null;
	
	//Holds flight number
	private String flightNumber = null;
	
	//Holds scheduler's date
	private String departureDate = null;
	
	// Holds flight departure Date
	private String flightDate = null;
	
	//Holds departure hour time
	private String departureTimeInHour = null;
	
	//Holds departure minute time
	private String departureTimeInMin = null;
	
	//Holds checked
	private String checked = PaxTraxConstants.NO;
	
	//Holds Flight Status
	private String nonScheduled = null;
	
	/**
	 * Returns the scheduler's date.
	 * @return String
	 */
	
	//	added for CA#290863 by vignesh starts here
	private String vesselNonScheduled = null;
	
	private String vesselName = null;
	//added for CA#290863 by vignesh ends here
	
	public String getDepartureDate()
	{
		return departureDate;
	}

	
	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber()
	{
		return flightNumber;
	}

	

	/**
	 * Sets the scheduler's date.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber)
	{
		this.flightNumber = flightNumber;
	}

	/**
	 * Returns the checked.
	 * @return String
	 */
	public String getChecked()
	{
		return checked;
	}

	/**
	 * Sets the checked.
	 * @param checked The checked to set
	 */
	public void setChecked(String checked)
	{
		this.checked = checked;
	}
	
	/**
	 * Returns the departureTimeInHour.
	 * @return String
	 */
	public String getDepartureTimeInHour()
	{
		return departureTimeInHour;
	}

	/**
	 * Returns the departureTimeInMin.
	 * @return String
	 */
	public String getDepartureTimeInMin()
	{
		return departureTimeInMin;
	}

	/**
	 * Sets the departureTimeInHour.
	 * @param departureTimeInHour The departureTimeInHour to set
	 */
	public void setDepartureTimeInHour(String departureTimeInHour)
	{
		this.departureTimeInHour = departureTimeInHour;
	}

	/**
	 * Sets the departureTimeInMin.
	 * @param departureTimeInMin The departureTimeInMin to set
	 */
	public void setDepartureTimeInMin(String departureTimeInMin)
	{
		this.departureTimeInMin = departureTimeInMin;
	}

	/**
	 * Returns the airlineCodeId.
	 * @return String
	 */
	public String getAirlineCodeId()
	{
		return airlineCodeId;
	}

	/**
	 * Returns the airlineRefId.
	 * @return String
	 */
	public String getAirlineRefId()
	{
		return airlineRefId;
	}

	/**
	 * Sets the airlineCodeId.
	 * @param airlineCodeId The airlineCodeId to set
	 */
	public void setAirlineCodeId(String airlineCodeId)
	{
		this.airlineCodeId = airlineCodeId;
	}

	/**
	 * Sets the airlineRefId.
	 * @param airlineRefId The airlineRefId to set
	 */
	public void setAirlineRefId(String airlineRefId)
	{
		this.airlineRefId = airlineRefId;
	}

	/**
	 * Returns the airlineCodeValue.
	 * @return String
	 */
	public String getAirlineCodeValue()
	{
		return airlineCodeValue;
	}

	/**
	 * Sets the airlineCodeValue.
	 * @param airlineCodeValue The airlineCodeValue to set
	 */
	public void setAirlineCodeValue(String airlineCodeValue)
	{
		this.airlineCodeValue = airlineCodeValue;
	}

	/**
	 * Returns the nonScheduled.
	 * @return String
	 */
	public String getNonScheduled()
	{
		return nonScheduled;
	}

	/**
	 * Sets the nonScheduled.
	 * @param nonScheduled The nonScheduled to set
	 */
	public void setNonScheduled(String nonScheduled)
	{
		this.nonScheduled = nonScheduled;
	}

	/**
	 * Returns the flightDate.
	 * @return String
	 */
	public String getFlightDate() {
		return flightDate;
	}

	/**
	 * Sets the flightDate.
	 * @param flightDate The flightDate to set
	 */
	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	/**
	 * @return
	 */
	public String getVesselName() {
		return vesselName;
	}

	/**
	 * @param string
	 */
	public void setVesselName(String string) {
		vesselName = string;
	}

	/**
	 * @return
	 */
	public String getVesselNonScheduled() {
		return vesselNonScheduled;
	}

	/**
	 * @param string
	 */
	public void setVesselNonScheduled(String string) {
		vesselNonScheduled = string;
	}

}