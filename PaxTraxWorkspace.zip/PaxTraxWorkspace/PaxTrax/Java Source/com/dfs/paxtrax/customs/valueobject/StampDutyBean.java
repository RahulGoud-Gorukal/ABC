package com.dfs.paxtrax.customs.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * This is the valueobject class which stores the data 
 * of the stamp duty colections
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 29/06/2004   Joseph Oommen A     Created
*/
public class StampDutyBean extends PaxTraxValueObject
{

	private String month = null;
	
	private String location = null;

	private double grossSaleAmount = 0.0;
	private double totalTaxableAmount = 0.0;
	private String amountOfRevenueStamp = null;
	private int numberOfStamps = 0;
	private double taxAmount = 0.0;

	private double netTransactionAmount = 0.0;
	private int sellingLocation = 0;
	private int salesTerminalNumber = 0;
	private int salesTransactionNumber = 0;
	private int origSellingLocation = 0;
	private int origTerminalNumber = 0;
	private int origTransactionNumber = 0;
	private double localAmount = 0.0;

	private double fromRange = 0.0;
	private double toRange = 0.0;
	private int stampDuty = 0;

	/**
	 * Returns the amountOfRevenueStamp.
	 * @return String
	 */
	public String getAmountOfRevenueStamp()
	{
		return amountOfRevenueStamp;
	}

	/**
	 * Returns the fromRange.
	 * @return double
	 */
	public double getFromRange()
	{
		return fromRange;
	}

	/**
	 * Returns the grossSaleAmount.
	 * @return double
	 */
	public double getGrossSaleAmount()
	{
		return grossSaleAmount;
	}

	/**
	 * Returns the localAmount.
	 * @return double
	 */
	public double getLocalAmount()
	{
		return localAmount;
	}

	/**
	 * Returns the month.
	 * @return String
	 */
	public String getMonth()
	{
		return month;
	}

	/**
	 * Returns the netTransactionAmount.
	 * @return double
	 */
	public double getNetTransactionAmount()
	{
		return netTransactionAmount;
	}

	/**
	 * Returns the numberOfStamps.
	 * @return int
	 */
	public int getNumberOfStamps()
	{
		return numberOfStamps;
	}

	/**
	 * Returns the origSellingLocation.
	 * @return int
	 */
	public int getOrigSellingLocation()
	{
		return origSellingLocation;
	}

	/**
	 * Returns the origTerminalNumber.
	 * @return int
	 */
	public int getOrigTerminalNumber()
	{
		return origTerminalNumber;
	}

	/**
	 * Returns the origTransactionNumber.
	 * @return int
	 */
	public int getOrigTransactionNumber()
	{
		return origTransactionNumber;
	}

	/**
	 * Returns the salesTerminalNumber.
	 * @return int
	 */
	public int getSalesTerminalNumber()
	{
		return salesTerminalNumber;
	}

	/**
	 * Returns the salesTransactionNumber.
	 * @return int
	 */
	public int getSalesTransactionNumber()
	{
		return salesTransactionNumber;
	}

	/**
	 * Returns the sellingLocation.
	 * @return int
	 */
	public int getSellingLocation()
	{
		return sellingLocation;
	}

	/**
	 * Returns the stampDuty.
	 * @return int
	 */
	public int getStampDuty()
	{
		return stampDuty;
	}

	/**
	 * Returns the taxAmount.
	 * @return double
	 */
	public double getTaxAmount()
	{
		return taxAmount;
	}

	/**
	 * Returns the toRange.
	 * @return double
	 */
	public double getToRange()
	{
		return toRange;
	}

	/**
	 * Returns the totalTaxableAmount.
	 * @return double
	 */
	public double getTotalTaxableAmount()
	{
		return totalTaxableAmount;
	}

	/**
	 * Sets the amountOfRevenueStamp.
	 * @param amountOfRevenueStamp The amountOfRevenueStamp to set
	 */
	public void setAmountOfRevenueStamp(String amountOfRevenueStamp)
	{
		this.amountOfRevenueStamp = amountOfRevenueStamp;
	}

	/**
	 * Sets the fromRange.
	 * @param fromRange The fromRange to set
	 */
	public void setFromRange(double fromRange)
	{
		this.fromRange = fromRange;
	}

	/**
	 * Sets the grossSaleAmount.
	 * @param grossSaleAmount The grossSaleAmount to set
	 */
	public void setGrossSaleAmount(double grossSaleAmount)
	{
		this.grossSaleAmount = grossSaleAmount;
	}

	/**
	 * Sets the localAmount.
	 * @param localAmount The localAmount to set
	 */
	public void setLocalAmount(double localAmount)
	{
		this.localAmount = localAmount;
	}

	/**
	 * Sets the month.
	 * @param month The month to set
	 */
	public void setMonth(String month)
	{
		this.month = month;
	}

	/**
	 * Sets the netTransactionAmount.
	 * @param netTransactionAmount The netTransactionAmount to set
	 */
	public void setNetTransactionAmount(double netTransactionAmount)
	{
		this.netTransactionAmount = netTransactionAmount;
	}

	/**
	 * Sets the numberOfStamps.
	 * @param numberOfStamps The numberOfStamps to set
	 */
	public void setNumberOfStamps(int numberOfStamps)
	{
		this.numberOfStamps = numberOfStamps;
	}

	/**
	 * Sets the origSellingLocation.
	 * @param origSellingLocation The origSellingLocation to set
	 */
	public void setOrigSellingLocation(int origSellingLocation)
	{
		this.origSellingLocation = origSellingLocation;
	}

	/**
	 * Sets the origTerminalNumber.
	 * @param origTerminalNumber The origTerminalNumber to set
	 */
	public void setOrigTerminalNumber(int origTerminalNumber)
	{
		this.origTerminalNumber = origTerminalNumber;
	}

	/**
	 * Sets the origTransactionNumber.
	 * @param origTransactionNumber The origTransactionNumber to set
	 */
	public void setOrigTransactionNumber(int origTransactionNumber)
	{
		this.origTransactionNumber = origTransactionNumber;
	}

	/**
	 * Sets the salesTerminalNumber.
	 * @param salesTerminalNumber The salesTerminalNumber to set
	 */
	public void setSalesTerminalNumber(int salesTerminalNumber)
	{
		this.salesTerminalNumber = salesTerminalNumber;
	}

	/**
	 * Sets the salesTransactionNumber.
	 * @param salesTransactionNumber The salesTransactionNumber to set
	 */
	public void setSalesTransactionNumber(int salesTransactionNumber)
	{
		this.salesTransactionNumber = salesTransactionNumber;
	}

	/**
	 * Sets the sellingLocation.
	 * @param sellingLocation The sellingLocation to set
	 */
	public void setSellingLocation(int sellingLocation)
	{
		this.sellingLocation = sellingLocation;
	}

	/**
	 * Sets the stampDuty.
	 * @param stampDuty The stampDuty to set
	 */
	public void setStampDuty(int stampDuty)
	{
		this.stampDuty = stampDuty;
	}

	/**
	 * Sets the taxAmount.
	 * @param taxAmount The taxAmount to set
	 */
	public void setTaxAmount(double taxAmount)
	{
		this.taxAmount = taxAmount;
	}

	/**
	 * Sets the toRange.
	 * @param toRange The toRange to set
	 */
	public void setToRange(double toRange)
	{
		this.toRange = toRange;
	}

	/**
	 * Sets the totalTaxableAmount.
	 * @param totalTaxableAmount The totalTaxableAmount to set
	 */
	public void setTotalTaxableAmount(double totalTaxableAmount)
	{
		this.totalTaxableAmount = totalTaxableAmount;
	}

	/**
	 * Returns the location.
	 * @return String
	 */
	public String getLocation()
	{
		return location;
	}

	/**
	 * Sets the location.
	 * @param location The location to set
	 */
	public void setLocation(String location)
	{
		this.location = location;
	}

	}
