package com.dfs.paxtrax.bagtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
 
 
/**
 * 
 * The bean class for stock at pickup location report
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 				COMMENTS
 * 05/07/2004	Yuvarani			Created  
 * 02/11/2004   Joseph Oommen A		Modified	 
 */

public class CageTrackingInquiryCageShelfBean extends PaxTraxValueObject
{
	
	
	private String cage = null;
	private String shelf = null;
	private int totalNoOfCartons;
	private ArrayList cartonBagList = null;
	
	/**
	 * Returns the cage.
	 * @return String
	 */
	public String getCage()
	{
		return cage;
	}

	/**
	 * Returns the cartonBagList.
	 * @return ArrayList
	 */
	public ArrayList getCartonBagList()
	{
		return cartonBagList;
	}

	/**
	 * Returns the shelf.
	 * @return String
	 */
	public String getShelf()
	{
		return shelf;
	}

	/**
	 * Returns the totalNoOfCartons.
	 * @return int
	 */
	public int getTotalNoOfCartons()
	{
		return totalNoOfCartons;
	}

	/**
	 * Sets the cage.
	 * @param cage The cage to set
	 */
	public void setCage(String cage)
	{
		this.cage = cage;
	}

	/**
	 * Sets the cartonBagList.
	 * @param cartonBagList The cartonBagList to set
	 */
	public void setCartonBagList(ArrayList cartonBagList)
	{
		this.cartonBagList = cartonBagList;
	}

	/**
	 * Sets the shelf.
	 * @param shelf The shelf to set
	 */
	public void setShelf(String shelf)
	{
		this.shelf = shelf;
	}

	/**
	 * Sets the totalNoOfCartons.
	 * @param totalNoOfCartons The totalNoOfCartons to set
	 */
	public void setTotalNoOfCartons(int totalNoOfCartons)
	{
		this.totalNoOfCartons = totalNoOfCartons;
	}

	}
