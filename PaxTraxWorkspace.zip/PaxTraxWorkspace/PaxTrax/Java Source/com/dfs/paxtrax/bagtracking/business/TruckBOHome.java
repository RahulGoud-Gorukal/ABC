package com.dfs.paxtrax.bagtracking.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;


/**
 * The home interface of the TruckBOBean
 * 
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 01/06/2004	Yuvarani    	Created   
 */

public interface TruckBOHome extends EJBHome {
    
    /**
       This function is used to get the remote interface of the TruckBOBean
       @roseuid 403D7CF2038F
     */
    public TruckBO create() throws CreateException, RemoteException;
}
