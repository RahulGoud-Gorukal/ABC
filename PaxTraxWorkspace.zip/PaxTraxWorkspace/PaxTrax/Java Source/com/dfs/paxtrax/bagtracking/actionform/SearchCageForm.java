package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.CageBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * This is action form which contains search attributes for Cage
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/05/2004   Joseph Oommen A     Created   
*/

public class SearchCageForm extends PaxTraxActionForm
{
	/**
	   This attribute contains the list of cage beans that match the search criteria
	 */
	private ArrayList cageList = null;
	/**
	   This attribute is used to store the cage number value that is presented in the Cage Search screen
	 */
	private CageBean cageBean = null;

	/**
	 * Returns the cageBean.
	 * @return CageBean
	 */
	public CageBean getCageBean()
	{
		return cageBean;
	}
	
	/**
	 * Returns the cageList.
	 * @return ArrayList
	 */
	public ArrayList getCageList()
	{
		return cageList;
	}

	/**
	 * Sets the cageBean.
	 * @param cageBean The cageBean to set
	 */
	public void setCageBean(CageBean cageBean)
	{
		this.cageBean = cageBean;
	}

	/**
	 * Sets the cageList.
	 * @param cageList The cageList to set
	 */
	public void setCageList(ArrayList cageList)
	{
		this.cageList = cageList;
	}

}