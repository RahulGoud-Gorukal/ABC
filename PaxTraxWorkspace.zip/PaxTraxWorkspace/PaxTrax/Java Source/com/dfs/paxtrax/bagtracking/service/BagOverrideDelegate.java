package com.dfs.paxtrax.bagtracking.service;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.BagOverrideBO;
import com.dfs.paxtrax.bagtracking.business.BagOverrideBOHome;
import com.dfs.paxtrax.bagtracking.exception.BagOverrideException;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
 
/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 05/11/2004	P.C.Sathish		Created   
 */

public class BagOverrideDelegate {

   /*
	* Holds service locator instance
	*/
	private ServiceLocator serviceLocator;

	private BagOverrideBO bagOverrideBo;
	private BagOverrideBOHome bagOverrideBoHome;
	
	/*
	 * Jndi look up is performed here
	 */
	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::BagOverrideDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			bagOverrideBoHome =
				(BagOverrideBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						PaxTraxConstants.BAG_OVERRIDE_BO_HOME_JNDI),
					BagOverrideBOHome.class);
			bagOverrideBo = bagOverrideBoHome.create();
		}
		catch (NamingException ne) {

			throw new PaxTraxSystemException(ne);
		}
		catch (CreateException ce) {
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagOverrideDelegate::jndiCall::End");
	}

	/**
	 * Assigns bag status to Airport bin.
	 * @param bagBean the bag status value object
	 * @throws BagOverrideException thrown on error
	 * @throws PaxTraxSystemException thrown on error
	 */
	public boolean assignAirPort(BagStatusBean bagBean) 
	throws BagOverrideException, PaxTraxSystemException {
		try {
			if (bagOverrideBoHome == null) {
				jndiCall();
			}
			return bagOverrideBo.assignAirPort(bagBean);
			
		} catch (RemoteException re) {
		
			throw new PaxTraxSystemException(re);
		}
	} 
	
	/**
	 * Assigns bag status to Ware house bin.
	 * @param bagBean the bag status value object
	 * @throws BagOverrideException thrown on error
	 * @throws PaxTraxSystemException thrown on error
	 */
	public boolean assignWareHouse(BagStatusBean bagBean) 
	throws BagOverrideException, PaxTraxSystemException {

		try {
			if (bagOverrideBoHome == null) {
				jndiCall();
			} 
			
			return bagOverrideBo.assignWareHouse(bagBean);
			
		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
	}
	
	public ArrayList getTruckList() throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax::BagOverrideDelegate::getTruckList()::Start");
		ArrayList truckList = null;
		try {
			if (bagOverrideBoHome == null) {
				jndiCall();
			} 
			truckList = bagOverrideBo.getTruckList();

		} catch (RemoteException re) {
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::BagOverrideDelegate::getTruckList()::End");
		return truckList;
	}

//code added on 2005/12/08. 
	public BagStatusBean changeSalesTransactionStatus(BagStatusBean bagBean) 
		throws BagOverrideException, PaxTraxSystemException {
		try 
		{
			if (bagOverrideBoHome == null) 
			{
				jndiCall();
			}
			
			bagBean = bagOverrideBo.changeSalesTransactionStatus(bagBean);
		} 
		catch (RemoteException re) 
		{
			throw new PaxTraxSystemException(re);
		}
		
		return bagBean;
	} 
//	Added by selvam for CA# 294102 starts


   /**
	* Assigns bag status to Sea Port bin.
	* @param bagBean the bag status value object
	* @throws BagOverrideException thrown on error
	* @throws PaxTraxSystemException thrown on error
	*/
   public boolean assignSeaPort(BagStatusBean bagBean) 
   throws BagOverrideException, PaxTraxSystemException {
	   try {
		   if (bagOverrideBoHome == null) {
			   jndiCall();
		   }
		   return bagOverrideBo.assignSeaPort(bagBean);
			
	   } catch (RemoteException re) {
		
		   throw new PaxTraxSystemException(re);
	   }
   } 


   /**
	* Method to release the bags
	* @param bagBean the bag status value object
	* @throws BagOverrideException thrown on error
	* @throws PaxTraxSystemException thrown on error
	*/
   public boolean releaseBags(BagStatusBean bagBean) 
   throws BagOverrideException, PaxTraxSystemException {
	   try {
		   if (bagOverrideBoHome == null) {
			   jndiCall();
		   }
		   return bagOverrideBo.releaseBags(bagBean);
			
	   } catch (RemoteException re) {
		
		   throw new PaxTraxSystemException(re);
	   }
   }
   
   
 // Added/Modified by David for CR 3659 starts	
  public ArrayList bagLookUp(BagStatusBean bagBean) 
  throws BagOverrideException, PaxTraxSystemException {
	  try {
		  if (bagOverrideBoHome == null) {
			  jndiCall();
		  }
		  return bagOverrideBo.bagLookUp(bagBean);
			
	  } catch (RemoteException re) {
		
		  throw new PaxTraxSystemException(re);
	  }
  }
 // Added/Modified by David for CR 3659 ends  
   
//Added by selvam for CA# 294102 ends
   


	
}

