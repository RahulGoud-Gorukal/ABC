package com.dfs.paxtrax.bagtracking.valueobject;
/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
/**
* This is valueobject class holds the 
* cage status detaiils
* Represents a single row in the cage status history
* section of the cage tracking report.   
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 01/06/2004    Cyril John 		Created   
* 02/11/2004	Joseph Oommen   Modified
*/
public class CageStatusHistoryBean extends PaxTraxValueObject
{

	private String cageNumber = null;
	private String pickupLocation = null;
	private String departureDate = null;
	private int totalNumberOfCartons = 0;
	private ArrayList cartonStatusList = null;
	private ArrayList shelfCountList = null;
	private String moduleId = null;
	private String cageCycle =null;

	/**
	 * Returns the cageNumber.
	 * @return String
	 */
	public String getCageNumber()
	{
		return cageNumber;
	}

	/**
	 * Returns the cartonStatusList.
	 * @return ArrayList
	 */
	public ArrayList getCartonStatusList()
	{
		return cartonStatusList;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Returns the shelfCountList.
	 * @return ArrayList
	 */
	public ArrayList getShelfCountList()
	{
		return shelfCountList;
	}

	/**
	 * Sets the cageNumber.
	 * @param cageNumber The cageNumber to set
	 */
	public void setCageNumber(String cageNumber)
	{
		this.cageNumber = cageNumber;
	}

	/**
	 * Sets the cartonStatusList.
	 * @param cartonStatusList The cartonStatusList to set
	 */
	public void setCartonStatusList(ArrayList cartonStatusList)
	{
		this.cartonStatusList = cartonStatusList;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the shelfCountList.
	 * @param shelfCountList The shelfCountList to set
	 */
	public void setShelfCountList(ArrayList shelfCountList)
	{
		this.shelfCountList = shelfCountList;
	}

	/**
	 * Returns the moduleId.
	 * @return String
	 */
	public String getModuleId()
	{
		return moduleId;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(String moduleId)
	{
		this.moduleId = moduleId;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Returns the totalNumberOfCartons.
	 * @return int
	 */
	public int getTotalNumberOfCartons()
	{
		return totalNumberOfCartons;
	}

	/**
	 * Sets the totalNumberOfCartons.
	 * @param totalNumberOfCartons The totalNumberOfCartons to set
	 */
	public void setTotalNumberOfCartons(int totalNumberOfCartons)
	{
		this.totalNumberOfCartons = totalNumberOfCartons;
	}

	/**
	 * Returns the cageCycle.
	 * @return String
	 */
	public String getCageCycle()
	{
		return cageCycle;
	}

	/**
	 * Sets the cageCycle.
	 * @param cageCycle The cageCycle to set
	 */
	public void setCageCycle(String cageCycle)
	{
		this.cageCycle = cageCycle;
	}

}
