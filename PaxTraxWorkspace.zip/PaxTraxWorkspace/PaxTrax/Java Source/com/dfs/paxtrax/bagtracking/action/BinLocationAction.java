package com.dfs.paxtrax.bagtracking.action;

/**
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.BinLocationForm;
import com.dfs.paxtrax.bagtracking.exception.BinLocationException;
import com.dfs.paxtrax.bagtracking.service.BinLocationDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This action class is used for inserting and updating binlocation records
 * 
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *           DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE          USER            COMMENTS
 * 18/05/2004    R.R.Yuvarani	 Created
 */

public class BinLocationAction extends PaxTraxAction
{

	/**
	 * Updates bin location details in the database
	 * @param mapping ActionMapping
	 * @param form ActionForm 
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in updation
	 */
	public ActionForward updateBinLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::updateBinLocationDetails::Begin");
		BinLocationForm binForm = (BinLocationForm) form;
		BinLocationBean binBean = binForm.getBinLocationBean();
		BinLocationDelegate binDelegate = new BinLocationDelegate();
		ArrayList allRecords = null;
		HttpSession session = request.getSession();
		binBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		String forward = null;
		ArrayList pickupLocationList = binForm.getPickupLocationList();
		ReferenceDataBean referrenceData = null;
		int size = 0;
		if (pickupLocationList != null)
		{
			size = pickupLocationList.size();
		}
		for (int i = 0; i < size; i++)
		{
			referrenceData = (ReferenceDataBean) pickupLocationList.get(i);
			if (referrenceData
				.getCodeId()
				.equals(binBean.getPickupLocationBean().getCodeId()))
			{
				binBean.setPickupLocationBean(referrenceData);
				break;
			}
		}
		String fromPage =
			(String) request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);

		String fromPageNumber =
			request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, fromPageNumber);

		try
		{
			binDelegate.updateBinLocationDetails(binBean);
			binForm.setBinLocationBean(binBean);
			if (fromPage.equals(PaxTraxConstants.SEARCH_BIN))
			{
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
				int recordSize = 0;
				if (allRecords != null)
					recordSize = allRecords.size();

				for (int i = 0; i < recordSize; i++)
				{
					BinLocationBean binLocationBean =
						(BinLocationBean) allRecords.get(i);
					if (binLocationBean
						.getBinLocation()
						.equals(binBean.getBinLocation()))
					{
						allRecords.remove(i);
						allRecords.add(i, binBean);
						session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
						session.setAttribute(
							PaxTraxConstants.ALL_RECORDS,
							allRecords);
						break;
					}
				}
			}
			request.setAttribute(
				PaxTraxConstants.SUCCESS,
				"" + PaxTraxConstants.BIN_LOCATION_UPDATED);
			forward = PaxTraxConstants.MAINTAIN_BIN_LOCATION_CONFIRMATION;
		}
		catch (BinLocationException binLocationException)
		{
			request.setAttribute(
				PaxTraxConstants.ERROR_CODE,
				"" + binLocationException.getErrorCode());
			request.setAttribute(
				PaxTraxConstants.SUCCESS,
				PaxTraxConstants.TRUE);
			forward = PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::updateBinLocationDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * Removes BinLocationDetails from the database.
	 * @param mapping ActionMapping 
	 * @param form ActionForm 
	 * @param request HttpServletRequest 
	 * @param response HttpServletResponse 
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in deletion
	 */
	public ActionForward removeBinLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, BinLocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::removeBinLocationDetails::Begin");
		BinLocationForm binForm = (BinLocationForm) form;
		BinLocationBean binBean = binForm.getBinLocationBean();

		HttpSession session = request.getSession();
		binBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));

		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);

		String fromPageNumber =
			request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, fromPageNumber);

		String forward = null;

		try
		{
			BinLocationDelegate binDelegate = new BinLocationDelegate();
			binDelegate.removeBinLocationDetails(binBean);

			ArrayList pickupLocationList = binForm.getPickupLocationList();
			ReferenceDataBean referrenceData = null;
			int size = 0;
			if (pickupLocationList != null)
			{
				size = pickupLocationList.size();
			}
			for (int i = 0; i < size; i++)
			{
				referrenceData = (ReferenceDataBean) pickupLocationList.get(i);
				if (referrenceData
					.getCodeId()
					.equals(binBean.getPickupLocationBean().getCodeId()))
				{
					binBean.setPickupLocationBean(referrenceData);
					break;
				}
			}

			if (fromPage.equals(PaxTraxConstants.SEARCH_BIN))
			{
				ArrayList allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);
				int recordSize = 0;
				if (allRecords != null)
				{
					recordSize = allRecords.size();
				}
				for (int i = 0; i < recordSize; i++)
				{
					BinLocationBean binLocationBean =
						(BinLocationBean) allRecords.get(i);
					if (binLocationBean
						.getBinLocation()
						.equals(binBean.getBinLocation()))
					{
						allRecords.remove(i);
						session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
						session.setAttribute(
							PaxTraxConstants.ALL_RECORDS,
							allRecords);
						break;
					}
				}

				/*
				 * Adjusting the Page number
				 */
				if (recordSize == 1)
				{
					/*
					 * if there was only one record and
					 * that got deleted then page number attribute
					 * should be removed from the session
					 */
					request.removeAttribute(PaxTraxConstants.PAGE_NUMBER);
				}
				else
					if ((recordSize % 10) == 1)
					{
						int pageNumber =
							Integer.parseInt(
								(String) request.getAttribute(
									PaxTraxConstants.PAGE_NUMBER));
						--pageNumber;
						request.setAttribute(
							PaxTraxConstants.PAGE_NUMBER,
							Integer.toString(pageNumber));
					}

			}
			request.setAttribute(
				PaxTraxConstants.SUCCESS,
				"" + PaxTraxConstants.BIN_LOCATION_DELETED);
			binForm.setBinLocationBean(binBean);
			forward = PaxTraxConstants.MAINTAIN_BIN_LOCATION_CONFIRMATION;
		}
		catch (BinLocationException binException)
		{
			request.setAttribute(
				PaxTraxConstants.ERROR_CODE,
				"" + binException.getErrorCode());
			request.setAttribute(
				PaxTraxConstants.SUCCESS,
				PaxTraxConstants.TRUE);
			forward = PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::removeBinLocationDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * Gets the bin location details for the specified bin location
	 * @param mapping ActionMapping 
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in 
	 * getting the details
	 */
	public ActionForward getBinLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::getBinLocation::Begin");
		BinLocationForm binForm = (BinLocationForm) form;
		BinLocationBean binBean = binForm.getBinLocationBean();
		request.setAttribute(
			PaxTraxConstants.FROM_PAGE,
			PaxTraxConstants.MAINTAIN_BIN);
		BinLocationDelegate binDelegate = new BinLocationDelegate();
		try
		{
			binBean = binDelegate.getBinLocationDetails(binBean);
			binForm.setBinLocationBean(binBean);
			request.setAttribute(
				PaxTraxConstants.SUCCESS,
				PaxTraxConstants.TRUE);
		}
		catch (BinLocationException binException)
		{
			request.setAttribute(
				PaxTraxConstants.ERROR_CODE,
				"" + binException.getErrorCode());
		}
		PaxTraxLog.logDebug("PaxTrax::BinLocationAction::getBinLocation::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE);
	}

	/**
	 * This method is used to get pickuplocationlist and to create bin location 
	 * by forwarding to create bin location page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in getting 
	 * pickuplocation list
	 */
	public ActionForward createBinLocationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::createBinLocationPage::Begin");
		BinLocationForm binLocationForm = (BinLocationForm) form;
		BinLocationBean binBean = new BinLocationBean();
		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.BAG_TRACKING);
		ReferenceDataBean referData = new ReferenceDataBean();
		binBean.setPickupLocationBean(referData);
		ReferenceDataDelegate referrenceDelegate = new ReferenceDataDelegate();
		ArrayList pickupLocationList =
			referrenceDelegate.loadReferenceData(
				PaxTraxConstants.PICK_UP_LOCATION);
		binLocationForm.setBinLocationBean(binBean);
		binLocationForm.setPickupLocationList(pickupLocationList);
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::createBinLocationPage::End");
		return mapping.findForward(PaxTraxConstants.CREATE_BIN_LOCATION_PAGE);
	}

	/**
	 * Saves Bin location Details in the database
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in saving
	 */
	public ActionForward saveBinLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::saveBinLocationDetails::Begin");
		BinLocationForm binForm = (BinLocationForm) form;
		BinLocationBean binBean = binForm.getBinLocationBean();
		BinLocationDelegate binDelegate = new BinLocationDelegate();
		String forward = null;
		HttpSession session = request.getSession();
		binBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		ArrayList pickupLocationList = binForm.getPickupLocationList();
		ReferenceDataBean referrenceData = null;
		int size = 0;
		if (pickupLocationList != null)
		{
			size = pickupLocationList.size();
		}
		for (int i = 0; i < size; i++)
		{
			referrenceData = (ReferenceDataBean) pickupLocationList.get(i);
			if (referrenceData
				.getCodeId()
				.equals(binBean.getPickupLocationBean().getCodeId()))
			{
				binBean.setPickupLocationBean(referrenceData);
				break;
			}
		}
		try
		{
			binDelegate.saveBinLocationDetails(binBean);
			binForm.setBinLocationBean(binBean);
			forward = PaxTraxConstants.BIN_LOCATION_CONFIRMATION;
		}
		catch (BinLocationException binException)
		{
			binForm.setBinLocationBean(binBean);
			request.setAttribute(
				PaxTraxConstants.ERROR_CODE,
				"" + binException.getErrorCode());
			forward = PaxTraxConstants.CREATE_BIN_LOCATION_PAGE;
		}

		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::saveBinLocationDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * This method is used to maintain bin location details
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in maintaining 
	 * the details
	 */
	public ActionForward maintainBinLocationPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::maintainBinLocationPage::Begin");
		BinLocationForm binLocationForm = (BinLocationForm) form;
		BinLocationBean binBean = new BinLocationBean();
		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.BAG_TRACKING);
		ReferenceDataBean referData = new ReferenceDataBean();
		binBean.setPickupLocationBean(referData);
		ReferenceDataDelegate referrenceDelegate = new ReferenceDataDelegate();
		ArrayList pickupLocationList =
			referrenceDelegate.loadReferenceData(
				PaxTraxConstants.PICK_UP_LOCATION);
		binLocationForm.setBinLocationBean(binBean);
		binLocationForm.setPickupLocationList(pickupLocationList);
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::maintainBinLocationPage::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE);
	}

	/**
	 * Loads bin location details from the database
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in loading the
	 * details
	 */
	public ActionForward loadBinLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::loadBinLocationDetails::Begin");
		BinLocationForm binForm = (BinLocationForm) form;
		HttpSession session = request.getSession();
		ArrayList allRecords =
			(ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);
		int index = Integer.parseInt((String) request.getParameter("indexId"));
		BinLocationBean binLocationBean =
			(BinLocationBean) allRecords.get(index - 1);
	
		binForm.setBinLocationBean(binLocationBean);
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);
		request.setAttribute(
			PaxTraxConstants.PAGE_NUMBER,
			request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute(PaxTraxConstants.SUCCESS, PaxTraxConstants.TRUE);
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::loadBinLocationDetails::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE);
	}

	/**
	 * This method is used to change the language
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BinLocationAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country =
			request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String forward = null;
		String errorCode = (String) request.getParameter("erc");
		String success = (String) request.getParameter("suc");

		if (language != null && country != null)
		{
			super.changeLanguage(request, language, country);
		}

		HttpSession session = request.getSession();
		String page = (String) session.getAttribute(PaxTraxConstants.PAGE);

		if (PaxTraxConstants.CREATE_BIN_LOCATION_PAGE.equals(page))
		{
			if (!errorCode.equals("-1"))
			{
				request.setAttribute(PaxTraxConstants.ERROR_CODE, errorCode);
			}
			forward = PaxTraxConstants.CREATE_BIN_LOCATION_PAGE;
		}
		else
			if (PaxTraxConstants.BIN_LOCATION_CONFIRMATION.equals(page))
			{
				forward = PaxTraxConstants.BIN_LOCATION_CONFIRMATION;
			}
			else
				if (PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE.equals(page))
				{
					String fromPage =
						request.getParameter(PaxTraxConstants.FROM_PAGE);
					String fromPageNumber =
						request.getParameter(PaxTraxConstants.FROM_PAGE_NUMBER);
					request.setAttribute(
						PaxTraxConstants.PAGE_NUMBER,
						fromPageNumber);
					if (errorCode != null)
					{
						if (!fromPage.equals("null")
							&& !errorCode.equals("232"))
						{
							request.setAttribute(
								PaxTraxConstants.SUCCESS,
								PaxTraxConstants.TRUE);
						}
						if (!errorCode.equals("-1"))
						{
							request.setAttribute(
								PaxTraxConstants.ERROR_CODE,
								errorCode);
						}
					}
					request.setAttribute(PaxTraxConstants.FROM_PAGE, fromPage);
					forward = PaxTraxConstants.MAINTAIN_BIN_LOCATION_PAGE;
				}
				else
					if (PaxTraxConstants
						.MAINTAIN_BIN_LOCATION_CONFIRMATION
						.equals(page))
					{
						request.setAttribute(PaxTraxConstants.SUCCESS, success);
						String fromPage =
							request.getParameter(PaxTraxConstants.FROM_PAGE);
						request.setAttribute(
							PaxTraxConstants.FROM_PAGE,
							fromPage);
						String fromPageNumber =
							request.getParameter(
								PaxTraxConstants.FROM_PAGE_NUMBER);
						request.setAttribute(
							PaxTraxConstants.PAGE_NUMBER,
							fromPageNumber);
						forward =
							PaxTraxConstants.MAINTAIN_BIN_LOCATION_CONFIRMATION;
					}
		PaxTraxLog.logDebug("PaxTrax::BinLocationAction::changeLanguage::End");
		return mapping.findForward(forward);
	}

}
