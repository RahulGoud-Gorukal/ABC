package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByFlightInquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Bag Status By flight attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 06/07/2004     R.R.Yuvarani     Created   
*/

public class BagStatusByFlightInquiryForm extends PaxTraxActionForm
{
	public BagStatusByFlightInquiryForm()
	{
	}
	
	private ArrayList airlineCodeList = null;
	
	private BagStatusByFlightInquiryBean bagStatusInquiry = null;
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		if (bagStatusInquiry != null) bagStatusInquiry.setBagFound("N");
	}


	/**
	 * Returns the airlineCodeList.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodeList()
	{
		return airlineCodeList;
	}

	/**
	 * Returns the bagStatusInquiry.
	 * @return BagStatusByFlightInquiryBean
	 */
	public BagStatusByFlightInquiryBean getBagStatusInquiry()
	{
		return bagStatusInquiry;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setAirlineCodeList(ArrayList airlineCodeList)
	{
		this.airlineCodeList = airlineCodeList;
	}

	/**
	 * Sets the bagStatusInquiry.
	 * @param bagStatusInquiry The bagStatusInquiry to set
	 */
	public void setBagStatusInquiry(BagStatusByFlightInquiryBean bagStatusInquiry)
	{
		this.bagStatusInquiry = bagStatusInquiry;
	}

}

