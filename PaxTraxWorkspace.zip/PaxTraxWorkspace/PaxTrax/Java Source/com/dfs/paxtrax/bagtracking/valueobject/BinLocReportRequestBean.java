package com.dfs.paxtrax.bagtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 28/06/2004	Cyril Prince.J	Created   
 */

public class BinLocReportRequestBean extends PaxTraxValueObject{
	
	private String binStartLocation;
	private String binEndLocation;
	private boolean isAirportBin;
	
	
	
	/**
	 * Returns the binEndLocation.
	 * @return String
	 */
	public String getBinEndLocation() {
		return binEndLocation;
	}

	/**
	 * Returns the binStartLocation.
	 * @return String
	 */
	public String getBinStartLocation() {
		return binStartLocation;
	}

	/**
	 * Returns the isAirportBin.
	 * @return boolean
	 */
	public boolean isAirportBin() {
		return isAirportBin;
	}

	/**
	 * Sets the binEndLocation.
	 * @param binEndLocation The binEndLocation to set
	 */
	public void setBinEndLocation(String binEndLocation) {
		this.binEndLocation = binEndLocation;
	}

	/**
	 * Sets the binStartLocation.
	 * @param binStartLocation The binStartLocation to set
	 */
	public void setBinStartLocation(String binStartLocation) {
		this.binStartLocation = binStartLocation;
	}

	/**
	 * Sets the isAirportBin.
	 * @param isAirportBin The isAirportBin to set
	 */
	public void setIsAirportBin(boolean isAirportBin) {
		this.isAirportBin = isAirportBin;
	}

}
