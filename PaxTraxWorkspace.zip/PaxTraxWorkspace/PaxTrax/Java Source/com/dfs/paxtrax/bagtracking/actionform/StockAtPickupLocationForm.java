package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.StockAtPickupLocationInquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Stock at pickup location attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 2/07/2004     R.R.Yuvarani     Created   
*/

public class StockAtPickupLocationForm extends PaxTraxActionForm
{
	
	//PickupLocation List
	private ArrayList pickupLocation = null;
	
	//Stock at pickup location inquiry bean
	private StockAtPickupLocationInquiryBean stockAtPickup = null;

	/**
	 * Constructor for the class
	 */
	public StockAtPickupLocationForm()
	{
	}

	/**
	 * Returns the pickupLocation.
	 * @return ArrayList
	 */
	public ArrayList getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Returns the stockAtPickup.
	 * @return StockAtPickupLocationInquiryBean
	 */
	public StockAtPickupLocationInquiryBean getStockAtPickup()
	{
		return stockAtPickup;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(ArrayList pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Sets the stockAtPickup.
	 * @param stockAtPickup The stockAtPickup to set
	 */
	public void setStockAtPickup(StockAtPickupLocationInquiryBean stockAtPickup)
	{
		this.stockAtPickup = stockAtPickup;
	}

}