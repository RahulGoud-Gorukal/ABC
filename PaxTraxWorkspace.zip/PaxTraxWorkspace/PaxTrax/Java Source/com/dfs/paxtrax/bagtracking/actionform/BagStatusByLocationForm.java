package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByLocationBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Bag Status By Location attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Jaganmohan Gopinath
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 06/07/2007     Umamaheswari    Created   
*/

public class BagStatusByLocationForm extends PaxTraxActionForm
{
	public BagStatusByLocationForm()
	{
	}
	
	private ArrayList bagLocationList = null;
	
	private BagStatusByLocationBean bagStatusLocationBean = null;
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		if (bagStatusLocationBean != null) bagStatusLocationBean.setBagFound("N");
	}
	/**
	 * @return
	 */
	public ArrayList getBagLocationList() {
		return bagLocationList;
	}

	/**
	 * @return
	 */
	public BagStatusByLocationBean getBagStatusLocationBean() {
		return bagStatusLocationBean;
	}

	/**
	 * @param list
	 */
	public void setBagLocationList(ArrayList list) {
		bagLocationList = list;
	}

	/**
	 * @param bean
	 */
	public void setBagStatusLocationBean(BagStatusByLocationBean bean) {
		bagStatusLocationBean = bean;
	}

}

