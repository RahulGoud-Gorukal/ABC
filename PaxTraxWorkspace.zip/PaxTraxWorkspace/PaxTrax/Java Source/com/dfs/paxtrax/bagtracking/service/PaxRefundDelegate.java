package com.dfs.paxtrax.bagtracking.service;

/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.PaxRefundBO;
import com.dfs.paxtrax.bagtracking.business.PaxRefundBOHome;
import com.dfs.paxtrax.bagtracking.exception.PaxRefundException;
import com.dfs.paxtrax.bagtracking.valueobject.PaxRefundBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

/**
* This Delegate  class is used for inserting and updating paxRefund records
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 26/06/2004    Joseph Oommen A Created
*/
public class PaxRefundDelegate
{

	/*
	 * Holds service locator instance
	 */
	private ServiceLocator serviceLocator = null;
	/*
	 * Holds the Home interface
	 */
	private PaxRefundBOHome paxRefundBOHome = null;
	/*
	 * Hold the remote interface
	 */
	private PaxRefundBO paxRefundBO = null;
	/*
	 *Default Construtor for LocationDelegate
	 */

	public PaxRefundDelegate()
	{
	}

	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::PaxRefundDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			paxRefundBOHome =
				(PaxRefundBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						"ejb/com/dfs/paxtrax/bagtracking/business/PaxRefundBOHome"),
					PaxRefundBOHome.class);
		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Naming Exception PaxRefund Delagte ",ne);
			throw new PaxTraxSystemException(ne);
		}
		if (paxRefundBOHome == null)
		{
						PaxTraxLog.logError("Home is null");
			throw new PaxTraxSystemException(250);
		}
		try
		{
			paxRefundBO = paxRefundBOHome.create();
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("CreateException PaxRefund Delagte ",ce);
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("RemoteException PaxRefund Delagte ",re);
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::PaxRefundDelegate::jndiCall::End");
	}

	public ArrayList searchPaxRefundDetails(PaxRefundBean paxRefundBean)
		throws PaxTraxSystemException, PaxRefundException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundDelegate::searchPaxRefundDetails::Begin");
		ArrayList paxRefundDetails = new ArrayList();
		if (paxRefundBOHome == null)
		{
			jndiCall();
		}
		try
		{
			paxRefundDetails =
				paxRefundBO.searchPaxRefundDetails(paxRefundBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}

		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundDelegate::searchPaxRefundDetails::End");
		return paxRefundDetails;
	}

	
	
	public void savePaxRefund(ArrayList resultList)throws PaxTraxSystemException, PaxRefundException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundDelegate::savePaxRefund::Begin");

		if (paxRefundBOHome == null)
		{
			jndiCall();
		}
		try
		{
			paxRefundBO.savePaxRefund(resultList);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundDelegate::savePaxRefund::End");
		
	}
	
	public ArrayList searchFlightChangeDetails(PaxRefundBean paxRefundBean)
		throws PaxTraxSystemException, PaxRefundException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundDelegate::searchFlightChangeDetails::Begin");
		ArrayList paxRefundDetails = new ArrayList();
		if (paxRefundBOHome == null)
		{
			jndiCall();
		}
		try
		{
			paxRefundDetails =
				paxRefundBO.searchFlightChangeDetails(paxRefundBean);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}

		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundDelegate::searchFlightChangeDetails::End");
		return paxRefundDetails;
	}
}
