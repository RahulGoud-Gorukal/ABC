package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.BagStatusByFlightInquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByFlightInquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for a flight number
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 06/07/2004    Yuvarani		Created
* 10/11/2004	P.C. Sathish	Added Method (bagsMissingByFlight)
*/

public class BagStatusByFlightInquiryAction extends PaxTraxAction
{

	/**
	 * Method goToBagStatusByFlightInquiry.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward goToBagStatusByFlightInquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByFlightInquiryAction::goToBagStatusByFlightInquiry::Begin");
		BagStatusByFlightInquiryForm bagForm =
			(BagStatusByFlightInquiryForm) form;
		BagStatusByFlightInquiryBean bagInquiryBean =
			new BagStatusByFlightInquiryBean();
		ReferenceDataDelegate referData = new ReferenceDataDelegate();
		String forward = null;
		try
		{
			ArrayList airline =
				referData.loadReferenceData(PaxTraxConstants.AIRLINE_CODE);
			bagForm.setBagStatusInquiry(bagInquiryBean);
			bagForm.setAirlineCodeList(airline);
			forward = PaxTraxConstants.BAG_STATUS_BY_FLIGHT;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagStatusByFlightInquiryAction::goToBagStatusByFlightInquiry",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByFlightInquiryAction::goToBagStatusByFlightInquiry::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method getBagStatusByFlightInquiry.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 * @throws BagTrackingReportsException
	 */
	public ActionForward getBagStatusByFlightInquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByFlightInquiryAction::getBagStatusByFlightInquiry::Begin");
		BagStatusByFlightInquiryForm bagForm =
			(BagStatusByFlightInquiryForm) form;
		BagStatusByFlightInquiryBean bagStatusInquiry =
			bagForm.getBagStatusInquiry();
		BagTrackingReportsDelegate bagStatusDelegate =
			new BagTrackingReportsDelegate();
		String forward = null;

		try
		{
			bagStatusInquiry =
				bagStatusDelegate.getBagStatusByFlightInquiry(bagStatusInquiry);

			if ((bagStatusInquiry.getStatusTotalList() == null
				&& bagStatusInquiry.getBagsList() == null)
				|| (bagStatusInquiry.getStatusTotalList().size() == 0
					&& bagStatusInquiry.getBagsList().size() == 0))
			{
				request.setAttribute(
					PaxTraxConstants.ERROR_CODE,
					PaxTraxConstants.ERROR_CODE);
			}

			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			bagForm.setBagStatusInquiry(bagStatusInquiry);
			forward = PaxTraxConstants.BAG_STATUS_BY_FLIGHT;
		}
		catch (BagTrackingReportsException bagException)
		{
			PaxTraxLog.logDebug(
				"Paxtrax::BagStatusByFlightInquiryAction::getBagStatusByFlightInquiry"+
				bagException);
			ArrayList airline = bagForm.getAirlineCodeList();

			if (airline != null)
			{
				ReferenceDataBean referData = null;
				for (int i = 0; i < airline.size(); i++)
				{
					referData = (ReferenceDataBean) airline.get(i);
					if ((referData.getCodeId())
						.equals(bagStatusInquiry.getAirlineCode()))
					{
						bagStatusInquiry.setAirlineCodeValue(
							referData.getCodeValue());
					}
				}
			}
			bagStatusInquiry.setDepartureTime("");
			bagForm.setBagStatusInquiry(bagStatusInquiry);
			request.setAttribute(
				PaxTraxConstants.ERROR_CODE,
				"" + bagException.getErrorCode());
			forward = PaxTraxConstants.BAG_STATUS_BY_FLIGHT;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagStatusByFlightInquiryAction::getBagStatusByFlightInquiry",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByFlightInquiryAction::getBagStatusByFlightInquiry::End");
		return mapping.findForward(forward);
	}

	public ActionForward getStatusRecords(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByFlightInquiryAction::getStatusRecords::Begin");
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			request.getParameter(PaxTraxConstants.OPERATION));
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByFlightInquiryAction::getStatusRecords::End");
		return mapping.findForward(PaxTraxConstants.BAG_STATUS_BY_FLIGHT);
	}

	public ActionForward printBagStatusByFlight(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingEnquiryAction::printBagTrackingInquiry::Begin");
			BagStatusByFlightInquiryForm bagStatusByFlightInquiryForm =
				(BagStatusByFlightInquiryForm) form;
			BagStatusByFlightInquiryBean bagStatusInquiry =
				bagStatusByFlightInquiryForm.getBagStatusInquiry();
			bagStatusByFlightInquiryForm.setBagStatusInquiry(bagStatusInquiry);
			String operation = (String) request.getParameter("operation1");

			String result = (String) request.getParameter("result1");
			if (operation != null
				&& !operation.equals("")
				&& !operation.equals("null"))
			{
				operation = operation.trim();
				request.setAttribute(PaxTraxConstants.OPERATION, operation);
			}

			if (result != null && !result.equals("") && !result.equals("null"))
			{
				result = result.trim();
				request.setAttribute(PaxTraxConstants.RESULT, result);
			}

			ArrayList airLineList =
				bagStatusByFlightInquiryForm.getAirlineCodeList();
			String airLineCode =
				bagStatusByFlightInquiryForm
					.getBagStatusInquiry()
					.getAirlineCode();
			for (int i = 0; i < airLineList.size(); i++)
			{
				ReferenceDataBean tempBean =
					(ReferenceDataBean) airLineList.get(i);
				if (airLineCode.equals(tempBean.getCodeId()))
				{
					bagStatusByFlightInquiryForm
						.getBagStatusInquiry()
						.setAirlineCodeValue(
						tempBean.getCodeValue());
					break;
				}
			}

			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingEnquiryAction::printBagTrackingInquiry::End");
			forward = "printBagStatusByFlight";
		}
		catch (Exception ex)
		{

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}

}