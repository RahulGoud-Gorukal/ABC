package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import com.dfs.paxtrax.bagtracking.valueobject.TruckBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * This is action form which contains Truck attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/05/2004   Joseph Oommen A     Created   
*/

public class TruckForm extends PaxTraxActionForm {
    /**
       The TruckBean that is used to store all the truck details
     */
    private TruckBean truckBean = null;
    
	/**
	 * Returns the truckBean.
	 * @return TruckBean
	 */
	public TruckBean getTruckBean()
	{
		return truckBean;
	}

	/**
	 * Sets the truckBean.
	 * @param truckBean The truckBean to set
	 */
	public void setTruckBean(TruckBean truckBean)
	{
		this.truckBean = truckBean;
	}

}
