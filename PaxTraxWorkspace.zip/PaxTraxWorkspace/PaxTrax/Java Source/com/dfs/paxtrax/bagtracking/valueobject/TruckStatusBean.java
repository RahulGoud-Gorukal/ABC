package com.dfs.paxtrax.bagtracking.valueobject;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Truck attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 01/06/2004   Sundarrajan.K.	Created   
*/


public class TruckStatusBean extends PaxTraxValueObject
{

	// sets the status of the truck
	private String status = null;
	
	// sets the statusId of the truck
	private int statusId = 0;
	
	// sets the date and time the truck departed
	private String dateTime = null;
	
	// sets the terminal for the truck
	private String terminal = null;
	
	// sets the operator for the truck
	private String operator = null;
	
	


	/**
	 * Returns the dateTime.
	 * @return String
	 */
	public String getDateTime()
	{
		return dateTime;
	}

	/**
	 * Returns the operator.
	 * @return String
	 */
	public String getOperator()
	{
		return operator;
	}

	/**
	 * Returns the status.
	 * @return String
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * Returns the terminal.
	 * @return String
	 */
	public String getTerminal()
	{
		return terminal;
	}

	/**
	 * Sets the dateTime.
	 * @param dateTime The dateTime to set
	 */
	public void setDateTime(String dateTime)
	{
		this.dateTime = dateTime;
	}

	/**
	 * Sets the operator.
	 * @param operator The operator to set
	 */
	public void setOperator(String operator)
	{
		this.operator = operator;
	}

	/**
	 * Sets the status.
	 * @param status The status to set
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * Sets the terminal.
	 * @param terminal The terminal to set
	 */
	public void setTerminal(String terminal)
	{
		this.terminal = terminal;
	}

	/**
	 * Returns the statusId.
	 * @return int
	 */
	public int getStatusId()
	{
		return statusId;
	}

	/**
	 * Sets the statusId.
	 * @param statusId The statusId to set
	 */
	public void setStatusId(int statusId)
	{
		this.statusId = statusId;
	}

}
