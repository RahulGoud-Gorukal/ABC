package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.BagTrackingEnquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Bag not ready for pickup attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 08/07/2004     R.R.Yuvarani     Created   
*/

public class BagNotReadyForPickupForm extends PaxTraxActionForm
{
	private BagTrackingEnquiryBean bagEnquiry = null;

	private ArrayList airlineCodeList = null;
	
	private String reason = null;

	/**
	 * Returns the bagEnquiry.
	 * @return BagTrackingEnquiryBean
	 */
	public BagTrackingEnquiryBean getBagEnquiry()
	{
		return bagEnquiry;
	}

	/**
	 * Sets the bagEnquiry.
	 * @param bagEnquiry The bagEnquiry to set
	 */
	public void setBagEnquiry(BagTrackingEnquiryBean bagEnquiry)
	{
		this.bagEnquiry = bagEnquiry;
	}

	/**
	 * Returns the airlineCodeList.
	 * @return ArrayList
	 */
	public ArrayList getAirlineCodeList()
	{
		return airlineCodeList;
	}

	/**
	 * Sets the airlineCodeList.
	 * @param airlineCodeList The airlineCodeList to set
	 */
	public void setAirlineCodeList(ArrayList airlineCodeList)
	{
		this.airlineCodeList = airlineCodeList;
	}

	/**
	 * Returns the reason.
	 * @return String
	 */
	public String getReason()
	{
		return reason;
	}

	/**
	 * Sets the reason.
	 * @param reason The reason to set
	 */
	public void setReason(String reason)
	{
		this.reason = reason;
	}

}
