package com.dfs.paxtrax.bagtracking.business;
/**
 * Home interface for Enterprise Bean: BagOverrideBO
 */
public interface BagOverrideBOHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: BagOverrideBO
	 */
	public com.dfs.paxtrax.bagtracking.business.BagOverrideBO create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
