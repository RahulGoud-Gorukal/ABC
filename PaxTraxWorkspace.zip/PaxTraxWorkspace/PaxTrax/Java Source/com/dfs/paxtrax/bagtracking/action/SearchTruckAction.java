package com.dfs.paxtrax.bagtracking.action;


/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.SearchTruckForm;
import com.dfs.paxtrax.bagtracking.actionform.TruckForm;
import com.dfs.paxtrax.bagtracking.exception.TruckException;
import com.dfs.paxtrax.bagtracking.service.TruckDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.TruckBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;


/**
* This is action class which performs search truck  details
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 02/06/2004    R.R.Yuvarani    Created
*/
 
public class SearchTruckAction extends PaxTraxAction
{

	/**
	 * This method searches for truck that satisfies the given criteria
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem while searching
	 */
	public ActionForward searchTruckDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
			int pageNumber = 0;
			ArrayList allRecords = null;
			ArrayList currentRecords = null;
			SearchTruckForm searchTruckForm = (SearchTruckForm)form;
			HttpSession session = request.getSession();
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			
			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0))
			{
				int size = 0;
				pageNumber = 1;
				TruckDelegate truckDelegate = new TruckDelegate();
				TruckBean truckBean = new TruckBean();
				truckBean.setManufacturer(searchTruckForm.getManufacturer());
				truckBean.setMake(searchTruckForm.getMake());
				truckBean.setModel(searchTruckForm.getModel());
				truckBean.setYear(searchTruckForm.getYear());
				allRecords = truckDelegate.searchTruckDetails(truckBean);	
				
				if (allRecords != null)
					size = allRecords.size();
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.
											SIZE_OF_ALL_TRUCK_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_TRUCK_RECORDS,
					Integer.toString(size));
			}
			else
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((allRecords != null) && (allRecords.size() != 0))
			{
				// Get records to be displayed for the passed page number
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));

			//Sets records to be displayed for the page number 
			searchTruckForm.setTruckList(currentRecords);				
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			request.setAttribute(PaxTraxConstants.FROM_PAGE,PaxTraxConstants
															.SEARCH_TRUCK_PAGE);
		
		return mapping.findForward(PaxTraxConstants.SEARCH_TRUCK_PAGE);
		
	}

	/**
	 * This method transfers the control to search page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in transferring
	 * the control to search page
	 */
	public ActionForward goToTruckSearchPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		SearchTruckForm searchTruckForm = (SearchTruckForm)form;
		searchTruckForm.setMake(null);
		searchTruckForm.setManufacturer(null);
		searchTruckForm.setModel(null);
		searchTruckForm.setYear(null);
		searchTruckForm.setTruckList(null);
		request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);
		return mapping.findForward(PaxTraxConstants.SEARCH_TRUCK_PAGE);
	}

	/**
	 * This method is used to change the language
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants
													.CHANGE_LANGUAGE_COUNTRY);
		String pageNumber = request.getParameter("pno");
		String forward = null;
		if (language != null && country != null)
		{
			super.changeLanguage(request,language,country);
		}

		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
			if (!fromPage.equals("null"))
			{
				if (!pageNumber.equals("-1"))
				{
				request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);
				}
				request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);
				request.setAttribute(PaxTraxConstants.RESULT,
												PaxTraxConstants.SUCCESS);
			}
			else
			{
			request.setAttribute(PaxTraxConstants.RESULT,
												PaxTraxConstants.FAILURE);
			}
			forward = PaxTraxConstants.SEARCH_TRUCK_PAGE;
		return mapping.findForward(forward);
	}
}
