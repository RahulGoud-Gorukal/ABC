package com.dfs.paxtrax.bagtracking.exception;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxException;

/**
 * 
 * Exception handling class for throwing errors related to
 * bagoverride process.
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 15/06/2004	P.C. Sathish	Created   
 */

public class BagOverrideException  extends PaxTraxException {

	/**
	 * Constructor accepts actual exception object
	 *
	 * @param actualException Exception   Actual Exception
	 */
	public BagOverrideException(Exception actualException) {
	
	    super(PaxTraxErrorMessages.PT_SYSEXCEPTION, actualException);
	}
	
	/**
	 * Constructor accepts error code
	 *
	 * @param actualException Exception   Actual Exception
	 */
	public BagOverrideException( int errorCode) {
	
	    super(errorCode);
	}

}
