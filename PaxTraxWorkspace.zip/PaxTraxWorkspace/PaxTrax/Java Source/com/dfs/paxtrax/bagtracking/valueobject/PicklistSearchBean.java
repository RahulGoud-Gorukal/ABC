package com.dfs.paxtrax.bagtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class PicklistSearchBean extends PaxTraxValueObject
{
	/* The Ref ID for Pickup Location */
	String pickupLocationRefId = null;
	
	/* The Code Id of the Pickup Location selected */
	String pickupLocationCodeId = null;
	
	/* The departure date selected for generating picklist */
	String departureDate = null;
	
	/* The Ref ID for Shift */
	String shiftRefId = null;
	
	/* The Code Id of the selected Shift */
	String shiftCodeId = null;
	
	/* The current Date */
	String currentDate = null;
	
	/* The value of the pickup location selected */
	String pickupLocationValue = null;
	
	/* The value pf shift selected */
	String shiftValue = null;
	
	boolean printPicklist = false;
		
	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Returns the pickupLocationCodeId.
	 * @return String
	 */
	public String getPickupLocationCodeId()
	{
		return pickupLocationCodeId;
	}

	/**
	 * Returns the pickupLocationRefId.
	 * @return String
	 */
	public String getPickupLocationRefId()
	{
		return pickupLocationRefId;
	}

	/**
	 * Returns the shiftCodeId.
	 * @return String
	 */
	public String getShiftCodeId()
	{
		return shiftCodeId;
	}

	/**
	 * Returns the shiftRefId.
	 * @return String
	 */
	public String getShiftRefId()
	{
		return shiftRefId;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the pickupLocationCodeId.
	 * @param pickupLocationCodeId The pickupLocationCodeId to set
	 */
	public void setPickupLocationCodeId(String pickupLocationCodeId)
	{
		this.pickupLocationCodeId = pickupLocationCodeId;
	}

	/**
	 * Sets the pickupLocationRefId.
	 * @param pickupLocationRefId The pickupLocationRefId to set
	 */
	public void setPickupLocationRefId(String pickupLocationRefId)
	{
		this.pickupLocationRefId = pickupLocationRefId;
	}

	/**
	 * Sets the shiftCodeId.
	 * @param shiftCodeId The shiftCodeId to set
	 */
	public void setShiftCodeId(String shiftCodeId)
	{
		this.shiftCodeId = shiftCodeId;
	}

	/**
	 * Sets the shiftRefId.
	 * @param shiftRefId The shiftRefId to set
	 */
	public void setShiftRefId(String shiftRefId)
	{
		this.shiftRefId = shiftRefId;
	}

	/**
	 * Returns the currentDate.
	 * @return String
	 */
	public String getCurrentDate()
	{
		return currentDate;
	}

	/**
	 * Returns the pickupLocationValue.
	 * @return String
	 */
	public String getPickupLocationValue()
	{
		return pickupLocationValue;
	}

	/**
	 * Returns the shiftValue.
	 * @return String
	 */
	public String getShiftValue()
	{
		return shiftValue;
	}

	/**
	 * Sets the currentDate.
	 * @param currentDate The currentDate to set
	 */
	public void setCurrentDate(String currentDate)
	{
		this.currentDate = currentDate;
	}

	/**
	 * Sets the pickupLocationValue.
	 * @param pickupLocationValue The pickupLocationValue to set
	 */
	public void setPickupLocationValue(String pickupLocationValue)
	{
		this.pickupLocationValue = pickupLocationValue;
	}

	/**
	 * Sets the shiftValue.
	 * @param shiftValue The shiftValue to set
	 */
	public void setShiftValue(String shiftValue)
	{
		this.shiftValue = shiftValue;
	}

	/**
	 * Returns the printPicklist.
	 * @return boolean
	 */
	public boolean getPrintPicklist()
	{
		return printPicklist;
	}

	/**
	 * Sets the printPicklist.
	 * @param printPicklist The printPicklist to set
	 */
	public void setPrintPicklist(boolean printPicklist)
	{
		this.printPicklist = printPicklist;
	}

}
