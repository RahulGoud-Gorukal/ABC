package com.dfs.paxtrax.bagtracking.business;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.bagtracking.exception.BagOverrideException;

 
/**
 * Remote interface for Enterprise Bean: BagOverrideBO
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 *           DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE          USER                COMMENTS
 * 05/11/2004    P.C. Sathish	     Created   
 */
public interface BagOverrideBO extends javax.ejb.EJBObject {
	public boolean assignAirPort(BagStatusBean bagBean) throws RemoteException,BagOverrideException, PaxTraxSystemException;
	public boolean assignWareHouse(BagStatusBean bagBean) throws RemoteException,BagOverrideException, PaxTraxSystemException;
	public ArrayList getTruckList() throws RemoteException, PaxTraxSystemException;
	public BagStatusBean changeSalesTransactionStatus(BagStatusBean bagBean) throws RemoteException,BagOverrideException, PaxTraxSystemException;
	//Added by selvam for CA# 294102 starts
	public boolean assignSeaPort(BagStatusBean bagBean) throws RemoteException,BagOverrideException, PaxTraxSystemException;
	public boolean releaseBags(BagStatusBean bagBean) throws RemoteException,BagOverrideException, PaxTraxSystemException;
	// Added/Modified by David for CR 3659 starts
	public ArrayList bagLookUp(BagStatusBean bagBean) throws RemoteException,BagOverrideException, PaxTraxSystemException;
	// Added/Modified by David for CR 3659 ends
	//	Added by selvam for CA# 294102 ends
}
