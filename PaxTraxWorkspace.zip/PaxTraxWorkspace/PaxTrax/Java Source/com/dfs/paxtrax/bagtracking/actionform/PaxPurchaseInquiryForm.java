package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */ 


import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.PaxPurchaseInquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Deivery Manifest attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE           USER            COMMENTS
 * 06/07/2004     Sundarrajan.K.  Created   
*/

public class PaxPurchaseInquiryForm extends PaxTraxActionForm
{
	// sets the pax purchase inquiry bean
	private PaxPurchaseInquiryBean paxPurchaseInquiryBean = null;
	
	// sets the bag status bean
	private BagStatusBean bagStatusBean = null;
	
	

	/**
	 * Returns the bagStatusBean.
	 * @return BagStatusBean
	 */
	public BagStatusBean getBagStatusBean()
	{
		return bagStatusBean;
	}

	/**
	 * Returns the paxPurchaseInquiryBean.
	 * @return PaxPurchaseInquiryBean
	 */
	public PaxPurchaseInquiryBean getPaxPurchaseInquiryBean()
	{
		return paxPurchaseInquiryBean;
	}

	/**
	 * Sets the bagStatusBean.
	 * @param bagStatusBean The bagStatusBean to set
	 */
	public void setBagStatusBean(BagStatusBean bagStatusBean)
	{
		this.bagStatusBean = bagStatusBean;
	}

	/**
	 * Sets the paxPurchaseInquiryBean.
	 * @param paxPurchaseInquiryBean The paxPurchaseInquiryBean to set
	 */
	public void setPaxPurchaseInquiryBean(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
	{
		this.paxPurchaseInquiryBean = paxPurchaseInquiryBean;
	}

}
