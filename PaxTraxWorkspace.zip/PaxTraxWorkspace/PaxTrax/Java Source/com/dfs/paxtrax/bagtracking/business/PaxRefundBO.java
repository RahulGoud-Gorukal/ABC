package com.dfs.paxtrax.bagtracking.business;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.bagtracking.exception.PaxRefundException;
import com.dfs.paxtrax.bagtracking.valueobject.PaxRefundBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;

/**
*Remote interface for Enterprise Bean: LocationBO
*
* @author Cognizant Technology Solutions
* contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER                COMMENTS
* 29/05/2004    Joseph Oommen A     Created   
*/
public interface PaxRefundBO  extends EJBObject{
    
    
   /**
     * Saves paxRefund details by invoking BO method.
     * @param paxRefundBean PaxRefundBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in saving paxRefund details
     */
    public void savePaxRefundDetails(PaxRefundBean paxRefundBean) throws RemoteException,PaxTraxSystemException,PaxRefundException;
    
    
    /**
     * Search the paxRefund details by invoking BO method.
     * @param paxRefundBean PaxRefundBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in search paxRefund details
     */
    public ArrayList searchPaxRefundDetails(PaxRefundBean paxRefundBean) throws RemoteException,PaxTraxSystemException,PaxRefundException;
    
    
    /**
     * updates the paxRefund details by invoking BO method.
     * @param paxRefundBean PaxRefundBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in search paxRefund details
     */
    public void savePaxRefund(ArrayList resultList)throws RemoteException,PaxTraxSystemException, PaxRefundException;
    
     /**
     * Search the flight Change details by invoking BO method.
     * @param paxRefundBean PaxRefundBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in search paxRefund details
     */
    public ArrayList searchFlightChangeDetails(PaxRefundBean paxRefundBean) throws RemoteException,PaxTraxSystemException,PaxRefundException;
    
    
}
