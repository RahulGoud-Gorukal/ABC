package com.dfs.paxtrax.bagtracking.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.GeneratePicklistForm;
import com.dfs.paxtrax.bagtracking.service.GeneratePicklistDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.PicklistSearchBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class GeneratePicklistAction extends PaxTraxAction 
{
    public ActionForward goToGeneratePicklistPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
    	try
    	{
			PaxTraxLog.logDebug("PaxTrax::GeneratePicklistAction::goToGeneratePicklistPage::Begin");
			GeneratePicklistForm pickListForm = (GeneratePicklistForm) form;
	
			PicklistSearchBean picklistSearchBean = new PicklistSearchBean();
			picklistSearchBean.setPickupLocationRefId(PaxTraxConstants.PICK_UP_LOCATION);
			picklistSearchBean.setShiftRefId(PaxTraxConstants.SHIFT);
			picklistSearchBean.setPrintPicklist(false);
			
			ReferenceDataDelegate rdDelegate = new ReferenceDataDelegate();
			pickListForm.setPickupLocationList(rdDelegate.loadReferenceData(PaxTraxConstants.PICK_UP_LOCATION));
			
			pickListForm.setShiftList(rdDelegate.loadReferenceData(PaxTraxConstants.SHIFT));

			pickListForm.setPicklistSearchBean(picklistSearchBean);								
			
			HttpSession session = request.getSession();
			session.setAttribute(PaxTraxConstants.MODULE_NAME, PaxTraxConstants.BAG_TRACKING);
			
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
	
			PaxTraxLog.logDebug("PaxTrax::GeneratePicklistAction::goToGeneratePicklistPage::End");
    	}
    	catch(PaxTraxSystemException pse)
    	{
    		return(mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));	
    	}
    	
    	return(mapping.findForward(PaxTraxConstants.BT_GEN_PICKLIST_PAGE));
    }
    
    public ActionForward getPickList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
    	try
    	{
    		PaxTraxLog.logDebug("PaxTrax::GeneratePicklistAction::getPickList::Begin");

			int pageNumber = 0;
			ArrayList allRecords = null;
			ArrayList currentRecords = null;
			GeneratePicklistForm pickListForm = (GeneratePicklistForm) form;

			/*This part has been inserted for the print facility */
			String print = request.getParameter("print");

			HttpSession session = request.getSession();
			String pageNumberStr = request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr = ((pageNumberStr == null) || pageNumberStr.equals(SQLConstants.BLANK)) ? null: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0))
			{
				int size = 0;
				pageNumber = 1;
				
	    		GeneratePicklistDelegate delegate = new GeneratePicklistDelegate();
	    		
				if(print!=null && print.equals("yes"))
					pickListForm.getPicklistSearchBean().setPrintPicklist(true);
				
				String user = (String) session.getAttribute("userId");
				pickListForm.getPicklistSearchBean().setUser(user);
					
				allRecords = delegate.getPicklist(pickListForm.getPicklistSearchBean());
				pickListForm.getPicklistSearchBean().setPrintPicklist(false);
				
				if (allRecords != null)
					size = allRecords.size();
				

				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_RECORDS, Integer.toString(size));
			}
			else
				allRecords = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_RECORDS);

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((allRecords != null) && (allRecords.size() != 0))
			{
				// Get records to be displayed for the passed page number
				currentRecords = helper.getCurrentTableContent(allRecords, pageNumber, PaxTraxConstants.RECORDS_PER_PAGE);
			}
			
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, Integer.toString(pageNumber));

			//Sets records to be displayed for the page number 
			pickListForm.setPickList(currentRecords);

			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			
			if(print!=null && print.equals("yes") && allRecords.size()>0)
			{
				pickListForm.setPrintList(allRecords);

	    		Calendar c1 = Calendar.getInstance();
	    		int month = c1.get(Calendar.MONTH)+1;
	    		int date = c1.get(Calendar.DATE);
	    		int year = c1.get(Calendar.YEAR);
	    		
	    		String tempCurDate = "";
	    		
	    		tempCurDate = "" + year;
	    		tempCurDate = tempCurDate + "/" + (month<10 ? "0" + month : "" + month);
	    		tempCurDate = tempCurDate + "/" + (date<10 ? "0" + date : "" + date);
	    		
	    		pickListForm.getPicklistSearchBean().setCurrentDate(tempCurDate);
	    		ArrayList tempList1 = pickListForm.getShiftList();
	    		String shiftId = pickListForm.getPicklistSearchBean().getShiftCodeId();
	    		for(int i=0;i<tempList1.size();i++)
	    		{
	    			ReferenceDataBean referenceDataBean =(ReferenceDataBean)tempList1.get(i);
	    			String codeId=referenceDataBean.getCodeId();
	    			if(codeId.equals(shiftId))
	    			{
	    				pickListForm.getPicklistSearchBean().setShiftValue(referenceDataBean.getCodeValue());
	    				break;
	    			}
	    		}
	    		ArrayList tempList2 = pickListForm.getPickupLocationList();
	    		String pickupId = pickListForm.getPicklistSearchBean().getPickupLocationCodeId();
	    		for(int i=0;i<tempList2.size();i++)
	    		{
	    			ReferenceDataBean referenceDataBean =(ReferenceDataBean)tempList2.get(i);
	    			String codeId=referenceDataBean.getCodeId();
	    			if(codeId.equals(pickupId))
	    			{
	    				pickListForm.getPicklistSearchBean().setPickupLocationValue(referenceDataBean.getCodeValue());
	    				break;
	    			}
	    		}
	    		
	    		request.setAttribute("openPrintPage", "true");
			}
			
			PaxTraxLog.logDebug("PaxTrax::GeneratePicklistAction::getPickList::End");
		}
    	catch(PaxTraxSystemException pse)
    	{
    		return(mapping.findForward(PaxTraxConstants.SYSTEM_ERROR));
    	}
    	
    	return(mapping.findForward(PaxTraxConstants.BT_GEN_PICKLIST_PAGE));
    }
    
    public ActionForward openPrintPickListPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
    	return(mapping.findForward("printPicklistPage"));
    }
    
    public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
		PaxTraxLog.logDebug("PaxTrax::GeneratePicklistAction::changeLanguage::Begin");    	
		
		String forwardPage = "";
		
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		String result = request.getParameter("res");
		String pageNumber = request.getParameter("pN");
		
		if(language!=null && country!=null && result!=null)		
		{
			super.changeLanguage(request, language, country);
			forwardPage = PaxTraxConstants.BT_GEN_PICKLIST_PAGE;			
		}
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;					
		
		if(result.equals(PaxTraxConstants.SUCCESS))
		{
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		}
		else
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);		
		
		PaxTraxLog.logDebug("PaxTrax::GeneratePicklistAction::changeLanguage::End");
		
		return(mapping.findForward(forwardPage));
    }
}
