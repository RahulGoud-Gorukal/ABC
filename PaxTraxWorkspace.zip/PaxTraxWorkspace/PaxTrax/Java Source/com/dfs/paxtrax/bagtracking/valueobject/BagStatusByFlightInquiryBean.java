package com.dfs.paxtrax.bagtracking.valueobject;


/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
* This is valueobject class which contains bag status by flight attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 06/07/2004    R.R.Yuvarani     Created   
*/

public class BagStatusByFlightInquiryBean extends PaxTraxValueObject
{
	public BagStatusByFlightInquiryBean()
	{
	}
	
	private String bagFound;
	
	private String airlineCode = null;

	private String airlineCodeValue = null;
	
	private String flightNumber = null;
	
	private String departureDate = null;
	
	private String departureTime = null;
	
	private ArrayList statusTotalList = null;
	
	private ArrayList bagsList = null;
	
	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode()
	{
		return airlineCode;
	}

	/**
	 * Returns the bagsList.
	 * @return ArrayList
	 */
	public ArrayList getBagsList()
	{
		return bagsList;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Returns the departureTime.
	 * @return String
	 */
	public String getDepartureTime()
	{
		return departureTime;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber()
	{
		return flightNumber;
	}

	/**
	 * Returns the statusTotalList.
	 * @return ArrayList
	 */
	public ArrayList getStatusTotalList()
	{
		return statusTotalList;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode)
	{
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the bagsList.
	 * @param bagsList The bagsList to set
	 */
	public void setBagsList(ArrayList bagsList)
	{
		this.bagsList = bagsList;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the departureTime.
	 * @param departureTime The departureTime to set
	 */
	public void setDepartureTime(String departureTime)
	{
		this.departureTime = departureTime;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber)
	{
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the statusTotalList.
	 * @param statusTotalList The statusTotalList to set
	 */
	public void setStatusTotalList(ArrayList statusTotalList)
	{
		this.statusTotalList = statusTotalList;
	}

	/**
	 * Returns the airlineCodeValue.
	 * @return String
	 */
	public String getAirlineCodeValue()
	{
		return airlineCodeValue;
	}

	/**
	 * Sets the airlineCodeValue.
	 * @param airlineCodeValue The airlineCodeValue to set
	 */
	public void setAirlineCodeValue(String airlineCodeValue)
	{
		this.airlineCodeValue = airlineCodeValue;
	}

	/**
	 * Returns the bagFound.
	 * @return String
	 */
	public String getBagFound() {
		return bagFound;
	}

	/**
	 * Sets the bagFound.
	 * @param bagFound The bagFound to set
	 */
	public void setBagFound(String bagFound) {
		this.bagFound = bagFound;
	}

}
