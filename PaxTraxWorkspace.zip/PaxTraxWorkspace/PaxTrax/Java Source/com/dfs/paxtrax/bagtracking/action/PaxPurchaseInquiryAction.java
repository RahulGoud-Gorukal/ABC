package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.bagtracking.actionform.PaxPurchaseInquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.PaxPurchaseInquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

/**
*  This is action class which provides the details for a truck number
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 30/06/2004    Sundarrajan.K.	Created
*/

public class PaxPurchaseInquiryAction extends PaxTraxAction
{

	/**
	 * Forwards to PaxPurchaseInquiryPage.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward goToPaxPurchaseInquiryPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::goToPaxPurchaseInquiryPage::Begin");
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		BagStatusBean bagStatusBean = new BagStatusBean();
		PAXBean paxBean = new PAXBean();
		FlightDetailsBean flightDetailsBean = new FlightDetailsBean();
		AddressBean addressBean = new AddressBean();
		paxBean.setDepartureFlightDetails(flightDetailsBean);
		paxBean.setAddress(addressBean);
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
		paxPurchaseInquiryBean.setPaxBean(paxBean);
		paxPurchaseInquiryForm.setBagStatusBean(bagStatusBean);
		paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(paxPurchaseInquiryBean);
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::goToPaxPurchaseInquiryPage::End");
		return mapping.findForward(PaxTraxConstants.PAX_PURCHASE_INQUIRY_PAGE);
	}

	/**
	 * Forwards to PaxPurchaseInquiryPage.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward getPaxPurchaseInquiry(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxPurchaseInquiry::Begin");

		String paxNumber = null;
		String forward = null;
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = null;
		PAXBean paxBean = null;
		try
		{
			String history = request.getParameter("history");
			PaxTraxLog.logDebug("history values is " + history);
			/* if coming form some other pages then history will be equals to Y*/
			if ("Y".equals(history))
			{
				paxNumber = request.getParameter("paxNumber");
				PaxTraxLog.logDebug("Pax number is " + paxNumber);
				paxBean = new PAXBean();
				paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
				paxBean.setPaxNumber(paxNumber);
				paxPurchaseInquiryBean.setPaxBean(paxBean);

			}
			else if (request.getParameter("searchPaxNumber") != null)
			{
				paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();
				paxBean = paxPurchaseInquiryBean.getPaxBean();
				paxNumber = request.getParameter("searchPaxNumber");
				paxBean.setPaxNumber(paxNumber);
				paxPurchaseInquiryBean.setPaxBean(paxBean);

			}
			else if (request.getParameter("paxNumber") != null)
			{
				paxNumber = request.getParameter("paxNumber");
				PaxTraxLog.logDebug("Pax number is " + paxNumber);
				paxBean = new PAXBean();
				paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
				paxBean.setPaxNumber(paxNumber);
				paxPurchaseInquiryBean.setPaxBean(paxBean);
				request.setAttribute(PaxTraxConstants.PRESENT, PaxTraxConstants.FALSE);
			}
			else
			{
				paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();
				paxBean = paxPurchaseInquiryBean.getPaxBean();
				paxNumber = paxBean.getPaxNumber();
				PaxTraxLog.logDebug("Pax number is " + paxNumber);
				paxBean.setPaxNumber(paxNumber);
				paxPurchaseInquiryBean.setPaxBean(paxBean);
			}

			BagTrackingReportsDelegate bagTrackingDelegate = new BagTrackingReportsDelegate();
			paxPurchaseInquiryBean = bagTrackingDelegate.getPaxPurchaseInquiry(paxPurchaseInquiryBean);
			boolean validPax = false;
			if (paxPurchaseInquiryBean.getPurchaseHistory() != null && paxPurchaseInquiryBean.getPurchaseHistory().size() > 0)
			{
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			}
			else
			{
				request.setAttribute(PaxTraxConstants.ERRORCODE, "4702");
			}
			forward = PaxTraxConstants.PAX_PURCHASE_INQUIRY_PAGE;
		}
		catch (BagTrackingReportsException bte)
		{
			paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
			paxBean = new PAXBean();
			FlightDetailsBean flightDetailsBean = new FlightDetailsBean();
			AddressBean addressBean = new AddressBean();
			paxBean.setDepartureFlightDetails(flightDetailsBean);
			paxBean.setAddress(addressBean);
			paxBean.setPaxNumber(paxNumber);
			paxPurchaseInquiryBean.setPaxBean(paxBean);
			paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(paxPurchaseInquiryBean);

			if ((bte.getErrorCode()) == PaxTraxConstants.PAX_NOT_FOUND)
			{
				request.setAttribute(PaxTraxConstants.ERRORCODE, "4701");
			}
			else
			{
				request.setAttribute(PaxTraxConstants.ERRORCODE, "4702");
			}
			forward = PaxTraxConstants.PAX_PURCHASE_INQUIRY_PAGE;
		}
		catch (Exception pe)
		{
			PaxTraxLog.logError("PaxTrax::PaxPurchaseInquiryAction::getPaxPurchaseInquiry::PaxTraxSystemException " + pe.toString());

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(paxPurchaseInquiryBean);

		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxPurchaseInquiry::End");
		return mapping.findForward(forward);
	}

	public ActionForward printPaxPurchaseEnquiry(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		return mapping.findForward(PaxTraxConstants.PAX_PURCHASE_PRINT_PAGE);
	}
	public ActionForward paxDutyFreePurchaseReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::paxDutyFreePurchaseReport::Begin");
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PAXBean paxBean = new PAXBean();
		FlightDetailsBean flightDetailsBean = new FlightDetailsBean();
		AddressBean addressBean = new AddressBean();
		paxBean.setDepartureFlightDetails(flightDetailsBean);
		paxBean.setAddress(addressBean);
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
		paxPurchaseInquiryBean.setPaxBean(paxBean);
		paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(paxPurchaseInquiryBean);
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::paxDutyFreePurchaseReport::End");
		return mapping.findForward("paxDFPurchaseApprove");
	}
	public ActionForward getPaxDFPurchaseList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxDFPurchaseList::Begin");
		String forward = null;
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		String paxNumber = request.getParameter("paxnumber");
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = null;
		if (paxNumber != null)
		{
			paxNumber = paxNumber.trim();
			paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
			PAXBean paxBean = new PAXBean();
			paxBean.setPaxNumber(paxNumber);
			paxPurchaseInquiryBean.setPaxBean(paxBean);
			request.setAttribute("backbutton", "true");
		}
		else
		{
			paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();
		}

		BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		try
		{
			resultBean = bagTrackingReportsDelegate.getPaxDFPurchaseList(paxPurchaseInquiryBean);
			if (resultBean != null)
			{
				ArrayList departmentList = resultBean.getDepartmentList();
				if (departmentList == null || (departmentList.size() == 0))
					throw new BagTrackingReportsException(905);
			}
			paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(resultBean);
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			forward = "paxDFPurchaseApprove";
		}
		catch (BagTrackingReportsException bagTrackingReportsException)
		{

			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + bagTrackingReportsException.getErrorCode());
			forward = "paxDFPurchaseApprove";
		}
		catch (PaxTraxSystemException paxTraxSystemException)
		{
			PaxTraxLog.logError("PaxTrax::PaxPurchaseInquiryAction::getPaxDFPurchaseList" + paxTraxSystemException);
			throw new PaxTraxSystemException(paxTraxSystemException);

		}
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxDFPurchaseList::End");
		return mapping.findForward(forward);
	}

	public ActionForward approvePax(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::approvePax::Begin");
		String forward = null;
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();

		BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		try
		{
			resultBean = bagTrackingReportsDelegate.approvePax(paxPurchaseInquiryBean);
			paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(resultBean);
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			forward = "paxDFPurchaseApprove";
		}
		catch (BagTrackingReportsException bagTrackingReportsException)
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + bagTrackingReportsException.getErrorCode());
			forward = "paxDFPurchaseApprove";
		}
		catch (PaxTraxSystemException paxTraxSystemException)
		{
			PaxTraxLog.logError("PaxTrax::PaxPurchaseInquiryAction::approvePax" + paxTraxSystemException);
			throw new PaxTraxSystemException(paxTraxSystemException);

		}
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::approvePax::End");
		return mapping.findForward(forward);
	}
	public ActionForward rejectPax(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::rejectPax::Begin");
		String forward = null;
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();

		BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		try
		{
			resultBean = bagTrackingReportsDelegate.rejectPax(paxPurchaseInquiryBean);
			paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(resultBean);
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			forward = "paxDFPurchaseApprove";
		}
		catch (BagTrackingReportsException bagTrackingReportsException)
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + bagTrackingReportsException.getErrorCode());
			forward = "paxDFPurchaseApprove";
		}
		catch (PaxTraxSystemException paxTraxSystemException)
		{
			PaxTraxLog.logError("PaxTrax::PaxPurchaseInquiryAction::rejectPax" + paxTraxSystemException);
			throw new PaxTraxSystemException(paxTraxSystemException);

		}
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::rejectPax::End");
		return mapping.findForward(forward);
	}

	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{

		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::changeLanguage::Begin");

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.CHANGE_LANGUAGE_COUNTRY);
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
			page = page.trim();

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);

		/*  String presentValue =(String)request.getAttribute(PaxTraxConstants.PRESENT);
			if(presentValue !=null)*/

		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(PaxTraxConstants.SKU_ERROR, new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);

		}
		String forward = "paxDFPurchaseApprove";

		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::changeLanguage::End");
		return mapping.findForward(forward);

	}
	public ActionForward parallelingReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::parallelingReport::Begin");
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PAXBean paxBean = new PAXBean();
		FlightDetailsBean flightDetailsBean = new FlightDetailsBean();
		AddressBean addressBean = new AddressBean();
		paxBean.setDepartureFlightDetails(flightDetailsBean);
		paxBean.setAddress(addressBean);
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
		paxPurchaseInquiryBean.setPaxBean(paxBean);
		paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(paxPurchaseInquiryBean);
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::parallelingReport::End");
		return mapping.findForward("parallelingReport");
	}

	public ActionForward getPaxDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxDetails::Begin");
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();

		BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		String forward = null;
		try
		{
			resultBean = bagTrackingReportsDelegate.getPaxDetails(paxPurchaseInquiryBean);
			if (resultBean != null)
			{
				ArrayList purchaseList = resultBean.getPurchaseHistory();
				if (purchaseList == null || (purchaseList.size() == 0))
					throw new BagTrackingReportsException(905);
			}
			paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(resultBean);
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			forward = "parallelingReport";
		}
		catch (BagTrackingReportsException bagTrackingReportsException)
		{
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + bagTrackingReportsException.getErrorCode());
			forward = "parallelingReport";
		}
		catch (PaxTraxSystemException paxTraxSystemException)
		{
			PaxTraxLog.logError("PaxTrax::PaxPurchaseInquiryAction::getPaxDetails" + paxTraxSystemException);
			throw new PaxTraxSystemException(paxTraxSystemException);

		}
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxDetails::End");
		return mapping.findForward("parallelingReport");
	}
	public ActionForward paxDutyPaidPurchaseReport(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::paxDutyPaidPurchaseReport::Begin");
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		PAXBean paxBean = new PAXBean();
		//FlightDetailsBean flightDetailsBean = new FlightDetailsBean();
		AddressBean addressBean = new AddressBean();
		//paxBean.setDepartureFlightDetails(flightDetailsBean);
		paxBean.setAddress(addressBean);
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
		paxPurchaseInquiryBean.setPaxBean(paxBean);
		paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(paxPurchaseInquiryBean);
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::paxDutyPaidPurchaseReport::End");
		return mapping.findForward("paxDPPurchaseApprove");
	}
	public ActionForward getPaxDPPurchaseList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxDPPurchaseList::Begin");
		String forward = null;
		PaxPurchaseInquiryForm paxPurchaseInquiryForm = (PaxPurchaseInquiryForm) form;
		String paxNumber = request.getParameter("paxnumber");
		PaxPurchaseInquiryBean paxPurchaseInquiryBean = null;
		if (paxNumber != null)
		{
			paxNumber = paxNumber.trim();
			paxPurchaseInquiryBean = new PaxPurchaseInquiryBean();
			PAXBean paxBean = new PAXBean();
			paxBean.setPaxNumber(paxNumber);
			paxPurchaseInquiryBean.setPaxBean(paxBean);
			request.setAttribute("backbutton", "true");
		}
		else
		{
			paxPurchaseInquiryBean = paxPurchaseInquiryForm.getPaxPurchaseInquiryBean();
		}

		BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		try
		{
			resultBean = bagTrackingReportsDelegate.getPaxDPPurchaseList(paxPurchaseInquiryBean);
			if (resultBean != null)
			{
				ArrayList departmentList = resultBean.getDepartmentList();
				if (departmentList == null || (departmentList.size() == 0))
					throw new BagTrackingReportsException(905);
			}
			paxPurchaseInquiryForm.setPaxPurchaseInquiryBean(resultBean);
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
			forward = "paxDPPurchaseApprove";
		}
		catch (BagTrackingReportsException bagTrackingReportsException)
		{

			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + bagTrackingReportsException.getErrorCode());
			forward = "paxDPPurchaseApprove";
		}
		catch (PaxTraxSystemException paxTraxSystemException)
		{
			PaxTraxLog.logError("PaxTrax::PaxPurchaseInquiryAction::getPaxDPPurchaseList" + paxTraxSystemException);
			throw new PaxTraxSystemException(paxTraxSystemException);

		}
		PaxTraxLog.logDebug("PaxTrax::PaxPurchaseInquiryAction::getPaxDPPurchaseList::End");
		return mapping.findForward(forward);
	}

}
