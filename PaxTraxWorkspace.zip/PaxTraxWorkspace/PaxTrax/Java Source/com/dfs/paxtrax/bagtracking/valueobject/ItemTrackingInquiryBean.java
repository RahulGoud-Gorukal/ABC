

package com.dfs.paxtrax.bagtracking.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

public class ItemTrackingInquiryBean extends PaxTraxValueObject {
    private String itemNumber = null;
    private ArrayList itemHistory = null;
    
    
	/**
	 * Returns the itemHistory.
	 * @return ArrayList
	 */
	public ArrayList getItemHistory()
	{
		return itemHistory;
	}

	/**
	 * Returns the itemNumber.
	 * @return String
	 */
	public String getItemNumber()
	{
		return itemNumber;
	}

	/**
	 * Sets the itemHistory.
	 * @param itemHistory The itemHistory to set
	 */
	public void setItemHistory(ArrayList itemHistory)
	{
		this.itemHistory = itemHistory;
	}

	/**
	 * Sets the itemNumber.
	 * @param itemNumber The itemNumber to set
	 */
	public void setItemNumber(String itemNumber)
	{
		this.itemNumber = itemNumber;
	}

}
