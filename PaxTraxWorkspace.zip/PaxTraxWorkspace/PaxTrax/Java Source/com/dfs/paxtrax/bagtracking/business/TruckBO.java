package com.dfs.paxtrax.bagtracking.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.bagtracking.exception.TruckException;
import com.dfs.paxtrax.bagtracking.valueobject.TruckBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;


/**
 * The remote interface of the TruckBOBean
 * 
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 01/06/2004	Yuvarani    	Created   
 */

public interface TruckBO extends EJBObject{
    
    /**
     * This method is used to insert a Truck record into the database
	 * @param truckBean TruckBean
	 * @throws PaxTraxSystemException if there is any problem in saving
	 * @throws RemoteException
     */
    public void saveTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException,RemoteException,TruckException;
    
	/**
	 * Gets TruckDetails.
	 * @param truckBean TruckBean
	 * @return TruckBean
	 * @throws PaxTraxSystemException if there is any problem in 
	 * getting the details
	 * @throws RemoteException
	 * @throws TruckException if the truck does not exist
	 */
    public TruckBean getTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException,RemoteException,TruckException;
    	
	/**
	 * Updates truck details in the database
	 * @param truckBean TruckBean
	 * @throws PaxTraxSystemException if there is any problem in updation
	 * @throws RemoteException
	 */
    public void updateTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException,RemoteException;
    
	/**
	 * Removes TruckDetails from the database.
	 * @param truckBean TruckBean
	 * @throws PaxTraxSystemException if there is any problem in deletion
	 * @throws RemoteException
	 */
    public void removeTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException,RemoteException,TruckException;
    
	/**
	 * This method searches for truck that satisfies the given criteria
	 * @param truckBean TruckBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException if there is any problem while searching
	 * @throws RemoteException
	 */
    public ArrayList searchTruckDetails(TruckBean truckBean) 
    	throws PaxTraxSystemException,RemoteException;
}
