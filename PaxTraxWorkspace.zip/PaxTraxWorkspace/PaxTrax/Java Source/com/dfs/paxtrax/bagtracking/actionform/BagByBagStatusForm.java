package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.BagByBagStatusBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Bag By Bag Status attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Jaganmohan Gopinath
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 05/30/2007   	 Uma     Created   
*/

public class BagByBagStatusForm extends PaxTraxActionForm{
	
	public BagByBagStatusForm(){
		
	}
	
	private ArrayList bagStatusList = null;
	
	private BagByBagStatusBean bagByBagStatusBean = null;

	/**
	 * @return
	 */
	public BagByBagStatusBean getBagByBagStatusBean() {
		return bagByBagStatusBean;
	}

	/**
	 * @return
	 */
	public ArrayList getBagStatusList() {
		return bagStatusList;
	}

	/**
	 * @param bean
	 */
	public void setBagByBagStatusBean(BagByBagStatusBean bean) {
		bagByBagStatusBean = bean;
	}

	/**
	 * @param list
	 */
	public void setBagStatusList(ArrayList list) {
		bagStatusList = list;
	}

}
