package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.bagtracking.actionform.CageForm;
import com.dfs.paxtrax.bagtracking.exception.CageException;
import com.dfs.paxtrax.bagtracking.service.CageDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.CageBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
* This action class is used for inserting and updating cage records
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 18/05/2004    Joseph Oommen A Created
*/
public class CageAction extends PaxTraxAction
{

	String forward = null;

	/**
	* Saves the Cage Details in the database
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward saveCageDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::CageAction::saveCageDetails::Begin");
		CageForm cageForm = (CageForm) form;
		CageBean cageBean = cageForm.getCageBean();
		HttpSession session = request.getSession();
		cageBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		CageDelegate cageDelegate = new CageDelegate();
		try
		{
			cageDelegate.saveCageDetails(cageBean);
			forward = PaxTraxConstants.VIEW_CREATE_CAGE;
		}
		catch (CageException cageException)
		{
			PaxTraxLog.logError(
				"CageException caught saveCageDetails-CageAction",
				cageException);
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.LOCATION_ERROR,
				new ActionMessage("" + cageException.getErrorCode()));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + cageException.getErrorCode());
			forward = PaxTraxConstants.CREATE_CAGE_PAGE;
		}
		PaxTraxLog.logDebug("PaxTrax::CageAction::saveCageDetails::End");
		return mapping.findForward(forward);
	}

	/**
	* Forwards to create cage page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward createCagePage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::createCagePage::Begin");
		CageForm cageForm = (CageForm) form;
		CageBean cageBean = new CageBean();
		cageForm.setCageBean(cageBean);
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,
                                                PaxTraxConstants.BAG_TRACKING);
		forward = PaxTraxConstants.CREATE_CAGE_PAGE;
		PaxTraxLog.logDebug("PaxTrax::CageAction::createCagePage::End");
		return mapping.findForward(forward);
	}

	/**
	* Forwards to Maintain Cage page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to Maintain Cage Page
	*/
	public ActionForward maintainCagePage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::maintainCagePage::Begin");
		CageForm cageForm = (CageForm) form;
		CageBean cageBean = new CageBean();
		cageForm.setCageBean(cageBean);
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,
                                                PaxTraxConstants.BAG_TRACKING);
		forward = PaxTraxConstants.MAINTAIN_CAGE_PAGE;
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.UPDATE);
		PaxTraxLog.logDebug("PaxTrax::CageAction::maintainCagePage::End");
		return mapping.findForward(forward);
	}


	/**
		* updates the Cage Details
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while updating the cage
	*/
	public ActionForward updateCageDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::updateCageDetails::Begin");
		CageForm cageForm = (CageForm) form;
		CageBean cageBean = cageForm.getCageBean();
		HttpSession session = request.getSession();
		cageBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		CageDelegate cageDelegate = new CageDelegate();
		try
		{
			cageDelegate.updateCageDetails(cageBean);
			forward = PaxTraxConstants.VIEW_MAINTAINE_CAGE;
			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.UPDATE);
		}
		catch (CageException cageException)
		{
			PaxTraxLog.logError(
				"CageException caught updateCageDetails-CageAction",
				cageException);
		}
		PaxTraxLog.logDebug("PaxTrax::CageAction::updateCageDetails::End");
		return mapping.findForward(forward);
	}



	/**
		* removes the Cage Details
	 	* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while removing the cage
	*/
	public ActionForward removeCageDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::removeCageDetails::Begin");
		CageForm cageForm = (CageForm) form;
		CageBean cageBean = cageForm.getCageBean();

		try
		{
			HttpSession session = request.getSession();
			cageBean.setUser(
				(String) session.getAttribute(PaxTraxConstants.USER_ID));
			CageDelegate cageDelegate = new CageDelegate();
			cageDelegate.removeCageDetails(cageBean);
			String operation =
				(String) request.getParameter(PaxTraxConstants.OPERATION);
			if ((PaxTraxConstants.UPDATE_SEARCH).equals(operation))
			{

				int size = 0;
				ArrayList cageCollection =
					(ArrayList) session.getAttribute(PaxTraxConstants.ALL_CAGE_RECORDS);
				if (cageCollection != null)
					size = cageCollection.size();
				else
					size = 0;
				int i;

				for (i = 0; i < size; i++)
				{
					CageBean cageBeanTemp = (CageBean) cageCollection.get(i);
					if ((cageBeanTemp.getCageNumber())
						.equals(cageBean.getCageNumber()))
					{
						cageCollection.remove(i);
						session.removeAttribute(PaxTraxConstants.ALL_CAGE_RECORDS);
						session.setAttribute(PaxTraxConstants.ALL_CAGE_RECORDS, cageCollection);
						break;
					}
				}
				/*
				* Adjusting the Page number
				*/

				if (size == 1)
				{
					/*
					 * if there was only one record and
					 * that got deleted then page number attribute
					 * should be removed from the session
					 */
					session.removeAttribute(PaxTraxConstants.CAGE_PAGE_NUMBER);
				}

				else
					if ((size % 10) == 1 && (i == (size - 1)))
					{
						String cagePageNumber =
							(String) session.getAttribute(PaxTraxConstants.CAGE_PAGE_NUMBER);

						int page = Integer.parseInt(cagePageNumber);

						page = page - 1;

						String updatedPageNumber = "" + page;
						session.setAttribute(
							PaxTraxConstants.CAGE_PAGE_NUMBER,
							updatedPageNumber);

					}
			}
			cageForm.setCageBean(cageBean);
			forward = PaxTraxConstants.VIEW_MAINTAINE_CAGE;
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.DELETE);
		}
		catch (CageException cageException)
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.LOCATION_ERROR,
				new ActionMessage("" + cageException.getErrorCode()));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(
				PaxTraxConstants.ERRORCODE,
				"" + cageException.getErrorCode());
			forward = PaxTraxConstants.MAINTAIN_CAGE_PAGE;
			request.setAttribute(
				PaxTraxConstants.OPERATION,
				PaxTraxConstants.UPDATE);
		}
		PaxTraxLog.logDebug("PaxTrax::CageAction::removeCageDetails::End");
		return mapping.findForward(forward);
	}

	/**
		* cancel the Cage Details action
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while canceling the previous action
	*/
	public ActionForward cancel(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::cancel::Begin");
		forward =PaxTraxConstants.BAGTRACKING_HOME;
		PaxTraxLog.logDebug("PaxTrax::CageAction::cancel::Begin");
		return mapping.findForward(forward);
	}


	/**
		* loads the Cage Details
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while loading the details
	*/
	public ActionForward loadCageDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::loadCageDetails::Begin");
		CageForm cageForm = (CageForm) form;
		CageBean cageBean = cageForm.getCageBean();
		CageDelegate cageDelegate = new CageDelegate();
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null && operation.equals(PaxTraxConstants.SEARCH))
		{
			String index = request.getParameter(PaxTraxConstants.INDEX);
			HttpSession session = request.getSession();
			ArrayList allCageRecords =
				(ArrayList) session.getAttribute(PaxTraxConstants.ALL_CAGE_RECORDS);
			if (index != null)
			{
				CageBean resultBean =
					(CageBean) allCageRecords.get(
						(Integer.parseInt(index)) - 1);
				cageForm.setCageBean(resultBean);
				forward = PaxTraxConstants.MAINTAIN_CAGE_PAGE;
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.UPDATE_SEARCH);
			}
		}
		else
		{
			try
			{
				CageBean resultBean = cageDelegate.loadCageDetails(cageBean);
				forward = PaxTraxConstants.MAINTAIN_CAGE_PAGE;
				cageForm.setCageBean(resultBean);
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.UPDATE_RELOAD);
			}
			catch (CageException cageException)
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.LOCATION_ERROR,
					new ActionMessage("" + cageException.getErrorCode()));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.ERRORCODE,
					"" + cageException.getErrorCode());
				forward = PaxTraxConstants.MAINTAIN_CAGE_PAGE;
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.UPDATE);

			}
		}
		PaxTraxLog.logDebug("PaxTrax::CageAction::loadCageDetails::End");
		return mapping.findForward(forward);
	}

	/**
		* change the language
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while changing the language
	*/

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::CageAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);

		String country = request.getParameter(PaxTraxConstants.COUNTRY);

		super.changeLanguage(request, language, country);

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.SKU_ERROR,
				new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
		}
		String page = request.getParameter(PaxTraxConstants.PAGE);

		if ((PaxTraxConstants.CREATE).equals(page))
		{
			forward = PaxTraxConstants.CREATE_CAGE_PAGE;
		}
		else
			if ((PaxTraxConstants.MAINTAIN).equals(page))
			{
				forward = PaxTraxConstants.MAINTAIN_CAGE_PAGE;
			}
			else
				if ((PaxTraxConstants.VIEW_CREATE_CAGE).equals(page))
				{
					forward = PaxTraxConstants.VIEW_CREATE_CAGE;
				}
				else
					if ((PaxTraxConstants.VIEW_MAINTAINE_CAGE).equals(page))
					{
						forward = PaxTraxConstants.VIEW_MAINTAINE_CAGE;
					}
		PaxTraxLog.logDebug("PaxTrax::CageAction::changeLanguage::End");
		return mapping.findForward(forward);
	}

}
