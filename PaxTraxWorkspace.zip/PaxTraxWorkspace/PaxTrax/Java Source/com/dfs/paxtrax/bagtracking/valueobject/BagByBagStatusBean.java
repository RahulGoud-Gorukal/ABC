package com.dfs.paxtrax.bagtracking.valueobject;


/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
* This is valueobject class which contains bag by bag status attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Jaganmohan Gopinath
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 05/30/2007    Uma     Created   
*/

public class BagByBagStatusBean extends PaxTraxValueObject
{
	public BagByBagStatusBean()
	{
	}
	
	private String bagFound;
	
	private String bagCode = null;

	private String bagCodeValue = null;
	
	private String departureDate = null;
	
	private ArrayList bagsList = null;
	
	private String totalBags = null;
	

	/**
	 * @return
	 */
	public String getBagCode() {
		return bagCode;
	}

	/**
	 * @return
	 */
	public String getBagCodeValue() {
		return bagCodeValue;
	}

	/**
	 * @return
	 */
	public String getBagFound() {
		return bagFound;
	}

	/**
	 * @return
	 */
	public ArrayList getBagsList() {
		return bagsList;
	}

	/**
	 * @return
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * @return
	 */
	public String getTotalBags() {
		return totalBags;
	}

	/**
	 * @param string
	 */
	public void setBagCode(String string) {
		bagCode = string;
	}

	/**
	 * @param string
	 */
	public void setBagCodeValue(String string) {
		bagCodeValue = string;
	}

	/**
	 * @param string
	 */
	public void setBagFound(String string) {
		bagFound = string;
	}

	/**
	 * @param list
	 */
	public void setBagsList(ArrayList list) {
		bagsList = list;
	}

	/**
	 * @param string
	 */
	public void setDepartureDate(String string) {
		departureDate = string;
	}

	/**
	 * @param string
	 */
	public void setTotalBags(String string) {
		totalBags = string;
	}

}
