package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.TruckTrackingEnquiryForm;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.TruckStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.TruckTrackingInquiryBean;
import com
	.dfs
	.paxtrax
	.bagtracking
	.valueobject
	.TruckTrackingInquiryCageDetailsBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for a truck number
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 30/06/2004    Sundarrajan.K.	Created
*/

public class TruckTrackingEnquiryAction extends PaxTraxAction
{

	/**
	 * Forwards to TruckTrackingEnquiryPage.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward goToTruckTrackingEnquiryPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		ArrayList truckList = null;
		ArrayList pickList = null;
		String forward = null;
		PaxTraxLog.logDebug(
			"PaxTrax::TruckTrackingEnquiryAction::goToTruckTrackingEnquiryPage::Begin");
		int size = 0;
		TruckTrackingEnquiryForm truckTrackingForm =
			(TruckTrackingEnquiryForm) form;
		TruckTrackingInquiryCageDetailsBean truckTrackingInquiryCageDetailsBean =
			null;
		TruckStatusBean truckStatusBean = new TruckStatusBean();
		TruckTrackingInquiryBean truckTrackingInquiryBean =
			new TruckTrackingInquiryBean();
		//ArrayList pickupAdd = new ArrayList();
		try
		{
			/* 	ReferenceDataDelegate referrenceData = new ReferenceDataDelegate();
				ArrayList pickup = referrenceData.loadReferenceData(
													PaxTraxConstants.PICK_UP_LOCATION);
				if (pickup != null)
				{
					size = pickup.size();
				}
				for (int i = 0;i < size;i++)
				{
					truckTrackingInquiryCageDetailsBean = new TruckTrackingInquiryCageDetailsBean();
					truckTrackingInquiryCageDetailsBean.setPickupLocation(((ReferenceDataBean)pickup.get(i))
																	.getCodeValue());
					truckTrackingInquiryCageDetailsBean.setTotalNoOfCages(0);
					pickupAdd.add(truckTrackingInquiryCageDetailsBean);
				}
				truckTrackingInquiryBean.setTotalNoOfCagesPerPickupLocation(pickupAdd);
				truckTrackingForm.setPickList(pickupAdd);*/

			BagTrackingReportsDelegate truckTrackingDelegate =
				new BagTrackingReportsDelegate();
			truckList = truckTrackingDelegate.getTruckList();
			forward = PaxTraxConstants.TRUCK_TRACKING_ENQUIRY_PAGE;
		}
		catch (PaxTraxSystemException pe)
		{
			PaxTraxLog.logError(
				"PaxTrax::TruckTrackingEnquiryAction::goToTruckTrackingEnquiryPage::PaxTraxSystemException",
				pe);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		truckTrackingForm.setTruckList(truckList);
		truckTrackingForm.setTruckStatusBean(truckStatusBean);
		truckTrackingForm.setTruckTrackingInquiryBean(truckTrackingInquiryBean);
		truckTrackingForm.setTruckTrackingInquiryCageDetailsBean(
			truckTrackingInquiryCageDetailsBean);
		PaxTraxLog.logDebug(
			"PaxTrax::TruckTrackingEnquiryAction::goToTruckTrackingEnquiryPage::End");
		return mapping.findForward(forward);
	}

	/**
	 * Gets the report for a truck
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in retrieving the
	 * report
	 */
	public ActionForward getTruckTrackingEnquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::TruckTrackingEnquiryAction::getTruckTrackingEnquiry::Begin");
		
		TruckTrackingEnquiryForm truckTrackingForm =
			(TruckTrackingEnquiryForm) form;
		
		String truckNumber = null;
		String tripNumber = null;
		String forward = null;
		TruckTrackingInquiryBean truckTrackingInquiryBean = null;
		if (request.getParameter("truckNumber") == null)
		{
			truckTrackingInquiryBean =
				truckTrackingForm.getTruckTrackingInquiryBean();
			truckNumber = truckTrackingInquiryBean.getTruckNumber();
			truckTrackingInquiryBean.setTruckNumber(truckNumber);
			truckTrackingInquiryBean.setTripNumber("-1");
		}
		else
		{
			truckNumber = request.getParameter("truckNumber");
			tripNumber = request.getParameter("tripNumber");
			truckTrackingInquiryBean = new TruckTrackingInquiryBean();
			truckTrackingInquiryBean.setTruckNumber(truckNumber);
			truckTrackingInquiryBean.setTripNumber(tripNumber);
			request.setAttribute(
				PaxTraxConstants.PRESENT,
				PaxTraxConstants.FALSE);
		}
		try
		{
			BagTrackingReportsDelegate truckTrackingDelegate =
				new BagTrackingReportsDelegate();
			
			truckTrackingInquiryBean =
				truckTrackingDelegate.getTruckTrackingEnquiry(
					truckTrackingInquiryBean);
			forward = PaxTraxConstants.TRUCK_TRACKING_ENQUIRY_PAGE;
		}
		catch (PaxTraxSystemException pe)
		{
			PaxTraxLog.logError(
				"PaxTrax::TruckTrackingEnquiryAction::getTruckTrackingEnquiry::PaxTraxSystemException",
				pe);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		truckTrackingForm.setTruckTrackingInquiryBean(truckTrackingInquiryBean);
		request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		PaxTraxLog.logDebug(
			"PaxTrax::TruckTrackingEnquiryAction::getTruckTrackingEnquiry::End");
		return mapping.findForward(forward);
	}

	public ActionForward printTruckTrackingEnquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		return mapping.findForward(PaxTraxConstants.TRUCK_TRACKING_PRINT_PAGE);
	}

}
