package com.dfs.paxtrax.bagtracking.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.BagTrackingReportsForm;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.ItemDetailsBean;
/*Modified on 28th June 2006 - Starts
 *SR 1042 International DF Sale */
import com.dfs.paxtrax.bagtracking.valueobject.SKUSummaryReportBean;
/*Modified on 28th June 2006 - Ends
 *SR 1042 International DF Sale */
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class BagTrackingReportsAction extends PaxTraxAction
{
	/**
	 * Method bagTrackingReportsMainPage.
	 * 
	 * @param ActionMapping mapping
	 * @param ActionForm form
	 * @param HttpServletRequest request
	 * @param HttpServletResponse response
	 * @return ActionForward
	 * 
	 * Function to go to the Bag Tracking Reports Index page
	 */
	public ActionForward bagTrackingReportsMainPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::bagTrackingReportsMainPage");
			
			/*
			HttpSession session = request.getSession();
			String userId = (String)session.getAttribute("userId");
			
			BagTrackingReportsDelegate delegate = new BagTrackingReportsDelegate();
			ArrayList listOfReports = delegate.getReportsAssignedToUser(userId);
			BagTrackingReportsForm btform = (BagTrackingReportsForm)form;
			btform.setListOfReports(listOfReports);
			*/
			
		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME, PaxTraxConstants.BAG_TRACKING);

		return(mapping.findForward(PaxTraxConstants.BT_REPORTS_MAIN_PAGE));
	}
	
	/**
	 * Method changeLanguage.
	 * 
	 * @param ActionMapping mapping
	 * @param ActionForm form
	 * @param HttpServletRequest request
	 * @param HttpServletResponse response
	 * @return ActionForward
	 * 
	 * Function to perform the language toggle from Engligh - Japanese and vice-versa.
	 */
	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::changeLanguage::Begin");
		
		String forwardPage = null;
		
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String page = request.getParameter("page");
		
		if(language!=null && country!=null && page!=null)		
			super.changeLanguage(request, language, country);
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;
		
		if(page.equals("btReportsMainPage"))
			forwardPage = PaxTraxConstants.BT_REPORTS_MAIN_PAGE;
			
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::changeLanguage::End");
		
		return(mapping.findForward(forwardPage));
	}

	public ActionForward skuTransferDisplayPage(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::skuTransferDisplayPage:start");
		BagTrackingReportsForm bagTrackingReportsForm = (BagTrackingReportsForm) form;
		bagTrackingReportsForm.setListOfReports(null);
		bagTrackingReportsForm.setSkuTransferDate(null);
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::skuTransferDisplayPage:end");
		return(mapping.findForward("skuTransferDisplayPage"));
	}
	

	/**
	 * Returns the sku transfer details
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getSkuTransferDetails(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) {
		try {
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsAction::getSkuTransferDetails:start");
			BagTrackingReportsForm bagTrackingReportsForm = 
											(BagTrackingReportsForm) form;
			if (bagTrackingReportsForm.getSkuTransferDate() != null && 
				bagTrackingReportsForm.getSkuTransferDate().length() > 0) {
				
				BagTrackingReportsDelegate bagTrackingRptDelegate = 
													new BagTrackingReportsDelegate();
			
					/*Modified on 28th June 2006 - Starts
					 *SR 1042 International DF Sale */
			
			HttpSession session  = request.getSession();
			session.setAttribute("intl",bagTrackingReportsForm.getIsInternational()+"");
			SKUSummaryReportBean summaryReportBean = new SKUSummaryReportBean();
			summaryReportBean.setFromDateTime(bagTrackingReportsForm.getSkuTransferDate() +" 00:00:00");
			summaryReportBean.setToDateTime(bagTrackingReportsForm.getSkuTransferDate() +" 23:59:59");
			if(bagTrackingReportsForm.getIsInternational())
					summaryReportBean.setInternationalFlag("Y");
			else
					summaryReportBean.setInternationalFlag("N");
			
			ArrayList skuTransferList = bagTrackingRptDelegate.getSkuTransferReport(
			summaryReportBean);
			/*Modified on 28th June 2006 - Ends
			 *SR 1042 International DF Sale */
												
				skuTransferList = calculateQuantityPerTrip(skuTransferList);
				bagTrackingReportsForm.setListOfReports(skuTransferList);

				if (skuTransferList.size() > 0) {
					request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				} else {
					request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.FAILURE);
				}
			}
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsAction::getSkuTransferDetails:end");
		} catch(PaxTraxSystemException pse) {
    		PaxTraxLog.logError("Exception in PaxTrax::BagTrackingEnquiryAction::getSkuTransferDetails"+pse);
    		return(mapping.findForward(PaxTraxConstants.REPORT_ERROR));
    	}
		return(mapping.findForward("skuTransferDisplayPage"));
	}

	/**
	 * Generates sku Transfer Report in excel format
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward generateSkuTransferReport(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::"
								+"generateSkuTransferReport:start");
		String columnArray[]=
			{"Trip Number","Truck Number","Truck Time","SKU","SKU Price","Quantity"};
		String forward = "";
		try {
			BagTrackingReportsForm bagTrackingReportsForm = (BagTrackingReportsForm) form;
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");
			ArrayList skuBagsList = bagTrackingReportsForm.getListOfReports();
			/*Modified on 28th June 2006 - Starts
			 *SR 1042 International DF Sale */
			bagTrackingReportsForm.setIsInternational(new Boolean(""+session.getAttribute("intl")).booleanValue());
			//session.removeAttribute("intl");
			/*Modified on 28th June 2006 - Ends
			 *SR 1042 International DF Sale */
			
			int size = 0;
			if (skuBagsList != null) {
				size = skuBagsList.size();
				
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("SKU Transfer Report");
				sheet.setDefaultColumnWidth((short)16);
				//Create Header Font
				HSSFFont fontHeader = wb.createFont();
				fontHeader.setFontHeightInPoints((short)10);
				fontHeader.setFontName(HSSFFont.FONT_ARIAL);
				fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
								
				//Create font for the workbook Data cells
				HSSFFont font = wb.createFont();
				font.setFontHeightInPoints((short)10);
				font.setFontName(HSSFFont.FONT_ARIAL);
				
				//Style for the Header cells
				HSSFCellStyle styleHeader = wb.createCellStyle();
				styleHeader.setFont(fontHeader);
				styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
				styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				
				//Style for the Side Title cells
				HSSFCellStyle styleTitle = wb.createCellStyle();
				styleTitle.setFont(fontHeader);

				//Style for the Data cells
				HSSFCellStyle style = wb.createCellStyle();
				style.setFont(font);
				
				//Style for numeric data cells
				HSSFCellStyle styleNum = wb.createCellStyle();
				HSSFDataFormat format = wb.createDataFormat();
				styleNum.setDataFormat(format.getFormat("#,##0.00"));
				styleNum.setFont(font);

				/* integer style */
				HSSFCellStyle styleInt = wb.createCellStyle();
				HSSFDataFormat format2 = wb.createDataFormat();
				styleInt.setDataFormat(format2.getFormat("#,###"));
				styleInt.setFont(font);

				/* sku style */
				HSSFCellStyle skuStyle = wb.createCellStyle();
				HSSFDataFormat format3 = wb.createDataFormat();
				skuStyle.setDataFormat(format2.getFormat("####"));
				skuStyle.setFont(font);
				
				//Create Title rows
				HSSFRow row = sheet.createRow((short)0);
				HSSFCell cell = null;
				sheet.addMergedRegion(new Region(0, (short)0, 0, (short)5));
				createCell(row,
							cell,
							0, 
							true, 
							HSSFCellStyle.ALIGN_CENTER, 
							HSSFCell.CELL_TYPE_STRING, 
							styleHeader, 
							PaxTraxConstants.DFS_OKINAWA, 0.0);
							
				row = sheet.createRow((short)1);
				createCell(row,
							cell,
							0, 
							true, 
							HSSFCellStyle.ALIGN_CENTER, 
							HSSFCell.CELL_TYPE_STRING, 
							styleHeader, 
							PaxTraxConstants.SKU_TRANSFER_REPORT, 
							0.0);

				sheet.addMergedRegion(new Region(1, (short)0, 1, (short)5));	
				cell = row.getCell((short)0);
				cell.setCellStyle(styleHeader);

				row = sheet.createRow((short)3);
				sheet.addMergedRegion(new Region(3, (short)0, 3, (short)1));
				createCell(row,
							cell,
							0, 
							true, 
							HSSFCellStyle.ALIGN_LEFT, 
							HSSFCell.CELL_TYPE_STRING, 
							styleTitle, 
							"Date :"+bagTrackingReportsForm.getSkuTransferDate(), 
							0.0);
				/*Modified on 28th June 2006 - Starts
				 *SR 1042 International DF Sale */

				String travelType = PaxTraxConstants.DOMESTIC;
				if(bagTrackingReportsForm.getIsInternational())
					travelType = PaxTraxConstants.INTERNATIONAL;
				createCell(row,
								cell,
								4, 
								true, 
								HSSFCellStyle.ALIGN_LEFT, 
								HSSFCell.CELL_TYPE_STRING, 
								styleTitle, 
								travelType, 
								0.0);			
				/*Modified on 28th June 2006 - End
				 *SR 1042 International DF Sale */

				row = sheet.createRow((short)5);
				sheet.addMergedRegion(new Region(5, (short)2,5, (short)4));				
				sheet.addMergedRegion(new Region(5, (short)5,5, (short)7));				

				row = sheet.createRow((short)6);

				int colnum=1;
						
				for(colnum=0; colnum<columnArray.length; colnum++)
				{
					createCell(
						row,
						cell,
						colnum, 
						true, 
						HSSFCellStyle.ALIGN_CENTER, 
						HSSFCell.CELL_TYPE_STRING, 
						styleHeader, 
						columnArray[colnum], 
						0.0);
				}

				sheet.createFreezePane(0,7,0,7);
				int rownum = 7;
				int itemSize = 0;
				colnum = 0;

				for (int i = 0; i < size; i++) {
					row = sheet.createRow((short)rownum);
					
					BagStatusBean bagBean = (BagStatusBean) skuBagsList.get(i);
					
					//ArrayList itemDetailsList = bagBean.getSkuDetails();
					//itemSize = itemDetailsList.size();
					colnum = 0;
					if (bagBean.isTitle()) {
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style,  
									bagBean.getTripId(), 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, 
									bagBean.getTruck(), 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, 
									bagBean.getTripTime(), 0.0);
								
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
	
					} else if (bagBean.isTotalQuantity()) {
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, styleTitle,  "Total", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
								
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_NUMERIC, styleInt, null, 
									bagBean.getTripQuantity());
					} else if (bagBean.isGrandTotalQuantity()) {
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, styleTitle,  "Grand Total", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
								
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
									HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
						
						createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
									HSSFCell.CELL_TYPE_NUMERIC, styleInt, null,
									bagBean.getTripQuantity());
					} else {
						//for (int j = 0; j < itemSize; j++) {
							colnum = 0;
							//ItemDetailsBean itemBean = (ItemDetailsBean) itemDetailsList.get(j);
							createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
										HSSFCell.CELL_TYPE_STRING, style,  "", 0.0);
							
							createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
										HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
							
							createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
										HSSFCell.CELL_TYPE_STRING, style, "", 0.0);
									
							createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
										HSSFCell.CELL_TYPE_NUMERIC, skuStyle, null, 
										Double.parseDouble(bagBean.getItemCode()));
							
							createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
										HSSFCell.CELL_TYPE_NUMERIC, styleNum, null, 
										bagBean.getItemPrice());
							
							createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
										HSSFCell.CELL_TYPE_NUMERIC, styleInt, null, 
										Double.parseDouble(bagBean.getQuantity()));
						//}
					}
					rownum++;
					
				}
				
				String fileName = PaxTraxConstants.SKU_TRANSFER_REPORT + user + ".xls";
				String filePath = PaxTraxConstants.BAGTRAX_REPORTS_BASE_PATH;
				
				FileOutputStream fileOut = new FileOutputStream(filePath+fileName);
						
				PaxTraxLog.logDebug("Written to file "+ fileName);

				wb.write(fileOut);
				fileOut.close();
				
				request.setAttribute(PaxTraxConstants.SUCCESS, PaxTraxConstants.YES);
				request.setAttribute(PaxTraxConstants.FILE_NAME, fileName);
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				
			}
		}
		catch(Exception e)
		{
			PaxTraxLog.logError("Exception caught :SalesReportAction::"
										+"generateSkuTransferReport ", e);
			e.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::"
								+"generateSkuTransferReport:end");
		return (mapping.findForward("skuTransferDisplayPage"));
	}

	/**
	 * Displays summary sku transfer page.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward skuTransferGroupBySkuDisplayPage(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::"
								+"skuTransferGroupBySkuDisplayPage:start");
		BagTrackingReportsForm bagTrackingReportsForm = 
								(BagTrackingReportsForm) form;
		bagTrackingReportsForm.setListOfReports(null);
		bagTrackingReportsForm.setSkuTransferDate(null);
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::"
									+"skuTransferGroupBySkuDisplayPage:end");
		return(mapping.findForward("summarySkuTransferDisplayPage"));
	}


	/**
	 * Returns summary sku transfer information.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getSkuTransferGroupBySkuDetails(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) {
		try {
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsAction::"
						+"getSkuTransferGroupBySkuDetails:start");
			BagTrackingReportsForm bagTrackingReportsForm = 
											(BagTrackingReportsForm) form;
			if (bagTrackingReportsForm.getSkuTransferDate() != null && 
				bagTrackingReportsForm.getSkuTransferDate().length() > 0) {
				
				BagTrackingReportsDelegate bagTrackingRptDelegate = 
											new BagTrackingReportsDelegate();
					/*Modified on 28th June 2006 - Starts
					 *SR 1042 International DF Sale */

				HttpSession session  = request.getSession();
				session.setAttribute("intl",bagTrackingReportsForm.getIsInternational()+"");
				session.setAttribute("preOrder",bagTrackingReportsForm.getIsPreorder()+"");
				SKUSummaryReportBean summaryReportBean = new SKUSummaryReportBean();
				summaryReportBean.setFromDateTime(bagTrackingReportsForm.getSkuTransferDate() +" 00:00:00");
				summaryReportBean.setToDateTime(bagTrackingReportsForm.getSkuTransferDate() +" 23:59:59");
				if(bagTrackingReportsForm.getIsInternational())
					summaryReportBean.setInternationalFlag("Y");
				else
					summaryReportBean.setInternationalFlag("N");
					
				//System.out.println(bagTrackingReportsForm.getIsPreorder());
				if(bagTrackingReportsForm.getIsPreorder())
					summaryReportBean.setPreOrderFlag("Y");
				else
					summaryReportBean.setPreOrderFlag("N");
					
				ArrayList skuTransferList = 
					bagTrackingRptDelegate.getSkuTransferGroupBySkusList(
					summaryReportBean);
					/*Modified on 28th June 2006 - Ends
					 *SR 1042 International DF Sale */
								
				
				bagTrackingReportsForm.setListOfReports(skuTransferList);
				
				PaxTraxLog.logDebug("skuTransferList.size() "+ skuTransferList.size());
				if (skuTransferList.size() > 0) {
					request.setAttribute(
										PaxTraxConstants.RESULT, 
											PaxTraxConstants.SUCCESS);
				} else {
					request.setAttribute(
										PaxTraxConstants.RESULT, 
											PaxTraxConstants.FAILURE);
				}
			}
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsAction::"
								+"getSkuTransferGroupBySkuDetails:end");
		} catch(PaxTraxSystemException pse) {
    		PaxTraxLog.logError("Exception in PaxTrax::BagTrackingEnquiryAction::"
    								+"getSkuTransferGroupBySkuDetails"+pse);
    		return(mapping.findForward(PaxTraxConstants.REPORT_ERROR));
    	}
		return(mapping.findForward("summarySkuTransferDisplayPage"));
	}

	/**
	 * Generates summary sku Transfer Report in excel format
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward generateSkuTransferGroupBySkuReport(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) {
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::"
								+"generateSkuTransferGroupBySkuReport:start");
		String columnArray[]=
			{"SKU","SKU Price","Quantity"};
		String forward = "";
		try {
			BagTrackingReportsForm bagTrackingReportsForm = (BagTrackingReportsForm) form;
			HttpSession session = request.getSession();
			String user = (String) session.getAttribute("userId");
			ArrayList skuBagsList = bagTrackingReportsForm.getListOfReports();
			/*Modified on 28th June 2006 - Starts
			 *SR 1042 International DF Sale */

			bagTrackingReportsForm.setIsInternational(new Boolean(""+session.getAttribute("intl")).booleanValue());
			bagTrackingReportsForm.setIsPreorder(new Boolean(""+session.getAttribute("preOrder")).booleanValue());
			//session.removeAttribute("intl");
			//session.removeAttribute("preOrder");
			
			/*Modified on 28th June 2006 - Ends
			 *SR 1042 International DF Sale */

			int size = 0;
			if (skuBagsList != null) {
				size = skuBagsList.size();
				
				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet(PaxTraxConstants.SKU_SUMMARY_REPORT);
				sheet.setDefaultColumnWidth((short)16);
				//Create Header Font
				HSSFFont fontHeader = wb.createFont();
				fontHeader.setFontHeightInPoints((short)10);
				fontHeader.setFontName(HSSFFont.FONT_ARIAL);
				fontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
								
				//Create font for the workbook Data cells
				HSSFFont font = wb.createFont();
				font.setFontHeightInPoints((short)10);
				font.setFontName(HSSFFont.FONT_ARIAL);
				
				//Style for the Header cells
				HSSFCellStyle styleHeader = wb.createCellStyle();
				styleHeader.setFont(fontHeader);
				styleHeader.setFillForegroundColor(HSSFColor.AQUA.index);
				styleHeader.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
				styleHeader.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				
				//Style for the Side Title cells
				HSSFCellStyle styleTitle = wb.createCellStyle();
				styleTitle.setFont(fontHeader);

				//Style for the Data cells
				HSSFCellStyle style = wb.createCellStyle();
				style.setFont(font);
				
				//Style for numeric data cells
				HSSFCellStyle styleNum = wb.createCellStyle();
				HSSFDataFormat format = wb.createDataFormat();
				styleNum.setDataFormat(format.getFormat("#,##0.00"));
				styleNum.setFont(font);
				
				/* integer style */
				HSSFCellStyle styleInt = wb.createCellStyle();
				HSSFDataFormat format2 = wb.createDataFormat();
				styleInt.setDataFormat(format2.getFormat("#,###"));
				styleInt.setFont(font);

				/* sku style */
				HSSFCellStyle skuStyle = wb.createCellStyle();
				HSSFDataFormat format3 = wb.createDataFormat();
				skuStyle.setDataFormat(format2.getFormat("####"));
				skuStyle.setFont(font);
				

				//Create Title rows
				HSSFRow row = sheet.createRow((short)0);
				HSSFCell cell = null;
				sheet.addMergedRegion(new Region(0, (short)0, 0, (short)2));
				createCell(row,
							cell,
							0, 
							true, 
							HSSFCellStyle.ALIGN_CENTER, 
							HSSFCell.CELL_TYPE_STRING, 
							styleHeader, 
							PaxTraxConstants.DFS_OKINAWA, 0.0);
							
				row = sheet.createRow((short)1);
				createCell(row,
							cell,
							0, 
							true, 
							HSSFCellStyle.ALIGN_CENTER, 
							HSSFCell.CELL_TYPE_STRING, 
							styleHeader, 
							PaxTraxConstants.SKU_SUMMARY_REPORT, 
							0.0);

				sheet.addMergedRegion(new Region(1, (short)0, 1, (short)2));	
				cell = row.getCell((short)0);
				cell.setCellStyle(styleHeader);

				row = sheet.createRow((short)3);
				//sheet.addMergedRegion(new Region(3, (short)0, 3, (short)1));
				createCell(row,
							cell,
							0, 
							true, 
							HSSFCellStyle.ALIGN_LEFT, 
							HSSFCell.CELL_TYPE_STRING, 
							styleTitle, 
							"Date :"+bagTrackingReportsForm.getSkuTransferDate(), 
							0.0);
				/*Modified on 28th June 2006 - Starts
				 *SR 1042 International DF Sale */

				String travelType = PaxTraxConstants.DOMESTIC;;
				if(bagTrackingReportsForm.getIsInternational())
					travelType = PaxTraxConstants.INTERNATIONAL;
				
				String preOrderType = PaxTraxConstants.NON_PREORDER;
				if(bagTrackingReportsForm.getIsPreorder())
					preOrderType = PaxTraxConstants.PREORDER;
							
				createCell(row,cell,1, 
											true, 
											HSSFCellStyle.ALIGN_LEFT, 
											HSSFCell.CELL_TYPE_STRING, 
											styleTitle, 
											travelType, 
											0.0);
				createCell(row,cell,2, 	true, 
										HSSFCellStyle.ALIGN_LEFT, 
										HSSFCell.CELL_TYPE_STRING, 
										styleTitle, 
										preOrderType, 
										0.0);	
												
				/*Modified on 28th June 2006 - Ends
				 *SR 1042 International DF Sale */

				row = sheet.createRow((short)5);
				sheet.addMergedRegion(new Region(5, (short)2,5, (short)4));				
				sheet.addMergedRegion(new Region(5, (short)5,5, (short)7));				

				row = sheet.createRow((short)6);

				int colnum=1;
						
				for(colnum=0; colnum<columnArray.length; colnum++) {
					createCell(
						row,
						cell,
						colnum, 
						true, 
						HSSFCellStyle.ALIGN_CENTER, 
						HSSFCell.CELL_TYPE_STRING, 
						styleHeader, 
						columnArray[colnum], 
						0.0);
				}

				sheet.createFreezePane(0,7,0,7);
				int rownum = 7;

				colnum = 0;
				double grandTotal = 0;
				double total = 0;

				for (int i = 0; i < size; i++) {
					row = sheet.createRow((short)rownum);
					ItemDetailsBean itemBean = (ItemDetailsBean) skuBagsList.get(i);
					
					colnum = 0;
					
					total = Double.parseDouble(itemBean.getQuantity());
					grandTotal +=total;
					
					createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
								HSSFCell.CELL_TYPE_NUMERIC, skuStyle, 
								null, Double.parseDouble(itemBean.getItemCode()));
					
					createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
								HSSFCell.CELL_TYPE_NUMERIC, styleNum, 
								null, itemBean.getItemPrice());
					
					createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
								HSSFCell.CELL_TYPE_NUMERIC, styleInt, 
								null, total);
					rownum++;
				}
				row = sheet.createRow((short)rownum);
				colnum = 0;

				createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
							HSSFCell.CELL_TYPE_STRING, styleTitle, 
							"Grand Total", 0.0);
				
				createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_CENTER, 
							HSSFCell.CELL_TYPE_STRING, style, 
							null, 0.0);
				
				createCell(row, cell, colnum++, true, HSSFCellStyle.ALIGN_RIGHT, 
								HSSFCell.CELL_TYPE_NUMERIC, styleInt, 
								null, grandTotal);

				String fileName = PaxTraxConstants.SKU_SUMMARY_REPORT + user + ".xls";
				String filePath = PaxTraxConstants.BAGTRAX_REPORTS_BASE_PATH;
				
				FileOutputStream fileOut = new FileOutputStream(filePath+fileName);
						
				PaxTraxLog.logDebug("Written to file "+ filePath+fileName);

				wb.write(fileOut);
				fileOut.close();
				
				request.setAttribute(PaxTraxConstants.SUCCESS, PaxTraxConstants.YES);
				request.setAttribute(PaxTraxConstants.FILE_NAME, fileName);
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);

			}
		} catch(Exception e) {
			PaxTraxLog.logError("Exception caught :SalesReportAction::generateSkuTransferReport ", e);
			e.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}		
		PaxTraxLog.logDebug("PaxTrax::BagTrackingReportsAction::"
								+"generateSkuTransferGroupBySkuReport:End");
		return(mapping.findForward("summarySkuTransferDisplayPage"));
	}	

	/**
	 * Calculates sku quantity for each trip
	 * @param skuTransferList the bagstatus bean containing sku details
	 * @return ArrayList list of bagstatus beans
	 */
	private ArrayList calculateQuantityPerTrip(ArrayList skuTransferList) {

		String prevTripId = "";
		String currTripId = "";

		int total = 0;
		int grandTotal = 0;
		ArrayList bagList = new ArrayList();
		
		for (int i = 0; i < skuTransferList.size(); i++) {
			BagStatusBean bagBean = (BagStatusBean) skuTransferList.get(i);
			currTripId = bagBean.getTripId();
			
			if (i == 0) { /* insert title for the first trip */
				BagStatusBean titleBean = new BagStatusBean();
				titleBean.setTripId(bagBean.getTripId());
				titleBean.setTruck(bagBean.getTruck());
				titleBean.setTitle(true);
				titleBean.setTripTime(bagBean.getTripTime());
				bagList.add(titleBean);
			} else if ((i != 0) && !currTripId.equals(prevTripId)) {
				/* insert total quantity for the next trip */
				BagStatusBean totalBean = new BagStatusBean();
				totalBean.setTotalQuantity(true);
				totalBean.setTripQuantity(total);
				bagList.add(totalBean);
				grandTotal += total;
				total = 0;

				/* insert title for the next trip */
				BagStatusBean titleBean = new BagStatusBean();
				titleBean.setTripId(bagBean.getTripId());
				titleBean.setTruck(bagBean.getTruck());
				titleBean.setTripTime(bagBean.getTripTime());
				titleBean.setTitle(true);
				bagList.add(titleBean);
			}
			total += Integer.parseInt(bagBean.getQuantity());
			bagList.add(bagBean);
			prevTripId = currTripId;
			
		}
		
		if (bagList.size() > 0) {
			/* insert total quantity for last trip id */
			BagStatusBean bagTotalBean = new BagStatusBean();
			bagTotalBean.setTotalQuantity(true);
			bagTotalBean.setTripQuantity(total);
			bagList.add(bagTotalBean);
			grandTotal += total;
			
			/* insert grand total for all trips */
			BagStatusBean grandTotalBean = new BagStatusBean();
			grandTotalBean.setGrandTotalQuantity(true);
			grandTotalBean.setTripQuantity(grandTotal);
			bagList.add(grandTotalBean);
		}
		
		return bagList;
	}

	private void createCell(HSSFRow row, HSSFCell cell, int cellPosition, boolean newCell, 
				int cellAlignment, int cellType, HSSFCellStyle style ,String strValue, double doubleValue)
	{
		if(newCell)
			cell = row.createCell((short)cellPosition);
		
		cell.setCellType(cellType);
		style.setAlignment((short)cellAlignment);

		if(cell.getCellType()==HSSFCell.CELL_TYPE_NUMERIC)
			cell.setCellValue(doubleValue);
		else	
			cell.setCellValue(strValue);
			
		cell.setCellStyle(style);
	}	
	
}
