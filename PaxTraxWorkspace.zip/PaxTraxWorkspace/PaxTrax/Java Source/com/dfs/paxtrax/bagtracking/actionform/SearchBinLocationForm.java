package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains search attributes for binLocation
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 27/05/2004   	Yuvarani	    Created   
*/

public class SearchBinLocationForm extends PaxTraxActionForm {
	
	// The Type attribute of the search page
	private String type = "W";
	
	// The capacity attribute of the search page
	private String capacity = null;
	
	// The Remarks attribute of the search page
	private String remarks = null;
	
	// The pickup location attribute of the search page
	private String pickupLocation = null;
	
	/**
	 * The collection that is used to hold list of all BinLoc beans that 
	 * match the search criteria
	 */
	private ArrayList binLocList = null;
	    
	//List of pickup locations
	private ArrayList pickupLocationList = null;

	/**
	 * Returns the binLocList.
	 * @return ArrayList
	 */
	public ArrayList getBinLocList()
	{
		return binLocList;
	}

	/**
	 * Returns the capacity.
	 * @return String
	 */
	public String getCapacity()
	{
		return capacity;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Sets the binLocList.
	 * @param binLocList The binLocList to set
	 */
	public void setBinLocList(ArrayList binLocList)
	{
		this.binLocList = binLocList;
	}

	/**
	 * Sets the capacity.
	 * @param capacity The capacity to set
	 */
	public void setCapacity(String capacity)
	{
		this.capacity = capacity;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getRemarks()
	{
		return remarks;
	}

	/**
	 * Returns the type.
	 * @return String
	 */
	public String getType()
	{
		return type;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setRemarks(String remarks)
	{
		this.remarks = remarks;
	}

	/**
	 * Sets the type.
	 * @param type The type to set
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	/**
	 * Returns the pickupLocationList.
	 * @return ArrayList
	 */
	public ArrayList getPickupLocationList()
	{
		return pickupLocationList;
	}

	/**
	 * Sets the pickupLocationList.
	 * @param pickupLocationList The pickupLocationList to set
	 */
	public void setPickupLocationList(ArrayList pickupLocationList)
	{
		this.pickupLocationList = pickupLocationList;
	}
    
   public void reset(ActionMapping mapping,HttpServletRequest request)
    {
       
       pickupLocation = null; 
    }
    

}