package com.dfs.paxtrax.bagtracking.actionform;

import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.BagTrackingEnquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * @author 107316
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class BagTrackingEnquiryForm extends PaxTraxActionForm
{
	private BagTrackingEnquiryBean btEnquiryBean = null;
	
	private String bagFound = null;
	
	/**
	 * Returns the btEnquiryBean.
	 * @return BagTrackingEnquiryBean
	 */
	public BagTrackingEnquiryBean getBtEnquiryBean()
	{
		return btEnquiryBean;
	}

	/**
	 * Sets the btEnquiryBean.
	 * @param btEnquiryBean The btEnquiryBean to set
	 */
	public void setBtEnquiryBean(BagTrackingEnquiryBean btEnquiryBean)
	{
		this.btEnquiryBean = btEnquiryBean;
	}

	/**
	 * Returns the bagFound.
	 * @return String
	 */
	public String getBagFound()
	{
		return bagFound;
	}

	/**
	 * Sets the bagFound.
	 * @param bagFound The bagFound to set
	 */
	public void setBagFound(String bagFound)
	{
		this.bagFound = bagFound;
	}

}
