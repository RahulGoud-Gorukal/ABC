package com.dfs.paxtrax.bagtracking.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */ 
public interface GeneratePicklistBOHome extends javax.ejb.EJBHome
{
	/**
	 * Creates a default instance of Session Bean: GeneratePicklistBO
	 */
	public com.dfs.paxtrax.bagtracking.business.GeneratePicklistBO create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
