package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.DeliveryManifestBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;


/**
 * This is action form which contains Deivery Manifest attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/06/2004     R.R.Yuvarani     Created   
*/

public class DeliveryManifestForm extends PaxTraxActionForm
{
	public DeliveryManifestForm()
	{
	}
	
	private ArrayList pickup;
	
	private DeliveryManifestBean deliveryBean;
	
	private ArrayList truckList;
	
	/**
	 * Returns the pickup.
	 * @return ArrayList
	 */
	public ArrayList getPickup()
	{
		return pickup;
	}

	/**
	 * Sets the pickup.
	 * @param pickup The pickup to set
	 */
	public void setPickup(ArrayList pickup)
	{
		this.pickup = pickup;
	}

	
	/**
	 * Returns the truckList.
	 * @return ArrayList
	 */
	public ArrayList getTruckList()
	{
		return truckList;
	}

	/**
	 * Sets the truckList.
	 * @param truckList The truckList to set
	 */
	public void setTruckList(ArrayList truckList)
	{
		this.truckList = truckList;
	}

	/**
	 * Returns the deliveryBean.
	 * @return DeliveryManifestBean
	 */
	public DeliveryManifestBean getDeliveryBean()
	{
		return deliveryBean;
	}

	/**
	 * Sets the deliveryBean.
	 * @param deliveryBean The deliveryBean to set
	 */
	public void setDeliveryBean(DeliveryManifestBean deliveryBean)
	{
		this.deliveryBean = deliveryBean;
	}
	
	/* Code added as part of SR 1042 - International DF Sale Enhancement */
	/* Code added on July 17, 2006 */
	/* This property will hold the international flag */
	
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		if(deliveryBean!=null)
		{
			deliveryBean.setInternational("N");			
		}
	}	

	/* End of code added on July 17, 2006 */

}