package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * 
 * This Class contains tracing Refunded Bags related attributes
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Jaganmohan Gopinath
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 29/07/2007	Uma			Created   
 */

public class SkuBean extends PaxTraxValueObject{
	
	private String skuNo = null;
	private String skuQty = null;
	
	public SkuBean() {
	}	
	
	/**
	 * @return
	 */
	public String getSkuNo() {
		return skuNo;
	}

	/**
	 * @return
	 */
	public String getSkuQty() {
		return skuQty;
	}

	/**
	 * @param string
	 */
	public void setSkuNo(String string) {
		skuNo = string;
	}

	/**
	 * @param string
	 */
	public void setSkuQty(String string) {
		skuQty = string;
	}

}
