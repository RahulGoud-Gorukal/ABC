package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;
/**
* This is valueobject class which contains bag Bean attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 06/07/2004    Sundarrajan.K. Created   
*/

public class PaxPurchaseInquiryBean extends PaxTraxValueObject
{

	// sets the pax bean
	private PAXBean paxBean = null;

	// sets the total number of bags
	private int totalNoOfBags = 0;

	// sets the total number of items
	private int totalNoOfItems = 0;

	private boolean validPax = false;

	// sets the purchase history list
	private ArrayList purchaseHistory = null;

	private double purchaseAmount;

	private ArrayList departmentList = null;

	private String totalAmtExceeds = null;
	
	private String paxApproved = null;

	/**
	 * Returns the purchaseHistory.
	 * @return ArrayList
	 */
	public ArrayList getPurchaseHistory()
	{
		return purchaseHistory;
	}

	/**
	 * Returns the totalNoOfBags.
	 * @return int
	 */
	public int getTotalNoOfBags()
	{
		return totalNoOfBags;
	}

	/**
	 * Returns the totalNoOfItems.
	 * @return int
	 */
	public int getTotalNoOfItems()
	{
		return totalNoOfItems;
	}

	/**
	 * Sets the purchaseHistory.
	 * @param purchaseHistory The purchaseHistory to set
	 */
	public void setPurchaseHistory(ArrayList purchaseHistory)
	{
		this.purchaseHistory = purchaseHistory;
	}

	/**
	 * Sets the totalNoOfBags.
	 * @param totalNoOfBags The totalNoOfBags to set
	 */
	public void setTotalNoOfBags(int totalNoOfBags)
	{
		this.totalNoOfBags = totalNoOfBags;
	}

	/**
	 * Sets the totalNoOfItems.
	 * @param totalNoOfItems The totalNoOfItems to set
	 */
	public void setTotalNoOfItems(int totalNoOfItems)
	{
		this.totalNoOfItems = totalNoOfItems;
	}

	/**
	 * Returns the paxBean.
	 * @return PAXBean
	 */
	public PAXBean getPaxBean()
	{
		return paxBean;
	}

	/**
	 * Sets the paxBean.
	 * @param paxBean The paxBean to set
	 */
	public void setPaxBean(PAXBean paxBean)
	{
		this.paxBean = paxBean;
	}

	/**
	 * Returns the validPax.
	 * @return boolean
	 */
	public boolean getValidPax()
	{
		return validPax;
	}

	/**
	 * Sets the validPax.
	 * @param validPax The validPax to set
	 */
	public void setValidPax(boolean validPax)
	{
		this.validPax = validPax;
	}

	/**
	 * Returns the departmentList.
	 * @return ArrayList
	 */
	public ArrayList getDepartmentList()
	{
		return departmentList;
	}

	/**
	 * Returns the purchaseAmount.
	 * @return double
	 */
	public double getPurchaseAmount()
	{
		return purchaseAmount;
	}

	/**
	 * Sets the departmentList.
	 * @param departmentList The departmentList to set
	 */
	public void setDepartmentList(ArrayList departmentList)
	{
		this.departmentList = departmentList;
	}

	/**
	 * Sets the purchaseAmount.
	 * @param purchaseAmount The purchaseAmount to set
	 */
	public void setPurchaseAmount(double purchaseAmount)
	{
		this.purchaseAmount = purchaseAmount;
	}

	/**
	 * Returns the totalAmtExceeds.
	 * @return String
	 */
	public String getTotalAmtExceeds()
	{
		return totalAmtExceeds;
	}

	/**
	 * Sets the totalAmtExceeds.
	 * @param totalAmtExceeds The totalAmtExceeds to set
	 */
	public void setTotalAmtExceeds(String totalAmtExceeds)
	{
		this.totalAmtExceeds = totalAmtExceeds;
	}

	/**
	 * Returns the paxApproved.
	 * @return String
	 */
	public String getPaxApproved()
	{
		return paxApproved;
	}

	/**
	 * Sets the paxApproved.
	 * @param paxApproved The paxApproved to set
	 */
	public void setPaxApproved(String paxApproved)
	{
		this.paxApproved = paxApproved;
	}

}
