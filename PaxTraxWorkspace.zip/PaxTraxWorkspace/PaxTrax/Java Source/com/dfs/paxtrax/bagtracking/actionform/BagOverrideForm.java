package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * This is action form which contains Truck attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE         USER            	COMMENTS
 * 04/11/2004   P.C.Sathish		    Created   
*/

public class BagOverrideForm extends PaxTraxActionForm {
	private BagStatusBean bagBean;
	private ArrayList trucks;
	// Added/Modified by David for CR 3659 starts
	private ArrayList bagBeanList;
	private BagStatusBean bagBeanCheck;
	private BagStatusBean flightStatusBean;
	// Added/Modified by David for CR 3659 ends
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		if (bagBean != null) bagBean.setTruckDeparted("N");
	}

	/**
	 * Returns the bagBean.
	 * @return BagStatusBean
	 */
	public BagStatusBean getBagBean() {
		return bagBean;
	}

	/**
	 * Sets the bagBean.
	 * @param bagBean The bagBean to set
	 */
	public void setBagBean(BagStatusBean bagBean) {
		this.bagBean = bagBean;
	}

	/**
	 * Returns the trucks.
	 * @return ArrayList
	 */
	public ArrayList getTrucks() {
		return trucks;
	}

	/**
	 * Sets the trucks.
	 * @param trucks The trucks to set
	 */
	public void setTrucks(ArrayList trucks) {
		this.trucks = trucks;
	}

	/**
	 * @return
	 */
	public ArrayList getBagBeanList() {
		return bagBeanList;
	}

	/**
	 * @param list
	 */
	public void setBagBeanList(ArrayList list) {
		bagBeanList = list;
	}

	/**
	 * @return
	 */
	public BagStatusBean getBagBeanCheck() {
		return bagBeanCheck;
	}

	/**
	 * @param bean
	 */
	public void setBagBeanCheck(BagStatusBean bean) {
		bagBeanCheck = bean;
	}

	/**
	 * @return
	 */
	public BagStatusBean getFlightStatusBean() {
		return flightStatusBean;
	}

	/**
	 * @param bean
	 */
	public void setFlightStatusBean(BagStatusBean bean) {
		flightStatusBean = bean;
	}

}
