package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.StockAtPickupLocationForm;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.StockAtPickupLocationInquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for a pickup location
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 28/06/2004    Yuvarani		Created
*/

public class StockAtPickupLocationInquiryAction extends PaxTraxAction
{
	/**
	 * Forwards to StockAtPickupLocation page.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxtraxSystemException
	 */
	public ActionForward goToStockAtPickupLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::StockAtPickupLocationAction::goToStockAtPickupLocation::Begin");
		StockAtPickupLocationForm stockForm = (StockAtPickupLocationForm) form;
		StockAtPickupLocationInquiryBean stockBean =
			new StockAtPickupLocationInquiryBean();
		String forward = null;
		ReferenceDataDelegate referData = new ReferenceDataDelegate();
		try
		{
			ArrayList pickupLocation =
				referData.loadReferenceData(PaxTraxConstants.PICK_UP_LOCATION);
			stockForm.setStockAtPickup(stockBean);
			stockForm.setPickupLocation(pickupLocation);
			forward = PaxTraxConstants.STOCK_AT_PICKUP_LOCATION;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug(
				"PaxTrax::StockAtPickupLocationAction::goToStockAtPickupLocation",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::StockAtPickupLocationAction::goToStockAtPickupLocation::End");
		return mapping.findForward(forward);
	}

	/**
	 * Gets the information depending on the given pickup location.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward getStockAtPickupLocationInquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::StockAtPickupLocationAction::getStockAtPickupLocationInquiry::Begin");
		StockAtPickupLocationForm stockForm = (StockAtPickupLocationForm) form;
		StockAtPickupLocationInquiryBean stockBean =
			stockForm.getStockAtPickup();
		BagTrackingReportsDelegate stockDelegate =
			new BagTrackingReportsDelegate();
		String forward = null;
		try
		{
			stockBean =
				stockDelegate.getStockAtPickupLocationInquiry(stockBean);
			if ((stockBean.getStockList() == null)
				|| (stockBean.getStockList().size() == 0))
			{
				request.setAttribute(
					PaxTraxConstants.ERROR_CODE,
					PaxTraxConstants.ERROR_CODE);
			}
			stockForm.setStockAtPickup(stockBean);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			forward = PaxTraxConstants.STOCK_AT_PICKUP_LOCATION;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug(
				"PaxTrax::StockAtPickupLocationAction::getStockAtPickupLocationInquiry",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"Paxtrax::StockAtPickupLocationAction::getStockAtPickupLocationInquiry::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method printStockAtPickupLocationInquiry.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward printStockAtPickupLocationInquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{

		PaxTraxLog.logDebug(
			"Paxtrax::StockAtPickupLocationAction::printStockAtPickupLocationInquiry::Begin");
		StockAtPickupLocationForm stockForm = (StockAtPickupLocationForm) form;
		StockAtPickupLocationInquiryBean stockBean =
			stockForm.getStockAtPickup();
		ArrayList pickupLocationList = stockForm.getPickupLocation();
		String pickupLocation = stockBean.getPickupLocation();
		if (pickupLocation.equals("-1"))
		{
			stockBean.setPickupLocationValue("All");
		}
		else
		{
			for (int i = 0; i < pickupLocationList.size(); i++)
			{
				ReferenceDataBean tempBean =
					(ReferenceDataBean) pickupLocationList.get(i);
				if (pickupLocation.equals(tempBean.getCodeId()))
				{
					stockBean.setPickupLocationValue(tempBean.getCodeValue());
					break;
				}
			}
		}
		stockForm.setStockAtPickup(stockBean);
		stockForm.setStockAtPickup(stockBean);
		PaxTraxLog.logDebug(
			"Paxtrax::StockAtPickupLocationAction::printStockAtPickupLocationInquiry::End");
		return mapping.findForward(
			PaxTraxConstants.PRINT_STOCK_AT_PICKUP_LOCATION);
	}
}
