package com.dfs.paxtrax.bagtracking.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.GeneratePicklistBO;
import com.dfs.paxtrax.bagtracking.business.GeneratePicklistBOHome;
import com.dfs.paxtrax.bagtracking.valueobject.PicklistSearchBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class GeneratePicklistDelegate 
{
    public ArrayList getPicklist(PicklistSearchBean picklistSearchBean) throws PaxTraxSystemException
    {
    	ArrayList pickList = new ArrayList();
    	
    	try
    	{
			PaxTraxLog.logDebug("PaxTrax::GeneratePicklistDelegate::getPicklist::Begin");
			
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj = locator.getEJBHome(PaxTraxConstants.PT_JNDI_BT_GEN_PICKLIST);
			GeneratePicklistBOHome home =
				(GeneratePicklistBOHome) PortableRemoteObject.narrow(obj, GeneratePicklistBOHome.class);
			GeneratePicklistBO remote = home.create();
			pickList = remote.getPicklist(picklistSearchBean);

			PaxTraxLog.logDebug("PaxTrax::GeneratePicklistDelegate::getPicklist::End");
    	}
		catch (NamingException ne)
		{
			PaxTraxLog.logError("Exception in PaxTrax::GeneratePicklistDelegate::getPicklist",ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError("Exception in PaxTrax::GeneratePicklistDelegate::getPicklist",re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError("Exception in PaxTrax::GeneratePicklistDelegate::getPicklist",ce);
			throw new PaxTraxSystemException(ce);
		}
		
		return(pickList);
    	
    }
    
}
