package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.PaxRefundBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * This is action form which contains Pax Refund attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 26/07/2004   Joseph Oommen A     Created   
*/

public class PaxRefundForm extends PaxTraxActionForm
{
	PaxRefundBean paxRefundBean = null;
	ArrayList resultList = null;
       
	/**
	 * Returns the paxRefundBean.
	 * @return PaxRefundBean
	 */
	public PaxRefundBean getPaxRefundBean()
	{
		return paxRefundBean;
	}
	
	public PaxRefundBean getPaxRefundBean(int i)
	{
		return (PaxRefundBean)resultList.get(i);
	}

	/**
	 * Sets the paxRefundBean.
	 * @param paxRefundBean The paxRefundBean to set
	 */
	public void setPaxRefundBean(PaxRefundBean paxRefundBean)
	{
		this.paxRefundBean = paxRefundBean;
	}

	/**
	 * Returns the resultList.
	 * @return ArrayList
	 */
	public ArrayList getResultList()
	{
		return resultList;
	}

	/**
	 * Sets the resultList.
	 * @param resultList The resultList to set
	 */
	public void setResultList(ArrayList resultList)
	{
		this.resultList = resultList;
	}
	
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		if (resultList != null) 
		{
			
			for(int i =0;i<resultList.size();i++)
			{
				PaxRefundBean temp=(PaxRefundBean)resultList.get(i);
				temp.setActionTaken("N");
				resultList.remove(i);
				resultList.add(i,temp);
				
			}
		}
	}	
}
