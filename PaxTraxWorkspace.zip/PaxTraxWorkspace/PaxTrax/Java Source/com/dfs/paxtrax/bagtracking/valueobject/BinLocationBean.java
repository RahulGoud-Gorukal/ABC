package com.dfs.paxtrax.bagtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;



/**
 * This is valueobject class which contains bin location attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *           DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE          USER            COMMENTS
 * 18/05/2004    R.R.Yuvarani	Created   
 */

public class BinLocationBean extends PaxTraxValueObject {

	//  The binLoc attribute
	private String binLocation = null;
	
	// The capacity of the BinLoc
	private String capacity = null;
	
	// The description of the BinLoc
	private String remarks = null;
	
	//Pickup location type
	private String type;
	
	
	//Holding Location
	private String holdingLocation = "N";
	    
	//PickupLocationBean
	private ReferenceDataBean pickupLocationBean = null;
	/**
	 * Returns the binLocation.
	 * @return String
	 */
	public String getBinLocation()
	{
		return binLocation;
	}
	
	
	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getRemarks()
	{
		return remarks;
	}
	
	/**
	 * Sets the binLocation.
	 * @param binLocation The binLocation to set
	 */
	public void setBinLocation(String binLocation)
	{
		this.binLocation = binLocation;
	}
	
	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setRemarks(String remarks)
	{
		this.remarks = remarks;
	}
	
	/**
	 * Returns the type.
	 * @return String
	 */
	public String getType()
	{
		return type;
	}
	
	/**
	 * Sets the type.
	 * @param type The type to set
	 */
	public void setType(String type)
	{
		this.type = type;
	}
	


	/**
	 * Returns the capacity.
	 * @return String
	 */
	public String getCapacity()
	{
		return capacity;
	}

	/**
	 * Sets the capacity.
	 * @param capacity The capacity to set
	 */
	public void setCapacity(String capacity)
	{
		this.capacity = capacity;
	}

	/**
	 * Returns the pickupLocationBean.
	 * @return ReferenceDataBean
	 */
	public ReferenceDataBean getPickupLocationBean()
	{
		return pickupLocationBean;
	}

	/**
	 * Sets the pickupLocationBean.
	 * @param pickupLocationBean The pickupLocationBean to set
	 */
	public void setPickupLocationBean(ReferenceDataBean pickupLocationBean)
	{
		this.pickupLocationBean = pickupLocationBean;
	}

	

	/**
	 * Returns the holdingLocation.
	 * @return String
	 */
	public String getHoldingLocation()
	{
		return holdingLocation;
	}

	/**
	 * Sets the holdingLocation.
	 * @param holdingLocation The holdingLocation to set
	 */
	public void setHoldingLocation(String holdingLocation)
	{
		this.holdingLocation = holdingLocation;
	}

}