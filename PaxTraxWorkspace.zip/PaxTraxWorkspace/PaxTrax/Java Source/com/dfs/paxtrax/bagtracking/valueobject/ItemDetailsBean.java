package com.dfs.paxtrax.bagtracking.valueobject;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * This is valueobject class which contains SKU attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *           DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE          USER            COMMENTS
 * 30/06/2004    Anand Sivasankaran Created   
 * 29/08/2005    P.C. Sathish 		Modified
 */
public class ItemDetailsBean extends PaxTraxValueObject
{
    private String itemCode = null;
    private String quantity = null;
    private String itemDescription;
    /* holds sku price */
    private double itemPrice;
	/**
	 * Returns the itemCode.
	 * @return String
	 */
	public String getItemCode()
	{
		return itemCode;
	}

	/**
	 * Returns the quantity.
	 * @return String
	 */
	public String getQuantity()
	{
		return quantity;
	}

	/**
	 * Sets the itemCode.
	 * @param itemCode The itemCode to set
	 */
	public void setItemCode(String itemCode)
	{
		this.itemCode = itemCode;
	}

	/**
	 * Sets the quantity.
	 * @param quantity The quantity to set
	 */
	public void setQuantity(String quantity)
	{
		this.quantity = quantity;
	}

	/**
	 * Returns the itemDescription.
	 * @return String
	 */
	public String getItemDescription() {
		return itemDescription;
	}

	/**
	 * Sets the itemDescription.
	 * @param itemDescription The itemDescription to set
	 */
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	/**
	 * Returns the itemPrice.
	 * @return double
	 */
	public double getItemPrice() {
		return itemPrice;
	}

	/**
	 * Sets the itemPrice.
	 * @param itemPrice The itemPrice to set
	 */
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

}
