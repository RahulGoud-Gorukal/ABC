package com.dfs.paxtrax.bagtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class GeneratePicklistBean extends PaxTraxValueObject 
{
    /**
       The WH BinLocation attribute
     */
    private String whBinLocation = null;
    /**
       The carton attribute
     */
    private String carton = null;
    
	/**
	 * Returns the carton.
	 * @return String
	 */
	public String getCarton()
	{
		return carton;
	}

	/**
	 * Returns the whBinLocation.
	 * @return String
	 */
	public String getWhBinLocation()
	{
		return whBinLocation;
	}

	/**
	 * Sets the carton.
	 * @param carton The carton to set
	 */
	public void setCarton(String carton)
	{
		this.carton = carton;
	}

	/**
	 * Sets the whBinLocation.
	 * @param whBinLocation The whBinLocation to set
	 */
	public void setWhBinLocation(String whBinLocation)
	{
		this.whBinLocation = whBinLocation;
	}

}
