package com.dfs.paxtrax.bagtracking.action;


/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.SearchBinLocationForm;
import com.dfs.paxtrax.bagtracking.service.BinLocationDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
*  This is action class which performs search binLocation details
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 27/05/2004    Yuvarani		Created
*/
public class SearchBinLocationAction extends PaxTraxAction
{

	/**
	 * This method searches for bin location that satisfies the given criteria
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem while searching
	 */
	public ActionForward searchBinLocationDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
			PaxTraxLog.logDebug("PaxTrax::SearchBinLocationAction::searchBinLocationDetails::Begin");
			int pageNumber = 0;
			ArrayList allRecords = null;
			ArrayList currentRecords = null;
			SearchBinLocationForm searchBinForm = (SearchBinLocationForm)form;
			HttpSession session = request.getSession();
			String pageNumberStr =
				request.getParameter(PaxTraxConstants.PAGE_NUMBER);

			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr =
				((pageNumberStr == null)
					|| pageNumberStr.equals(SQLConstants.BLANK))
					? null
					: pageNumberStr;

			if ((pageNumberStr != null))
				pageNumber = Integer.parseInt(pageNumberStr);

			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */
			if ((pageNumber == 0))
			{
				int size = 0;
				pageNumber = 1;
				BinLocationDelegate binDelegate = new BinLocationDelegate();
				BinLocationBean binBean = new BinLocationBean();
				binBean.setType(searchBinForm.getType());
				ArrayList pickupLocationList = searchBinForm.
													getPickupLocationList();
				for (int i = 0;i < pickupLocationList.size();i++)
				{
					ReferenceDataBean referBean = (ReferenceDataBean)
													pickupLocationList.get(i);
					if (!("-1").equals(searchBinForm.getPickupLocation()))
					{
					if (referBean.getCodeId().equals(
						searchBinForm.getPickupLocation()))
					{
						binBean.setPickupLocationBean(referBean);
						break;
					}
					}
					else
					{
						binBean.setPickupLocationBean(null);
					}
				}
				binBean.setCapacity(searchBinForm.getCapacity());
				binBean.setRemarks(searchBinForm.getRemarks());
				allRecords = binDelegate.searchBinLocationDetails(binBean);	
				
				if (allRecords != null)
					size = allRecords.size();
				session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_RECORDS, allRecords);
				session.removeAttribute(PaxTraxConstants.
											SIZE_OF_ALL_BIN_LOCATION_RECORDS);
				session.setAttribute(
					PaxTraxConstants.SIZE_OF_ALL_BIN_LOCATION_RECORDS,
					Integer.toString(size));
			}
			else
				allRecords =
					(ArrayList) session.getAttribute(
						PaxTraxConstants.ALL_RECORDS);

			PaginationHelper helper = PaginationHelper.getInstance();

			if ((allRecords != null) && (allRecords.size() != 0))
			{
				// Get records to be displayed for the passed page number
				currentRecords =
					helper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
			}
			request.setAttribute(
				PaxTraxConstants.PAGE_NUMBER,
				Integer.toString(pageNumber));

			//Sets records to be displayed for the page number 
			searchBinForm.setBinLocList(currentRecords);				
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			request.setAttribute(PaxTraxConstants.FROM_PAGE,
												PaxTraxConstants.SEARCH_BIN);
		
		PaxTraxLog.logDebug("PaxTrax::SearchBinLocationAction::searchBinLocationDetails::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_BIN_LOCATION_PAGE);
	}

	/**
	 * This method transfers the control to search page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in transferring
	 * the control to search page
	 */
	public ActionForward goToBinLocationSearchPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SearchBinLocationAction::goToBinLocationSearchPage::Begin");
		SearchBinLocationForm searchBinForm = (SearchBinLocationForm)form;
		ReferenceDataDelegate referrenceDelegate = new ReferenceDataDelegate();
		searchBinForm.setBinLocList(null);
		searchBinForm.setCapacity(null);
		searchBinForm.setRemarks(null);
		searchBinForm.setType("W");
		searchBinForm.setPickupLocation(null);
		ArrayList pickupLocationList = referrenceDelegate.
						loadReferenceData(PaxTraxConstants.PICK_UP_LOCATION);
		searchBinForm.setPickupLocationList(pickupLocationList);
		request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);
		PaxTraxLog.logDebug("PaxTrax::SearchBinLocationAction::goToBinLocationSearchPage::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_BIN_LOCATION_PAGE);
	}

	/**
	 * This method is used to change the language
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchBinLocationAction::changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.
														CHANGE_LANGUAGE_COUNTRY);
		String pageNumber = request.getParameter("pno");
		String forward = null;
		if (language != null && country != null)
		{
			super.changeLanguage(request,language,country);
		}

		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
			if (!fromPage.equals("null"))
			{
				if (!pageNumber.equals("-1"))
				{
				request.setAttribute(PaxTraxConstants.PAGE_NUMBER,pageNumber);
				}
				request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);
				request.setAttribute(PaxTraxConstants.RESULT,
												PaxTraxConstants.SUCCESS);
			}
			else
			{
			request.setAttribute(PaxTraxConstants.RESULT,
												PaxTraxConstants.FAILURE);
			}
			forward = PaxTraxConstants.SEARCH_BIN_LOCATION_PAGE;
		PaxTraxLog.logDebug("PaxTrax::SearchBinLocationAction::changeLanguage::End");
		return mapping.findForward(forward);
	}
}
