/*
 * Created on Jun 28, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.dfs.paxtrax.bagtracking.valueobject;


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 113010
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SKUSummaryReportBean extends PaxTraxValueObject{
	
	String fromDateTime=null;
	String toDateTime=null;
	String internationalFlag="N";
	String preOrderFlag="N";
	

	/**
	 * @return
	 */
	public String getFromDateTime() {
		return fromDateTime;
	}

	/**
	 * @return
	 */
	public String getInternationalFlag() {
		return internationalFlag;
	}

	/**
	 * @return
	 */
	public String getToDateTime() {
		return toDateTime;
	}

	/**
	 * @param string
	 */
	public void setFromDateTime(String string) {
		fromDateTime = string;
	}

	/**
	 * @param string
	 */
	public void setInternationalFlag(String string) {
		internationalFlag = string;
	}

	/**
	 * @param string
	 */
	public void setToDateTime(String string) {
		toDateTime = string;
	}

	/**
	 * @return
	 */
	public String getPreOrderFlag()
	{
		return preOrderFlag;
	}

	/**
	 * @param string
	 */
	public void setPreOrderFlag(String string)
	{
		preOrderFlag = string;
	}

}
