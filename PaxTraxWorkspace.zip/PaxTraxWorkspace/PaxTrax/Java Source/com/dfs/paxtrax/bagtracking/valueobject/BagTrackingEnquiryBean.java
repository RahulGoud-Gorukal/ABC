package com.dfs.paxtrax.bagtracking.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 107316
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class BagTrackingEnquiryBean extends PaxTraxValueObject
{
	/* Used to hold all the bag details */
	private BagStatusBean bagBean = null;
	
	/* The ArrayList that will hold the status history of the bag */
	private ArrayList statusHistoryList = null;
	
	/* The ArrayList that will hold the list of items */
	private ArrayList itemList = null;
	
	/* The total number of items present in the bag */
	private String totalNumberOfItems = null;
	
	/* Holds the current System Date */
	private String currentDate = null;
	
	private String reason = null;
	
	private String terminal = null;
	/**
	 * Returns the bagBean.
	 * @return BagStatusBean
	 */
	public BagStatusBean getBagBean()
	{
		return bagBean;
	}

	/**
	 * Returns the currentDate.
	 * @return String
	 */
	public String getCurrentDate()
	{
		return currentDate;
	}

	/**
	 * Returns the itemList.
	 * @return ArrayList
	 */
	public ArrayList getItemList()
	{
		return itemList;
	}

	/**
	 * Returns the statusHistoryList.
	 * @return ArrayList
	 */
	public ArrayList getStatusHistoryList()
	{
		return statusHistoryList;
	}

	/**
	 * Returns the totalNumberOfItems.
	 * @return String
	 */
	public String getTotalNumberOfItems()
	{
		return totalNumberOfItems;
	}

	/**
	 * Sets the bagBean.
	 * @param bagBean The bagBean to set
	 */
	public void setBagBean(BagStatusBean bagBean)
	{
		this.bagBean = bagBean;
	}

	/**
	 * Sets the currentDate.
	 * @param currentDate The currentDate to set
	 */
	public void setCurrentDate(String currentDate)
	{
		this.currentDate = currentDate;
	}

	/**
	 * Sets the itemList.
	 * @param itemList The itemList to set
	 */
	public void setItemList(ArrayList itemList)
	{
		this.itemList = itemList;
	}

	/**
	 * Sets the statusHistoryList.
	 * @param statusHistoryList The statusHistoryList to set
	 */
	public void setStatusHistoryList(ArrayList statusHistoryList)
	{
		this.statusHistoryList = statusHistoryList;
	}

	/**
	 * Sets the totalNumberOfItems.
	 * @param totalNumberOfItems The totalNumberOfItems to set
	 */
	public void setTotalNumberOfItems(String totalNumberOfItems)
	{
		this.totalNumberOfItems = totalNumberOfItems;
	}

	/**
	 * Returns the reason.
	 * @return String
	 */
	public String getReason()
	{
		return reason;
	}

	/**
	 * Sets the reason.
	 * @param reason The reason to set
	 */
	public void setReason(String reason)
	{
		this.reason = reason;
	}

	/**
	 * Returns the terminal.
	 * @return String
	 */
	public String getTerminal()
	{
		return terminal;
	}

	/**
	 * Sets the terminal.
	 * @param terminal The terminal to set
	 */
	public void setTerminal(String terminal)
	{
		this.terminal = terminal;
	}

}
