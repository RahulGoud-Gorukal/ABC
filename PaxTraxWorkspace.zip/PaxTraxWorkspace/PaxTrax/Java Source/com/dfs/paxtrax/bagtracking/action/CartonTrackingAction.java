package com.dfs.paxtrax.bagtracking.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.CartonTrackingEnquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.CartonTrackingEnquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 *
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	P.C. Sathish	Created
 */
public class CartonTrackingAction extends PaxTraxAction
{

	/**
	 * Gets the list of all the cartons and displays them on the page.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward getCartonList(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::CartonTrackingAction:: getCartonList() :: Begin ");
		String forward = PaxTraxConstants.DISPLAY_CARTON_REPORT_PAGE;
		try
		{
			CartonTrackingEnquiryForm cartonForm =
				(CartonTrackingEnquiryForm) form;
			CartonTrackingEnquiryBean cartonBean =
				new CartonTrackingEnquiryBean();
			cartonForm.setCartonBean(cartonBean);
			HttpSession session = request.getSession();
			BagTrackingReportsDelegate cartonDelegate =
				new BagTrackingReportsDelegate();
			ArrayList cartonList = cartonDelegate.getCartonList();
			cartonForm.setCartons(cartonList);

		}
		catch (PaxTraxSystemException e)
		{
			PaxTraxLog.logError(
				"PaxTrax::CartonTrackingAction:: getCartonList() :: PaxTraxSystemException occured",
				e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::CartonTrackingAction:: getCartonList() :: End ");
		return mapping.findForward(forward);
	}
	/**
		 * Displays the carton details given a carton number.
		 * @param mapping
		 * @param form
		 * @param request
		 * @param response
		 * @return ActionForward
		 * @throws PaxTraxSystemException
		 */
	public ActionForward displayCartonDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::CartonTrackingAction:: displayCartonDetails() :: Begin ");

		String forward = PaxTraxConstants.DISPLAY_CARTON_REPORT_PAGE;
		try
		{
			HttpSession session = request.getSession();
			CartonTrackingEnquiryForm cartonForm =
				(CartonTrackingEnquiryForm) form;
			CartonTrackingEnquiryBean cartonBean = cartonForm.getCartonBean();
			if (cartonBean == null)
			{
				cartonBean = new CartonTrackingEnquiryBean();
			}
			String cartonNumber = request.getParameter("cartonNumber");
			String cartonCycle = request.getParameter("cartonCycle");
			int cycleId = -1;
			if (cartonCycle == null)
			{
				cartonCycle = "-1";
			}
			else
			{
				if (cartonCycle.trim().length() > 0)
				{
					cycleId = Integer.parseInt(cartonCycle);
					request.setAttribute("backButton", "true");
				}
			}

			BagTrackingReportsDelegate cartonDelegate =
				new BagTrackingReportsDelegate();
			CartonTrackingEnquiryBean cartonBean1 = cartonForm.getCartonBean();
			cartonBean1 =
				cartonDelegate.getCartonDetails(cartonNumber, cycleId);
			cartonBean1.setCartonNumber(cartonNumber);
			cartonForm.setCartonBean(cartonBean);
			//int size1 = cartonBean1.getCartonHistoryList().size();
			//int size2 = cartonBean1.getBagStatusList().size();
			cartonForm.setCartonBean(cartonBean1);
			request.setAttribute("generated", "true");
		}
		catch (NumberFormatException e)
		{
			PaxTraxLog.logError(
				"CartonTrackingAction:: displayCartonDetails() : ModuleId is invalid ",
				e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		catch (BagTrackingReportsException btException)
		{
			PaxTraxLog.logDebug(
				"Business Exception in PaxTrax::CartonTrackingAction:: displayCartonDetails() ",
				btException);
			
			request.setAttribute("errorCode", "" + btException.getErrorCode());
			
		}
		catch (Exception e)
		{
			PaxTraxLog.logDebug(
				"PaxTrax::CartonTrackingAction:: displayCartonDetails() :: PaxTraxSystemException occured",
				e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::CartonTrackingAction:: displayCartonDetails() :: End ");
		return mapping.findForward(forward);
	}

	/**
	 * Prints the carton details.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward printCartonDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::CartonTrackingAction:: printCartonDetails() :: Begin ");
		String forward = PaxTraxConstants.PRINT_CARTON_REPORT_PAGE;
		try
		{
			HttpSession session = request.getSession();
			CartonTrackingEnquiryForm cartonForm =
				(CartonTrackingEnquiryForm) form;
			CartonTrackingEnquiryBean cartonBean = cartonForm.getCartonBean();
			//cartonBean = getMoreDetails(cartonBean);
			cartonForm.setCartonBean(cartonBean);
		}
		catch (Exception e)
		{
			PaxTraxLog.logDebug(
				"PaxTrax::CartonTrackingAction:: printCartonDetails() :: PaxTraxSystemException occured",
				e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::CartonTrackingAction:: printCartonDetails() :: End ");
		return mapping.findForward(forward);
	}
}
