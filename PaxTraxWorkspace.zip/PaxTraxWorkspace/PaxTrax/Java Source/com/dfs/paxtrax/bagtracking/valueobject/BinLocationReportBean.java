package com.dfs.paxtrax.bagtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant   - Sankaranarayanan srinivasan
 * DFS                  - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE         USER            COMMENTS
 *  29/07/2004  Joseph Oommen A Created   
 */

public class BinLocationReportBean extends PaxTraxValueObject
{

	private String binStartLocation;
	private String binEndLocation;
	private boolean isAirportBin;
	private String moduleId = null;
	private String pickUpLocationValue;
	private String whBinLocation;
	private String apBinLocation;
	private String pickupLocationId;
	private String cartonCycle = null;
	private String cartonNumber;
	private int totalNumberOfBags;
	private String deliveryDate;
	private String Shift;

	/**
	 * Returns the apBinLocation.
	 * @return String
	 */
	public String getApBinLocation()
	{
		return apBinLocation;
	}

	/**
	 * Returns the binEndLocation.
	 * @return String
	 */
	public String getBinEndLocation()
	{
		return binEndLocation;
	}

	/**
	 * Returns the binStartLocation.
	 * @return String
	 */
	public String getBinStartLocation()
	{
		return binStartLocation;
	}

	/**
	 * Returns the cartonNumber.
	 * @return String
	 */
	public String getCartonNumber()
	{
		return cartonNumber;
	}

	/**
	 * Returns the deliveryDate.
	 * @return String
	 */
	public String getDeliveryDate()
	{
		return deliveryDate;
	}

	/**
	 * Returns the isAirportBin.
	 * @return boolean
	 */
	public boolean getIsAirportBin()
	{
		return isAirportBin;
	}

	/**
	 * Returns the pickupLocationId.
	 * @return String
	 */
	public String getPickupLocationId()
	{
		return pickupLocationId;
	}

	/**
	 * Returns the pickUpLocationValue.
	 * @return String
	 */
	public String getPickUpLocationValue()
	{
		return pickUpLocationValue;
	}

	/**
	 * Returns the shift.
	 * @return String
	 */
	public String getShift()
	{
		return Shift;
	}

	/**
	 * Returns the totalNumberOfBags.
	 * @return int
	 */
	public int getTotalNumberOfBags()
	{
		return totalNumberOfBags;
	}

	/**
	 * Returns the whBinLocation.
	 * @return String
	 */
	public String getWhBinLocation()
	{
		return whBinLocation;
	}

	/**
	 * Sets the apBinLocation.
	 * @param apBinLocation The apBinLocation to set
	 */
	public void setApBinLocation(String apBinLocation)
	{
		this.apBinLocation = apBinLocation;
	}

	/**
	 * Sets the binEndLocation.
	 * @param binEndLocation The binEndLocation to set
	 */
	public void setBinEndLocation(String binEndLocation)
	{
		this.binEndLocation = binEndLocation;
	}

	/**
	 * Sets the binStartLocation.
	 * @param binStartLocation The binStartLocation to set
	 */
	public void setBinStartLocation(String binStartLocation)
	{
		this.binStartLocation = binStartLocation;
	}

	/**
	 * Sets the cartonNumber.
	 * @param cartonNumber The cartonNumber to set
	 */
	public void setCartonNumber(String cartonNumber)
	{
		this.cartonNumber = cartonNumber;
	}

	/**
	 * Sets the deliveryDate.
	 * @param deliveryDate The deliveryDate to set
	 */
	public void setDeliveryDate(String deliveryDate)
	{
		this.deliveryDate = deliveryDate;
	}

	/**
	 * Sets the isAirportBin.
	 * @param isAirportBin The isAirportBin to set
	 */
	public void setIsAirportBin(boolean isAirportBin)
	{
		this.isAirportBin = isAirportBin;
	}

	/**
	 * Sets the pickupLocationId.
	 * @param pickupLocationId The pickupLocationId to set
	 */
	public void setPickupLocationId(String pickupLocationId)
	{
		this.pickupLocationId = pickupLocationId;
	}

	/**
	 * Sets the pickUpLocationValue.
	 * @param pickUpLocationValue The pickUpLocationValue to set
	 */
	public void setPickUpLocationValue(String pickUpLocationValue)
	{
		this.pickUpLocationValue = pickUpLocationValue;
	}

	/**
	 * Sets the shift.
	 * @param shift The shift to set
	 */
	public void setShift(String shift)
	{
		Shift = shift;
	}

	/**
	 * Sets the totalNumberOfBags.
	 * @param totalNumberOfBags The totalNumberOfBags to set
	 */
	public void setTotalNumberOfBags(int totalNumberOfBags)
	{
		this.totalNumberOfBags = totalNumberOfBags;
	}

	/**
	 * Sets the whBinLocation.
	 * @param whBinLocation The whBinLocation to set
	 */
	public void setWhBinLocation(String whBinLocation)
	{
		this.whBinLocation = whBinLocation;
	}

	/**
	 * Returns the moduleId.
	 * @return String
	 */
	public String getModuleId()
	{
		return moduleId;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(String moduleId)
	{
		this.moduleId = moduleId;
	}

	/**
	 * Returns the cartonCycle.
	 * @return String
	 */
	public String getCartonCycle()
	{
		return cartonCycle;
	}

	/**
	 * Returns the isAirportBin.
	 * @return boolean
	 */
	public boolean isAirportBin()
	{
		return isAirportBin;
	}

	/**
	 * Sets the cartonCycle.
	 * @param cartonCycle The cartonCycle to set
	 */
	public void setCartonCycle(String cartonCycle)
	{
		this.cartonCycle = cartonCycle;
	}

}
