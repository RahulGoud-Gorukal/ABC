package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.BagByBagStatusForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagByBagStatusBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for a bag status
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Jaganmohan Gopinath
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 05/30/2007    Uma		Created
*/

public class BagByBagStatusAction extends PaxTraxAction
{
	String forward = null;
	/**
	 * Loads the report page by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in creating the Bag Status Report Page
	 */
	public ActionForward goToBagByBagStatusReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::goToBagByBagStatusReport::Begin");
		
		ArrayList bagStatus = new ArrayList();
		BagByBagStatusForm bagByBagStatusForm = (BagByBagStatusForm) form;
		BagByBagStatusBean bagByBagStatusBean = new BagByBagStatusBean();
		BagTrackingReportsDelegate reportsDelegate = new BagTrackingReportsDelegate();
		
		try
		{
			bagStatus =	reportsDelegate.loadBagStatus(PaxTraxConstants.BAG_CODE);
			Calendar cal = Calendar.getInstance();
			int day = cal.get(Calendar.DATE);
			int month = cal.get(Calendar.MONTH) + 1;
			int year = cal.get(Calendar.YEAR);
			
			String currentDate = "";
			currentDate = "" + year + "/" + (month<10 ? "0" + month : "" + month) + "/" + (day<10 ? "0" + day : "" + day);
			bagByBagStatusBean.setDepartureDate(currentDate); 
			bagByBagStatusForm.setBagByBagStatusBean(bagByBagStatusBean);
			bagByBagStatusForm.setBagStatusList(bagStatus);
			forward = PaxTraxConstants.BAG_BY_BAG_STATUS;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug("PaxTrax::BagByBagStatusAction::goToBagByBagStatusReport",paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		
		PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::goToBagByBagStatusReport::End");
		return mapping.findForward(forward);
	}
	
	/**
	 * Retrieves the list of bag status by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in retrieving bag status details
	 */
	public ActionForward getBagByBagStatusReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::Begin");
		
		int pageNumber = 0 ;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		HttpSession session = request.getSession();
		BagByBagStatusForm bagByBagStatusForm = (BagByBagStatusForm) form;
		BagByBagStatusBean bagByBagStatusBean = bagByBagStatusForm.getBagByBagStatusBean();
		BagTrackingReportsDelegate bagStatusDelegate = new BagTrackingReportsDelegate();
		
		try
		{
			String pageNumberStr = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::pageNumber"+pageNumberStr);
			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr = ((pageNumberStr == null) || pageNumberStr.equals(SQLConstants.BLANK))
																			? null : pageNumberStr;
			if ((pageNumberStr != null))
			{
				pageNumber = Integer.parseInt(pageNumberStr);
			}
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */

			if (pageNumber == 0)
			{
				PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::insideif");
				int size = 0;
				int bagSize = 0;
				pageNumber = 1;
				
				bagByBagStatusBean = bagStatusDelegate.getBagByBagStatusReport(bagByBagStatusBean);
				if ((bagByBagStatusBean.getBagsList() == null) || (bagByBagStatusBean.getBagsList().size() == 0))
				{
					request.setAttribute(PaxTraxConstants.ERROR_CODE,PaxTraxConstants.ERROR_CODE);
					bagByBagStatusBean.setTotalBags(null);
				}
				else
				{
					bagSize = bagByBagStatusBean.getBagsList().size();
					bagByBagStatusBean.setTotalBags(String.valueOf(bagSize));
				}
				allRecords = bagByBagStatusBean.getBagsList();
				if (allRecords != null)
				{
					size = allRecords.size();
				}
				PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::sizeofRecords"+ allRecords.size());

				session.removeAttribute(PaxTraxConstants.ALL_BAG_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_BAG_RECORDS,allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_BAG_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_BAG_RECORDS,Integer.toString(size));
			}			
			else
			{
				allRecords = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_BAG_RECORDS);
			}
			
			PaginationHelper helper = PaginationHelper.getInstance();
			if ((allRecords != null) && (allRecords.size() != 0))
			{
				currentRecords = helper.getCurrentTableContent(allRecords,pageNumber,PaxTraxConstants.RECORDS_PER_PAGE);
				request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
				PaxTraxLog.logDebug(
							"Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::current records size is" + currentRecords.size());
			}
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
			bagByBagStatusBean.setBagsList(currentRecords);
			
			bagByBagStatusForm.setBagByBagStatusBean(bagByBagStatusBean);
			forward = PaxTraxConstants.BAG_BY_BAG_STATUS;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug("PaxTrax::BagByBagStatusAction::getBagByBagStatusReport",paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
																						
		PaxTraxLog.logDebug("Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::End");
		return mapping.findForward(forward);
	}	


	/**
	 * Prints the list of bag status by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in printing the bag status details
	 */	
	public ActionForward printBagByBagStatus(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug("PaxTrax::BagByBagStatusAction::printBagByBagStatus::Begin");
			ArrayList allRecords = new ArrayList();
			HttpSession session = request.getSession();
			BagByBagStatusForm bagByBagStatusForm = (BagByBagStatusForm) form;
			BagByBagStatusBean bagByBagStatusBean = bagByBagStatusForm.getBagByBagStatusBean();
			
			allRecords = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_BAG_RECORDS);
			bagByBagStatusBean.setBagsList(allRecords);
			bagByBagStatusForm.setBagByBagStatusBean(bagByBagStatusBean);
			
			ArrayList bagStatusList = bagByBagStatusForm.getBagStatusList();
			String bagStatus = bagByBagStatusForm.getBagByBagStatusBean().getBagCode();
			for (int i = 0; i < bagStatusList.size(); i++)
			{
				ReferenceDataBean tempBean = (ReferenceDataBean) bagStatusList.get(i);
				if (bagStatus.equals(tempBean.getCodeId()))
				{
					bagByBagStatusForm.getBagByBagStatusBean().setBagCodeValue(tempBean.getCodeValue());
					break;
				}
			}

			PaxTraxLog.logDebug("PaxTrax::BagByBagStatusAction::printBagByBagStatus::End");
			forward = PaxTraxConstants.PRINT_BAG_STATUS_REPORT;
		}
		catch (Exception ex)
		{

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}	
}