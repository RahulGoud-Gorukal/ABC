package com.dfs.paxtrax.bagtracking.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.PicklistSearchBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public interface GeneratePicklistBO extends javax.ejb.EJBObject
{
	public ArrayList getPicklist(PicklistSearchBean picklistSearchBean) throws PaxTraxSystemException,RemoteException;
}
