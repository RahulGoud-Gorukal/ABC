package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;

/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class BagTrackingReportsForm extends PaxTraxActionForm {
	private String bagNumber = null;
	private String airlineCode = null;
	private String flightNumber = null;
	private String departureDate = null;
	private String cartonNumber = null;
	private String fromBinLocation = null;
	private String toBinLocation = null;
	private String cageNumber = null;
	private String truckNumber = null;
	private String paxNumber = null;
	private String itemNumber = null;
	private String pickupLocation = null;
	private String skuTransferDate = null;
	private ArrayList listOfReports = null;
	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

	private boolean isInternational = false;
	private boolean isPreorder = false;
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

	/**
	 * Returns the airlineCode.
	 * @return String
	 */
	public String getAirlineCode() {
		return airlineCode;
	}

	/**
	 * Returns the bagNumber.
	 * @return String
	 */
	public String getBagNumber() {
		return bagNumber;
	}

	/**
	 * Returns the cageNumber.
	 * @return String
	 */
	public String getCageNumber() {
		return cageNumber;
	}

	/**
	 * Returns the cartonNumber.
	 * @return String
	 */
	public String getCartonNumber() {
		return cartonNumber;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * Returns the fromBinLocation.
	 * @return String
	 */
	public String getFromBinLocation() {
		return fromBinLocation;
	}

	/**
	 * Returns the itemNumber.
	 * @return String
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * Returns the paxNumber.
	 * @return String
	 */
	public String getPaxNumber() {
		return paxNumber;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation() {
		return pickupLocation;
	}

	/**
	 * Returns the toBinLocation.
	 * @return String
	 */
	public String getToBinLocation() {
		return toBinLocation;
	}

	/**
	 * Returns the truckNumber.
	 * @return String
	 */
	public String getTruckNumber() {
		return truckNumber;
	}

	/**
	 * Sets the airlineCode.
	 * @param airlineCode The airlineCode to set
	 */
	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	/**
	 * Sets the bagNumber.
	 * @param bagNumber The bagNumber to set
	 */
	public void setBagNumber(String bagNumber) {
		this.bagNumber = bagNumber;
	}

	/**
	 * Sets the cageNumber.
	 * @param cageNumber The cageNumber to set
	 */
	public void setCageNumber(String cageNumber) {
		this.cageNumber = cageNumber;
	}

	/**
	 * Sets the cartonNumber.
	 * @param cartonNumber The cartonNumber to set
	 */
	public void setCartonNumber(String cartonNumber) {
		this.cartonNumber = cartonNumber;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the fromBinLocation.
	 * @param fromBinLocation The fromBinLocation to set
	 */
	public void setFromBinLocation(String fromBinLocation) {
		this.fromBinLocation = fromBinLocation;
	}

	/**
	 * Sets the itemNumber.
	 * @param itemNumber The itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * Sets the paxNumber.
	 * @param paxNumber The paxNumber to set
	 */
	public void setPaxNumber(String paxNumber) {
		this.paxNumber = paxNumber;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Sets the toBinLocation.
	 * @param toBinLocation The toBinLocation to set
	 */
	public void setToBinLocation(String toBinLocation) {
		this.toBinLocation = toBinLocation;
	}

	/**
	 * Sets the truckNumber.
	 * @param truckNumber The truckNumber to set
	 */
	public void setTruckNumber(String truckNumber) {
		this.truckNumber = truckNumber;
	}

	/**
	 * Returns the listOfReports.
	 * @return ArrayList
	 */
	public ArrayList getListOfReports() {
		return listOfReports;
	}

	/**
	 * Sets the listOfReports.
	 * @param listOfReports The listOfReports to set
	 */
	public void setListOfReports(ArrayList listOfReports) {
		this.listOfReports = listOfReports;
	}

	/**
	 * Returns the skuTransferDate.
	 * @return String
	 */
	public String getSkuTransferDate() {
		return skuTransferDate;
	}

	/**
	 * Sets the skuTransferDate.
	 * @param skuTransferDate The skuTransferDate to set
	 */
	public void setSkuTransferDate(String skuTransferDate) {
		this.skuTransferDate = skuTransferDate;
	}

	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

	/**
	 * @return
	 */
	public boolean getIsInternational() {
		return isInternational;
	}

	/**
	 * @param b
	 */
	public void setIsInternational(boolean b) {

		isInternational = b;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request) 
	{
		isInternational = false;
		isPreorder = false;
	}
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

	/**
	 * @return
	 */
	public boolean getIsPreorder()
	{
		return isPreorder;
	}

	/**
	 * @param b
	 */
	public void setIsPreorder(boolean b)
	{
		isPreorder = b;
	}

}
