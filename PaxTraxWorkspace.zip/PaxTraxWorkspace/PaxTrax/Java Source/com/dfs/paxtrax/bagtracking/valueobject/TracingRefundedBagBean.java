package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.HashMap;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * 
 * This Class contains tracing Refunded Bags related attributes
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Jaganmohan Gopinath
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/07/2007	Vijay			Created   
 */

public class TracingRefundedBagBean extends PaxTraxValueObject {

	private String refundedDate = null;
	private String international = "N";
	private String preOrder = "N";
	private String bagNo = null;
	private String bagStatus = null;
	private String showCheckBox="N";
	private ArrayList skuList = null;
	

	public TracingRefundedBagBean() {
	}
	/**
	 * @return
	 */
	public String getBagNo() {
		return bagNo;
	}

	/**
	 * @return
	 */
	public String getBagStatus() {
		return bagStatus;
	}

	/**
	 * @return
	 */
	public String getRefundedDate() {
		return refundedDate;
	}

	

	/**
	 * @param string
	 */
	public void setBagNo(String string) {
		bagNo = string;
	}

	/**
	 * @param string
	 */
	public void setBagStatus(String string) {
		bagStatus = string;
	}

	/**
	 * @param string
	 */
	public void setRefundedDate(String string) {
		refundedDate = string;
	}

	
	/**
	 * @return
	 */
	public String getInternational() {
		return international;
	}

	/**
	 * @return
	 */
	public String getPreOrder() {
		return preOrder;
	}

	/**
	 * @param string
	 */
	public void setInternational(String string) {
		international = string;
	}

	/**
	 * @param string
	 */
	public void setPreOrder(String string) {
		preOrder = string;
	}

	/**
	 * @return
	 */
	public String getShowCheckBox() {
		return showCheckBox;
	}

	/**
	 * @param string
	 */
	public void setShowCheckBox(String string) {
		showCheckBox = string;
	}

	/**
	 * @return
	 */
	public ArrayList getSkuList() {
		return skuList;
	}

	/**
	 * @param list
	 */
	public void setSkuList(ArrayList list) {
		skuList = list;
	}

}
