package com.dfs.paxtrax.bagtracking.action;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.BinLocEnquiryForm;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationBean;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationReportBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 24/06/2004	Cyril Prince.J	Created   
 */

public class BinLocEnquiryAction extends PaxTraxAction
{

	/**
	 * Method getBinLocReportPage.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getBinLocReportPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		BinLocationReportBean binLocationReportBean = null;
		boolean airportBin = false;
		BinLocEnquiryForm binLocEnquiryForm = (BinLocEnquiryForm) form;
		binLocationReportBean = binLocEnquiryForm.getBinLocationReportBean();
		
		if (binLocationReportBean != null)
		{
			airportBin = binLocationReportBean.getIsAirportBin();
		}
		else
		{
			binLocationReportBean = new BinLocationReportBean();
		}
		binLocationReportBean.setBinStartLocation(null);
		binLocationReportBean.setBinEndLocation(null);
		
		binLocationReportBean.setIsAirportBin(airportBin);
		ArrayList locations = new ArrayList();
		BagTrackingReportsDelegate del = new BagTrackingReportsDelegate();

		try
		{
			if (airportBin)
			{
				locations = del.getAllBinLocations("A");
			}
			else
			{
				locations = del.getAllBinLocations("W");
			}

		}
		catch (PaxTraxSystemException e)
		{
			PaxTraxLog.logError(
				"BinLocEnquiryAction:getBinLocReportPage() - Error",
				e);
		}

		binLocEnquiryForm.setBinLocFromList(locations);
		binLocEnquiryForm.setBinLocToList(locations);
		binLocEnquiryForm.setBinLocationReportBean(binLocationReportBean);
		//Commented on May 3, 2005 as a aprt of the cleanup of unnecessary log statements	
		//PaxTraxLog.logFatal(
		//	"BinLocEnquiryAction:getBinLocReportPage() - forwarding to jsp..");
		return mapping.findForward("binLocReport");

	}

	/**
	 * Method getBinLocReport.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getBinLocReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		BinLocEnquiryForm binLocEnquiryForm = (BinLocEnquiryForm) form;
		BinLocationReportBean binLocationReportBean =
			binLocEnquiryForm.getBinLocationReportBean();
		ArrayList fromBinLoc = binLocEnquiryForm.getBinLocFromList();
		ArrayList toBinLoc = binLocEnquiryForm.getBinLocToList();
		ArrayList combinedList = new ArrayList();
		BagTrackingReportsDelegate reportsDelegate =
			new BagTrackingReportsDelegate();
		/*StringTokenizer binStartTokenizer =
			new StringTokenizer(
				binLocationReportBean.getBinStartLocation(),
				"~");
		StringTokenizer binEndTokenizer =
			new StringTokenizer(binLocationReportBean.getBinEndLocation(), "~");
		String binStartId = null,
			binStartvalue = null,
			binEndId = null,
			binEndvalue = null;
		while (binStartTokenizer.hasMoreTokens())
		{
			binStartId = (String) binStartTokenizer.nextToken();
			binStartvalue = (String) binStartTokenizer.nextToken();
		}
		while (binEndTokenizer.hasMoreTokens())
		{
			binEndId = (String) binEndTokenizer.nextToken();
			binEndvalue = (String) binEndTokenizer.nextToken();
		}*/

		int fromBinLocSize = 0, toBinLocSize = 0;
		if (fromBinLoc != null)
		{
			fromBinLocSize = fromBinLoc.size();
		}
		if (toBinLoc != null)
		{
			toBinLocSize = toBinLoc.size();
		}
		int startId =
			Integer.parseInt(binLocationReportBean.getBinStartLocation());

		int endId = Integer.parseInt(binLocationReportBean.getBinEndLocation());

		if (startId == endId)
		{
			if (startId == -1)
			{
				for (int i = 0; i < fromBinLocSize; i++)
				{
					ReferenceDataBean referenceDataBean =
						(ReferenceDataBean) fromBinLoc.get(i);
					if (!combinedList
						.contains(referenceDataBean.getCodeValue()))
					{
						combinedList.add(referenceDataBean.getCodeValue());
					}
				}

			}
			else
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) fromBinLoc.get(startId);
				if (!combinedList.contains(referenceDataBean.getCodeValue()))
				{
					combinedList.add(referenceDataBean.getCodeValue());
				}
			}
		}
		else
			if (startId == -1 && endId != -1)
			{

				for (int j = 0; j <= endId; j++)
				{
					ReferenceDataBean referenceDataBean =
						(ReferenceDataBean) toBinLoc.get(j);
					if (!combinedList
						.contains(referenceDataBean.getCodeValue()))
					{
						combinedList.add(referenceDataBean.getCodeValue());
					}
				}
			}
			else
				if (startId != -1 && endId == -1)
				{

					for (int i = startId; i < fromBinLocSize; i++)
					{
						ReferenceDataBean referenceDataBean =
							(ReferenceDataBean) fromBinLoc.get(i);
						if (!combinedList
							.contains(referenceDataBean.getCodeValue()))
						{
							combinedList.add(referenceDataBean.getCodeValue());
						}
					}

				}
				else
				{

					for (int i = startId; i <= endId; i++)
					{
						ReferenceDataBean referenceDataBean =
							(ReferenceDataBean) fromBinLoc.get(i);

						if (!combinedList
							.contains(referenceDataBean.getCodeValue()))
						{
							combinedList.add(referenceDataBean.getCodeValue());
						}
					}

					/*for (int j = 0; j < endId; j++)
					{
						ReferenceDataBean referenceDataBean =
							(ReferenceDataBean) toBinLoc.get(j);
						if (!combinedList
							.contains(referenceDataBean.getCodeValue()))
						{
							combinedList.add(referenceDataBean.getCodeValue());
						}
					}*/
				}


		try
		{
			ArrayList reportList =
				reportsDelegate.getBinLocEnquiryReport(
					binLocationReportBean,
					combinedList);
			forward = "binLocReport";
			if (reportList == null || reportList.size() == 0)
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.LOCATION_ERROR,
					new ActionMessage(
						""
							+ PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.ERRORCODE,
					"" + PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND);
			}
			else
			{

				binLocEnquiryForm.setBinLocResultList(reportList);
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);

			}

		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);

	}

	public ActionForward printBinLocationInquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BinLocEnquiryAction::printBinLocationInquiry::Begin");
			BinLocEnquiryForm binLocEnquiryForm = (BinLocEnquiryForm) form;
			BinLocationReportBean newBean = new BinLocationReportBean();
			BinLocationReportBean reportBean =
				binLocEnquiryForm.getBinLocationReportBean();
			String fromWhBin = reportBean.getBinStartLocation();
			newBean.setBinStartLocation(fromWhBin);
			String endWhBin = reportBean.getBinEndLocation();
			newBean.setBinEndLocation(endWhBin);
			ArrayList resultList = binLocEnquiryForm.getBinLocToList();
			if (reportBean.getIsAirportBin())
			{
				newBean.setApBinLocation("Airport");

			}
			else
			{
				newBean.setApBinLocation("Warehouse");
			}
			if (fromWhBin.equals("-1"))
			{
				binLocEnquiryForm.setStartLocation("-");

			}
			else
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) resultList.get(
						Integer.parseInt(fromWhBin));
				binLocEnquiryForm.setStartLocation(
					referenceDataBean.getCodeValue());
			}

			if (endWhBin.equals("-1"))
			{

				binLocEnquiryForm.setEndLocation("-");
			}
			else
			{
				ReferenceDataBean referenceDataBean =
					(ReferenceDataBean) resultList.get(
						Integer.parseInt(endWhBin));
				binLocEnquiryForm.setEndLocation(
					referenceDataBean.getCodeValue());
			}

			String operation = request.getParameter(PaxTraxConstants.OPERATION);
			if (operation != null
				&& !operation.equals("")
				&& !operation.equals("null"))
			{
				operation = operation.trim();
				request.setAttribute(PaxTraxConstants.OPERATION, operation);

			}
			binLocEnquiryForm.setBinLocationReportBean(newBean);
			PaxTraxLog.logDebug(
				"PaxTrax::BinLocEnquiryAction::printBinLocationInquiry::End");
			forward = "printBinLocReport";
		}
		catch (Exception ex)
		{
			ex.printStackTrace();

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}

}
