package com.dfs.paxtrax.bagtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 24/06/2004	Cyril Prince.J	Created   
 */

public class BinLocEnquiryResultBean extends PaxTraxValueObject {
	private String binLocation;
	private String pickupLocation;
	private String cartonNumber;
	private int totalNumberOfBags;
	private String deliveryDate;
	private String Shift;
	
	/**
	 * Returns the binLocation.
	 * @return String
	 */
	public String getBinLocation() {
		return binLocation;
	}

	/**
	 * Returns the cartonNumber.
	 * @return String
	 */
	public String getCartonNumber() {
		return cartonNumber;
	}

	/**
	 * Returns the deliveryDate.
	 * @return String
	 */
	public String getDeliveryDate() {
		return deliveryDate;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation() {
		return pickupLocation;
	}

	/**
	 * Returns the shift.
	 * @return String
	 */
	public String getShift() {
		return Shift;
	}

	/**
	 * Returns the totalNumberOfBags.
	 * @return int
	 */
	public int getTotalNumberOfBags() {
		return totalNumberOfBags;
	}

	/**
	 * Sets the binLocation.
	 * @param binLocation The binLocation to set
	 */
	public void setBinLocation(String binLocation) {
		this.binLocation = binLocation;
	}

	/**
	 * Sets the cartonNumber.
	 * @param cartonNumber The cartonNumber to set
	 */
	public void setCartonNumber(String cartonNumber) {
		this.cartonNumber = cartonNumber;
	}

	/**
	 * Sets the deliveryDate.
	 * @param deliveryDate The deliveryDate to set
	 */
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Sets the shift.
	 * @param shift The shift to set
	 */
	public void setShift(String shift) {
		Shift = shift;
	}

	/**
	 * Sets the totalNumberOfBags.
	 * @param totalNumberOfBags The totalNumberOfBags to set
	 */
	public void setTotalNumberOfBags(int totalNumberOfBags) {
		this.totalNumberOfBags = totalNumberOfBags;
	}

}
