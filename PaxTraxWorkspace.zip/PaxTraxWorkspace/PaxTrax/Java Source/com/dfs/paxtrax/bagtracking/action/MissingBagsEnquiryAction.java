package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.MissingBagsEnquiryForm;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.MissingBagsEnquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for a flight number
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER           		 COMMENTS
* 26/11/2004    Joseph Oommen A		 Created
*/

public class MissingBagsEnquiryAction extends PaxTraxAction
{

	public ActionForward bagsMissingByFlight(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::bagsMissingByFlight::Begin");
		String forward = null;

		MissingBagsEnquiryForm missingBagsEnquiryForm = (MissingBagsEnquiryForm) form;
		ArrayList statusList = new ArrayList();
		String arr[] = { "All", "Misssing", "Found" };
		for (int i = 0; i < 3; i++)
		{
			ReferenceDataBean referenceDataBean = new ReferenceDataBean();
			referenceDataBean.setCodeId("" + i);
			referenceDataBean.setCodeValue(arr[i]);
			statusList.add(referenceDataBean);
		}
		missingBagsEnquiryForm.setStatusList(statusList);
		MissingBagsEnquiryBean missingBagsEnquiryBean = new MissingBagsEnquiryBean();
		missingBagsEnquiryForm.setMissingBagsEnquiryBean(missingBagsEnquiryBean);
		PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::bagsMissingByFlight::End");
		return mapping.findForward("bagsMissingByFlight");
	}

	public ActionForward getMissingBagDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::getMissingBagDetails::Begin");

			MissingBagsEnquiryForm missingBagsEnquiryForm = (MissingBagsEnquiryForm) form;
			MissingBagsEnquiryBean missingBagsEnquiryBean = missingBagsEnquiryForm.getMissingBagsEnquiryBean();
			BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
			ArrayList missingBagsList = null;

			missingBagsList = bagTrackingReportsDelegate.getMissingBagDetails(missingBagsEnquiryBean);
			missingBagsEnquiryForm.setMissingBagsList(missingBagsList);
			PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::getMissingBagDetails::missingBagsList ->" + missingBagsList.size());
			if (missingBagsList != null && missingBagsList.size() < 1)
			{

				request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.NO_RECORDS_FOUND);
			}
			forward = "bagsMissingByFlight";
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);

		}
		catch (Exception exception)
		{
			PaxTraxLog.logError("PaxTrax::MissingBagsEnquiryAction::getMissingBagDetails" + exception);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::getMissingBagDetails::End");
		return mapping.findForward(forward);
	}

	public ActionForward saveMissingBagDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::saveMissingBagDetails::Begin");
		String forward = "";
		try
		{
			ArrayList missingBagsList = null;

			BagTrackingReportsDelegate bagTrackingReportsDelegate = new BagTrackingReportsDelegate();
			MissingBagsEnquiryForm missingBagsEnquiryForm = (MissingBagsEnquiryForm) form;
			MissingBagsEnquiryBean missingBagsEnquiryBean = missingBagsEnquiryForm.getMissingBagsEnquiryBean();

			HttpSession session = request.getSession();
			missingBagsList = missingBagsEnquiryForm.getMissingBagsList();
			String position = request.getParameter("index");

			int index = 0;
			if (position != null)
			{
				index = Integer.parseInt(position);
			}

			MissingBagsEnquiryBean tempBean = (MissingBagsEnquiryBean) missingBagsList.get(index);
			tempBean.setClientMachine(request.getRemoteHost());
			tempBean.setUser((String) session.getAttribute(PaxTraxConstants.USER_ID));
			ArrayList saveBagsList = new ArrayList();
			saveBagsList.add(tempBean);
			bagTrackingReportsDelegate.saveMissingBagDetails(saveBagsList);
			missingBagsList = bagTrackingReportsDelegate.getMissingBagDetails(missingBagsEnquiryBean);
			missingBagsEnquiryForm.setMissingBagsList(missingBagsList);
			forward = "bagsMissingByFlight";
			request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
		}
		catch (Exception e)
		{
			PaxTraxLog.logError("PaxTrax::MissingBagsEnquiryAction::saveMissingBagDetails " + e);
			forward = PaxTraxConstants.REPORT_ERROR;
		}

		PaxTraxLog.logDebug("PaxTrax::MissingBagsEnquiryAction::saveMissingBagDetails::End");
		return mapping.findForward(forward);
	}
}