package com.dfs.paxtrax.bagtracking.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.BinLocationBO;
import com.dfs.paxtrax.bagtracking.business.BinLocationBOHome;
import com.dfs.paxtrax.bagtracking.exception.BinLocationException;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * The delegate class that is used to delegate the control to the 
 * correct Business object.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 27/05/2004	Yuvarani    	Created   
 */

public class BinLocationDelegate {
    
    //Holds Bin Location BO Home
    BinLocationBOHome home = null;
    
    //Holds Bin Location Remote variable
    BinLocationBO remote = null;
    
    //Holds service locator
    ServiceLocator locator = null;
    
    //Constructor for this class
    public BinLocationDelegate() {
    }
    
	/**
	 * Method jndiCall.
	 * @throws PaxTraxSystemException
	 */
	private void jndiCall() throws PaxTraxSystemException
    {
    	locator = ServiceLocator.getInstance();
    	try
    	{
    	Object object = locator.getEJBHome(PaxTraxConstants.BIN_LOCATION_BO_HOME_JNDI);
    	home = (BinLocationBOHome)PortableRemoteObject.narrow(
    										object,BinLocationBOHome.class);
    	}
    	catch (NamingException namingException)	
    	{
    		throw new PaxTraxSystemException(namingException);
    	}
		if (home == null)
		{
			throw new PaxTraxSystemException(PaxTraxConstants.BIN_LOCATION_HOME_NOT_FOUND);

		}
		try
		{
			remote = home.create();
		}
		catch (RemoteException remoteException)
		{
			throw new PaxTraxSystemException(remoteException);
		}
		catch (CreateException createException) 
		{
			throw new PaxTraxSystemException(createException);
		}
    	
    }

	/**
	 * Saves bin location details in the database
	 * @param binLocationBean BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in saving
	 */
    public void saveBinLocationDetails(BinLocationBean binLocationBean)
    	throws PaxTraxSystemException,BinLocationException
    {
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::saveBinLocationDetails::Begin");
    	if (home == null)
    	{
    		jndiCall();
    	}
    	try
    	{
    		remote.saveBinLocationDetails(binLocationBean);
    	}
    	catch (RemoteException remoteException)
    	{
    		throw new PaxTraxSystemException(remoteException);
    	} 
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::saveBinLocationDetails::End");

    }

	/**
	 * Gets BinLocationDetails from the database.
	 * @param binBean BinLocationBean
	 * @return BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in retriving data
	 * @throws BinLocationException if the location does not exist
	 */
	public BinLocationBean getBinLocationDetails(BinLocationBean binBean)
		throws PaxTraxSystemException,BinLocationException
	{
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::getBinLocationDetails::Begin");
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			binBean = remote.getBinLocationDetails(binBean);
		}
		catch (RemoteException remoteException) 
		{
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::getBinLocationDetails::End");
		return binBean;
	}
	
	/**
	 * Updates bin location details in the database
	 * @param binLocationBean BinLocationBean 
	 * @throws PaxTraxSystemException if there is any problem in updation
	 * @throws BinLocationException
	 */
    public void updateBinLocationDetails(BinLocationBean binLocationBean) 
    	throws PaxTraxSystemException,BinLocationException
    {
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::updateBinLocationDetails::Begin");
    	if (home == null)
    	{
    		jndiCall();
    	}
    	try
    	{
    		remote.updateBinLocationDetails(binLocationBean);
    	}
    	catch (RemoteException remoteException)
    	{
    		throw new PaxTraxSystemException(remoteException);
    	} 
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::updateBinLocationDetails::End");
    }
    
	/**
	 * Removes BinLocationDetails from the database.
	 * @param binLocationBean BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in deletion
	 */
    public void removeBinLocationDetails(BinLocationBean binLocationBean) 
    	throws PaxTraxSystemException,BinLocationException
    {
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::removeBinLocationDetails::Begin");
    	if (home == null)
    	{
    		jndiCall();
    	}
    	try
    	{
    		remote.removeBinLocationDetails(binLocationBean);
    	}
    	catch (RemoteException remoteException)
    	{
    		throw new PaxTraxSystemException(remoteException);
    	} 
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::removeBinLocationDetails::End");
    	
    }
    
	/**
	 * This method searches for bin location that satisfies the given criteria
	 * @param binLocationBean BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem while searching
	 */
    public ArrayList searchBinLocationDetails(BinLocationBean binLocationBean) 
    	throws PaxTraxSystemException
    {
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::searchBinLocationDetails::Begin");
    	ArrayList binLocationDetails = null;
    	if (home == null)
    	{
    		jndiCall();
    	}
    	try
    	{
    		binLocationDetails = remote.searchBinLocationDetails(binLocationBean);
    	}
    	catch (RemoteException remoteException)
    	{
    		throw new PaxTraxSystemException(remoteException);
    	} 
    			
		PaxTraxLog.logDebug("PaxTrax::BinLocationDelegate::searchBinLocationDetails::End");
    		return binLocationDetails;
    }
}
