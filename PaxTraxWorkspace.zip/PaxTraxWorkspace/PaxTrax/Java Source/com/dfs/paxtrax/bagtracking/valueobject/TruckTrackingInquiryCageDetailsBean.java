package com.dfs.paxtrax.bagtracking.valueobject;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Truck attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 01/06/2004   Sundarrajan.K.	Created   
*/

public class TruckTrackingInquiryCageDetailsBean extends PaxTraxValueObject
{
	private String pickupLocation;
	
	private String cageNumber;
	
	private String shift;
	
	private String departureDate;
	
	private int totalNoOfCartons;
	
	private String openDateTime;
	
	private String closeDateTime;
	
	private String moduleId;
	
	private int totalNoOfCages;
	
	private String cageCycleId =null;
	
	/**
	 * Returns the cageNumber.
	 * @return String
	 */
	public String getCageNumber()
	{
		return cageNumber;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Returns the shift.
	 * @return String
	 */
	public String getShift()
	{
		return shift;
	}

	/**
	 * Returns the totalNoOfCartons.
	 * @return String
	 */
	public int getTotalNoOfCartons()
	{
		return totalNoOfCartons;
	}

	/**
	 * Sets the cageNumber.
	 * @param cageNumber The cageNumber to set
	 */
	public void setCageNumber(String cageNumber)
	{
		this.cageNumber = cageNumber;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Sets the shift.
	 * @param shift The shift to set
	 */
	public void setShift(String shift)
	{
		this.shift = shift;
	}

	/**
	 * Sets the totalNoOfCartons.
	 * @param totalNoOfCartons The totalNoOfCartons to set
	 */
	public void setTotalNoOfCartons(int totalNoOfCartons)
	{
		this.totalNoOfCartons = totalNoOfCartons;
	}

	/**
	 * Returns the closeDateTime.
	 * @return String
	 */
	public String getCloseDateTime()
	{
		return closeDateTime;
	}

	/**
	 * Returns the openDateTime.
	 * @return String
	 */
	public String getOpenDateTime()
	{
		return openDateTime;
	}

	/**
	 * Sets the closeDateTime.
	 * @param closeDateTime The closeDateTime to set
	 */
	public void setCloseDateTime(String closeDateTime)
	{
		this.closeDateTime = closeDateTime;
	}

	/**
	 * Sets the openDateTime.
	 * @param openDateTime The openDateTime to set
	 */
	public void setOpenDateTime(String openDateTime)
	{
		this.openDateTime = openDateTime;
	}

	/**
	 * Returns the moduleId.
	 * @return String
	 */
	public String getModuleId()
	{
		return moduleId;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(String moduleId)
	{
		this.moduleId = moduleId;
	}

	/**
	 * Returns the totalNoOfCages.
	 * @return String
	 */
	public int getTotalNoOfCages()
	{
		return totalNoOfCages;
	}

	/**
	 * Sets the totalNoOfCages.
	 * @param totalNoOfCages The totalNoOfCages to set
	 */
	public void setTotalNoOfCages(int totalNoOfCages)
	{
		this.totalNoOfCages = totalNoOfCages;
	}

	/**
	 * Returns the cageCycleId.
	 * @return String
	 */
	public String getCageCycleId()
	{
		return cageCycleId;
	}

	/**
	 * Sets the cageCycleId.
	 * @param cageCycleId The cageCycleId to set
	 */
	public void setCageCycleId(String cageCycleId)
	{
		this.cageCycleId = cageCycleId;
	}

}