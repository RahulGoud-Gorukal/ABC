package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.ItemTrackingInquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains item 
 *  attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 28/06/2004   Joseph Oommen A     Created   
*/

public class ItemTrackingInquiryForm extends PaxTraxActionForm
{
	
    private  ItemTrackingInquiryBean itemTrackingInquiryBean=null;
    
    private ArrayList itemList =null;

	
	
	/**
	 * Returns the itemTrackingInquiryBean.
	 * @return ItemTrackingInquiryBean
	 */
	public ItemTrackingInquiryBean getItemTrackingInquiryBean()
	{
		return itemTrackingInquiryBean;
	}

	/**
	 * Sets the itemTrackingInquiryBean.
	 * @param itemTrackingInquiryBean The itemTrackingInquiryBean to set
	 */
	public void setItemTrackingInquiryBean(ItemTrackingInquiryBean itemTrackingInquiryBean)
	{
		this.itemTrackingInquiryBean = itemTrackingInquiryBean;
	}

	/**
	 * Returns the itemList.
	 * @return ArrayList
	 */
	public ArrayList getItemList()
	{
		return itemList;
	}

	/**
	 * Sets the itemList.
	 * @param itemList The itemList to set
	 */
	public void setItemList(ArrayList itemList)
	{
		this.itemList = itemList;
	}

}
