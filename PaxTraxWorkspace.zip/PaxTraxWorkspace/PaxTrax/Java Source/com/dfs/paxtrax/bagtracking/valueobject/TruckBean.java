package com.dfs.paxtrax.bagtracking.valueobject;


/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
* This is valueobject class which contains Truck attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 02/06/2004    Yuvarani		Created   
*/

public class TruckBean extends PaxTraxValueObject {

    // The truck number of the truck
    private String number = null;

    // The model of the truck
    private String model = null;

    // The manufacturer of the truck
    private String manufacturer = null;

    // The year of manufacturing of the truck
    private String year = null;

    //  The make of the truck
    private String make = null;

    // The remarks on the truck
    private String remarks = null;
    
	//Holds current status of the truck
	private String currentStatus = null;
	
	/**
	 * Returns the make.
	 * @return String
	 */
	public String getMake()
	{
		return make;
	}

	/**
	 * Returns the manufacturer.
	 * @return String
	 */
	public String getManufacturer()
	{
		return manufacturer;
	}

	/**
	 * Returns the model.
	 * @return String
	 */
	public String getModel()
	{
		return model;
	}

	/**
	 * Returns the number.
	 * @return String
	 */
	public String getNumber()
	{
		return number;
	}

	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getRemarks()
	{
		return remarks;
	}

	/**
	 * Returns the year.
	 * @return String
	 */
	public String getYear()
	{
		return year;
	}

	/**
	 * Sets the make.
	 * @param make The make to set
	 */
	public void setMake(String make)
	{
		this.make = make;
	}

	/**
	 * Sets the manufacturer.
	 * @param manufacturer The manufacturer to set
	 */
	public void setManufacturer(String manufacturer)
	{
		this.manufacturer = manufacturer;
	}

	/**
	 * Sets the model.
	 * @param model The model to set
	 */
	public void setModel(String model)
	{
		this.model = model;
	}

	/**
	 * Sets the number.
	 * @param number The number to set
	 */
	public void setNumber(String number)
	{
		this.number = number;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setRemarks(String remarks)
	{
		this.remarks = remarks;
	}

	/**
	 * Sets the year.
	 * @param year The year to set
	 */
	public void setYear(String year)
	{
		this.year = year;
	}

	/**
	 * Returns the currentStatus.
	 * @return String
	 */
	public String getCurrentStatus()
	{
		return currentStatus;
	}

	/**
	 * Sets the currentStatus.
	 * @param currentStatus The currentStatus to set
	 */
	public void setCurrentStatus(String currentStatus)
	{
		this.currentStatus = currentStatus;
	}

}