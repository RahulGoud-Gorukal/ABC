package com.dfs.paxtrax.bagtracking.valueobject;

/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 18/05/2004    Joseph Oommen A Created   
*/

public class CageBean extends PaxTraxValueObject {
    /**
       The Cage Number of the cage
     */
    private String cageNumber = null;
    /**
       The Description of the cage
     */
    private String description = null;
    /**
       Remarks on the Cage
     */
    private String remarks = null;
    /**
       The maximum number of bags that can be placed in a cage
     */
    private String maxNoOfCartonsPerCage = null;
    
    
    /**
       The  current status of the cage
     */
    private String currentStatus = null;
    
    
    /**
     * Default Constructor for CageBean
     */
	public CageBean()
    {
    }
    /**
     * Returns the cageNumber.
     * @return String
     */
    
	public String getCageNumber()
	{
		return cageNumber;
	}

	/**
	 * Returns the description.
	 * @return String
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * Returns the maxNoOfCartonsPerCage.
	 * @return int
	 */
	public String getMaxNoOfCartonsPerCage()
	{
		return maxNoOfCartonsPerCage;
	}

	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getRemarks()
	{
		return remarks;
	}

	/**
	 * Sets the cageNumber.
	 * @param cageNumber The cageNumber to set
	 */
	public void setCageNumber(String cageNumber)
	{
		this.cageNumber = cageNumber;
	}

	/**
	 * Sets the description.
	 * @param description The description to set
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * Sets the maxNoOfCartonsPerCage.
	 * @param maxNoOfCartonsPerCage The maxNoOfCartonsPerCage to set
	 */
	public void setMaxNoOfCartonsPerCage(String maxNoOfCartonsPerCage)
	{
		this.maxNoOfCartonsPerCage = maxNoOfCartonsPerCage;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setRemarks(String remarks)
	{
		this.remarks = remarks;
	}

	/**
	 * Returns the currentStatus.
	 * @return String
	 */
	public String getCurrentStatus()
	{
		return currentStatus;
	}

	/**
	 * Sets the currentStatus.
	 * @param currentStatus The currentStatus to set
	 */
	public void setCurrentStatus(String currentStatus)
	{
		this.currentStatus = currentStatus;
	}

}