package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.admin.service.LocationDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.SearchCageForm;
import com.dfs.paxtrax.bagtracking.exception.CageException;
import com.dfs.paxtrax.bagtracking.service.CageDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.CageBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
* This is action class which performs search cage details
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 18/05/2004    Joseph Oommen A Created
*/

public class SearchCageAction extends PaxTraxAction
{

	private String forward = null;
    
	private CageDelegate cageDelegate = null;

	/**
		* forwards to the search Cage Page
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while forwarding to the page
	*/

	public ActionForward createSearchPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::SearchCageAction::createSearchPage::Begin");
		SearchCageForm searchCageForm = (SearchCageForm) form;
		CageBean cageBean = new CageBean();
		searchCageForm.setCageBean(cageBean);
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,
                                                PaxTraxConstants.BAG_TRACKING);
		forward = PaxTraxConstants.SEARCH_CAGE_PAGE;
		PaxTraxLog.logDebug("PaxTrax::SearchCageAction::createSearchPage::End");
		return mapping.findForward(forward);

	}

	/**
		* searching for the cage details
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while searching the cage details
	*/
	public ActionForward searchCageDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, CageException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::SearchCageAction::searchCageDetails::Begin");
		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		int pageNumber = 0;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		SearchCageForm searchCageForm = (SearchCageForm) form;

		HttpSession session = request.getSession();
		String pageNumberStr = null;
		//CageBean cageBean = searchCageForm.getCageBean();
		CageBean cageBean = new CageBean();
		if (operation != ""
			&& operation != null
			&& ((PaxTraxConstants.UPDATE).equals(operation)
				|| (PaxTraxConstants.DELETE).equals(operation)
				|| (PaxTraxConstants.UPDATE_SEARCH).equals(operation)))
		{
			pageNumberStr =
				(String) session.getAttribute(
					PaxTraxConstants.CAGE_PAGE_NUMBER);

		}

		else
		{
			pageNumberStr =
				request.getParameter(PaxTraxConstants.CAGE_PAGE_NUMBER);
			session.setAttribute(
				PaxTraxConstants.CAGE_PAGE_NUMBER,
				pageNumberStr);
		}

		/* If page number is null or empty it sets null otherwise
		 * it is same
		 */
		pageNumberStr =
			((pageNumberStr == null)
				|| pageNumberStr.equals(SQLConstants.BLANK))
				? null
				: pageNumberStr;
		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */

		if ((pageNumber == 0)
			|| ((PaxTraxConstants.UPDATE_SEARCH).equals(operation)
				|| (PaxTraxConstants.DELETE).equals(operation)
				|| (PaxTraxConstants.UPDATE).equals(PaxTraxConstants.OPERATION)))
		{
			int size = 0;
			if (pageNumber == 0)
				pageNumber = 1;

			cageDelegate = new CageDelegate();

			allRecords = cageDelegate.searchCageDetails(cageBean);

			if (allRecords != null)
			{
				size = allRecords.size();
			}

			session.removeAttribute(PaxTraxConstants.ALL_CAGE_RECORDS);
			session.setAttribute(PaxTraxConstants.ALL_CAGE_RECORDS, allRecords);
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_CAGE_RECORDS);
			session.setAttribute(
				PaxTraxConstants.SIZE_OF_ALL_CAGE_RECORDS,
				Integer.toString(size));
		}
		else
		{

			allRecords =
				(ArrayList) session.getAttribute(
					PaxTraxConstants.ALL_CAGE_RECORDS);
		}
		PaginationHelper helper = PaginationHelper.getInstance();
		if ((allRecords != null) && (allRecords.size() != 0))
		{
			//Get records to be displayed for the passed page number
			currentRecords =
				(ArrayList) helper.getCurrentTableContent(
					allRecords,
					pageNumber,
					PaxTraxConstants.RECORDS_PER_PAGE);
		}
		request.setAttribute(
			PaxTraxConstants.CAGE_PAGE_NUMBER,
			Integer.toString(pageNumber));

		searchCageForm.setCageList(currentRecords);
		if ((currentRecords == null) || (currentRecords.size() == 0))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.RECORD,
				new ActionMessage("" + PaxTraxConstants.NO_CAGE_RECORDS_FOUND));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, "" + PaxTraxConstants.NO_CAGE_RECORDS_FOUND);
		}
		searchCageForm.setCageBean(cageBean);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.SEARCH);
		PaxTraxLog.logDebug(
			"PaxTrax::SearchCageAction::searchCageDetails::End");
		forward = PaxTraxConstants.SEARCH_CAGE_PAGE;
		return mapping.findForward(forward);
	}

	/**
		* change language
		* @param mapping ActionMapping
		* @param form ActionForm
		* @param request HttpServletRequest
		* @param response HttpServletResponse
		* @return ActionForward Action forward
		* @throws PaxTraxSystemException This exception is thrown
		* if there is any problem while forwarding to the page
	*/
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::SearchCageAction::changeLanguage::Begin");

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		super.changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
			page = page.trim();

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);
		String pageNumber =
			(String) request.getParameter(PaxTraxConstants.PAGE_NUMBER);

		if (page != null && !pageNumber.equals("-1"))
			request.setAttribute(PaxTraxConstants.CAGE_PAGE_NUMBER, pageNumber);
		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(PaxTraxConstants.ERROR, new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
		}
		PaxTraxLog.logDebug("PaxTrax::SearchCageAction::changeLanguage::End");
		return mapping.findForward(PaxTraxConstants.SEARCH_CAGE_PAGE);

	}

}
