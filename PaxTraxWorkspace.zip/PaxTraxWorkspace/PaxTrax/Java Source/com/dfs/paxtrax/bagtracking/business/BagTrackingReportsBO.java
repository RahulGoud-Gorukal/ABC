package com.dfs.paxtrax.bagtracking.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.valueobject.BagByBagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByFlightInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByLocationBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagTrackingEnquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationReportBean;
import com.dfs.paxtrax.bagtracking.valueobject.CageStatusHistoryBean;
import com.dfs.paxtrax.bagtracking.valueobject.CartonTrackingEnquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.DeliveryManifestBean;
import com.dfs.paxtrax.bagtracking.valueobject.ItemTrackingInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.MissingBagsEnquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.PaxPurchaseInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.SKUSummaryReportBean;
import com.dfs.paxtrax.bagtracking.valueobject.StockAtPickupLocationInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.TracingRefundedBagBean;
import com.dfs.paxtrax.bagtracking.valueobject.TruckTrackingInquiryBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;

/**
 * 
 * Business interface for BagTracking reports.
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 * 29/08/2005	P.C. Sathish	Created
 * 06/06/2007	Uma				Added method for CR changes
 * 07/30/2007	Uma				Added method for CR changes
 */
public interface BagTrackingReportsBO extends javax.ejb.EJBObject {
	public ArrayList getReportsAssignedToUser(String userId)
		throws PaxTraxSystemException, RemoteException;

	/**
	  * Searches for the Item details in the database by 
	  * delegating the request to  the bean. 
	  * @param itemTrackingInquiryBean ItemTrackingInquiryBean object
	  * @throws PaxTraxSystemException for System Exception
	  * @throws BagTrackingReportsException for BusinessException 
	  */
	public ArrayList getItemTrackingInquiry(ItemTrackingInquiryBean itemTrackingInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	public BagTrackingEnquiryBean getBagTrackingEnquiryData(BagTrackingEnquiryBean btEnquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	public ArrayList getTruck() throws PaxTraxSystemException, RemoteException;

	/**
	 * Gets the list of truck
	 * @return ArrayList
	 * @throws PaxTraxSystemException if there is any problem in retrieving the
	 * truck
	 * @throws RemoteException
	 */
	public ArrayList getTruckList()
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Gets the report for a truck
	 * @param deliveryBean
	 * @return DeliveryManifestBean
	 * @throws PaxTraxSystemException if there is any problem in retrieving the
	 * report
	 * @throws RemoteException
	 */
	public DeliveryManifestBean getDeliveryManifest(DeliveryManifestBean deliveryBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Prints DeliveryManifestpage and changes the status of truck,cages,cartons
	 * and bags.
	 * @param deliveryBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public void printDeliveryManifest(DeliveryManifestBean deliveryBean)
		throws PaxTraxSystemException, RemoteException;

	/** 
	 * Method getBinLocEnquiryReport.
	 * @param bEBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public ArrayList getBinLocEnquiryReport(
		BinLocationReportBean bEBean,
		ArrayList combinedList)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method getAllBinLocations.
	 * @param locationType
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public ArrayList getAllBinLocations(String locationType)
		throws PaxTraxSystemException, RemoteException;

	/**
		* Generates the report for truck from the database.
		* @param TruckTrackingInquiryBean
		* @return TruckTrackingInquiryBean
		* @throws PaxTraxException This exception is thrown
		* if there is any problem in retrieval
		*/
	public TruckTrackingInquiryBean getTruckTrackingEnquiry(TruckTrackingInquiryBean truckTrackingInquiryBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method getStockAtPickupLocationInquiry.
	 * @param stockBean
	 * @return StockAtPickupLocationInquiryBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public StockAtPickupLocationInquiryBean getStockAtPickupLocationInquiry(StockAtPickupLocationInquiryBean stockBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method getCageReport.
	 * @param cageStatusHistoryBean
	 * @return CageReportResultBean
	 * @throws PaxTraxSystemException
	 */
	public CageStatusHistoryBean getCageReport(CageStatusHistoryBean cageStatusHistoryBean)
		throws RemoteException, PaxTraxSystemException, BagTrackingReportsException;

	/**
	* Generates the report for pax purchase from the database.
	* @return PaxPurchaseInquiryBean
	* @throws PaxTraxException This exception is thrown
	* if there is any problem in retrieval
	*/
	public PaxPurchaseInquiryBean getPaxPurchaseInquiry(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws RemoteException, BagTrackingReportsException, PaxTraxSystemException;

	/**
	 * Method getBagStatusByFlightInquiry.
	 * @param bagStatusInquiry
	 * @return BagStatusByFlightInquiryBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public BagStatusByFlightInquiryBean getBagStatusByFlightInquiry(BagStatusByFlightInquiryBean bagStatusInquiry)
		throws PaxTraxSystemException, RemoteException, BagTrackingReportsException;

	/**
	 * Returns list of carton numbers.
	 * @return ArrayList list of carton numbers
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getCartonList()
		throws RemoteException, PaxTraxSystemException;

	/**
	 * Returns carton tracking enquiry information bean .
	 * @param cartonNumber the carton number
	 * @param moduleId the module id
	 * @return CartonTrackingEnquiryBean the carton tracking info bean
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public CartonTrackingEnquiryBean getCartonDetails(
		String cartonNumber,
		long moduleId)
		throws RemoteException, PaxTraxSystemException, BagTrackingReportsException;

	/**
	 * Method getBagNotReadyForPickup.
	 * @param bagEnquiry
	 * @return BagTrackingEnquiryBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public BagTrackingEnquiryBean getBagNotReadyForPickup(BagTrackingEnquiryBean bagEnquiry)
		throws PaxTraxSystemException, RemoteException, BagTrackingReportsException;

	/**
	 * Method getAllCages.
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public ArrayList getAllCages()
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method bagCancelSave.
	 * @param bagBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public void bagCancelSave(BagTrackingEnquiryBean bagBean)
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Method getMissingBagDetailst.
	 * @param missingBagsEnquiryBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public ArrayList getMissingBagDetails(MissingBagsEnquiryBean missingBagsEnquiryBean)
		throws PaxTraxSystemException, RemoteException;

	public void saveMissingBagDetails(ArrayList missingBags)
		throws PaxTraxSystemException, RemoteException;

	public PaxPurchaseInquiryBean getPaxDFPurchaseList(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	public PaxPurchaseInquiryBean approvePax(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	public PaxPurchaseInquiryBean rejectPax(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	public PaxPurchaseInquiryBean getPaxDetails(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	public PaxPurchaseInquiryBean getPaxDPPurchaseList(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException, RemoteException;

	/**
	 * Returns the list of SKU's that were transferred through a truck trip
	 * on a particular day
	 * @param date date for which sku transfer is required
	 * @return ArrayList list of BagStatusBean containing sku list
	 * @throws PaxTraxSystemException thrown on Error
	 * @throws RemoteException thrown if remote access fails
	 */
	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

	public ArrayList getSkuTransferList(SKUSummaryReportBean skuSummaryReportBean)
			throws PaxTraxSystemException, RemoteException;

		/**
		 * Returns the list of items that were transferred on a particular day
		 * @param date date for which sku transfer details are needed
		 * @return ArrayList list of ItemDetailsBean containing sku list
		 * @throws PaxTraxSystemException thrown on Error
		 * @throws RemoteException thrown if remote access fails
		 */
		public ArrayList getSkuTransferGroupBySkusList(SKUSummaryReportBean skuSummaryReportBean)
			throws PaxTraxSystemException, RemoteException;
	/*Modified on 28th June 2006 - End
	 *SR 1042 International DF Sale */
	 
 /* Added on June 06, 2007 for CR 251-260 changes Begin*/
 
	 /**
	  * This method is used to get the Bag status list.
	  * @param bagByBagStatusBean
	  * @return BagByBagStatusBean
	  * @throws PaxTraxSystemException
	  * @throws RemoteException
	  */
	 public BagByBagStatusBean getBagByBagStatusReport(BagByBagStatusBean bagByBagStatusBean)
		 throws PaxTraxSystemException, RemoteException, BagTrackingReportsException; 
		 
	/**
	 * Returns the search result list for the given Bag Status
	 * @param bagCode
	 * @return ArrayList list of bag status
	 * @throws PaxTraxSystemException thrown on Error
	 * @throws RemoteException thrown if remote access fails
	 */
	public ArrayList loadBagStatus(String bagCode)
		throws PaxTraxSystemException, RemoteException;	

	/**
	 * This method is used to get the Bag status by location display list.
	 * @param bagStatusLocationBean
	 * @return refName
	 * @throws ArrayList
	 * @throws RemoteException
	 */
	public ArrayList loadConfigData(String refName)
		throws PaxTraxSystemException, RemoteException;	
		
	/**
	 * This method is used to get the Bag status by location list.
	 * @param bagStatusLocationBean
	 * @return BagStatusByLocationBean
	 * @throws PaxTraxSystemException
	 * @throws RemoteException
	 */
	public BagStatusByLocationBean getBagStatusByLocationReport(BagStatusByLocationBean bagStatusLocationBean)
		throws PaxTraxSystemException, RemoteException, BagTrackingReportsException;			 
 
 /* Added on June 06, 2007 for CR 251-260 changes End*/
 
	 //	Added on 30jul07 for CR 261 Tracing RefundedBags Starts
	 /**
	  * Returns the list of bags that were refunded at AP/received at Galleria on a particular day
	  * @return ArrayList list of Refunded Bags .
	  * @throws PaxTraxSystemException thrown on Error
	  * @throws RemoteException thrown if remote access fails
	  */
	 public ArrayList getRefundedBagList(TracingRefundedBagBean tracingRefundedBagBean)
		 throws PaxTraxSystemException, RemoteException;
	 /**
	  * Returns the list of bags that were received at Galleria
	  * @return ArrayList list of Refunded Bags .
	  * @throws PaxTraxSystemException thrown on Error
	  * @throws RemoteException thrown if remote access fails
	  */
		 public ArrayList receiveBagsatGalleria(ArrayList refundedBagList, String userId)
			 throws PaxTraxSystemException, RemoteException;
	 //	Added on 30jul07 for CR 261 Tracing RefundedBags Ends 

}