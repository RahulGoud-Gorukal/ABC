package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */ 


import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.TruckStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.TruckTrackingInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.TruckTrackingInquiryCageDetailsBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains Deivery Manifest attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE           USER            COMMENTS
 * 30/06/2004     Sundarrajan.K.  Created   
*/

public class TruckTrackingEnquiryForm extends PaxTraxActionForm
{
	// sets the Truck list
	private ArrayList truckList = null;
	
	// sets the list of pickup locations
	private ArrayList pickList = null;
	
	// sets the truck tracking inquiry bean attributes
	private TruckTrackingInquiryBean truckTrackingInquiryBean = null;
	
	// sets the truck status bean attributes
	private TruckStatusBean truckStatusBean = null;
	
	// sets the truck status inquiry cage details bean attributes
	private TruckTrackingInquiryCageDetailsBean truckTrackingInquiryCageDetailsBean= null;
	
	/**
	 * Returns the pickList.
	 * @return ArrayList
	 */
	public ArrayList getPickList()
	{
		return pickList;
	}

	/**
	 * Returns the truckList.
	 * @return ArrayList
	 */
	public ArrayList getTruckList()
	{
		return truckList;
	}

	/**
	 * Returns the truckStatusBean.
	 * @return TruckStatusBean
	 */
	public TruckStatusBean getTruckStatusBean()
	{
		return truckStatusBean;
	}

	/**
	 * Returns the truckTrackingInquiryBean.
	 * @return TruckTrackingInquiryBean
	 */
	public TruckTrackingInquiryBean getTruckTrackingInquiryBean()
	{
		return truckTrackingInquiryBean;
	}

	/**
	 * Returns the truckTrackingInquiryCageDetailsBean.
	 * @return TruckTrackingInquiryCageDetailsBean
	 */
	public TruckTrackingInquiryCageDetailsBean getTruckTrackingInquiryCageDetailsBean()
	{
		return truckTrackingInquiryCageDetailsBean;
	}

	/**
	 * Sets the pickList.
	 * @param pickList The pickList to set
	 */
	public void setPickList(ArrayList pickList)
	{
		this.pickList = pickList;
	}

	/**
	 * Sets the truckList.
	 * @param truckList The truckList to set
	 */
	public void setTruckList(ArrayList truckList)
	{
		this.truckList = truckList;
	}

	/**
	 * Sets the truckStatusBean.
	 * @param truckStatusBean The truckStatusBean to set
	 */
	public void setTruckStatusBean(TruckStatusBean truckStatusBean)
	{
		this.truckStatusBean = truckStatusBean;
	}

	/**
	 * Sets the truckTrackingInquiryBean.
	 * @param truckTrackingInquiryBean The truckTrackingInquiryBean to set
	 */
	public void setTruckTrackingInquiryBean(TruckTrackingInquiryBean truckTrackingInquiryBean)
	{
		this.truckTrackingInquiryBean = truckTrackingInquiryBean;
	}

	/**
	 * Sets the truckTrackingInquiryCageDetailsBean.
	 * @param truckTrackingInquiryCageDetailsBean The truckTrackingInquiryCageDetailsBean to set
	 */
	public void setTruckTrackingInquiryCageDetailsBean(TruckTrackingInquiryCageDetailsBean truckTrackingInquiryCageDetailsBean)
	{
		this.truckTrackingInquiryCageDetailsBean =
			truckTrackingInquiryCageDetailsBean;
	}

}	