package com.dfs.paxtrax.bagtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
 * 
 * The bean class for stock at pickup location report
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 02/07/2004	Yuvarani			Created   
 */

public class StockAtPickupLocationInquiryBean extends PaxTraxValueObject
{
	
	//pickupLocation 
	private String pickupLocation = null;
	
	private String pickupLocationValue =null;
	
	//stockList 
	private ArrayList stockList = null;

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Returns the stockList.
	 * @return ArrayList
	 */
	public ArrayList getStockList()
	{
		return stockList;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Sets the stockList.
	 * @param stockList The stockList to set
	 */
	public void setStockList(ArrayList stockList)
	{
		this.stockList = stockList;
	}

	/**
	 * Returns the pickupLocationValue.
	 * @return String
	 */
	public String getPickupLocationValue()
	{
		return pickupLocationValue;
	}

	/**
	 * Sets the pickupLocationValue.
	 * @param pickupLocationValue The pickupLocationValue to set
	 */
	public void setPickupLocationValue(String pickupLocationValue)
	{
		this.pickupLocationValue = pickupLocationValue;
	}

}