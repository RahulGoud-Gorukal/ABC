package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * This is action form which contains search attributes for truck
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 02/06/2004   R.R.Yuvarani	    Created   
*/

public class SearchTruckForm extends PaxTraxActionForm {

    // The manufacturer attribute of the search page
    private String manufacturer = null;

    // The make attribute of the search page
    private String make = null;

    // The model attribute of the search page
    private String model = null;

    // The year attribute of the search page
    private String year = null;

    /**
     * The collection that is used to hold the list of Truck Beans 
     * that match search criteria 
     */
    private ArrayList truckList = null;
    
	/**
	 * Returns the make.
	 * @return String
	 */
	public String getMake()
	{
		return make;
	}

	/**
	 * Returns the manufacturer.
	 * @return String
	 */
	public String getManufacturer()
	{
		return manufacturer;
	}

	/**
	 * Returns the model.
	 * @return String
	 */
	public String getModel()
	{
		return model;
	}

	/**
	 * Returns the truckList.
	 * @return ArrayList
	 */
	public ArrayList getTruckList()
	{
		return truckList;
	}

	/**
	 * Returns the year.
	 * @return String
	 */
	public String getYear()
	{
		return year;
	}

	/**
	 * Sets the make.
	 * @param make The make to set
	 */
	public void setMake(String make)
	{
		this.make = make;
	}

	/**
	 * Sets the manufacturer.
	 * @param manufacturer The manufacturer to set
	 */
	public void setManufacturer(String manufacturer)
	{
		this.manufacturer = manufacturer;
	}

	/**
	 * Sets the model.
	 * @param model The model to set
	 */
	public void setModel(String model)
	{
		this.model = model;
	}

	/**
	 * Sets the truckList.
	 * @param truckList The truckList to set
	 */
	public void setTruckList(ArrayList truckList)
	{
		this.truckList = truckList;
	}

	/**
	 * Sets the year.
	 * @param year The year to set
	 */
	public void setYear(String year)
	{
		this.year = year;
	}

}