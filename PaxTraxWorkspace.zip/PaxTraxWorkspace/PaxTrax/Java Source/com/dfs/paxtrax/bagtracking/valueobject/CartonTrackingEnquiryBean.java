package com.dfs.paxtrax.bagtracking.valueobject;

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * @author 115157
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CartonTrackingEnquiryBean extends PaxTraxValueObject {
	
	private String pickupLocation;
	private String departureDate;
	private String shift;
	private int noOfBags;
	private String cartonNumber;	
	/* Carton Status history bean */
	private ArrayList bagStatusList;	
	/* BagStatusBean */
	private ArrayList cartonHistoryList;
	
	
	/**
	 * Returns the bagStatusList.
	 * @return ArrayList
	 */
	public ArrayList getBagStatusList()
	{
		return bagStatusList;
	}

	/**
	 * Returns the cartonHistoryList.
	 * @return ArrayList
	 */
	public ArrayList getCartonHistoryList()
	{
		return cartonHistoryList;
	}

	/**
	 * Returns the cartonNumber.
	 * @return String
	 */
	public String getCartonNumber()
	{
		return cartonNumber;
	}

	/**
	 * Returns the departureDate.
	 * @return String
	 */
	public String getDepartureDate()
	{
		return departureDate;
	}

	/**
	 * Returns the noOfBags.
	 * @return int
	 */
	public int getNoOfBags()
	{
		return noOfBags;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Returns the shift.
	 * @return String
	 */
	public String getShift()
	{
		return shift;
	}

	/**
	 * Sets the bagStatusList.
	 * @param bagStatusList The bagStatusList to set
	 */
	public void setBagStatusList(ArrayList bagStatusList)
	{
		this.bagStatusList = bagStatusList;
	}

	/**
	 * Sets the cartonHistoryList.
	 * @param cartonHistoryList The cartonHistoryList to set
	 */
	public void setCartonHistoryList(ArrayList cartonHistoryList)
	{
		this.cartonHistoryList = cartonHistoryList;
	}

	/**
	 * Sets the cartonNumber.
	 * @param cartonNumber The cartonNumber to set
	 */
	public void setCartonNumber(String cartonNumber)
	{
		this.cartonNumber = cartonNumber;
	}

	/**
	 * Sets the departureDate.
	 * @param departureDate The departureDate to set
	 */
	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	/**
	 * Sets the noOfBags.
	 * @param noOfBags The noOfBags to set
	 */
	public void setNoOfBags(int noOfBags)
	{
		this.noOfBags = noOfBags;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Sets the shift.
	 * @param shift The shift to set
	 */
	public void setShift(String shift)
	{
		this.shift = shift;
	}

}
