package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.PicklistSearchBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;


/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created   
 */
public class GeneratePicklistForm extends PaxTraxActionForm 
{
	/* The Bean that will hold all the search criteris specified */
	PicklistSearchBean picklistSearchBean = null;
	
	/* The ArrayList that will hold all the pickup location values */
	ArrayList pickupLocationList = null;
	
	/* The ArrayList that will hold all the shift values */	
	ArrayList shiftList = null;
	
	/* The ArrayList that holds the picklist records */
	ArrayList pickList = null;
	
	/* The ArrayList that will hold the records to be displayed on the printable window */
	ArrayList printList = null;
	
	/**
	 * Returns the picklistSearchBean.
	 * @return PicklistSearchBean
	 */
	public PicklistSearchBean getPicklistSearchBean()
	{
		return picklistSearchBean;
	}

	/**
	 * Returns the pickupLocationList.
	 * @return ArrayList
	 */
	public ArrayList getPickupLocationList()
	{
		return pickupLocationList;
	}

	/**
	 * Returns the shiftList.
	 * @return ArrayList
	 */
	public ArrayList getShiftList()
	{
		return shiftList;
	}

	/**
	 * Sets the picklistSearchBean.
	 * @param picklistSearchBean The picklistSearchBean to set
	 */
	public void setPicklistSearchBean(PicklistSearchBean picklistSearchBean)
	{
		this.picklistSearchBean = picklistSearchBean;
	}

	/**
	 * Sets the pickupLocationList.
	 * @param pickupLocationList The pickupLocationList to set
	 */
	public void setPickupLocationList(ArrayList pickupLocationList)
	{
		this.pickupLocationList = pickupLocationList;
	}

	/**
	 * Sets the shiftList.
	 * @param shiftList The shiftList to set
	 */
	public void setShiftList(ArrayList shiftList)
	{
		this.shiftList = shiftList;
	}

	/**
	 * Returns the pickList.
	 * @return ArrayList
	 */
	public ArrayList getPickList()
	{
		return pickList;
	}

	/**
	 * Sets the pickList.
	 * @param pickList The pickList to set
	 */
	public void setPickList(ArrayList pickList)
	{
		this.pickList = pickList;
	}

	/**
	 * Returns the printList.
	 * @return ArrayList
	 */
	public ArrayList getPrintList()
	{
		return printList;
	}

	/**
	 * Sets the printList.
	 * @param printList The printList to set
	 */
	public void setPrintList(ArrayList printList)
	{
		this.printList = printList;
	}

}
