package com.dfs.paxtrax.bagtracking.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMapping;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.bagtracking.valueobject.TracingRefundedBagBean;

/**
 * 
 * The Action Form for Tracing Refunded Bags
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Jaganmohan Gopinath
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/07/2007	Vijay			Created   
 */

public class TracingRefundedBagForm extends PaxTraxActionForm{
	private ArrayList refundedBagList=null;
	private TracingRefundedBagBean 	tracingRefundedBagBean=null; 

	public TracingRefundedBagForm(){
	}
	
	/**
	 * @return
	 */
	public ArrayList getRefundedBagList() {
		return refundedBagList;
	}

	/**
	 * @param list
	 */
	public void setRefundedBagList(ArrayList list) {
		refundedBagList = list;
	}

	/**
	 * @return
	 */
	public TracingRefundedBagBean getTracingRefundedBagBean() {
		return tracingRefundedBagBean;
	}

	/**
	 * @param bean
	 */
	public void setTracingRefundedBagBean(TracingRefundedBagBean bean) {
		tracingRefundedBagBean = bean;
	}
	
	public void reset(ActionMapping mapping,HttpServletRequest request)
	{
		if (refundedBagList != null)
		{
			int size = refundedBagList.size();
			TracingRefundedBagBean refundedBean = null;
			for (int i = 0;i < size;i++)
			{	
				refundedBean = (TracingRefundedBagBean)refundedBagList.get(i);
				refundedBean.setShowCheckBox("N");
				refundedBagList.remove(i);
				refundedBagList.add(i,refundedBean);
			}
		}
	}
}
