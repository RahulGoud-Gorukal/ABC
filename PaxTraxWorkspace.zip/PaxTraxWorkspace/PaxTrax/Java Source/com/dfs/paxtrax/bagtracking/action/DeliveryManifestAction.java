package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.action.ReferenceDataAction;
import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.DeliveryManifestForm;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.DeliveryManifestBean;
import com.dfs.paxtrax.bagtracking.valueobject.TruckTrackingInquiryCageDetailsBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for a truck number
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 23/06/2004    Yuvarani		Created
*/

public class DeliveryManifestAction extends PaxTraxAction
{
	/**
	 * Forwards to DeliveryManifestPage.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward goToDeliveryManifestPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::DeliveryManifestAction::goToDeliveryManifestPage::Begin");
		int size = 0;
		DeliveryManifestForm delivery = (DeliveryManifestForm) form;
		DeliveryManifestBean deliveryBean = new DeliveryManifestBean();
		TruckTrackingInquiryCageDetailsBean manifestBean = null;
		ArrayList pickupAdd = new ArrayList();
		String forward = null;
		ReferenceDataDelegate referrenceData = new ReferenceDataDelegate();

		try
		{
			ArrayList pickup =
				referrenceData.loadReferenceData(
					PaxTraxConstants.PICK_UP_LOCATION);
			if (pickup != null)
			{
				size = pickup.size();
			}
			for (int i = 0; i < size; i++)
			{
				manifestBean = new TruckTrackingInquiryCageDetailsBean();
				manifestBean.setPickupLocation(
					((ReferenceDataBean) pickup.get(i)).getCodeValue());
				pickupAdd.add(manifestBean);
			}
			delivery.setPickup(pickupAdd);
			BagTrackingReportsDelegate deliveryDelegate =
				new BagTrackingReportsDelegate();
			ArrayList truckList = deliveryDelegate.getTruck();
			delivery.setTruckList(truckList);
			delivery.setDeliveryBean(deliveryBean);
			forward = PaxTraxConstants.DELIVERY_MANIFEST_PAGE;
		}
		catch (Exception paxException)
		{
			PaxTraxLog.logError(
				"PaxTrax::DeliveryManifestAction::goToDeliveryManifestPage",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}

		PaxTraxLog.logDebug(
			"PaxTrax::DeliveryManifestAction::goToDeliveryManifestPage::End");
		return mapping.findForward(forward);
	}

	/**
	 * Gets the report for a truck
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in retrieving the
	 * report
	 */
	public ActionForward getDeliveryManifest(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::DeliveryManifestAction::getDeliveryManifest::Begin");
		DeliveryManifestForm deliveryForm = (DeliveryManifestForm) form;
		DeliveryManifestBean deliveryBean = deliveryForm.getDeliveryBean();
		TruckTrackingInquiryCageDetailsBean manifest = null;
		BagTrackingReportsDelegate deliveryDelegate =
			new BagTrackingReportsDelegate();
		String forward = null;
		try
		{
			deliveryBean = deliveryDelegate.getDeliveryManifest(deliveryBean);
			if (deliveryBean.getManifestList() == null
				|| deliveryBean.getManifestList().size() == 0)
			{
				request.setAttribute(
					PaxTraxConstants.ERROR_CODE,
					PaxTraxConstants.ERROR_CODE);
			}
			ArrayList pickup =
				deliveryBean.getTotalNoOfCartonsPerPickupLocation();
			ArrayList pickupList = deliveryForm.getPickup();

			int size = 0;
			if (pickupList != null)
			{
				size = pickupList.size();
			}
			int size1 = 0;
			if (pickup != null)
			{
				size1 = pickup.size();
			}
	
			/* Code added as part of the fix to display the correct
			 * carton count per pickup location. Code added on July 26, 2006 
			 * as part of the SR 1042 enhancement
			 * 
			 * This piece of code resets the carton count for all the pickup locations  
			 */ 
			
			for (int i = 0; i < size; i++)
			{
				manifest = new TruckTrackingInquiryCageDetailsBean();
				manifest = (TruckTrackingInquiryCageDetailsBean) pickupList.get(i);
				manifest.setTotalNoOfCartons(0);
				pickupList.remove(i);
				pickupList.add(i, manifest);
			}
			
			/* Code ends */
			
			for (int i = 0; i < size; i++)
			{
				manifest = new TruckTrackingInquiryCageDetailsBean();
				manifest =
					(TruckTrackingInquiryCageDetailsBean) pickupList.get(i);

				String pickupLocation2 = manifest.getPickupLocation();
				for (int j = 0; j < size1; j++)
				{
					ReferenceDataBean referenceDataBean =
						(ReferenceDataBean) pickup.get(j);
					String pickupLocation1 = referenceDataBean.getCodeId();
					
					if (pickupLocation1 != null
						&& pickupLocation1.equals(pickupLocation2))
					{
						manifest.setTotalNoOfCartons(
							Integer.parseInt(referenceDataBean.getCodeValue()));
						pickupList.remove(i);
						pickupList.add(i, manifest);
					}
				}
			}
			deliveryForm.setPickup(pickupList);
			
			/* Code added as part of SR1042 - International DF Sales Enhancement */
			/* This is to retain the International flag on the print page */
			HttpSession session = request.getSession();
			session.setAttribute("IntlFlag", deliveryBean.getInternational());
			/* Code ends */
			
			deliveryForm.setDeliveryBean(deliveryBean);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			forward = PaxTraxConstants.DELIVERY_MANIFEST_PAGE;
		}
		catch (Exception paxException)
		{
			PaxTraxLog.logError(
				"PaxTrax::DeliveryManifestAction::getDeliveryManifest",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}

		PaxTraxLog.logDebug(
			"PaxTrax::DeliveryManifestAction::getDeliveryManifest::End");
		return mapping.findForward(forward);
	}

	/**
	 * Prints DeliveryManifest page.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward printDeliveryManifest(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::DeliveryManifestAction::printDeliveryManifest::Begin");
		DeliveryManifestForm deliveryForm = (DeliveryManifestForm) form;
		DeliveryManifestBean deliveryBean = deliveryForm.getDeliveryBean();
		HttpSession session = request.getSession();
		deliveryBean.setUser(
			(String) session.getAttribute(PaxTraxConstants.USER_ID));
		deliveryBean.setClientMachine(request.getRemoteHost());
		BagTrackingReportsDelegate deliveryDelegate =
			new BagTrackingReportsDelegate();
		String forward = null;
		try
		{
			/* Code added as part of SR1042 - International DF Sales Enhancement */
			/* This is to retain the International flag on the print page */
			String intlFlag = (String) session.getAttribute("IntlFlag");
			deliveryBean.setInternational(intlFlag);
			/* Code ends */			
			deliveryDelegate.printDeliveryManifest(deliveryBean);
			forward = PaxTraxConstants.PRINT_DELIVERY_MANIFEST;
		}
		catch (Exception paxException)
		{
			PaxTraxLog.logError(
				"PaxTrax::DeliveryManifestAction::printDeliveryManifest",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::DeliveryManifestAction::printDeliveryManifest::end");
		return mapping.findForward(forward);
	}

}