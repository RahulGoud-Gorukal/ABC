package com.dfs.paxtrax.bagtracking.action;


/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.TruckForm;
import com.dfs.paxtrax.bagtracking.exception.TruckException;
import com.dfs.paxtrax.bagtracking.service.TruckDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.TruckBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
* This action class is used for inserting and updating truck records
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 29/05/2004    R.R.Yuvarani    Created
*/

public class TruckAction extends PaxTraxAction
{

	/**
	 * This method is used to create truck by forwarding to create truck page
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 */
	public ActionForward createTruckPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::createTruckPage::Begin");
		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,
												PaxTraxConstants.BAG_TRACKING);
		TruckForm truckForm = (TruckForm)form;
		TruckBean truckBean= new TruckBean();
		truckForm.setTruckBean(truckBean);
		PaxTraxLog.logDebug("PaxTrax::TruckAction::createTruckPage::End");
		return mapping.findForward(PaxTraxConstants.CREATE_TRUCK_PAGE);
		
	}
	
	/**
	 * Saves Truck Details in the database
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in saving
	 */
	public ActionForward saveTruckDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
	
		PaxTraxLog.logDebug("PaxTrax::TruckAction::saveTruckDetails::Begin");
		TruckForm truckForm = (TruckForm)form;
		TruckBean truckBean = truckForm.getTruckBean();
		TruckDelegate truckDelegate = new TruckDelegate();
		String forward = null;
		HttpSession session = request.getSession();
		truckBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));
		try
		{
		truckDelegate.saveTruckDetails(truckBean);
		forward = PaxTraxConstants.TRUCK_CONFIRMATION;
		}
		catch(TruckException truckException)
		{
			request.setAttribute(PaxTraxConstants.ERROR_CODE,
										""+truckException.getErrorCode());
			forward = PaxTraxConstants.CREATE_TRUCK_PAGE;	
		}
				
		PaxTraxLog.logDebug("PaxTrax::TruckAction::saveTruckDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * This method is used to maintain truck details
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in maintaining 
	 * the details
	 */
	public ActionForward maintainTruckPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::maintainTruckPage::Begin");
		HttpSession session = request.getSession();
		session.setAttribute(PaxTraxConstants.MODULE_NAME,
												PaxTraxConstants.BAG_TRACKING);
		TruckForm truckForm = (TruckForm)form;
		TruckBean truckBean= new TruckBean();
		truckForm.setTruckBean(truckBean);
		PaxTraxLog.logDebug("PaxTrax::TruckAction::maintainTruckPage::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_TRUCK_PAGE);
	}
	
	/**
	 * Updates truck details in the database
	 * @param mapping ActionMapping
	 * @param form ActionForm 
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in updation
	 */
	public ActionForward updateTruckDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::updateTruckDetails::Begin");
		TruckForm truckForm = (TruckForm)form;
		TruckBean truckBean = truckForm.getTruckBean();
		TruckDelegate truckDelegate = new TruckDelegate();
		String forward = null;
		ArrayList allRecords = null;
		HttpSession session = request.getSession();
		truckBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));
		String fromPage = (String)request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);

		String fromPageNumber = request.getParameter(PaxTraxConstants
															.FROM_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,fromPageNumber);

		truckDelegate.updateTruckDetails(truckBean);

		if (fromPage.equals(PaxTraxConstants.SEARCH_TRUCK_PAGE))
		{
			allRecords = (ArrayList)session.
								getAttribute(PaxTraxConstants.ALL_RECORDS);				
			int recordSize = 0;
			if (allRecords != null)
				recordSize = allRecords.size();
			
			for (int i = 0;i < recordSize;i++)
			{
				TruckBean truck = (TruckBean)allRecords.get(i);
				if (truck.getNumber().equals(truckBean.getNumber()))
				{
					allRecords.remove(i);
					allRecords.add(i,truckBean);
					session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
					session.setAttribute(PaxTraxConstants.ALL_RECORDS,
																allRecords);
				break;
				}
			}
		}
		request.setAttribute(PaxTraxConstants.SUCCESS,
									""+PaxTraxConstants.TRUCK_UPDATED);

		PaxTraxLog.logDebug("PaxTrax::TruckAction::updateTruckDetails::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_TRUCK_CONFIRMATION);
	}

	/**
	 * Removes TruckDetails from the database.
	 * @param mapping ActionMapping 
	 * @param form ActionForm 
	 * @param request HttpServletRequest 
	 * @param response HttpServletResponse 
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in deletion
	 */
	public ActionForward removeTruckDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException,TruckException
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::removeTruckDetails::Begin");
		TruckForm truckForm = (TruckForm)form;
		TruckBean truckBean = truckForm.getTruckBean();
		
		HttpSession session = request.getSession();
		truckBean.setUser((String)session.getAttribute(PaxTraxConstants.USER_ID));
		
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);

		String fromPageNumber = request.getParameter(PaxTraxConstants
															.FROM_PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,fromPageNumber);

		String forward = null;
		
		try
		{
		TruckDelegate truckDelegate = new TruckDelegate();
		truckDelegate.removeTruckDetails(truckBean);

		if (fromPage.equals(PaxTraxConstants.SEARCH_TRUCK_PAGE))
		{
			ArrayList allRecords = (ArrayList)session.getAttribute(
												PaxTraxConstants.ALL_RECORDS);
			int recordSize = 0;									
			if (allRecords != null)
			{
				recordSize = allRecords.size();
			}
			for (int i = 0;i < recordSize;i++)
			{
				TruckBean truck = (TruckBean)allRecords.get(i);
				if (truck.getNumber().equals(truckBean.getNumber()))
				{
					allRecords.remove(i);
					session.removeAttribute(PaxTraxConstants.ALL_RECORDS);
					session.setAttribute(PaxTraxConstants.ALL_RECORDS,allRecords);
					break;
				}
			}

				/*
				 * Adjusting the Page number
				 */
				if (recordSize == 1)
				{
					/*
					 * if there was only one record and
					 * that got deleted then page number attribute
					 * should be removed from the session
					 */
					request.removeAttribute(PaxTraxConstants.PAGE_NUMBER);
				}
				else if ((recordSize % 10) == 1)
				{
					int pageNumber = Integer.parseInt((String)request.
								getAttribute(PaxTraxConstants.PAGE_NUMBER));
					--pageNumber;
					request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
											Integer.toString(pageNumber));
				}
			
		}
		request.setAttribute(PaxTraxConstants.SUCCESS,
										""+PaxTraxConstants.TRUCK_DELETED);
		forward = PaxTraxConstants.MAINTAIN_TRUCK_CONFIRMATION;	
		}
		catch (TruckException truckException)
		{
			request.setAttribute(PaxTraxConstants.ERROR_CODE,""
												+truckException.getErrorCode());
			request.setAttribute(PaxTraxConstants.SUCCESS,PaxTraxConstants.TRUE);
			forward = PaxTraxConstants.MAINTAIN_TRUCK_PAGE;
		}
		PaxTraxLog.logDebug("PaxTrax::TruckAction::removeTruckDetails::End");
		return mapping.findForward(forward);
	}

	/**
	 * Gets the truck details for the specified truck
	 * @param mapping ActionMapping 
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in 
	 * getting the details
	 */
	public ActionForward selectTruck(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::selectTruck::Begin");
		TruckForm truckForm = (TruckForm)form;
		TruckBean truckBean = truckForm.getTruckBean();
		request.setAttribute(PaxTraxConstants.FROM_PAGE,PaxTraxConstants.MAINTAIN_TRUCK_PAGE);
		TruckDelegate truckDelegate = new TruckDelegate();
		try
		{
		truckBean = truckDelegate.getTruckDetails(truckBean);
		truckForm.setTruckBean(truckBean);
		request.setAttribute(PaxTraxConstants.SUCCESS,PaxTraxConstants.TRUE);
		}
		catch (TruckException truckException)
		{
			request.setAttribute(PaxTraxConstants.ERROR_CODE,""
										+truckException.getErrorCode());
		}
		PaxTraxLog.logDebug("PaxTrax::TruckAction::selectTruck::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_TRUCK_PAGE);
	}

	/**
	 * Loads truck details from the database
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 * @throws PaxTraxSystemException if there is any problem in loading the
	 * details
	 */
	public ActionForward loadTruckDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::loadTruckDetails::Begin");
		TruckForm truckForm = (TruckForm)form;
		HttpSession session = request.getSession();
		ArrayList allRecords = (ArrayList)session.getAttribute(
												PaxTraxConstants.ALL_RECORDS);	
		int index = Integer.parseInt((String)request.getParameter("indexId"));
		TruckBean truckBean = (TruckBean)allRecords.get(index-1);
		truckForm.setTruckBean(truckBean);														
		String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
		request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER,
							request.getParameter(PaxTraxConstants.PAGE_NUMBER));
		request.setAttribute(PaxTraxConstants.SUCCESS,PaxTraxConstants.TRUE);
		PaxTraxLog.logDebug("PaxTrax::TruckAction::loadTruckDetails::End");
		return mapping.findForward(PaxTraxConstants.MAINTAIN_TRUCK_PAGE);
	}

	/**
	 * This method is used to change the language
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::TruckAction::updateTruckDetails::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants
													.CHANGE_LANGUAGE_COUNTRY);
		String forward = null;
		String errorCode = (String)request.getParameter("erc");
		String success = (String)request.getParameter("suc");
		if (language != null && country != null)
		{
			super.changeLanguage(request,language,country);
		}

		HttpSession session = request.getSession();
		String page = (String)session.getAttribute(PaxTraxConstants.PAGE);
		if (PaxTraxConstants.CREATE_TRUCK_PAGE.equals(page))
		{
			if (!errorCode.equals("-1"))
			{
				request.setAttribute(PaxTraxConstants.ERROR_CODE,errorCode);
			}
			forward = PaxTraxConstants.CREATE_TRUCK_PAGE;
		}
		else if (PaxTraxConstants.TRUCK_CONFIRMATION.equals(page))
		{
			forward = PaxTraxConstants.TRUCK_CONFIRMATION;
		}
		else if (PaxTraxConstants.MAINTAIN_TRUCK_PAGE.equals(page))
		{
			String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
			String fromPageNumber = request.getParameter(PaxTraxConstants.
															FROM_PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,fromPageNumber);
			if (errorCode != null)
			{
			if (!fromPage.equals("null") && errorCode.equals("-1") )
			{
				request.setAttribute(PaxTraxConstants.SUCCESS,
													PaxTraxConstants.TRUE);
			}
			if (!errorCode.equals("-1"))
			{
				request.setAttribute(PaxTraxConstants.ERROR_CODE,errorCode);
			}
			}
			request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);
			forward = PaxTraxConstants.MAINTAIN_TRUCK_PAGE;
		}
		else if (PaxTraxConstants.MAINTAIN_TRUCK_CONFIRMATION.equals(page))
		{
			request.setAttribute(PaxTraxConstants.SUCCESS,success);
			String fromPage = request.getParameter(PaxTraxConstants.FROM_PAGE);
			request.setAttribute(PaxTraxConstants.FROM_PAGE,fromPage);
			String fromPageNumber = request.getParameter(PaxTraxConstants.
															FROM_PAGE_NUMBER);
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,fromPageNumber);
			forward = PaxTraxConstants.MAINTAIN_TRUCK_CONFIRMATION;
		}
		PaxTraxLog.logDebug("PaxTrax::TruckAction::changeLanguage::End");
		return mapping.findForward(forward);
		
	}
}
