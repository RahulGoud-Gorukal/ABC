package com.dfs.paxtrax.bagtracking.valueobject;


/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
* This is valueobject class which contains delivery manifest attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 18/06/2004    R.R.Yuvarani     Created   
*/

public class DeliveryManifestBean extends PaxTraxValueObject
{
	private String truckNumber;
	
	private String tripTime;
	
	private String tripDate;
	
	private ArrayList totalNoOfCartonsPerPickupLocation;
	
	private String totalNoOfCartons;
	
	private String totalNoOfCages;
	
	private String totalNoOfBags;
	
	private ArrayList manifestList;
	
	/* Code added as part of SR 1042 - International DF Sale Enhancement */
	/* Code added on July 17, 2006 */
	/* This property will hold the international flag */
	
	private String international = "N";
	
	/* End of code added on July 17, 2006 */
	
	/**
	 * Returns the manifestList.
	 * @return ArrayList
	 */
	public ArrayList getManifestList()
	{
		return manifestList;
	}

	/**
	 * Returns the totalNoOfBags.
	 * @return String
	 */
	public String getTotalNoOfBags()
	{
		return totalNoOfBags;
	}

	/**
	 * Returns the totalNoOfCages.
	 * @return String
	 */
	public String getTotalNoOfCages()
	{
		return totalNoOfCages;
	}

	/**
	 * Returns the totalNoOfCartons.
	 * @return String
	 */
	public String getTotalNoOfCartons()
	{
		return totalNoOfCartons;
	}

	/**
	 * Returns the tripDate.
	 * @return String
	 */
	public String getTripDate()
	{
		return tripDate;
	}

	/**
	 * Returns the tripTime.
	 * @return String
	 */
	public String getTripTime()
	{
		return tripTime;
	}

	/**
	 * Returns the truckNumber.
	 * @return String
	 */
	public String getTruckNumber()
	{
		return truckNumber;
	}

	/**
	 * Sets the manifestList.
	 * @param manifestList The manifestList to set
	 */
	public void setManifestList(ArrayList manifestList)
	{
		this.manifestList = manifestList;
	}

	/**
	 * Sets the totalNoOfBags.
	 * @param totalNoOfBags The totalNoOfBags to set
	 */
	public void setTotalNoOfBags(String totalNoOfBags)
	{
		this.totalNoOfBags = totalNoOfBags;
	}

	/**
	 * Sets the totalNoOfCages.
	 * @param totalNoOfCages The totalNoOfCages to set
	 */
	public void setTotalNoOfCages(String totalNoOfCages)
	{
		this.totalNoOfCages = totalNoOfCages;
	}

	/**
	 * Sets the totalNoOfCartons.
	 * @param totalNoOfCartons The totalNoOfCartons to set
	 */
	public void setTotalNoOfCartons(String totalNoOfCartons)
	{
		this.totalNoOfCartons = totalNoOfCartons;
	}

	/**
	 * Sets the tripDate.
	 * @param tripDate The tripDate to set
	 */
	public void setTripDate(String tripDate)
	{
		this.tripDate = tripDate;
	}

	/**
	 * Sets the tripTime.
	 * @param tripTime The tripTime to set
	 */
	public void setTripTime(String tripTime)
	{
		this.tripTime = tripTime;
	}

	/**
	 * Sets the truckNumber.
	 * @param truckNumber The truckNumber to set
	 */
	public void setTruckNumber(String truckNumber)
	{
		this.truckNumber = truckNumber;
	}

	/**
	 * Returns the totalNoOfCartonsPerPickupLocation.
	 * @return ArrayList
	 */
	public ArrayList getTotalNoOfCartonsPerPickupLocation()
	{
		return totalNoOfCartonsPerPickupLocation;
	}

	/**
	 * Sets the totalNoOfCartonsPerPickupLocation.
	 * @param totalNoOfCartonsPerPickupLocation The totalNoOfCartonsPerPickupLocation to set
	 */
	public void setTotalNoOfCartonsPerPickupLocation(ArrayList totalNoOfCartonsPerPickupLocation)
	{
		this.totalNoOfCartonsPerPickupLocation =
			totalNoOfCartonsPerPickupLocation;
	}

	/* Code added as part of SR 1042 - International DF Sale Enhancement */
	/* Code added on July 17, 2006 */
	/* This property will hold the international flag */
	
	public String getInternational() {
		return international;
	}

	/**
	 * @param string
	 */
	public void setInternational(String string) {
		international = string;
	}
	
	/* End of code added on July 17, 2006 */	

}