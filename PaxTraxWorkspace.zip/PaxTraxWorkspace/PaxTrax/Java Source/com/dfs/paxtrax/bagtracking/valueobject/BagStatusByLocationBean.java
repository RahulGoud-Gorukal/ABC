package com.dfs.paxtrax.bagtracking.valueobject;


/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */


import java.util.ArrayList;
import java.util.HashMap;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
* This is valueobject class which contains bag status by location attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Jaganmohan Gopinath
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 06/07/2007   Umamaheswari    Created   
*/

public class BagStatusByLocationBean extends PaxTraxValueObject
{
	public BagStatusByLocationBean()
	{
	}
	
	private String bagFound;
	
	private String bagLocationCode = null;

	private String bagLocationValue = null;
	
	private String departureDate = null;
	
	private ArrayList statusTotalList = null;
	
	private ArrayList bagsList = null;
	
	private HashMap bagMap = null;

	/**
	 * @return
	 */
	public String getBagFound() {
		return bagFound;
	}

	/**
	 * @return
	 */
	public String getBagLocationCode() {
		return bagLocationCode;
	}

	/**
	 * @return
	 */
	public String getBagLocationValue() {
		return bagLocationValue;
	}

	/**
	 * @return
	 */
	public ArrayList getBagsList() {
		return bagsList;
	}

	/**
	 * @return
	 */
	public String getDepartureDate() {
		return departureDate;
	}

	/**
	 * @return
	 */
	public ArrayList getStatusTotalList() {
		return statusTotalList;
	}

	/**
	 * @param string
	 */
	public void setBagFound(String string) {
		bagFound = string;
	}

	/**
	 * @param string
	 */
	public void setBagLocationCode(String string) {
		bagLocationCode = string;
	}

	/**
	 * @param string
	 */
	public void setBagLocationValue(String string) {
		bagLocationValue = string;
	}

	/**
	 * @param list
	 */
	public void setBagsList(ArrayList list) {
		bagsList = list;
	}

	/**
	 * @param string
	 */
	public void setDepartureDate(String string) {
		departureDate = string;
	}

	/**
	 * @param list
	 */
	public void setStatusTotalList(ArrayList list) {
		statusTotalList = list;
	}

	/**
	 * @return
	 */
	public HashMap getBagMap() {
		return bagMap;
	}

	/**
	 * @param map
	 */
	public void setBagMap(HashMap map) {
		bagMap = map;
	}

}
