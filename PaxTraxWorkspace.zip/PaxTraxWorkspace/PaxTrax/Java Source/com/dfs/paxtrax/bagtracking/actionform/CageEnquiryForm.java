package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.CageStatusHistoryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;




/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 24/06/2004	Cyril Prince.J	Created   
 * 02/11/2004   Joseph Oommen A	 Modified
 */
public class CageEnquiryForm extends PaxTraxActionForm
{

	private ArrayList cageNumberList = null;
	private CageStatusHistoryBean cageStatusHistoryBean = null;
	
	/**
	 * Returns the cageNumberList.
	 * @return ArrayList
	 */
	public ArrayList getCageNumberList()
	{
		return cageNumberList;
	}

	/**
	 * Returns the cageStatusHistoryBean.
	 * @return CageStatusHistoryBean
	 */
	public CageStatusHistoryBean getCageStatusHistoryBean()
	{
		return cageStatusHistoryBean;
	}

	/**
	 * Sets the cageNumberList.
	 * @param cageNumberList The cageNumberList to set
	 */
	public void setCageNumberList(ArrayList cageNumberList)
	{
		this.cageNumberList = cageNumberList;
	}

	/**
	 * Sets the cageStatusHistoryBean.
	 * @param cageStatusHistoryBean The cageStatusHistoryBean to set
	 */
	public void setCageStatusHistoryBean(CageStatusHistoryBean cageStatusHistoryBean)
	{
		this.cageStatusHistoryBean = cageStatusHistoryBean;
	}

}
