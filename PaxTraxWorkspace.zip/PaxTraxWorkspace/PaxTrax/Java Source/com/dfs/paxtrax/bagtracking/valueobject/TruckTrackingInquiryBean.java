package com.dfs.paxtrax.bagtracking.valueobject;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Truck attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 01/06/2004   Sundarrajan.K.	Created   
*/

public class TruckTrackingInquiryBean extends PaxTraxValueObject
{
	// truck number
	private String truckNumber = null;
	// trip number
	private String tripNumber = null;
	// total number of cages
	private int totalNoOfCages = 0;
	// total number of cartons
	private int totalNoOfCartons = 0;
	// total number of cages per pickup location
	private ArrayList totalNoOfCagesPerPickupLocation = null;
	// pickup location
	private String pickupLocation = null;
	// model of the truck
	private String model = null;
	// manufacturer of the truck
	private String manufacturer = null;
	// year of manufacturing
	private String year = null;
	// make of the truck
	private String make = null;
	// status history
	private ArrayList statusHistory = null;
	// cage details list
	private ArrayList cageDetailsList = null;
	
	


	/**
	 * Returns the cageDetailsList.
	 * @return ArrayList
	 */
	public ArrayList getCageDetailsList()
	{
		return cageDetailsList;
	}

	/**
	 * Returns the make.
	 * @return String
	 */
	public String getMake()
	{
		return make;
	}

	/**
	 * Returns the manufacturer.
	 * @return String
	 */
	public String getManufacturer()
	{
		return manufacturer;
	}

	/**
	 * Returns the model.
	 * @return String
	 */
	public String getModel()
	{
		return model;
	}

	/**
	 * Returns the statusHistory.
	 * @return ArrayList
	 */
	public ArrayList getStatusHistory()
	{
		return statusHistory;
	}

	/**
	 * Returns the totalNoOfCages.
	 * @return int
	 */
	public int getTotalNoOfCages()
	{
		return totalNoOfCages;
	}

	/**
	 * Returns the totalNoOfCartons.
	 * @return int
	 */
	public int getTotalNoOfCartons()
	{
		return totalNoOfCartons;
	}

	/**
	 * Returns the truckNumber.
	 * @return String
	 */
	public String getTruckNumber()
	{
		return truckNumber;
	}

	/**
	 * Returns the year.
	 * @return String
	 */
	public String getYear()
	{
		return year;
	}

	/**
	 * Sets the cageDetailsList.
	 * @param cageDetailsList The cageDetailsList to set
	 */
	public void setCageDetailsList(ArrayList cageDetailsList)
	{
		this.cageDetailsList = cageDetailsList;
	}

	/**
	 * Sets the make.
	 * @param make The make to set
	 */
	public void setMake(String make)
	{
		this.make = make;
	}

	/**
	 * Sets the manufacturer.
	 * @param manufacturer The manufacturer to set
	 */
	public void setManufacturer(String manufacturer)
	{
		this.manufacturer = manufacturer;
	}

	/**
	 * Sets the model.
	 * @param model The model to set
	 */
	public void setModel(String model)
	{
		this.model = model;
	}

	/**
	 * Sets the statusHistory.
	 * @param statusHistory The statusHistory to set
	 */
	public void setStatusHistory(ArrayList statusHistory)
	{
		this.statusHistory = statusHistory;
	}

	/**
	 * Sets the totalNoOfCages.
	 * @param totalNoOfCages The totalNoOfCages to set
	 */
	public void setTotalNoOfCages(int totalNoOfCages)
	{
		this.totalNoOfCages = totalNoOfCages;
	}

	/**
	 * Sets the totalNoOfCartons.
	 * @param totalNoOfCartons The totalNoOfCartons to set
	 */
	public void setTotalNoOfCartons(int totalNoOfCartons)
	{
		this.totalNoOfCartons = totalNoOfCartons;
	}

	/**
	 * Sets the truckNumber.
	 * @param truckNumber The truckNumber to set
	 */
	public void setTruckNumber(String truckNumber)
	{
		this.truckNumber = truckNumber;
	}

	/**
	 * Sets the year.
	 * @param year The year to set
	 */
	public void setYear(String year)
	{
		this.year = year;
	}

	/**
	 * Returns the pickupLocation.
	 * @return String
	 */
	public String getPickupLocation()
	{
		return pickupLocation;
	}

	/**
	 * Sets the pickupLocation.
	 * @param pickupLocation The pickupLocation to set
	 */
	public void setPickupLocation(String pickupLocation)
	{
		this.pickupLocation = pickupLocation;
	}

	/**
	 * Returns the tripNumber.
	 * @return String
	 */
	public String getTripNumber()
	{
		return tripNumber;
	}

	/**
	 * Sets the tripNumber.
	 * @param tripNumber The tripNumber to set
	 */
	public void setTripNumber(String tripNumber)
	{
		this.tripNumber = tripNumber;
	}

	/**
	 * Returns the totalNoOfCagesPerPickupLocation.
	 * @return ArrayList
	 */
	public ArrayList getTotalNoOfCagesPerPickupLocation()
	{
		return totalNoOfCagesPerPickupLocation;
	}

	/**
	 * Sets the totalNoOfCagesPerPickupLocation.
	 * @param totalNoOfCagesPerPickupLocation The totalNoOfCagesPerPickupLocation to set
	 */
	public void setTotalNoOfCagesPerPickupLocation(ArrayList totalNoOfCagesPerPickupLocation)
	{
		this.totalNoOfCagesPerPickupLocation = totalNoOfCagesPerPickupLocation;
	}

}