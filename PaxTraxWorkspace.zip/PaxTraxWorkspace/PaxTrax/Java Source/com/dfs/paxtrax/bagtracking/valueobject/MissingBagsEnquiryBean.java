package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
 * This is valueobject class which contains bin location attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *           DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE          USER            COMMENTS
 * 18/05/2004    Joseph Oommen	 Created   
 */

public class MissingBagsEnquiryBean extends PaxTraxValueObject
{

	private String bagStatus = null;
	private String fromDepartureDate = null;
	private String toDepartureDate = null;
	private int totalNoOfItems = 0;
	private String lastKnownLocation = null;
	private String bagFound = null;
	private String remarks = null;
	private String bagNumber = null;
	


	/**
	 * Returns the bagStatus.
	 * @return String
	 */
	public String getBagStatus()
	{
		return bagStatus;
	}

	/**
	 * Returns the fromDepartureDate.
	 * @return String
	 */
	public String getFromDepartureDate()
	{
		return fromDepartureDate;
	}

	/**
	 * Returns the lastKnownLocation.
	 * @return String
	 */
	public String getLastKnownLocation()
	{
		return lastKnownLocation;
	}

	/**
	 * Returns the remarks.
	 * @return String
	 */
	public String getRemarks()
	{
		return remarks;
	}

	/**
	 * Returns the toDepartureDate.
	 * @return String
	 */
	public String getToDepartureDate()
	{
		return toDepartureDate;
	}

	/**
	 * Returns the totalNoOfItems.
	 * @return int
	 */
	public int getTotalNoOfItems()
	{
		return totalNoOfItems;
	}

	/**
	 * Sets the bagStatus.
	 * @param bagStatus The bagStatus to set
	 */
	public void setBagStatus(String bagStatus)
	{
		this.bagStatus = bagStatus;
	}

	/**
	 * Sets the fromDepartureDate.
	 * @param fromDepartureDate The fromDepartureDate to set
	 */
	public void setFromDepartureDate(String fromDepartureDate)
	{
		this.fromDepartureDate = fromDepartureDate;
	}

	/**
	 * Sets the lastKnownLocation.
	 * @param lastKnownLocation The lastKnownLocation to set
	 */
	public void setLastKnownLocation(String lastKnownLocation)
	{
		this.lastKnownLocation = lastKnownLocation;
	}

	/**
	 * Sets the remarks.
	 * @param remarks The remarks to set
	 */
	public void setRemarks(String remarks)
	{
		this.remarks = remarks;
	}

	/**
	 * Sets the toDepartureDate.
	 * @param toDepartureDate The toDepartureDate to set
	 */
	public void setToDepartureDate(String toDepartureDate)
	{
		this.toDepartureDate = toDepartureDate;
	}

	/**
	 * Sets the totalNoOfItems.
	 * @param totalNoOfItems The totalNoOfItems to set
	 */
	public void setTotalNoOfItems(int totalNoOfItems)
	{
		this.totalNoOfItems = totalNoOfItems;
	}

	/**
	 * Returns the bagNumber.
	 * @return String
	 */
	public String getBagNumber()
	{
		return bagNumber;
	}

	/**
	 * Sets the bagNumber.
	 * @param bagNumber The bagNumber to set
	 */
	public void setBagNumber(String bagNumber)
	{
		this.bagNumber = bagNumber;
	}

	/**
	 * Returns the bagFound.
	 * @return String
	 */
	public String getBagFound() {
		return bagFound;
	}

	/**
	 * Sets the bagFound.
	 * @param bagFound The bagFound to set
	 */
	public void setBagFound(String bagFound) {
		this.bagFound = bagFound;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("\n bagNumber = "+ bagNumber);
		buffer.append("bagStatus = "+bagStatus);
		buffer.append("\n fromDepartureDate = "+fromDepartureDate);
		buffer.append("\n toDepartureDate = "+toDepartureDate);
		buffer.append("\n  totalNoOfItems = "+totalNoOfItems);
		buffer.append("\n lastKnownLocation = "+lastKnownLocation);
		buffer.append("\n bagFound = "+bagFound);
		buffer.append("\n remarks = "+remarks);
		return buffer.toString();
	}

}