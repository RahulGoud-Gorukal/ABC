package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
/**
 * This is action form which contains Pax Refund attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 26/07/2004   Joseph Oommen A     Created   
*/

public class PaxRefundBean extends PaxTraxValueObject
implements Cloneable
{

	String fromDate = null;
	String toDate = null;
	String notificationType = null;
	String notificationStatus = null;
	String displayNotificationStatus =null;
	
	int recordId = 0;
	int flightChangeSeqId = 0;
	
	String paxCodeId = null;
	
	ArrayList itemNumber = null;
	String flightOrBag = null;
	String actionTaken = null;
	boolean actionDisabled = true;
	String printAction = null;
	FlightDetailsBean fromFlightBean = null;
	FlightDetailsBean toFlightBean = null;
	BagStatusBean bagStatusBean = null;
	
	String paxNo = null;
	String paxSeqId = null;
	
	String refundTimeStamp = null;
	/**
	 * Returns the actionDisabled.
	 * @return boolean
	 */
	public boolean getActionDisabled()
	{
		return actionDisabled;
	}

	/**
	 * Returns the actionTaken.
	 * @return String
	 */
	public String getActionTaken()
	{
		return actionTaken;
	}

	/**
	 * Returns the bagStatusBean.
	 * @return BagStatusBean
	 */
	public BagStatusBean getBagStatusBean()
	{
		return bagStatusBean;
	}

	/**
	 * Returns the displayNotificationStatus.
	 * @return String
	 */
	public String getDisplayNotificationStatus()
	{
		return displayNotificationStatus;
	}

	/**
	 * Returns the flightOrBag.
	 * @return String
	 */
	public String getFlightOrBag()
	{
		return flightOrBag;
	}

	/**
	 * Returns the fromDate.
	 * @return String
	 */
	public String getFromDate()
	{
		return fromDate;
	}

	/**
	 * Returns the fromFlightBean.
	 * @return FlightDetailsBean
	 */
	public FlightDetailsBean getFromFlightBean()
	{
		return fromFlightBean;
	}

	/**
	 * Returns the itemNumber.
	 * @return ArrayList
	 */
	public ArrayList getItemNumber()
	{
		return itemNumber;
	}

	/**
	 * Returns the notificationStatus.
	 * @return String
	 */
	public String getNotificationStatus()
	{
		return notificationStatus;
	}

	/**
	 * Returns the notificationType.
	 * @return String
	 */
	public String getNotificationType()
	{
		return notificationType;
	}

	/**
	 * Returns the paxCodeId.
	 * @return String
	 */
	public String getPaxCodeId()
	{
		return paxCodeId;
	}

	/**
	 * Returns the printAction.
	 * @return String
	 */
	public String getPrintAction()
	{
		return printAction;
	}

	/**
	 * Returns the toDate.
	 * @return String
	 */
	public String getToDate()
	{
		return toDate;
	}

	/**
	 * Returns the toFlightBean.
	 * @return FlightDetailsBean
	 */
	public FlightDetailsBean getToFlightBean()
	{
		return toFlightBean;
	}

	/**
	 * Sets the actionDisabled.
	 * @param actionDisabled The actionDisabled to set
	 */
	public void setActionDisabled(boolean actionDisabled)
	{
		this.actionDisabled = actionDisabled;
	}

	/**
	 * Sets the actionTaken.
	 * @param actionTaken The actionTaken to set
	 */
	public void setActionTaken(String actionTaken)
	{
		this.actionTaken = actionTaken;
	}

	/**
	 * Sets the bagStatusBean.
	 * @param bagStatusBean The bagStatusBean to set
	 */
	public void setBagStatusBean(BagStatusBean bagStatusBean)
	{
		this.bagStatusBean = bagStatusBean;
	}

	/**
	 * Sets the displayNotificationStatus.
	 * @param displayNotificationStatus The displayNotificationStatus to set
	 */
	public void setDisplayNotificationStatus(String displayNotificationStatus)
	{
		this.displayNotificationStatus = displayNotificationStatus;
	}

	/**
	 * Sets the flightOrBag.
	 * @param flightOrBag The flightOrBag to set
	 */
	public void setFlightOrBag(String flightOrBag)
	{
		this.flightOrBag = flightOrBag;
	}

	/**
	 * Sets the fromDate.
	 * @param fromDate The fromDate to set
	 */
	public void setFromDate(String fromDate)
	{
		this.fromDate = fromDate;
	}

	/**
	 * Sets the fromFlightBean.
	 * @param fromFlightBean The fromFlightBean to set
	 */
	public void setFromFlightBean(FlightDetailsBean fromFlightBean)
	{
		this.fromFlightBean = fromFlightBean;
	}

	/**
	 * Sets the itemNumber.
	 * @param itemNumber The itemNumber to set
	 */
	public void setItemNumber(ArrayList itemNumber)
	{
		this.itemNumber = itemNumber;
	}

	/**
	 * Sets the notificationStatus.
	 * @param notificationStatus The notificationStatus to set
	 */
	public void setNotificationStatus(String notificationStatus)
	{
		this.notificationStatus = notificationStatus;
	}

	/**
	 * Sets the notificationType.
	 * @param notificationType The notificationType to set
	 */
	public void setNotificationType(String notificationType)
	{
		this.notificationType = notificationType;
	}

	/**
	 * Sets the paxCodeId.
	 * @param paxCodeId The paxCodeId to set
	 */
	public void setPaxCodeId(String paxCodeId)
	{
		this.paxCodeId = paxCodeId;
	}

	/**
	 * Sets the printAction.
	 * @param printAction The printAction to set
	 */
	public void setPrintAction(String printAction)
	{
		this.printAction = printAction;
	}

	/**
	 * Sets the toDate.
	 * @param toDate The toDate to set
	 */
	public void setToDate(String toDate)
	{
		this.toDate = toDate;
	}

	/**
	 * Sets the toFlightBean.
	 * @param toFlightBean The toFlightBean to set
	 */
	public void setToFlightBean(FlightDetailsBean toFlightBean)
	{
		this.toFlightBean = toFlightBean;
	}

	/**
	 * Returns the recordId.
	 * @return int
	 */
	public int getRecordId()
	{
		return recordId;
	}

	/**
	 * Sets the recordId.
	 * @param recordId The recordId to set
	 */
	public void setRecordId(int recordId)
	{
		this.recordId = recordId;
	}

	/**
	 * Returns the flightChangeSeqId.
	 * @return int
	 */
	public int getFlightChangeSeqId()
	{
		return flightChangeSeqId;
	}

	/**
	 * Sets the flightChangeSeqId.
	 * @param flightChangeSeqId The flightChangeSeqId to set
	 */
	public void setFlightChangeSeqId(int flightChangeSeqId)
	{
		this.flightChangeSeqId = flightChangeSeqId;
	}

	/**
	 * Returns the paxNo.
	 * @return String
	 */
	public String getPaxNo()
	{
		return paxNo;
	}

	/**
	 * Returns the paxSeqId.
	 * @return String
	 */
	public String getPaxSeqId()
	{
		return paxSeqId;
	}

	/**
	 * Sets the paxNo.
	 * @param paxNo The paxNo to set
	 */
	public void setPaxNo(String paxNo)
	{
		this.paxNo = paxNo;
	}

	/**
	 * Sets the paxSeqId.
	 * @param paxSeqId The paxSeqId to set
	 */
	public void setPaxSeqId(String paxSeqId)
	{
		this.paxSeqId = paxSeqId;
	}

	/**
	 * @see java.lang.Object#clone()
	 */
	public Object clone() throws CloneNotSupportedException {
		return (super.clone());
	}	


	/**
	 * Returns the refundTimeStamp.
	 * @return String
	 */
	public String getRefundTimeStamp()
	{
		return refundTimeStamp;
	}

	/**
	 * Sets the refundTimeStamp.
	 * @param refundTimeStamp The refundTimeStamp to set
	 */
	public void setRefundTimeStamp(String refundTimeStamp)
	{
		this.refundTimeStamp = refundTimeStamp;
	}

}	