package com.dfs.paxtrax.bagtracking.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.bagtracking.exception.BinLocationException;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationBean;
import com.dfs.paxtrax.common.exception.PaxTraxException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;

/**
 * The remote interface of the BinLocBOBean
 * 
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/05/2004	Yuvarani    	Created   
 */

public interface BinLocationBO extends EJBObject{
    
	/**
	 * Saves Bin Location details in the database
	 * @param binLocationBean BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in saving
	 * @throws RemoteException
	 */
    public void saveBinLocationDetails(BinLocationBean binLocationBean)
    	throws PaxTraxSystemException,RemoteException,BinLocationException;
    
	/**
	 * Updates bin location details in the database
	 * @param binLocationBean BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in updation
	 * @throws RemoteException
	 */
    public void updateBinLocationDetails(BinLocationBean binLocationBean) 
    	throws PaxTraxSystemException,RemoteException,BinLocationException;
    
	/**
	 * Removes BinLocationDetails from the database.
	 * @param binLocationBean BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in deletion
	 * @throws RemoteException
	 */
    public void removeBinLocationDetails(BinLocationBean binLocationBean) 
    	throws PaxTraxSystemException,RemoteException,BinLocationException;
    
	/**
	 * This method searches for bin location that satisfies the given criteria
	 * @param binLocationBean BinLocationBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException if there is any problem while searching
	 * @throws RemoteException
	 */
    public ArrayList searchBinLocationDetails(BinLocationBean binLocationBean) 
    	throws PaxTraxSystemException,RemoteException;
    	
	/**
	 * Gets BinLocationDetails from the database.
	 * @param binBean BinLocationBean
	 * @return BinLocationBean
	 * @throws PaxTraxSystemException if there is any problem in retriving data
	 * @throws RemoteException
	 * @throws BinLocationException if the location does not exist
	 */
	public BinLocationBean getBinLocationDetails(BinLocationBean binBean)
		throws PaxTraxSystemException,RemoteException,BinLocationException;

}
