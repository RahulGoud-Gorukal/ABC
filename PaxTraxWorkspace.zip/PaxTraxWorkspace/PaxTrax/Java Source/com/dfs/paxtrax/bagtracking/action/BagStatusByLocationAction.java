package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.BagStatusByLocationForm;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByLocationBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
*  This is action class which provides the details for Bag Status By Location
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Jaganmohan Gopinath
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 06/07/2007	Umamaheswari	Created	
*/

public class BagStatusByLocationAction extends PaxTraxAction
{
	String forward = null;
	/**
	 * Loads the report page by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in creating the Bag Status By Location Report Page
	 */
	public ActionForward goToBagStatusByLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::goToBagStatusByLocation::Begin");
		BagStatusByLocationForm bagStatusByLocationForm = (BagStatusByLocationForm) form;
		BagStatusByLocationBean bagStatusLocationBean = new BagStatusByLocationBean();
		//ReferenceDataDelegate referData = new ReferenceDataDelegate();
		BagTrackingReportsDelegate bagStatusDelegate = new BagTrackingReportsDelegate();
				
		try
		{
			ArrayList bagLocationList =	bagStatusDelegate.loadConfigData(PaxTraxConstants.BAG_LOCATION_CODE);
			Calendar cal = Calendar.getInstance();
			int day = cal.get(Calendar.DATE);
			int month = cal.get(Calendar.MONTH) + 1;
			int year = cal.get(Calendar.YEAR);
			
			String currentDate = "";
			currentDate = "" + year + "/" + (month<10 ? "0" + month : "" + month) + "/" + (day<10 ? "0" + day : "" + day);
			bagStatusLocationBean.setDepartureDate(currentDate);
			bagStatusLocationBean.setBagLocationCode(PaxTraxConstants.AIRPORT_CODE);
			bagStatusByLocationForm.setBagStatusLocationBean(bagStatusLocationBean);
			bagStatusByLocationForm.setBagLocationList(bagLocationList);
			forward = PaxTraxConstants.BAG_STATUS_BY_LOCATION;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logError("PaxTrax::BagStatusByLocationAction::goToBagStatusByLocation::Exception::",paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::goToBagStatusByLocation::End");
		return mapping.findForward(forward);
	}
	
	/**
	 * Retrieves the search result list for the bag location status by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in retrieving bag status details
	 */
	public ActionForward getBagStatusByLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getBagStatusByLocation::Begin");
		
		int pageNumber = 0 ;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		HttpSession session = request.getSession();		
		BagStatusByLocationForm bagStatusByLocationForm = (BagStatusByLocationForm) form;
		BagStatusByLocationBean bagStatusLocationBean = bagStatusByLocationForm.getBagStatusLocationBean();
		BagTrackingReportsDelegate bagStatusDelegate = new BagTrackingReportsDelegate();
		
		try
		{
			String pageNumberStr = request.getParameter(PaxTraxConstants.PAGE_NUMBER);
			PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getBagStatusByLocation::pageNumber"+pageNumberStr);
			/* If page number is null or empty it sets null otherwise 
			 * it is same
			 */
			pageNumberStr = ((pageNumberStr == null) || pageNumberStr.equals(SQLConstants.BLANK))
																			? null : pageNumberStr;
			if ((pageNumberStr != null))
			{
				pageNumber = Integer.parseInt(pageNumberStr);
			}			
			
			/* First time goes to Database and fetches the data and next time
			 * it will fetch record from session
			 */

			if (pageNumber == 0)
			{
				PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getBagStatusByLocation::insideif");
				int size = 0;
				int bagSize = 0;
				pageNumber = 1;
				
				bagStatusLocationBean = bagStatusDelegate.getBagStatusByLocation(bagStatusLocationBean);
				if ((bagStatusLocationBean.getStatusTotalList() == null	&& bagStatusLocationBean.getBagsList() == null)
					|| (bagStatusLocationBean.getStatusTotalList().size() == 0 && bagStatusLocationBean.getBagsList().size() == 0))
				{
					request.setAttribute(PaxTraxConstants.ERROR_CODE,PaxTraxConstants.ERROR_CODE);
				}				

				allRecords = bagStatusLocationBean.getBagsList();
				if (allRecords != null)
				{
					size = allRecords.size();
				}
				PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getBagStatusByLocation::sizeofRecords"+ allRecords.size());

				session.removeAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS);
				session.setAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS,allRecords);
				session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_CUSTOMSBAG_RECORDS);
				session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_CUSTOMSBAG_RECORDS,Integer.toString(size));
			}
			else
			{
				allRecords = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS);
			}
			
			PaginationHelper helper = PaginationHelper.getInstance();
			if ((allRecords != null) && (allRecords.size() != 0))
			{
				currentRecords = helper.getCurrentTableContent(allRecords,pageNumber,PaxTraxConstants.RECORDS_PER_PAGE);
				request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
				PaxTraxLog.logDebug(
							"Paxtrax::BagByBagStatusAction::getBagByBagStatusReport::current records size is" + currentRecords.size());
			}
			request.setAttribute(PaxTraxConstants.PAGE_NUMBER,Integer.toString(pageNumber));
			bagStatusLocationBean.setBagsList(currentRecords);		

			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
			bagStatusByLocationForm.setBagStatusLocationBean(bagStatusLocationBean);
			forward = PaxTraxConstants.BAG_STATUS_BY_LOCATION;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logDebug("PaxTrax::BagStatusByLocationAction::getBagStatusByLocation",paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getBagStatusByLocation::End");
		return mapping.findForward(forward);
	}

	/**
	 * Retrieves the search result status list for the bag location status 
	 * by calling delegate method.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 * @throws PaxTraxSystemException This exception is thrown
	 * if there is any problem in retrieving bag status details
	 */
	public ActionForward getStatusRecords(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws BagTrackingReportsException,PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagStatusByLocationAction::getStatusRecords::Begin");
		int pageNumber = 0 ;
		ArrayList allRecords = null;
		ArrayList currentRecords = null;
		HttpSession session = request.getSession();	
		ArrayList bagList = new ArrayList();
		String status = request.getParameter(PaxTraxConstants.OPERATION);
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getStatusRecords::status"+status);
		BagStatusByLocationForm bagStatusByLocationForm = (BagStatusByLocationForm) form;
		BagStatusByLocationBean bagStatusLocationBean = bagStatusByLocationForm.getBagStatusLocationBean();
		
		String pageNumberStr = request.getParameter(PaxTraxConstants.FILTER_PAGE_NUMBER);
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getStatusRecords::pageNumber"+pageNumberStr);
		/* If page number is null or empty it sets null otherwise 
		 * it is same
		 */
		pageNumberStr = ((pageNumberStr == null) || pageNumberStr.equals(SQLConstants.BLANK))
																		? null : pageNumberStr;
		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */

		if (pageNumber == 0)
		{
			PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getStatusRecords::insideif");
			int size = 0;
			int bagSize = 0;
			pageNumber = 1;
				
			HashMap bagMap = bagStatusLocationBean.getBagMap();

			if(bagMap.containsKey(status))
			{
				bagList = (ArrayList) bagMap.get(status);
				bagStatusLocationBean.setBagsList(bagList);
			}
			allRecords = bagStatusLocationBean.getBagsList();
			if (allRecords != null)
			{
				size = allRecords.size();
			}
			PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getStatusRecords::sizeofRecords"+ allRecords.size());

			session.removeAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS);
			session.setAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS,allRecords);
			session.removeAttribute(PaxTraxConstants.SIZE_OF_ALL_CUSTOMSBAG_RECORDS);
			session.setAttribute(PaxTraxConstants.SIZE_OF_ALL_CUSTOMSBAG_RECORDS,Integer.toString(size));
		}		
		else
		{
			allRecords = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS);
			if((allRecords != null) && (allRecords.size() != 0))
			{
				BagStatusBean bag = (BagStatusBean) allRecords.get(1);
				status = bag.getStatus();
			}
		}
		
		PaginationHelper helper = PaginationHelper.getInstance();
		if ((allRecords != null) && (allRecords.size() != 0))
		{
			currentRecords = helper.getCurrentTableContent(allRecords,pageNumber,PaxTraxConstants.RECORDS_PER_PAGE);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
			PaxTraxLog.logDebug(
						"Paxtrax::BagByBagStatusAction::getStatusRecords::current records size is" + currentRecords.size());
		}
		request.setAttribute(PaxTraxConstants.FILTER_PAGE_NUMBER,Integer.toString(pageNumber));
		bagStatusLocationBean.setBagsList(currentRecords);	

		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getStatusRecords::listsize"+bagList.size());		
		request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		request.setAttribute(PaxTraxConstants.OPERATION,status);
		bagStatusByLocationForm.setBagStatusLocationBean(bagStatusLocationBean);
		forward = PaxTraxConstants.BAG_STATUS_BY_LOCATION;
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::getStatusRecords::End");
		return mapping.findForward(forward);
	}

	/**
	 * Prints the search result list for the bag location status.
	 * @param mapping ActionMapping
	 * @param form ActionForm
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */	
	public ActionForward printBagStatusByLocation(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::printBagStatusByLocation::Begin");
		ArrayList bagList = new ArrayList();
		HttpSession session = request.getSession();
		BagStatusByLocationForm bagStatusByLocationForm = (BagStatusByLocationForm)form;
		BagStatusByLocationBean bagStatusLocationBean = bagStatusByLocationForm.getBagStatusLocationBean();
		
		String operation = (String) request.getParameter("operation1");

		String result = (String) request.getParameter("result1");
		if (operation != null
			&& !operation.equals("")
			&& !operation.equals("null"))
		{
			operation = operation.trim();
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}

		if (result != null && !result.equals("") && !result.equals("null"))
		{
			result = result.trim();
			request.setAttribute(PaxTraxConstants.RESULT, result);
		}		
		bagList = (ArrayList) session.getAttribute(PaxTraxConstants.ALL_CUSTOMSBAG_RECORDS);
		bagStatusLocationBean.setBagsList(bagList);
		ArrayList bagStatusList = bagStatusByLocationForm.getBagLocationList();
		String bagStatus = bagStatusByLocationForm.getBagStatusLocationBean().getBagLocationCode();
		for (int i = 0; i < bagStatusList.size(); i++)
		{
			ReferenceDataBean tempBean = (ReferenceDataBean) bagStatusList.get(i);
			if (bagStatus.equals(tempBean.getCodeId()))
			{
				bagStatusByLocationForm.getBagStatusLocationBean().setBagLocationValue(tempBean.getCodeValue());
				break;
			}
		}			
		bagStatusByLocationForm.setBagStatusLocationBean(bagStatusLocationBean);		
		PaxTraxLog.logDebug("Paxtrax::BagStatusByLocationAction::printBagStatusByLocation::End");
		return mapping.findForward(PaxTraxConstants.PRINT_BAG_STATUS_LOCATION_REPORT);
	}

}