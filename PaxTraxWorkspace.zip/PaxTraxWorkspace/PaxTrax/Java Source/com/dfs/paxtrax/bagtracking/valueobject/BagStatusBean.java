package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

/**
 * This is valueobject class which contains Bag/Cage attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *           DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE          USER            COMMENTS
 * 26/06/2004    Joseph Oommen A Created   
 * 29/08/2005    P.C. Sathish 	Modified
 */
public class BagStatusBean extends PaxTraxValueObject
{
	private String bagNumber = null;
	private PAXBean paxBean =null;
	private String paxNumber = null;
	private String lastName = null;
	private String firstName = null;
	private int statusId = 0;
	private String status = null;
	private String carton = null;
	private String moduleId = null;
	private String whBinLocation = null;
	private String cage = null;
	private String shelf = null;
	private String truck = null;
	private String tripId = null;
	private String apBinLocation = null;
	private String statusDateTime = null;
	private String terminal = null;
	private String operator = null;
	private String cartonCycleId = null;
	private String cageCycleId = null;
	private String truckDeparted = "N";
	private int tripQuantity = 0;
	private boolean totalQuantity = false;
	private boolean title = false;
	private boolean grandTotalQuantity = false;
	private String itemCode = null;
	private String quantity = null;
	private double itemPrice;	
	
	/* holds sku details for the bag */
	
	private boolean refunded = false;
	private String tripTime = null;
	//Added by selvam for CA# 294102 starts
	private String cartonNumber = null;
	private String cageNumber = null;
	private int bagStatus = 0;
	// Added/Modified by David for CR 3659 starts	
	private String index = null;
	private String bagStatusId=null;
	private String flightNumber = null;
	private String flightDate=null;
	// Added/Modified by David for CR 3659 ends
	//Added by selvam for CA# 294102 ends
	

	/**
	 * Returns the apBinLocation.
	 * @return String
	 */
	public String getApBinLocation()
	{
		return apBinLocation;
	}

	/**
	 * Returns the bagNumber.
	 * @return String
	 */
	public String getBagNumber()
	{
		return bagNumber;
	}

	/**
	 * Returns the cage.
	 * @return String
	 */
	public String getCage()
	{
		return cage;
	}

	/**
	 * Returns the cageCycleId.
	 * @return String
	 */
	public String getCageCycleId()
	{
		return cageCycleId;
	}

	/**
	 * Returns the carton.
	 * @return String
	 */
	public String getCarton()
	{
		return carton;
	}

	/**
	 * Returns the cartonCycleId.
	 * @return String
	 */
	public String getCartonCycleId()
	{
		return cartonCycleId;
	}

	/**
	 * Returns the firstName.
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Returns the lastName.
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Returns the moduleId.
	 * @return String
	 */
	public String getModuleId()
	{
		return moduleId;
	}

	/**
	 * Returns the operator.
	 * @return String
	 */
	public String getOperator()
	{
		return operator;
	}

	/**
	 * Returns the paxNumber.
	 * @return String
	 */
	public String getPaxNumber()
	{
		return paxNumber;
	}

	/**
	 * Returns the shelf.
	 * @return String
	 */
	public String getShelf()
	{
		return shelf;
	}

	/**
	 * Returns the status.
	 * @return String
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * Returns the statusDateTime.
	 * @return String
	 */
	public String getStatusDateTime()
	{
		return statusDateTime;
	}

	/**
	 * Returns the statusId.
	 * @return int
	 */
	public int getStatusId()
	{
		return statusId;
	}

	/**
	 * Returns the terminal.
	 * @return String
	 */
	public String getTerminal()
	{
		return terminal;
	}

	/**
	 * Returns the tripId.
	 * @return String
	 */
	public String getTripId()
	{
		return tripId;
	}

	/**
	 * Returns the truck.
	 * @return String
	 */
	public String getTruck()
	{
		return truck;
	}

	/**
	 * Returns the whBinLocation.
	 * @return String
	 */
	public String getWhBinLocation()
	{
		return whBinLocation;
	}

	/**
	 * Sets the apBinLocation.
	 * @param apBinLocation The apBinLocation to set
	 */
	public void setApBinLocation(String apBinLocation)
	{
		this.apBinLocation = apBinLocation;
	}

	/**
	 * Sets the bagNumber.
	 * @param bagNumber The bagNumber to set
	 */
	public void setBagNumber(String bagNumber)
	{
		this.bagNumber = bagNumber;
	}

	/**
	 * Sets the cage.
	 * @param cage The cage to set
	 */
	public void setCage(String cage)
	{
		this.cage = cage;
	}

	/**
	 * Sets the cageCycleId.
	 * @param cageCycleId The cageCycleId to set
	 */
	public void setCageCycleId(String cageCycleId)
	{
		this.cageCycleId = cageCycleId;
	}

	/**
	 * Sets the carton.
	 * @param carton The carton to set
	 */
	public void setCarton(String carton)
	{
		this.carton = carton;
	}

	/**
	 * Sets the cartonCycleId.
	 * @param cartonCycleId The cartonCycleId to set
	 */
	public void setCartonCycleId(String cartonCycleId)
	{
		this.cartonCycleId = cartonCycleId;
	}

	/**
	 * Sets the firstName.
	 * @param firstName The firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Sets the lastName.
	 * @param lastName The lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(String moduleId)
	{
		this.moduleId = moduleId;
	}

	/**
	 * Sets the operator.
	 * @param operator The operator to set
	 */
	public void setOperator(String operator)
	{
		this.operator = operator;
	}

	/**
	 * Sets the paxNumber.
	 * @param paxNumber The paxNumber to set
	 */
	public void setPaxNumber(String paxNumber)
	{
		this.paxNumber = paxNumber;
	}

	/**
	 * Sets the shelf.
	 * @param shelf The shelf to set
	 */
	public void setShelf(String shelf)
	{
		this.shelf = shelf;
	}

	/**
	 * Sets the status.
	 * @param status The status to set
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * Sets the statusDateTime.
	 * @param statusDateTime The statusDateTime to set
	 */
	public void setStatusDateTime(String statusDateTime)
	{
		this.statusDateTime = statusDateTime;
	}

	/**
	 * Sets the statusId.
	 * @param statusId The statusId to set
	 */
	public void setStatusId(int statusId)
	{
		this.statusId = statusId;
	}

	/**
	 * Sets the terminal.
	 * @param terminal The terminal to set
	 */
	public void setTerminal(String terminal)
	{
		this.terminal = terminal;
	}

	/**
	 * Sets the tripId.
	 * @param tripId The tripId to set
	 */
	public void setTripId(String tripId)
	{
		this.tripId = tripId;
	}

	/**
	 * Sets the truck.
	 * @param truck The truck to set
	 */
	public void setTruck(String truck)
	{
		this.truck = truck;
	}

	/**
	 * Sets the whBinLocation.
	 * @param whBinLocation The whBinLocation to set
	 */
	public void setWhBinLocation(String whBinLocation)
	{
		this.whBinLocation = whBinLocation;
	}

	/**
	 * Returns the paxBean.
	 * @return PAXBean
	 */
	public PAXBean getPaxBean()
	{
		return paxBean;
	}

	/**
	 * Sets the paxBean.
	 * @param paxBean The paxBean to set
	 */
	public void setPaxBean(PAXBean paxBean)
	{
		this.paxBean = paxBean;
	}

	/**
	 * Returns the truckDeparted.
	 * @return String
	 */
	public String getTruckDeparted() {
		return truckDeparted;
	}

	/**
	 * Sets the truckDeparted.
	 * @param truckDeparted The truckDeparted to set
	 */
	public void setTruckDeparted(String truckDeparted) {
		this.truckDeparted = truckDeparted;
	}

	/**
	 * Returns the totalQuantity.
	 * @return boolean
	 */
	public boolean isTotalQuantity() {
		return totalQuantity;
	}

	/**
	 * Returns the tripQuantity.
	 * @return int
	 */
	public int getTripQuantity() {
		return tripQuantity;
	}

	/**
	 * Sets the totalQuantity.
	 * @param totalQuantity The totalQuantity to set
	 */
	public void setTotalQuantity(boolean totalQuantity) {
		this.totalQuantity = totalQuantity;
	}

	/**
	 * Sets the tripQuantity.
	 * @param tripQuantity The tripQuantity to set
	 */
	public void setTripQuantity(int tripQuantity) {
		this.tripQuantity = tripQuantity;
	}

	/**
	 * Returns the refunded.
	 * @return boolean
	 */
	public boolean getRefunded() {
		return refunded;
	}

	/**
	 * Sets the refunded.
	 * @param refunded The refunded to set
	 */
	public void setRefunded(boolean refunded) {
		this.refunded = refunded;
	}

	/**
	 * Returns the title.
	 * @return boolean
	 */
	public boolean isTitle() {
		return title;
	}

	/**
	 * Sets the title.
	 * @param title The title to set
	 */
	public void setTitle(boolean title) {
		this.title = title;
	}

	/**
	 * Returns the grandTotalQuantity.
	 * @return boolean
	 */
	public boolean isGrandTotalQuantity() {
		return grandTotalQuantity;
	}

	/**
	 * Sets the grandTotalQuantity.
	 * @param grandTotalQuantity The grandTotalQuantity to set
	 */
	public void setGrandTotalQuantity(boolean grandTotalQuantity) {
		this.grandTotalQuantity = grandTotalQuantity;
	}

	/**
	 * Returns the tripTime.
	 * @return String
	 */
	public String getTripTime() {
		return tripTime;
	}

	/**
	 * Sets the tripTime.
	 * @param tripTime The tripTime to set
	 */
	public void setTripTime(String tripTime) {
		this.tripTime = tripTime;
	}

	/**
	 * Returns the itemCode.
	 * @return String
	 */
	public String getItemCode() {
		return itemCode;
	}

	/**
	 * Returns the itemPrice.
	 * @return double
	 */
	public double getItemPrice() {
		return itemPrice;
	}

	/**
	 * Returns the quantity.
	 * @return String
	 */
	public String getQuantity() {
		return quantity;
	}

	/**
	 * Sets the itemCode.
	 * @param itemCode The itemCode to set
	 */
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	/**
	 * Sets the itemPrice.
	 * @param itemPrice The itemPrice to set
	 */
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	/**
	 * Sets the quantity.
	 * @param quantity The quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
//	Added by selvam for CA# 294102 starts
	/**
	 * @return
	 */
	public String getCageNumber() {
		return cageNumber;
	}

	/**
	 * @return
	 */
	public String getCartonNumber() {
		return cartonNumber;
	}

	/**
	 * @param string
	 */
	public void setCageNumber(String string) {
		cageNumber = string;
	}

	/**
	 * @param string
	 */
	public void setCartonNumber(String string) {
		cartonNumber = string;
	}

	/**
	 * @return
	 */
	public int getBagStatus() {
		return bagStatus;
	}

	/**
	 * @param i
	 */
	public void setBagStatus(int i) {
		bagStatus = i;
	}
//	Added by selvam for CA# 294102 ends
	/**
	 * @return
	 */
	public String getIndex() {
		return index;
	}

	/**
	 * @param string
	 */
	public void setIndex(String string) {
		index = string;
	}

	/**
	 * @return
	 */
	public String getBagStatusId() {
		return bagStatusId;
	}

	/**
	 * @param string
	 */
	public void setBagStatusId(String string) {
		bagStatusId = string;
	}

	/**
	 * @return
	 */
	public String getFlightDate() {
		return flightDate;
	}

	/**
	 * @return
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * @param string
	 */
	public void setFlightDate(String string) {
		flightDate = string;
	}

	/**
	 * @param string
	 */
	public void setFlightNumber(String string) {
		flightNumber = string;
	}

}
