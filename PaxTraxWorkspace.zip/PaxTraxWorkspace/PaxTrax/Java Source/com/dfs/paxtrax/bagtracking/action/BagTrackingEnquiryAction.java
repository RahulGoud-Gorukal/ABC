package com.dfs.paxtrax.bagtracking.action;

import java.util.Calendar;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.BagTrackingEnquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagTrackingEnquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.valueobject.AddressBean;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

public class BagTrackingEnquiryAction extends PaxTraxAction 
{
	public ActionForward gotoBagTrackingInquiryPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
	{
		BagTrackingEnquiryForm btEnquiryForm = (BagTrackingEnquiryForm)form;
		BagTrackingEnquiryBean btEnquiryBean = new BagTrackingEnquiryBean();
		btEnquiryBean.setTotalNumberOfItems("0");
		BagStatusBean bagStatusBean = new BagStatusBean();
		PAXBean paxBean = new PAXBean();
		paxBean.setAddress(new AddressBean());
		paxBean.setDepartureFlightDetails(new FlightDetailsBean());
		bagStatusBean.setPaxBean(paxBean);
		btEnquiryBean.setBagBean(bagStatusBean);
				
		btEnquiryForm.setBtEnquiryBean(btEnquiryBean);
		btEnquiryForm.setBagFound("N");
		
		return(mapping.findForward("goToBagTrackingEnquiryPage"));
	}
    
    public ActionForward getBagTrackingInquiry(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
    {
    	BagTrackingEnquiryForm btEnquiryForm = (BagTrackingEnquiryForm)form;    	
    	
    	try
    	{
	    	String bagNumberFromRequest = request.getParameter("bagNumber");
	    	BagTrackingEnquiryBean btEnquiryBean = btEnquiryForm.getBtEnquiryBean();
	    	
	    	String bagNumberInForm = null;
	    	
	    	if(btEnquiryBean!=null)
	    		bagNumberInForm = btEnquiryBean.getBagBean().getBagNumber();
	    	
	    	/* This new Bean is created so as to remove all the previous values in the report */
			btEnquiryBean = new BagTrackingEnquiryBean();
			BagStatusBean bagStatusBean1 = new BagStatusBean();
			PAXBean paxBean1 = new PAXBean();
			paxBean1.setAddress(new AddressBean());
			paxBean1.setDepartureFlightDetails(new FlightDetailsBean());
			bagStatusBean1.setPaxBean(paxBean1);
			bagStatusBean1.setBagNumber(bagNumberInForm);
			btEnquiryBean.setBagBean(bagStatusBean1);
			btEnquiryForm.setBtEnquiryBean(btEnquiryBean);
				    	
	    	/* If the bag number is being passed in the URL - navigating from some other report */
	    	if(bagNumberFromRequest!=null)
	    		btEnquiryBean.getBagBean().setBagNumber(bagNumberFromRequest);
	    	
			BagTrackingReportsDelegate delegate = new BagTrackingReportsDelegate();
			btEnquiryBean = delegate.getBagTrackingEnquiryData(btEnquiryBean);
			btEnquiryForm.setBtEnquiryBean(btEnquiryBean);
			btEnquiryForm.setBagFound("Y");	
    	}
    	catch(PaxTraxSystemException pse)
    	{
    		PaxTraxLog.logError("Exception in PaxTrax::BagTrackingEnquiryAction::getBagTrackingInquiry"+pse);
    		return(mapping.findForward(PaxTraxConstants.REPORT_ERROR));
    	}
    	
    	catch(BagTrackingReportsException btException)
    	{
    		PaxTraxLog.logDebug("Business Exception in PaxTrax::BagTrackingEnquiryAction::getBagTrackingInquiry",btException);
    		btEnquiryForm.setBagFound("N");
    		request.setAttribute("errorCode", "" + btException.getErrorCode());
			return(mapping.findForward("goToBagTrackingEnquiryPage"));
    	}
    	
    	return(mapping.findForward("goToBagTrackingEnquiryPage"));
    }
    
    public ActionForward printBagTrackingInquiry(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
    {
    	String forward = null;
    	try {
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingEnquiryAction::printBagTrackingInquiry::Begin");
			BagTrackingEnquiryForm bagTrackingEnquiryForm =
				(BagTrackingEnquiryForm) form;
			BagTrackingEnquiryBean btEnquiryBean = new BagTrackingEnquiryBean();
			
			btEnquiryBean = bagTrackingEnquiryForm.getBtEnquiryBean();
			
			bagTrackingEnquiryForm.setBtEnquiryBean(btEnquiryBean);
			
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingEnquiryAction::printBagTrackingInquiry::End");
			forward = "printBagTrackingEnquiryPage";
		} catch (Exception ex) {

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
    }
    
}
