package com.dfs.paxtrax.bagtracking.service;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.BagTrackingReportsBO;
import com.dfs.paxtrax.bagtracking.business.BagTrackingReportsBOHome;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.valueobject.BagByBagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByFlightInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusByLocationBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagTrackingEnquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.BinLocationReportBean;
import com.dfs.paxtrax.bagtracking.valueobject.CageStatusHistoryBean;
import com.dfs.paxtrax.bagtracking.valueobject.CartonTrackingEnquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.DeliveryManifestBean;
import com.dfs.paxtrax.bagtracking.valueobject.ItemTrackingInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.MissingBagsEnquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.PaxPurchaseInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.SKUSummaryReportBean;
import com.dfs.paxtrax.bagtracking.valueobject.StockAtPickupLocationInquiryBean;
import com.dfs.paxtrax.bagtracking.valueobject.TracingRefundedBagBean;
import com.dfs.paxtrax.bagtracking.valueobject.TruckTrackingInquiryBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

/**
 * 
 * The Action Class for PAX related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/06/2004	Anand			Created  
 * 07/30/2007	Uma D			Modified for CR changes
 * 06/06/2007	Uma D 			Modified for CR changes
 */
public class BagTrackingReportsDelegate
{
	/*
	* Holds service locator instance
	*/
	private ServiceLocator serviceLocator = null;
	/*
	 * Holds the Home interface
	 */
	private BagTrackingReportsBOHome bagTrackingReportsBOHome = null;
	/*
	 * Hold the remote interface
	 */
	private BagTrackingReportsBO bagTrackingReportsBO = null;
	/*
	 *Default Construtor for LocationDelegate
	 */
	public ArrayList getReportsAssignedToUser(String userId)
		throws PaxTraxSystemException
	{
		ArrayList listOfReports = new ArrayList();

		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsDelegate::getReportsAssignedToUser::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.PT_JNDI_BT_REPORTS_HOME);
			BagTrackingReportsBOHome home =
				(BagTrackingReportsBOHome) PortableRemoteObject.narrow(
					obj,
					BagTrackingReportsBOHome.class);
			BagTrackingReportsBO remote = home.create();
			listOfReports = remote.getReportsAssignedToUser(userId);

			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsDelegate::getReportsAssignedToUser::End");

		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getReportsAssignedToUser",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getReportsAssignedToUser",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getReportsAssignedToUser",
				ce);
			throw new PaxTraxSystemException(ce);
		}

		return (listOfReports);

	}

	/*
	 * Jndi look up is performed here
	 */
	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			bagTrackingReportsBOHome =
				(BagTrackingReportsBOHome) PortableRemoteObject.narrow(
					serviceLocator.getEJBHome(
						PaxTraxConstants.BT_JNDI_BO_REPORTS_HOME),
					BagTrackingReportsBOHome.class);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}
		if (bagTrackingReportsBOHome == null)
		{
			throw new PaxTraxSystemException(
				PaxTraxConstants.BT_REPORTS_BO_HOME_NOT_FOUND);
		}
		try
		{
			bagTrackingReportsBO = bagTrackingReportsBOHome.create();
		}
		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::jndiCall::End");
	}

	/**
	   * Searches for the Item details in the database by 
	   * delegating the request to  the bean. 
	   * @param itemTrackingInquiryBean ItemTrackingInquiryBean object
	   * @throws PaxTraxSystemException for System Exception
	   * @throws BagTrackingReportsException for BusinessException 
	   */
	public ArrayList getItemTrackingInquiry(ItemTrackingInquiryBean itemTrackingInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getItemTrackingInquiry::Begin");
		ArrayList itemList = null;
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			itemList =
				bagTrackingReportsBO.getItemTrackingInquiry(
					itemTrackingInquiryBean);

		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}

		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getItemTrackingInquiry::End");
		return itemList;
	}

	public BagTrackingEnquiryBean getBagTrackingEnquiryData(BagTrackingEnquiryBean btEnquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsDelegate::getBagTrackingEnquiryData::Begin");
			ServiceLocator locator = ServiceLocator.getInstance();
			Object obj =
				locator.getEJBHome(PaxTraxConstants.PT_JNDI_BT_REPORTS_HOME);
			BagTrackingReportsBOHome home =
				(BagTrackingReportsBOHome) PortableRemoteObject.narrow(
					obj,
					BagTrackingReportsBOHome.class);
			BagTrackingReportsBO remote = home.create();
			btEnquiryBean = remote.getBagTrackingEnquiryData(btEnquiryBean);

			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsDelegate::getBagTrackingEnquiryData::End");

		}
		catch (NamingException ne)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getBagTrackingEnquiryData",
				ne);
			throw new PaxTraxSystemException(ne);
		}
		catch (RemoteException re)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getBagTrackingEnquiryData",
				re);
			throw new PaxTraxSystemException(re);
		}
		catch (CreateException ce)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getBagTrackingEnquiryData",
				ce);
			throw new PaxTraxSystemException(ce);
		}

		return (btEnquiryBean);

	}

	public ArrayList getTruck() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getTruck::Begin");
		ArrayList truckList = null;
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}

		try
		{
			truckList = bagTrackingReportsBO.getTruck();
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getTruck",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getTruck::End");
		return truckList;
	}

	public ArrayList getTruckList() throws PaxTraxSystemException
	{

		ArrayList truckList = null;
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}

		try
		{
			truckList = bagTrackingReportsBO.getTruckList();
		}
		catch (RemoteException remoteException)
		{
			throw new PaxTraxSystemException(remoteException);
		}
		return truckList;
	}

	/**
	 * Gets the report for a truck
	 * @param deliveryBean
	 * @return DeliveryManifestBean
	 * @throws PaxTraxSystemException if there is any problem in retrieving the
	 * report
	 */
	public DeliveryManifestBean getDeliveryManifest(DeliveryManifestBean deliveryBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getDeliveryManifest::Begin");
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}

		try
		{
			deliveryBean =
				bagTrackingReportsBO.getDeliveryManifest(deliveryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getDeliveryManifest",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getDeliveryManifest::End");
		return deliveryBean;
	}

	/**
	 * Prints DeliveryManifestpage and changes the status of truck,cages,cartons
	 * and bags.
	 * @param deliveryBean
	 * @throws PaxTraxSystemException
	 */
	public void printDeliveryManifest(DeliveryManifestBean deliveryBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::printDeliveryManifest::Begin");
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			bagTrackingReportsBO.printDeliveryManifest(deliveryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::printDeliveryManifest",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::printDeliveryManifest::End");
	}

	/**
	 * Method getAllBinLocations.
	 * @return ArrayList
	 */
	public ArrayList getAllBinLocations(String locationType)
		throws PaxTraxSystemException
	{
		ArrayList binLocList = null;
		try
		{
			binLocList =
				getBagTrackingReportsBO().getAllBinLocations(locationType);

		}
		catch (RemoteException e)
		{
			PaxTraxLog.logFatal(
				"BagTrackingReportsDelegate:getBinLocEnquiryReport() - Error ",
				e);
			throw new PaxTraxSystemException(e);
		}
		return binLocList;

	}

	/**
	 * Method getBagTrackingReportsBO.
	 * @return BagTrackingReportsBO
	 * @throws PaxTraxSystemException
	 */
	private BagTrackingReportsBO getBagTrackingReportsBO()
		throws PaxTraxSystemException
	{
		BagTrackingReportsBOHome btHome = null;
		BagTrackingReportsBO bTReportsBO = null;
		try
		{
			PaxTraxLog.logInfo(
				"BTRDelegate:getBagTrackingReportsBO() - Using JNDI ["
					+ PaxTraxConstants.PT_JNDI_BT_REPORTS_HOME
					+ "]");
			btHome =
				(BagTrackingReportsBOHome) ServiceLocator
					.getInstance()
					.getEJBHome(
					PaxTraxConstants.PT_JNDI_BT_REPORTS_HOME);
			bTReportsBO = btHome.create();
		}
		catch (NamingException e)
		{
			PaxTraxLog.logFatal(
				"BTRDelegate:getBagTrackingReportsBO() - Error",
				e);
			throw new PaxTraxSystemException(e);
		}
		catch (RemoteException e)
		{
			PaxTraxLog.logFatal(
				"BTRDelegate:getBagTrackingReportsBO() - Error",
				e);
			throw new PaxTraxSystemException(e);
		}
		catch (CreateException e)
		{
			PaxTraxLog.logFatal(
				"BTRDelegate:getBagTrackingReportsBO() - Error",
				e);
			throw new PaxTraxSystemException(e);
		}

		return bTReportsBO;
	}

	/**
	 * Method getBinLocEnquiryReport.
	 * @param bEBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList getBinLocEnquiryReport(
		BinLocationReportBean bEBean,
		ArrayList combinedList)
		throws PaxTraxSystemException
	{
		ArrayList reportList = null;
		try
		{
			reportList =
				getBagTrackingReportsBO().getBinLocEnquiryReport(
					bEBean,
					combinedList);

		}
		catch (RemoteException e)
		{
			PaxTraxLog.logFatal(
				"BagTrackingReportsDelegate:getBinLocEnquiryReport() - Error ",
				e);
			throw new PaxTraxSystemException(e);
		}
		return reportList;
	}

	/**
	* Generates the report for truck from the database.
	* @param TruckTrackingInquiryBean
	* @return TruckTrackingInquiryBean
	* @throws PaxTraxException This exception is thrown
	* if there is any problem in retrieval
	*/
	public TruckTrackingInquiryBean getTruckTrackingEnquiry(TruckTrackingInquiryBean truckTrackingInquiryBean)
		throws PaxTraxSystemException
	{
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			truckTrackingInquiryBean =
				bagTrackingReportsBO.getTruckTrackingEnquiry(
					truckTrackingInquiryBean);
		}
		catch (RemoteException remoteException)
		{
			throw new PaxTraxSystemException(remoteException);
		}
		return truckTrackingInquiryBean;
	}

	/**
	 * Method getStockAtPickupLocationInquiry.
	 * @param stockBean
	 * @return StockAtPickupLocationInquiryBean
	 * @throws PaxTraxSystemException
	 */
	public StockAtPickupLocationInquiryBean getStockAtPickupLocationInquiry(StockAtPickupLocationInquiryBean stockBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getStockAtPickupLocationInquiry::Begin");
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			stockBean =
				bagTrackingReportsBO.getStockAtPickupLocationInquiry(stockBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getStockAtPickupLocationInquiry",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getStockAtPickupLocationInquiry::End");
		return stockBean;
	}

	/**
	 * Method getCageReport.
	 * @param cRBean
	 * @return CageReportResultBean
	 * @throws PaxTraxSystemException
	 */
	public CageStatusHistoryBean getCageReport(CageStatusHistoryBean cageStatusHistoryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logInfo(
			"BagTrackingReportsDelegate:getCageReport() - Delegating the call");

		try
		{
			return (
				getBagTrackingReportsBO().getCageReport(cageStatusHistoryBean));
		}
		catch (RemoteException e)
		{
			PaxTraxLog.logFatal(
				"BagTrackingReportsDelegate:getCageReport() - RemoteException occured",
				e);
			throw new PaxTraxSystemException(e);
		}

	}

	/**
	* Generates the report for pax purchase from the database.
	* @return PaxPurchaseInquiryBean
	* @throws PaxTraxException This exception is thrown
	* if there is any problem in retrieval
	*/
	public PaxPurchaseInquiryBean getPaxPurchaseInquiry(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws BagTrackingReportsException, PaxTraxSystemException
	{
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			paxPurchaseInquiryBean =
				bagTrackingReportsBO.getPaxPurchaseInquiry(
					paxPurchaseInquiryBean);
		}
		catch (BagTrackingReportsException e)
		{
			PaxTraxLog.logDebug(
				"BagTrackingReportsDelegate:getPaxPurchaseInquiry() - "
					+ "Bag Tracking Report Exception happened "
					+ e.getErrorCode());
			throw new BagTrackingReportsException(e.getErrorCode());
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"BagTrackingReportsDelegate:getPaxPurchaseInquiry() - "
					+ "Remote Exception happened ",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		return paxPurchaseInquiryBean;

	}

	/**
	 * Method getBagStatusByFlightInquiry.
	 * @param bagStatusInquiry
	 * @return BagStatusByFlightInquiryBean
	 * @throws PaxTraxSystemException
	 */
	public BagStatusByFlightInquiryBean getBagStatusByFlightInquiry(BagStatusByFlightInquiryBean bagStatusInquiry)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getBagStatusByFlightInquiry::Begin");
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}

		try
		{
			bagStatusInquiry =
				bagTrackingReportsBO.getBagStatusByFlightInquiry(
					bagStatusInquiry);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getBagStatusByFlightInquiry",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getBagStatusByFlightInquiry::End");
		return bagStatusInquiry;
	}

	public ArrayList getCartonList() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getCartonList::Begin");
		ArrayList list = null;
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			list = bagTrackingReportsBO.getCartonList();
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::getCartonList",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getCartonList::End");
		return list;

	}

	public CartonTrackingEnquiryBean getCartonDetails(
		String cartonNumber,
		long moduleId)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"BagTrackingReportsDelegate:: getCartonDetails()::Begin");
		CartonTrackingEnquiryBean cartonTrackingEnquiryBean = null;
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			cartonTrackingEnquiryBean =
				bagTrackingReportsBO.getCartonDetails(cartonNumber, moduleId);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getCartonDetails",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::getCartonList::End");
		return cartonTrackingEnquiryBean;
	}

	/**
	 * Method getBagNotReadyForPickup.
	 * @param bagEnquiry
	 * @return BagTrackingEnquiryBean
	 * @throws PaxTraxSystemException
	 */
	public BagTrackingEnquiryBean getBagNotReadyForPickup(BagTrackingEnquiryBean bagEnquiry)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getBagNotReadyForPickup::Begin");
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			bagEnquiry =
				bagTrackingReportsBO.getBagNotReadyForPickup(bagEnquiry);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getBagNotReadyForPickup",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getBagNotReadyForPickup::End");
		return bagEnquiry;
	}

	public ArrayList getAllCages() throws PaxTraxSystemException
	{
		ArrayList list = new ArrayList();
		try
		{

			list = getBagTrackingReportsBO().getAllCages();
		}
		catch (RemoteException e)
		{
			PaxTraxLog.logFatal("BagTrackingReportsDelegate:getAllCages - ", e);
			throw new PaxTraxSystemException(e);

		}

		return list;

	}

	public void bagCancelSave(BagTrackingEnquiryBean bagBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::bagCancelSave::Begin");
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			bagTrackingReportsBO.bagCancelSave(bagBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::bagCancelSave",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::bagCancelSave::End");
	}

	/**
	* Method getMissingBagDetailst.
	* @param missingBagsEnquiryBean
	* @return ArrayList
	* @throws PaxTraxSystemException
	* @throws RemoteException
	*/
	public ArrayList getMissingBagDetails(MissingBagsEnquiryBean missingBagsEnquiryBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getBagsMissingByFlight()::Begin");
		ArrayList missingBagList = new ArrayList();
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			missingBagList =
				bagTrackingReportsBO.getMissingBagDetails(
					missingBagsEnquiryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getBagsMissingByFlight",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getBagsMissingByFlight()::End");
		return missingBagList;
	}
	
	/**
	 * Saves missing bag details.
	 * @param missingBagsEnquiryBean
	 * @return ArrayList list of missing bag enquiry beans
	 * @throws PaxTraxSystemException thrown on error
	 */
	public void saveMissingBagDetails(ArrayList missingBagsList)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::saveMissingBagDetails()::Begin");
		
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{	
			bagTrackingReportsBO.saveMissingBagDetails(missingBagsList);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::saveMissingBagDetails",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::saveMissingBagDetails()::End");
	}

	public PaxPurchaseInquiryBean getPaxDFPurchaseList(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getPaxDFPurchaseList()::Begin");
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			resultBean =
				bagTrackingReportsBO.getPaxDFPurchaseList(
					paxPurchaseInquiryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getPaxDFPurchaseList",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getPaxDFPurchaseList()::End");
		return resultBean;
	}
	
	public PaxPurchaseInquiryBean approvePax(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::approvePax()::Begin");
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			resultBean =
				bagTrackingReportsBO.approvePax(paxPurchaseInquiryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::approvePax",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::approvePax()::End");
		return resultBean;
	}

	public PaxPurchaseInquiryBean rejectPax(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::rejectPax()::Begin");
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			resultBean = bagTrackingReportsBO.rejectPax(paxPurchaseInquiryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::rejectPax",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::rejectPax()::End");
		return resultBean;
	}
	
	public PaxPurchaseInquiryBean getPaxDetails(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getPaxDetails()::Begin");
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			resultBean = bagTrackingReportsBO.getPaxDetails(paxPurchaseInquiryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getPaxDetails",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getPaxDetails()::End");
		return resultBean;
	}
	public PaxPurchaseInquiryBean getPaxDPPurchaseList(PaxPurchaseInquiryBean paxPurchaseInquiryBean)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getPaxDFPurchaseList()::Begin");
		PaxPurchaseInquiryBean resultBean = new PaxPurchaseInquiryBean();
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
		try
		{
			resultBean =
				bagTrackingReportsBO.getPaxDPPurchaseList(
					paxPurchaseInquiryBean);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getPaxDPPurchaseList",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getPaxDPPurchaseList()::End");
		return resultBean;
	}
	
	/**
	 * Returns the list of SKU's that were transferred through a truck trip
	 * on a particular day
	 * @param date date for which sku transfer is required
	 * @return ArrayList list of BagStatusBean containing sku list
	 * @throws PaxTraxSystemException thrown on Error
	 */
	
	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

	public ArrayList getSkuTransferReport(SKUSummaryReportBean skuSummaryReportBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getSkuTransferReport()::Begin");
		ArrayList resultBean = null;
		if (bagTrackingReportsBOHome == null) {
			jndiCall();
		}
		try {
			resultBean =
				bagTrackingReportsBO.getSkuTransferList(skuSummaryReportBean);
		}
		catch (RemoteException remoteException) {
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getSkuTransferReport",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getSkuTransferReport()::End");
		return (resultBean);
	}
	
	/**
	 * Returns the list of items that were transferred on a particular day
	 * @param date date for which sku transfer details are needed
	 * @return ArrayList list of ItemDetailsBean containing sku list
	 * @throws PaxTraxSystemException thrown on Error
	 * @throws RemoteException thrown if remote access fails
	 */
	public ArrayList getSkuTransferGroupBySkusList(SKUSummaryReportBean skuSummaryReportBean)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getSkuTransferGroupBySkusList()::Begin");
		ArrayList resultBean = null;
		if (bagTrackingReportsBOHome == null) {
			jndiCall();
		}
		try {
			resultBean =
				bagTrackingReportsBO.getSkuTransferGroupBySkusList(skuSummaryReportBean);
		}
		catch (RemoteException remoteException) {
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getSkuTransferGroupBySkusList() ",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getSkuTransferGroupBySkusList()::Begin");
		return (resultBean);
	}
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

	
	/* added on June 06, 2007 for CR 251-260 changes Begin*/
		/**
		   * This method is used to retrieve the list of Bag status from the database by 
		   * delegating the request to  the bean. 
		   * @param bagCode ArrayList
		   * @throws PaxTraxSystemException for System Exception
		   * @throws PaxTraxSystemException 
		   */
		public ArrayList loadBagStatus(String bagCode)
			throws PaxTraxSystemException
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsDelegate::loadBagStatus::Begin");
			ArrayList bagStatusList = null;
			if (bagTrackingReportsBOHome == null)
			{
				jndiCall();
			}
			try
			{
				bagStatusList =	bagTrackingReportsBO.loadBagStatus(bagCode);

			}
			catch (RemoteException re)
			{
				throw new PaxTraxSystemException(re);
			}

			PaxTraxLog.logDebug(
				"PaxTrax::BagTrackingReportsDelegate::loadBagStatus::End");
			return bagStatusList;
		}
	
		/**
		 * This method is used to retrieve the search result list for the 
		 * bag status from the database by delegating the request to  the bean. 
		 * @param bagStatusBean
		 * @return BagByBagStatusBean
		 * @throws PaxTraxSystemException
		 */
		public BagByBagStatusBean getBagByBagStatusReport(BagByBagStatusBean bagByBagStatusBean)
			throws PaxTraxSystemException, BagTrackingReportsException
		{
			PaxTraxLog.logDebug(
				"Paxtrax::BagTrackingReportsDelegate::getBagByBagStatusReport::Begin");
			if (bagTrackingReportsBOHome == null)
			{
				jndiCall();
			}

			try
			{
				bagByBagStatusBean =	bagTrackingReportsBO.getBagByBagStatusReport(bagByBagStatusBean);
			}
			catch (RemoteException remoteException)
			{
				PaxTraxLog.logError(
					"Exception in PaxTrax::BagTrackingReportsDelegate::getBagByBagStatusReport",
					remoteException);
				throw new PaxTraxSystemException(remoteException);
			}
			PaxTraxLog.logDebug(
				"Paxtrax::BagTrackingReportsDelegate::getBagByBagStatusReport::End");
			return bagByBagStatusBean;
		}	
		
	/**
	 * This method is used to retrieve the bag location display list for the 
	 * bag status by location from the database by delegating the request to  the bean. 
	 * @param refName
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList loadConfigData(String refName)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::loadBagLocationList::Begin");
		ArrayList bagLocationList = null;
		if (bagTrackingReportsBOHome == null)
		{
			jndiCall();
		}
	
		try
		{
			bagLocationList =	bagTrackingReportsBO.loadConfigData(refName);
		}
		catch (RemoteException remoteException)
		{
			PaxTraxLog.logError(
				"Exception in PaxTrax::BagTrackingReportsDelegate::loadBagLocationList",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"Paxtrax::BagTrackingReportsDelegate::loadBagLocationList::End");
		return bagLocationList;
	}		
		
		/**
		 * This method is used to retrieve the search result list for the 
		 * bag status by location from the database by delegating the request to  the bean. 
		 * @param bagStatusLocationBean
		 * @return BagStatusByLocationBean
		 * @throws PaxTraxSystemException
		 */
		public BagStatusByLocationBean getBagStatusByLocation(BagStatusByLocationBean bagStatusLocationBean)
			throws PaxTraxSystemException, BagTrackingReportsException
		{
			PaxTraxLog.logDebug(
				"Paxtrax::BagTrackingReportsDelegate::getBagStatusByLocation::Begin");
			if (bagTrackingReportsBOHome == null)
			{
				jndiCall();
			}
	
			try
			{
				bagStatusLocationBean =	bagTrackingReportsBO.getBagStatusByLocationReport(bagStatusLocationBean);
			}
			catch (RemoteException remoteException)
			{
				PaxTraxLog.logError(
					"Exception in PaxTrax::BagTrackingReportsDelegate::getBagStatusByLocation",
					remoteException);
				throw new PaxTraxSystemException(remoteException);
			}
			PaxTraxLog.logDebug(
				"Paxtrax::BagTrackingReportsDelegate::getBagStatusByLocation::End");
			return bagStatusLocationBean;
		}		
	
	
		/* added on June 06, 2007 for CR 251-260 changes End*/
		

//	Added on 30jul07 for CR 261 Tracing RefundedBags Starts
	/**
	 * Returns the list of bags that were refunded at AP/received at Galleria on a particular day
	 * @param date date for which sku transfer details are needed
	 * @return ArrayList list of Refunded Bags .
	 * @throws PaxTraxSystemException thrown on Error
	 * @throws RemoteException thrown if remote access fails
	 */
	public ArrayList getRefundedBagList(TracingRefundedBagBean tracingRefundedBagBean )
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getRefundedBagList()::Begin");
		ArrayList resultList = null;
		if (bagTrackingReportsBOHome == null) {
			jndiCall();
		}
		try {
			resultList =
				bagTrackingReportsBO.getRefundedBagList(tracingRefundedBagBean);
		}
		catch (RemoteException remoteException) {
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::getRefundedBagList() ",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::getRefundedBagList()::Ends");
		return (resultList);
	}
	  
  /**
   * Returns the list of bags that were received at Galleria 
   * @param date date for which sku transfer details are needed
   * @return ArrayList list of Refunded Bags .
   * @throws PaxTraxSystemException thrown on Error
   * @throws RemoteException thrown if remote access fails
   */
	public ArrayList receiveBagsInGalleria(ArrayList refundedBagList,String userId )
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::receiveBagsatGalleria()::Begin");
		ArrayList resultList = null;
		if (bagTrackingReportsBOHome == null) {
			jndiCall();
		}
		try {
			resultList =
				bagTrackingReportsBO.receiveBagsatGalleria(refundedBagList,userId);
		}
		catch (RemoteException remoteException) {
			PaxTraxLog.logError(
				"PaxTrax::BagTrackingReportsDelegate::receiveBagsatGalleria() ",
				remoteException);
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagTrackingReportsDelegate::receiveBagsatGalleria()::Ends");
		return (resultList);
	}
	  
	  
//	Added on 30jul07 for CR 261 Tracing RefundedBags ends		
}