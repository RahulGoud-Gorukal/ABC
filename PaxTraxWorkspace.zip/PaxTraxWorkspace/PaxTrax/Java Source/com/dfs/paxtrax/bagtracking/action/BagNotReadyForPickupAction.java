package com.dfs.paxtrax.bagtracking.action;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.admin.service.ReferenceDataDelegate;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.bagtracking.actionform.BagNotReadyForPickupForm;
import com.dfs.paxtrax.bagtracking.actionform.BagTrackingEnquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.bagtracking.valueobject.BagTrackingEnquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

/**
*  This is action class which provides the details for a flight number
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 08/07/2004    Yuvarani		Created
*/

public class BagNotReadyForPickupAction extends PaxTraxAction
{

	/**
	 * Method goToBagNotReadyForPickup.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward goToBagNotReadyForPickup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::goToBagNotReadyForPickup::Begin");
		BagNotReadyForPickupForm bagPickupForm =
			(BagNotReadyForPickupForm) form;
		BagTrackingEnquiryBean bagEnquiry = new BagTrackingEnquiryBean();
		FlightDetailsBean flightBean = new FlightDetailsBean();
		PAXBean pax = new PAXBean();
		BagStatusBean bag = new BagStatusBean();
		pax.setDepartureFlightDetails(flightBean);
		bag.setPaxBean(pax);
		bagEnquiry.setBagBean(bag);
		ReferenceDataDelegate referData = new ReferenceDataDelegate();
		String forward = null;

		try
		{
			ArrayList airline =
				referData.loadReferenceData(PaxTraxConstants.AIRLINE_CODE);

			bagPickupForm.setBagEnquiry(bagEnquiry);
			bagPickupForm.setAirlineCodeList(airline);
			forward = PaxTraxConstants.BAG_NOT_READY_FOR_PICKUP;
		}
		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagNotReadyForPickupAction::goToBagNotReadyForPickup",
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::goToBagNotReadyForPickup::End");
		return mapping.findForward(forward);
	}

	/**
	 * Method getBagNotReadyForPickup.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward getBagNotReadyForPickup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException, BagTrackingReportsException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::getBagNotReadyForPickup::Begin");
		BagNotReadyForPickupForm bagPickupForm =
			(BagNotReadyForPickupForm) form;
		BagTrackingEnquiryBean bagEnquiry = bagPickupForm.getBagEnquiry();
		String forward = null;
		try
		{
			BagTrackingReportsDelegate bagNotReady =
				new BagTrackingReportsDelegate();
			bagEnquiry = bagNotReady.getBagNotReadyForPickup(bagEnquiry);
			if (bagEnquiry.getItemList() == null
				|| bagEnquiry.getItemList().size() == 0)
				request.setAttribute(
					PaxTraxConstants.ERROR_CODE,
					PaxTraxConstants.ERROR_CODE);
			bagPickupForm.setBagEnquiry(bagEnquiry);
			request.setAttribute(
				PaxTraxConstants.RESULT,
				PaxTraxConstants.SUCCESS);
			forward = PaxTraxConstants.BAG_NOT_READY_FOR_PICKUP;
		}
		catch (BagTrackingReportsException bagException)
		{
			PaxTraxLog.logError(
				"Paxtrax::BagNotReadyForPickupAction::getBagNotReadyForPickup",
				bagException);
			ArrayList airline = bagPickupForm.getAirlineCodeList();

			if (airline != null)
			{
				ReferenceDataBean referData = null;
				BagStatusBean b = bagEnquiry.getBagBean();
				PAXBean p = b.getPaxBean();
				FlightDetailsBean f = p.getDepartureFlightDetails();
				for (int i = 0; i < airline.size(); i++)
				{
					referData = (ReferenceDataBean) airline.get(i);
					if ((referData.getCodeId()).equals(f.getAirlineCode()))
					{
						f.setAirlineCodeValue(referData.getCodeValue());

						break;
					}
				}
				f.setTime("");
				p.setDepartureFlightDetails(f);
				b.setPaxBean(p);
				bagEnquiry.setBagBean(b);
			}
			bagPickupForm.setBagEnquiry(bagEnquiry);
			request.setAttribute(
				PaxTraxConstants.ERROR_CODE,
				"" + bagException.getErrorCode());
			forward = PaxTraxConstants.BAG_NOT_READY_FOR_PICKUP;
		}

		catch (PaxTraxSystemException paxException)
		{
			PaxTraxLog.logError(
				"PaxTrax::BagNotReadyForPickupAction::getBagNotReadyForPickup"+
				paxException);
			forward = PaxTraxConstants.REPORT_ERROR;
		}
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::getBagNotReadyForPickup::End");
		return mapping.findForward(forward);
	}

	public ActionForward bagCancel(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::bagCancel::Begin");
		request.setAttribute(
			PaxTraxConstants.BAG_NUMBER,
			request.getParameter(PaxTraxConstants.BAG_NUMBER));

		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::bagCancel::End");
		return mapping.findForward(PaxTraxConstants.BAG_CANCELLATION);
	}

	public ActionForward bagCancelSave(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::bagCancelSave::Begin");
		String reason = request.getParameter("reason");
		reason = reason.trim();
		String bagNo = request.getParameter("bagNo");
		String terminal = request.getRemoteHost();
		bagNo = bagNo.trim();
		BagTrackingEnquiryBean bagBean = new BagTrackingEnquiryBean();
		BagStatusBean bagStatusBean = new BagStatusBean();
		bagBean.setReason(reason);
		bagStatusBean.setBagNumber(bagNo);
		bagBean.setBagBean(bagStatusBean);
		bagBean.setTerminal(terminal);
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute(PaxTraxConstants.USER_ID);
		bagBean.setUser(user);
		BagTrackingReportsDelegate delegate = new BagTrackingReportsDelegate();
		delegate.bagCancelSave(bagBean);
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.SUCCESS);

		request.setAttribute(PaxTraxConstants.BAG_NUMBER, bagNo);
		PaxTraxLog.logDebug(
			"PaxTrax::BagNotReadyForPickupAction::bagCancelSave::End");
		return mapping.findForward(PaxTraxConstants.BAG_CANCELLATION);
	}
	public ActionForward printBagNotReadyForPickup(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::BagNotReadyForPickupAction::printBagNotReadyForPickup::Begin");
			BagNotReadyForPickupForm bagNotReadyForPickupForm =
				(BagNotReadyForPickupForm) form;
				
			ArrayList airLineList = bagNotReadyForPickupForm.getAirlineCodeList();
			String airLineCode = bagNotReadyForPickupForm.getBagEnquiry().getBagBean().getPaxBean().getDepartureFlightDetails().getAirlineCode();
			for (int i = 0; i < airLineList.size(); i++)
			{
				ReferenceDataBean tempBean =
					(ReferenceDataBean) airLineList.get(i);
				if (airLineCode.equals(tempBean.getCodeId()))
				{
					bagNotReadyForPickupForm.getBagEnquiry().getBagBean().getPaxBean().getDepartureFlightDetails().setAirlineCodeValue(tempBean.getCodeValue());
					break;
				}
			}	
			String result = (String) request.getParameter("result1");
			
			if (result != null && !result.equals("") && !result.equals("null"))
			{
				result = result.trim();
				request.setAttribute(PaxTraxConstants.RESULT, result);
			}

			PaxTraxLog.logDebug(
				"PaxTrax::BagNotReadyForPickupAction::printBagNotReadyForPickup::End");
			forward = "printBagNotReadyForPickup";
		}
		catch (Exception ex)
		{

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}
}
