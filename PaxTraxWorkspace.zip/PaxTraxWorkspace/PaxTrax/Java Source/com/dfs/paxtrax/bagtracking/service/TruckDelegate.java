package com.dfs.paxtrax.bagtracking.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.TruckBO;
import com.dfs.paxtrax.bagtracking.business.TruckBOHome;
import com.dfs.paxtrax.bagtracking.exception.TruckException;
import com.dfs.paxtrax.bagtracking.valueobject.TruckBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * The delegate class that is used to delegate control 
 * to the correct business object
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 01/06/2004	Yuvarani    	Created   
 */

public class TruckDelegate {
    
    //Holds Bin Location BO Home
    TruckBOHome home = null;
    
    //Holds Bin Location Remote variable
    TruckBO remote = null;
    
    //Holds service locator
    ServiceLocator locator = null;
    
	//Constructor for this class
    public TruckDelegate() {
    }

	/**
	 * Method jndiCall.
	 * @throws PaxTraxSystemException
	 */
	private void jndiCall() throws PaxTraxSystemException
    {
    	locator = ServiceLocator.getInstance();
    	try
    	{
    	Object object = locator.getEJBHome(PaxTraxConstants.TRUCK_BO_HOME_JNDI);
    	home = (TruckBOHome)PortableRemoteObject.narrow(
    										object,TruckBOHome.class);
    	}
    	catch (NamingException namingException)	
    	{
    		throw new PaxTraxSystemException(namingException);
    	}
		if (home == null)
		{
			throw new PaxTraxSystemException(PaxTraxConstants.TRUCK_HOME_NOT_FOUND);

		}
		try
		{
			remote = home.create();
		}
		catch (RemoteException remoteException)
		{
			throw new PaxTraxSystemException(remoteException);
		}
		catch (CreateException createException) 
		{
			throw new PaxTraxSystemException(createException);
		}
    	
    }
    
	/**
	 * Saves Truck Details in the database
	 * @param truckBean TruckBean 
	 * @throws PaxTraxSystemException if there is any problem in saving
	 */
    public void saveTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException,TruckException
    {
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::saveTruckDetails::Begin");
    	if (home == null)
    	{
    		jndiCall();
    	}
    	try
    	{
    		remote.saveTruckDetails(truckBean);
    	}
    	catch (RemoteException remoteException)
    	{
    		throw new PaxTraxSystemException(remoteException);
    	} 
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::saveTruckDetails::End");
    }
    
	/**
	 * Gets TruckDetails from the database.
	 * @param truckBean TruckBean 
	 * @return TruckBean
	 * @throws PaxTraxSystemException if there is any problem in retriving data
	 * @throws TruckException if the truck does not exist
	 */
	public TruckBean getTruckDetails(TruckBean truckBean)
		throws PaxTraxSystemException,TruckException
	{
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::getTruckDetails::Begin");
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			truckBean = remote.getTruckDetails(truckBean);
		}
		catch (RemoteException remoteException) 
		{
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::getTruckDetails::End");
		return truckBean;
	}
    
	/**
	 * This method searches for truck that satisfies the given criteria
	 * @param truckBean TruckBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException if there is any problem while searching
	 */
    public ArrayList searchTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException
    {
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::searchTruckDetails::Begin");
        ArrayList truckDetails = null;
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			truckDetails = (ArrayList)remote.searchTruckDetails(truckBean);
		}
		catch (RemoteException remoteException) 
		{
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::searchTruckDetails::End");
        return truckDetails;
    }
    
	/**
	 * Updates truck details in the database
	 * @param truckBean TruckBean
	 * @throws PaxTraxSystemException if there is any problem in updation
	 */
    public void updateTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException
    {
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::updateTruckDetails::Begin");
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			remote.updateTruckDetails(truckBean);
		}
		catch (RemoteException remoteException) 
		{
			throw new PaxTraxSystemException(remoteException);
		}
        PaxTraxLog.logDebug("PaxTrax::TruckDelegate::updateTruckDetails::End");    
    }
    
	/**
	 * Removes TruckDetails from the database.
	 * @param truckBean TruckBean
	 * @throws PaxTraxSystemException if there is any problem in deletion
	 */
    public void removeTruckDetails(TruckBean truckBean)
    	throws PaxTraxSystemException,TruckException
    {
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::removeTruckDetails::Begin");
		if (home == null)
		{
			jndiCall();
		}
		try
		{
			remote.removeTruckDetails(truckBean);
		}
		catch (RemoteException remoteException) 
		{
			throw new PaxTraxSystemException(remoteException);
		}
		PaxTraxLog.logDebug("PaxTrax::TruckDelegate::removeTruckDetails::End");
    }
}
