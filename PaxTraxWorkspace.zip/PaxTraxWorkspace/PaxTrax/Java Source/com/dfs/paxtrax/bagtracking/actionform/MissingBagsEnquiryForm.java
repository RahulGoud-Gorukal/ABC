package com.dfs.paxtrax.bagtracking.actionform;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.MissingBagsEnquiryBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 26/11/04     Joseph Oommen A Modified
 */
public class MissingBagsEnquiryForm extends PaxTraxActionForm
{

	ArrayList missingBagsList = null;
	MissingBagsEnquiryBean missingBagsEnquiryBean = null;
	ArrayList statusList = null;

	public void reset(ActionMapping mapping, HttpServletRequest request) {
		if (missingBagsList != null) {
			for (int i=0; i < missingBagsList.size(); i++) {
				MissingBagsEnquiryBean tempBean = 
						(MissingBagsEnquiryBean) missingBagsList.get(i);
				//tempBean.setBagFound("N");
			}
		}
	}

	/**
	 * Returns the missingBagsList.
	 * @return ArrayList
	 */
	public ArrayList getMissingBagsList()
	{
		return missingBagsList;
	}

	/**
	 * Sets the missingBagsList.
	 * @param missingBagsList The missingBagsList to set
	 */
	public void setMissingBagsList(ArrayList missingBagsList)
	{
		this.missingBagsList = missingBagsList;
	}

	/**
	 * Returns the missingBagsEnquiryBean.
	 * @return MissingBagsEnquiryBean
	 */
	public MissingBagsEnquiryBean getMissingBagsEnquiryBean()
	{
		return missingBagsEnquiryBean;
	}

	/**
	 * Sets the missingBagsEnquiryBean.
	 * @param missingBagsEnquiryBean The missingBagsEnquiryBean to set
	 */
	public void setMissingBagsEnquiryBean(MissingBagsEnquiryBean missingBagsEnquiryBean)
	{
		this.missingBagsEnquiryBean = missingBagsEnquiryBean;
	}

	/**
	 * Returns the statusList.
	 * @return ArrayList
	 */
	public ArrayList getStatusList()
	{
		return statusList;
	}

	/**
	 * Sets the statusList.
	 * @param statusList The statusList to set
	 */
	public void setStatusList(ArrayList statusList)
	{
		this.statusList = statusList;
	}

}
