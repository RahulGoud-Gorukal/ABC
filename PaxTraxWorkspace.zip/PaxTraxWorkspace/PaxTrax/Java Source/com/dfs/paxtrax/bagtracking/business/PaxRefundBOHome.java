package com.dfs.paxtrax.bagtracking.business;

/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
* This action class is used for inserting and updating paxRefund records
*
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER                COMMENTS
* 26/07/2004    Joseph Oommen A     Created
*/

public interface PaxRefundBOHome  extends EJBHome {

    /**
     * Creates a default instance of Session Bean: PaxRefundBO
     * @return PaxRefundBO Remote interface for this home interface
     * @throws CreateException This exception is thrown if there is a problem
     * in creation
     */
    public PaxRefundBO create() throws CreateException, RemoteException;
}
