package com.dfs.paxtrax.bagtracking.valueobject;
/**
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 * 
 */
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;
/**
* This is valueobject class which contains Cage attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 07/06/2004    Cyril John		Created   
*/
public class ShelfCartonCountMapBean extends PaxTraxValueObject 
{
	private String shelfNumber = null;
	private int cartonCount = 0;
	private long moduleId = 0;
	private ArrayList cartonList = null;
	
	/**
	 * Returns the cartonCount.
	 * @return int
	 */
	public int getCartonCount() {
		return cartonCount;
	}

	/**
	 * Returns the shelfNumber.
	 * @return String
	 */
	public String getShelfNumber() {
		return shelfNumber;
	}

	/**
	 * Sets the cartonCount.
	 * @param cartonCount The cartonCount to set
	 */
	public void setCartonCount(int cartonCount) {
		this.cartonCount = cartonCount;
	}

	/**
	 * Sets the shelfNumber.
	 * @param shelfNumber The shelfNumber to set
	 */
	public void setShelfNumber(String shelfNumber) {
		this.shelfNumber = shelfNumber;
	}

	/**
	 * Returns the moduleId.
	 * @return long
	 */
	public long getModuleId()
	{
		return moduleId;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(long moduleId)
	{
		this.moduleId = moduleId;
	}

	/**
	 * Returns the cartonList.
	 * @return ArrayList
	 */
	public ArrayList getCartonList()
	{
		return cartonList;
	}

	/**
	 * Sets the cartonList.
	 * @param cartonList The cartonList to set
	 */
	public void setCartonList(ArrayList cartonList)
	{
		this.cartonList = cartonList;
	}

}
