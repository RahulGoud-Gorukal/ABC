package com.dfs.paxtrax.bagtracking.action;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.BagOverrideForm;
import com.dfs.paxtrax.bagtracking.exception.BagOverrideException;
import com.dfs.paxtrax.bagtracking.service.BagOverrideDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.BagStatusBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;


import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 * This class is used to override Bags in ware house or APbin location.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/11/2004	P.C. Sathish	Created
 */
public class BagOverrideAction extends PaxTraxAction  {

	public ActionForward displayWareHouse(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		BagOverrideForm bagForm = (BagOverrideForm) form;
		BagStatusBean bagBean = new BagStatusBean();
		BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
		ArrayList truckList = bagDelegate.getTruckList();
		if (truckList == null) {
			truckList = new ArrayList();
		}
		bagForm.setTrucks(truckList);
		bagForm.setBagBean(bagBean);
		return(mapping.findForward(PaxTraxConstants.BAG_OVERRIDE_WARE_HOUSE_PAGE));
	}
	
	public ActionForward assignWareHouse(
						ActionMapping mapping, 
						ActionForm form, 
						HttpServletRequest request, 
						HttpServletResponse response) 
	throws PaxTraxSystemException {
		try {
			BagOverrideForm bagForm = (BagOverrideForm) form;
			BagStatusBean bagBean = bagForm.getBagBean();
			HttpSession session = request.getSession();
			bagBean.setUser((String)session.getAttribute(PaxTraxConstants.USER));
			bagBean.setTerminal(request.getRemoteHost());
			BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
			if (bagDelegate.assignWareHouse(bagBean)) {
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				PaxTraxLog.logDebug("BagOverrideAction::assignWareHouse():: Successful ");
			}
			
		} catch (BagOverrideException e) {
			PaxTraxLog.logDebug("BagOverrideAction::assignWareHouse():: Bagoverride exception "
							+ e.getErrorCode() + ", "+ e.getMessage());
			request.setAttribute(PaxTraxConstants.ERROR,"true");
			request.setAttribute("ErrorCode", ""+e.getErrorCode());
		}
		return(mapping.findForward(PaxTraxConstants.BAG_OVERRIDE_WARE_HOUSE_PAGE));
	}

	public ActionForward displayAirport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		BagOverrideForm bagForm = (BagOverrideForm) form;
		BagStatusBean bagBean = new BagStatusBean();
		bagForm.setBagBean(bagBean);
		return(mapping.findForward(PaxTraxConstants.BAG_OVERRIDE_AIRPORT_PAGE));
	}

	public ActionForward assignAirport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		try {
			BagOverrideForm bagForm = (BagOverrideForm) form;
			BagStatusBean bagBean = bagForm.getBagBean();
			HttpSession session = request.getSession();
			bagBean.setUser((String)session.getAttribute(PaxTraxConstants.USER));
			bagBean.setTerminal(request.getRemoteHost());
			BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
			if (bagDelegate.assignAirPort(bagBean)) {
				request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
				PaxTraxLog.logDebug("BagOverrideAction::assignWareHouse():: Successful ");				
			}
		} catch (BagOverrideException e) {
			PaxTraxLog.logDebug("BagOverrideAction::assignWareHouse():: Bagoverride exception "
							+ e.getErrorCode() + ", "+ e.getMessage());
			request.setAttribute(PaxTraxConstants.ERROR,"true");
			request.setAttribute("ErrorCode", ""+e.getErrorCode());
		}
		return(mapping.findForward(PaxTraxConstants.BAG_OVERRIDE_AIRPORT_PAGE));
	}

	/**
	 * @see com.dfs.paxtrax.common.action.PaxTraxAction#changeLanguage(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)
	 */
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction:: changeLanguage::Begin");
		String language = request.getParameter(PaxTraxConstants.LANGUAGE);
		String country = request.getParameter(PaxTraxConstants.COUNTRY);
		String forward = request.getParameter("forward");
		super.changeLanguage(request, language, country);
		PaxTraxLog.logDebug("Forward value is " + forward);
		PaxTraxLog.logDebug(
			"PaxTrax::NACCSDuplicatePaxReportAction:: changeLanguage::End");
			
		String errorCode = request.getParameter("erc");

		if (errorCode != null)
		{
			if (!(errorCode.equals("-1")))
			{
				request.setAttribute(PaxTraxConstants.ERROR,"true");
				request.setAttribute("ErrorCode", ""+errorCode);
			}
		}
		return mapping.findForward(forward);
	}	

//Code added on 2005/12/08. To display the change sales transaction page	
	public ActionForward displayChangeTransactionStatusPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		HttpSession session = request.getSession();
		BagOverrideForm bagForm = (BagOverrideForm) form;
		BagStatusBean bagBean = new BagStatusBean();
		bagForm.setBagBean(bagBean);
		session.removeAttribute(PaxTraxConstants.TRANS_STATUS);
		return(mapping.findForward(PaxTraxConstants.CHANGE_TRANSACTION_STATUS));
	}

//Code added on 2005/12/08. To update the status of sales transaction 
	public ActionForward updateSalesTransactionStatus(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		try
		{
			PaxTraxLog.logDebug("PaxTrax::BagOverrideAction:: updateSalesTransactionStatus::Begin");
			BagOverrideForm bagForm = (BagOverrideForm) form;
			BagStatusBean bagBean = bagForm.getBagBean();
			HttpSession session = request.getSession();
			BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
			
			//Code added to get the User ID from the session and to get the terminal IP from which 
			// the screen is accessed		
			bagBean.setUser((String)session.getAttribute(PaxTraxConstants.USER));
			bagBean.setTerminal(request.getRemoteHost());
			
			bagBean = (BagStatusBean)bagDelegate.changeSalesTransactionStatus(bagBean);
			bagForm.setBagBean(bagBean);
			session.setAttribute(PaxTraxConstants.TRANS_STATUS,"true");
			PaxTraxLog.logDebug("PaxTrax::BagOverrideAction:: updateSalesTransactionStatus::End");
		}
		catch (BagOverrideException e)
		{
			PaxTraxLog.logDebug("PaxTrax::BagOverrideAction::updateSalestatus():: Bagoverride exception "
							+ e.getErrorCode() + ", "+ e.getMessage());
			request.setAttribute(PaxTraxConstants.ERROR,"true");
			request.setAttribute("ErrorCode", ""+e.getErrorCode());
		}

		return(mapping.findForward(PaxTraxConstants.CHANGE_TRANSACTION_STATUS));
	}

//	Added by selvam for CA# 294102 starts

  public ActionForward createreleaseBags(
	  ActionMapping mapping,
	  ActionForm form,
	  HttpServletRequest request,
	  HttpServletResponse response)
	  throws PaxTraxSystemException {
	  BagOverrideForm bagForm = (BagOverrideForm) form;
	  BagStatusBean bagBean = new BagStatusBean();
	  BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
	  ArrayList truckList = bagDelegate.getTruckList();
	  if (truckList == null) {
		  truckList = new ArrayList();
	  }
	 
	  bagForm.setTrucks(truckList);
	  bagForm.setBagBean(bagBean);
	  return(mapping.findForward(PaxTraxConstants.BAG_RELEASE_PAGE));
  }



////  public ActionForward releaseBags(
////	  ActionMapping mapping,
////	  ActionForm form,
////	  HttpServletRequest request,
////	  HttpServletResponse response)
////	  throws PaxTraxSystemException,BagOverrideException  {
////	  try {
////	
////		  BagOverrideForm bagForm = (BagOverrideForm) form;
////		  BagStatusBean bagBean = bagForm.getBagBean();
////		  // Added/Modified by David for CR 3659 starts
////		  BagStatusBean bagBeanCheck=new BagStatusBean();
////		  // Added/Modified by David for CR 3659 ends
////		  HttpSession session = request.getSession();
////		  bagBean.setUser((String)session.getAttribute(PaxTraxConstants.USER));
////		  bagBean.setTerminal(request.getRemoteHost());
////		   // Added/Modified by David for CR 3659 starts
////		  String strIndex = request.getParameter("index");
////		  String index = request.getParameter("indexId");
////		  request.setAttribute("indexId",index);
////		 // Added/Modified by David for CR 3659 ends
////		BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
////		// Added/Modified by David for CR 3659 starts
////		ArrayList bagBeanList=bagDelegate.bagLookUp(bagBean);
////		bagBeanCheck=(BagStatusBean)bagBeanList.get(Integer.parseInt(bagBean.getIndex()));
////		bagForm.setBagBeanCheck((BagStatusBean)bagBeanList.get(Integer.parseInt(bagBean.getIndex())));
////		if (bagBeanCheck.getBagStatusId().equals("Y") )
////		{
////				    
////		  if (bagDelegate.releaseBags(bagBeanCheck)) {
////		  	 
////			request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
////			  
////			request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
////			bagBeanList =bagDelegate.bagLookUp(bagBean);
////			bagForm.setBagBeanList(bagBeanList);
////			  PaxTraxLog.logDebug("BagOverrideAction::releaseBags():: Successful ");				
////		  }  
////		}
////		else
////		{
////			request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
////			request.setAttribute(PaxTraxConstants.BAG_RELEASED, PaxTraxConstants.SUCCESS);
////			//request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
////			bagBeanList =bagDelegate.bagLookUp(bagBean);
////			bagForm.setBagBeanList(bagBeanList);
////		}
////		
////	  }
////		  catch (BagOverrideException e) {
////	  PaxTraxLog.logDebug("BagOverrideAction::releaseBags():: BagRelease exception "
////					  + e.getErrorCode() + ", "+ e.getMessage());
////	  request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
////	  request.setAttribute(PaxTraxConstants.ERROR,"true");
////	  request.setAttribute("ErrorCode", ""+e.getErrorCode());
////	// Added/Modified by David for CR 3659 ends
////  }
////	 
////	 return(mapping.findForward(PaxTraxConstants.BAG_RELEASE_PAGE));
////  }
  public ActionForward releaseBags(
	  ActionMapping mapping,
	  ActionForm form,
	  HttpServletRequest request,
	  HttpServletResponse response)
	  throws PaxTraxSystemException,BagOverrideException  {
	  try {
		
		  BagOverrideForm bagForm = (BagOverrideForm) form;
		  BagStatusBean bagBean = bagForm.getBagBean();
		  HttpSession session = request.getSession();
		  bagBean.setUser((String)session.getAttribute(PaxTraxConstants.USER));
		  bagBean.setTerminal(request.getRemoteHost());
		//Added/Modified by David for CR 3659 starts  
		String strIndex = request.getParameter("index");
		String index = request.getParameter("indexId");
		request.setAttribute("indexId",index);
		BagStatusBean bagBeanCheck=new BagStatusBean();
		BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
		ArrayList bagBeanList=bagDelegate.bagLookUp(bagBean);
		
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date d = new Date(new java.util.Date().getTime());
		
		Date d5=  new Date(d.getTime()+ 32400000);

		String dt= dateFormat.format(d5);
		
		String dt1=null;
		int check=0;
		
		bagBeanCheck=(BagStatusBean)bagBeanList.get(bagBeanList.size()-1);
		dt1=bagBeanCheck.getFlightDate().trim();
		if(dt1 != null)
		{	
		if(new Date(dt1).compareTo(new Date(dt))<=0)
		check=1;	
		}	

				if(check==1)
				{
					if(bagBean.getBagNumber().equals(""))
					{
							
							bagBeanCheck=(BagStatusBean)bagBeanList.get(Integer.parseInt(bagBean.getIndex()));
							bagForm.setBagBeanCheck((BagStatusBean)bagBeanList.get(Integer.parseInt(bagBean.getIndex())));
							if (bagBeanCheck.getBagStatusId().equals("Y") )
							{
									    
							  if (bagDelegate.releaseBags(bagBeanCheck)) {
							  	 
								request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
								  
								request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
								bagBeanList =bagDelegate.bagLookUp(bagBean);
								bagForm.setBagBeanList(bagBeanList);
								  PaxTraxLog.logDebug("BagOverrideAction::releaseBags():: Successful ");				
							  }  
							}
							else
							{
								request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
								request.setAttribute(PaxTraxConstants.BAG_RELEASED, PaxTraxConstants.SUCCESS);
								//request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
								bagBeanList =bagDelegate.bagLookUp(bagBean);
								bagForm.setBagBeanList(bagBeanList);
							}
					}
					else
					{	
						int i=0;
						for(int j=0;j<bagBeanList.size();j++){
							
							bagBeanCheck=(BagStatusBean)bagBeanList.get(j);
							if(bagBean.getBagNumber().equals(bagBeanCheck.getBagNumber()))
							{
								i=1;
								bagForm.setBagBeanCheck((BagStatusBean)bagBeanList.get(j));
								if (bagBeanCheck.getBagStatusId().equals("Y") )
								{
					    
								  if (bagDelegate.releaseBags(bagBeanCheck)) {
				 
									request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
				  
									request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
									bagBeanList =bagDelegate.bagLookUp(bagBean);
									bagForm.setBagBeanList(bagBeanList);
									  PaxTraxLog.logDebug("BagOverrideAction::releaseBags():: Successful ");				
								  }  
								}
								else
								{
									request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
									request.setAttribute(PaxTraxConstants.BAG_RELEASED, PaxTraxConstants.SUCCESS);
									//request.setAttribute(PaxTraxConstants.OPERATION, PaxTraxConstants.SUCCESS);
									bagBeanList =bagDelegate.bagLookUp(bagBean);
									bagForm.setBagBeanList(bagBeanList);
								}
							}
						}
						if(i!=1)
						{	
							request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
							request.setAttribute(PaxTraxConstants.BAG_SEARCH_NOT_FOUND, PaxTraxConstants.SUCCESS);
						}
					}
				}
				
				else
		
				{
					
					request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
					request.setAttribute(PaxTraxConstants.DATE_FLIGHT_VALIDATION, PaxTraxConstants.SUCCESS);
				  
				}
		
	  }
		  catch (BagOverrideException e) {
	  PaxTraxLog.logDebug("BagOverrideAction::releaseBags():: BagRelease exception "
					  + e.getErrorCode() + ", "+ e.getMessage());
	  request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
	  request.setAttribute(PaxTraxConstants.ERROR,"true");
	  request.setAttribute("ErrorCode", ""+e.getErrorCode());
//	  Added/Modified by David for CR 3659 ends
  }
	 
	 return(mapping.findForward(PaxTraxConstants.BAG_RELEASE_PAGE));
  }



  public ActionForward bagLookUp(
	  ActionMapping mapping,
	  ActionForm form,
	  HttpServletRequest request,
	  HttpServletResponse response)
	  throws PaxTraxSystemException {
	  // Added/Modified by David for CR 3659 starts
	  String index = request.getParameter(PaxTraxConstants.INDEX);
	  request.setAttribute("indexId",index);
	  BagOverrideForm bagForm = (BagOverrideForm) form;
	  BagStatusBean bagBean = bagForm.getBagBean();
	  HttpSession session = request.getSession();
	 
	  
	  BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
	  //David
	  ArrayList bagBeanList  = new ArrayList();
	  try
	  {
	  
		bagBeanList =bagDelegate.bagLookUp(bagBean);
 
		bagForm.setBagBeanList(bagBeanList);
	 	
	 	
	/* if(bagBean.getBagStatus()==10)
	 {
	 
	 request.setAttribute(PaxTraxConstants.BAG_RELEASED, PaxTraxConstants.SUCCESS);
	 }
	 else
	 request.setAttribute(PaxTraxConstants.BAG_RELEASED, PaxTraxConstants.FAILURE);*/
	
	  
	 request.setAttribute(PaxTraxConstants.BAGCHECK, PaxTraxConstants.SUCCESS);
	 request.setAttribute("index", "0");
	 
	 PaxTraxLog.logDebug("BagOverrideAction::bagLookUp():: Successful ");		
	 	  
	  }
	catch (BagOverrideException e) {
		  PaxTraxLog.logDebug("BagOverrideAction::bagLookUp():: BagRelease exception "
						  + e.getErrorCode() + ", "+ e.getMessage());
					//		Added/Modified by David for CO 6781 starts -- DP Tracking
					//	  System.out.println(+ e.getErrorCode() + ", "+ e.getMessage());
					if (e.getErrorCode() == 799)
					{
						request.setAttribute(PaxTraxConstants.BAG_NOT_FOUND,"true");
					}
					else if (e.getErrorCode() == 800)
					{
						request.setAttribute(PaxTraxConstants.FLIGHT_NT_FOUND,"true");
					}
					//		Added/Modified by David for CO 6781 ends -- DP Tracking
		 // request.setAttribute(PaxTraxConstants.BAG_NOT_FOUND,"true");
		  //request.setAttribute("ErrorCode", ""+e.getErrorCode());
		 // Added/Modified by David for CR 3659 ends
	  }
	  return(mapping.findForward(PaxTraxConstants.BAG_RELEASE_PAGE));
  }

  public ActionForward createassignSeaBin(
	  ActionMapping mapping,
	  ActionForm form,
	  HttpServletRequest request,
	  HttpServletResponse response)
	  throws PaxTraxSystemException {
	  BagOverrideForm bagForm = (BagOverrideForm) form;
	  BagStatusBean bagBean = new BagStatusBean();
	  BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
	  ArrayList truckList = bagDelegate.getTruckList();
	  if (truckList == null) {
		  truckList = new ArrayList();
	  }
	  bagForm.setTrucks(truckList);
	  bagForm.setBagBean(bagBean);
	  return(mapping.findForward(PaxTraxConstants.ASSIGN_SEA_BIN));
  }
  
  
  public ActionForward assignSeaPort(	
	  ActionMapping mapping,
	  ActionForm form,
	  HttpServletRequest request,
	  HttpServletResponse response)
	  throws PaxTraxSystemException,BagOverrideException {
	  try {
		  BagOverrideForm bagForm = (BagOverrideForm) form;
		  BagStatusBean bagBean = bagForm.getBagBean();
		  HttpSession session = request.getSession();
		  bagBean.setUser((String)session.getAttribute(PaxTraxConstants.USER));
		  bagBean.setTerminal(request.getRemoteHost());
			BagOverrideDelegate bagDelegate = new BagOverrideDelegate();
	
		  if (bagDelegate.assignSeaPort(bagBean)) {
	
			  request.setAttribute(PaxTraxConstants.RESULT, PaxTraxConstants.SUCCESS);
			  PaxTraxLog.logDebug("BagOverrideAction::assignSeaPort():: Successful ");	
		 	
		  }  
	  } catch (BagOverrideException e) {
		request.setAttribute(PaxTraxConstants.ERROR,"true");
		request.setAttribute("ErrorCode", ""+e.getErrorCode());
		
		PaxTraxLog.logDebug("BagOverrideAction::assignSeaPort():: BagRelease exception "
							+ e.getErrorCode() + ", "+ e.getMessage());
	 
	 
  }
	  return(mapping.findForward(PaxTraxConstants.ASSIGN_SEA_BIN));
  }

//Added by selvam for CA# 294102 ends




}
