package com.dfs.paxtrax.bagtracking.valueobject;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
/**
 * This class acts as a value object containing flight details.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/06/2004	P.C. Satish    	Created      
 */
public class FlightDetailsBean {
	private String referenceId;
	private String flightCode;
	private String flightNumber;
	private String flightTime;

	/**
	 * Returns the flightCode.
	 * @return String
	 */
	public String getFlightCode() {
		return flightCode;
	}

	/**
	 * Returns the flightNumber.
	 * @return String
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * Returns the referenceId.
	 * @return String
	 */
	public String getReferenceId() {
		return referenceId;
	}

	/**
	 * Sets the flightCode.
	 * @param flightCode The flightCode to set
	 */
	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}

	/**
	 * Sets the flightNumber.
	 * @param flightNumber The flightNumber to set
	 */
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	/**
	 * Sets the referenceId.
	 * @param referenceId The referenceId to set
	 */
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	/**
	 * Returns the flightTime.
	 * @return String
	 */
	public String getFlightTime() {
		return flightTime;
	}

	/**
	 * Sets the flightTime.
	 * @param flightTime The flightTime to set
	 */
	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}

}
