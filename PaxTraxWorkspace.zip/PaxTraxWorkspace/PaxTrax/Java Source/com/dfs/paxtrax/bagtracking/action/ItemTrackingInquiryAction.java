package com.dfs.paxtrax.bagtracking.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.bagtracking.actionform.ItemTrackingInquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.ItemTrackingInquiryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This is the action class which contains item attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 28/06/2004   Joseph Oommen A     Created   
*/

public class ItemTrackingInquiryAction extends PaxTraxAction {
	String forward = null;
	/**
	* Forwards to create Item Inquiry page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward itemEnquiryPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::ItemTrackingInquiryAction::itemEnquiryPage::Begin");
		ItemTrackingInquiryForm itemTrackingInquiryForm =
			(ItemTrackingInquiryForm) form;
		ItemTrackingInquiryBean itemTrackingInquiryBean =
			new ItemTrackingInquiryBean();
		itemTrackingInquiryForm.setItemTrackingInquiryBean(
			itemTrackingInquiryBean);
		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.BAG_TRACKING);
		forward = PaxTraxConstants.ITEM_ENQUIRY_REPORT_PAGE;
		PaxTraxLog.logDebug(
			"PaxTrax::ItemTrackingInquiryAction::itemEnquiryPage::End");
		return mapping.findForward(forward);
	}

	/**
	* Forwards to get the item details
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward getItemTrackingInquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax::ItemTrackingInquiryAction::getItemTrackingInquiry::Begin");
		ItemTrackingInquiryForm itemTrackingInquiryForm =
			(ItemTrackingInquiryForm) form;
		String history = request.getParameter("history");
		ItemTrackingInquiryBean itemTrackingInquiryBean = null;
		if (history != null && history.equals("Y")) {
			itemTrackingInquiryBean = new ItemTrackingInquiryBean();
			String itemNumber = request.getParameter("itemNumber");
			itemTrackingInquiryBean.setItemNumber(itemNumber);
			itemTrackingInquiryForm.setItemTrackingInquiryBean(
				itemTrackingInquiryBean);

		} else {

			itemTrackingInquiryBean =
				itemTrackingInquiryForm.getItemTrackingInquiryBean();
		}

		BagTrackingReportsDelegate bagTrackingReportsDelegate =
			new BagTrackingReportsDelegate();
		try {
			ArrayList itemList =
				bagTrackingReportsDelegate.getItemTrackingInquiry(
					itemTrackingInquiryBean);
			if (itemList == null || itemList.size() == 0) {
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.LOCATION_ERROR,
					new ActionMessage(
						""
							+ PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.ERRORCODE,
					"" + PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND);
			} else {
				itemTrackingInquiryForm.setItemList(itemList);
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);
			}
			forward = PaxTraxConstants.ITEM_ENQUIRY_REPORT_PAGE;
		} catch (BagTrackingReportsException bagTrackingReportsException) {
			PaxTraxLog.logError(
				"Business Exception caught",
				bagTrackingReportsException);
		} catch (Exception ex) {
			forward = PaxTraxConstants.REPORT_ERROR;
		}

		PaxTraxLog.logDebug(
			"PaxTrax::ItemTrackingInquiryAction::getItemTrackingInquiry::End");
		return mapping.findForward(forward);
	}

	/**
	* Forwards to print Item Inquiry page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward printItemEnquiryPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {

		try {
			PaxTraxLog.logDebug(
				"PaxTrax::ItemTrackingInquiryAction::printItemEnquiryPage::Begin");
			ItemTrackingInquiryForm itemTrackingInquiryForm =
				(ItemTrackingInquiryForm) form;
			ArrayList itemList = itemTrackingInquiryForm.getItemList();
			String itemNumber =
				itemTrackingInquiryForm
					.getItemTrackingInquiryBean()
					.getItemNumber();
			ItemTrackingInquiryBean itemTrackingInquiryBean =
				new ItemTrackingInquiryBean();
			if (itemList != null) {
				itemTrackingInquiryForm.setItemList(itemList);
				itemTrackingInquiryBean.setItemNumber(itemNumber);
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);
			}
			itemTrackingInquiryForm.setItemTrackingInquiryBean(
				itemTrackingInquiryBean);
			PaxTraxLog.logDebug(
				"PaxTrax::ItemTrackingInquiryAction::printItemEnquiryPage::End");
			forward = PaxTraxConstants.ITEM_ENQUIRY_PRINT_PAGE;
		} catch (Exception ex) {

			forward = PaxTraxConstants.REPORT_ERROR;
		}

		return mapping.findForward(forward);

	}
}
