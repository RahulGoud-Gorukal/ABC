package com.dfs.paxtrax.bagtracking.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

 
/**
 * 
 * The bean class for stock at pickup location report
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 05/07/2004	Yuvarani			Created   
 */

public class StockAtPickupLocationBean extends PaxTraxValueObject
{
	public StockAtPickupLocationBean()
	{
	}
	
	private String cage = null;
	
	private String departureDateTime = null;
	
	private String shift = null;
	
	private int totalNoOfCartons;

	private String apBinLocation = null;
	
	private ArrayList cageShelfList = null;
	
	private String moduleId = null;
	
	private String cageCycleId = null;
	/**
	 * Returns the cage.
	 * @return String
	 */
	public String getCage()
	{
		return cage;
	}

	/**
	 * Returns the cageShelfList.
	 * @return ArrayList
	 */
	public ArrayList getCageShelfList()
	{
		return cageShelfList;
	}

	/**
	 * Returns the departureDateTime.
	 * @return String
	 */
	public String getDepartureDateTime()
	{
		return departureDateTime;
	}

	/**
	 * Returns the shift.
	 * @return String
	 */
	public String getShift()
	{
		return shift;
	}

	/**
	 * Returns the totalNoOfCartons.
	 * @return String
	 */
	public int getTotalNoOfCartons()
	{
		return totalNoOfCartons;
	}

	/**
	 * Sets the cage.
	 * @param cage The cage to set
	 */
	public void setCage(String cage)
	{
		this.cage = cage;
	}

	/**
	 * Sets the cageShelfList.
	 * @param cageShelfList The cageShelfList to set
	 */
	public void setCageShelfList(ArrayList cageShelfList)
	{
		this.cageShelfList = cageShelfList;
	}

	/**
	 * Sets the departureDateTime.
	 * @param departureDateTime The departureDateTime to set
	 */
	public void setDepartureDateTime(String departureDateTime)
	{
		this.departureDateTime = departureDateTime;
	}

	/**
	 * Sets the shift.
	 * @param shift The shift to set
	 */
	public void setShift(String shift)
	{
		this.shift = shift;
	}

	/**
	 * Sets the totalNoOfCartons.
	 * @param totalNoOfCartons The totalNoOfCartons to set
	 */
	public void setTotalNoOfCartons(int totalNoOfCartons)
	{
		this.totalNoOfCartons = totalNoOfCartons;
	}

	/**
	 * Returns the apBinLocation.
	 * @return String
	 */
	public String getApBinLocation()
	{
		return apBinLocation;
	}

	/**
	 * Sets the apBinLocation.
	 * @param apBinLocation The apBinLocation to set
	 */
	public void setApBinLocation(String apBinLocation)
	{
		this.apBinLocation = apBinLocation;
	}

	/**
	 * Returns the moduleId.
	 * @return String
	 */
	public String getModuleId()
	{
		return moduleId;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(String moduleId)
	{
		this.moduleId = moduleId;
	}

	/**
	 * Returns the cageCycleId.
	 * @return String
	 */
	public String getCageCycleId()
	{
		return cageCycleId;
	}

	/**
	 * Sets the cageCycleId.
	 * @param cageCycleId The cageCycleId to set
	 */
	public void setCageCycleId(String cageCycleId)
	{
		this.cageCycleId = cageCycleId;
	}

}

