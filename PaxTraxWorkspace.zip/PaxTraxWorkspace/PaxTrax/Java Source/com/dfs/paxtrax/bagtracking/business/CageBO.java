package com.dfs.paxtrax.bagtracking.business;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.bagtracking.exception.CageException;
import com.dfs.paxtrax.bagtracking.valueobject.CageBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;

/**
*Remote interface for Enterprise Bean: LocationBO
*
* @author Cognizant Technology Solutions
* contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER                COMMENTS
* 29/05/2004    Joseph Oommen A     Created   
*/
public interface CageBO  extends EJBObject{
    
    
   /**
     * Saves cage details by invoking BO method.
     * @param cageBean CageBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in saving cage details
     */
    public void saveCageDetails(CageBean cageBean) throws RemoteException,PaxTraxSystemException,CageException;
    
     /**
     * updates the cage details by invoking BO method.
     * @param cageBean CageBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in updating cage details
     */
    public void updateCageDetails(CageBean cageBean) throws RemoteException,PaxTraxSystemException,CageException;
    
    /**
     * Removes the cage details by invoking BO method.
     * @param cageBean CageBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in removing cage details
     */
    public void removeCageDetails(CageBean cageBean) throws RemoteException,PaxTraxSystemException,CageException;
    
    /**
     * Search the cage details by invoking BO method.
     * @param cageBean CageBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in search cage details
     */
    public ArrayList searchCageDetails(CageBean cageBean) throws RemoteException,PaxTraxSystemException,CageException;
    
    /**
     * loads the cage details by invoking BO method.
     * @param cageBean CageBean object
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in loading cage details
     */
    public CageBean loadCageDetails(CageBean cageBean) throws RemoteException,PaxTraxSystemException,CageException;
}
