package com.dfs.paxtrax.bagtracking.valueobject;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;

/**
* This is valueobject class which contains Cage attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 26/06/2004    Joseph Oommen A Created   
*/
public class DepartmentBean extends PaxTraxValueObject
{
	private String departmentCode =null;
	private String departmentDescription = null;
	private String purchaseAmount =null;
	private String purchaseQty = null;
	private ArrayList itemList =null;
	private String qtyLimitExceeds =null;
	private String amtLimitExceeds =null;
	
	/**
	 * Returns the departmentCode.
	 * @return String
	 */
	public String getDepartmentCode()
	{
		return departmentCode;
	}

	/**
	 * Returns the departmentDescription.
	 * @return String
	 */
	public String getDepartmentDescription()
	{
		return departmentDescription;
	}

	/**
	 * Returns the itemList.
	 * @return ArrayList
	 */
	public ArrayList getItemList()
	{
		return itemList;
	}

	/**
	 * Returns the purchaseAmount.
	 * @return String
	 */
	public String getPurchaseAmount()
	{
		return purchaseAmount;
	}

	/**
	 * Sets the departmentCode.
	 * @param departmentCode The departmentCode to set
	 */
	public void setDepartmentCode(String departmentCode)
	{
		this.departmentCode = departmentCode;
	}

	/**
	 * Sets the departmentDescription.
	 * @param departmentDescription The departmentDescription to set
	 */
	public void setDepartmentDescription(String departmentDescription)
	{
		this.departmentDescription = departmentDescription;
	}

	/**
	 * Sets the itemList.
	 * @param itemList The itemList to set
	 */
	public void setItemList(ArrayList itemList)
	{
		this.itemList = itemList;
	}

	/**
	 * Sets the purchaseAmount.
	 * @param purchaseAmount The purchaseAmount to set
	 */
	public void setPurchaseAmount(String purchaseAmount)
	{
		this.purchaseAmount = purchaseAmount;
	}

	/**
	 * Returns the amtLimitExceeds.
	 * @return String
	 */
	public String getAmtLimitExceeds()
	{
		return amtLimitExceeds;
	}

	/**
	 * Returns the qtyLimitExceeds.
	 * @return String
	 */
	public String getQtyLimitExceeds()
	{
		return qtyLimitExceeds;
	}

	/**
	 * Sets the amtLimitExceeds.
	 * @param amtLimitExceeds The amtLimitExceeds to set
	 */
	public void setAmtLimitExceeds(String amtLimitExceeds)
	{
		this.amtLimitExceeds = amtLimitExceeds;
	}

	/**
	 * Sets the qtyLimitExceeds.
	 * @param qtyLimitExceeds The qtyLimitExceeds to set
	 */
	public void setQtyLimitExceeds(String qtyLimitExceeds)
	{
		this.qtyLimitExceeds = qtyLimitExceeds;
	}

	/**
	 * Returns the purchaseQty.
	 * @return String
	 */
	public String getPurchaseQty()
	{
		return purchaseQty;
	}

	/**
	 * Sets the purchaseQty.
	 * @param purchaseQty The purchaseQty to set
	 */
	public void setPurchaseQty(String purchaseQty)
	{
		this.purchaseQty = purchaseQty;
	}

}
