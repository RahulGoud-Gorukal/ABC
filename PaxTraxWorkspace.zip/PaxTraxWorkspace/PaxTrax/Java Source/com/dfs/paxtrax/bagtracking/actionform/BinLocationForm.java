package com.dfs.paxtrax.bagtracking.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.valueobject.BinLocationBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;


/**
 * This is action form which contains bin location attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 18/05/2004   R.R.Yuvarani	    Created   
*/

public class BinLocationForm extends PaxTraxActionForm {

    // The bean that stores all BinLoc Details for the form
    private BinLocationBean binLocationBean = null;
    
   //List of pickup locations
   private ArrayList pickupLocationList = null;
   
	/**
	 * Returns the binLocationBean.
	 * @return BinLocationBean
	 */
	public BinLocationBean getBinLocationBean()
	{
		return binLocationBean;
	}

	/**
	 * Sets the binLocationBean.
	 * @param binLocationBean The binLocationBean to set
	 */
	public void setBinLocationBean(BinLocationBean binLocationBean)
	{
		this.binLocationBean = binLocationBean;
	}

	/**
	 * Returns the pickupLocationList.
	 * @return ArrayList
	 */
	public ArrayList getPickupLocationList()
	{
		return pickupLocationList;
	}
	
	/**
	 * Sets the pickupLocationList.
	 * @param pickupLocationList The pickupLocationList to set
	 */
	public void setPickupLocationList(ArrayList pickupLocationList)
	{
		this.pickupLocationList = pickupLocationList;
	}

	public void reset(ActionMapping mapping,HttpServletRequest request)
	{
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if (page != null)
		{
			if (!page.equals(PaxTraxConstants.BIN_LOCATION_CONFIRMATION)
				&& !page.equals(PaxTraxConstants.MAINTAIN_BIN_LOCATION_CONFIRMATION)
				&& !page.equals(PaxTraxConstants.SEARCH_BIN_LOCATION_PAGE))
			{
			if (binLocationBean != null)
			{
				binLocationBean.setCapacity(null);
			//binLocationBean.setUrgentBags(false);
				binLocationBean.setHoldingLocation("N");
			}
			}
		}
	}
}
