package com.dfs.paxtrax.bagtracking.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.xalan.transformer.TrAXFilter;

import com.dfs.paxtrax.bagtracking.actionform.BagTrackingReportsForm;
import com.dfs.paxtrax.bagtracking.actionform.TracingRefundedBagForm;

import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.TracingRefundedBagBean;

import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * 
 * The Action Class for Tracing Refunded Bags related actions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Jaganmohan Gopinath
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/07/2007	Vijay			Created   
 */
public class TracingRefundedBagAction extends PaxTraxAction {
	/**
	 * This method is used to display the Refunded bags daily summary report page.
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward getRefundedBagPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) 
		throws PaxTraxSystemException{
		PaxTraxLog.logDebug(
			"PaxTrax::TracingRefundedBagAction::getRefundedBagPage:Begin");
		TracingRefundedBagForm tracingRefundedBagForm =
			(TracingRefundedBagForm) form;
		TracingRefundedBagBean tracingRefundedBagBean = new TracingRefundedBagBean();
	
		Calendar cal = Calendar.getInstance();
		int day = cal.get(Calendar.DATE);
		int month = cal.get(Calendar.MONTH) + 1;
		int year = cal.get(Calendar.YEAR);
			
		String currentDate = "";
		currentDate = "" + year + "/" + (month<10 ? "0" + month : "" + month) + "/" + (day<10 ? "0" + day : "" + day);
		PaxTraxLog.logDebug(
			"PaxTrax::TracingRefundedBagAction::getRefundedBagPage:Date"+currentDate);
		tracingRefundedBagBean.setRefundedDate(currentDate);
		tracingRefundedBagForm.setRefundedBagList(new ArrayList());
		tracingRefundedBagForm.setTracingRefundedBagBean(tracingRefundedBagBean);
		PaxTraxLog.logDebug(
			"PaxTrax::TracingRefundedBagAction::getRefundedBagPage:end");
		return (mapping.findForward(PaxTraxConstants.TRACING_REFUNDED_BAGS));
	}

	/**
	 * This method is used to display the refunded and received bag details for the specfied
	 * search criteria
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
	public ActionForward getRefundedBagsDetails(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) 
		throws PaxTraxSystemException{
		try 
		{
			PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails:Begin");
			TracingRefundedBagForm tracingRefundedBagForm = (TracingRefundedBagForm) form;
			TracingRefundedBagBean tracingRefundedBagBean = tracingRefundedBagForm.getTracingRefundedBagBean();
			BagTrackingReportsDelegate bagTrackingRptDelegate = new BagTrackingReportsDelegate();
			ArrayList refundedBagList = new ArrayList();

			PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails:Date"+tracingRefundedBagBean.getRefundedDate());
			PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails::Preorder "+tracingRefundedBagBean.getPreOrder());
			PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails::Intl :"+tracingRefundedBagBean.getInternational());
			
			refundedBagList =	bagTrackingRptDelegate.getRefundedBagList(tracingRefundedBagBean);
			tracingRefundedBagForm.setRefundedBagList(refundedBagList);
			if (refundedBagList != null && refundedBagList.size() > 0) 
			{
				request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
				PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails:totalBagsRefunded :"
						+ refundedBagList.size());
			} 
			else 
			{
				request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.FAILURE);
			}
		
		} 
		catch (PaxTraxSystemException pse) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails:"+ pse);
			return mapping.findForward(PaxTraxConstants.REPORT_ERROR);
		}
		PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::getRefundedBagsDetails:End");		
		return mapping.findForward(PaxTraxConstants.TRACING_REFUNDED_BAGS);
	}

	/**
	 * This method is used to receive the bags that are refunded in Airport 
	 * @param mapping Action mapping
	 * @param form Action form
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @return ActionForward Action forward
	 */
		
	public ActionForward receiveBagsInGalleria(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) 
		throws PaxTraxSystemException{
		try 
		{
			PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::receiveBagsatGalleria:Begin");
			TracingRefundedBagForm tracingRefundedBagForm = (TracingRefundedBagForm) form;
			TracingRefundedBagBean tracingRefundedBean = tracingRefundedBagForm.getTracingRefundedBagBean();
			BagTrackingReportsDelegate bagTrackingRptDelegate = new BagTrackingReportsDelegate();;
			ArrayList refundedBagList = new ArrayList(); 
			HttpSession session = request.getSession();
			
			String userId = (String) session.getAttribute(PaxTraxConstants.USER);			
			refundedBagList = tracingRefundedBagForm.getRefundedBagList();			
			refundedBagList = bagTrackingRptDelegate.receiveBagsInGalleria(refundedBagList,userId);
       		tracingRefundedBagForm.setRefundedBagList(refundedBagList);
			request.setAttribute(PaxTraxConstants.RESULT,PaxTraxConstants.SUCCESS);
		} 
		catch (PaxTraxSystemException pse) 
		{
			PaxTraxLog.logError("Exception in PaxTrax::TracingRefundedBagAction::receiveBagsatGalleria"
					+ pse);
			return (mapping.findForward(PaxTraxConstants.REPORT_ERROR));
		}
		PaxTraxLog.logDebug("PaxTrax::TracingRefundedBagAction::receiveBagsatGalleria:End");
		return mapping.findForward(PaxTraxConstants.TRACING_REFUNDED_BAGS);
	}
}