package com.dfs.paxtrax.bagtracking.actionform;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import com.dfs.paxtrax.bagtracking.valueobject.BinLocationReportBean;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 24/06/2004	Cyril Prince.J	Created   
 * 29/07/04     Joseph Oommen A Modified
 */
public class BinLocEnquiryForm extends PaxTraxActionForm
{

	//private boolean isAirportBin;
	//private String binStratLocation;
	//private String binEndLocation;

	private ArrayList binLocResultList;
	//private ArrayList jalBinLocList;

	private ArrayList binLocFromList;
	private ArrayList binLocToList;
	private BinLocationReportBean binLocationReportBean = null;
	private String endLocation = null;
	private String startLocation = null;
	/**
	 * Returns the binLocFromList.
	 * @return ArrayList
	 */
	public ArrayList getBinLocFromList()
	{
		return binLocFromList;
	}

	/**
	 * Returns the binLocResultList.
	 * @return ArrayList
	 */
	public ArrayList getBinLocResultList()
	{
		return binLocResultList;
	}

	/**
	 * Returns the binLocToList.
	 * @return ArrayList
	 */
	public ArrayList getBinLocToList()
	{
		return binLocToList;
	}

	/**
	 * Sets the binLocFromList.
	 * @param binLocFromList The binLocFromList to set
	 */
	public void setBinLocFromList(ArrayList binLocFromList)
	{
		this.binLocFromList = binLocFromList;
	}

	/**
	 * Sets the binLocResultList.
	 * @param binLocResultList The binLocResultList to set
	 */
	public void setBinLocResultList(ArrayList binLocResultList)
	{
		this.binLocResultList = binLocResultList;
	}

	/**
	 * Sets the binLocToList.
	 * @param binLocToList The binLocToList to set
	 */
	public void setBinLocToList(ArrayList binLocToList)
	{
		this.binLocToList = binLocToList;
	}

	/**
	 * Returns the binLocationReportBean.
	 * @return BinLocationReportBean
	 */
	public BinLocationReportBean getBinLocationReportBean()
	{
		return binLocationReportBean;
	}

	/**
	 * Sets the binLocationReportBean.
	 * @param binLocationReportBean The binLocationReportBean to set
	 */
	public void setBinLocationReportBean(BinLocationReportBean binLocationReportBean)
	{
		this.binLocationReportBean = binLocationReportBean;
	}

	/**
	 * Returns the endLocation.
	 * @return String
	 */
	public String getEndLocation()
	{
		return endLocation;
	}

	/**
	 * Returns the startLocation.
	 * @return String
	 */
	public String getStartLocation()
	{
		return startLocation;
	}

	/**
	 * Sets the endLocation.
	 * @param endLocation The endLocation to set
	 */
	public void setEndLocation(String endLocation)
	{
		this.endLocation = endLocation;
	}

	/**
	 * Sets the startLocation.
	 * @param startLocation The startLocation to set
	 */
	public void setStartLocation(String startLocation)
	{
		this.startLocation = startLocation;
	}

}
