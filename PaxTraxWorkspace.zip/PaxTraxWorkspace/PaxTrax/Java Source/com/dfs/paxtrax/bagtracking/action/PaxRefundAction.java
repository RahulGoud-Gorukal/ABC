package com.dfs.paxtrax.bagtracking.action;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.dfs.paxtrax.bagtracking.actionform.PaxRefundForm;
import com.dfs.paxtrax.bagtracking.exception.PaxRefundException;
import com.dfs.paxtrax.bagtracking.service.PaxRefundDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.PaxRefundBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaginationHelper;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This is the action class which contains Pax Refund attributes
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 26/07/2004   Joseph Oommen A     Created   
*/

public class PaxRefundAction extends PaxTraxAction
{
	String forward = null;
	/**
	* Forwards to create Pax Refund Page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward createFlightChangeReportPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::createFlightChangeReportPage::Begin");

		PaxRefundForm paxRefundForm = (PaxRefundForm) form;
		PaxRefundBean paxRefundBean = new PaxRefundBean();
		paxRefundBean.setNotificationStatus("1");
		paxRefundBean.setNotificationType("1");
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		String currDate = dateFormat.format(cal.getTime());
		
		paxRefundBean.setFromDate(currDate);
		paxRefundBean.setToDate(currDate);
		
		paxRefundForm.setPaxRefundBean(paxRefundBean);
		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.BAG_TRACKING);
		forward = "flightChangeReportPage";
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::createFlightChangeReportPage::End");
		return mapping.findForward(forward);
	}

	/**
	* Search the Flight change Report items 
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException
	*/
	public ActionForward searchFlightChangeItems(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundAction::searchFlightChangeItems::Begin");
		forward = "flightChangeReportPage";
		int pageNumber = 0;
		/*String pageNumberStr = null;
		pageNumberStr = (String) request.getParameter("PaxRefundPageNumber");
		request.setAttribute(
			"PaxRefundPageNumber",
			Integer.toString(pageNumber));
		pageNumberStr =
			((pageNumberStr == null)
				|| pageNumberStr.equals(SQLConstants.BLANK))
				? null
				: pageNumberStr;
		if (pageNumberStr != null
			&& !pageNumberStr.equals("")
			&& !pageNumberStr.equals("null"))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}*/
		if (pageNumber == 0)
		{
			pageNumber = 1;
		}
		HttpSession session = request.getSession();

		PaxRefundForm paxRefundForm = (PaxRefundForm) form;
		PaxRefundDelegate paxRefundDelegate = new PaxRefundDelegate();
		PaxRefundBean paxRefundBean = paxRefundForm.getPaxRefundBean();

		String fromDate = paxRefundBean.getFromDate();
		String toDate = paxRefundBean.getToDate();
		String notificationType = paxRefundBean.getNotificationType();
		String notificationStatus = paxRefundBean.getNotificationStatus();

		PaxRefundBean newBean = new PaxRefundBean();
		newBean.setFromDate(fromDate);
		newBean.setToDate(toDate);
		newBean.setNotificationType(notificationType);
		newBean.setNotificationStatus(notificationStatus);
		paxRefundForm.setPaxRefundBean(newBean);

		ArrayList allRecords = new ArrayList();
		ArrayList currentRecords = new ArrayList();
		try
		{
			allRecords =
				paxRefundDelegate.searchFlightChangeDetails(paxRefundBean);
			if (allRecords == null || allRecords.size() < 1)
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.LOCATION_ERROR,
					new ActionMessage(""
							+ PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.ERRORCODE,
					"" + PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND);

			}
			else
			{
				session.setAttribute("flightChangeRecords", allRecords);
				session.setAttribute(
					"sizeOfAllFlightChangeRecords",
					Integer.toString(allRecords.size()));
				PaginationHelper paginationHelper =
					PaginationHelper.getInstance();
				currentRecords =
					paginationHelper.getCurrentTableContent(
						allRecords,
						pageNumber,
						PaxTraxConstants.RECORDS_PER_PAGE);
				paxRefundForm.setResultList(allRecords);
				request.setAttribute(
					"FlightChangeReportPageNumber",
					Integer.toString(pageNumber));
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);

			}
		}
		catch (PaxRefundException paxRefundException)
		{

		}

		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::searchFlightChangeItems::End");

		return mapping.findForward(forward);
	}

	/**
	* changes the language
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::changeLanguage::Begin");

		String language = request.getParameter(PaxTraxConstants.LANGUAGE);

		String country = request.getParameter(PaxTraxConstants.COUNTRY);

		super.changeLanguage(request, language, country);

		String errorCode = request.getParameter(PaxTraxConstants.ERRORCODE);

		String operation = request.getParameter(PaxTraxConstants.OPERATION);
		if (operation != null)
		{
			request.setAttribute(PaxTraxConstants.OPERATION, operation);
		}
		String pageNumber =
			(String) request.getParameter("PaxRefundPageNumber");
		if (pageNumber != null)
		{
			request.setAttribute("PaxRefundPageNumber", pageNumber);
		}
		if ((errorCode != null) && !errorCode.equals("-1"))
		{
			ActionMessages messages = new ActionMessages();
			messages.add(
				PaxTraxConstants.SKU_ERROR,
				new ActionMessage(errorCode));
			request.setAttribute(Globals.MESSAGE_KEY, messages);
			request.setAttribute(PaxTraxConstants.ERRORCODE, errorCode);
		}

		String page = request.getParameter(PaxTraxConstants.PAGE);
		if(page != null && page.equals("paxRefund"))
		{
			forward = "paxRefundPage";
		}
		if(page != null && page.equals("paxFlightChange"))
		{
			forward = "flightChangeReportPage";
		}
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::changeLanguage::End");

		return mapping.findForward(forward);
	}

	/**
	* moves to next page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/

	public ActionForward nextPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		PaxRefundForm paxRefundForm = (PaxRefundForm) form;
		HttpSession session = request.getSession();

		String pageNumberStr = request.getParameter("PaxRefundPageNumber");
		int pageNumber = 0;
		pageNumberStr =
			((pageNumberStr == null) || pageNumberStr.equals(""))
				? null
				: pageNumberStr;
		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */

		if (pageNumber == 0)
		{
			pageNumber = 1;
		}
		ArrayList allRecords = new ArrayList(),
			currentRecords = new ArrayList();
		allRecords = (ArrayList) session.getAttribute("paxRefundRecords");

		int size1 = 0;
		size1 = allRecords.size();
		String tempBagNo = "";
		boolean actionEnabled = false;

		for (int i = 0; i < size1; i++)
		{
			PaxRefundBean refundBean1 = (PaxRefundBean) allRecords.get(i);
			PaxRefundBean resultBean = refundBean1;

			String bagNo = refundBean1.getBagStatusBean().getBagNumber();
			String flightChangeAction = refundBean1.getActionTaken();
			if (tempBagNo == null
				|| tempBagNo.equals("")
				|| !tempBagNo.equals(bagNo))
			{
				if (flightChangeAction.equals("Y"))
				{
					resultBean.setActionDisabled(true);
					actionEnabled = false;
				}
				else
				{
					resultBean.setActionDisabled(false);
					actionEnabled = true;
				}

			}
			else
			{
				if (flightChangeAction.equals("Y"))
				{
					resultBean.setActionDisabled(true);
					actionEnabled = false;
				}
				else
					if (actionEnabled)
					{
						resultBean.setActionDisabled(true);

					}
					else
					{
						resultBean.setActionDisabled(false);
						actionEnabled = true;
					}
			}
			allRecords.remove(i);
			allRecords.add(i, resultBean);
			tempBagNo = bagNo;

		}
		session.setAttribute("paxRefundRecords", allRecords);
		/*ArrayList currentListForm = paxRefundForm.getResultList();
		
		int size1 = 0, size2 = 0;
		
		if (allRecords != null)
		{
			size1 = allRecords.size();
		}
		if (currentListForm != null)
		{
			size2 = currentListForm.size();
		}
		for (int k = 0; k < size2; k++)
		{
			PaxRefundBean refundBean3 = (PaxRefundBean) allRecords.get(k);
				
		}
		
		for (int i = 0; i < size1; i++)
		{
			PaxRefundBean refundBean1 = (PaxRefundBean) allRecords.get(i);
		
			for (int j = 0; j < size2; j++)
			{
				PaxRefundBean refundBean2 =
					(PaxRefundBean) currentListForm.get(j);
		
				if (refundBean1.getRecordId() == refundBean2.getRecordId())
				{

				}
		
				if (refundBean1.getRecordId() == refundBean2.getRecordId()
					&& !refundBean1.getActionTaken().equals(
						refundBean2.getActionTaken()))
				{
					allRecords.remove(i);
					allRecords.add(i, refundBean2);
				}
		
			}
		}*/

		PaginationHelper paginationHelper = PaginationHelper.getInstance();
		currentRecords =
			paginationHelper.getCurrentTableContent(
				allRecords,
				pageNumber,
				PaxTraxConstants.RECORDS_PER_PAGE);
		paxRefundForm.setResultList(currentRecords);
		request.setAttribute(
			"PaxRefundPageNumber",
			Integer.toString(pageNumber));
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.SUCCESS);
		forward = "paxRefundPage";
		return mapping.findForward(forward);
	}

	public ActionForward savePaxRefund(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{


		PaxRefundDelegate paxRefundDelegate = new PaxRefundDelegate();
		HttpSession session = request.getSession();
		ArrayList allRecords = new ArrayList();
		allRecords = (ArrayList) session.getAttribute("paxRefundRecords");
		
		int size1 = allRecords.size();
		String tempBagNo = "";
		boolean actionEnabled = false;
		
				

		for (int i = 0; i < size1; i++)
		{
			PaxRefundBean refundBean1 = (PaxRefundBean) allRecords.get(i);
			
			PaxRefundBean resultBean = refundBean1;

			String bagNo = refundBean1.getBagStatusBean().getBagNumber();
			String flightChangeAction = refundBean1.getActionTaken();
			if (tempBagNo == null
				|| tempBagNo.equals("")
				|| !tempBagNo.equals(bagNo))
			{
				if (flightChangeAction.equals("Y"))
				{
					resultBean.setActionDisabled(true);
					actionEnabled = false;
				}
				else
				{
					resultBean.setActionDisabled(false);
					actionEnabled = true;
				}

			}
			else
			{
				if (flightChangeAction.equals("Y"))
				{
					resultBean.setActionDisabled(true);
					actionEnabled = false;
				}
				else
					if (actionEnabled)
					{
						resultBean.setActionDisabled(true);

					}
					else
					{
						resultBean.setActionDisabled(false);
						actionEnabled = true;
					}
			}
			allRecords.remove(i);
			allRecords.add(i, resultBean);
			tempBagNo = bagNo;

		}
		session.setAttribute("paxRefundRecords", allRecords);
		try
		{
			paxRefundDelegate.savePaxRefund(allRecords);
		}
		catch (PaxRefundException paxRefundException)
		{
		}

		String pageNumberStr = request.getParameter("PaxRefundPageNumber");
		int pageNumber = 0;
		pageNumberStr =
			((pageNumberStr == null) || pageNumberStr.equals(""))
				? null
				: pageNumberStr;
		if ((pageNumberStr != null))
		{
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		/* First time goes to Database and fetches the data and next time
		 * it will fetch record from session
		 */

		if (pageNumber == 0)
		{
			pageNumber = 1;
		}
		request.setAttribute(
			"PaxRefundPageNumber",
			Integer.toString(pageNumber));
		request.setAttribute(
			PaxTraxConstants.OPERATION,
			PaxTraxConstants.SUCCESS);
		forward = "paxRefundPage";
		return mapping.findForward(forward);
	}
	
	/**
	 * Method printPaxRefund - Displays Print Pax Refund Report popup
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward printFlightChangeReport(ActionMapping mapping,
		ActionForm form, HttpServletRequest request, 
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::printPaxRefund::Begin");
		forward = "printFlightChangeReportPage";
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::printPaxRefund::End");			
		return mapping.findForward(forward);
	}
	
	
	/**
	* Forwards to create Pax Refund Page
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward createPaxRefundPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::paxRefundPage::Begin");

		PaxRefundForm paxRefundForm = (PaxRefundForm) form;
		PaxRefundBean paxRefundBean = new PaxRefundBean();
		paxRefundBean.setNotificationStatus("1");
		paxRefundBean.setNotificationType("1");
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		String currDate = dateFormat.format(cal.getTime());
		
		paxRefundBean.setFromDate(currDate);
		paxRefundBean.setToDate(currDate);
		
		paxRefundForm.setPaxRefundBean(paxRefundBean);
		paxRefundForm.setResultList(null);
		HttpSession session = request.getSession();
		session.setAttribute(
			PaxTraxConstants.MODULE_NAME,
			PaxTraxConstants.BAG_TRACKING);
		forward = "paxRefundPage";
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::paxRefundPage::End");
		return mapping.findForward(forward);
	}

	/**
	* Search the refund items 
	* @param mapping ActionMapping
	* @param form ActionForm
	* @param request HttpServletRequest
	* @param response HttpServletResponse
	* @return ActionForward Action forward
	* @throws PaxTraxSystemException This exception is thrown
	* if there is any problem in forwarding to create Cage Page
	*/
	public ActionForward searchRefundItems(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::PaxRefundAction::searchRefundItems::Begin");
		forward = "paxRefundPage";
		HttpSession session = request.getSession();

		PaxRefundForm paxRefundForm = (PaxRefundForm) form;
		PaxRefundDelegate paxRefundDelegate = new PaxRefundDelegate();
		PaxRefundBean paxRefundBean = paxRefundForm.getPaxRefundBean();

//		String fromDate = paxRefundBean.getFromDate();
//		String toDate = paxRefundBean.getToDate();

//		PaxRefundBean newBean = new PaxRefundBean();
//		newBean.setFromDate(fromDate);
//		newBean.setToDate(toDate);
//		newBean.setNotificationType(notificationType);
//		newBean.setNotificationStatus(notificationStatus);
//		paxRefundForm.setPaxRefundBean(newBean);

		ArrayList allRecords = new ArrayList();
//		ArrayList currentRecords = new ArrayList();
		try
		{
			allRecords =
				paxRefundDelegate.searchPaxRefundDetails(paxRefundBean);
			if (allRecords == null || allRecords.size() < 1)
			{
				ActionMessages messages = new ActionMessages();
				messages.add(
					PaxTraxConstants.LOCATION_ERROR,
					new ActionMessage(""
							+ PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND));
				request.setAttribute(Globals.MESSAGE_KEY, messages);
				request.setAttribute(
					PaxTraxConstants.ERRORCODE,
					"" + PaxTraxConstants.BT_ITEM_ENQUIRY_NO_RECORDS_FOUND);
			}
			else
			{
				session.setAttribute("paxRefundRecords", allRecords);
				session.setAttribute(
					"sizeOfAllPaxRefundRecords",
					Integer.toString(allRecords.size()));
				paxRefundForm.setResultList(allRecords);
				request.setAttribute(
					PaxTraxConstants.OPERATION,
					PaxTraxConstants.SUCCESS);

			}
		}
		catch (PaxRefundException paxRefundException)
		{
			PaxTraxLog.logError("PaxTrax::PaxRefundAction::paxRefundException",
								paxRefundException);			
		}

		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::searchRefundItems::End");

		return mapping.findForward(forward);
	}
	
	/**
	 * Method printPaxRefund - Displays Print Pax Refund Report popup
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 * @throws PaxTraxSystemException
	 */
	public ActionForward printPaxRefund(ActionMapping mapping,
		ActionForm form, HttpServletRequest request, 
		HttpServletResponse response)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::printPaxRefund::Begin");
		forward = "printPaxRefundPage";
		PaxTraxLog.logDebug("PaxTrax::PaxRefundAction::printPaxRefund::End");			
		return mapping.findForward(forward);
	}
}
