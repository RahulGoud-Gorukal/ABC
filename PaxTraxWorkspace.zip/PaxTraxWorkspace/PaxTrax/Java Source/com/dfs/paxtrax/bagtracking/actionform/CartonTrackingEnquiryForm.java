package com.dfs.paxtrax.bagtracking.actionform;

import java.util.ArrayList;

import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.bagtracking.valueobject.CartonTrackingEnquiryBean;

/**
 * @author 115157
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CartonTrackingEnquiryForm extends PaxTraxActionForm {
	private ArrayList cartons;
	private String reportDate;
	private CartonTrackingEnquiryBean cartonBean;


	/**
	 * Returns the cartons.
	 * @return ArrayList
	 */
	public ArrayList getCartons() {
		return cartons;
	}

	/**
	 * Sets the cartons.
	 * @param cartons The cartons to set
	 */
	public void setCartons(ArrayList cartons) {
		this.cartons = cartons;
	}

	/**
	 * Returns the cartonBean.
	 * @return CartonTrackingEnquiryBean
	 */
	public CartonTrackingEnquiryBean getCartonBean() {
		return cartonBean;
	}

	/**
	 * Sets the cartonBean.
	 * @param cartonBean The cartonBean to set
	 */
	public void setCartonBean(CartonTrackingEnquiryBean cartonBean) {
		this.cartonBean = cartonBean;
	}

	/**
	 * Returns the reportDate.
	 * @return String
	 */
	public String getReportDate() {
		return reportDate;
	}

	/**
	 * Sets the reportDate.
	 * @param reportDate The reportDate to set
	 */
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}

}
