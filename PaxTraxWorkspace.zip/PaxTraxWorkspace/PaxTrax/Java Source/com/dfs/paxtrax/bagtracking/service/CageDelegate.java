package com.dfs.paxtrax.bagtracking.service;

/* * 
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.bagtracking.business.CageBO;
import com.dfs.paxtrax.bagtracking.business.CageBOHome;
import com.dfs.paxtrax.bagtracking.exception.CageException;
import com.dfs.paxtrax.bagtracking.valueobject.CageBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

/**
* This Delegate  class is used for inserting and updating cage records
* 
* 
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 29/05/2004    Joseph Oommen A Created
*/
public class CageDelegate
{
    
    /*
     * Holds service locator instance
     */
    private ServiceLocator serviceLocator = null;
    /*
     * Holds the Home interface
     */
    private CageBOHome cageBOHome = null;
    /*
     * Hold the remote interface
     */
    private CageBO cageBO = null;
    /*
     *Default Construtor for LocationDelegate
     */

	public CageDelegate()
	{
	}
    
    private void jndiCall() throws PaxTraxSystemException
    {

        PaxTraxLog.logDebug("PaxTrax::CageDelegate::jndiCall::Begin");
        try
        {
            serviceLocator = ServiceLocator.getInstance();
            cageBOHome =
                (CageBOHome) PortableRemoteObject.narrow(
                    serviceLocator.getEJBHome(
                        PaxTraxConstants.CAGE_BO_HOME_JNDI),
                    CageBOHome.class);
        }
        catch (NamingException ne)
        {
            throw new PaxTraxSystemException(ne);
        }
        if (cageBOHome == null)
        {
            throw new PaxTraxSystemException(
               250);
        }
        try
        {
            cageBO = cageBOHome.create();
        }
        catch (CreateException ce)
        {
            throw new PaxTraxSystemException(ce);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug("PaxTrax::CageDelegate::jndiCall::End");
    }


    /**
     * Saves details details into the database by 
     * delegating the request to  the cage  bean. 
     * @param cageBean CageBean object
     * @throws PaxTraxSystemException,LocationException
     */
	public void saveCageDetails(CageBean cageBean) throws PaxTraxSystemException,CageException
	{
        
        PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::saveCageDetails::Begin");
        if (cageBOHome == null)
        {
            jndiCall();
        }
        try
        {
            cageBO.saveCageDetails(cageBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::saveCageDetails::End");
	}

	public void updateCageDetails(CageBean cageBean) throws PaxTraxSystemException,CageException
	{
         PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::updateCageDetails::Begin");
         
        if (cageBOHome == null)
        {
            jndiCall();
        }
        try
        {
         cageBO.updateCageDetails(cageBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::updateCageDetails::End");
          
	}

	public void removeCageDetails(CageBean cageBean) throws PaxTraxSystemException,CageException
	{
        
        PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::removeCageDetails::Begin");
         
        if (cageBOHome == null)
        {
            jndiCall();
        }
        try
        {
         cageBO.removeCageDetails(cageBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::removeCageDetails::End");
	}

	public ArrayList searchCageDetails(CageBean cageBean)throws 
		PaxTraxSystemException,CageException
	{
		ArrayList cageDetails = new ArrayList();
         if (cageBOHome == null)
        {
            jndiCall();
        }
        try
        {
          cageDetails = cageBO.searchCageDetails(cageBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
		return cageDetails;

	}
    
    public CageBean loadCageDetails(CageBean cageBean)throws PaxTraxSystemException,CageException
    {
           PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::loadCageDetails::Begin");
             CageBean resultBean  = new CageBean();
        if (cageBOHome == null)
        {
            jndiCall();
        }
        try
        {
          resultBean = cageBO.loadCageDetails(cageBean);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::CageDelegate::loadCageDetails::End");
            return resultBean;
    }
}
