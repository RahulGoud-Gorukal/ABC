package com.dfs.paxtrax.bagtracking.valueobject;


/* *
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;


/**
* This is valueobject class which contains bag status by flight attributes
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 07/07/2004    R.R.Yuvarani     Created   
*/

public class BagStatusByFlightInquiryStatusBean extends PaxTraxValueObject
{
	private String status = null;
	
	private int totalNoOfBags;
	
	/**
	 * Returns the status.
	 * @return String
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * Returns the totalNoOfBags.
	 * @return String
	 */
	public int getTotalNoOfBags()
	{
		return totalNoOfBags;
	}

	/**
	 * Sets the status.
	 * @param status The status to set
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * Sets the totalNoOfBags.
	 * @param totalNoOfBags The totalNoOfBags to set
	 */
	public void setTotalNoOfBags(int totalNoOfBags)
	{
		this.totalNoOfBags = totalNoOfBags;
	}

}
