package com.dfs.paxtrax.bagtracking.action;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.bagtracking.actionform.CageEnquiryForm;
import com.dfs.paxtrax.bagtracking.exception.BagTrackingReportsException;
import com.dfs.paxtrax.bagtracking.service.BagTrackingReportsDelegate;
import com.dfs.paxtrax.bagtracking.valueobject.CageStatusHistoryBean;
import com.dfs.paxtrax.common.action.PaxTraxAction;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This is a struts Form class for assigning cage to Airport Bin.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant 	- Sankaranarayanan srinivasan
 * DFS 					- Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 24/06/2004	Cyril Prince.J	Created   
 */

public class CageEnquiryAction extends PaxTraxAction
{
	/**
	 * Method getBinLocReportPage.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getCageTrackingReportPage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{

		PaxTraxLog.logInfo(
			"PaxTrax::CageEnquiryAction::getCageTrackingReportPage::Begin");
		ArrayList cageList = new ArrayList();

		/*try
		{
		
		BagTrackingReportsDelegate reportsDelegate =
			new BagTrackingReportsDelegate();
			cageList = reportsDelegate.getAllCages();
		}
		catch(PaxTraxSystemException e)
		{
			PaxTraxLog.logInfo("PaxTrax::CageEnquiryAction::getCageTrackingReportPage::End");
		}*/

		CageEnquiryForm cageEnquiryForm = (CageEnquiryForm) form;
		CageStatusHistoryBean cageStatusHistoryBean =
			new CageStatusHistoryBean();
		cageEnquiryForm.setCageStatusHistoryBean(cageStatusHistoryBean);
		PaxTraxLog.logInfo(
			"PaxTrax::CageEnquiryAction::getCageTrackingReportPage::End");
		return mapping.findForward("cageReport");

	}

	/**
	 * Method getBinLocReport.
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward getCageTrackingReport(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{

		PaxTraxLog.logInfo(
			"PaxTrax::CageEnquiryAction::getCageTrackingReport::Begin");
		String binLocationType = "";
		String cageNumber = null;

		CageEnquiryForm cageEnquiryForm = (CageEnquiryForm) form;

		CageStatusHistoryBean cageStatusHistoryBean =
			cageEnquiryForm.getCageStatusHistoryBean();
		
		if (request.getParameter("cageNumber") != null)
		{
			cageNumber = request.getParameter("cageNumber");
			cageStatusHistoryBean = new CageStatusHistoryBean();
			cageStatusHistoryBean.setCageNumber(cageNumber);
			request.setAttribute("backButton", "true");
		}
		
		String cageCycle = request.getParameter("cageCycle");
		if (cageCycle != null)
		{
			cageStatusHistoryBean.setCageCycle(cageCycle);

		}
		else
			cageStatusHistoryBean.setCageCycle("-1");

		PaxTraxLog.logInfo(
			"CageEnquiryAction:getCageTrackingReport() - Shelf No"
				+ (String) request.getAttribute("shelfNo"));

		BagTrackingReportsDelegate reportsDelegate =
			new BagTrackingReportsDelegate();
		CageStatusHistoryBean resultBean = new CageStatusHistoryBean();
		try
		{
			resultBean = reportsDelegate.getCageReport(cageStatusHistoryBean);
		
			request.setAttribute("generated", "true");
		}
		catch (PaxTraxSystemException e)
		{
			PaxTraxLog.logError(
				"CageEnquiryAction:getCageTrackingReport() Error" + e);
			return (mapping.findForward(PaxTraxConstants.REPORT_ERROR));
		}
		catch (BagTrackingReportsException btException)
		{
			PaxTraxLog.logDebug(
				"Business Exception in PaxTrax::CartonTrackingAction:: displayCartonDetails() ",
				btException);

			request.setAttribute("errorCode", "" + btException.getErrorCode());

		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"CageEnquiryAction:getCageTrackingReport() Error",
				e);
			return (mapping.findForward(PaxTraxConstants.REPORT_ERROR));
		}

		PaxTraxLog.logInfo(
			"PaxTrax::CageEnquiryAction::getCageTrackingReport::End");
			cageEnquiryForm.setCageStatusHistoryBean(resultBean);	
		return mapping.findForward("cageReport");
	}
	public ActionForward printCageEnquiry(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
	{
		String forward = null;
		try
		{
			PaxTraxLog.logDebug(
				"PaxTrax::CageEnquiryAction::printCageEnquiry::Begin");
			CageEnquiryForm cageForm = (CageEnquiryForm) form;

			request.setAttribute("generated", "true");
			PaxTraxLog.logDebug(
				"PaxTrax::CageEnquiryAction::printCageEnquiry::End");
			forward = "printCageReport";
		}
		catch (Exception ex)
		{

			forward = PaxTraxConstants.REPORT_ERROR;
		}
		return mapping.findForward(forward);
	}
}
