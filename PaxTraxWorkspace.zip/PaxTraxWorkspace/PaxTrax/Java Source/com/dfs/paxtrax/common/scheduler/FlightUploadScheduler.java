package com.dfs.paxtrax.common.scheduler;

/* 
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2014, DFS All rights reserved.
 *
 */

import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.service.FlightUploadDelegate;

/**
* This is a scheduler class which uploads Flight data to Wincor
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Mohammed Faheem
*
* @version    1.0
*
*/

public class FlightUploadScheduler extends TimerTask
{

	public FlightUploadScheduler()
	{
	}
	
	public void init()
	{
	}

	public void run()
	{
		try
		{
			FlightUploadDelegate flightDelegate = new FlightUploadDelegate();
			flightDelegate.flightData();

		}
		catch (PaxTraxSystemException paxtraxSystemException)
		{
			PaxTraxLog.logError("PaxTrax::FlightUploadScheduler : run()  PaxTrax System Exception ", paxtraxSystemException);
		}
	}
}
