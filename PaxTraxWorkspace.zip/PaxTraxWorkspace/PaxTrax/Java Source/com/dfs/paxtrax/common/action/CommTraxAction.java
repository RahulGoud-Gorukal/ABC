package com.dfs.paxtrax.common.action;


import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.dfs.paxtrax.common.actionform.CommTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;



/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CommTraxAction extends DispatchAction {

	public CommTraxAction()
	{
	}




	/**
     * This is the struts framework call back method which is invoked by Action servlet on execution of each action.
     *
     * @param mapping  The ActionMapping object
     * @param form     The ActionForm object
     * @param request  The HttpServletRequest object
     * @param response The HttpServletResponse object
     * @return ActionForward - Returns the ActionForward containing the
     *         next page.
     */

public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response) {
        ActionForward forward = null;
        String DEFAULT_COUNTRY = "JP";
        String DEFAULT_LANGUAGE = "en";
        try {

    	    HttpSession session = request.getSession();
    	    boolean valid = true;

		if(session==null)
			valid = false;

    	if ((session != null) && (session.getAttribute(PaxTraxConstants.USER_ID) == null))
    	    valid = false;

    	// Forward control based on the results
    	if (!valid)   {

    		forward = mapping.findForward("redirectToLogin");
    		return forward ;
    	}
    	else{

            Locale locale = (Locale) session.getAttribute(PaxTraxConstants.LOCALE_KEY);
            if (locale == null) {
                locale = new java.util.Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
                session.setAttribute(PaxTraxConstants.LOCALE_KEY, locale);
            }
            setLocale(request, locale);
            String country = locale.getCountry();
            String language = locale.getLanguage();
            if (country == null) country = DEFAULT_COUNTRY;
            if (language == null) language = DEFAULT_LANGUAGE;
            StringBuffer imgPathBuff = new StringBuffer();
            imgPathBuff.append("./images/");
            imgPathBuff.append(country + "/");
            imgPathBuff.append(language);
            session.setAttribute("imagePath", imgPathBuff.toString());
			StringBuffer jsPathBuff = new StringBuffer();
            jsPathBuff.append("./js/");
            jsPathBuff.append(country + "/");
            jsPathBuff.append(language);
            session.setAttribute("jsPath", jsPathBuff.toString());

			/*
			if (form != null)
			{
			}else
			{
			}
			*/

            //CommForm commActionForm = (CommForm) form;
            CommTraxActionForm commTraxActionForm = (CommTraxActionForm) form;


            String page = commTraxActionForm.getPage();
            if (page == null){page=""; }
            session.setAttribute("page", page);


            forward = super.execute(mapping, form, request, response);
    	}

        } catch (Exception e) {
            e.printStackTrace();
            return mapping.findForward(PaxTraxConstants.SYSTEM_ERROR);
        }
        return forward;
    }
    protected void changeLanguage(HttpServletRequest request,String language, String country ){

        String DEFAULT_COUNTRY = "JP";
        String DEFAULT_LANGUAGE = "en";

        Locale locale = getLocale(request);
        HttpSession session = request.getSession();
        String page = request.getParameter("page");
        country = request.getParameter("country");
        language = request.getParameter("language");

        if (country == null) country = DEFAULT_COUNTRY;
        if (language == null) language = DEFAULT_LANGUAGE;

        if ((language != null && language.length() > 0) &&
                (country != null && country.length() > 0)) {
            locale = new java.util.Locale(language, country);
        } else if (language != null && language.length() > 0) {
            locale = new java.util.Locale(language, "");
        }
        session.setAttribute(PaxTraxConstants.LOCALE_KEY, locale);
        setLocale(request, locale);

        if (locale == null) {
            locale = new java.util.Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
            session.setAttribute(PaxTraxConstants.LOCALE_KEY, locale);
        }
		StringBuffer imgPathBuff = new StringBuffer();
        imgPathBuff.append("./images/");
        imgPathBuff.append(country + "/");
        imgPathBuff.append(language);
		String imgPath = imgPathBuff.toString();
        session.setAttribute("imagePath", imgPath);
		StringBuffer jsPathBuff = new StringBuffer();
        jsPathBuff.append("./js/");
        jsPathBuff.append(country + "/");
        jsPathBuff.append(language);
		String jsPath = jsPathBuff.toString();
        session.setAttribute("jsPath", jsPath);

    }

	public ActionForward changeLanguage(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response)
		{
		String forward = null;
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		changeLanguage(request, language, country);
		String page = request.getParameter(PaxTraxConstants.PAGE);
		if(page.equals(PaxTraxConstants.SYSTEM_ERROR))
		{
			forward=PaxTraxConstants.SYSTEM_ERROR;
		}
		else
		{
			forward = page;
		}

		String pageNumber = (String)request.getParameter(PaxTraxConstants.PAGE_NUMBER);
		request.setAttribute(PaxTraxConstants.PAGE_NUMBER, pageNumber);
		return mapping.findForward(forward);

	}
}
