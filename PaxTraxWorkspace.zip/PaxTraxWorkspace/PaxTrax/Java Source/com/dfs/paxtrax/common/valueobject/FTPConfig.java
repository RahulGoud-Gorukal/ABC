package com.dfs.paxtrax.common.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


/**
 * Class for storing code value pairs needed for ftp
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 18/05/2004	Vaikundamurthy	Created   
 */


public class FTPConfig extends PaxTraxValueObject
{
	//Holds host
	private String remoteHost = null;
	
	//Holds user name
	private String userName = null;
	
	//Holds password
	private String password = null;
	
	//Holds ftp port
	private String ftpPort = null;
	
	//Holds remote directory
	private String remoteDirectory = null;
	
	//Holds remote file name
	private String remoteFileName = null;
	
	//Holds source directory
	private String sourceDirectory = null;
	
	//Holds destination direction
	private String destinationDirectory = null;
	
	//Holds transfer mode
	private String transferMode = null;
	
	//Holds NACCS File generation frequency
	private int naccsGenerationFrequency = 0;
	
	//Holds NACCS FTP frequency
	private int naccsFTPFrequency = 0;
	
	//Holds pc acknowledge source dir
	private String pcAcknowledgeSourceDir = null;
	
	//Holds pc acknowledge move dir
	private String pcAcknowledgeMoveDir = null;
	
	//Holds enterprise destination dir
	private String esAcknowledgeDestDir = null;
	
	//Holds enterprise move dir
	private String esAcknowledgeMoveDir = null;
	
	//Holds entry no upload frequency
	private int entryNoUploadFrequency = 0; 
	
	//Holds flight generation frequency
	private int flightGenerationFrequency;
	
	// pax file name location required for naccs entry number upload
	private int paxFileNameLoc;
	
	// import declartion number required for naccs entry number upload
	private int importDeclarationNo;
	
	// flight line number required for naccs entry number upload
	private int flightLineNo;
	
	// air line code line no required for naccs entry number upload
	private int airlineCodeLineNo;
	
	private String mappedAckSourceDir;
	
	private String mappedNaccsDestinationDir;
	
	private String mappedAckMovDir;
	
	/**
	 * Returns the ftpPort.
	 * @return String
	 */
	public String getFtpPort()
	{
		return ftpPort;
	}

	/**
	 * Returns the password.
	 * @return String
	 */
	public String getPassword()
	{
		return password;
	}

	/**
	 * Returns the remoteDirectory.
	 * @return String
	 */
	public String getRemoteDirectory()
	{
		return remoteDirectory;
	}

	/**
	 * Returns the remoteFileName.
	 * @return String
	 */
	public String getRemoteFileName()
	{
		return remoteFileName;
	}

	/**
	 * Returns the sourceDirectory.
	 * @return String
	 */
	public String getSourceDirectory()
	{
		return sourceDirectory;
	}

	/**
	 * Returns the userName.
	 * @return String
	 */
	public String getUserName()
	{
		return userName;
	}

	/**
	 * Sets the ftpPort.
	 * @param ftpPort The ftpPort to set
	 */
	public void setFtpPort(String ftpPort)
	{
		this.ftpPort = ftpPort;
	}

	/**
	 * Sets the password.
	 * @param password The password to set
	 */
	public void setPassword(String password)
	{
		this.password = password;
	}

	/**
	 * Sets the remoteDirectory.
	 * @param remoteDirectory The remoteDirectory to set
	 */
	public void setRemoteDirectory(String remoteDirectory)
	{
		this.remoteDirectory = remoteDirectory;
	}

	/**
	 * Sets the remoteFileName.
	 * @param remoteFileName The remoteFileName to set
	 */
	public void setRemoteFileName(String remoteFileName)
	{
		this.remoteFileName = remoteFileName;
	}

	/**
	 * Sets the sourceDirectory.
	 * @param sourceDirectory The sourceDirectory to set
	 */
	public void setSourceDirectory(String sourceDirectory)
	{
		this.sourceDirectory = sourceDirectory;
	}

	/**
	 * Sets the userName.
	 * @param userName The userName to set
	 */
	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	/**
	 * Returns the remoteHost.
	 * @return String
	 */
	public String getRemoteHost()
	{
		return remoteHost;
	}

	/**
	 * Sets the remoteHost.
	 * @param remoteHost The remoteHost to set
	 */
	public void setRemoteHost(String remoteHost)
	{
		this.remoteHost = remoteHost;
	}

	/**
	 * Returns the destinationDirectory.
	 * @return String
	 */
	public String getDestinationDirectory()
	{
		return destinationDirectory;
	}

	/**
	 * Sets the destinationDirectory.
	 * @param destinationDirectory The destinationDirectory to set
	 */
	public void setDestinationDirectory(String destinationDirectory)
	{
		this.destinationDirectory = destinationDirectory;
	}

	/**
	 * Returns the transferMode.
	 * @return String
	 */
	public String getTransferMode()
	{
		return transferMode;
	}

	/**
	 * Sets the transferMode.
	 * @param transferMode The transferMode to set
	 */
	public void setTransferMode(String transferMode)
	{
		this.transferMode = transferMode;
	}

	/**
	 * Returns the naccsFTPFrequency.
	 * @return int
	 */
	public int getNaccsFTPFrequency()
	{
		return naccsFTPFrequency;
	}

	/**
	 * Returns the naccsGenerationFrequency.
	 * @return int
	 */
	public int getNaccsGenerationFrequency()
	{
		return naccsGenerationFrequency;
	}

	/**
	 * Sets the naccsFTPFrequency.
	 * @param naccsFTPFrequency The naccsFTPFrequency to set
	 */
	public void setNaccsFTPFrequency(int naccsFTPFrequency)
	{
		this.naccsFTPFrequency = naccsFTPFrequency;
	}

	/**
	 * Sets the naccsGenerationFrequency.
	 * @param naccsGenerationFrequency The naccsGenerationFrequency to set
	 */
	public void setNaccsGenerationFrequency(int naccsGenerationFrequency)
	{
		this.naccsGenerationFrequency = naccsGenerationFrequency;
	}

	/**
	 * Returns the esAcknowledgeDestDir.
	 * @return String
	 */
	public String getEsAcknowledgeDestDir()
	{
		return esAcknowledgeDestDir;
	}

	/**
	 * Returns the esAcknowledgeMoveDir.
	 * @return String
	 */
	public String getEsAcknowledgeMoveDir()
	{
		return esAcknowledgeMoveDir;
	}

	/**
	 * Returns the pcAcknowledgeMoveDir.
	 * @return String
	 */
	public String getPcAcknowledgeMoveDir()
	{
		return pcAcknowledgeMoveDir;
	}

	/**
	 * Returns the pcAcknowledgeSourceDir.
	 * @return String
	 */
	public String getPcAcknowledgeSourceDir()
	{
		return pcAcknowledgeSourceDir;
	}

	/**
	 * Sets the esAcknowledgeDestDir.
	 * @param esAcknowledgeDestDir The esAcknowledgeDestDir to set
	 */
	public void setEsAcknowledgeDestDir(String esAcknowledgeDestDir)
	{
		this.esAcknowledgeDestDir = esAcknowledgeDestDir;
	}

	/**
	 * Sets the esAcknowledgeMoveDir.
	 * @param esAcknowledgeMoveDir The esAcknowledgeMoveDir to set
	 */
	public void setEsAcknowledgeMoveDir(String esAcknowledgeMoveDir)
	{
		this.esAcknowledgeMoveDir = esAcknowledgeMoveDir;
	}

	/**
	 * Sets the pcAcknowledgeMoveDir.
	 * @param pcAcknowledgeMoveDir The pcAcknowledgeMoveDir to set
	 */
	public void setPcAcknowledgeMoveDir(String pcAcknowledgeMoveDir)
	{
		this.pcAcknowledgeMoveDir = pcAcknowledgeMoveDir;
	}

	/**
	 * Sets the pcAcknowledgeSourceDir.
	 * @param pcAcknowledgeSourceDir The pcAcknowledgeSourceDir to set
	 */
	public void setPcAcknowledgeSourceDir(String pcAcknowledgeSourceDir)
	{
		this.pcAcknowledgeSourceDir = pcAcknowledgeSourceDir;
	}

	/**
	 * Returns the entryNoUploadFrequency.
	 * @return int
	 */
	public int getEntryNoUploadFrequency()
	{
		return entryNoUploadFrequency;
	}

	/**
	 * Sets the entryNoUploadFrequency.
	 * @param entryNoUploadFrequency The entryNoUploadFrequency to set
	 */
	public void setEntryNoUploadFrequency(int entryNoUploadFrequency)
	{
		this.entryNoUploadFrequency = entryNoUploadFrequency;
	}

	/**
	 * Returns the flight generation frequency.
	 * @return int the flight generation frequency
	 */
	public int getFlightGenerationFrequency() {
		return flightGenerationFrequency;
	}

	/**
	 * Sets the flight generation frequency.
	 * @param flightGenerationFrequency The flightGenerationFrequency to set
	 */
	public void setFlightGenerationFrequency(int flightGenerationFrequency) {
		this.flightGenerationFrequency = flightGenerationFrequency;
	}

	/**
	 * Returns the airlineCodeLineNo.
	 * @return int
	 */
	public int getAirlineCodeLineNo() {
		return airlineCodeLineNo;
	}

	/**
	 * Returns the flightLineNo.
	 * @return int
	 */
	public int getFlightLineNo() {
		return flightLineNo;
	}

	/**
	 * Returns the importDeclarationNo.
	 * @return int
	 */
	public int getImportDeclarationNo() {
		return importDeclarationNo;
	}

	/**
	 * Returns the paxFileNameLoc.
	 * @return int
	 */
	public int getPaxFileNameLoc() {
		return paxFileNameLoc;
	}

	/**
	 * Sets the airlineCodeLineNo.
	 * @param airlineCodeLineNo The airlineCodeLineNo to set
	 */
	public void setAirlineCodeLineNo(int airlineCodeLineNo) {
		this.airlineCodeLineNo = airlineCodeLineNo;
	}

	/**
	 * Sets the flightLineNo.
	 * @param flightLineNo The flightLineNo to set
	 */
	public void setFlightLineNo(int flightLineNo) {
		this.flightLineNo = flightLineNo;
	}

	/**
	 * Sets the importDeclarationNo.
	 * @param importDeclarationNo The importDeclarationNo to set
	 */
	public void setImportDeclarationNo(int importDeclarationNo) {
		this.importDeclarationNo = importDeclarationNo;
	}

	/**
	 * Sets the paxFileNameLoc.
	 * @param paxFileNameLoc The paxFileNameLoc to set
	 */
	public void setPaxFileNameLoc(int paxFileNameLoc) {
		this.paxFileNameLoc = paxFileNameLoc;
	}

	/**
	 * Returns the mappedAckMovDir.
	 * @return String
	 */
	public String getMappedAckMovDir() {
		return mappedAckMovDir;
	}

	/**
	 * Returns the mappedAckSourceDir.
	 * @return String
	 */
	public String getMappedAckSourceDir() {
		return mappedAckSourceDir;
	}

	/**
	 * Returns the mappedNaccsDestinationDir.
	 * @return String
	 */
	public String getMappedNaccsDestinationDir() {
		return mappedNaccsDestinationDir;
	}

	/**
	 * Sets the mappedAckMovDir.
	 * @param mappedAckMovDir The mappedAckMovDir to set
	 */
	public void setMappedAckMovDir(String mappedAckMovDir) {
		this.mappedAckMovDir = mappedAckMovDir;
	}

	/**
	 * Sets the mappedAckSourceDir.
	 * @param mappedAckSourceDir The mappedAckSourceDir to set
	 */
	public void setMappedAckSourceDir(String mappedAckSourceDir) {
		this.mappedAckSourceDir = mappedAckSourceDir;
	}

	/**
	 * Sets the mappedNaccsDestinationDir.
	 * @param mappedNaccsDestinationDir The mappedNaccsDestinationDir to set
	 */
	public void setMappedNaccsDestinationDir(String mappedNaccsDestinationDir) {
		this.mappedNaccsDestinationDir = mappedNaccsDestinationDir;
	}

}