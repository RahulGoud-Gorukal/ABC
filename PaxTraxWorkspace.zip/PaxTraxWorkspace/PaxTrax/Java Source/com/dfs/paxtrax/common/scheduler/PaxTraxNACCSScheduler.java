package com.dfs.paxtrax.common.scheduler;


/*
 * Copyright (c) 2003 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */


import java.util.ArrayList;
import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.customs.valueobject.NACCSFileSearchBean;


/**
 * The Scheduler for generating NACCS File
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Pankaj Dubey	Created
 */


public class PaxTraxNACCSScheduler extends TimerTask
{

	private FTPConfig ftpConfig = null;
    private static final boolean DEBUG = true;
   private  NACCSDelegate naccsDelegate= null;

		
    /**
     * Empty Constructor
     */
    public PaxTraxNACCSScheduler()
    { 
        init();

    }

    private void init()
    {    	
    	PaxTraxLog.logDebug( "Initializing NACCS Scheduler");    	

          	naccsDelegate = new NACCSDelegate();		
			PaxTraxLog.logDebug( "Initialized NACCS Scheduler");    	
    }

    /**
     * Call NACCS File genration method. This method is called periodically 
     * by the timer. Implements the run method in the java.util.TimerTask 
     * interface
     */
    
    public void run()
    {
    	PaxTraxLog.logDebug("PaxTrax::PaxTraxNACCSScheduler::run::Begin");
        try 
        {
    			
        
	        NACCSFileSearchBean flightBean = null;
	       if (ftpConfig == null)
	         {
	         	ftpConfig = naccsDelegate.getNACCSFTPParameters();
	         	PaxTraxLog.logDebug("PaxTraxNACCSScheduler::run(): ftpConfig got created ");
	         } 	        
	         else
	         	{
	        		PaxTraxLog.logDebug("PaxTraxNACCSScheduler::run(): ftp frequency " 
	        								+ ftpConfig.getFlightGenerationFrequency());
	        		ArrayList generatedList = naccsDelegate.generateNACCSForScheduler(
	        										ftpConfig.getFlightGenerationFrequency());
	        		PaxTraxLog.logDebug("PaxTraxNACCSScheduler::run(): generated list is "+ generatedList);
	        		if (generatedList != null)
	        			{
	        				int size = generatedList.size();
				        	PaxTraxLog.logDebug("PaxTraxNACCSScheduler::run(): Generated List size " + size);
				        	for (int i = 0; i < size; i++)
				        	{
				        		flightBean = (NACCSFileSearchBean) generatedList.get(i);
				        		PaxTraxLog.logDebug("NACCS File generated successfully for"
				        								+" the following flights");
				        		PaxTraxLog.logDebug("Flight Number " 
				        			+ flightBean.getAirlineCodeValue() + " " 
				        			+ flightBean.getFlightNumber());
				        	}
	        		}	        
	         	}
	        PaxTraxLog.logDebug("PaxTrax::PaxTraxNACCSScheduler::run::End");
	                
        } catch(PaxTraxSystemException e)
        {
       	    	
        	PaxTraxLog.logError("PaxTraxNACCSScheduler::run(): NACCS File generation Scheduler failed", e);
        } catch(Exception e) {
        	PaxTraxLog.logError("PaxTraxNACCSScheduler::run(): General Exception has happened", e);
        }
        
    }   

}


