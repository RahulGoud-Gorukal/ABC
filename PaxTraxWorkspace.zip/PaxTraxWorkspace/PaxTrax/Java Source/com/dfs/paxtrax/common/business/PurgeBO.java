package com.dfs.paxtrax.common.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;

/**
*Remote interface for Enterprise Bean: LocationBO
*
* @author Cognizant Technology Solutions
* contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE          USER            COMMENTS
* 26/05/2004    Joseph Oommen A Created   
* 07/28/2007	Uma D			Modified for CR changes
*/

public interface PurgeBO extends EJBObject
{
	/**
	 * Purge Data by invoking BO method.
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in purging data
	 */
	public void purgeData() throws RemoteException, PaxTraxSystemException;
	
//	Added for CR 250 changes on July 28,2007 --  Begin	
	/**
	 * Deletes the Naccs record from the database
	 * @throws PaxTraxSystemException
	 */	

	public void purgeNaccsData() throws RemoteException, PaxTraxSystemException;
	
//	Added for CR 250 changes on July 28,2007 --  End		
}
