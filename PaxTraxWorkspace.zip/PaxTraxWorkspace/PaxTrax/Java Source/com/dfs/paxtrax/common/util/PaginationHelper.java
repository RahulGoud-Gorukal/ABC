package com.dfs.paxtrax.common.util;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.ArrayList;
import java.util.Iterator;

import com.dfs.paxtrax.common.valueobject.PaxTraxValueObject;



/**
 * This class is used  to return records to be displayed for the given
 * page number.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */	

public class PaginationHelper 
{
    
  
    //This contains the instance of PaginationHelper class 
    private static PaginationHelper paginationHelper = null;

    /**
     * Creates an instance of PaginationHelper only if the instance does not
     * exist.
     * 
     * @return PaginationHelper Returns the PaginationHelper instance
     */
    public static PaginationHelper getInstance() 
    {
        if (paginationHelper == null) 
        {
            initializeInstance();
        }
        return paginationHelper;
    }

	/**
	 * Sets the PaginationHelper class instance
	 */
	private static synchronized void initializeInstance() 
	{
        if (paginationHelper == null) 
        {
            paginationHelper = new PaginationHelper();
        }
	}
    
    /**
     * Constructor for this class
     */
    private PaginationHelper() 
    {

    }

    /**
	 * Returns records that are to be displayed for the selected page number.
	 * 
	 * @param masterColelction Master collection contains all records
	 * @param pageNumber Page number clicked in pagination link
	 * @param recordsPerPage No of records per page
	 * 
	 * @return UnindexedCollection Records to be displayed for this 
	 * page
	 */
    public ArrayList getCurrentTableContent(
    	ArrayList masterCollection, int pageNumber, int recordsPerPage) 
    {
        
    	ArrayList  currentCollection = null;   
    	int total = 0;
				
	   	//Total number of records	
		if (masterCollection != null) 
		{
			total = masterCollection.size();
			if (total != 0) 
			{
				currentCollection = new ArrayList();
			
		        // End record number of the sub collection
		        int endRecord = recordsPerPage * pageNumber;
				// Start record number of the sub collection
	    	    int startRecord = (endRecord - recordsPerPage);
	
		        if (endRecord > total) 
		        {
		            endRecord = total;
		        }
				Iterator iterator = masterCollection.iterator();

				// Move to the start record number
				for (int i = 0; i < startRecord; i++) 
				{
					iterator.next();
				}
				// Add the records from startRecord to endRecord
				for (int i = startRecord; i < endRecord; i++) 
				{
					Object object = iterator.next();
					PaxTraxValueObject valueObject = (PaxTraxValueObject) object;
					valueObject.setSerialNo(masterCollection.indexOf(object)+1);
					currentCollection.add(object);
				}		        
			}	
		}
		return currentCollection;		        
    }
}
