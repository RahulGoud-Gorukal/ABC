package com.dfs.paxtrax.common.scheduler;

/* *
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.service.CommTraxDelegate;

/**
* This is a scheduler class which performs Data purging operations every Day
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 26/05/2004    Joseph Oommen A Created
*/

public class CommtraxFTPScheduler extends TimerTask
{

	public CommtraxFTPScheduler()
	{

	}
	public void init()
	{

	}
	public void run()
	{
		try
		{

			CommTraxDelegate commDelegate = new CommTraxDelegate();
			commDelegate.createDataFiles();

		}
		catch (PaxTraxSystemException paxtraxSystemException)
		{
			PaxTraxLog.logError("PaxtraxPurgeScheduler : run()  PaxTrax System Exception ", paxtraxSystemException);
		}
	}
}
