package com.dfs.paxtrax.common.scheduler;


/*
 * Copyright (c) 2003 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ftp.FTP_client;
import com.dfs.paxtrax.common.util.ftp.FTP_connectmode;
import com.dfs.paxtrax.common.util.ftp.FTP_exception;
import com.dfs.paxtrax.common.util.ftp.FTP_transfertype;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.exception.NACCSException;
import com.dfs.paxtrax.customs.service.NACCSDelegate;



/**
 * The Scheduler for doing FTP
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/05/2004	Vaikudamurthy	Created
 * 10/06/2004	P.C. Sathish	Modified ( For BugFix FTP set binary, put file)
 */


public class PaxTraxNACCSFTPScheduler extends TimerTask
{

    private static final boolean DEBUG = true;
   	private FTPConfig ftpConfig = null;
   	private  NACCSDelegate naccsDelegate  = null;
   	private String fileSeparator;

		
    /**
     * Empty Constructor. This constructor initializes the JMS Queue and the
     * Email Session and Transport.
     * The necessary properties read from the INOConfig.properties file
     * @see com.cts.iknow.util.INOConfig
     */
    public PaxTraxNACCSFTPScheduler()
    { 
        init();

    }

    private void init()
    {
    	naccsDelegate = new NACCSDelegate();		
		PaxTraxLog.logDebug( "PaxTraxNACCSFTPScheduler: init(): Initialized NACCS Scheduler");
		fileSeparator = System.getProperty("file.separator");
    }

    /**
     *This method is called periodically by the timer. It will check for
     *the mail connection and if found okay will start flow of messages by
     *calling start() on the QueueConnection. If there is a problem with
     *the mail connection it will call stop() on the QueueConnection.
     *Implements the run method in the java.util.TimerTask  interface
     *@see java.util.TimerTask#run
     */
    
    

		 
    public void run()
    {
    	PaxTraxLog.logDebug("PaxTrax::PaxTraxNACCSFTPScheduler::run::Begin");
        FTP_client ftp = null;
        try 
        {
            int fileLength = 0;
	        char charBuff[] = null;
	        boolean ftpSuccess = true;
	        String fullPath = null;
	        File naccsFile = null;
	        
	        String sentFilePath = null;
	        
      	    if (ftpConfig == null)
	        {
	        	ftpConfig = naccsDelegate.getNACCSFTPParameters();
	        	PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): ftpConfig got created ");
	        } 	        
			else
			{
				
		        String tobesentFilePath = ftpConfig.getSourceDirectory();
		        PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): to_be_sent dir = "+ tobesentFilePath);
		        File file = new File(tobesentFilePath);	        
		        if(file.isDirectory())
		        {        	
		        	File fileArray[] = file.listFiles();
		        	int length = fileArray.length;
		        	PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): "
		        						+ " No of files in to_be_sent dir "+ length);
		        	if (length > 0)
		        	{
		                sentFilePath = ftpConfig.getDestinationDirectory();
				                     
		        
			        	for (int k =0; k < length; k++)
			        	{
			        		try {
				        		naccsFile = (File) fileArray[k];
				    			String source = naccsFile.getAbsolutePath();
				    			String destination = naccsFile.getName();
				    			
				    			PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): " 
				    					+ " Full File name " + source);
			
				    			PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): " 
				    					+ " Remote file name " + destination);
				    			ftp = new FTP_client(ftpConfig.getRemoteHost());
				    			ftpLogin(ftp);
				    			ftpSuccess = ftpCopyFileToNACCS(ftp, source, destination);							
					    		PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): Successfully put file " 
					    			+ naccsFile.getName());
															
				        		PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): FTP Transfer Status = "+ftpSuccess);
				        			        		
				        		
				        		if(ftpSuccess)
				        		{ 		
					        		fullPath = sentFilePath + fileSeparator + naccsFile.getName();
					        		File newFile = new File(fullPath);
					        		
					        		BufferedWriter out = new BufferedWriter(
					        			new BufferedWriter(new FileWriter(newFile), 32768));
					          		BufferedReader in = new BufferedReader(
					          			new FileReader(naccsFile), 32768);         		
					 				
					 				fileLength = (int) naccsFile.length();
									charBuff = new char[fileLength];
									
									while (in.read(charBuff,0,fileLength) != -1)
									{
										out.write(charBuff,0,fileLength);
									}  
									in.close();	
							        out.close();
							        out = null;
							        boolean fileDel = naccsFile.delete();
									
									if (fileDel) {
										PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): Deleted file " 
											+ naccsFile.getName());
									} else {
										PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): Could not delete file " 
											+ naccsFile.getName());
									}
									int count = 1;
									while (!fileDel) {
										fileDel = naccsFile.delete();
										Thread.sleep(500);
										if (count == 10) {
											fileDel = true;
										}
									}
	
									String fileName = naccsFile.getName();
									int index = fileName.indexOf(".");
									if (index != -1) {
										fileName = fileName.substring(0, index);									
									}
									PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler:: run(): fileName to be updated - "+ fileName);
									naccsDelegate.updateStatus(fileName);
	
				        		}
				        		else
				        		{
				        			PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler:: run(): FTP failed for file " 
				        						+ naccsFile);
				        		}  
				        	}catch(PaxTraxSystemException e) {
								PaxTraxLog.logError("PaxTraxNACCSFTPScheduler:: run(): Unable to update file status ", e);
				        	}
		        		}
		        		
		        	}
		        	
		        }
		        else
		        {
		        	PaxTraxLog.logError("PaxTraxNACCSFTPScheduler:: run():"
		        		+"To be sent File specified is not a valid Directory");
		        }       
				
				PaxTraxLog.logDebug("PaxTrax::PaxTraxNACCSFTPScheduler::run::End");
				        
	        } 
        }
        catch(FTP_exception e)
        {   
        	if (!e.getMessage().equals("Transfer complete")) {
	        	PaxTraxLog.logError("PaxTraxNACCSFTPScheduler:: run():FTP Scheduler failed" + e.getMessage(), e);
        	}
        }
        catch (Exception e) {
    		PaxTraxLog.logError("PaxTraxNACCSFTPScheduler:: run():"
    				+"General Exception Occured", e);
        	
        }
         
    }
    
    
    
    private void ftpLogin(FTP_client ftp) throws IOException , FTP_exception{
        
        try
        {
        	ftp.login(ftpConfig.getUserName(), ftpConfig.getPassword());
        }
        catch (Exception e)
        {
        	PaxTraxLog.logError("PaxTraxNACCSFTPScheduler: run(): FTP Login Failed", e);
        }
        
        PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): Successfully logged in ");
                
        ftp.chdir(ftpConfig.getRemoteDirectory());
        // set to binary mode
        ftp.setType(FTP_transfertype.BINARY);
		ftp.setConnectMode(FTP_connectmode.ACTIVE);
    }
    
    /**
	 * Copies files to NACCS
	 * @param ftp the ftp Client
	 * @param source local file with absolute path
	 * @param destination remote file name
	 * @return boolean true or false
	 */
	private boolean ftpCopyFileToNACCS(FTP_client ftp,String source,String destination)
	{
		boolean ftpStatus = true;
		PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler:ftpCopyFileToNACCS()  source is "
						+ source + " destination is "+destination);
		try {
			PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: ftpCopyFileToNACCS(): Inside Try Block ");			
			ftp.put(source, destination);
			PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: ftpCopyFileToNACCS(): After Try Block ");			
		} catch(IOException e) {
			ftpStatus = false;
			PaxTraxLog.logError("PaxTraxNACCSFTPScheduler : ftpCopyFileToNACCS(): "
					+ "I/O Exception Occured while copying the file " + e.getMessage(), e);

		} catch(FTP_exception e) {
			if (e != null && "Transfer complete".equals(e.getMessage())) {
				ftpStatus = true;
			}
			PaxTraxLog.logError("PaxTraxNACCSFTPScheduler : ftpCopyFileToNACCS(): "
					+ " FTP Exception " , e);
		}
		
		try {
			ftp.quit();
			
		} catch(IOException e) {
			ftpStatus = false;
			PaxTraxLog.logError("PaxTraxNACCSFTPScheduler : ftpCopyFileToNACCS(): "
					+ "I/O Exception Occured while copying the file " + e.getMessage(), e);

		} catch(FTP_exception e) {
		}
		return ftpStatus;
	}
	

}


