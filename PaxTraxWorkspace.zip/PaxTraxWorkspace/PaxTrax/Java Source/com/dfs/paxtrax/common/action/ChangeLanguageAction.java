package com.dfs.paxtrax.common.action;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.util.PaxTraxLog;

public class ChangeLanguageAction extends PaxTraxAction
{

	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{

		// Extract attributes we will need
		HttpSession session = request.getSession();
		Locale locale = getLocale(request);

		String language = null;
		String country = null;
		String page = null;

		try
		{
			language = (String) PropertyUtils.getSimpleProperty(form, "language");
			country = (String) PropertyUtils.getSimpleProperty(form, "country");
			page = (String) PropertyUtils.getSimpleProperty(form, "page");
		}
		catch (Exception e)
		{

			PaxTraxLog.logError("ChangeLanguageAction " + e);
		}

		if ((language != null && language.length() > 0) && (country != null && country.length() > 0))
		{
			locale = new java.util.Locale(language, country);
		}
		else if (language != null && language.length() > 0)
		{
			locale = new java.util.Locale(language, "");
		}

		session.setAttribute(PaxTraxConstants.LOCALE_KEY, locale);
		setLocale(request, locale);
		String imgPath = getImagePath(session);
		session.setAttribute("imagePath", imgPath);

		if (null == page)
			return mapping.findForward("home");
		else
			return new ActionForward("jsp/" + page);

	}

	private String getImagePath(HttpSession session)
	{
		String DEFAULT_COUNTRY = "JP";
		String DEFAULT_LANGUAGE = "en";
		String country = null;
		String language = null;
		Locale locale = (Locale) session.getAttribute(PaxTraxConstants.LOCALE_KEY);
		if (locale == null)
		{
			locale = new java.util.Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
			session.setAttribute(PaxTraxConstants.LOCALE_KEY, locale);
		}
		country = locale.getCountry();
		language = locale.getLanguage();
		if (country == null)
			country = DEFAULT_COUNTRY;
		if (language == null)
			language = DEFAULT_LANGUAGE;
		StringBuffer imgPathBuff = new StringBuffer();
		imgPathBuff.append("./images/");
		imgPathBuff.append(country + "/");
		imgPathBuff.append(language);
		return imgPathBuff.toString();
	}
}
