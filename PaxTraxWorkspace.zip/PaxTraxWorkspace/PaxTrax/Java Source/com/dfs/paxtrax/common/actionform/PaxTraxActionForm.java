package com.dfs.paxtrax.common.actionform;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import org.apache.struts.action.ActionForm;

/**
 * Common form class which extends actionform
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 *          <p/>
 *          MOD HISTORY
 *          DATE 		USER 			COMMENTS
 *          22/03/2004	Vaikundamurthy	Created
 * @contact Cognizant - Sankaranarayanan srinivasan
 * DFS - Buensalida Sheila
 */

public class PaxTraxActionForm extends ActionForm
{
	private String page = null;

	private String moduleName = null;

	private String subaction = null;

	public String getPage()
	{
		return this.page;
	}

	public void setPage(String page)
	{
		this.page = page;
	}

	public String getModuleName()
	{
		return this.moduleName;
	}

	public void setModuleName(String moduleName)
	{
		this.moduleName = moduleName;
	}

	public String getSubaction()
	{
		return this.subaction;
	}

	public void setSubaction(String subaction)
	{
		this.subaction = subaction;
	}
}
