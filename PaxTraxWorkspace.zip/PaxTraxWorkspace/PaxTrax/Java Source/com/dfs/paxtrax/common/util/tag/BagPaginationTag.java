package com.dfs.paxtrax.common.util.tag;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2007, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.common.constants.HtmlConstants;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;

import java.io.IOException;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;


/**
 * Generates dynamic footer for table in a list page. This is used in 
 * pagination to display page numbers, next, previous, first and last links.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 20/06/2007	Umamaheswari	Created   
 */

public class BagPaginationTag extends TagSupport {

	private String totalRecords = null;

	private String currentPage = null;

	private String actionPage = null;

	private String formName = null;

	private String language = null;	
		
	/**
	 * This contains javascript function call
	 */
	public static final String CALL_JAVASCRIPT =
		"javascript:submitPage1(document.";
	
	/**
	 * This contains Next link string in English
	 */
	public static final String NEXT_LINK = "Next";
	
	/**
	 * This contains Next link string in Japanese
	 */
	public static final String NEXT_LINK_JP_1 = "&#27425;&#12398;";

	/**
	 * This contains Next link string in Japanese
	 */
	public static final String NEXT_LINK_JP_2 = "&#20214;&#12408;";
	
	/**
	 * This contains Previous link string in English
	 */
	public static final String PREVIOUS_LINK = "Previous";

	/**
	 * This contains Previous link string in Japanese
	 */
	public static final String PREVIOUS_LINK_JP_1 = "&#21069;&#12398;";

	/**
	 * This contains Previous link string in Japanese
	 */
	public static final String PREVIOUS_LINK_JP_2 = "&#20214;&#12408;";
	
	/**
	 * This contains First link string in English
	 */
	public static final String FIRST_LINK = "First";

	/**
	 * This contains First link string in Japanese
	 */
	public static final String FIRST_LINK_JP = "&#26368;&#21021;";
	
	/**
	 * This contains Last link string in English
	 */
	public static final String LAST_LINK = "Last";

	/**
	 * This contains Last link string in Japanese
	 */
	public static final String LAST_LINK_JP = "&#26368;&#24460;";
	
	public static final String RESULT_PAGE = "Result Page : ";
	
	public static final String RESULT_PAGE_JP = "&#26908;&#32034;&#32080;&#26524;&#12506;&#12540;&#12472; : ";
	
	/**
	 * Constructor for this class
	 *
	 */
	public BagPaginationTag() {
	}

	
	/**
	 * Sets the totalRecords
	 * @param totalRecords This contains total number of records
	 */
	public void setTotalRecords(String totalRecords) {
	
		this.totalRecords = totalRecords;
	}

	/**
	 * Sets the currentPage
	 * @param currentPage Page number clicked in HIPAA report
	 */
	public void setCurrentPage(String currentPage) {
		
		this.currentPage = currentPage;
	
	}

	/**
	 * Sets the actionPage
	 * @param actionPage Page to which to go on clicking page number in HIPAA
	 * report
	 */
	public void setActionPage(String actionPage) {
	
		this.actionPage = actionPage;
	}

	/**
	 * Sets the form Name
	 * @param formName Form name in HIPAA report
	 */
	public void setFormName(String formName) {
	
		this.formName = formName;
	}

	/**
	 * Returns the language.
	 * @return String
	 */
	public String getLanguage()
	{
		return language;
	}

	/**
	 * Sets the language.
	 * @param language The language to set
	 */
	public void setLanguage(String language)
	{
		this.language = language;
	}
	

	/**
	 * Generates the HTML code for displaying the footer of the table.
	 * Footer contains page number links for navigating thru entire
	 * collection of records.
	 * @return int SKIP_BODY
	 * @exception JspTagException This exception is thrown if there is an 
	 * error.
	 */
	public int doStartTag() throws JspTagException {
			
		int recordsPerPage = PaxTraxConstants.RECORDS_PER_PAGE;
		int pagesPerSet = PaxTraxConstants.PAGES_PER_SET;

		JspWriter out = pageContext.getOut();
		StringBuffer footerLink = new StringBuffer();
		StringBuffer scriptCall = new StringBuffer();

		int startPage = 0;
		int endPage = 0;
		int totalRecordNumber = Integer.parseInt(totalRecords);
		int totalPages = (int) Math.ceil((double) totalRecordNumber
			/ recordsPerPage);

		int currentPageNumber = 1;
		if (currentPage != null) {
			currentPageNumber = Integer.parseInt(currentPage);
		}

		int i = 0;
		int currentSetNumber = 0;

		// To find out the current set number
		for (i = pagesPerSet, currentSetNumber = 1;
				i < currentPageNumber;
					currentSetNumber++, i = pagesPerSet * currentSetNumber);

		endPage = pagesPerSet * currentSetNumber;
		startPage = endPage - (pagesPerSet - 1);
		
		if (endPage > totalPages) {
			endPage = totalPages;
		}

		int nextSetFirstPage = (currentSetNumber * pagesPerSet) + 1;
		
		if (nextSetFirstPage > totalPages) {
			nextSetFirstPage = 0;
		}

		int previousSetFirstPage = (currentSetNumber * pagesPerSet)
			- (2 * pagesPerSet) + 1;

		if (previousSetFirstPage < 0) {
			previousSetFirstPage = 0;
		}

		// Generating HTML Code Starts here

		String link = null;
		
		if(totalRecordNumber>0)
		{
			if(language!=null && language.equals(PaxTraxConstants.JP))
				footerLink.append(RESULT_PAGE_JP);
			else
				footerLink.append(RESULT_PAGE);
		}
				
		// If records exists in previous set give link to 'Previous 10 Pages'
		if (previousSetFirstPage != 0) {

		   /* If current page is not first page then give hyperlink to 
			* 'First'
			*/
			if (currentPageNumber != 1) {

				link = scriptCall.append(CALL_JAVASCRIPT).append(formName)
								 .append(SQLConstants.COMMA).append(SQLConstants.QUOTE).append(actionPage)
								 	.append(SQLConstants.QUOTE).append(SQLConstants.COMMA).append(SQLConstants.SPACE)
								 		.append(SQLConstants.QUOTE).append(1).append(SQLConstants.QUOTE)
								 			.append(SQLConstants.CLOSE_PAREN).toString();					

				footerLink.append(HtmlConstants.AHREF_START);
				footerLink.append(link);
				footerLink.append(SQLConstants.DOUBLE_QUOTE).append(SQLConstants.GT);

				if(language!=null && language.equals(PaxTraxConstants.JP))
					footerLink.append(FIRST_LINK_JP);
				else
					footerLink.append(FIRST_LINK);
				
				footerLink.append(HtmlConstants.ANCHOR_END );				
				footerLink.append(HtmlConstants.HTML_SPACE)
					.append(HtmlConstants.HTML_SPACE)
						.append(HtmlConstants.HTML_SPACE)
							.append(HtmlConstants.HTML_SPACE);				
			}
			scriptCall = new StringBuffer();
			link = scriptCall.append(CALL_JAVASCRIPT).append(formName)
				.append(SQLConstants.COMMA).append(SQLConstants.QUOTE).append(actionPage).append(SQLConstants.QUOTE)
					.append(SQLConstants.COMMA).append(SQLConstants.QUOTE).append(previousSetFirstPage)
						.append(SQLConstants.QUOTE).append(SQLConstants.CLOSE_PAREN).toString();
			
			footerLink.append(HtmlConstants.AHREF_START);
			footerLink.append(link);
			footerLink.append(SQLConstants.DOUBLE_QUOTE).append(SQLConstants.GT);

			if(language!=null && language.equals(PaxTraxConstants.JP))
			{
				footerLink.append(PREVIOUS_LINK_JP_1);
				footerLink.append(HtmlConstants.HTML_SPACE);
				footerLink.append(pagesPerSet);
				footerLink.append(PREVIOUS_LINK_JP_2);
			}
			else
			{
				footerLink.append(PREVIOUS_LINK);
				footerLink.append(HtmlConstants.HTML_SPACE);
				footerLink.append(pagesPerSet);
			}
			
			footerLink.append(HtmlConstants.ANCHOR_END);				
			footerLink.append(HtmlConstants.HTML_SPACE).append(HtmlConstants.HTML_SPACE)
				.append(HtmlConstants.HTML_SPACE)
					.append(HtmlConstants.HTML_SPACE);
		}

		// Generating page numbers with hyperlinks
		for (i = startPage; i <= endPage; i++) {
			// Give hyper link to page numbers except for current page
			if (i != currentPageNumber) {

				scriptCall = new StringBuffer();
				link = scriptCall.append(CALL_JAVASCRIPT).append(formName)
					.append(SQLConstants.COMMA).append(SQLConstants.QUOTE).append(actionPage)
						.append(SQLConstants.QUOTE).append(SQLConstants.COMMA).append(SQLConstants.QUOTE).append(i)
							.append(SQLConstants.QUOTE).append(SQLConstants.CLOSE_PAREN).toString();

				footerLink.append(HtmlConstants.AHREF_START);
				footerLink.append(link);
				footerLink.append(SQLConstants.DOUBLE_QUOTE).append(SQLConstants.GT);
			}
			footerLink.append(i);
			if (i != currentPageNumber) {
				footerLink.append(HtmlConstants.ANCHOR_END);
			}
			footerLink.append(HtmlConstants.HTML_SPACE)
				.append(HtmlConstants.HTML_SPACE);
		}

		// If records exist in next set give hyperlink to 'Next 10 Pages'
		if (nextSetFirstPage != 0) {

			scriptCall = new StringBuffer();
			link = scriptCall.append(CALL_JAVASCRIPT).append(formName).append(SQLConstants.COMMA)
				.append(SQLConstants.QUOTE).append(actionPage).append(SQLConstants.QUOTE).append(SQLConstants.COMMA)
					.append(SQLConstants.QUOTE).append(nextSetFirstPage).append(SQLConstants.QUOTE)
						.append(SQLConstants.CLOSE_PAREN).toString();

			footerLink.append(HtmlConstants.AHREF_START);
			footerLink.append(link);
			footerLink.append(SQLConstants.DOUBLE_QUOTE).append(SQLConstants.GT);
			
			if(language!=null && language.equals(PaxTraxConstants.JP))
			{
				footerLink.append(NEXT_LINK_JP_1);
				footerLink.append(HtmlConstants.HTML_SPACE);
				footerLink.append(pagesPerSet);
				footerLink.append(NEXT_LINK_JP_2);
			}
			else
			{
				footerLink.append(NEXT_LINK);
				footerLink.append(HtmlConstants.HTML_SPACE);
				footerLink.append(pagesPerSet);
			}
			
			footerLink.append(HtmlConstants.ANCHOR_END);
			footerLink.append(HtmlConstants.HTML_SPACE).append(HtmlConstants.HTML_SPACE)
				.append(HtmlConstants.HTML_SPACE)
					.append(HtmlConstants.HTML_SPACE);								

			if (currentPageNumber != totalPages) {

				scriptCall = new StringBuffer();
				link = scriptCall.append(CALL_JAVASCRIPT).append(formName)
					.append(SQLConstants.COMMA).append(SQLConstants.QUOTE).append(actionPage)
						.append(SQLConstants.QUOTE).append(SQLConstants.COMMA).append(SQLConstants.QUOTE)
							.append(totalPages).append(SQLConstants.QUOTE)
								.append(SQLConstants.CLOSE_PAREN).toString();

				footerLink.append(HtmlConstants.AHREF_START);
				footerLink.append(link);
				footerLink.append(SQLConstants.DOUBLE_QUOTE).append(SQLConstants.GT);
				
				if(language!=null && language.equals(PaxTraxConstants.JP))
					footerLink.append(LAST_LINK_JP);
				else
					footerLink.append(LAST_LINK);
					
				footerLink.append(HtmlConstants.ANCHOR_END);				
			}				
		}

		// If current page is not last page give hyperlink to 'Last'


		try {
			// outputs the HTML code into the JSP page
			out.print(footerLink.toString());
		} catch (IOException ioe)	{
			throw new JspTagException(ioe.getMessage());
		}
		return (SKIP_BODY);
	}

}
