/*********************************************************************************
*  PROGRAM NAME		:  FTPDataSocket
*  NAME OF AUTHOR	:  Bipin
*  DATE OF CREATION	:  25/06/2004
*  DESCRIPTION	    :  This will get the selected files from the Report server.
*  VERSION		    :  1.0
*  CTS All rights reserved

 *  Supports client-side FTP DataSocket in Passive and Active Mode.
 *  Wrapper for Socket and ServerSocket. Methods are package access
 *  only - not for public use.

REVISION HISTORY

| Date	 |	Programmer name   |  Ver  |  Change history
---------------------------------------------------------------------------------------------------------
|        |                    |       |
--------------------------------------------------------------------------------------------------------
*/
package com.dfs.paxtrax.common.util.ftp;
import java.io.*;
import java.net.*;
import java.util.*;


public class FTP_datasocket {

    /**
     *  The underlying socket for Active connection.
     */
    private ServerSocket activeSocket = null;

    /**
     *  The underlying socket for PASV connection or Socket acepted from server.
     */
    private Socket passiveSocket = null;

    /**
     *  Create socket wrapper for Active connection.
     */
    FTP_datasocket(ServerSocket s) {
         activeSocket = s;
    }
    /**
     *  Create socket pper for PASV connection.
     */
    FTP_datasocket(Socket s) {
         passiveSocket = s;
    }
     /**
      *  Closes underlying sockets.
      */
    void close() throws IOException {

        if (passiveSocket != null)
            passiveSocket.close();
        if (activeSocket != null)
            activeSocket.close();
    }
    /**
     *  If active mode, accepts the FTP server's connection - in PASV,
     *  we are already connected. Then gets the input stream of
     *  the connection
     *
     *  @return  input stream for underlying socket.
     */
    InputStream getInputStream() throws IOException {

        if (passiveSocket != null) {
            return passiveSocket.getInputStream();
        } else {
            // accept socket from server, in Active mode
            passiveSocket = activeSocket.accept();
            // get and return it's InputStream
            return passiveSocket.getInputStream ();
        }
    }
    /**
     *  If active mode, accepts the FTP server's connection - in PASV,
     *  we are already connected. Then gets the output stream of
     *  the connection
     *
     *  @return  output stream for underlying socket.
     */
    OutputStream getOutputStream() throws IOException {

        if (passiveSocket != null) {
            return passiveSocket.getOutputStream();
        }
        else {
            // accept socket from server, in Active mode
            passiveSocket = activeSocket.accept();
            // get and return its OutputStream
            return passiveSocket.getOutputStream ();
        }
    }
    /**
     *   Set the TCP timeout on the underlying control socket.
     *
     *   If a timeout is set, then any operation which
     *   takes longer than the timeout value will be
     *   killed with a java.io.InterruptedException.
     *
     *   @param millis The length of the timeout, in milliseconds
     */
    void setTimeout(int millis)
        throws IOException {

        if (passiveSocket != null)
            passiveSocket.setSoTimeout(millis);
        else if (activeSocket != null)
            activeSocket.setSoTimeout(millis);
    }
}
