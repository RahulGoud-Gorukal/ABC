package com.dfs.paxtrax.common.exception;

/**
 * General Exception, should be inherited  by all other PaxTrax application exception.
 *
 * @author    Pankaj Dubey (Cognizant)
 * @created   March 22, 2004
 */
public abstract class PaxTraxException extends Exception {

    private int errorCode;
    private Exception actualException = null;


    /**
     * Constructor accepts error code. The error code should be available in GO2ErrorMessages
     *
     * @param errorCode Error code to get error message
     */
    public PaxTraxException(int errorCode) {
    this.errorCode = errorCode;
    }

    /**
     * Constructor accepts error code and actual exception .
     * The error code should be available in GO2ErrorMessages
     *
     * @param errorCode Error       Code to get error message
     * @param actualException Exception   Actual Exception
     */
    public PaxTraxException(int errorCode, Exception actualException) {
        this.errorCode = errorCode;
        this.actualException = actualException;
    }

    /**
     * Getting error message for the current exception
     *
     * @return message Error message as per PaxTraxErrorMessages
     */
    public String getMessage() {
        return PaxTraxErrorMessages.getErrorMessage(errorCode);
    }

    /**
     * Returns error code
     * @return int - Error code
     */
    public int getErrorCode()
    {
    	return errorCode;
    }


    /**
     * Prints the stack trace of given actual exception and thrown exception. It is a overloaded
     * method
     *
     *
     */
    public void printStackTrace() {

        if (actualException != null)
            actualException.printStackTrace();

        super.printStackTrace();
    }
}
