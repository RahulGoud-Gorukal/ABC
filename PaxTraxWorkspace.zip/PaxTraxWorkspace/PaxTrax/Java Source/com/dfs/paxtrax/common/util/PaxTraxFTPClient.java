package com.dfs.paxtrax.common.util;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
 
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.valueobject.FTPConfig;


/**
 * This is PaxTraxFTPClient class which is a singleton.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 04/05/2004	Pankaj Dubey	Created   
 */


public class PaxTraxFTPClient {
	
	//Holds FTPConfig object
	private FTPConfig ftpConfig = null;
	
	/*
	 * Private constructor for this class
	 */
	public PaxTraxFTPClient(FTPConfig ftpConfig) {
		this.ftpConfig = ftpConfig;
	}


	/**
	 * Transmits file given
	 * @param fileName Name of the file to be transmitted
	 * @return boolean Indicated whether successfully transmitted or not
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in transmitting the file
	 */
	public boolean transmitFile(String fileName) 
		throws PaxTraxSystemException {
			boolean success = false;
	
		try 
		{
			//String filePath = PaxTraxConfig.getProperty("naccs.tobesent.path");
			String filePath = ftpConfig.getSourceDirectory() + "/" + fileName;			 
			File file = new File(filePath);
			ftpFile(file);
			success = true;
		}
		catch (PaxTraxSystemException e) 
		{
			e.printStackTrace();
			success = false;
		}
		catch (IOException e) 
		{			
			e.printStackTrace();
			success = false;
		}		
		return success;
	}

	/*
	 * Stores the file in the server
	 */
	private void ftpFile(File localFile)
		throws PaxTraxSystemException , IOException {
			
		String host = null;
		String username = null;
		String password = null;
		String portStr = null;
		String dir = null;
		String remoteName = null;
		
		/*try 
		{
			
			host = PaxTraxConfig.getProperty(PaxTraxConstants.TRANSMIT_FTP_HOST);
			username = PaxTraxConfig.getProperty(PaxTraxConstants.TRANSMIT_FTP_USERNAME);
			password = PaxTraxConfig.getProperty(PaxTraxConstants.TRANSMIT_FTP_PASSWORD);
			port_str = PaxTraxConfig.getProperty(PaxTraxConstants.TRANSMIT_FTP_PORT);
			dir = PaxTraxConfig.getProperty(PaxTraxConstants.TRANSMIT_FTP_DIR);
	        remoteName = PaxTraxConfig.getProperty(PaxTraxConstants.TRANSMIT_FTP_NAME);			*/
	       if (ftpConfig != null)
	       {
	       		host = ftpConfig.getRemoteHost();
	       		username = ftpConfig.getUserName();
	       		password = ftpConfig.getPassword();
	       		portStr = ftpConfig.getFtpPort();
	       		dir = ftpConfig.getRemoteDirectory();
	       		remoteName = ftpConfig.getRemoteFileName();
	       } 
		/*}
		catch (PaxTraxConfigFileException e) 
		{
		}*/
		

		if (!localFile.isFile()) 
		{
			throw new IllegalStateException(
				localFile + " should be a valid system file for transmission");
		}
		
		int port = 21; //default FTP control port.
		try 
		{
			if (portStr != null) 
			{
				port = Integer.parseInt(portStr);
			}
		}
		catch (NumberFormatException e) 
		{
			//should be RuntimeExceptions and NOT checked exceptions. Read
			//Martin Fowler's and Bill Venner's series on checked vs un-checked
			//to know why.
			e.printStackTrace();
			throw new IllegalStateException("Malformed FTP Service port in configuration properties");
		}
		
		FTPClient ftpc = new FTPClient();
		
		try 
		{
			int reply;
			boolean result = false;
			ftpc.connect(host, port);
			reply = ftpc.getReplyCode();
			
			if (!FTPReply.isPositiveCompletion(reply)) 
			{
				ftpc.disconnect();
				throw new IOException("FTP Server (" + host + "," + port
						+ ") refused connection with reply code: "	+ reply);
			}
			result = ftpc.login(username, password);
			
			if (!result) 
			{
				throw new IOException("Couldn't login into FTP Server ("
						+ host + "," + port	+ ")");
			}
			
			if (dir != null) 
			{
				result = ftpc.changeWorkingDirectory(dir);
				
				if (!result) 
				{
					throw new IOException("Couldn't change directory to "
							+ dir + " on FTP Server (" + host + ","	+ port
							+ ")");
				}
			}
			
			InputStream bin =
				new BufferedInputStream(new FileInputStream(localFile));
            
            if (remoteName != null) 
            {
                result = ftpc.storeFile(remoteName, bin);                
            } 
            else 
            {
                result = ftpc.storeFile(localFile.getName(), bin);                
            }
			
			if (!result) 
			{
				throw new IOException("Couldn't store file: " + localFile
						+ " to dir: " + dir	+ " on FTP Server (" + host
						+ ","
						+ port + ")");
			}  			
		}
		finally 
		{
			if (ftpc != null && ftpc.isConnected()) 
			{
				try 
				{
					ftpc.disconnect();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
		}
		//successfully FTP'ed file.
	}

    public static void main(String args[]) {
        try {
            /*
               Properties props = new Properties();
               props.setProperty(TRANSMIT_FTP_HOST, "blrftp");
               props.setProperty(TRANSMIT_FTP_USERNAME, "fsr");
               props.setProperty(TRANSMIT_FTP_PASSWORD, "passfsr123");
               MMREFOperations ops = new MMREFOperations(props);
               ops.ftpFile(new File("build.xml"));
               */
            //PaxTraxFTPClient ops = new PaxTraxFTPClient();            
            //ops.ftpFile(new File("pankaj.txt"));
            //assume
        } catch(Exception t) {
            t.printStackTrace();
        }
    }
}
