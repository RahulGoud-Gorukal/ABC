package com.dfs.paxtrax.common.business;

import java.rmi.RemoteException;
import java.util.ArrayList;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2014, DFS All rights reserved.
 *
 */
 

/**
 *
 * The remote interface of the EJB that will be used for flight system related functions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Mohammed Faheem
 *
 * @version    1.0
 *
 */

public interface FlightUploadBO extends javax.ejb.EJBObject {
		
		public boolean getFlightData(String date, String time, String lastProcessedDateTime) throws RemoteException;
		
		public String getLastProcessedDateTime() throws RemoteException;
		
		public boolean sendFlightDataToWincor(ArrayList paxUploadList) throws RemoteException;
		
		public boolean updateLastProcessedDate(String date, String time) throws RemoteException;
		
		public boolean putFlightToWincorQueue(String xmlString) throws RemoteException;
}
