package com.dfs.paxtrax.common.action;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.Globals;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.actions.DispatchAction;

import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.actionform.LoginActionForm;
import com.dfs.paxtrax.common.actionform.PaxTraxActionForm;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.MenuException;
import com.dfs.paxtrax.common.service.MenuDelegate;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.valueobject.LeftNavBean;


/**
 * This action class forwards to home pages of passenger, customs, bagtracking
 * and admin pages
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 *          <p/>
 *          MOD HISTORY
 *          DATE 		USER 			COMMENTS
 *          24/03/2004	Vaikundamurthy	Created
 *          contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 */


public class LoginAction extends DispatchAction {


    /**
     * Forwards to login page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward loginPage(ActionMapping mapping,
                                   ActionForm form,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {
   		PaxTraxLog.logDebug("PaxTrax::LoginAction::loginPage::Begin");
		//initAction(mapping,form,request,response);
        LoginActionForm logonform = (LoginActionForm) form;
        UserBean user = new UserBean();
        logonform.setUserBean(user);
   		PaxTraxLog.logDebug("PaxTrax::LoginAction::loginPage::End");
        return mapping.findForward(PaxTraxConstants.LOGIN);
    }

    /**
     * Forwards to login page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward logout(ActionMapping mapping,
                                   ActionForm form,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {
   		PaxTraxLog.logDebug("PaxTrax::LoginAction::logout::Begin");

        String forwardPage = "";

		String language = request.getParameter("language");
		request.setAttribute("language", language);

		HttpSession session = request.getSession();
		if(session!=null)
	        session.invalidate();

        if(language.equals("jp"))
        	forwardPage = PaxTraxConstants.LOGIN + "JP";
        else
        	forwardPage = PaxTraxConstants.LOGIN;

        Locale locale = new Locale(language, "JP");
        setLocale(request,locale);

   		PaxTraxLog.logDebug("PaxTrax::LoginAction::logout::End");

        return mapping.findForward(forwardPage);
    }
    /**
     * Forwards to paxtrax home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
        public ActionForward paxtraxHomePage(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response) {

   		PaxTraxLog.logDebug("PaxTrax::LoginAction::paxtraxHomePage::Begin");
        HttpSession session = request.getSession();
        String forward = null;
        ArrayList arrList = null;
		int cnt = 0;

        try
        {

            UserBean userBean = new UserBean();
            userBean.setUserId(request.getParameter("userId"));
            userBean.setPassword(request.getParameter("password"));

            String userid = userBean.getUserId();
            String password = userBean.getPassword();

            String prevUserId = request.getParameter("prevUserId");
            String invalidAttempts = request.getParameter("invalidAttempts");

            String language = request.getParameter("language");

    		if(!prevUserId.equals(userid))
    		{
    			invalidAttempts = "1";
    			userBean.setInvalidTries(1);
    		}
    		else
    		{
    			userBean.setInvalidTries(Integer.parseInt(invalidAttempts) + 1);
    			invalidAttempts = "" + (Integer.parseInt(invalidAttempts) + 1);
    		}

            MenuDelegate menuDelegate = new MenuDelegate();

		    try
   	        {
	            arrList = menuDelegate.loadMenuDetails(userBean,PaxTraxConstants.PAXTRAXHOME);

	            if (arrList != null && !arrList.isEmpty()) {

	                for (int i = 0; i < arrList.size(); i++)
	                {
	                    LeftNavBean ln = (LeftNavBean) arrList.get(i);
	                    if (!ln.getModuleName().equals("")) {
	                        cnt++;
	                     PaxTraxLog.logDebug("The module is "+ln.getModuleName());
	                    }
	                }
	            }
	            else
	            {
	                arrList = new ArrayList();
	            }

				session.setAttribute(PaxTraxConstants.USER_ID, userid);
				session.setAttribute(PaxTraxConstants.PASSWORD, password);
		        forward = PaxTraxConstants.PAXTRAXHOME;
	            session.setAttribute(PaxTraxConstants.MENU_LIST, arrList);
	            session.setAttribute(PaxTraxConstants.MENU_COUNT, new Integer(cnt));
	            initAction(mapping, form, request, response);
            }
            catch(MenuException me)
            {
            	if(me.getErrorCode() == PaxTraxConstants.USER_LOCKED
            		|| me.getErrorCode() == PaxTraxConstants.USERID_NOT_FOUND
            		|| me.getErrorCode() == PaxTraxConstants.USER_DEACTIVATED
            		|| me.getErrorCode() == 100)
					invalidAttempts = "0";

				if(language.equals("jp"))
			    	forward = PaxTraxConstants.LOGIN + "JP";
			    else
			    	forward = PaxTraxConstants.LOGIN;

		    	request.setAttribute(PaxTraxConstants.PRESENT, String.valueOf(me.getErrorCode()));
		    	request.setAttribute("invalidAttempts", invalidAttempts);
		    	request.setAttribute("userId", userBean.getUserId());
		    	request.setAttribute("language", language);
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

   		PaxTraxLog.logDebug("PaxTrax::LoginAction::paxtraxHomePage::End");

        return mapping.findForward(forward);
    }


    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) {
        try{

        return super.execute(mapping, form, request, response);
        }catch (Exception e)
        {
        	e.printStackTrace();
        	return  null;
        }

    }

    private void initAction (ActionMapping mapping,
                             ActionForm form,
                             HttpServletRequest request,
                             HttpServletResponse response){

  		PaxTraxLog.logDebug("PaxTrax::LoginAction::initAction::Begin");
		String DEFAULT_COUNTRY = "JP";
        String DEFAULT_LANGUAGE = "en";

        HttpSession session = request.getSession();
    	try
    	{
            Locale locale = new java.util.Locale(request.getParameter("language"),DEFAULT_COUNTRY);
	        session.setAttribute(PaxTraxConstants.LOCALE_KEY, locale);

	        setLocale(request, locale);
	        String country = locale.getCountry();
	        String language = locale.getLanguage();

	        if (language == null) language = DEFAULT_LANGUAGE;
	        StringBuffer imgPathBuff = new StringBuffer();
	        imgPathBuff.append("./images/");
	        imgPathBuff.append(country + "/");
	        imgPathBuff.append(language);
	        session.setAttribute("imagePath", imgPathBuff.toString());

			StringBuffer jsPathBuff = new StringBuffer();
            jsPathBuff.append("./js/");
            jsPathBuff.append(country + "/");
            jsPathBuff.append(language);
            session.setAttribute("jsPath", jsPathBuff.toString());

            /*
	        PaxTraxActionForm paxTraxform = (PaxTraxActionForm) form;

	        String page = paxTraxform.getPage();
	        if (page == null){page = "";}
	        session.setAttribute("page", page);
	        */

			PaxTraxLog.logDebug("PaxTrax::LoginAction::initAction::End");

    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }

   	public ActionForward changeLanguage(
	ActionMapping mapping,
	ActionForm form,
	HttpServletRequest request,
	HttpServletResponse response)
	{
		String forwardPage = "";
		PaxTraxLog.logDebug("PaxTrax::FlightAction::changeLanguage::Begin");

		String language = request.getParameter("language");
		String prevUserId = request.getParameter("prevUserId");
        String invalidAttempts = request.getParameter("invalidAttempts");
		String result = request.getParameter(PaxTraxConstants.PRESENT);

		if(language==null)
			language = "jp";

        Locale locale = new java.util.Locale(language,"JP");
        setLocale(request, locale);

		if(language.equals("jp"))
			forwardPage = PaxTraxConstants.LOGIN + "JP";
		else
			forwardPage = PaxTraxConstants.LOGIN;

		String userId = request.getParameter("userId");

		if(userId==null)
			userId = "";

		request.setAttribute("userId", userId);


		request.setAttribute(PaxTraxConstants.PRESENT,result);
		request.setAttribute("prevUserId", prevUserId);
		request.setAttribute("invalidAttempts", invalidAttempts);

		PaxTraxLog.logDebug("PaxTrax::FlightAction::changeLanguage::End");

		return mapping.findForward(forwardPage);
	}

}
