package com.dfs.paxtrax.common.util;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;

/**
 * @version 	1.0
 * @author		Anand Sivasankaran
 */
public final class DownloadServlet extends HttpServlet 
{
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException 
	{
		loadFile(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException 
	{
		loadFile(req, resp);
	}
	
    public void loadFile(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, java.io.IOException
    {
    	String basePath = PaxTraxConstants.SALES_REPORTS_BASE_PATH;
	    String fileName = request.getParameter(PaxTraxConstants.FILE_NAME);
		String fileType = request.getParameter(PaxTraxConstants.FILE_TYPE);
		String alternateBasePath = request.getParameter(
								PaxTraxConstants.ALTERNATE_DOWNLOAD_PATH);
		if (alternateBasePath != null 
			&& alternateBasePath.equals(PaxTraxConstants.BAGTRAX_FILE_PATH)) {
			basePath = PaxTraxConstants.BAGTRAX_REPORTS_BASE_PATH;
		}
		
        if(fileName!=null) 
        {
			InputStream in = null;
			ServletOutputStream out = null;
			
			try 
			{
                in = new BufferedInputStream(new FileInputStream(basePath+fileName));
            	out = response.getOutputStream();
            	
            	if(fileType.equals(PaxTraxConstants.MS_EXCEL))
	                response.setContentType(PaxTraxConstants.APP_MS_EXCEL);
	            else if(fileType.equals(PaxTraxConstants.MS_WORD))
	            	response.setContentType(PaxTraxConstants.APP_MS_WORD);
	            else if(fileType.equals(PaxTraxConstants.PDF))
	            	response.setContentType(PaxTraxConstants.APP_PDF);
	            
                response.setHeader("Content-Disposition","inline; filename=\"" + fileName + "\"");

                int c;
                while((c=in.read())!= -1)
                    out.write( c );
                    
                return;
	        }
               
            finally
            {
                if( in != null ) try { in.close(); } catch( Exception e ) {}
                if( out != null ) try { out.close(); } catch( Exception e ) {}
            }
        }
        
        response.sendError(HttpServletResponse.SC_NOT_FOUND);
    }
}
