package com.dfs.paxtrax.common.util;

import java.util.Properties;

import com.dfs.paxtrax.common.exception.PaxTraxConfigFileException;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;

/**
 * @author Pankaj Dubey
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PaxTraxConfig {
	
	private static Properties properties = null;

    /**
     *  Loading properties from PaxTraxConfig.properties
     *
     * @exception PaxTraxConfigFileException problem
     */
    private static void loadProperties() throws PaxTraxConfigFileException
    {

        properties = new Properties();

        try
        {
			Object obj = new PaxTraxConfig();
            properties.load(obj.getClass().getResourceAsStream("PaxTraxConfig.properties"));
        }catch (Exception exp)
        {        	
            throw new PaxTraxConfigFileException(PaxTraxErrorMessages.PT_CONFIG_EXCEPTION);
        }
    }

    /**
     * Giving the value for the given key
     *
     * @param        String    Key to take property
     * @return    String    Value of for the given key
     *
     * @exception INOConfigFile Exception
     */
    public static String getProperty(String key) throws PaxTraxConfigFileException
    {        
        if (properties == null)
        {
            loadProperties();
        }

        String prop =  properties.getProperty(key);
        if (prop != null)
        {
            prop=prop.trim();
        }
        return prop;
    }   

}
