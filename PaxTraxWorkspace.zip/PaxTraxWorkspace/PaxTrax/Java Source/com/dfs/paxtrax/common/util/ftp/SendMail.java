package com.dfs.paxtrax.common.util.ftp;
import javax.mail.* ;
import javax.mail.event.* ;
import javax.mail.internet.* ;
/**
*   This program is used to send mail.
**/
public class SendMail
{
    static String smtphost = null;
    public SendMail()
    {
        smtphost = "";
    }
    public SendMail(String smtphostname)
    {
        smtphost = smtphostname;
    }
	/**
	*	This method is to send the mail to the addresses passed.The parameters
	**/
    public static void sendMessage(String from,String bcc,String subject,String msg) throws MessagingException,SendFailedException
    {
        if (msg == null || msg == "")
        {
            System.exit(1);
        } //end of if
        int flag = 0,i = 0,charflag = 0;
		int bcc_len=bcc.length();
        for (i = 0; i <bcc_len; i ++ )
        {
            if (bcc.charAt(i) == ' ')
            {
                flag = 1;
            }
            else
            {
	            charflag = 1;
            }
        } //end of for
        if ((bcc == null || bcc == "" || flag == 1 && charflag == 0))
        {
		     throw new MessagingException();
        } 
        else
        {
			java.util.Properties properties = System.getProperties();
			Session session = Session.getInstance(properties,null);
			//Construct  a message
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(bcc));
			if (subject == null || subject == "")
				message.setSubject("");
			else
				message.setSubject(subject);
			message.setContent(msg,"text/plain");
			//Connect to the transport
			Transport transport = session.getTransport("smtp");
			transport.addConnectionListener(new ConnectionHandler());
			transport.addTransportListener(new TransportHandler());
			transport.connect(smtphost," "," ");
			//Send the message and close the connection
			int bs = message.getSize();
			transport.sendMessage(message,message.getAllRecipients());
			transport.close();
        } //end of else
    } //end of sendMessage function
} //end of class sendMail
/**
* This is an adapter class for Connection Events.
**/
class ConnectionHandler extends ConnectionAdapter
{
    public void opened(ConnectionEvent e)
    {
    }

    public void disconnected(ConnectionEvent e)
    {
    }

    public void closed(ConnectionEvent e)
    {
    }
} //end of class ConnectionHandler
/**
* This is the adapter class for Transport Events.
**/
class TransportHandler extends TransportAdapter
{
    public void messageDelivered(TransportEvent e)
    {
    }

    public void messageNotDelivered(TransportEvent e)
    {
    }
    public void messagePartiallyDelivered(TransportEvent e)
    {
    }
}
 