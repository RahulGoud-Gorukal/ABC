package com.dfs.paxtrax.common.scheduler;

/* *
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
* This is a scheduler class which performs Data purging operations every Day
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 07/12/2004    Ezhilmuthu      Created
*/

public class PaxtraxLTSScheduler extends TimerTask
{

	public PaxtraxLTSScheduler()
	{

	}
	public void init()
	{

	}
	public void run()
	{
		try
		{
			
			NACCSDelegate naccsDelegate = new NACCSDelegate();
			naccsDelegate.ltsuploadCopyData();
		}
		catch (PaxTraxSystemException paxtraxSystemException)
		{
			PaxTraxLog.logError("PaxtraxLTSScheduler : run()  PaxTrax System Exception ", paxtraxSystemException);
		}
	}
}
