package com.dfs.paxtrax.common.scheduler;


/*
 * Copyright (c) 2007 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */


import java.util.ArrayList;
import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.service.PurgeDelegate;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * The Scheduler for purging NACCS table
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Jaganmohan Gopinath
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 07/26/2007	Umamaheswari	Created
 */


public class PaxTraxNaccsPurgeScheduler extends TimerTask
{

   private  PurgeDelegate purgeDelegate= null;

		
    /**
     * Empty Constructor
     */
    public PaxTraxNaccsPurgeScheduler()
    { 
        init();

    }

    private void init()
    {    	
    	PaxTraxLog.logDebug( "Initializing NACCS Purge Scheduler");    	

			purgeDelegate = new PurgeDelegate();		
			PaxTraxLog.logDebug( "Initialized NACCS Purge Scheduler");    	
    }

    /**
     * Call NACCS purge data method. This method is called periodically 
     * by the timer. Implements the run method in the java.util.TimerTask 
     * interface
     */
    
    public void run()
    {
    	PaxTraxLog.logDebug("PaxTrax::PaxTraxNaccsPurgeScheduler::run::Begin");
        try 
        {
			purgeDelegate.purgeNaccsData();
			PaxTraxLog.logDebug("PaxTrax::PaxTraxNaccsPurgeScheduler::run::End");	                
        } 
        catch(PaxTraxSystemException e)
        {
        	PaxTraxLog.logError("PaxTraxNaccsPurgeScheduler::run(): NACCS Purge Scheduler failed", e);
        } 
        catch(Exception e) {
        	PaxTraxLog.logError("PaxTraxNaccsPurgeScheduler::run(): General Exception has happened", e);
        }
        
    }   

}


