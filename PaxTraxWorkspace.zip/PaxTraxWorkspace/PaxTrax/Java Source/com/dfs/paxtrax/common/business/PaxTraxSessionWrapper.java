package com.dfs.paxtrax.common.business;

import javax.ejb.SessionBean;
import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import java.rmi.RemoteException;

/**
 * Created by IntelliJ IDEA.
 * User: 107646
 * Date: Mar 27, 2004
 * Time: 4:00:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class PaxTraxSessionWrapper implements SessionBean{
    public void ejbActivate() throws EJBException, RemoteException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void ejbPassivate() throws EJBException, RemoteException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void ejbRemove() throws EJBException, RemoteException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setSessionContext(SessionContext sessionContext) throws EJBException, RemoteException {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
