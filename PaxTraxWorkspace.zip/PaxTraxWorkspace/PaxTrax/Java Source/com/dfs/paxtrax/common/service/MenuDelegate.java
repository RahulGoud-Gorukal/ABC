package com.dfs.paxtrax.common.service;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.business.MenuBO;
import com.dfs.paxtrax.common.business.MenuBOHome;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.MenuException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;


/**
 * Bean implementation class for Enterprise Bean: UserBOManager
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Sundarrajan.K.	Created   
 */	


public class MenuDelegate {
	
	/**
	* Default Construtor for MenuDelegate
	*/
	public MenuDelegate()
	{
	}

//Holds service locator instance


	private ServiceLocator serviceLocator = null;

	private MenuBOHome menuBOHome = null;
	private MenuBO menuBO = null;
	
	private void jndiCall() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::MenuDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			menuBOHome = (MenuBOHome)PortableRemoteObject.narrow (serviceLocator.getEJBHome(
				PaxTraxConstants.MENU_BO_BEAN_JNDI),MenuBOHome.class);
		}
		catch (NamingException ne)
		{
			throw  new PaxTraxSystemException(ne);
		}		
		if (menuBOHome == null)
		{
			//throw new PaxTraxSystemException(PaxTraxConstants.FLIGHT_BO_HOME_NOT_FOUND);
		}
		try
		{
			menuBO = menuBOHome.create();			
		}
		catch (CreateException ce)
		{
			throw  new PaxTraxSystemException(ce);
		}
		catch(RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::MenuDelegate::jndiCall::End");
	}
	
	/**
	 * Loads module options for the given user
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in loading menuDetails
	 */
	public ArrayList loadMenuDetails(UserBean userBean,String webProject) 
		throws PaxTraxSystemException,MenuException
	{
		PaxTraxLog.logDebug("PaxTrax::MenuDelegate::loadMenuDetails::Begin");
		ArrayList menuDetails = null;
		if (menuBOHome == null)
		{
			jndiCall();
		}
		
		try
		{
			menuDetails = menuBO.loadMenuDetails(userBean,webProject);
		}
		catch (RemoteException re)
		{
			throw  new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::MenuDelegate::loadMenuDetails::End");
		return menuDetails;
	}
}
