package com.dfs.paxtrax.common.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


/**
 * Class for storing code value pairs needed to add and update application data
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 30/03/2004	Sundarrajan.K.	Created   
 */


public class LeftNavBean extends PaxTraxValueObject
{
	
	// transaction id for a particular userid
	private String txnId;
	// transaction name for a particular userid
	private String txnName;
	// module id for a particular userid
	private String moduleId;
	// submodule id for a particular userid
	private String submoduleId;
	// module name for a particular userid
	private String moduleName;
	// sub module name for a particular userid
	private String subModuleName;
	
	
	/**
	 * Default constructor
	 */
	public LeftNavBean() {
	}


	/**
	 * Gets the value
	 * @return Returns a String
	 */
	public String getTxnId() {
		return txnId;
	}
	/**
	 * Sets the value
	 * @param value The value to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	
	/**
	 * Gets the Value
	 * @return Returns a String
	 */
	public String getTxnName() {
		return txnName;
	}
	/**
	 * Sets the value
	 * @param value The value to set
	 */
	public void setTxnName(String txnName) {
		this.txnName = txnName;
	}

	/**
	 * Gets the Value
	 * @return Returns a String
	 */
	public String getModuleName() {
		return moduleName;
	}
	/**
	 * Sets the value
	 * @param value The value to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	
	/**
	 * Gets the Value
	 * @return Returns a String
	 */
	public String getSubModuleName() {
		return subModuleName;
	}
	/**
	 * Sets the value
	 * @param value The value to set
	 */
	public void setSubModuleName(String subModuleName) {
		this.subModuleName = subModuleName;
	}
	
	/**
	 * Returns the moduleId.
	 * @return String
	 */
	public String getModuleId() {
		return moduleId;
	}

	/**
	 * Returns the submoduleId.
	 * @return String
	 */
	public String getSubmoduleId() {
		return submoduleId;
	}

	/**
	 * Sets the moduleId.
	 * @param moduleId The moduleId to set
	 */
	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	/**
	 * Sets the submoduleId.
	 * @param submoduleId The submoduleId to set
	 */
	public void setSubmoduleId(String submoduleId) {
		this.submoduleId = submoduleId;
	}

}
