package com.dfs.paxtrax.common.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2014, DFS All rights reserved.
 *
 */
 

/**
 *
 * The EJB that performs FlightUpload system related functions
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Mohammed Faheem
 *
 * @version    1.0
 *
 */
public interface FlightUploadBOHome extends javax.ejb.EJBHome {
	/**
	 * Creates a default instance of Session Bean: FlightUploadBO
	 */
	public com.dfs.paxtrax.common.business.FlightUploadBO create()
		throws javax.ejb.CreateException, java.rmi.RemoteException;
}
