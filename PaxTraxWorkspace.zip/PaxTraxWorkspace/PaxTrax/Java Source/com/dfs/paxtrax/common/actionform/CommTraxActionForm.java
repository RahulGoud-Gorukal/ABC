package com.dfs.paxtrax.common.actionform;


import org.apache.struts.action.ActionForm;
/**
 * @author 114258
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class CommTraxActionForm extends ActionForm {
	
private String page = null;

    private String moduleName = null;

    private String subaction = null;

    public String getPage() {
        return this.page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getModuleName() {
        return this.moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getSubaction() {
        return this.subaction;
    }

    public void setSubaction(String subaction) {
        this.subaction = subaction;
    }	

}
