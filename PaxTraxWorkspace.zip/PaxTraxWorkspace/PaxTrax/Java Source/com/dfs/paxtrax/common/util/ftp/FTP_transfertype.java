/**************************************************************************************
*  PROGRAM NAME		:  FTPTransferType
*  NAME OF AUTHOR	:  Bipin
*  DATE OF CREATION	:  25/06/2004
*  DESCRIPTION	    :  This will set the Transfer type.
*  VERSION		    :  1.0
*  CTS All rights reserved
*************************************************************************************
REVISION HISTORY

| Date	 |	Programmer name   |  Ver  |  Change history
---------------------------------------------------------------------------------------------------------
|        |                    |       |
--------------------------------------------------------------------------------------------------------
*/

package com.dfs.paxtrax.common.util.ftp;
 public class FTP_transfertype {


     /**
      *   Represents ASCII transfer type
      */
     public static FTP_transfertype ASCII = new FTP_transfertype();

     /**
      *   Represents Image (or binary) transfer type
      */
     public static FTP_transfertype BINARY = new FTP_transfertype();

     /**
      *   The char sent to the server to set ASCII
      */
     static String ASCII_CHAR = "A";

     /**
      *   The char sent to the server to set BINARY
      */
     static String BINARY_CHAR = "I";


     /**
      *  Private so no-one else can instantiate this class
      */
     private FTP_transfertype() {
     }
}
