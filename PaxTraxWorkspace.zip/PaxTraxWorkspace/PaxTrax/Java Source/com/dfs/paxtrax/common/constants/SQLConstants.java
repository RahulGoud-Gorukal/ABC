package com.dfs.paxtrax.common.constants;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 * This class holds all SQL constants
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created
 * 10/07/2004	P.C. Sathish	Modified
 */

public class SQLConstants {
	/**
	 * Constructor for this class
	 */
	private SQLConstants() {

	}

	/**
	 * Holds the string value ","
	 */
	public static final String COMMA = ",";

	/**
	 * Holds the string value " "
	 */
	public static final String BLANK = "";

	/**
	 * Holds the string value " "
	 */
	public static final String SPACE = " ";

	/**
	 * Holds the string value "'"
	 */
	public static final String QUOTE = "'";

	/**
	 * Holds the character '"'
	 */
	public static final char DOUBLE_QUOTE = '"';

	/**
	 * Holds open parenthesis
	 */
	public static final String OPEN_PAREN = "(";

	/**
	 * Holds close parenthesis
	 */
	public static final String CLOSE_PAREN = ")";

	/**
	 * Holds greater than
	 */
	public static final String GT = ">";

	/**
	 * Holds call
	 */
	public static final String CALL = "call";

	/**
	 * Holds open bracket
	 */
	public static final String OPEN_BRACKET = "{";

	/**
	 * Holds close bracket
	 */
	public static final String CLOSE_BRACKET = "}";

	/**
	 * Holds open question mark
	 */
	public static final String QUESTION_MARK = "{";

	/**
	 * Holds slash
	 */
	public static final String SLASH = "/";

	/**
	 * Holds hyphen
	 */
	public static final String HYPHEN = "-";

	// Security queries
	public static final String ALL = "A";
	/**
	 * Holds update user query
	 */
	public static final String UPDATE_USER_MSTR =
		"update TB_USER_MSTR set "
			+ "USER_USER_ID = ?, USER_USER_PASSWORD = ?, USER_EMP_ID = ?, "
			+ "USER_L_NAME = ?, USER_F_NAME = ?, USER_DOB = ?, USER_REF_ID = ?, "
			+ "USER_LANGUAGE_ID = ?, USER_NEVER_LOCK = ?, USER_INVALID_TRY = ?, "
			+ "USER_ACTIVE = ?, USER_REASON = ?, USER_LOCKED = ? WHERE "
			+ "USER_USER_ID = ?";

	/**
	 * Holds delete user query
	 */
	public static final String DELETE_USER =
		"update TB_USER_MSTR set "
			+ "USER_DELETED = 'Y' where USER_USER_ID = ? ";

	/**
	 * Holds update active status query
	 */
	public static final String UPDATE_ACTIVE_STATUS =
		"update TB_USER_MSTR "
			+ "set USER_ACTIVE = ?, USER_REASON = ? where USER_USER_ID = ? ";

	/**
	 * Holds update lock status query
	 */
	public static final String UPDATE_LOCK_STATUS =
		"update TB_USER_MSTR " + "set USER_LOCKED = ? where USER_USER_ID = ?";

	/**
	 * Holds select transaction query
	 */
	public static final String SELECT_TRANSACTIONS =
		"select TRANS_TRANS_ID, "
			+ "TRANS_TRANS_NAME from TB_TRANS_MSTR TM ORDER BY TM.MODULE_ID";

	/**
	 * check userid exists query
	 */
	public static final String CHECK_USER_ID_EXISTS =
		"select COUNT("
			+ "USER_USER_ID) from TB_USER_MSTR where USER_USER_ID = ? ";

	/**
	 * checks user active query
	 */
	public static final String CHECK_USER_ACTIVE =
		"select USER_ACTIVE from " + "TB_USER_MSTR where USER_USER_ID = ? ";

	/**
	 * Holds procedure call for insert user
	 */
	public static final String PROC_INSERT_USER_DETAILS =
		"{call ADM_INSERT_USER_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

	/**
	 * Holds procedure call for insert transactions
	 */
	public static final String PROC_INSERT_TRANSACTIONS =
		"{call ADM_INSERT_TRANSACTIONS(?,?,?)}";

	/**
	 * Holds procedure call for insert reference data
	 */
	public static final String PROC_INSERT_REF_DATA =
		"{call ADM_INSERT_REF_DATA(?,?,?,?,?,?,?,?)}";

	/**
	 * Holds procedure call for delete reference data
	 */
	public static final String PROC_DELETE_REF_DATA =
		"{call ADM_DELETE_REF_DATA(?,?,?)}";

	/**
	 * Holds NACCS discount code select query
	 */
	public static final String SELECT_NACCS_DISCOUNT_CODE =
		"select NACCS_DISCOUNT_CODE FROM TB_NACCS_DISC_CODE";

	/**
	 * Holds procedure call for naccs details selection
	 */
	//	Added by David for CA #313423 starts
	
	//public static final String PROCE_SELECT_NACCS_DETAILS =
	//	"{call CUS_GET_NACCS_FILE_DETAILS(?,?,?,?)}";
	
	public static final String PROCE_SELECT_NACCS_DETAILS =
				"{call CUS_GET_NACCS_FILE_DETAILS(?,?,?,?,?,?)}";
				
	//	Added by David for CA #313423 ends

	/**
	 * Holds NACCS parameter select query
	 */
	public static final String SELECT_NACCS_PARAMETER =
		"SELECT TO_BE_SENT_DIR, ITEM_PER_FILE, FILE_EXT, "
			+ "CURRENT DATE FROM TB_NACCS_COM_PARA_MSTR";

	/**
	 * Holds procedure call for naccs file header insertion
	 */
	/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : starts  */

//		public static final String PROC_INSERT_NACCS_FILE_HEADER =
//			"{call CUS_INSERT_NACCS_FILE_HDR(?,?,?,?,?,?,?,?,?,?)}";
//		
		public static final String PROC_INSERT_NACCS_FILE_HEADER =
				"{call CUS_INSERT_NACCS_FILE_HDR(?,?,?,?,?,?,?,?,?,?,?)}";
		/* CR 253 Added on Oct 12, 2007 to display Flight Departure time in Customs Report : ends  */

	/**
	 * Holds procedure call for naccs file details insertion
	 */
	public static final String PROC_INSERT_NACCS_FILE_DETAIL =
		"{call CUS_INSERT_NACCS_FILE_DETAIL(?,?,?,?,?,?,?,?,?)}";

	/**
	 * Holds update transaction query
	 */
	/* COMMENTED BY VIGNESH
	 
	public static final String UPDATE_TRANSACTIONS =
		"UPDATE TB_SALES_HEADER_DATA SET SALES_TRANSACTION_STATUS = ? "
			+ " WHERE SALES_SELLING_LOCATION = ? AND SALES_TERMINAL_NUMBER ="
			+ "? AND SALES_TRANSACTION_NUMBER = ?";

			*/
			
/* DP TRANSACTIONS CODE CHANGE FOR RCA # 207068  STARTS HERE  */
	
	public static final String UPDATE_TRANSACTIONS =
	"update TB_SALES_HEADER_DATA set SALES_TRANSACTION_STATUS = ? " 
	+ " where (SALES_SELLING_LOCATION ,SALES_TERMINAL_NUMBER, SALES_TRANSACTION_NUMBER) in "
	+ " (SELECT SALES_SELLING_LOCATION ,SALES_TERMINAL_NO, SALES_TRANSACTION_NUMBER FROM TB_SALES_TRANS_DATA st " 
	+ " where SALES_SELLING_LOCATION = ? and SALES_TERMINAL_NO  = ?  and SALES_TRANSACTION_NUMBER=? " 
	+ " and st.SALES_SKU_DUTY_TYPE='1' ) " ;

/* DP TRANSACTIONS CODE CHANGE FOR RCA # 207068  ENDS HERE  */

	/**
	 * Holds select query for getting naccs ftp parameters
	 */
	public static final String SELECT_NACCS_FTP_PARAMETERS =
		"SELECT IP_ADDRESS, USER_ID, PWD, TO_BE_SENT_DIR, SENT_DIR, "
			+ "DEST_DIR, MAPPED_NACCS_DIR, MAPPED_NACCS_ACK_SRC_DIR,"
			+ "TRANSFER_MODE, FTP_PORT_NUMBER, NACCS_FTP_FREQUENCY, "
			+ "NACCS_FILE_GEN_FREQUENCY, NACCSPC_ACK_SRC_DIR, NACCSPC_ACK_MOVE_DIR,"
			+ "NACCSES_ACK_DEST_DIR, NACCSES_ACK_MOVE_DIR,"
			+ "NACCS_ENTRY_NO_UPLOAD_FREQUENC, NACCS_FLIGHT_GEN_FREQUENCY,"
			+ "ENT_PAXFILE_NAME_LOC, ENT_IMPORT_DECLARATION_LINENO,"
			+ "ENT_FLIGHT_LINENO, ENT_AIRLINE_CODE_LINENO, MAPPED_NACCS_ACK_MOV_DIR "
			+ " FROM TB_NACCS_COM_PARA_MSTR";

	/**
	 * Holds procedure call for updating pax once it is generated
	 */
	public static final String UPDATE_STATUS_FOR_PAX =
		"{call CUS_UPDATE_STATUS_FOR_PAX(?,?,?,?,?)}";

	/**
	 * checks if the NACCS is generated for this flight
	 */
	public static final String CHECK_NACCS_STATUS_FOR_FLIGHT =
		"SELECT COUNT(NACCS_FILE_NAME) FROM TB_NACCS_FILE_HDR "
			+ "WHERE FLIGHT_AIRLINE_REF_ID = ? AND FLIGHT_AIRLINE_CODE_ID = ?"
			+ " AND FLIGHT_FLIGHT_NUMBER = ? AND NACCS_DEPARTURE_DATE = ?";

	/**
	 * Delete query for deleting transaction for the user
	 */
	public static final String DELETE_TRANSACTIONS_FOR_USER =
		"DELETE FROM TB_MAP_TR_TO_USER WHERE USER_USER_ID = ? ";

	public static final String SELECT_PAXNO_FOR_PAXFILENAME =
		"SELECT PAX_NO FROM TB_NACCS_FILE_HDR WHERE NACCS_FILE_NAME = ?";

	public static final String SELECT_LOCATION_DUTY_FREE_AMT_FOR_SELLING_LOCATION =
		"SELECT LOCATION_DUTY_FREE_AMT FROM TB_LOCATION WHERE LOCATION_ID = ?";

	public static final String INSERT_PAX_TOTAL =
		"{call CUS_INSERT_TARIFF_FREE_AMOUNT(?,?,?,?)}";

	public static final String SELECT_PAX_TOTAL =
		"SELECT NACCS_AMOUNT_OF_TARIFF_FREE_GO FROM TB_PAX_TOTAL WHERE PAX_SEQ_ID=? and PAX_PAX_NO=?";

	public static final String SELECT_NACCS_FILE_NAME =
		"SELECT  NACCS_FILE_NAME  from TB_NACCS_FILE_HDR  WHERE PAX_NO=?";

	/*Commented as a part of change request of adding country field in the Naccs File
		 public static final String SELECT_PAX_NOS =
			"select PM.PAX_SEQ_ID, PM.PAX_PAX_NO, "
				+ "PM.PAX_L_NAME, PM.PAX_F_NAME, "
				+ "A.POST_CODE, A.ADDRESS_ADDRESS_LINE1, "
				+ "A.ADDRESS_ADDRESS_LINE2, A.ADDRESS_CITY, "
				+ "CR.CODE_NACCS_CODE "
				+ "from TB_PAX_MSTR PM, TB_ADDRESS A, TB_CODE_REF CR where "
				+ "PM.FLIGHT_DEPT_AIRLINE_REF_ID = ? "
				+ "AND PM.FLIGHT_DEPT_AIRLINE_CODE_ID = ? "
				+ "AND PM.FLIGHT_DEPT_FLIGHT_NUMBER = ? "
				+ "AND PM.FLIGHT_DEPT_DATE = ? "
				+ "AND PM.PAX_SEQ_ID = A.PAX_SEQ_ID "
				+ "AND PM.FLIGHT_DEPT_AIRLINE_REF_ID = CR.REF_ID "
				+ "AND PM.FLIGHT_DEPT_AIRLINE_CODE_ID = CR.CODE_CODE_ID ";
		*/

	public static final String SELECT_PAX_NOS =
			"select PM.PAX_SEQ_ID, PM.PAX_PAX_NO, "
				+ "PM.PAX_L_NAME, PM.PAX_F_NAME, "
				+ "A.POST_CODE, A.ADDRESS_ADDRESS_LINE1, "
				+ "A.ADDRESS_ADDRESS_LINE2, A.ADDRESS_CITY, "
				+ "CR.CODE_NACCS_CODE,A.COUNTRY "
				+ "from TB_PAX_MSTR PM, TB_ADDRESS A, TB_CODE_REF CR where "
				+ "PM.FLIGHT_DEPT_AIRLINE_REF_ID = ? "
				+ "AND PM.FLIGHT_DEPT_AIRLINE_CODE_ID = ? "
				+ "AND PM.FLIGHT_DEPT_FLIGHT_NUMBER = ? "
				+ "AND PM.FLIGHT_DEPT_DATE = ? "
				+ "AND PM.PAX_SEQ_ID = A.PAX_SEQ_ID "
				+ "AND PM.FLIGHT_DEPT_AIRLINE_REF_ID = CR.REF_ID "
				+ "AND PM.FLIGHT_DEPT_AIRLINE_CODE_ID = CR.CODE_CODE_ID ";

	public static final String SELECT_SALES_TRANSACTIONS =
		"select SALES_SELLING_LOCATION, SALES_TERMINAL_NUMBER, "
			+ "SALES_TRANSACTION_NUMBER, SALES_REKEY_TRANSACTION, "
			+ "SALES_ORIG_SELLING_LOC_NUMBER, SALES_ORIG_TERMINAL_NUMBER, "
			+ "SALES_ORIG_TRANSACTION_NUMBER "
			+ "from TB_SALES_HEADER_DATA where PAX_SEQ_ID = ? "
			+ " AND SALES_TRANSACTION_STATUS = '2'  AND SALES_REKEY_TRANSACTION != 'Y'";

	public static final String SELECT_SALES_TRANSACTIONS_LINES =
		"select  STD.SALES_TRANSACTION_LINE_NUMBER ,STD.SALES_SKU_NUM, "
			+ "STD.SALES_SKU_ACTUAL_PRICE , STD.SALES_SKU_REGULAR_PRICE, "
			+ "STD.SALES_SKU_QTY, SM.SKU_SHORT_DESC, "
			+ "SM.HARMONIZE_CODE, SM.TAX_TYPE, "
			+ "SM.DIVISION_NUMBER, SM.SIZE, "
			+ "SM.COUNTRY_OF_ORIGIN, SM.TAX_ALCOHOL_STRENGTH, "
			+ "HM.HARMONIZE_TARIFF_RATE, HM.HARMONIZE_TAX_DENOMINATOR, "
			+ "COO.ISO_COUNTRY_CODE, SM.DEPARTMENT,"
			+ "SM.CLASS "
			+ "from TB_SALES_TRANS_DATA STD, TB_COUNTRY_OF_ORIGIN_MSTR COO, "
			+ "TB_HARMONIZE_MSTR HM, "
			+ "TB_SKU_MSTR SM  where "
			+ "STD.SALES_SELLING_LOCATION = ? "
			+ "AND STD.SALES_TERMINAL_NO = ? "
			+ "AND STD.SALES_TRANSACTION_NUMBER = ? "
			+ "AND STD.SALES_SKU_DUTY_TYPE = ? "
			+ "AND STD.SALES_SKU_NUM = SM.SKU_NUMBER "
			+ "AND HM.HARMONIZE_CODE = SM.HARMONIZE_CODE "
			+ "AND HM.DIVISION_NUMBER = SM.DIVISION_NUMBER "
			+ "AND SM.COUNTRY_OF_ORIGIN = COO.COUNTRY_OF_ORIGIN ";

	public static final String SELECT_TAX_DETAILS =
		"select TAX_CONCUMPTION_TAX, TAX_RATE_DENOMINATOR from TB_TAX_MSTR "
			+ "where DIVISION_NUMBER = ? "
			+ "AND TAX_ALCOHOL_STRENGTH = ? "
			+ "AND TAX_TYPE = ?";

	public static final String SELECT_DISCOUNT_DETAILS =
		"select SALES_DISCOUNT_AMOUNT, SALES_DISCOUNT_CODE from "
			+ "TB_SALES_DISCOUNT_DETAIL where "
			+ "SALES_SELLING_LOCATION = ? "
			+ "AND SALES_TERMINAL_NO = ? AND SALES_TRANSACTION_LINE_NUMBER = ?"
			+ "AND SALES_TRANSACTION_NUMBER = ?";

	public static final String SELECT_CONSUMPTION_CLASSIFICATION =
		"select TAX_TYPE, ALCO_CLASSIFICATION_CODE, SPARK_CLASSIFICATION_CODE, INCLUDE_ALCO_STRENGTH from "
			+ "TB_ALCO_SPARK_CLASSIFICATION";

	public static final String SELECT_CONSUMPTION_DESCRIPTION =
		"select TAX_TYPE, DESCRIPTION, LEFT_OPERATOR, LEFT_OPERATOR_VALUE, "
			+ "RIGHT_OPERATOR, RIGHT_OPERATOR_VALUE, DESCRIPTION_CODE from "
			+ "TB_PROD_SUB_DESCRIPTION";

	public static final String SELECT_NABCO_DETAILS =
		"select SELLING_LOCATION, LOCATION_DESC, "
			+ "PERCENT_SALE_NCP, NATIONAL_CONSUMPTION_TAX, "
			+ "LOCAL_CONSUMPTION_TAX  from TB_NABCO a, TB_LOCATION b "
			+ "where  a.selling_location=b.LOCATION_ID";

	public static final String SELECT_SALES_TRANSACTION_NET_AMT =
		"SELECT SUM(SHD.SALES_TRANSACTION_NET_AMOUNT) FROM "
			+ "TB_SALES_HEADER_DATA SHD, TB_NABCO_STORES NS WHERE SHD.PAX_SEQ_ID IN "
			+ "(SELECT PAX_SEQ_ID FROM TB_PAX_MSTR WHERE FLIGHT_DEPT_DATE= ? ) "
			+ "AND SHD.SALES_SELLING_LOCATION=NS.SALES_SELLING_LOCATION "
			+ "AND SHD.SALES_TERMINAL_NUMBER = NS.SALES_TERMINAL_NO "
			+ "AND SHD.SALES_SELLING_LOCATION= ? "
			+ "AND NS.NABCO_LOCATION=? "
			+ "AND SHD.SALES_TRANSACTION_STATUS > ?";

	public static final String SELECT_SALES_TRANSACTION_DETAILS =
		"select NACCS_FILE_NAME, ITEM, "
			+ "QTY, NACCS_UNIT_PRICE, "
			+ "TARIFF_IDENTIFIER from TB_NACCS_FILE_DETAIL "
			+ "where NACCS_FILE_NAME in (select NACCS_FILE_NAME "
			+ "from TB_NACCS_FILE_HDR where NACCS_DEPARTURE_DATE= ? and SELLING_LOCATION= ?)";

	public static final String SELECT_NABCO_TAX_DETAILS =
		"select SM.SIZE, SM.TAX_ALCOHOL_STRENGTH, TAX_CONCUMPTION_TAX, TAX_RATE_DENOMINATOR, SM.TAX_TYPE from TB_TAX_MSTR TM, TB_SKU_MSTR SM "
			+ "where  TM.DIVISION_NUMBER =  SM.DIVISION_NUMBER "
			+ "and  TM.TAX_ALCOHOL_STRENGTH= SM.TAX_ALCOHOL_STRENGTH and SM.TAX_TYPE is not null and TM.TAX_TYPE=SM.TAX_TYPE and sku_number= ?";

	public static final String SELECT_NABCO_HARMO_DETAILS =
		"SELECT HARMONIZE_TARIFF_RATE, HARMONIZE_TAX_DENOMINATOR FROM TB_SKU_MSTR SM, TB_HARMONIZE_MSTR HM WHERE "
			+ "SM.DIVISION_NUMBER = HM.DIVISION_NUMBER AND SM.HARMONIZE_CODE = HM.HARMONIZE_CODE AND SM.SKU_NUMBER= ?";

	public static final String SELECT_POSTAL_CODE_DETAILS =
		"select POST_CODE_AREA, POST_CODE_PREFECTURE, "
			+ "POST_CODE_CITY from TB_POST_CODE_MSTR  where POST_CODE = ?";

	public static final String CONSUMPTION_TAX_CALCULATOR_PROC =
		"call CUS_GET_NABCO_DETAILS(?,?,?,?,?,?,?,?)";

	public static final String SELECT_UNIQUE_NABCO_STORES =
		"SELECT DISTINCT NABCO_LOCATION FROM TB_NABCO_STORES WHERE SALES_SELLING_LOCATION = ?";

	public static final String SELECT_NABCO_STORE_TABLE_DETAILS =
		"SELECT SALES_SELLING_LOCATION, SALES_TERMINAL_NO, NABCO_LOCATION FROM TB_NABCO_STORES ";

	public static final String SELECT_TAX_MSTR_TABLE_DETAIILS =
		"SELECT DIVISION_NUMBER, TAX_TYPE, TAX_ALCOHOL_STRENGTH,"
			+ "TAX_CONCUMPTION_TAX, TAX_RATE_DENOMINATOR FROM TB_TAX_MSTR";

	public static final String SELECT_HARMO_MSTR_TABLE_DETAILS =
		"SELECT DIVISION_NUMBER, HARMONIZE_CODE, HARMONIZE_TARIFF_RATE,"
			+ "HARMONIZE_TAX_DENOMINATOR FROM TB_HARMONIZE_MSTR";

	public static final String SELECT_NACCS_FILE_HDR_NACCS_FILE_NAME =
		"SELECT NACCS_FILE_NAME FROM TB_NACCS_FILE_HDR WHERE "
			+ " NACCS_DEPARTURE_DATE=?";

	public static final String SELECT_NACCS_FILE_DETAILS_NACCS_FILE_NAME =
		"SELECT ITEM, QTY, NACCS_UNIT_PRICE, TARIFF_IDENTIFIER, "
			+ "SALES_SELLING_LOCATION, SALES_TERMINAL_NO "
			+ "from TB_NACCS_FILE_DETAIL where NACCS_FILE_NAME=? "
			+ "and SALES_SELLING_LOCATION=?";

	public static final String SELECT_DUTY_FREE_NACCS_FILE_NAME1 =
		" select  hdr.naccs_file_name,detail.ITEM,detail.QTY,detail.NACCS_UNIT_PRICE,detail.TARIFF_IDENTIFIER,detail.SALES_SELLING_LOCATION,detail.SALES_TERMINAL_NO,  "
			+ " skuMstr.DIVISION_NUMBER,skuMstr.SIZE, skuMstr.TAX_ALCOHOL_STRENGTH,skuMstr.TAX_TYPE, skuMstr.HARMONIZE_CODE   from tb_naccs_file_hdr hdr ,TB_SKU_MSTR skuMstr, "
			+ " tb_naccs_file_detail detail where hdr.naccs_file_name =detail.naccs_file_name and "
			+ " detail.sales_selling_location=?  and month(naccs_departure_date) = ? and   detail.ITEM = skuMstr.sku_number";

	public static final String SELECT_TAX_FROM_SKU_MSTR =
		"SELECT DIVISION_NUMBER, SIZE, TAX_ALCOHOL_STRENGTH, "
			+ "TAX_TYPE, HARMONIZE_CODE from TB_SKU_MSTR "
			+ "WHERE SKU_NUMBER=?";

	public static final String SELECT_NACCS_DUPLICATE_PAX_DETAILS =
		"SELECT pm.pax_seq_id, pm.pax_pax_no, pm.pax_l_name , pm.pax_f_name, POST_CODE   "
			+ "from tb_pax_mstr  pm, TB_ADDRESS ADR  "
			+ "where pm.pax_pax_no is not null and pm.pax_seq_id = ADR.pax_seq_id "
			+ "AND FLIGHT_DEPT_AIRLINE_CODE_ID=? "
			+ "AND FLIGHT_DEPT_FLIGHT_NUMBER=? "
			+ "AND FLIGHT_DEPT_DATE=? "
			+ "and (UCASE(pax_l_name),UCASE(pax_f_name))  in (   "
			+ "select  UCASE(pax_l_name ), UCASE( pax_f_name ) from tb_pax_mstr   "
			+ "where FLIGHT_DEPT_AIRLINE_CODE_ID=? "
			+ "AND FLIGHT_DEPT_FLIGHT_NUMBER=? "
			+ "AND FLIGHT_DEPT_DATE=? "
			+ "group by (UCASE(pax_l_name),UCASE(Pax_f_name)) having count(*) >1)   "
			+ "order by PAX_L_NAME, PAX_F_NAME, PAX_PAX_NO";

	/*---Commented as a part of the change request to make Duplicate PAX report to show Duty Free items only
	 public static final String SELECT_NACCS_DUPLICATE_SALES_HEADER_DATA =
		"SELECT SALES_TRANSACTION_TYPE, SALES_SELLING_LOCATION, SALES_TERMINAL_NUMBER,  "
			+ "SALES_TRANSACTION_NUMBER,SALES_SALES_ASSOCIATE_ID,SALES_TRANSACTION_DATE,  "
			+ "SALES_TRANSACTION_TIME, SALES_TRANSACTION_NET_AMOUNT, SALES_TRANSACTION_STATUS "
			+ "from TB_SALES_HEADER_DATA where PAX_SEQ_ID=?  "
			+ "order by SALES_TRANSACTION_DATE, SALES_TRANSACTION_TIME";
	*/

	//---The changed query added on 2006-01-24
	public static final String SELECT_NACCS_DUPLICATE_SALES_HEADER_DATA =
		"SELECT SALES_TRANSACTION_TYPE, SALES_SELLING_LOCATION, SALES_TERMINAL_NUMBER,  "
			+ "SALES_TRANSACTION_NUMBER,SALES_SALES_ASSOCIATE_ID,SALES_TRANSACTION_DATE,  "
			+ "SALES_TRANSACTION_TIME, SALES_TRANSACTION_NET_AMOUNT, SALES_TRANSACTION_STATUS "
			+ "from TB_SALES_HEADER_DATA where PAX_SEQ_ID=? and SALES_REPORT_GROUP!=630 and SALES_TRANSACTION_TYPE='S' and SALES_TRANSACTION_STATUS!='6' "
			+ "order by SALES_TRANSACTION_DATE, SALES_TRANSACTION_TIME";

	public static final String SELECT_SALES_REFUND_DATA =
		"SELECT COUNT(SALES_ORIG_TRANSACTION_NUMBER) FROM TB_SALES_HEADER_DATA WHERE "
			+ "SALES_ORIG_SELLING_LOC_NUMBER = ? AND "
			+ "SALES_ORIG_TERMINAL_NUMBER = ? AND "
			+ "SALES_ORIG_TRANSACTION_NUMBER = ?";

	public static final String SELECT_PAX_REFUND_FLIGHT_DETAILS =
		"SELECT PFC.FLIGHT_CHANGE_SEQ_ID, PFC.PAX_SEQ_ID,"
			+ "PM.PAX_PAX_NO, PM.PAX_L_NAME,"
			+ "FCB.BAG_NO, FCB.FLIGHT_CHANGE_ACTION,"
			+ "PFC.FROM_DEPT_AIRLINE_ID, CR1.CODE_CODE_VALUE AS FROM_AIRLINE_CODE_VALUE,"
			+ " PFC.FROM_DEPT_FLIGHT_NUMBER,"
			+ "PFC.FROM_DEPT_DATE,"
			+ "PFC.TO_DEPT_AIRLINE_ID, CR2. CODE_CODE_VALUE AS TO_AIRLINE_CODE_VALUE,"
			+ " PFC.TO_DEPT_FLIGHT_NUMBER,"
			+ " PFC.TO_DEPT_DATE "
			+ "FROM TB_PAX_FLIGHT_CHANGE PFC INNER JOIN TB_CODE_REF CR1 ON "
			+ "PFC.FROM_DEPT_DATE >= ? AND PFC.TO_DEPT_DATE <= ? AND "
			+ "CR1.REF_ID='8' AND PFC.FROM_DEPT_AIRLINE_ID = CR1.CODE_CODE_ID "
			+ "INNER JOIN TB_CODE_REF CR2 ON CR2.REF_ID='8' "
			+ "AND PFC.TO_DEPT_AIRLINE_ID = CR2.CODE_CODE_ID "
			+ "INNER JOIN TB_PAX_MSTR PM ON PFC.PAX_SEQ_ID = PM.PAX_SEQ_ID "
			+ "INNER JOIN TB_FLIGHT_CHANGE_BAG FCB ON "
			+ "PFC.FLIGHT_CHANGE_SEQ_ID = FCB.FLIGHT_CHANGE_SEQ_ID "
			+ "AND FCB.FLIGHT_CHANGE_ACTION = 'N' "
			+ "ORDER BY FCB.BAG_NO, PFC.FLIGHT_CHANGE_SEQ_ID";

	public static final String SELECT_PAX_REFUND_BAG_DETAILS =
		"select entity_display_status, carton_no,wh_bin_loc_id,cage_no,"
			+ "truck_no,ap_bin_loc_id  from tb_bag_status_history b,"
			+ "tb_entity_status_mstr e where bag_no = ? and "
			+ "e.entity_status_id=b.status_id and  e.entity_id = 2 "
			+ "order by created_timestamp desc fetch first 1 rows only";

	public static final String SELECT_PAX_REFUND_DETAILS =
		"SELECT PM.PAX_PAX_NO, PM.PAX_L_NAME,BM.PAX_SEQ_ID,"
			+ "RB.BAG_NO, RB.REFUND_TIMESTAMP, RB.ACTION_TAKEN "
			+ "FROM TB_REFUND_BAG RB INNER JOIN TB_BAG_MSTR BM ON "
			+ "date( RB.REFUND_TIMESTAMP ) >= ? AND date( RB.REFUND_TIMESTAMP ) <= ? "
			+ "AND RB.ACTION_TAKEN = 'N' AND RB.BAG_NO = BM.BAG_NO "
			+ "INNER JOIN TB_PAX_MSTR PM ON BM.PAX_SEQ_ID = PM.PAX_SEQ_ID";

	public static final String SELECT_BAG_HISTORY =
		"SELECT BSH.BAG_NO, BSH.BAG_ENTITY_ID, BSH.STATUS_ID, "
			+ "ESM.ENTITY_DISPLAY_STATUS AS BAG_STATUS, BSH.CARTON_NO,"
			+ "BSH.CARTON_CYCLE_ID, BSH.WH_BIN_LOC_ID, BSH.CAGE_NO, BSH.SHELF_NO,"
			+ "BSH.CAGE_CYCLE_ID, BSH.TRUCK_NO, BSH.TRIP_ID, BSH.AP_BIN_LOC_ID,"
			+ "BSH.CREATED_TIMESTAMP, BSH.TERMINAL_NO, BSH.CREATED_BY "
			+ "FROM TB_BAG_STATUS_HISTORY BSH INNER JOIN "
			+ "TB_ENTITY_STATUS_MSTR ESM ON BSH.BAG_NO = ? AND "
			+ "BSH.BAG_ENTITY_ID = ESM.ENTITY_ID AND "
			+ "BSH.STATUS_ID = ESM.ENTITY_STATUS_ID "
			+ "ORDER BY BSH.CREATED_TIMESTAMP DESC FOR READ ONLY";

	public static final String SELECT_SALES_DUTY_FREE_TOTAL =
		"SELECT SALES_TOTAL_DUTY_FREE FROM TB_PAX_TOTAL WHERE "
			+ "PAX_PAX_NO = ? ";

	public static final String BAGS_IN_CAGE =
		"SElECT bagCarton.CARTON_NUMBER,bagCarton.CARTON_CYCLE_ID,bagMaster.BAG_NO,paxMstr.PAX_PAX_NO,"
			+ " paxMstr.PAX_L_NAME, paxMstr.PAX_F_NAME, ENTITY_DISPLAY_STATUS "
			+ " FROM TB_BAG_TO_CARTON bagCarton,TB_BAG_MSTR bagMaster ,TB_PAX_MSTR paxMstr, "
			+ " TB_ENTITY_STATUS_MSTR WHERE bagMaster.PAX_SEQ_ID= paxMstr.PAX_SEQ_ID AND  "
			+ " bagMaster.CURR_STATUS_ID = ENTITY_STATUS_ID and ENTITY_ID =2 and  "
			+ " bagMaster.CURR_BAG_CARTON_SEQ_ID=bagCarton.BAG_CARTON_SEQ_ID   "
			+ " and bagCarton.CARTON_NUMBER IN (select cartonMstr.CARTON_NUMBER from  "
			+ " TB_CARTON_TO_CAGE_SHELF cartonCage,TB_CARTON_MSTR cartonMstr where  "
			+ " cartonCage.CAGE_NUMBER=? AND cartonCage.CARTON_CAGE_SEQ_ID =  "
			+ " cartonMstr.CURR_CARTON_CAGE_SEQ_ID)";

	public static final String GET_BAGS_FOR_PAX =
		"SELECT BAG_NO FROM TB_BAG_MSTR M, TB_PAX_MSTR P WHERE M.PAX_SEQ_ID = P.PAX_SEQ_ID AND P.PAX_PAX_NO = ?";

	public static final String BAG_DETAILS_FOR_PAX =
		"SELECT  ENTITY_DISPLAY_STATUS,history.CARTON_NO, "
			+ " history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO, "
			+ " history.TRUCK_NO,history.AP_BIN_LOC_ID,history.created_by, history.created_timestamp,"
			+ " history.terminal_no,history.CARTON_CYCLE_ID, "
			+ " history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history , TB_ENTITY_STATUS_MSTR WHERE"
			+ " ENTITY_ID=2 AND ENTITY_STATUS_ID=history.STATUS_ID AND history.BAG_NO = ?  order by created_timestamp desc fetch First 1 rows only  FOR READ ONLY";

	public static final String GET_BAG_DETAILS_FOR_FLIGHT_PICKUP =
		"SELECT  history.CARTON_NO, "
			+ " history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO, "
			+ " history.TRUCK_NO,history.AP_BIN_LOC_ID, history.created_timestamp,"
			+ " history.terminal_no,history.created_by,history.CARTON_CYCLE_ID, "
			+ " history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history WHERE"
			+ " history.BAG_NO = ?  order by created_timestamp desc fetch First 1 rows only  FOR READ ONLY";

	public static final String ITEM_ENQUIRY_REPORT_BAGS =
		" SELECT pax.pax_pax_no,pax.pax_l_name,pax.pax_f_name,mstr.BAG_NO,mstr.CURR_STATUS_ID, ENTITY_DISPLAY_STATUS FROM "
			+ " TB_BAG_MSTR mstr, TB_PAX_MSTR pax, TB_ENTITY_STATUS_MSTR, TB_SALES_TRANS_DATA salesTrans "
			+ " WHERE mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID AND ENTITY_ID=2 AND ENTITY_STATUS_ID=mstr.CURR_STATUS_ID AND salesTrans.SALES_SKU_NUM = ? "
			+ " AND salesTrans.SALES_SELLING_LOCATION = mstr.SALES_SELLING_LOCATION AND  "
			+ "  salesTrans.SALES_TRANSACTION_NUMBER = mstr.SALES_TRANSACTION_NUMBER AND "
			+ " salesTrans.SALES_TERMINAL_NO = mstr.SALES_TERMINAL_NUMBER  FOR READ ONLY";

	public static final String GET_BAG_DETAILS_FOR_ITEM_ENQUIRY =
		"SELECT  history.CARTON_NO, "
			+ " history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO, "
			+ " history.TRUCK_NO,history.AP_BIN_LOC_ID, history.created_timestamp,"
			+ " history.terminal_no,history.created_by,history.CARTON_CYCLE_ID, "
			+ " history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history WHERE"
			+ " history.BAG_NO = ?  order by created_timestamp desc fetch First 1 rows only  FOR READ ONLY";

	public static final String STOCK_AT_PICKUP_CAGE_COUNT =
		" SELECT CAGE_NUMBER, SHELF_NUMBER,"
			+ " COUNT(CARTON_NUMBER) FROM TB_CARTON_TO_CAGE_SHELF "
			+ " WHERE CAGE_NUMBER = ? "
			+ " GROUP BY CAGE_NUMBER, SHELF_NUMBER  "
			+ " ORDER BY CAGE_NUMBER, SHELF_NUMBER ";
	
	//Modified by selvam for CA# 294102 starts
	//public static final String SELECT_TRUCK_LIST ="SELECT TRUCK_NUMBER FROM TB_TRUCK_MSTR WHERE TRUCK_DELETED = 'N' AND CURR_STATUS_ID < 3 ";
	public static final String SELECT_TRUCK_LIST =
		"SELECT TRUCK_NUMBER FROM TB_TRUCK_MSTR WHERE TRUCK_DELETED = 'N' AND CURR_STATUS_ID < 5 ";
//	Modified by selvam for CA# 294102 ends

	public static final String PROC_ASSIGN_WARE_HOUSE =
		"call BT_OVERRIDE_WH(?,?,?,?,?,?)";

	public static final String PROC_ASSIGN_AIR_PORT =
		"call BT_OVERRIDE_AP(?,?,?,?,?)";

	public static final String STOCK_AT_PICKUP_BAG_DETAILS =
		" SELECT DISTINCT BAGMSTR.BAG_NO,CARTONMSTR.CURR_STATUS_ID,ENTITYSTATUS.ENTITY_DISPLAY_STATUS, "
			+ " PAXMSTR.PAX_L_NAME,PAXMSTR.PAX_F_NAME,CODEREF.REF_ID,CODEREF.CODE_CODE_ID,"
			+ " CODEREF.CODE_CODE_VALUE, PAXMSTR.FLIGHT_DEPT_FLIGHT_NUMBER,CARTONMSTR.CARTON_NUMBER, "
			+ " PAXMSTR.FLIGHT_DEPT_DATE,CARTONMSTR.CURR_CYCLE_ID FROM TB_PAX_MSTR PAXMSTR, TB_BAG_MSTR BAGMSTR,   TB_CODE_REF CODEREF ,  "
			+ " TB_ENTITY_STATUS_MSTR ENTITYSTATUS,TB_BAG_TO_CARTON BAGCARTON, "
			+ " TB_CARTON_TO_CAGE_SHELF CAGESHELF, TB_CAGE_MSTR CAGEMSTR,TB_CARTON_MSTR CARTONMSTR WHERE BAGMSTR.PAX_SEQ_ID = "
			+ " PAXMSTR.PAX_SEQ_ID AND CODEREF.CODE_CODE_ID = PAXMSTR.FLIGHT_DEPT_AIRLINE_CODE_ID AND "
			+ " PAXMSTR .FLIGHT_DEPT_AIRLINE_REF_ID = CODEREF.REF_ID AND CARTONMSTR.CURR_STATUS_ID =  "
			+ " ENTITYSTATUS.ENTITY_STATUS_ID AND ENTITYSTATUS.ENTITY_ID =2 AND BAGMSTR.CURR_BAG_CARTON_SEQ_ID = "
			+ " BAGCARTON.BAG_CARTON_SEQ_ID AND BAGCARTON.CARTON_CYCLE_ID =CAGESHELF.CARTON_CYCLE_ID AND CAGESHELF.CAGE_CYCLE_ID =  "
			+ " CAGEMSTR.CURR_CYCLE_ID AND CARTONMSTR.CARTON_NUMBER=BAGCARTON.CARTON_NUMBER AND CAGEMSTR.CAGE_NUMBER =? ";

	public static final String BAG_NOT_READY_PICKUP =
		"SELECT  mstr.BAG_NO ,mstr.curr_status_ID ,ent.entity_display_status, pax.pax_l_name, pax.pax_f_name FROM "
			+ " TB_BAG_MSTR mstr, tb_entity_status_mstr ent ,TB_PAX_MSTR pax WHERE mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID and FLIGHT_DEPT_AIRLINE_REF_ID = '8' AND "
			+ " FLIGHT_DEPT_AIRLINE_CODE_ID = ? AND FLIGHT_DEPT_FLIGHT_NUMBER = ?  AND  "
			+ " mstr.curr_status_ID=ent.entity_status_id and ent.entity_id =2 and mstr.curr_status_ID in (1,2,3,4,5,6,7,8,9,12,13,14,15) and "
			+ " FLIGHT_DEPT_FLIGHT_TYPE = 'D' AND VARCHAR(FLIGHT_DEPT_DATE) =? ORDER BY mstr.curr_status_id desc,mstr.BAG_NO FOR READ ONLY";

	public static final String GET_STATUS_BAGTOTAL =
		" SELECT ent.ENTITY_DISPLAY_STATUS,CURR_STATUS_ID,COUNT(BAG_NO) from "
			+ "TB_BAG_MSTR bag,TB_PAX_MSTR pax,TB_ENTITY_STATUS_MSTR ent where "
			+ "bag.PAX_SEQ_ID = pax.PAX_SEQ_ID and FLIGHT_DEPT_AIRLINE_REF_ID = '8' "
			+ "AND FLIGHT_DEPT_AIRLINE_CODE_ID = ? AND FLIGHT_DEPT_FLIGHT_NUMBER = "
			+ "? AND FLIGHT_DEPT_FLIGHT_TYPE = 'D' AND VARCHAR(FLIGHT_DEPT_DATE) = ? and "
			+ "CURR_STATUS_ID =ent.ENTITY_STATUS_ID and ent.ENTITY_ID =2  group by("
			+ "CURR_STATUS_ID,ent.ENTITY_DISPLAY_STATUS) FOR READ ONLY";

	public static final String GET_BAG_FOR_FLIGHT =
		"SELECT  mstr.BAG_NO,pax.PAX_PAX_NO,pax.PAX_L_NAME,pax.PAX_F_NAME "
			+ "from TB_BAG_MSTR mstr,TB_PAX_MSTR pax WHERE mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID "
			+ " and FLIGHT_DEPT_AIRLINE_REF_ID = '8' AND FLIGHT_DEPT_AIRLINE_CODE_ID = ? AND FLIGHT_DEPT_FLIGHT_NUMBER = ?"
			+ " AND FLIGHT_DEPT_FLIGHT_TYPE = 'D' AND VARCHAR(FLIGHT_DEPT_DATE) = ? FOR READ ONLY ";

	public static final String GET_BAG_DETAILS_FOR_FLIGHT =
		"SELECT  history.STATUS_ID,ent.ENTITY_DISPLAY_STATUS,history.CARTON_NO, "
			+ " history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO, "
			+ " history.TRUCK_NO,history.AP_BIN_LOC_ID, history.created_timestamp,"
			+ "history.terminal_no,history.created_by,history.CARTON_CYCLE_ID, "
			+ " history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history,"
			+ " TB_entity_status_mstr ent WHERE history.STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = 2 "
			+ " and history.BAG_NO = ?  order by created_timestamp desc fetch First 1 rows only  FOR READ ONLY";

	public static final String UPDATE_COND_VISIT =
		"INSERT INTO TB_COND_PAX_VISIT(VISIT_CODE,PAX_SEQ_NO) VALUES(?,?)";

	/**
	 * Holds query to search GROUP
	 */


	
	//Commented by selvam  for Ticket # 283759   
/*	public static final String SEARCH_GROUP =
		"SELECT A.START_PAX_NO,A.NUMBER_OF_PAX,A.GROUP_SEQ_ID,"
			+ "A.FLIGHT_ARR_AIRLINE_REF_ID,A.FLIGHT_ARR_AIRLINE_CODE_ID,(SELECT "
			+ "D.CODE_CODE_VALUE FROM TB_CODE_REF D WHERE D.REF_ID = "
			+ "A.FLIGHT_ARR_AIRLINE_REF_ID AND D.CODE_CODE_ID = "
			+ "A.FLIGHT_ARR_AIRLINE_CODE_ID),A.FLIGHT_ARR_FLIGHT_NUMBER,"
			+ "A.FLIGHT_ARR_DATE,A.FLIGHT_DEPT_AIRLINE_REF_ID,"
			+ "A.FLIGHT_DEPT_AIRLINE_CODE_ID,(SELECT C.CODE_CODE_VALUE FROM TB_CODE_REF C "
			+ "WHERE C.REF_ID = A.FLIGHT_DEPT_AIRLINE_REF_ID AND C.CODE_CODE_ID = "
			+ "A.FLIGHT_DEPT_AIRLINE_CODE_ID),A.FLIGHT_DEPT_FLIGHT_NUMBER,"
			+ "A.FLIGHT_DEPT_DATE,A.FLIGHT_ARR_TYPE,A.FLIGHT_DEPT_TYPE FROM "
			+ "TB_GROUP_MSTR A WHERE A.VISIT_CODE = ?";	 */
	//Added by selvam for Ticket # 283759  starts
	public static final String SEARCH_GROUP =
			"SELECT A.START_PAX_NO,A.NUMBER_OF_PAX,A.GROUP_SEQ_ID,"
				+ "A.FLIGHT_ARR_AIRLINE_REF_ID,A.FLIGHT_ARR_AIRLINE_CODE_ID,(SELECT "
				+ "D.CODE_CODE_VALUE FROM TB_CODE_REF D WHERE D.REF_ID = "
				+ "A.FLIGHT_ARR_AIRLINE_REF_ID AND D.CODE_CODE_ID = "
				+ "A.FLIGHT_ARR_AIRLINE_CODE_ID),A.FLIGHT_ARR_FLIGHT_NUMBER,"
				+ "A.FLIGHT_ARR_DATE,A.FLIGHT_DEPT_AIRLINE_REF_ID,"
				+ "A.FLIGHT_DEPT_AIRLINE_CODE_ID,(SELECT C.CODE_CODE_VALUE FROM TB_CODE_REF C "
				+ "WHERE C.REF_ID = A.FLIGHT_DEPT_AIRLINE_REF_ID AND C.CODE_CODE_ID = "
				+ "A.FLIGHT_DEPT_AIRLINE_CODE_ID),A.FLIGHT_DEPT_FLIGHT_NUMBER,"
				+ "A.FLIGHT_DEPT_DATE,A.FLIGHT_ARR_TYPE,A.FLIGHT_DEPT_TYPE ,PM.NATIONALITY_CODE_CODE_ID FROM "
				+ "TB_GROUP_MSTR A,TB_PAX_MSTR  PM WHERE A.VISIT_CODE = ?    and A.START_PAX_NO=PM.PAX_PAX_NO";	  
//	Added by selvam for Ticket # 283759  ends		
				
	public static final String GET_MISSING_BAGS =
		" select bagmstr.bag_no from tb_bag_mstr bagmstr ,tb_pax_mstr paxmstr "
			+ " where bagmstr.pax_seq_id=paxmstr.pax_seq_id and varchar(FLIGHT_DEPT_DATE) >= ? "
			+ " and varchar(FLIGHT_DEPT_DATE) <=?  and bagmstr.curr_status_id in ";

	public static final String MISSING_BAG_DETAILS =
		"{call BT_GET_MISSING_BAGS(?,?,?,?,?)}";

	//Holds query to search visit details
	public static final String START_VISIT =
	/*	"SELECT VM.VISIT_CODE,VM.TA_CODE,VM.TA_BRANCH_CODE,VM.EXP_VISIT_DATE,"
			+ "VM.EXP_VISIT_TIME,VM.EXP_NO_OF_PAX,TAM.TA_AGENCY_NAME,"
			+ "TBM.TA_BRANCH_NAME,VM.VISIT_NAME,GUIDE_NAME,ESCORT_NAME,REMARKS FROM TB_VISIT_MSTR VM,TB_TA_MSTR TAM,"
			+ "TB_TA_BRANCH_MSTR TBM WHERE VM.TA_CODE = TAM.TA_CODE AND "
			+ "VM.TA_BRANCH_CODE = TBM.TA_BRANCH_CODE AND TAM.TA_CODE = TBM.TA_CODE "
			+ "AND VM.VISIT_STATUS = 'R'";
	*/
	
	// added for CR695 on 03-0ct 2008 begin
		"SELECT VM.VISIT_CODE,VM.TA_CODE,VM.TA_BRANCH_CODE,VM.EXP_VISIT_DATE,"
			+ "VM.EXP_VISIT_TIME,VM.EXP_NO_OF_PAX,TAM.TA_AGENCY_NAME,"
			+ "TBM.TA_BRANCH_NAME,VM.VISIT_NAME,GUIDE_NAME,ESCORT_NAME,REMARKS, VM.ACTUAL_VISIT_DATE,VM.ACTUAL_VISIT_TIME FROM TB_VISIT_MSTR VM,TB_TA_MSTR TAM,"
			+ "TB_TA_BRANCH_MSTR TBM WHERE VM.TA_CODE = TAM.TA_CODE AND "
			+ "VM.TA_BRANCH_CODE = TBM.TA_BRANCH_CODE AND TAM.TA_CODE = TBM.TA_CODE "
			+ "AND VM.VISIT_STATUS = 'R'";
	
	// added for CR695 on 03-0ct 2008 end
	
	
	//Holds query that fetches pax details based on visitcode
	public static final String GET_VISIT_PAX =
		"SELECT PM.PAX_PAX_NO,PM.PAX_L_NAME,PM.PAX_F_NAME,PM.FLIGHT_DEPT_DATE,"
			+ "(SELECT CR.CODE_CODE_VALUE FROM TB_CODE_REF CR WHERE CR.REF_ID = "
			+ "PM.FLIGHT_DEPT_AIRLINE_REF_ID AND CR.CODE_CODE_ID = "
			+ "PM.FLIGHT_DEPT_AIRLINE_CODE_ID),PM.FLIGHT_DEPT_FLIGHT_NUMBER,(SELECT "
			+ "ADDR.POST_CODE FROM TB_ADDRESS ADDR WHERE ADDR.PAX_SEQ_ID = PM.PAX_SEQ_ID) "
			+ "FROM TB_COND_PAX_VISIT PV,TB_PAX_MSTR PM WHERE PV.VISIT_CODE = ? AND "
			+ "PV.PAX_SEQ_NO = PM.PAX_SEQ_ID";

	public static final String GET_ITEM_DETAILS =
		"SELECT SALES_SKU_NUM, sales_sku_description, sum(sales_sku_qty) AS SUM_SALE_QTY "
			+ " FROM TB_SALES_TRANS_DATA TRANS,TB_SALES_HEADER_DATA HEADER,TB_PAX_MSTR mstr "
			+ " WHERE HEADER.SALES_SELLING_LOCATION= TRANS.SALES_SELLING_LOCATION AND "
			+ " HEADER.SALES_TERMINAL_NUMBER =TRANS.SALES_TERMINAL_NO AND "
			+ " HEADER.SALES_TRANSACTION_NUMBER = TRANS.SALES_TRANSACTION_NUMBER AND "
			+ " TRANS.SALES_SKU_DUTY_TYPE = '1' AND HEADER.SALES_TRANSACTION_TYPE ='S' AND "
			+ " HEADER.SALES_REKEY_TRANSACTION <> 'Y' AND HEADER.PAX_SEQ_ID=MSTR.PAX_SEQ_ID"
			+ " AND  SALES_SKU_DEPARTMENT = ? AND MSTR.PAX_PAX_NO = ? "
			+ " GROUP BY(SALES_SKU_NUM, SALES_SKU_DESCRIPTION)  ORDER BY SALES_SKU_NUM ";

	public static final String GET_DP_ITEM_DETAILS =
		"SELECT SALES_SKU_NUM, sales_sku_description, sum(sales_sku_qty) AS SUM_SALE_QTY "
			+ " FROM TB_SALES_TRANS_DATA TRANS,TB_SALES_HEADER_DATA HEADER,TB_PAX_MSTR mstr "
			+ " WHERE HEADER.SALES_SELLING_LOCATION= TRANS.SALES_SELLING_LOCATION AND "
			+ " HEADER.SALES_TERMINAL_NUMBER =TRANS.SALES_TERMINAL_NO AND "
			+ " HEADER.SALES_TRANSACTION_NUMBER = TRANS.SALES_TRANSACTION_NUMBER AND "
			+ " TRANS.SALES_SKU_DUTY_TYPE = '2' AND HEADER.SALES_TRANSACTION_TYPE ='S' AND "
			+ " HEADER.SALES_REKEY_TRANSACTION <> 'Y' AND HEADER.PAX_SEQ_ID=MSTR.PAX_SEQ_ID"
			+ " AND  SALES_SKU_DEPARTMENT = ? AND MSTR.PAX_PAX_NO = ? "
			+ " GROUP BY(SALES_SKU_NUM, SALES_SKU_DESCRIPTION)  ORDER BY SALES_SKU_NUM ";

	public static final String PAX_DF_PURCHASE_ENQUIRY =
		"{call BT_PAX_DF_PURCHASE_ENQUIRY(?,?,?,?,?,?,?,?,?,?)}";

	public static final String PAX_DP_PURCHASE_ENQUIRY =
		"{call BT_PAX_DP_PURCHASE_ENQUIRY(?,?)}";

	//Holds query to update visit master to start the visit
	public static final String UPDATE_START_VISIT =
		/*"UPDATE TB_VISIT_MSTR SET ACTUAL_VISIT_DATE = CURRENT DATE,"
			+ "ACTUAL_VISIT_TIME = CURRENT TIME,ACTUAL_NO_OF_PAX = ?,MODIFIED_BY "
			+ "= ?,MODIFIED_DATE = CURRENT TIMESTAMP,VISIT_STATUS = 'Y' WHERE VISIT_CODE = ?";
		*/
		/*added for CR695 on 02-oct-2008 begin*/
			"UPDATE TB_VISIT_MSTR SET ACTUAL_VISIT_DATE = CURRENT DATE,"
				+ "ACTUAL_VISIT_TIME = ?,ACTUAL_NO_OF_PAX = ?,MODIFIED_BY "
				+ "= ?,MODIFIED_DATE = CURRENT TIMESTAMP,VISIT_STATUS = 'Y' WHERE VISIT_CODE = ?";
	/*added for CR695 on 02-oct-2008 end*/
		
	public static final String APPROVE_PAX = "{call BT_APPROVE_PAX(?,?)}";

	public static final String REJECT_PAX = "{call BT_REJECT_PAX(?,?)}";

	public static final String SELECT_TRAVEL_AGENT_CODE =
		"SELECT TA_CODE, TA_AGENCY_NAME FROM TB_TA_MSTR WHERE TA_ACTIVE='Y' ORDER BY TA_AGENCY_NAME";

	public static final String SELECT_TRAVEL_AGENT_BRANCH =
		"SELECT TA_BRANCH_CODE, TA_BRANCH_NAME FROM TB_TA_BRANCH_MSTR "
			+ "WHERE TA_BRANCH_ACTIVE='Y' AND TA_CODE=? ORDER BY TA_BRANCH_NAME";

	public static final String GET_PAX_DETAILS =
		"SELECT PAX_SEQ_ID, PAX_PAX_NO, PAX_L_NAME,  "
			+ " PAX_F_NAME, FLIGHT_DEPT_AIRLINE_REF_ID, FLIGHT_DEPT_AIRLINE_CODE_ID, "
			+ " CODE_CODE_VALUE,FLIGHT_DEPT_FLIGHT_NUMBER, FLIGHT_DEPT_DATE "
			+ " FROM TB_PAX_MSTR PM INNER JOIN TB_CODE_REF CR ON VARCHAR(FLIGHT_DEPT_DATE)= ? AND  "
			+ " PM.FLIGHT_DEPT_AIRLINE_REF_ID = CR.REF_ID AND PM.FLIGHT_DEPT_AIRLINE_CODE_ID = CR.CODE_CODE_ID ";

	public static final String GET_PAX_APPROVE_STATUS =
		"{call BT_PARALELLING_REPORT(?,?,?,?,?,?,?,?)}";

	public static final String CHECK_PAX =
		"SELECT COUNT(PAX_SEQ_NO) FROM TB_COND_PAX_VISIT WHERE VISIT_CODE = ? "
			+ "AND PAX_SEQ_NO = ?";

	public static final String GET_DIVISION_NUMBER =
		"SELECT DIVISION_NUMBER FROM TB_DIVISION FETCH FIRST 1 ROWS ONLY";

	public static final String LTS_TRIP_DETAILS_QUERY =
		"SELECT BAGMSTR.SALES_SELLING_LOCATION, BAGMSTR.SALES_TERMINAL_NUMBER,  BAGMSTR.SALES_TRANSACTION_NUMBER , "
			+ " HEADER.SALES_TRANSACTION_DATE,HEADER.SALES_TRANSACTION_TIME ,  SUM(TRANS.SALES_SKU_QTY) AS SALESQTY,BAGSTATUSHISTORY.TRUCK_NO, "
			+ " DATE(LTSSTATUS.TRANSFER_TIMESTAMP) AS TRANSFERDATE,  "
			+ " TIME(LTSSTATUS.TRANSFER_TIMESTAMP)AS TRANSFERTIME, "
			+ " (SELECT SHIFT_CODE_CODE_ID  FROM TB_BT_MODULE_MSTR MODULE,TB_CODE_REF WHERE MODULE.MODULE_ID = BAGSTATUSHISTORY.BAG_MODULE AND CODE_CODE_ID =SHIFT_CODE_CODE_ID AND SHIFT_REF_ID =REF_ID) AS SHIFTCODE, "
			+ " (SELECT CODE_CODE_VALUE FROM TB_BT_MODULE_MSTR MODULE,TB_CODE_REF WHERE MODULE.MODULE_ID =BAGSTATUSHISTORY.BAG_MODULE AND CODE_CODE_ID =SHIFT_CODE_CODE_ID AND SHIFT_REF_ID =REF_ID)AS SHIFTVALUE,"
			+ " (SELECT CODE_TO_FLAG FROM TB_BT_MODULE_MSTR MODULE,TB_CODE_REF WHERE MODULE.MODULE_ID =BAGSTATUSHISTORY.BAG_MODULE AND CODE_CODE_ID =PICKUP_LOC_CODE_CODE_ID AND PICKUP_LOC_REF_ID =REF_ID)AS INTERNATIONAL, "
			+ " LTSSTATUS.TRIP_ID FROM TB_TRIP_LTS_STATUS  LTSSTATUS,TB_BAG_STATUS_HISTORY BAGSTATUSHISTORY,  TB_BAG_MSTR BAGMSTR,TB_SALES_HEADER_DATA HEADER,TB_SALES_TRANS_DATA TRANS "
			+ " WHERE  LTSSTATUS.TRIP_ID =BAGSTATUSHISTORY.TRIP_ID AND BAGMSTR.BAG_NO = BAGSTATUSHISTORY.BAG_NO AND BAGSTATUSHISTORY .STATUS_ID IN(7,19) AND  BAGMSTR.SALES_SELLING_LOCATION = HEADER.SALES_SELLING_LOCATION "
			+ " AND  BAGMSTR.SALES_TERMINAL_NUMBER =HEADER.SALES_TERMINAL_NUMBER AND   BAGMSTR.SALES_TRANSACTION_NUMBER =HEADER.SALES_TRANSACTION_NUMBER AND "
			+ " TRANS.SALES_SELLING_LOCATION = HEADER.SALES_SELLING_LOCATION AND "
			+ " TRANS.SALES_TERMINAL_NO =HEADER.SALES_TERMINAL_NUMBER AND TRANS.SALES_TRANSACTION_NUMBER = HEADER.SALES_TRANSACTION_NUMBER AND LTSSTATUS.LTS_STATUS ='N' "
			+ " GROUP BY (LTSSTATUS.TRANSFER_TIMESTAMP, "
			+ " LTSSTATUS.TRIP_ID,BAGMSTR.BAG_NO, BAGMSTR.SALES_SELLING_LOCATION  , BAGMSTR.SALES_TERMINAL_NUMBER, BAGMSTR.SALES_TRANSACTION_NUMBER ,HEADER.SALES_TRANSACTION_DATE,HEADER.SALES_TRANSACTION_TIME, "
			+ " BAGSTATUSHISTORY.BAG_MODULE,BAGSTATUSHISTORY.TRUCK_NO) ";

	public static final String LTS_TRIPID_UPDATE_QUERY =
		" UPDATE TB_TRIP_LTS_STATUS set LTS_STATUS='Y' WHERE TRIP_ID = ? ";

	public static final String SPEND_LIMIT_QUERY =
		" SELECT LOCATION_SPND_LIMIT_TR FROM TB_LOCATION WHERE LOCATION_ID=? ";

	public static final String GET_START_VISIT_TIME =
		"SELECT START_VISIT_TIME FROM TB_PAXTRAX_CONTROL_PARMS";

	public static final String SELECT_NET_SALES_AMOUNT_FOR_AIRPORT_LOCATION =
		"SELECT  SUM( STD.SALES_SKU_ACTUAL_PRICE) FROM TB_SALES_TRANS_DATA STD,TB_SALES_HEADER_DATA header,"
			+ " TB_PAX_MSTR mstr WHERE STD.SALES_SELLING_LOCATION =header.SALES_SELLING_LOCATION AND "
			+ "	std.SALES_TERMINAL_NO =header.SALES_TERMINAL_Number and std.SALES_TRANSACTION_NUMBER =header.SALES_TRANSACTION_NUMBER and "
			+ " header.PAX_SEQ_ID =mstr.PAX_SEQ_ID and MONTH(mstr.FLIGHT_DEPT_DATE)= ? and "
			+ " header.SALES_REPORT_GROUP= ? "
			+ " AND header.SALES_TRANSACTION_STATUS >? "
			+ " AND std.SALES_SKU_DUTY_TYPE= ? ";

	public static final String SELECT_DUTY_FREE_NACCS_FILE_NAME =
		" select distinct hdr.naccs_file_name from tb_naccs_file_hdr hdr ,"
			+ " tb_naccs_file_detail detail where hdr.naccs_file_name =detail.naccs_file_name and "
			+ " detail.sales_selling_location=?  and month(naccs_departure_date) = ? ";

	public static final String SELECT_ALL_LOCATIONS =
		"SELECT LOCATION_ID, LOCATION_DESC FROM TB_LOCATION WHERE LOCATION_ID !=999";

	public static final String SELECT_PAX_BY_FLIGHT =
		"select pax_seq_id,pax_pax_no,pax_l_name,pax_f_name "
			+ " from tb_pax_mstr where FLIGHT_DEPT_AIRLINE_REF_ID='8' "
			+ " AND FLIGHT_DEPT_AIRLINE_CODE_ID=? AND "
			+ " FLIGHT_DEPT_FLIGHT_NUMBER =? AND   VARCHAR(FLIGHT_DEPT_DATE)=? ";

	public static final String MASS_FLIGHT_CHANGE =
		"{call MASS_FLIGHT_CHANGE(?,?,?,?,?,?,?)}";

	public static final String PASS_VALIDATE_TA =
		"{ CALL PAS_UPLOAD_VALIDATE_TA(?,?,?,?,?,?) } ";

	public static final String SELECT_DUTY_PAID_CONSUMPTION_FOR_MONTH =
		" select sum(trans.sales_tax_amount1),sum(trans.sales_sku_actual_price) from tb_sales_trans_data trans,tb_sales_header_data header,tb_pax_mstr mstr "
			+ " where MONTH(header.SALES_TRANSACTION_BUSINESS_DAT) =? and mstr.pax_seq_id=header.pax_seq_id and header.sales_report_group=? and trans.sales_sku_duty_type='2' and "
			+ " header.sales_selling_location=trans.sales_selling_location and "
			+ " trans.sales_terminal_no=header.sales_terminal_number and "
			+ " trans.sales_transaction_number =header.sales_transaction_number ";

	public static final String SELECT_GROSS_DUTY_PAID_SALES_FOR_MONTH =
		"SELECT SUM(PT.SALES_TOTAL_DUTY_PAID) FROM "
			+ " TB_PAX_TOTAL PT WHERE PT.PAX_SEQ_ID IN "
			+ " (SELECT PAX_SEQ_ID FROM TB_PAX_MSTR WHERE MONTH(FLIGHT_DEPT_DATE)=?) "
			+ " AND PT.SELLING_LOCATION= ? ";

	public static final String GET_TA_FILE_HEADER_DETAILS =
		" SELECT FILE_ENCRYPTION_TYPE, DELIMITED_FILE, DETAILS_DELIMITER_USED, "
			+ " HEADER_PRESENT, HEADER_DELIMITED, HEADER_DELIMITER_USED, FOOTER_PRESENT, "
			+ " FOOTER_DELIMITED, FOOTER_DELIMITER_USED, DATE_FORMAT, DETAIL_ROW_INDICATOR, HEADER_ROW_INDICATOR, "
			+ " FOOTER_ROW_INDICATOR,AIRLINE_VALUE_REFERRED_TO,LOCAL_DEST_FOLDER,PAX_RECORD_LOG_FOLDER FROM TB_TA_FILE_MSTR WHERE TA_CODE= ? ";
	public static final String GET_TA_FIELD_DETAILS =
		"SELECT FIELD_CODE_ID, START_INDEX_POSITION, END_POSITION, "
			+ " LENGTH FROM TB_TA_FILE_DETAILS WHERE TA_CODE= ? AND LINE_TYPE= ? ORDER BY START_INDEX_POSITION";

	public static final String GET_TA_FILE_DESCRIPTION =
		"SELECT FIELD_CODE_ID, FIELD_DESCRIPTION FROM TB_TA_FILE_FIELDS ";

	public static final String COMMTRAX_FTP_LOCATION =
		" SELECT COMMTRAX_FTP_LOCATION,COMMTRAX_GEN_LOCATION FROM TB_COMMTRAX_PARAM ";

	public static final String PAS_UPLOAD_PAX =
		"{ CALL PAS_UPLOAD_PAX(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) } ";

	public static final String DELETE_GROUP =
		"DELETE FROM TB_GROUP_MSTR WHERE " + "GROUP_SEQ_ID = ?";

	public static final String GET_GROUP_NO_PAX =
		"SELECT COUNT(GROUP_SEQ_ID) "
			+ "FROM TB_GROUP_MSTR WHERE visit_code = ? AND start_pax_no is null";

	public static String UPDATE_VISIT =
		"UPDATE TB_VISIT_MSTR SET EXP_NO_OF_PAX "
			+ "= ?,MODIFIED_BY = ?,MODIFIED_DATE = CURRENT TIMESTAMP WHERE "
			+ "VISIT_CODE = ? AND EXP_NO_OF_PAX < ?";

	public static String SALES_TENDER_REPORT =
		" select tmp.*, mstr.TENDER_DESCRIPTION from (SELECT sum(B.SALES_LOCAL_AMOUNT), B.SALES_TENDER_CODE,"
			+ " A.SALES_TRANSACTION_TYPE from  TB_SALES_HEADER_DATA A, TB_SALES_PAYMENT_DETAIL B "
			+ " where A.SALES_SELLING_LOCATION = B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NUMBER and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ "(A.SALES_TRANSACTION_TYPE ='S' ) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and  ?  and SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ " Group By B.SALES_TENDER_CODE,A.SALES_TRANSACTION_TYPE "
			+ " union  all "
			+ " SELECT sum(B.SALES_LOCAL_AMOUNT), B.SALES_TENDER_CODE,A.SALES_TRANSACTION_TYPE "
			+ " from  TB_SALES_HEADER_DATA A, TB_SALES_PAYMENT_DETAIL B "
			+ " where A.SALES_SELLING_LOCATION = B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NUMBER and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " (A.SALES_TRANSACTION_TYPE ='P'  or  A.SALES_TRANSACTION_TYPE ='F' ) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and  ?  and SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ " Group By B.SALES_TENDER_CODE,A.SALES_TRANSACTION_TYPE)tmp,TB_TENDER_MSTR mstr where mstr.TENDER_CODE = tmp.SALES_TENDER_CODE order by tmp.SALES_TENDER_CODE ";

	public static String SALES_TENDER_REPORT_ALL_LOCATIONS =
		" select tmp.* ,mstr.TENDER_DESCRIPTION from (SELECT sum(B.SALES_LOCAL_AMOUNT), B.SALES_TENDER_CODE,"
			+ " A.SALES_TRANSACTION_TYPE from  TB_SALES_HEADER_DATA A, TB_SALES_PAYMENT_DETAIL B "
			+ " where A.SALES_SELLING_LOCATION = B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NUMBER and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ "(A.SALES_TRANSACTION_TYPE ='S' ) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and  ?   "
			+ " Group By B.SALES_TENDER_CODE,A.SALES_TRANSACTION_TYPE "
			+ " union  all "
			+ " SELECT sum(B.SALES_LOCAL_AMOUNT), B.SALES_TENDER_CODE,A.SALES_TRANSACTION_TYPE "
			+ " from  TB_SALES_HEADER_DATA A, TB_SALES_PAYMENT_DETAIL B "
			+ " where A.SALES_SELLING_LOCATION = B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NUMBER and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " (A.SALES_TRANSACTION_TYPE ='P'  or  A.SALES_TRANSACTION_TYPE ='F' ) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and  ?   "
			+ " Group By B.SALES_TENDER_CODE,A.SALES_TRANSACTION_TYPE)tmp,TB_TENDER_MSTR mstr where mstr.TENDER_CODE = tmp.SALES_TENDER_CODE order by tmp.SALES_TENDER_CODE ";

	public static String SELECT_DUTY_FREE_SALE_FOR_LEASED_VENDOR1 =
		"select sum(sales_transaction_net_amount) from tb_sales_header_data hd, tb_sales_trans_data td, tb_pax_mstr pm where "
			+ "pm.pax_seq_id=hd.pax_seq_id "
			+ " and hd.sales_selling_location=td.sales_selling_location "
			+ " and hd.sales_terminal_number = td.sales_terminal_no "
			+ " and hd.sales_transaction_number = td.sales_transaction_number "
			+ " and hd.sales_transaction_status > '2' "
			+ " and td.sales_sku_duty_type='1' "
			+ " and month(pm.flight_dept_date) = ";

	public static String SELECT_DUTY_FREE_SALE_FOR_LEASED_VENDOR2 =
		" and hd.sales_terminal_number in ";

	public static String SELECT_DUTY_FREE_NACCS_FILE_NAME_FOR_LEASED_VENDOR1 =
		"select hdr.naccs_file_name,detail.ITEM,detail.QTY, "
			+ "detail.NACCS_UNIT_PRICE,detail.TARIFF_IDENTIFIER, "
			+ "detail.SALES_SELLING_LOCATION,detail.SALES_TERMINAL_NO, "
			+ "skuMstr.DIVISION_NUMBER,skuMstr.SIZE, skuMstr.TAX_ALCOHOL_STRENGTH, "
			+ "skuMstr.TAX_TYPE, skuMstr.HARMONIZE_CODE   from tb_naccs_file_hdr hdr ,TB_SKU_MSTR skuMstr,  "
			+ "tb_naccs_file_detail detail where hdr.naccs_file_name =detail.naccs_file_name "
			+ "and detail.sales_selling_location in "
			+ "(select sales_selling_location from TB_SALES_HEADER_DATA where "
			+ "sales_report_group= 630) and month(naccs_departure_date) =";

	public static String SELECT_DUTY_FREE_NACCS_FILE_NAME_FOR_LEASED_VENDOR2 =
		" and detail.ITEM = skuMstr.sku_number and detail.sales_terminal_no in ";

	public static String SELECT_DUTY_FREE_NACCS_FILE_NAME_FOR_LEASED_VENDOR3 =
		" order by detail.sales_selling_location";

	public static String SELECT_DUTY_PAID_SALE_FOR_LEASED_VENDOR1 =
		"select sum(trans.sales_tax_amount1),sum(trans.sales_sku_actual_price) from tb_sales_trans_data trans,tb_sales_header_data header,tb_pax_mstr mstr  "
			+ "where MONTH(header.SALES_TRANSACTION_BUSINESS_DAT) = ";

	public static String SELECT_DUTY_PAID_SALE_FOR_LEASED_VENDOR2 =
		" and mstr.pax_seq_id=header.pax_seq_id and header.sales_report_group=630 and trans.sales_sku_duty_type='2' and  "
			+ "header.sales_selling_location=trans.sales_selling_location and  "
			+ "trans.sales_terminal_no=header.sales_terminal_number and  "
			+ "trans.sales_transaction_number =header.sales_transaction_number  "
			+ "and trans.sales_terminal_no in ";

	public static String SELECT_VENDOR_DETAILS =
		"select TERMINAL_NUMBER VMAP, VENDOR_DESC VMSTR FROM TB_LEASED_VENDOR_MSTR VMSTR, "
			+ "TB_LEASED_VENDOR_TERMINAL_MAP VMAP "
			+ "WHERE VMAP.VENDOR_ID=VMSTR.VENDOR_ID";

	public static String SELECT_VENDOR_ID =
		"select vendor_id from TB_LEASED_VENDOR_MSTR";

	public static String SELECT_VENDOR_DETAIL =
		"select TERMINAL_NUMBER, VENDOR_DESC from TB_LEASED_VENDOR_TERMINAL_MAP VMAP, TB_LEASED_VENDOR_MSTR VMSTR where VMAP.VENDOR_ID=VMSTR.VENDOR_ID "
			+ "and VMSTR.VENDOR_ID=";

	public static final String SALES_TERMINAL_REPORT_PROCEDURE =
		"{ CALL SALES_REPORT_BY_TERMINAL(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) } ";

	public static final String INSERT_LOG_LOC =
		"INSERT INTO "
			+ "TB_MAP_LOGICAL_LOCATION(LOGICAL_LOCATION_ID,LOCATION_ID,"
			+ "LOGICAL_LOCATION_DESC) VALUES(?,?,?)";

	public static final String getFTPDetails =
		"Select T.TA_CODE, t.FTP_LOCATION_IP,t.FTP_LOCATION_PORT,t.FTP_USER_ID,T.FTP_USER_PASSWORD,t.FTP_SRC_FOLDER ,t.LOCAL_DEST_FOLDER from TB_TA_FILE_MSTR t";

	public static final String GET_LOGICAL_LOCATION =
		"SELECT LOGICAL_LOCATION_ID,LOCATION_ID,LOGICAL_LOCATION_DESC from "
			+ "TB_MAP_LOGICAL_LOCATION where LOGICAL_LOCATION_ID NOT IN(SELECT "
			+ "LOCATION_ID from TB_LOCATION)";

	public static final String DELETE_LOG_LOC =
		"DELETE FROM "
			+ "TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?";

	public static final String SALES_ASSOCIATE_USER_DETAILS =
		" SELECT USER_USER_ID,USER_F_NAME, USER_L_NAME from TB_USER_MSTR ";

	/***public static final String SALES_ASSOCIATE_REPORT =
		"SELECT DISTINCT(SALES_SALES_ASSOCIATE_ID) AS ASSOCIATE_ID from TB_SALES_HEADER_DATA where TB_SALES_HEADER_DATA.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
			+ " VARCHAR(SALES_TRANSACTION_BUSINESS_DAT) between ? and ? group by SALES_SALES_ASSOCIATE_ID";
	***/

	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_REPORT =
		"SELECT DISTINCT(SALES_SALES_ASSOCIATE_ID)"
			+ "from TB_SALES_HEADER_DATA "
			+ "where TB_SALES_HEADER_DATA.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
			+ "VARCHAR(SALES_TRANSACTION_BUSINESS_DAT) between ? and ? "
			+ "UNION "
			+ "SELECT DISTINCT(SALES_SALES_ASSOCIATE_ID) from TB_SALES_HEADER_DATA "
			+ "where(SALES_SELLING_LOCATION,SALES_TERMINAL_NUMBER,SALES_TRANSACTION_NUMBER) "
			+ "in (SELECT SALES_ORIG_SELLING_LOC_NUMBER,SALES_ORIG_TERMINAL_NUMBER,SALES_ORIG_TRANSACTION_NUMBER from TB_SALES_HEADER_DATA "
			+ "where sales_transaction_type in ('P','F') and VARCHAR(SALES_TRANSACTION_BUSINESS_DAT) between ? and ?) and SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ "group by SALES_SALES_ASSOCIATE_ID";

	/* -- Commented as a part of the change request to attribute refunds to the original sales associate
	public static final String SALES_ASSOCIATE_SALES =
		"SELECT SALES_SALES_ASSOCIATE_ID,SUM(case  when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_TRANSACTION_NET_AMOUNT ELSE 0 END), "
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN ('P' , 'F') then A.SALES_TRANSACTION_NET_AMOUNT ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A "
			+ " where   "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? group by SALES_SALES_ASSOCIATE_ID ";
	*/

	//-- The changed query added on May 9, 2005
	/***public static final String SALES_ASSOCIATE_SALES =
		"SELECT (case  when A.SALES_TRANSACTION_TYPE = 'S'  then A.SALES_SALES_ASSOCIATE_ID  ELSE  A.SALES_ORIG_SALES_ASSOCIATE  END) "
			+ ",SUM(case when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_TRANSACTION_NET_AMOUNT ELSE 0 END), "
			+ " SUM(case when A.SALES_TRANSACTION_TYPE IN ('P' , 'F') then A.SALES_TRANSACTION_NET_AMOUNT ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A "
			+ " where   "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
				+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? group by (case when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_SALES_ASSOCIATE_ID ELSE A.SALES_ORIG_SALES_ASSOCIATE END)";
	  ***/

	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_SALES =
		"SELECT A.SALES_SALES_ASSOCIATE_ID,SUM( A.SALES_TRANSACTION_NET_AMOUNT )"
			+ "from TB_SALES_HEADER_DATA A where "
			+ "A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and A.SALES_TRANSACTION_TYPE ='S' "
			+ "and VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? "
			+ "group by  A.SALES_SALES_ASSOCIATE_ID";

	/***public static final String SALES_ASSOCIATE_REFUND =
		"SELECT SALES_SALES_ASSOCIATE_ID,SUM(A.SALES_TRANSACTION_NET_AMOUNT) "
			+ " from TB_SALES_HEADER_DATA A "
			+ " where A.SALES_TRANSACTION_TYPE IN ('P' , 'F')  and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? group by SALES_SALES_ASSOCIATE_ID ";
	***/

	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_REFUND =
		"SELECT SALES_SALES_ASSOCIATE_ID,-SUM(SALES_TRANSACTION_NET_AMOUNT) from TB_SALES_HEADER_DATA "
			+ "where(SALES_SELLING_LOCATION,SALES_TERMINAL_NUMBER,SALES_TRANSACTION_NUMBER) "
			+ "in (SELECT SALES_ORIG_SELLING_LOC_NUMBER,SALES_ORIG_TERMINAL_NUMBER,SALES_ORIG_TRANSACTION_NUMBER from TB_SALES_HEADER_DATA "
			+ "where sales_transaction_type in ('P','F') and VARCHAR(SALES_TRANSACTION_BUSINESS_DAT) between ? and ?) and SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ "group by SALES_SALES_ASSOCIATE_ID";

	/* -- Commented as a part of the change request to attribute refunds to the original sales associate
	public static final String SALES_ASSOCIATE_DISCOUNT_SALES =
		" SELECT SALES_SALES_ASSOCIATE_ID,SUM(case  when A.SALES_TRANSACTION_TYPE = 'S' then B.SALES_DISCOUNT_AMOUNT ELSE 0 END), "
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN ('P' , 'F') then B.SALES_DISCOUNT_AMOUNT ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ " where  "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by SALES_SALES_ASSOCIATE_ID ";
	*/

	//The changed query added on May 9, 2005
	/***public static final String SALES_ASSOCIATE_DISCOUNT_SALES =
		" SELECT (case when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_SALES_ASSOCIATE_ID ELSE A.SALES_ORIG_SALES_ASSOCIATE  END) "
			+ ",SUM(case when A.SALES_TRANSACTION_TYPE = 'S' then B.SALES_DISCOUNT_AMOUNT ELSE 0 END), "
			+ " SUM(case when A.SALES_TRANSACTION_TYPE IN ('P', 'F') then B.SALES_DISCOUNT_AMOUNT ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ " where  "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by (case when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_SALES_ASSOCIATE_ID ELSE A.SALES_ORIG_SALES_ASSOCIATE END) ";
	 ***/

	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_DISCOUNT_SALES =
		"SELECT  A.SALES_SALES_ASSOCIATE_ID,SUM(B.SALES_DISCOUNT_AMOUNT )"
			+ "from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ "where "
			+ "A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ "A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ "A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ "VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ "A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and sales_transaction_type='S' "
			+ "group by A.SALES_SALES_ASSOCIATE_ID";

	/***public static final String SALES_ASSOCIATE_DISCOUNT_REFUND =
		" SELECT SALES_SALES_ASSOCIATE_ID,SUM(B.SALES_DISCOUNT_AMOUNT) from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ " where A.SALES_TRANSACTION_TYPE IN ('P' , 'F') and "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by SALES_SALES_ASSOCIATE_ID ";
	 ***/
	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_DISCOUNT_REFUND =
		"SELECT A.SALES_SALES_ASSOCIATE_ID,-SUM(B.SALES_DISCOUNT_AMOUNT) "
			+ "from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ "where "
			+ "A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ "A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ "A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ "(A.SALES_SELLING_LOCATION,A.SALES_TERMINAL_NUMBER,A.SALES_TRANSACTION_NUMBER) "
			+ "in (select SALES_ORIG_SELLING_LOC_NUMBER,SALES_ORIG_TERMINAL_NUMBER,SALES_ORIG_TRANSACTION_NUMBER from TB_SALES_HEADER_DATA "
			+ "where sales_transaction_type in ('P','F') and VARCHAR(SALES_TRANSACTION_BUSINESS_DAT) between ? and ?) and A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ "group by A.SALES_SALES_ASSOCIATE_ID";

	/* -- Commented as a part of the change request to attribute refunds to the original sales associate
	public static final String SALES_ASSOCIATE_QTY_SALES =
		" SELECT A.SALES_SALES_ASSOCIATE_ID,SUM(case  when A.SALES_TRANSACTION_TYPE = 'S' then B.SALES_SKU_QTY ELSE 0 END), "
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN ('P' , 'F') then B.SALES_SKU_QTY ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A, TB_SALES_TRANS_DATA B "
			+ " where "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by A.SALES_SALES_ASSOCIATE_ID ";
	*/

	//Changed query added on May 9, 2005
	/***public static final String SALES_ASSOCIATE_QTY_SALES =
		" SELECT (case when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_SALES_ASSOCIATE_ID  ELSE  A.SALES_ORIG_SALES_ASSOCIATE  END) "
			+ ",SUM(case when A.SALES_TRANSACTION_TYPE = 'S' then B.SALES_SKU_QTY ELSE 0 END), "
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN ('P' , 'F') then B.SALES_SKU_QTY ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A, TB_SALES_TRANS_DATA B "
			+ " where "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by (case when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_SALES_ASSOCIATE_ID ELSE A.SALES_ORIG_SALES_ASSOCIATE  END) ";
	 ***/

	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_QTY_SALES =
		"SELECT  A.SALES_SALES_ASSOCIATE_ID ,SUM(B.SALES_SKU_QTY) "
			+ "from TB_SALES_HEADER_DATA A,TB_SALES_TRANS_DATA B "
			+ "where "
			+ "A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ "A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ "A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ "A.SALES_TRANSACTION_TYPE='S' and "
			+ "VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ "A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ "group by A.SALES_SALES_ASSOCIATE_ID";

	/***public static final String SALES_ASSOCIATE_QTY_REFUND =
		" SELECT A.SALES_SALES_ASSOCIATE_ID,SUM(B.SALES_SKU_QTY) from TB_SALES_HEADER_DATA A, TB_SALES_TRANS_DATA B "
			+ " where A.SALES_TRANSACTION_TYPE IN ('P' , 'F') and "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by A.SALES_SALES_ASSOCIATE_ID  ";
	 ***/

	//-- Code added on Mar 10,2006.Code change to fix the Sales By Sales Associate Report
	public static final String SALES_ASSOCIATE_QTY_REFUND =
		"SELECT  A.SALES_SALES_ASSOCIATE_ID,SUM(B.SALES_SKU_QTY) "
			+ "from TB_SALES_HEADER_DATA A,TB_SALES_TRANS_DATA B "
			+ "where "
			+ "A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ "A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ "A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ "(A.SALES_SELLING_LOCATION,A.SALES_TERMINAL_NUMBER,A.SALES_TRANSACTION_NUMBER) "
			+ "in (select SALES_ORIG_SELLING_LOC_NUMBER,SALES_ORIG_TERMINAL_NUMBER,SALES_ORIG_TRANSACTION_NUMBER from TB_SALES_HEADER_DATA "
			+ "where sales_transaction_type in ('P','F') and VARCHAR(SALES_TRANSACTION_BUSINESS_DAT) between ? and ?) and A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ "group by A.SALES_SALES_ASSOCIATE_ID ";

	public static final String SALES_ASSOCIATE_UNIT =
		" SELECT SALES_SALES_ASSOCIATE_ID, COUNT(*) from TB_SALES_HEADER_DATA A "
			+ " where VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?)group by SALES_SALES_ASSOCIATE_ID ";

	public static final String SALES_ASSOCIATE_TICKET_SPENDING =
		" SELECT SALES_SALES_ASSOCIATE_ID, COUNT(*) from TB_SALES_HEADER_DATA A "
			+ " where VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_TRANSACTION_TYPE = 'S' and"
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?)group by SALES_SALES_ASSOCIATE_ID ";

	public static final String SALES_DEPARTMENT_REPORT_PROC =
		"{call SALES_REPORT_FOR_DEPARTMENTS(?,?,?,?,?,?)}";

	public static String SALES_TERMINAL_REPORT =
		" select SALES_TERMINAL_NUMBER, sum(SALES_TRANSACTION_NET_AMOUNT) from tb_sales_header_data where SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ " and VARCHAR(SALES_TRANSACTION_DATE) between ?  and  ?  "
			+ " group by sales_terminal_number ";

	public static String SALES_REPORT_BY_TERMINAL =
		" select SALES_TERMINAL_NUMBER from tb_sales_header_data where SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) "
			+ " and VARCHAR(SALES_TRANSACTION_DATE) between ?  and  ?  ";

	public static final String SALES_TERMINAL_SALES =
		"SELECT SALES_TERMINAL_NUMBER,SUM( case  when A.SALES_TRANSACTION_TYPE = 'S' then A.SALES_TRANSACTION_NET_AMOUNT ELSE 0 END), "
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN('P','F') then A.SALES_TRANSACTION_NET_AMOUNT ELSE 0 END) "
			+ " from TB_SALES_HEADER_DATA A "
			+ " where  "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? group by SALES_TERMINAL_NUMBER ";

	public static final String SALES_TERMINAL_REFUND =
		"SELECT SALES_TERMINAL_NUMBER,SUM(A.SALES_TRANSACTION_NET_AMOUNT) "
			+ " from TB_SALES_HEADER_DATA A "
			+ " where A.SALES_TRANSACTION_TYPE IN ('P' , 'F')  and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? group by SALES_TERMINAL_NUMBER ";

	public static final String SALES_TERMINAL_DISCOUNT_SALES =
		" SELECT SALES_TERMINAL_NUMBER,SUM( case  when A.SALES_TRANSACTION_TYPE = 'S' then B.SALES_DISCOUNT_AMOUNT ELSE 0 END),"
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN('P','F') then B.SALES_DISCOUNT_AMOUNT ELSE 0 END)"
			+ " from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ " where "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by SALES_TERMINAL_NUMBER ";

	public static final String SALES_TERMINAL_DISCOUNT_REFUND =
		" SELECT SALES_TERMINAL_NUMBER,SUM(B.SALES_DISCOUNT_AMOUNT) from TB_SALES_HEADER_DATA A, TB_SALES_DISCOUNT_DETAIL B "
			+ " where A.SALES_TRANSACTION_TYPE IN ('P' , 'F') and "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by SALES_TERMINAL_NUMBER ";

	public static final String SALES_TERMINAL_QTY_SALES =
		" SELECT A.SALES_TERMINAL_NUMBER,SUM(case  when A.SALES_TRANSACTION_TYPE = 'S' then B.SALES_SKU_QTY ELSE 0 END),"
			+ " SUM(case  when A.SALES_TRANSACTION_TYPE IN('P','F') then B.SALES_SKU_QTY ELSE 0 END)"
			+ " from TB_SALES_HEADER_DATA A, TB_SALES_TRANS_DATA B "
			+ " where  "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by A.SALES_TERMINAL_NUMBER ";

	public static final String SALES_TERMINAL_QTY_REFUND =
		" SELECT A.SALES_TERMINAL_NUMBER,SUM(B.SALES_SKU_QTY) from TB_SALES_HEADER_DATA A, TB_SALES_TRANS_DATA B "
			+ " where A.SALES_TRANSACTION_TYPE IN ('P' , 'F') and "
			+ " A.SALES_SELLING_LOCATION=B.SALES_SELLING_LOCATION and "
			+ " A.SALES_TERMINAL_NUMBER = B.SALES_TERMINAL_NO and "
			+ " A.SALES_TRANSACTION_NUMBER = B.SALES_TRANSACTION_NUMBER and "
			+ " VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?) group by A.SALES_TERMINAL_NUMBER  ";

	public static final String SALES_TERMINAL_UNIT =
		" SELECT SALES_TERMINAL_NUMBER, COUNT(*) from TB_SALES_HEADER_DATA A "
			+ " where VARCHAR(A.SALES_TRANSACTION_BUSINESS_DAT) between ? and ? and "
			+ " A.SALES_REPORT_GROUP IN (SELECT LOCATION_ID FROM TB_MAP_LOGICAL_LOCATION WHERE LOGICAL_LOCATION_ID = ?)group by SALES_TERMINAL_NUMBER ";

	/* Commented as a part of the change request to make Bag Status By Flight report
	   to show the bag list in order of Last Name & First Name */
	/*public static final String GET_BAG_PAX_DETAILS =
		"SELECT  mstr.BAG_NO,pax.PAX_PAX_NO,pax.PAX_L_NAME,pax.PAX_F_NAME,"
			+ "history.STATUS_ID,ent.ENTITY_DISPLAY_STATUS,history.CARTON_NO,"
			+ "history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO,"
			+ "history.TRUCK_NO,history.AP_BIN_LOC_ID,history.created_timestamp,"
			+ "history.terminal_no,history.created_by,history.CARTON_CYCLE_ID,"
			+ "history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history,"
			+ "TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax WHERE "
			+ "mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID and FLIGHT_DEPT_AIRLINE_REF_ID = '8' "
			+ "AND FLIGHT_DEPT_AIRLINE_CODE_ID = ? AND FLIGHT_DEPT_FLIGHT_NUMBER = ?"
			+ " AND history.STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = 2 "
			+ "AND FLIGHT_DEPT_FLIGHT_TYPE = 'D' AND VARCHAR(FLIGHT_DEPT_DATE) = ? AND "
			+ " mstr.bag_no = history.bag_no and "
			+ "concat(mstr.bag_no, varchar(history.created_timestamp)) = "
			+ "(SELECT MAX(concat(history1.bag_no, varchar(history1.created_timestamp"
			+ "))) FROM TB_BAG_STATUS_HISTORY history1 WHERE history1.BAG_NO = "
			+ "mstr.BAG_NO )ORDER BY mstr.BAG_NO";*/

	public static final String GET_BAG_PAX_DETAILS =
		"SELECT  mstr.BAG_NO,pax.PAX_PAX_NO,pax.PAX_L_NAME,pax.PAX_F_NAME,"
			+ "history.STATUS_ID,ent.ENTITY_DISPLAY_STATUS,history.CARTON_NO,"
			+ "history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO,"
			+ "history.TRUCK_NO,history.AP_BIN_LOC_ID,history.created_timestamp,"
			+ "history.terminal_no,history.created_by,history.CARTON_CYCLE_ID,"
			+ "history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history,"
			+ "TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax WHERE "
			+ "mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID and FLIGHT_DEPT_AIRLINE_REF_ID = '8' "
			+ "AND FLIGHT_DEPT_AIRLINE_CODE_ID = ? AND FLIGHT_DEPT_FLIGHT_NUMBER = ?"
			+ " AND history.STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = 2 "
			+ "AND FLIGHT_DEPT_FLIGHT_TYPE = 'D' AND VARCHAR(FLIGHT_DEPT_DATE) = ? AND "
			+ " mstr.bag_no = history.bag_no and "
			+ "concat(mstr.bag_no, varchar(history.created_timestamp)) = "
			+ "(SELECT MAX(concat(history1.bag_no, varchar(history1.created_timestamp"
			+ "))) FROM TB_BAG_STATUS_HISTORY history1 WHERE history1.BAG_NO = "
			+ "mstr.BAG_NO )ORDER BY pax.PAX_L_NAME,pax.PAX_F_NAME";

	public static final String BAG_DETAILS_BY_PAX =
		" SELECT mstr.BAG_NO AS BAGNO , "
			+ " (SELECT ENTITY_DISPLAY_STATUS FROM TB_ENTITY_STATUS_MSTR WHERE ENTITY_ID=2  "
			+ " AND ENTITY_STATUS_ID=mstr.CURR_STATUS_ID) AS BAGSTATUS,history.CARTON_NO  "
			+ " AS CARTONNUMBER,history.WH_BIN_LOC_ID AS WHBIN,history.CAGE_NO AS CAGENO, "
			+ " history.shelf_no,history.TRUCK_NO AS TRUCKNO, history.AP_BIN_LOC_ID AS APBIN, "
			+ " history.created_by,history.created_timestamp ,history.terminal_no, "
			+ " history.carton_cycle_Id, history.cage_cycle_id, history.trip_id "
			+ " FROM TB_BAG_STATUS_HISTORY history,TB_BAG_MSTR mstr, TB_PAX_MSTR pax  "
			+ " WHERE pax.PAX_PAX_NO = ? AND mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID AND  "
			+ " mstr.bag_no = history.bag_no and "
			+ " concat(mstr.bag_no, varchar(history.created_timestamp)) =  "
			+ " (SELECT MAX(concat(history1.bag_no, varchar(history1.created_timestamp))) "
			+ "  FROM TB_BAG_STATUS_HISTORY history1 WHERE history1.BAG_NO =mstr.BAG_NO )ORDER BY mstr.BAG_NO ";

	/**
	 * Holds query to insert Sales Transaction Data
	 */
	public static final String SALES_INSERT_TRANS_DATA =
		"INSERT INTO TB_SALES_TRANS_DATA( SALES_SELLING_LOCATION, SALES_TERMINAL_NO,"
			+ " SALES_TRANSACTION_NUMBER, SALES_TRANSACTION_LINE_NUMBER, "
			+ " SALES_TRANSACTION_BUSINESS_DAT, SALES_SKU_NUM, SALES_SKU_DEPARTMENT, "
			+ " SALES_SKU_REGULAR_PRICE, SALES_SKU_ACTUAL_PRICE, SALES_SKU_QTY,"
			+ " SALES_SKU_PRICE_OVERRIDE, SALES_SKU_DESCRIPTION, SALES_SKU_DUTY_TYPE,"
			+ " SALES_TAX_AMOUNT1, SALES_SKU_NOT_ON_FILE, SALES_ENTERED_CODE) "
			+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Holds query to insert Sales Payment Details
	 */
	public static final String SALES_INSERT_PAYMENT_DETAIL =
		"INSERT INTO TB_SALES_PAYMENT_DETAIL( SALES_SELLING_LOCATION, "
			+ " SALES_TERMINAL_NUMBER, SALES_TRANSACTION_NUMBER, "
			+ " SALES_PAYMENT_LINE_NUMBER, SALES_TRANS_BUSINESS_DATE, "
			+ " SALES_TENDER_TYPE, SALES_TENDER_CODE, SALES_CURRENCY_CODE,"
			+ " SALES_LOCAL_AMOUNT, SALES_FOREIGN_AMOUNT, SALES_CHANGE_ROUNDING)"
			+ " VALUES(?,?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Holds query to insert Sales Discount Details
	 */
	public static final String SALES_INSERT_DISCOUNT_DETAIL =
		"INSERT INTO TB_SALES_DISCOUNT_DETAIL( SALES_SELLING_LOCATION,"
			+ " SALES_TERMINAL_NO, SALES_TRANSACTION_NUMBER,"
			+ " SALES_TRANSACTION_LINE_NUMBER, SALES_DISCOUNT_LINE_NUMBER,"
			+ " SALES_TRANS_BUSINESS_DATE, SALES_DISCOUNT_TYPE,"
			+ " SALES_DISCOUNT_CODE, SALES_DISCOUNT_AMOUNT, "
			+ " SALES_DISCOUNT_PERCENT) VALUES(?,?,?,?,?,?,?,?,?,?)";

	/**
	 * Query to check if Pax number exists in the naccs file header
	 */
	public static final String SELECT_PAX_FROM_NACCS_FILE_HDR =
		"SELECT PAX_NO FROM TB_NACCS_FILE_HDR WHERE NACCS_FILE_NAME=";

	/**
	 * Query to get TA Code and segment code
	 */
	public static final String GET_TA_SEGMENT_DETAILS =
		"SELECT ta_code, ta_segment_code FROM tb_ta_segment";

	/**
	 * Holds query to insert TA Segment Details
	 */
	public static final String INSERT_TA_SEGMENT_DETAILS =
		"INSERT INTO tb_ta_segment"
			+ "(ta_code, ta_segment_code, ta_segment_name, ta_segment_active, created_by, created_date) values(?,?,?,?,?,current timestamp)";
	public static final String UPDATE_TA_SEGMENT_DETAILS =
		"UPDATE tb_ta_segment SET ta_segment_name = ?,modified_by = ?, modified_date = current timestamp,ta_segment_active = ? WHERE ta_code = ? AND ta_segment_code =?";
	public static final String CURRENT_TIMESTAMP = "current timestamp ";

	public static final String SELECT_SEGMENT =
		"select ta_code, ta_segment_code, ta_segment_name from tb_ta_segment ";

	public static final String UPDATE_SEGMENT =
		"update tb_ta_segment set ta_segment_name=";

	public static final String DELETE_SEGMENT =
		"update tb_ta_segment set ta_segment_active='N' ";

	//Modified the query to get Remarks for CR1859
	public static final String SELECT_RAC_PREASSIGNMENT =
		"select rac_company_code, start_pax_no, end_pax_no, remarks from tb_rac_preassignment_mstr where rac_active='Y' ";

	/* Added by Vani on 06/08/2005
	 * This change was done to dynamically populate the
	 * leased vendors of a TA and to add RAC classification based commission */
	//Code addition starts here

	public static final String SELECT_TA_COUNT =
		"SELECT COUNT(TA_CODE) FROM TB_TA_COMMISSION_RATE WHERE TA_CODE = ? "
			+ "AND PURCHASE_TYPE_REF_ID = ? AND PURCHASE_TYPE_CODE_ID = ?";

		//Commented on 2006-11-08 for CommTrax Enhancement

	/* public static final String UPDATE_TA_COMMISSION =
		"UPDATE TB_TA_COMMISSION_RATE SET "
			+ "TA_CONDUCTED_ORIGINAL_RATE = ?,TA_CONDUCTED_REPEATER_RATE = ?,"
			+ "TA_NON_CONDUCTED_ORIGINAL_RATE = ?,TA_NON_CONDUCTED_REPEATER_RATE = ?,"
			+ "TA_RAC_DFS_ORIGINAL_RATE = ?,TA_RAC_DFS_REPEATER_RATE = ?,"
			+ "TA_RAC_DRIVEIN_ORIGINAL_RATE = ?,TA_RAC_DRIVEIN_REPEATER_RATE = ?,"
			+ "MODIFIED_BY = ?,MODIFIED_DATE = CURRENT DATE WHERE TA_CODE = ? "
			+ "AND PURCHASE_TYPE_REF_ID = ? AND PURCHASE_TYPE_CODE_ID = ?";
*/
			//Modified on 2006-11-08  for CommTrax Enhancement

	public static final String UPDATE_TA_COMMISSION = "UPDATE TB_TA_COMMISSION_RATE SET "
				+"TA_CONDUCTED_ORIGINAL_RATE = ?,TA_CONDUCTED_REPEATER_RATE = ?,"
				+"TA_NON_CONDUCTED_ORIGINAL_RATE = ?,TA_NON_CONDUCTED_REPEATER_RATE = ?,"
				+"TA_RAC_DRIVEIN_ORIGINAL_RATE = ?,TA_RAC_DRIVEIN_REPEATER_RATE = ?,"
				+"MODIFIED_BY = ?,MODIFIED_DATE = CURRENT DATE ,"
				+"TA_RAC_PICKUP_ORIGINAL_RATE = ? , TA_RAC_DROPOFF_ORIGINAL_RATE = ? ,"
				+"TA_RAC_DROPOFF_REPEATER_RATE = ? "
				+ "WHERE TA_CODE = ? "
				+"AND PURCHASE_TYPE_REF_ID = ? AND PURCHASE_TYPE_CODE_ID = ?";

		//Commented on 2006-11-08 for CommTrax Enhancement

/*	public static final String INSERT_TA_COMMISSION =
		"INSERT INTO TB_TA_COMMISSION_RATE"
			+ "(TA_CODE,PURCHASE_TYPE_REF_ID,PURCHASE_TYPE_CODE_ID,"
			+ "TA_CONDUCTED_ORIGINAL_RATE,TA_CONDUCTED_REPEATER_RATE,"
			+ "TA_NON_CONDUCTED_ORIGINAL_RATE,TA_NON_CONDUCTED_REPEATER_RATE,"
			+ "CREATED_BY,CREATED_DATE,"
			+ "TA_RAC_DFS_ORIGINAL_RATE ,TA_RAC_DFS_REPEATER_RATE ,"
			+ "TA_RAC_DRIVEIN_ORIGINAL_RATE ,TA_RAC_DRIVEIN_REPEATER_RATE) "
			+ "values(?,?,?,?,?,?,?,?,CURRENT DATE,?,?,?,?)";
	*/

	//Modified on 2006-11-08  for CommTrax Enhancement

public static final String INSERT_TA_COMMISSION = "INSERT INTO TB_TA_COMMISSION_RATE"
				+"(TA_CODE,PURCHASE_TYPE_REF_ID,PURCHASE_TYPE_CODE_ID,"
				+"TA_CONDUCTED_ORIGINAL_RATE,TA_CONDUCTED_REPEATER_RATE,"
				+"TA_NON_CONDUCTED_ORIGINAL_RATE,TA_NON_CONDUCTED_REPEATER_RATE,"
				+"CREATED_BY,CREATED_DATE,"
				+"TA_RAC_DRIVEIN_ORIGINAL_RATE ,TA_RAC_DRIVEIN_REPEATER_RATE,"
				+"TA_RAC_PICKUP_ORIGINAL_RATE,TA_RAC_DROPOFF_ORIGINAL_RATE,"
				+"TA_RAC_DROPOFF_REPEATER_RATE ) "
				+"values(?,?,?,?,?,?,?,?,CURRENT DATE,?,?,?,?,?)";

	public static final String GET_TA_COUNT =
		"SELECT COUNT(TA_CODE) FROM TB_TA_COMMISSION_RATE WHERE TA_CODE = ? ";

//Commented on 2006-11-08 for CommTrax Enhancement

/*	public static final String SELECT_TA_COMMISSIONS =
		"select code_code_value,TA_CONDUCTED_ORIGINAL_RATE,ta_conducted_repeater_rate,ta_non_conducted_original_rate,"
			+ "ta_non_conducted_repeater_rate,ta_rac_dfs_original_rate,ta_rac_dfs_repeater_rate,ta_rac_drivein_original_rate,ta_rac_drivein_repeater_rate,"
			+ " PURCHASE_TYPE_REF_ID, PURCHASE_TYPE_code_ID "
			+ " from tb_ta_commission_rate , tb_code_ref  where ta_code = ? and PURCHASE_TYPE_REF_ID = REF_ID and "
			+ " PURCHASE_TYPE_code_ID = code_code_ID and ref_id ='11'";
*/
	//Modified on 2006-11-08  for CommTrax Enhancement

	public static final String SELECT_TA_COMMISSIONS = "select code_code_value,TA_CONDUCTED_ORIGINAL_RATE,ta_conducted_repeater_rate,ta_non_conducted_original_rate,"
					+"ta_non_conducted_repeater_rate,ta_rac_drivein_original_rate,ta_rac_drivein_repeater_rate,"
					+" PURCHASE_TYPE_REF_ID, PURCHASE_TYPE_code_ID ,ta_rac_pickup_original_rate,ta_rac_dropoff_original_rate,ta_rac_dropoff_repeater_rate "
					+" from tb_ta_commission_rate , tb_code_ref  where ta_code = ? and PURCHASE_TYPE_REF_ID = REF_ID and "
					+" PURCHASE_TYPE_code_ID = code_code_ID and ref_id ='11'";


	public static final String SELECT_REF_NOTIN_TA_COMMISSIONS =
		"SELECT CODE_CODE_ID,CODE_CODE_VALUE,ref_id FROM TB_CODE_REF WHERE REF_ID = '11' and code_code_id not IN"
			+ "(select  PURCHASE_TYPE_CODE_ID from TB_TA_COMMISSION_RATE where PURCHASE_TYPE_REF_ID = '11' and ta_code=?)";

	/*Modified on 28th June 2006 -Starts
			SR 1042 International DF Sale */
	public static final String SELECT_SKU_TRANSFER_DETAILS1 =
		" SELECT C.SALES_SKU_NUM, C.SALES_SKU_REGULAR_PRICE, SUM(C.SALES_SKU_QTY), A.TRUCK_NO, A.TRIP_ID,(SELECT TIME(D.CREATED_TIMESTAMP) FROM TB_TRUCK_STATUS_HISTORY D WHERE D.TRIP_ID=A.TRIP_ID AND D.TRUCK_NUMBER=A.TRUCK_NO AND D.STATUS_ID=3) FROM TB_BAG_STATUS_HISTORY A, TB_BAG_MSTR B, TB_SALES_TRANS_DATA C, TB_BT_MODULE_MSTR  E , TB_CODE_REF F WHERE  A.STATUS_ID IN (7,19)  and   A.BAG_NO=B.BAG_NO AND B.SALES_SELLING_LOCATION=C.SALES_SELLING_LOCATION AND  B.SALES_TERMINAL_NUMBER=C.SALES_TERMINAL_NO AND B.SALES_TRANSACTION_NUMBER=C.SALES_TRANSACTION_NUMBER and A.BAG_MODULE = E.MODULE_ID and e.PICKUP_LOC_CODE_CODE_ID = F.CODE_CODE_ID and E.PICKUP_LOC_REF_ID=f.REF_ID and A.CREATED_TIMESTAMP BETWEEN  ";

	public static final String SELECT_SKU_TRANSFER_DETAILS2 =
		" GROUP BY C.SALES_SKU_NUM, C.SALES_SKU_REGULAR_PRICE, A.TRUCK_NO, A.TRIP_ID ORDER BY  A. TRIP_ID ";

	public static final String GROUP_SKUS_TRANSFERRED1 =
		" SELECT C.SALES_SKU_NUM, C.SALES_SKU_REGULAR_PRICE, SUM(C.SALES_SKU_QTY) FROM TB_BAG_STATUS_HISTORY A,TB_BAG_MSTR B,  TB_SALES_TRANS_DATA C,TB_BT_MODULE_MSTR D,TB_CODE_REF E WHERE   a.BAG_MODULE=D.module_id and d.PICKUP_LOC_REF_ID=e.REF_ID AND d.PICKUP_LOC_CODE_CODE_ID = e.CODE_CODE_ID and A.CREATED_TIMESTAMP BETWEEN ";

	public static final String GROUP_SKUS_TRANSFERRED2 =
		" and  A.STATUS_ID IN (7,19) AND A.BAG_NO=B.BAG_NO AND B.SALES_SELLING_LOCATION=C.SALES_SELLING_LOCATION AND B.SALES_TERMINAL_NUMBER=C.SALES_TERMINAL_NO AND B.SALES_TRANSACTION_NUMBER=C.SALES_TRANSACTION_NUMBER GROUP BY C.SALES_SKU_NUM, C.SALES_SKU_REGULAR_PRICE ";
	/*Modified on 28th June 2006 -Ends
		SR 1042 International DF Sale */

	public static final String SALES_LOCATION_REPORT =
		"select nabco_location,sum(sales_transaction_net_amount) from"
			+ " tb_sales_header_data a,tb_nabco_stores b"
			+ " where b.sales_terminal_no = a.sales_terminal_number"
			+ " and sales_on_arrival = 'Y' and sales_record_date"
			+ " between date(?) and date(?) group by nabco_location";

	public static final String TAFILE_FTP_SCHEDULER =
		"select hour(FTP_SCHEDULED_TIME),minute(FTP_SCHEDULED_TIME),second(FTP_SCHEDULED_TIME), ftp_scheduler_frequency from tb_paxtrax_control_parms ";

	//Code added on 08/12/2005
	public static final String CHECK_BAG_NUMBER =
		"SELECT SALES_SELLING_LOCATION, SALES_TERMINAL_NUMBER, SALES_TRANSACTION_NUMBER FROM TB_BAG_MSTR WHERE BAG_NO=?";

	public static final String SELECT_SALES_STATUS =
		"SELECT SALES_TRANSACTION_STATUS FROM TB_SALES_HEADER_DATA WHERE SALES_SELLING_LOCATION=? AND SALES_TERMINAL_NUMBER=? AND SALES_TRANSACTION_NUMBER=?";

	public static final String UPDATE_SALES_STATUS =
		"UPDATE TB_SALES_HEADER_DATA SET SALES_TRANSACTION_STATUS='2' WHERE SALES_SELLING_LOCATION=? AND SALES_TERMINAL_NUMBER=? AND SALES_TRANSACTION_NUMBER=?";

	public static final String SELECT_STATUS_DESC =
		"SELECT ENTITY_STATUS FROM TB_ENTITY_STATUS_MSTR WHERE ENTITY_ID = 1 AND ENTITY_STATUS_ID=?";

	/* Code added as part of SR1042 - Query to fetch the frequency and Time for the
	 * International import declaration number scheduler */

	public static final String INTL_IMPORT_DECL_SCHEDULER = "SELECT HOUR(INTL_IMPORT_DECL_TIME), MINUTE(INTL_IMPORT_DECL_TIME), SECOND(INTL_IMPORT_DECL_TIME),INTL_IMPORT_DECL_FREQ  FROM TB_PAXTRAX_CONTROL_PARMS ";

	/* Code added as part of SR1042 ends here */

	/* Added for CR 251-260 changes begin*/
	public static final String GET_BAG_STATUS_LIST= "select ENTITY_STATUS_ID,ENTITY_STATUS from TB_ENTITY_STATUS_MSTR where ENTITY_ID = ? order by ENTITY_STATUS_ID";
	
	public static final String GET_BAG_BY_BAG_STATUS1 = 
			"SELECT  mstr.BAG_NO,pax.PAX_PAX_NO,pax.PAX_L_NAME,pax.PAX_F_NAME, " 
			+ " history.STATUS_ID,ent.ENTITY_DISPLAY_STATUS,history.CARTON_NO, "
			+ " history.WH_BIN_LOC_ID,history.CAGE_NO,history.SHELF_NO, "
			+ " history.TRUCK_NO,history.AP_BIN_LOC_ID,history.created_timestamp, "
			+ " history.terminal_no,history.created_by,history.CARTON_CYCLE_ID, "
			+ " history.CAGE_CYCLE_ID,history.TRIP_ID FROM TB_BAG_STATUS_HISTORY history, "
			+ " TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax WHERE "
			+ " mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID ";
			
	public static final String GET_BAG_BY_BAG_STATUS2 = 			
			" AND history.STATUS_ID = ? "
			+ " AND history.STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = 2 "
			+ " AND FLIGHT_DEPT_FLIGHT_TYPE = 'D' AND "
			+ " mstr.bag_no = history.bag_no and "
			+ " history.created_timestamp = (select max(history1.created_timestamp) "
			+ " from TB_BAG_STATUS_HISTORY history1 where "
			+ " history1.BAG_NO=mstr.BAG_NO and mstr.CURR_STATUS_ID=history1.STATUS_ID )  "
			+ " ORDER BY pax.PAX_L_NAME,pax.PAX_F_NAME";
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL1 =
		" select temp.ds,temp.sid,count(temp.cnt) from "
			+ " (SELECT ent.ENTITY_DISPLAY_STATUS ds,CURR_STATUS_ID sid,(BAG_NO) cnt from TB_BAG_MSTR bag, "
			+ " TB_PAX_MSTR pax,TB_ENTITY_STATUS_MSTR ent,TB_FLIGHT_MSTR flight  "
			+ " where date(bag.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and " ;
				
	public static final String GET_STATUS_BAGLOCATION_TOTAL2 = 			
		" AND pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') AND pax.FLIGHT_DEPT_AIRLINE_REF_ID= "
			+ " flight.FLIGHT_AIRLINE_REF_ID and "
			+ " pax.FLIGHT_DEPT_AIRLINE_CODE_ID=flight.FLIGHT_AIRLINE_CODE_ID "
			+ " and pax.FLIGHT_DEPT_FLIGHT_NUMBER = flight.FLIGHT_FLIGHT_NUMBER and pax.FLIGHT_DEPT_FLIGHT_TYPE= "
			+ " flight.FLIGHT_type and bag.PAX_SEQ_ID = pax.PAX_SEQ_ID  AND "
			+ " bag.CURR_STATUS_ID IN (select ENTITY_STATUS_ID from TB_BAG_LOCATION where BAG_LOCATION_ID= ?)  and "
			+ " bag.CURR_STATUS_ID =ent.ENTITY_STATUS_ID and ent.ENTITY_ID =bag.BAG_ENTITY_ID " ;
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL3 = 
		"union "
// Query to fetch the bags that are refunded in Airport	Terminal 110 and 131	
			+ " SELECT ent.ENTITY_DISPLAY_STATUS ds,CURR_STATUS_ID sid,(BAG_NO) cnt "
			+ " from TB_BAG_MSTR bag,TB_PAX_MSTR pax,TB_ENTITY_STATUS_MSTR ent ,TB_SALES_HEADER_DATA sales "
			+ " where ";
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL4=
		" and sales.SALES_SELLING_LOCATION in "
			+ " (select LOCATION_ID from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.AIRPORT_STORE+"') and "
			+ " sales.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND "
			+ " sales.SALES_ORIG_SELLING_LOC_NUMBER=bag.SALES_SELLING_LOCATION AND sales.SALES_ORIG_TERMINAL_NUMBER=bag.SALES_TERMINAL_NUMBER AND "
			+ " sales.SALES_ORIG_TRANSACTION_NUMBER=bag.SALES_TRANSACTION_NUMBER  and sales.PAX_SEQ_ID=pax.PAX_SEQ_ID AND "
			+ " date(bag.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and ";
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL5= 
		" AND "
			+ " pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and bag.CURR_STATUS_ID="+PaxTraxConstants.REFUNDED_STATUS+" AND "
			+ " bag.PAX_SEQ_ID =pax.PAX_SEQ_ID AND bag.CURR_STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = bag.BAG_ENTITY_ID "
			+ " union "
// Query to fetch the bags that are refunded in Galleria but the bag is transferred to AP			
			+ " SELECT ent.ENTITY_DISPLAY_STATUS ds,bag.CURR_STATUS_ID sid,(bag.BAG_NO) cnt "
			+ "	from TB_BAG_MSTR bag,TB_PAX_MSTR pax,TB_ENTITY_STATUS_MSTR ent ,TB_SALES_HEADER_DATA sales , TB_BAG_STATUS_HISTORY history "
			+ "	where sales.SALES_SELLING_LOCATION in (select LOCATION_ID from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.GALLERIA_STORE+"') and "
			+ "	sales.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND sales.SALES_ORIG_SELLING_LOC_NUMBER=bag.SALES_SELLING_LOCATION AND "
			+ "	sales.SALES_ORIG_TERMINAL_NUMBER=bag.SALES_TERMINAL_NUMBER AND sales.SALES_ORIG_TRANSACTION_NUMBER=bag.SALES_TRANSACTION_NUMBER  and "
			+ "	sales.PAX_SEQ_ID=pax.PAX_SEQ_ID AND  date(bag.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and ";
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL6= 	
		" AND pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and "
			+ "	bag.CURR_STATUS_ID="+PaxTraxConstants.REFUNDED_STATUS+" AND bag.PAX_SEQ_ID =pax.PAX_SEQ_ID AND ";
		
	public static final String GET_STATUS_BAGLOCATION_TOTAL7= 			
		" AND history.BAG_NO =bag.BAG_NO and "
			+ " bag.CURR_STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = bag.BAG_ENTITY_ID) temp group by temp.sid,temp.ds for read only ";
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL8= 			
		 " union "
//	Query to fetch the bags that are refunded in Galleria and bag not moved to AP
			+ " SELECT ent.ENTITY_DISPLAY_STATUS ds,bag.CURR_STATUS_ID sid,(bag.BAG_NO) cnt "
			+ "	from TB_BAG_MSTR bag,TB_PAX_MSTR pax,TB_ENTITY_STATUS_MSTR ent , TB_BAG_STATUS_HISTORY history, TB_BAG_STATUS_HISTORY history1, "
			+ "	TB_SALES_HEADER_DATA sales where "
			+ " sales.SALES_SELLING_LOCATION in (select LOCATION_ID from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.GALLERIA_STORE+"') and "
			+ " sales.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND sales.SALES_ORIG_SELLING_LOC_NUMBER=bag.SALES_SELLING_LOCATION AND "
			+ " sales.SALES_ORIG_TERMINAL_NUMBER=bag.SALES_TERMINAL_NUMBER AND sales.SALES_ORIG_TRANSACTION_NUMBER=bag.SALES_TRANSACTION_NUMBER  and "
			+ "	sales.PAX_SEQ_ID=pax.PAX_SEQ_ID aND date(bag.CREATED_TIMESTAMP) >= pax.CREATED_DATE AND "; 
			
	public static final String GET_STATUS_BAGLOCATION_TOTAL9=
		" and pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') AND "
			+ " bag.CURR_STATUS_ID ="+PaxTraxConstants.REFUNDED_STATUS+" AND bag.PAX_SEQ_ID = pax.PAX_SEQ_ID AND "
			+ " history1.STATUS_ID in (select bag_status_id from "
		+ " tb_bag_status where bag_location='"+PaxTraxConstants.GALLERIA_LOCATION+"') and history1.BAG_NO not in (select distinct BH.bag_no from TB_BAG_STATUS_HISTORY BH "
			+ " where BH.STATUS_ID in (select bag_status_id from "
		+ " tb_bag_status where bag_location='"+PaxTraxConstants.AIRPORT_LOCATION+"') and BH.BAG_NO=bag.BAG_NO) "
			+ " and   bag.BAG_NO=history1.BAG_NO and bag.CURR_STATUS_ID =ent.ENTITY_STATUS_ID and bag.BAG_ENTITY_ID = ent.ENTITY_ID)temp "
			+ " group by temp.sid,temp.ds for read only";
			
	public static final String GET_BAG_STATUS_LOCATION1 = 		
		" select temp.bag,temp.pn,temp.pl,temp.pf,temp.si,temp.ds,temp.cn,temp.wb,temp.cgn,temp.sn,temp.tn,temp.ab,temp.ct,temp.trn,temp.cy, "
			+ "	temp.cid,temp.ccd,temp.ti FROM  (SELECT  mstr.BAG_NO bag,pax.PAX_PAX_NO pn,pax.PAX_L_NAME pl,pax.PAX_F_NAME pf, "
			+ "	history.STATUS_ID si,ent.ENTITY_DISPLAY_STATUS ds,history.CARTON_NO cn, history.WH_BIN_LOC_ID wb,history.CAGE_NO cgn,history.SHELF_NO sn , "
			+ "	history.TRUCK_NO tn,history.AP_BIN_LOC_ID ab,history.created_timestamp ct, history.terminal_no trn ,history.created_by cy, "
			+ "	history.CARTON_CYCLE_ID cid, history.CAGE_CYCLE_ID ccd,history.TRIP_ID ti "
			+ "	FROM TB_BAG_STATUS_HISTORY history,  TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax, tb_flight_mstr flight "
			+ "	WHERE  date(mstr.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and "; 
				
	public static final String GET_BAG_STATUS_LOCATION2 = 			
		" AND "
			+ "	pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and mstr.PAX_SEQ_ID = pax.PAX_SEQ_ID "
			+ " and pax.FLIGHT_DEPT_AIRLINE_REF_ID=flight.FLIGHT_AIRLINE_REF_ID and pax.FLIGHT_DEPT_AIRLINE_CODE_ID=flight.FLIGHT_AIRLINE_CODE_ID "
			+ "	and pax.FLIGHT_DEPT_FLIGHT_NUMBER = flight.FLIGHT_FLIGHT_NUMBER and flight.FLIGHT_type=pax.FLIGHT_DEPT_FLIGHT_TYPE "
			+ "	AND  history.STATUS_ID in (select ENTITY_STATUS_ID from TB_BAG_LOCATION  where BAG_LOCATION_ID= ?) AND "
			+ "	history.bag_no = mstr.bag_no and  history.STATUS_ID=mstr.CURR_STATUS_ID and "
			+ "	history.created_timestamp = (select max(history1.created_timestamp)  from TB_BAG_STATUS_HISTORY history1 where "
			+ "	 history1.BAG_NO=mstr.BAG_NO and mstr.CURR_STATUS_ID=history1.STATUS_ID ) and "
			+ "	history.STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = history.BAG_ENTITY_ID ";
			
	public static final String GET_BAG_STATUS_LOCATION3 = 			
		"	union "
//	Query to fetch the bags that are refunded in Airport	Terminal 110 and 131
			+ "	SELECT  mstr.BAG_NO bag,pax.PAX_PAX_NO pn,pax.PAX_L_NAME pl,pax.PAX_F_NAME pf, history.STATUS_ID si,ent.ENTITY_DISPLAY_STATUS ds, "
			+ "	history.CARTON_NO cn, history.WH_BIN_LOC_ID wb,history.CAGE_NO cgn,history.SHELF_NO sn , history.TRUCK_NO tn,history.AP_BIN_LOC_ID ab, "
			+ "	history.created_timestamp ct, history.terminal_no trn ,history.created_by cy,history.CARTON_CYCLE_ID cid, history.CAGE_CYCLE_ID ccd, "
			+ "	history.TRIP_ID ti FROM TB_BAG_STATUS_HISTORY history, "
			+ " TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax, TB_SALES_HEADER_DATA sales "
			+ "	where ";
			
	public static final String GET_BAG_STATUS_LOCATION4 =
		" and "
			+ "		sales.SALES_SELLING_LOCATION in (select LOCATION_ID from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.AIRPORT_STORE+"') and "
			+ " sales.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND sales.SALES_ORIG_SELLING_LOC_NUMBER=mstr.SALES_SELLING_LOCATION AND "
			+ "	sales.SALES_ORIG_TERMINAL_NUMBER=mstr.SALES_TERMINAL_NUMBER AND sales.SALES_ORIG_TRANSACTION_NUMBER=mstr.SALES_TRANSACTION_NUMBER  and "
			+ "	sales.PAX_SEQ_ID=pax.PAX_SEQ_ID AND date(mstr.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and ";
			
	public static final String GET_BAG_STATUS_LOCATION5 =
		" 	AND pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and "
			+ " mstr.PAX_SEQ_ID =pax.PAX_SEQ_ID and history.STATUS_ID="+PaxTraxConstants.REFUNDED_STATUS+" AND history.bag_no = mstr.bag_no AND history.STATUS_ID=mstr.CURR_STATUS_ID and "
			+ "	history.created_timestamp = (select max(history1.created_timestamp)  from TB_BAG_STATUS_HISTORY history1 where "
			+ " history1.BAG_NO=mstr.BAG_NO and mstr.CURR_STATUS_ID=history1.STATUS_ID ) and "
			+ "	history.STATUS_ID = ent.ENTITY_STATUS_ID and ent.ENTITY_ID = history.BAG_ENTITY_ID "
			+ " union "
//	Query to fetch the bags that are refunded in Galleria but the bag is transferred to AP	
			+ " SELECT  mstr.BAG_NO bag,pax.PAX_PAX_NO pn,pax.PAX_L_NAME pl,pax.PAX_F_NAME pf, history.STATUS_ID si,ent.ENTITY_DISPLAY_STATUS ds, "
			+ " history.CARTON_NO cn, history.WH_BIN_LOC_ID wb,history.CAGE_NO cgn,history.SHELF_NO sn , history.TRUCK_NO tn,history.AP_BIN_LOC_ID ab, "
			+ " history.created_timestamp ct, history.terminal_no trn ,history.created_by cy,history.CARTON_CYCLE_ID cid, history.CAGE_CYCLE_ID ccd, "
			+ " history.TRIP_ID ti FROM TB_BAG_STATUS_HISTORY history, "
			+ " TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax, TB_SALES_HEADER_DATA sales,  TB_BAG_STATUS_HISTORY history1 "
			+ "	where sales.SALES_SELLING_LOCATION in (select LOCATION_ID from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.GALLERIA_STORE+"') and "
			+ "	sales.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND sales.SALES_ORIG_SELLING_LOC_NUMBER=mstr.SALES_SELLING_LOCATION AND "
			+ " sales.SALES_ORIG_TERMINAL_NUMBER=mstr.SALES_TERMINAL_NUMBER AND sales.SALES_ORIG_TRANSACTION_NUMBER=mstr.SALES_TRANSACTION_NUMBER  and "
			+ " sales.PAX_SEQ_ID=pax.PAX_SEQ_ID AND date(mstr.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and ";
			
			
	public static final String GET_BAG_STATUS_LOCATION6 =  	
	" AND pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
		+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and "
		+ " mstr.pax_seq_id = pax.pax_seq_id and ";
		
	public static final String GET_BAG_STATUS_LOCATION7 =		
	" and history.STATUS_ID ="+PaxTraxConstants.REFUNDED_STATUS+"  and "
		+ "  history.STATUS_ID=mstr.CURR_STATUS_ID and history.BAG_NO=history1.BAG_NO and history.BAG_NO =mstr.BAG_NO and "
		+ " history.created_timestamp = (select max(history2.created_timestamp)  from TB_BAG_STATUS_HISTORY history2 where "
		+ " history2.BAG_NO=mstr.BAG_NO and mstr.CURR_STATUS_ID=history2.STATUS_ID ) and "
		+ " history.STATUS_ID = ent.ENTITY_STATUS_ID AND ent.ENTITY_ID=history.BAG_ENTITY_ID ) temp order by temp.pl,temp.pf" ;
		
		
	public static final String GET_BAG_STATUS_LOCATION8 =	
		" union "
//	Query to fetch the bags that are refunded in Galleria and bag not moved to AP
			+ " SELECT  mstr.BAG_NO bag,pax.PAX_PAX_NO pn,pax.PAX_L_NAME pl,pax.PAX_F_NAME pf,history.STATUS_ID si,ent.ENTITY_DISPLAY_STATUS ds, "
			+ " history.CARTON_NO cn, history.WH_BIN_LOC_ID wb,history.CAGE_NO cgn,history.SHELF_NO sn , history.TRUCK_NO tn, "
			+ " history.AP_BIN_LOC_ID ab,history.created_timestamp ct, history.terminal_no trn ,history.created_by cy,history.CARTON_CYCLE_ID cid, "
			+ " history.CAGE_CYCLE_ID ccd,history.TRIP_ID ti FROM TB_BAG_STATUS_HISTORY history, "
			+ "  TB_BAG_MSTR mstr, TB_entity_status_mstr ent ,TB_PAX_MSTR pax , TB_BAG_STATUS_HISTORY history1,  TB_SALES_HEADER_DATA sales "
			+ " where sales.SALES_SELLING_LOCATION in (select LOCATION_ID from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.GALLERIA_STORE+"') and "
			+ " sales.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND "
			+ " sales.SALES_ORIG_SELLING_LOC_NUMBER=mstr.SALES_SELLING_LOCATION AND "
			+ " sales.SALES_ORIG_TERMINAL_NUMBER=mstr.SALES_TERMINAL_NUMBER AND sales.SALES_ORIG_TRANSACTION_NUMBER=mstr.SALES_TRANSACTION_NUMBER  and "
			+ " sales.PAX_SEQ_ID=pax.PAX_SEQ_ID AND date(mstr.CREATED_TIMESTAMP) >= pax.CREATED_DATE  and "; 
	
	public static final String GET_BAG_STATUS_LOCATION9 =	
	" AND pax.FLIGHT_DEPT_FLIGHT_TYPE in (select code from tb_data_config where "
		+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"')  AND "  
		+ " mstr.pax_seq_id = pax.pax_seq_id and history.STATUS_ID ="+PaxTraxConstants.REFUNDED_STATUS+" and "
		+ " history.STATUS_ID=mstr.CURR_STATUS_ID and history1.STATUS_ID in (select bag_status_id from "
		+ " tb_bag_status where bag_location='"+PaxTraxConstants.GALLERIA_LOCATION+"') and "
		+ " history1.BAG_NO not in (select distinct BH.bag_no from TB_BAG_STATUS_HISTORY BH "
		+ " where BH.STATUS_ID in (select bag_status_id from "
		+ " tb_bag_status where bag_location='"+PaxTraxConstants.AIRPORT_LOCATION+"') and BH.BAG_NO=mstr.BAG_NO) "
		+ "	and history.BAG_NO=history1.BAG_NO and history.BAG_NO =mstr.BAG_NO  and history.created_timestamp = (select max(history2.created_timestamp)  from TB_BAG_STATUS_HISTORY history2 where "
		+ "	history2.BAG_NO=mstr.BAG_NO and mstr.CURR_STATUS_ID=history2.STATUS_ID ) and "
		+ "	history.STATUS_ID = ent.ENTITY_STATUS_ID AND history.BAG_ENTITY_ID =ent.ENTITY_ID ) temp order by temp.pl,temp.pf ";
			
	public static final String GET_CODE_DATA = "SELECT REFERENCE,CODE,DESCRIPTION,REMARKS FROM TB_DATA_CONFIG where REFERENCE = ? and ACTIVE_FLAG='Y' order by code";					
			
	/* Added for CR 251-260 changes End*/
	
	// Added for CR changes
	
	public static String UPDATE_DEPARTED_PAX = "UPDATE TB_PAX_MSTR SET PAX_DEPARTED = 'Y',MODIFIED_BY=?,MODIFIED_DATE=CURRENT DATE WHERE PAX_PAX_NO = ?";
	
	// Added for CR changes
	
//	Added for changes made for CR 250 on July 24,2007 -- Begin	
	public static String PROC_NACCS_STATUS_FOR_FLIGHT = "call ADM_INSERT_NACCS_STATUS(?,?,?,?,?,?,?)";
	
	public static String GET_FLIGHT_NACCS_STATUS = "SELECT NACCS_STATUS FROM TB_NACCS_GENERATED_FLIGHTS WHERE FLIGHT_REF_ID=? and FLIGHT_CODE_ID=? AND FLIGHT_NUMBER=?";
	
	public static String PURGE_NACCS_DATA = "DELETE FROM TB_NACCS_GENERATED_FLIGHTS WHERE CREATED_TIMESTAMP IS NOT NULL AND DATE(MODIFIED_TIMESTAMP) < ";
	
	public static String SELECT_CONTROL_PARAMS = "select PURGE_SCHEDULER_CLASS_NAME, PURGE_SCHEDULER_TIME, PURGE_SCHEDULER_PERIOD FROM tb_SCHEDULER_PARAMS WHERE SCHEDULER_NAME='"+PaxTraxConstants.SCHEDULER_REFERENCE+"'";
	
	public static String CHECK_NACCS_GENERATED = 
		"select count(NACCS_FILE_NAME) from tb_naccs_file_hdr where FLIGHT_AIRLINE_REF_ID=? and "
		+	" FLIGHT_AIRLINE_CODE_ID=? and FLIGHT_FLIGHT_NUMBER=? ";
		
//	Added for changes made for CR 250 on July 24,2007 -- End	

// Added for CR 261 changes -- Begin

   public static String INSERT_BAG_HISTORY = 
		"INSERT INTO TB_BAG_STATUS_HISTORY(BAG_NO,BAG_ENTITY_ID,STATUS_ID,BAG_MODULE,CARTON_NO, "
			+ " WH_BIN_LOC_ID,CAGE_NO,SHELF_NO,TRUCK_NO,AP_BIN_LOC_ID,BAG_CARTON_SEQ_ID,CARTON_CYCLE_ID, "
			+ " CAGE_CYCLE_ID,TRIP_ID,CREATED_BY,CREATED_TIMESTAMP,TERMINAL_NO) VALUES(?,?,?,null,null,null, "
			+ " null,null,null,null,null,null,null,null,?,current timestamp,null)";
			
	public static String UPDATE_BAG_STATUS = "UPDATE TB_BAG_MSTR SET CURR_STATUS_ID=?,MODIFIED_BY=?,MODIFIED_TIMESTAMP=CURRENT TIMESTAMP WHERE BAG_NO=?"; 
	
	public static String GET_REFUNDED_BAG_DETAILS1 = 
		"SELECT TEMP.BAG,TEMP.STATUS,TEMP.SKU,SUM(TEMP.QTY) FROM "
			+ " (select BH1.BAG_NO BAG,EM.ENTITY_DISPLAY_STATUS STATUS,ST.SALES_SKU_NUM SKU,"
			+ " ST.SALES_TRANSACTION_LINE_NUMBER LN,ST.SALES_SKU_QTY QTY "
			+ " from TB_SALES_HEADER_DATA SH, TB_SALES_TRANS_DATA ST, TB_BAG_STATUS_HISTORY BH1,TB_BAG_MSTR BM, "
			+ " TB_ENTITY_STATUS_MSTR EM, TB_PAX_MSTR PM, TB_FLIGHT_MSTR FM ";
			
	public static String GET_REFUNDED_BAG_DETAILS2 = 
		" and SH.SALES_SELLING_LOCATION in (select LOCATION_ID "
			+ " from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.AIRPORT_STORE+"') and "
			+ " SH.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND "
			+ " SH.SALES_ORIG_SELLING_LOC_NUMBER=BM.SALES_SELLING_LOCATION AND SH.SALES_ORIG_TERMINAL_NUMBER= "
			+ " BM.SALES_TERMINAL_NUMBER AND SH.SALES_ORIG_TRANSACTION_NUMBER=BM.SALES_TRANSACTION_NUMBER "
			+ " AND BM.SALES_SELLING_LOCATION=ST.SALES_SELLING_LOCATION AND "
			+ " BM.SALES_TERMINAL_NUMBER=ST.SALES_TERMINAL_NO AND BM.SALES_TRANSACTION_NUMBER= "
			+ " ST.SALES_TRANSACTION_NUMBER and SH.PAX_SEQ_ID=PM.PAX_SEQ_ID "; 
				
	public static String GET_REFUNDED_BAG_DETAILS3 = 
		"  and BH1.STATUS_ID="+PaxTraxConstants.REFUNDED_STATUS+" AND BH1.STATUS_ID=BM.CURR_STATUS_ID AND "
			+ " FM.FLIGHT_TYPE in (select code from tb_data_config where reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"')"
			+ " and PM.FLIGHT_DEPT_AIRLINE_REF_ID = FM.FLIGHT_AIRLINE_REF_ID "
			+ " and PM.FLIGHT_DEPT_AIRLINE_CODE_ID = FM.FLIGHT_AIRLINE_CODE_ID and "
			+ " PM.FLIGHT_DEPT_FLIGHT_NUMBER =FM.FLIGHT_FLIGHT_NUMBER "
			+ " and BM.PAX_SEQ_ID =PM.PAX_SEQ_ID AND BH1.BAG_NO=BM.BAG_NO and BH1.BAG_ENTITY_ID=EM.ENTITY_ID "
			+ " AND BH1.STATUS_ID=EM.ENTITY_STATUS_ID UNION "
			+ " select BH1.BAG_NO BAG,EM.ENTITY_DISPLAY_STATUS STATUS,ST.SALES_SKU_NUM SKU, " 
			+ " ST.SALES_TRANSACTION_LINE_NUMBER LN, ST.SALES_SKU_QTY QTY "
			+ " from TB_SALES_HEADER_DATA SH, TB_SALES_TRANS_DATA ST, TB_BAG_STATUS_HISTORY BH1,TB_BAG_MSTR BM, " 
			+ " TB_ENTITY_STATUS_MSTR EM, TB_PAX_MSTR PM, TB_FLIGHT_MSTR FM, TB_BAG_STATUS_HISTORY BH2 "
			+ " where SH.SALES_SELLING_LOCATION in (select LOCATION_ID "
			+ " from TB_LOCATION where LOCATION_TYPE_CODE_CODE_ID='"+PaxTraxConstants.GALLERIA_STORE+"') "
			+ " and SH.SALES_TRANSACTION_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.REFUND_TYPE+"') AND "
			+ " SH.SALES_ORIG_SELLING_LOC_NUMBER=BM.SALES_SELLING_LOCATION AND "
			+ " SH.SALES_ORIG_TERMINAL_NUMBER=BM.SALES_TERMINAL_NUMBER AND "
			+ " SH.SALES_ORIG_TRANSACTION_NUMBER=BM.SALES_TRANSACTION_NUMBER AND "
			+ " BM.SALES_SELLING_LOCATION=ST.SALES_SELLING_LOCATION AND BM.SALES_TERMINAL_NUMBER=ST.SALES_TERMINAL_NO "
			+ " AND BM.SALES_TRANSACTION_NUMBER=ST.SALES_TRANSACTION_NUMBER  and "
			+ " SH.PAX_SEQ_ID=PM.PAX_SEQ_ID ";
   
	public static String GET_REFUNDED_BAG_DETAILS4 =
		" and BH1.STATUS_ID ="+PaxTraxConstants.REFUNDED_STATUS+" and BH1.STATUS_ID=BM.CURR_STATUS_ID "
			+ " and FM.FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and "
			+ " PM.FLIGHT_DEPT_AIRLINE_REF_ID = "
			+ " FM.FLIGHT_AIRLINE_REF_ID and PM.FLIGHT_DEPT_AIRLINE_CODE_ID = FM.FLIGHT_AIRLINE_CODE_ID and "
			+ " PM.FLIGHT_DEPT_FLIGHT_NUMBER = FM.FLIGHT_FLIGHT_NUMBER "
			+ "  and BM.pax_seq_id = PM.pax_seq_id AND "
			+ " BH1.BAG_NO =BM.BAG_NO and BH1.BAG_NO=BH2.BAG_NO and BH1.BAG_ENTITY_ID=EM.ENTITY_ID "
			+ " AND BH1.STATUS_ID=EM.ENTITY_STATUS_ID union "
			+ " SELECT BH1.BAG_NO bag, EM.ENTITY_DISPLAY_STATUS status, "
			+ " ST.SALES_SKU_NUM sku, ST.SALES_TRANSACTION_LINE_NUMBER ln,(ST.SALES_SKU_QTY)qty "
			+ " FROM TB_BAG_STATUS_HISTORY BH1, TB_BAG_MSTR BM, TB_SALES_TRANS_DATA ST, TB_BAG_STATUS_HISTORY BH2, "
			+ " TB_ENTITY_STATUS_MSTR EM ,TB_BAG_STATUS_HISTORY BH3 ,  TB_PAX_MSTR PM, TB_FLIGHT_MSTR FM "
			+ " WHERE BM.SALES_SELLING_LOCATION=ST.SALES_SELLING_LOCATION AND "
			+ " BM.SALES_TERMINAL_NUMBER=ST.SALES_TERMINAL_NO AND "
			+ " BM.SALES_TRANSACTION_NUMBER=ST.SALES_TRANSACTION_NUMBER  ";
		   	
	public static String GET_REFUNDED_BAG_DETAILS5 = 
		"  and BH1.STATUS_ID ="+PaxTraxConstants.REFUNDED_STATUS+" and FM.FLIGHT_TYPE in (select code from tb_data_config where "
			+ " reference = '"+PaxTraxConstants.FLIGHT_DEPARTURE_TYPE+"') and PM.FLIGHT_DEPT_AIRLINE_REF_ID = "
			+ " FM.FLIGHT_AIRLINE_REF_ID and PM.FLIGHT_DEPT_AIRLINE_CODE_ID = FM.FLIGHT_AIRLINE_CODE_ID and "
			+ " PM.FLIGHT_DEPT_FLIGHT_NUMBER =FM.FLIGHT_FLIGHT_NUMBER "
			+ " and BM.pax_seq_id =PM.pax_seq_id and BH1.BAG_NO =BM.BAG_NO  and ";
			
	public static String GET_REFUNDED_BAG_DETAILS6 =			
		" and BH1.BAG_NO=BH3.BAG_NO and "
			+ " BH3.BAG_ENTITY_ID=EM.ENTITY_ID and BH3.STATUS_ID=EM.ENTITY_STATUS_ID "
			+ " ) TEMP GROUP BY BAG,STATUS,SKU ORDER BY BAG, SKU ";
  
// Added for CR 261 changes -- End   

// Added for CR258 changes on Mar 25, 2008  - Begin

   public static String ADM_UPDATE_FLIGHT_SCHEDULE = 
		" call ADM_UPDATE_FLIGHT_SCHEDULE(?,?,?,?,?,?,?,?,?,?,?)";
   		
	public static String ADM_UPDATE_SCREEN_DETAILS = 
		 " call ADM_UPDATE_SCREEN_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";  
		 
	public static String SELECT_DELETE_FLIGHT_OVERRIDE_SCHEDULE1 = 
		" select A.FLIGHT_OVER_DATE,  "
			+ " A.FLIGHT_OVER_TIME,A.FLIGHT_ORIGINAL_DATE,A.FLIGHT_ORIGINAL_TIME from "
			+ " TB_FLIGHT_OVERRIDE A where ";
	
	public static String SELECT_DELETE_FLIGHT_OVERRIDE_SCHEDULE2 = 		
			" and "
			+ " timestamp(a. FLIGHT_OVER_DATE,a.FLIGHT_OVER_TIME ) >=current timestamp   and "
	+ "  a.FLIGHT_FLIGHT_NUMBER=? and "
	+ " a.FLIGHT_AIRLINE_CODE_CODE_ID=? and a.FLIGHT_AIRLINE_REF_ID = ? "
	+ " and a.FLIGHT_TYPE= ? ";
		 
	public static String DELETE_FLIGHT_OVERRIDE_SCHEDULE = 
		" delete from TB_FLIGHT_OVERRIDE where FLIGHT_FLIGHT_NUMBER=? and FLIGHT_AIRLINE_CODE_CODE_ID = ? "
			+ " and FLIGHT_AIRLINE_REF_ID=? and FLIGHT_TYPE=? and timestamp(FLIGHT_OVER_DATE,FLIGHT_OVER_TIME ) >=current timestamp  ";

	/*	public static String DELETE_FLIGHT_OVERRIDE_SCHEDULE = 
		" call ADM_DELETE_OVERRIDE_SCHEDULE(?,?,?,?,?,?,?,?,?)";  */
			
	public static String DELETE_FLIGHT_SCHEDULE = 
		" delete from TB_FLIGHT_SCHEDULE where FLIGHT_FLIGHT_NUMBER=? and FLIGHT_AIRLINE_CODE_ID = ? "
			+ " and FLIGHT_AIRLINE_REF_ID=? and FLIGHT_TYPE=? ";	
			
	public static String LOAD_FLIGHT_SCHEDULE = 
		" SELECT SCHEDULE_YEAR,SCHEDULE_MONTH,SCHEDULE_WEEK,ROW_NUMBER,FROM_DATE,TO_DATE,hour(SCHEDULE_TIME)," +
		" minute(SCHEDULE_TIME),DAILY_CHECKED FROM "
			+ " TB_FLIGHT_SCHEDULE where FLIGHT_AIRLINE_REF_ID=? and FLIGHT_AIRLINE_CODE_ID=? and "
			+ " FLIGHT_FLIGHT_NUMBER=? and FLIGHT_TYPE=? "; 		
					
	public static String PURGE_FLIGHT_OVERRIDE_DATA = "DELETE FROM TB_FLIGHT_OVERRIDE WHERE " +
		" FLIGHT_ORIGINAL_DATE < "; 
		
	public static String SELECT_FLIGHT_CONTROL_PARAMS = "select PURGE_SCHEDULER_CLASS_NAME, "
	 + " PURGE_SCHEDULER_TIME, PURGE_SCHEDULER_PERIOD FROM tb_SCHEDULER_PARAMS WHERE SCHEDULER_NAME='Flight override purge'";
	 
	public static String GET_NON_SCHEDULE_FLIGHT_DETAILS =	 
	" select temp.ref,temp.code,temp.value,temp.fno,temp.typ,temp.org_ref,temp.org_code,temp.org_val,temp.dest_ref,temp.dest_code, "
	+ " temp.dest_val,temp.status,temp.cut_hr,temp.cut_min,temp.pic_ref,temp.pic_code,temp.pic_val,temp.org_dat,temp.org_hr, "
	+ " temp.org_min,temp.ovr_dat,temp.ovr_hr,temp.ovr_min,temp.int_flg,temp.flg from "
	+ " (select fm.FLIGHT_AIRLINE_REF_ID ref, fm.FLIGHT_AIRLINE_CODE_ID code,(select   a.code_code_value from tb_code_ref a "
	+ " where  fm.flight_airline_ref_id = a.ref_id and  fm.flight_airline_code_id = a.code_code_id) value, fm.FLIGHT_FLIGHT_NUMBER fno, "
	+ "	fm.FLIGHT_TYPE typ, fm.FLIGHT_ORIGIN_AIRPORT_REF_ID org_ref,fm.FLIGHT_CODE_ORIGIN_CODE_ID org_code, "
	+ " (select b.code_code_value from tb_code_ref b "
	+ "	where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id) org_val,fm.FLIGHT_DEST_AIRPORT_REF_ID dest_ref, "
	+ "	fm.FLIGHT_CODE_DEST_CODE_ID dest_code,(select c.code_code_value from tb_code_ref c where fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and "
	+ "	fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id) dest_val,fm.FLIGHT_FLIGHT_STATUS status,hour(fm.FLIGHT_CUTOFF_TIME) cut_hr, "
	+ " minute(fm.FLIGHT_CUTOFF_TIME) cut_min,fm.FLIGHT_PICKUP_LOC_REF_ID pic_ref,fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID pic_code, "
	+ "	(select d.code_code_value from tb_code_ref d where "
	+" 	fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id) pic_val,fs.flight_original_date org_dat, "
	+ " hour(fs.flight_original_time) org_hr,minute(fs.flight_original_time) org_min, fs.flight_over_date ovr_dat,hour(fs.flight_over_time) ovr_hr, "
	+ " minute(fs.flight_over_time) ovr_min,  fm.INTERNATIONAL_FLAG int_flg,'ovr' flg  from tb_flight_mstr fm,tb_flight_override fs where fs.flight_cancelled = 'N' "
	+ " and fm.FLIGHT_FLIGHT_DELETED = 'N' and fm.FLIGHT_FLIGHT_STATUS = ? and fm.flight_airline_ref_id = fs.flight_airline_ref_id and "
	 + "  fm.flight_airline_code_id = fs.flight_airline_code_code_id and fm.flight_flight_number = fs.flight_flight_number and fm.flight_type = "
	  + " fs.flight_type and fm.flight_type = ?  ";
	  
	public static String GET_NON_SCHEDULE_FLIGHT_DETAILS1 =	
	
	 " except "
	 + " select fm.FLIGHT_AIRLINE_REF_ID ref, fm.FLIGHT_AIRLINE_CODE_ID code,(select   a.code_code_value from tb_code_ref a "
	 + " where  fm.flight_airline_ref_id = a.ref_id and  fm.flight_airline_code_id = a.code_code_id) value, fm.FLIGHT_FLIGHT_NUMBER fno, "
	 + " fm.FLIGHT_TYPE typ, fm.FLIGHT_ORIGIN_AIRPORT_REF_ID org_ref,fm.FLIGHT_CODE_ORIGIN_CODE_ID org_code, "
	 + " (select b.code_code_value from tb_code_ref b "
	 + " where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id) org_val,fm.FLIGHT_DEST_AIRPORT_REF_ID dest_ref, "
	 + " fm.FLIGHT_CODE_DEST_CODE_ID dest_code,(select c.code_code_value from tb_code_ref c where fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and " 
	 + " fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id) dest_val,fm.FLIGHT_FLIGHT_STATUS status,hour(fm.FLIGHT_CUTOFF_TIME) cut_hr, "
	 + " minute(fm.FLIGHT_CUTOFF_TIME) cut_min,fm.FLIGHT_PICKUP_LOC_REF_ID pic_ref,fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID pic_code, "
	 + " (select d.code_code_value from tb_code_ref d where "
	 + " fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id) pic_val,fs.flight_original_date org_dat, "
	 + " hour(fs.flight_original_time) org_hr,minute(fs.flight_original_time) org_min, fs.flight_over_date ovr_dat,hour(fs.flight_over_time) ovr_hr, "
	 + " minute(fs.flight_over_time) ovr_min,  fm.INTERNATIONAL_FLAG int_flg,'ovr' flg  from tb_flight_mstr fm,tb_flight_override fs where fs.flight_cancelled = 'N' " 
	 + "  and fm.FLIGHT_FLIGHT_DELETED = 'N' and fm.FLIGHT_FLIGHT_STATUS = ? and fm.flight_airline_ref_id = fs.flight_airline_ref_id and "
	  + "  fm.flight_airline_code_id = fs.flight_airline_code_code_id and fm.flight_flight_number = fs.flight_flight_number and fm.flight_type = "
	  + " fs.flight_type and fs.FLIGHT_ORIGINAL_DATE between (select from_date FROM "
	  + " TB_FLIGHT_SCHEDULE where fs.FLIGHT_ORIGINAL_DATE between from_date and to_date and FLIGHT_FLIGHT_NUMBER = fm.FLIGHT_FLIGHT_NUMBER AND FLIGHT_AIRLINE_REF_ID= "
	  + " fm.FLIGHT_AIRLINE_REF_ID and FLIGHT_AIRLINE_CODE_ID=fm.FLIGHT_AIRLINE_CODE_ID and FLIGHT_TYPE = fm.FLIGHT_TYPE and fm.flight_type = ? fetch first row only) and "
	  + " (select to_date from TB_FLIGHT_SCHEDULE "
	  + " where fs.FLIGHT_ORIGINAL_DATE between from_date and to_date and FLIGHT_FLIGHT_NUMBER = fm.FLIGHT_FLIGHT_NUMBER AND FLIGHT_AIRLINE_REF_ID= "
	  + " fm.FLIGHT_AIRLINE_REF_ID and FLIGHT_AIRLINE_CODE_ID=fm.FLIGHT_AIRLINE_CODE_ID and FLIGHT_TYPE = fm.FLIGHT_TYPE and fm.flight_type = ? fetch first row only) and fm.flight_type = ? " ;
	  
	  
	public static String GET_NON_SCHEDULE_FLIGHT_DETAILS2 =
	" union "
	+ " select fm.FLIGHT_AIRLINE_REF_ID ref, fm.FLIGHT_AIRLINE_CODE_ID code,(select   a.code_code_value from tb_code_ref a "
	+ " where  fm.flight_airline_ref_id = a.ref_id and  fm.flight_airline_code_id = a.code_code_id) value, fm.FLIGHT_FLIGHT_NUMBER fno, "
	+ " fm.FLIGHT_TYPE typ, fm.FLIGHT_ORIGIN_AIRPORT_REF_ID org_ref,fm.FLIGHT_CODE_ORIGIN_CODE_ID org_code, "
	+ " (select b.code_code_value from tb_code_ref b "
	+ " where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id) org_val,fm.FLIGHT_DEST_AIRPORT_REF_ID dest_ref, " 
	+ " fm.FLIGHT_CODE_DEST_CODE_ID dest_code,(select c.code_code_value from tb_code_ref c where fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and " 
	+ " fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id) dest_val,fm.FLIGHT_FLIGHT_STATUS status,hour(fm.FLIGHT_CUTOFF_TIME) cut_hr, " 
	+ " minute(fm.FLIGHT_CUTOFF_TIME) cut_min,fm.FLIGHT_PICKUP_LOC_REF_ID pic_ref,fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID pic_code, " 
	+ " (select d.code_code_value from tb_code_ref d where " 
	+ " fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id) pic_val, " 
	 + " fs.from_date org_dat, hour(fs.schedule_time) org_hr,minute(fs.schedule_time) org_min, fs.to_date ovr_dat,hour(fs.schedule_time) ovr_hr, " 
	  + " minute(fs.schedule_time) ovr_min,  fm.INTERNATIONAL_FLAG int_flg,'sch' flg from tb_flight_mstr fm,tb_flight_schedule fs where " 
	  + "  fm.FLIGHT_FLIGHT_DELETED = 'N' and fm.FLIGHT_FLIGHT_STATUS = ? and fm.flight_airline_ref_id = fs.flight_airline_ref_id and " 
	  + "  fm.flight_airline_code_id = fs.flight_airline_code_id and fm.flight_flight_number = fs.flight_flight_number and fm.flight_type = " 
	  + " fs.flight_type and fm.flight_type = ? ";
	  
	public static String GET_MAINTAIN_NON_SCHEDULE_FLIGHT_DETAILS =	 
	" select temp.ref,temp.code,temp.value,temp.fno,temp.typ,temp.org_ref,temp.org_code,temp.org_val,temp.dest_ref,temp.dest_code, "
	+ " temp.dest_val,temp.status,temp.cut_hr,temp.cut_min,temp.pic_ref,temp.pic_code,temp.pic_val,temp.org_dat,temp.org_hr, "
	+ " temp.org_min,temp.ovr_dat,temp.ovr_hr,temp.ovr_min,temp.int_flg,temp.flg from "
	+ " (select fm.FLIGHT_AIRLINE_REF_ID ref, fm.FLIGHT_AIRLINE_CODE_ID code,(select   a.code_code_value from tb_code_ref a "
	+ " where  fm.flight_airline_ref_id = a.ref_id and  fm.flight_airline_code_id = a.code_code_id) value, fm.FLIGHT_FLIGHT_NUMBER fno, "
	+ "	fm.FLIGHT_TYPE typ, fm.FLIGHT_ORIGIN_AIRPORT_REF_ID org_ref,fm.FLIGHT_CODE_ORIGIN_CODE_ID org_code, "
	+ " (select b.code_code_value from tb_code_ref b "
	+ "	where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id) org_val,fm.FLIGHT_DEST_AIRPORT_REF_ID dest_ref, "
	+ "	fm.FLIGHT_CODE_DEST_CODE_ID dest_code,(select c.code_code_value from tb_code_ref c where fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and "
	+ "	fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id) dest_val,fm.FLIGHT_FLIGHT_STATUS status,hour(fm.FLIGHT_CUTOFF_TIME) cut_hr, "
	+ " minute(fm.FLIGHT_CUTOFF_TIME) cut_min,fm.FLIGHT_PICKUP_LOC_REF_ID pic_ref,fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID pic_code, "
	+ "	(select d.code_code_value from tb_code_ref d where "
	+" 	fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id) pic_val,fs.flight_original_date org_dat, "
	+ " hour(fs.flight_original_time) org_hr,minute(fs.flight_original_time) org_min, fs.flight_over_date ovr_dat,hour(fs.flight_over_time) ovr_hr, "
	+ " minute(fs.flight_over_time) ovr_min,  fm.INTERNATIONAL_FLAG int_flg,'ovr' flg  from tb_flight_mstr fm,tb_flight_override fs where fs.flight_cancelled = 'N' "
	+ " and fm.FLIGHT_FLIGHT_DELETED = 'N' and fm.FLIGHT_FLIGHT_STATUS = '2' and fm.flight_airline_ref_id = fs.flight_airline_ref_id and "
	 + "  fm.flight_airline_code_id = fs.flight_airline_code_code_id and fm.flight_flight_number = fs.flight_flight_number and fm.flight_type = "
	  + " fs.flight_type and fm.flight_type = ?  ";
	  
	public static String GET_MAINTAIN_NON_SCHEDULE_FLIGHT_DETAILS1 =	
	
	 " except "
	 + " select fm.FLIGHT_AIRLINE_REF_ID ref, fm.FLIGHT_AIRLINE_CODE_ID code,(select   a.code_code_value from tb_code_ref a "
	 + " where  fm.flight_airline_ref_id = a.ref_id and  fm.flight_airline_code_id = a.code_code_id) value, fm.FLIGHT_FLIGHT_NUMBER fno, "
	 + " fm.FLIGHT_TYPE typ, fm.FLIGHT_ORIGIN_AIRPORT_REF_ID org_ref,fm.FLIGHT_CODE_ORIGIN_CODE_ID org_code, "
	 + " (select b.code_code_value from tb_code_ref b "
	 + " where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id) org_val,fm.FLIGHT_DEST_AIRPORT_REF_ID dest_ref, "
	 + " fm.FLIGHT_CODE_DEST_CODE_ID dest_code,(select c.code_code_value from tb_code_ref c where fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and " 
	 + " fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id) dest_val,fm.FLIGHT_FLIGHT_STATUS status,hour(fm.FLIGHT_CUTOFF_TIME) cut_hr, "
	 + " minute(fm.FLIGHT_CUTOFF_TIME) cut_min,fm.FLIGHT_PICKUP_LOC_REF_ID pic_ref,fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID pic_code, "
	 + " (select d.code_code_value from tb_code_ref d where "
	 + " fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id) pic_val,fs.flight_original_date org_dat, "
	 + " hour(fs.flight_original_time) org_hr,minute(fs.flight_original_time) org_min, fs.flight_over_date ovr_dat,hour(fs.flight_over_time) ovr_hr, "
	 + " minute(fs.flight_over_time) ovr_min,  fm.INTERNATIONAL_FLAG int_flg,'ovr' flg  from tb_flight_mstr fm,tb_flight_override fs where fs.flight_cancelled = 'N' " 
	 + "  and fm.FLIGHT_FLIGHT_DELETED = 'N' and fm.FLIGHT_FLIGHT_STATUS = '2' and fm.flight_airline_ref_id = fs.flight_airline_ref_id and "
	  + "  fm.flight_airline_code_id = fs.flight_airline_code_code_id and fm.flight_flight_number = fs.flight_flight_number and fm.flight_type = "
	  + " fs.flight_type and fs.FLIGHT_ORIGINAL_DATE between (select from_date FROM "
	  + " TB_FLIGHT_SCHEDULE where fs.FLIGHT_ORIGINAL_DATE between from_date and to_date and FLIGHT_FLIGHT_NUMBER = fm.FLIGHT_FLIGHT_NUMBER AND FLIGHT_AIRLINE_REF_ID= "
	  + " fm.FLIGHT_AIRLINE_REF_ID and FLIGHT_AIRLINE_CODE_ID=fm.FLIGHT_AIRLINE_CODE_ID and FLIGHT_TYPE = fm.FLIGHT_TYPE and fm.flight_type = ? fetch first row only) and "
	  + " (select to_date from TB_FLIGHT_SCHEDULE "
	  + " where fs.FLIGHT_ORIGINAL_DATE between from_date and to_date and FLIGHT_FLIGHT_NUMBER = fm.FLIGHT_FLIGHT_NUMBER AND FLIGHT_AIRLINE_REF_ID= "
	  + " fm.FLIGHT_AIRLINE_REF_ID and FLIGHT_AIRLINE_CODE_ID=fm.FLIGHT_AIRLINE_CODE_ID and FLIGHT_TYPE = fm.FLIGHT_TYPE and fm.flight_type = ? fetch first row only) and fm.flight_type = ? " ;
	  
	  
	public static String GET_MAINTAIN_NON_SCHEDULE_FLIGHT_DETAILS2 =
	" union "
	+ " select fm.FLIGHT_AIRLINE_REF_ID ref, fm.FLIGHT_AIRLINE_CODE_ID code,(select   a.code_code_value from tb_code_ref a "
	+ " where  fm.flight_airline_ref_id = a.ref_id and  fm.flight_airline_code_id = a.code_code_id) value, fm.FLIGHT_FLIGHT_NUMBER fno, "
	+ " fm.FLIGHT_TYPE typ, fm.FLIGHT_ORIGIN_AIRPORT_REF_ID org_ref,fm.FLIGHT_CODE_ORIGIN_CODE_ID org_code, "
	+ " (select b.code_code_value from tb_code_ref b "
	+ " where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id) org_val,fm.FLIGHT_DEST_AIRPORT_REF_ID dest_ref, " 
	+ " fm.FLIGHT_CODE_DEST_CODE_ID dest_code,(select c.code_code_value from tb_code_ref c where fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and " 
	+ " fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id) dest_val,fm.FLIGHT_FLIGHT_STATUS status,hour(fm.FLIGHT_CUTOFF_TIME) cut_hr, " 
	+ " minute(fm.FLIGHT_CUTOFF_TIME) cut_min,fm.FLIGHT_PICKUP_LOC_REF_ID pic_ref,fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID pic_code, " 
	+ " (select d.code_code_value from tb_code_ref d where " 
	+ " fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id) pic_val, " 
	 + " fs.from_date org_dat, hour(fs.schedule_time) org_hr,minute(fs.schedule_time) org_min, fs.to_date ovr_dat,hour(fs.schedule_time) ovr_hr, " 
	  + " minute(fs.schedule_time) ovr_min,  fm.INTERNATIONAL_FLAG int_flg,'sch' flg from tb_flight_mstr fm,tb_flight_schedule fs where " 
	  + "  fm.FLIGHT_FLIGHT_DELETED = 'N' and fm.FLIGHT_FLIGHT_STATUS = '2' and fm.flight_airline_ref_id = fs.flight_airline_ref_id and " 
	  + "  fm.flight_airline_code_id = fs.flight_airline_code_id and fm.flight_flight_number = fs.flight_flight_number and fm.flight_type = " 
	  + " fs.flight_type and fm.flight_type = ? ";
	  
	   	 
// Added for CR258 changes on Mar 25, 2008  - End   

//Added for CR1832 Changes
  public static String INSERT_TA_COMM_CHANGE_LOGS = "INSERT INTO TB_TA_COMM_CHANGE VALUES(NEXTVAL FOR TA_COMM_TRACKING_SEQ_ID, ?,?,?,?,?,?,CURRENT TIMESTAMP) ";
//	INSERT INTO TB_TA_COMM_CHANGE VALUES(NEXTVAL FOR TA_COMM_TRACKING_SEQ_ID, '001','4','CO',1,2,'9999',CURRENT TIMESTAMP) 
	public static String INSERT_VISIT_TRACKING_LOGS_PAX = "INSERT INTO TB_VISIT_TRACKING VALUES (nextval for VISIT_TRACKING_SEQ_ID,?,?, ?,(SELECT distinct CODE_CODE_VALUE FROM TB_CODE_REF where REF_ID='4' and CODE_CODE_ID=?),?, ?,?,?, (SELECT distinct MODIFIED_DATE FROM TB_VISIT_MSTR where VISIT_CODE = ?),(SELECT distinct EXP_VISIT_DATE FROM TB_VISIT_MSTR where VISIT_CODE = ?))";
//	  Added for CR1832 Changes ends


	//Added by selvam for CA# 294102 starts
	public static final String PROC_ASSIGN_SEA_PORT =
		"call BT_RELEASE_TRUCK_AT_SEAPORT(?,?,?,?)";
		
		
		
	public static final String SELECT_SEA_TRUCK_LIST =
		"SELECT TRUCK_NUMBER FROM TB_TRUCK_MSTR WHERE TRUCK_DELETED = 'N' AND CURR_STATUS_ID > 1 AND CURR_STATUS_ID < 5  ";
		
		
	//public static final String GET_CAGE_LIST = "SELECT CAGE_NUMBER FROM TB_CAGE_TO_TRIP  where TRUCK_NUMBER = ? and   CAGE_NUMBER ="+"\'"+"026"+"\'";
	
	public static final String GET_CAGE_LIST = " SELECT  cageMstr.CAGE_NUMBER  FROM TB_CAGE_TO_TRIP cageTrip,TB_CAGE_MSTR cageMstr, " +
	 " TB_TRUCK_MSTR truckMstr  WHERE  truckMstr.TRUCK_NUMBER=? AND truckMstr.CURR_TRIP_ID=cageTrip.TRIP_ID and " +
	 " cageMstr.CURR_CAGE_TRUCK_SEQ_ID=cageTrip.CAGE_TRUCK_SEQ_ID ";
	
	public static final String GET_BIN_HOLDING_STATUS = "SELECT HOLDING_LOC  FROM TB_BIN_LOC_MSTR WHERE UCASE(BIN_LOC_ID) = ? AND BIN_LOC_TYPE  ="+"\'"+"A"+"\'";
	
	public static final String BIN_PRESENT = "SELECT COUNT(BIN_LOC_ID) 	FROM TB_BIN_LOC_MSTR WHERE UCASE(BIN_LOC_ID) = " +
		" ? AND BIN_LOC_DELETED = 'N' AND BIN_LOC_TYPE = 'A' " ;
	 
		
		
	public static final String BT_ASSIGN_CAGE_TO_SEA_BIN =
		"call BT_ASSIGN_CAGE_SEABIN(?,?,?,?,?,?)";
		
	public static final String BT_UPDATE_BAG_STATUS_SEAPORT =
		"call BT_UPDATE_BAG_STATUS_SEAPORT(?,?,?,?,?)";	
		
	// Added/Modified by David for CR 3659 starts	
	
	//public static final String BAG_LOOKUP =
		//"SELECT bc.CARTON_NUMBER,cc.CAGE_NUMBER||'-'||cc.SHELF_NUMBER FROM TB_BAG_TO_CARTON bc, TB_CARTON_TO_CAGE_SHELF  cc where bc.BAG_NO  =? and bc.CARTON_CYCLE_ID=cc.CARTON_CYCLE_ID ";
	
	public static final String BAG_LOOKUP ="SELECT bc.BAG_NO,bc.CARTON_NUMBER,cc.CAGE_NUMBER||'-'||cc.SHELF_NUMBER,bs.ENTITY_STATUS,bg.CURR_STATUS_ID " +
		"FROM TB_PAX_MSTR px,TB_BAG_TO_CARTON bc, TB_CARTON_TO_CAGE_SHELF  cc,TB_BAG_MSTR bg,TB_ENTITY_STATUS_MSTR bs where px.PAX_PAX_NO = ? " +
		"and px.PAX_SEQ_ID=bg.PAX_SEQ_ID and   bc.BAG_NO  = bg.BAG_NO and bc.CARTON_CYCLE_ID=cc.CARTON_CYCLE_ID and bg.CURR_STATUS_ID=bs.ENTITY_STATUS_ID and bg.BAG_ENTITY_ID=bs.ENTITY_ID order by bc.BAG_NO desc";
	
	
	public static final String FLIGHT_LOOKUP ="SELECT b.CODE_CODE_VALUE||' '||a.FLIGHT_DEPT_FLIGHT_NUMBER,a.FLIGHT_DEPT_DATE FROM  TB_PAX_MSTR a,TB_CODE_REF b where a.PAX_PAX_NO= ? and a.FLIGHT_DEPT_AIRLINE_REF_ID=b.REF_ID and a.FLIGHT_DEPT_AIRLINE_CODE_ID=b.CODE_CODE_ID  ";
	
	// Added/Modified by David for CR 3659 ends		
	public static final String BAG_STATUS ="SELECT CURR_STATUS_ID FROM TB_BAG_MSTR WHERE BAG_NO =  ? ";
	
	
		
	public static final String TRUCK_STATUS_INSERT =
		"INSERT INTO TB_TRUCK_STATUS_HISTORY(TRUCK_NUMBER, STATUS_ID, TRUCK_ENTITY_ID, CREATED_BY,  CREATED_TIMESTAMP, TERMINAL_NO) "+
	" VALUES(?, 1, 6, ?, CURRENT TIMESTAMP, ?)";
		
		
		
	public static final String TRUCK_MSTR_UPDATE=
		"UPDATE TB_TRUCK_MSTR SET CAGE_COUNT = 0, CURR_TRIP_ID = null, CURR_STATUS_ID = 1, MODIFIED_BY = ?, " + 
	" MODIFIED_TIMESTAMP = CURRENT TIMESTAMP, TERMINAL_NO = ? WHERE TRUCK_NUMBER = ?";
		
//	For Flight Upload
	  public static String FLIGHT_GET_LAST_PROCESSED_DATE_TIME = "SELECT LAST_PROCESSED_DATE_TIME FROM TB_WINCOR_UPLOAD_MSTR WHERE UPLOAD_TYPE = 'Flight'";
	
	  public static String FLIGHT_UPDATE_LAST_PROCESSED_DATE_TIME = "UPDATE TB_WINCOR_UPLOAD_MSTR SET LAST_PROCESSED_DATE_TIME = TIMESTAMP('";
	  
//	For PostCode Upload
	  public static String POSTCODE_GET_LAST_PROCESSED_DATE_TIME = "SELECT LAST_PROCESSED_DATE_TIME FROM TB_WINCOR_UPLOAD_MSTR WHERE UPLOAD_TYPE = 'PostalCode'";
	
	  public static String POSTCODE_UPDATE_LAST_PROCESSED_DATE_TIME = "UPDATE TB_WINCOR_UPLOAD_MSTR SET LAST_PROCESSED_DATE_TIME = TIMESTAMP('";
			
		
//	Added by selvam for CA# 294102 ends
















}
