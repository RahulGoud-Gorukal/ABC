package com.dfs.paxtrax.common.util;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
 
/**
 * Xml utility class for encoding data.
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * DATE 		USER 			COMMENTS
 * 25/06/2004	P.C. Sathish	Created   
 *
 */
public class XmlUtil {

	/**
	 * Encodes each character by replacing them with xml encoded characters.
	 * The following characters are replaced.
	 *  &, ', ", >, <
	 * @param String rawData the raw string of data
	 * @return the encoded data
	 */
	public String encodeCharacterData(String rawData) {
		// first optimize by checking null and zero length strings		
		if (rawData == null) {
			return rawData;
		}
		if (rawData.length() == 0) {
			return rawData;
		}
		
		String encodedData = "";
		for (int i = 0; i < rawData.length(); i++) {
			char rawChar = rawData.charAt(i);
			switch (rawChar) {
				case '&':
					encodedData += "&amp;";
					break;
				case '\'':
					encodedData += "&apos;";
					break;
				case '\"':
					encodedData += "&quot;";
					break;
				case '>':
					encodedData += "&gt;";
					break;
				case '<':
					encodedData += "&lt;";
					break;
				default:
					encodedData += rawChar;
					break;				
			}
		}
		
		return encodedData;
	}
	
	/**
	 * Appends the raw data within a CDATA section. No characters are
	 * modified in the given raw data.
	 * 
	 * @param String rawData the raw string of data
	 * @return the encoded data
	 */
	public String encodeUsingCDATA(String rawData) {
		if (rawData != null) {
			return "<![CDATA["+rawData+"]]>";
		} else {
			return rawData;
		}
	}
}
