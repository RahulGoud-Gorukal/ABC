package com.dfs.paxtrax.common.util;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dfs.paxtrax.common.exception.PaxTraxConfigFileException;

/**
 * This is a generic logging class used for logging all debugging/error logging
 * messages. This class also defines all the category that are applicable to
 * the PaxTrax application. Application developers must use this class for printing
 * all debugging/error handling mesages and MUST NOT use any System.out
 * statements.
 *
 * @author Pankaj Dubey (Cognizant)
 * @created March 22, 2004
 */
public class PaxTraxLog {

    // This section defines all the levels that could be used while
    // defining messages. These levels provide a way for the logger to
    // enable/disable logging based on the type of environment (dev, preprod,
    // prod etc)

    /**
     * DEBUG Level
     */
    public static final int DEBUG = 101;

    /**
     * INFO Level
     */
    public static final int INFO = 102;

    /**
     * WARNING Level
     */
    public static final int WARNING = 103;

    /**
     * ERROR Level
     */
    public static final int ERROR = 104;

    /**
     * FATAL Level
     */
    public static final int FATAL = 105;


    /**
     * Log messages enabling/disabling flags for debug messages
     */
    public static final boolean B_DEBUG = true;

    /**
     * Log messages enabling/disabling flags for info messages
     */
    public static final boolean B_INFO = true;

    /**
     * Log messages enabling/disabling flags for warn messages
     */
    public static final boolean B_WARNING = true;

    /**
     * Log messages enabling/disabling flags for error messages
     */
    public static final boolean B_ERROR = true;


    /**
     * Log messages enabling/disabling flags for fatal messages
     */
    public static final boolean B_FATAL = true;


    static Logger logger;

    static {    	              
        try {
			PropertyConfigurator.configure(PaxTraxConfig.getProperty("log4j.file.lcf"));
		} catch (PaxTraxConfigFileException e) {
		}                
        logger = Logger.getLogger("PaxTraxLog");
    }

    // This methods just provide a way of concating a level specfic string
    // in the front of the actual message.
    private static String getLevelString(int level) {
        switch (level) {
            case DEBUG:
                return "DEBUG";
            case INFO:
                return "INFO";
            case WARNING:
                return "WARNING";
            case ERROR:
                return "ERROR";
            case FATAL:
                return "FATAL";
            default      :
                return "INVALID LEVEL";
        }
    }

    /**
     * Use this for printing debugging messages. Currently, this method does
     * do any fancy optimization but is provide to avoid usage of System.out
     * in the system. This implementation of this must be changed in future.
     *
     * @param message actual log message
     */
    public static final void logDebug(String message) {
        if (B_DEBUG)
            log(DEBUG, message);

    }

    /**
     * Use this for printing debugging messages. This method also prints the
     * the stack trace.
     *
     * @param message actual log message
     * @throws ex expception that was thrown
     */
    public static final void logDebug(String message,
                                      Exception ex) {
        if (B_DEBUG)
            log(DEBUG, message, ex);
    }


    /**
     * Use this for printing informative messages. Currently, this method does
     * do any fancy optimization but is provide to avoid usage of System.out
     * in the system. This implementation of this must be changed in future.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     */
    public static final void logInfo(String message) {
        if (B_INFO)
            log(INFO, message);
    }

    /**
     * Use this for printing informative messages. This method also prints the
     * the stack trace.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     * @throws ex expception that was thrown
     */
    public static final void logInfo(String message,
                                     Exception ex) {
        if (B_INFO)
            log(INFO, message, ex);

    }


    /**
     * Use this for printing warning messages.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     */
    public static final void logWarning(String message) {
        if (B_WARNING)
            log(WARNING, message);
    }

    /**
     * Use this for printing warning messages with exception.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     * @param ex       exception that was thrown
     */
    public static final void logWarning(String message,
                                        Exception ex) {
        if (B_WARNING)
            log(WARNING, message, ex);
    }

    /**
     * Use this for printing error messages.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     */
    public static final void logError(String message) {
        if (B_ERROR)
            log(ERROR, message);

    }

    /**
     * Use this for printing error messages with exception.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     * @param ex       exception that was thrown
     */
    public static final void logError(String message,
                                      Exception ex) {
        if (B_ERROR)
            log(ERROR, message, ex);


    }


    /**
     * Use this for printing fatal messages.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     */
    public static final void logFatal(String message) {
        if (B_FATAL)
            log(FATAL, message);

    }

    /**
     * Use this for printing fatal messages with exception.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     * @param ex       exception that was thrown
     */
    public static final void logFatal(String message,
                                      Exception ex) {
        if (B_FATAL)
            log(FATAL, message, ex);

    }


    /**
     * Use this generic log operation for logging any kindof message.
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     */
    public static final void log(int level, String message) {
      switch (level) {
            case DEBUG:
                logger.debug(message);
                break;
            case INFO:
                logger.info(message);
                break;
            case WARNING:
                logger.warn(message);
                break;
            case ERROR:
                logger.error(message);
                break;
            case FATAL:
                logger.fatal(message);
                break;
        }
    }

    /**
     * Use this generic log operation for logging any kindof message with
     * <code>Exception</code>
     *
     * @param category current catgory id where this message belongs
     * @param message  actual log message
     * @param ex       exception to be printed
     */
    public static final void log(int level, String message,
                                 Exception ex) {
        /*  getCategoryString(category) + ": " + message + " ]");*/
        switch (level) {
            case DEBUG:
                logger.debug(message, ex);
                break;
            case INFO:
                logger.info(message, ex);
                break;
            case WARNING:
                logger.warn(message, ex);
                break;
            case ERROR:
                logger.error(message, ex);
                break;
            case FATAL:
                logger.fatal(message, ex);
                break;
        }
        // ex.printStackTrace();
    }
}
