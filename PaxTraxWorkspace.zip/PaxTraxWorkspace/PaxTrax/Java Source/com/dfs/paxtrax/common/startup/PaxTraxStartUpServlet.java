package com.dfs.paxtrax.common.startup;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxConfigFileException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxConfig;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.valueobject.FTPConfig;

/**
 * This is delegate class which performs jndi lookup and it act as a point of 
 * entry for business methods.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 05/05/2004	Pankaj Dubey	Created   
 * 15/07/2004	P.C.Sathish		Modified
 * 07/28/2007	Uma D			Modified for CR changes
 */
public class PaxTraxStartUpServlet extends HttpServlet
{
	private ArrayList timers = new ArrayList();

	public void init() throws ServletException
	{

		FTPConfig ftpConfig = null;
		int ftpScheduler = 0;
		try
		{
			ftpConfig = getNACCSFTPParameters();
		}
		catch (PaxTraxSystemException se)
		{
			PaxTraxLog.logDebug(
				"Unable to get FTP parameters " + se.getMessage());
		}

		// Purge Scheduler
		try
		{

			String purgeClassName = null;
			Calendar purgeStartAsDate = null;
			Calendar currentDate = null;
			String purgeScheduleType = null;
			String purgePeriod = null;
			long purgePeriodAsLong = 0;
			Timer purgeTimer = new Timer();
			timers.add(purgeTimer);
			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);

			purgeClassName =
				PaxTraxConfig.getProperty(
					"scheduler.purge.scheduler.classname");

			PaxTraxLog.logDebug(
				"ENTERED INTO purge Scheduler name " + purgeClassName);
			purgeScheduleType =
				PaxTraxConfig.getProperty("scheduler.purge.scheduler.type");

			purgePeriod =
				PaxTraxConfig.getProperty("scheduler.purge.scheduler.period");
			PaxTraxLog.logDebug("Purge Period is " + purgePeriod);

			purgePeriod = purgePeriod.trim();
			purgeStartAsDate = Calendar.getInstance();

			currentDate = Calendar.getInstance();
			PaxTraxLog.logDebug(
				"Current Time is          :" + currentDate.getTime());

			currentDate.set(
				Calendar.MINUTE,
				currentDate.get(Calendar.MINUTE) + 1);
			PaxTraxLog.logDebug(
				"Current Checking Time is :" + currentDate.getTime());

			int nHour =
				Integer.parseInt(
					PaxTraxConfig.getProperty("scheduler.purge.schedule.hour"));
			int nMinute =
				Integer.parseInt(
					PaxTraxConfig.getProperty(
						"scheduler.purge.schedule.minute"));
			int nSecond =
				Integer.parseInt(
					PaxTraxConfig.getProperty(
						"scheduler.purge.schedule.second"));

			PaxTraxLog.logDebug(
				"Purge Hour from property file-::"
					+ nHour
					+ "::Minute::"
					+ nMinute
					+ "::Second::"
					+ nSecond);

			purgeStartAsDate.set(Calendar.HOUR_OF_DAY, nHour);
			purgeStartAsDate.set(Calendar.MINUTE, nMinute);
			purgeStartAsDate.set(Calendar.SECOND, nSecond);
			PaxTraxLog.logDebug(
				"Actual Purge Scheduled Time is :"
					+ purgeStartAsDate.getTime());

			if (purgeStartAsDate.before(currentDate))
			{
				purgeStartAsDate.set(
					Calendar.DATE,
					currentDate.get(Calendar.DATE) + 1);
				PaxTraxLog.logDebug(
					"purge ReSchedule Time is      : "
						+ purgeStartAsDate.getTime());
			}

			Date firstTime = purgeStartAsDate.getTime();

			purgePeriodAsLong = Long.parseLong(purgePeriod);

			//     fdelay is the default for timer

			if (!(purgeScheduleType.equalsIgnoreCase("frate")
				|| purgeScheduleType.equalsIgnoreCase("fdelay")))
			{
				purgeScheduleType = "fdelay";
			}

			TimerTask purgeTask =
				(TimerTask) (Class.forName(purgeClassName).newInstance());

			if (purgeScheduleType.equalsIgnoreCase("fdelay"))
			{
				purgeTimer.schedule(purgeTask, firstTime, purgePeriodAsLong);

			}
			else
			{
				purgeTimer.scheduleAtFixedRate(
					purgeTask,
					firstTime,
					purgePeriodAsLong);
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in Purge Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The purge scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for Purge Scheduler"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the Purge Scheduler" + e.getMessage());

		}

		//Commtrax 
		try
		{

			String commtraxClassName = null;
			Calendar commtraxStartAsDate = null;
			String commtraxScheduleType = null;
			String commtraxPeriod = null;
			long commtraxPeriodAsLong = 0;
			Timer commtraxTimer = new Timer();
			timers.add(commtraxTimer);
			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);

			commtraxClassName =
				PaxTraxConfig.getProperty(
					"scheduler.commtrax.scheduler.classname");

			PaxTraxLog.logDebug(
				"ENTERED INTO commtrax Scheduler name " + commtraxClassName);
			commtraxScheduleType =
				PaxTraxConfig.getProperty("scheduler.commtrax.scheduler.type");

			commtraxPeriod =
				PaxTraxConfig.getProperty(
					"scheduler.commtrax.scheduler.period");
			PaxTraxLog.logDebug("commtrax Period is " + commtraxPeriod);

			commtraxPeriod = commtraxPeriod.trim();

			commtraxStartAsDate = Calendar.getInstance();
			Calendar currentDate = Calendar.getInstance();
			PaxTraxLog.logDebug(
				"Current Time is          :" + currentDate.getTime());

			currentDate.set(
				Calendar.MINUTE,
				currentDate.get(Calendar.MINUTE) + 1);
			PaxTraxLog.logDebug(
				"Current Checking Time is :" + currentDate.getTime());

			int nHour =
				Integer.parseInt(
					PaxTraxConfig.getProperty(
						"scheduler.commtrax.schedule.hour"));
			int nMinute =
				Integer.parseInt(
					PaxTraxConfig.getProperty(
						"scheduler.commtrax.schedule.minute"));
			int nSecond =
				Integer.parseInt(
					PaxTraxConfig.getProperty(
						"scheduler.commtrax.schedule.second"));

			PaxTraxLog.logDebug(
				"Commtrax HOUR from property-::"
					+ nHour
					+ "::Minute::"
					+ nMinute
					+ "::Second::"
					+ nSecond);

			commtraxStartAsDate.set(Calendar.HOUR_OF_DAY, nHour);
			commtraxStartAsDate.set(Calendar.MINUTE, nMinute);
			commtraxStartAsDate.set(Calendar.SECOND, nSecond);
			PaxTraxLog.logDebug(
				"Actual Commtrax Scheduled Time is :"
					+ commtraxStartAsDate.getTime());

			if (commtraxStartAsDate.before(currentDate))
			{
				commtraxStartAsDate.set(
					Calendar.DATE,
					currentDate.get(Calendar.DATE) + 1);
				PaxTraxLog.logDebug(
					"Commtrax ReSchedule Time is      : "
						+ commtraxStartAsDate.getTime());
			}

			Date firstTime = commtraxStartAsDate.getTime();

			commtraxPeriodAsLong = Long.parseLong(commtraxPeriod);

			//     fdelay is the default for timer

			if (!(commtraxScheduleType.equalsIgnoreCase("frate")
				|| commtraxScheduleType.equalsIgnoreCase("fdelay")))
			{
				commtraxScheduleType = "fdelay";
			}

			TimerTask commtraxTask =
				(TimerTask) (Class.forName(commtraxClassName).newInstance());

			if (commtraxScheduleType.equalsIgnoreCase("fdelay"))
			{
				commtraxTimer.schedule(
					commtraxTask,
					firstTime,
					commtraxPeriodAsLong);

			}
			else
			{
				commtraxTimer.scheduleAtFixedRate(
					commtraxTask,
					firstTime,
					commtraxPeriodAsLong);
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in Purge Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The purge scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for Purge Scheduler"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the Purge Scheduler" + e.getMessage());

		}

		// NACCS Scheduler

		try
		{

			int autoGeneration = 0;
			String naccsClassName = null;
			Calendar naccsStartAsDate = null;
			String naccsScheduleType = null;
			String naccsPeriod = null;
			long naccsPeriodAsLong = 0;
			Timer naccsTimer = new Timer();
			timers.add(naccsTimer);

			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);
			try
			{
				autoGeneration =
					Integer.parseInt(
						PaxTraxConfig.getProperty(
							"scheduler.naccsscheduler.autogeneration"));
			}
			catch (NumberFormatException nfe)
			{
				PaxTraxLog.logError(
					"Generation NACCS auto generation invalid in PaxTraxConfig.properties",
					nfe);
			}
			// switch on auto generation if it is 1, else switch if off.
			if (autoGeneration == 1)
			{

				naccsClassName =
					PaxTraxConfig.getProperty(
						"scheduler.naccsscheduler.classname");
				PaxTraxLog.logDebug("Scheduler name " + naccsClassName);
				naccsScheduleType =
					PaxTraxConfig.getProperty("scheduler.naccsscheduler.type");
				//naccsPeriod = PaxTraxConfig.getProperty("scheduler.naccsscheduler.period");

				if (ftpConfig != null)
				{
					naccsPeriod =
						""
							+ ftpConfig.getNaccsGenerationFrequency() * 60 * 1000;
				}
				PaxTraxLog.logDebug("Generation Frequency " + naccsPeriod);
				naccsStartAsDate = Calendar.getInstance();
				naccsStartAsDate.set(
					Calendar.MINUTE,
					naccsStartAsDate.get(Calendar.MINUTE) + 1);
				Date firstTime = naccsStartAsDate.getTime();

				naccsPeriodAsLong = Long.parseLong(naccsPeriod);

				//fdelay is the default for timer

				if (!(naccsScheduleType.equalsIgnoreCase("frate")
					|| naccsScheduleType.equalsIgnoreCase("fdelay")))
				{
					naccsScheduleType = "fdelay";
				}

				TimerTask naccsTask =
					(TimerTask) (Class.forName(naccsClassName).newInstance());

				if (naccsScheduleType.equalsIgnoreCase("fdelay"))
				{
					naccsTimer.schedule(
						naccsTask,
						firstTime,
						naccsPeriodAsLong);
				}
				else
				{
					naccsTimer.scheduleAtFixedRate(
						naccsTask,
						firstTime,
						naccsPeriodAsLong);
				}
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Generation NACCS Scheduler Error in period format in PaxTraxConfig.properties",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The NACCS scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Generation NACCS Scheduler Error reading PaxTraxConfig.properties"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Generation NACCS Scheduler Error in Starting the Scheduler"
					+ e.getMessage());

		}

		//NACCS FTP scheduler
		try
		{

			String naccsClassName = null;
			Calendar naccsStartAsDate = null;
			String naccsScheduleType = null;
			String naccsPeriod = null;
			long naccsPeriodAsLong = 0;
			Timer naccsTimer = new Timer();
			timers.add(naccsTimer);

			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);

			ftpScheduler =
				Integer.parseInt(
					PaxTraxConfig.getProperty(
						"scheduler.naccsscheduler.ftpscheduler"));
			/** use ftp scheduler if 1, else use copy scheduler */
			if (ftpScheduler == 1)
			{
				naccsClassName =
					PaxTraxConfig.getProperty(
						"scheduler.naccsftpscheduler.classname");
			}
			else
			{
				naccsClassName =
					PaxTraxConfig.getProperty(
						"scheduler.naccscopyscheduler.classname");
			}

			PaxTraxLog.logDebug("FTP Scheduler name " + naccsClassName);
			naccsScheduleType =
				PaxTraxConfig.getProperty("scheduler.naccsftpscheduler.type");
			//naccsPeriod = PaxTraxConfig.getProperty("scheduler.naccsscheduler.period");
			if (ftpConfig != null)
			{
				naccsPeriod = "" + ftpConfig.getNaccsFTPFrequency() * 60 * 1000;

				PaxTraxLog.logDebug("FTP Frequency " + naccsPeriod);
				naccsStartAsDate = Calendar.getInstance();
				naccsStartAsDate.set(
					Calendar.MINUTE,
					naccsStartAsDate.get(Calendar.MINUTE) + 1);
				Date firstTime = naccsStartAsDate.getTime();

				naccsPeriodAsLong = Long.parseLong(naccsPeriod);

				//fdelay is the default for timer

				if (!(naccsScheduleType.equalsIgnoreCase("frate")
					|| naccsScheduleType.equalsIgnoreCase("fdelay")))
				{
					naccsScheduleType = "fdelay";
				}

				TimerTask naccsTask =
					(TimerTask) (Class.forName(naccsClassName).newInstance());

				if (naccsScheduleType.equalsIgnoreCase("fdelay"))
				{
					naccsTimer.schedule(
						naccsTask,
						firstTime,
						naccsPeriodAsLong);
				}
				else
				{
					naccsTimer.scheduleAtFixedRate(
						naccsTask,
						firstTime,
						naccsPeriodAsLong);
				}
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"NACCS FTP scheduler Error in period format in PaxTraxConfig.properties",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The NACCS FTP scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"NACCS FTP scheduler Error reading PaxTraxConfig.properties"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"NACCS FTP scheduler Error in Starting the Scheduler"
					+ e.getMessage());

		}

		//NACCS Acknowledge Scheduler       

		try
		{

			String naccsClassName = null;
			Calendar naccsStartAsDate = null;
			String naccsScheduleType = null;
			String naccsPeriod = null;
			long naccsPeriodAsLong = 0;
			Timer naccsTimer = new Timer();
			timers.add(naccsTimer);

			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);

			/** use acknowledgement ftp scheduler if 1, else use acknowledgement copy scheduler */
			if (ftpScheduler == 1)
			{
				naccsClassName =
					PaxTraxConfig.getProperty(
						"scheduler.naccsacknowledge.scheduler.classname");
			}
			else
			{
				naccsClassName =
					PaxTraxConfig.getProperty(
						"scheduler.naccsacknowledge.copyscheduler.classname");
			}

			PaxTraxLog.logDebug(
				"ENTERED INTO NACCCS ACKNOWLEDGE Scheduler name "
					+ naccsClassName);
			naccsScheduleType =
				PaxTraxConfig.getProperty(
					"scheduler.naccsacknowledge.scheduler.type");

			//   naccsPeriod = PaxTraxConfig.getProperty("scheduler.naccsacknowledge.scheduler.period");
			naccsPeriod =
				"" + ftpConfig.getEntryNoUploadFrequency() * 60 * 1000;

			naccsStartAsDate = Calendar.getInstance();
			naccsStartAsDate.set(
				Calendar.MINUTE,
				naccsStartAsDate.get(Calendar.MINUTE) + 1);
			Date firstTime = naccsStartAsDate.getTime();

			naccsPeriodAsLong = Long.parseLong(naccsPeriod);

			//     fdelay is the default for timer

			if (!(naccsScheduleType.equalsIgnoreCase("frate")
				|| naccsScheduleType.equalsIgnoreCase("fdelay")))
			{
				naccsScheduleType = "fdelay";
			}

			TimerTask naccsTask =
				(TimerTask) (Class.forName(naccsClassName).newInstance());

			if (naccsScheduleType.equalsIgnoreCase("fdelay"))
			{
				naccsTimer.schedule(naccsTask, firstTime, naccsPeriodAsLong);
			}
			else
			{
				naccsTimer.scheduleAtFixedRate(
					naccsTask,
					firstTime,
					naccsPeriodAsLong);
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in period format in NACCS Acknowledge Scheduler   PaxTraxConfig.properties",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The NACCS Acknowledge NACCS Acknowledge Scheduler    implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading NACCS Acknowledge Scheduler   PaxTraxConfig.properties"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the NACCS Acknowledge Scheduler   "
					+ e.getMessage());

		}

		// LTS Scheduler
		try
		{

			String ltsClassName = null;
			Calendar ltsStartAsDate = null;
			Calendar currentDate = null;
			String ltsScheduleType = null;
			String ltsPeriod = null;
			long ltsPeriodAsLong = 0;
			Timer ltsTimer = new Timer();
			timers.add(ltsTimer);
			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);

			ltsClassName =
				PaxTraxConfig.getProperty("scheduler.lts.scheduler.classname");

			PaxTraxLog.logDebug(
				"ENTERED INTO lts Scheduler name " + ltsClassName);
			ltsScheduleType =
				PaxTraxConfig.getProperty("scheduler.lts.scheduler.type");

			ltsPeriod =
				PaxTraxConfig.getProperty("scheduler.lts.scheduler.period");
			PaxTraxLog.logDebug("LTS Period is " + ltsPeriod);

			ltsPeriod = ltsPeriod.trim();

			ltsStartAsDate = Calendar.getInstance();
			currentDate = Calendar.getInstance();
			PaxTraxLog.logDebug(
				"Current Time is          :" + currentDate.getTime());

			currentDate.set(
				Calendar.MINUTE,
				currentDate.get(Calendar.MINUTE) + 1);
			PaxTraxLog.logDebug(
				"Current Checking Time is :" + currentDate.getTime());

			int nHour =
				Integer.parseInt(
					PaxTraxConfig.getProperty("scheduler.lts.schedule.hour"));
			int nMinute =
				Integer.parseInt(
					PaxTraxConfig.getProperty("scheduler.lts.schedule.minute"));
			int nSecond =
				Integer.parseInt(
					PaxTraxConfig.getProperty("scheduler.lts.schedule.second"));

			PaxTraxLog.logDebug(
				"LTS HOUR from property-::"
					+ nHour
					+ "::Minute::"
					+ nMinute
					+ "::Second::"
					+ nSecond);

			ltsStartAsDate.set(Calendar.HOUR_OF_DAY, nHour);
			ltsStartAsDate.set(Calendar.MINUTE, nMinute);
			ltsStartAsDate.set(Calendar.SECOND, nSecond);
			PaxTraxLog.logDebug(
				"Actual LTS Scheduled Time is :" + ltsStartAsDate.getTime());

			if (ltsStartAsDate.before(currentDate))
			{
				ltsStartAsDate.set(
					Calendar.DATE,
					currentDate.get(Calendar.DATE) + 1);
				PaxTraxLog.logDebug(
					"LTS ReSchedule Time is      : "
						+ ltsStartAsDate.getTime());
			}

			Date firstTime = ltsStartAsDate.getTime();

			ltsPeriodAsLong = Long.parseLong(ltsPeriod);

			//     fdelay is the default for timer

			if (!(ltsScheduleType.equalsIgnoreCase("frate")
				|| ltsScheduleType.equalsIgnoreCase("fdelay")))
			{
				ltsScheduleType = "fdelay";
			}

			TimerTask ltsTask =
				(TimerTask) (Class.forName(ltsClassName).newInstance());

			if (ltsScheduleType.equalsIgnoreCase("fdelay"))
			{
				ltsTimer.schedule(ltsTask, firstTime, ltsPeriodAsLong);

			}
			else
			{
				ltsTimer.scheduleAtFixedRate(
					ltsTask,
					firstTime,
					ltsPeriodAsLong);
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in LTS Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The LTS scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for LTS Scheduler"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the LTS Scheduler" + e.getMessage());

		}
		//TA File FTP Scheduler 
		//Added on 30-09-2005
		Connection con = null;
		Statement s = null;
		ResultSet rs = null;
		try
		{

			String taClassName = null;
			Calendar taStartAsDate = null;
			Calendar currentDate = null;
			String taScheduleType = null;
			String taPeriod = null;
			long taPeriodAsLong = 0;
			Timer taTimer = new Timer();
			timers.add(taTimer);

			con = null;
			DBUtil dbUtil = DBUtil.getInstance();
			con = dbUtil.getConnection();
			s = con.createStatement();
			int nHour = 0;
			int nMinute = 0;
			int nSecond = 0;
			rs =
				s.executeQuery(
					SQLConstants.TAFILE_FTP_SCHEDULER);

			if (rs != null)
			{
				if (rs.next())
				{
					nHour = rs.getInt(1);
					nMinute = rs.getInt(2);
					nSecond = rs.getInt(3);
					taPeriod = rs.getString(4);
				}

			}

			SimpleDateFormat dateFormatter =
				new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);
			taClassName =
				PaxTraxConfig.getProperty("scheduler.ta.scheduler.classname");

			PaxTraxLog.logDebug(
				"ENTERED INTO ta Scheduler name " + taClassName);
			taScheduleType =
				PaxTraxConfig.getProperty("scheduler.ta.scheduler.type");

			PaxTraxLog.logDebug("ta Period is " + taPeriod);

			taPeriod = taPeriod.trim();
			taStartAsDate = Calendar.getInstance();

			currentDate = Calendar.getInstance();
			PaxTraxLog.logDebug(
				"Current Time is          :" + currentDate.getTime());

			currentDate.set(
				Calendar.MINUTE,
				currentDate.get(Calendar.MINUTE) + 1);
			PaxTraxLog.logDebug(
				"Current Checking Time is :" + currentDate.getTime());

			PaxTraxLog.logDebug(
				"ta Hour from DB::"
					+ nHour
					+ "::Minute::"
					+ nMinute
					+ "::Second::"
					+ nSecond);

			taStartAsDate.set(Calendar.HOUR_OF_DAY, nHour);
			taStartAsDate.set(Calendar.MINUTE, nMinute);
			taStartAsDate.set(Calendar.SECOND, nSecond);
			PaxTraxLog.logDebug(
				"Actual ta Scheduled Time is :" + taStartAsDate.getTime());

			if (taStartAsDate.before(currentDate))
			{
				taStartAsDate.set(
					Calendar.DATE,
					currentDate.get(Calendar.DATE) + 1);
				PaxTraxLog.logDebug(
					"ta ReSchedule Time is      : " + taStartAsDate.getTime());
			}

			Date firstTime = taStartAsDate.getTime();

			taPeriodAsLong = Long.parseLong(taPeriod);

			//     fdelay is the default for timer

			if (!(taScheduleType.equalsIgnoreCase("frate")
				|| taScheduleType.equalsIgnoreCase("fdelay")))
			{
				taScheduleType = "fdelay";
			}

			TimerTask taTask =
				(TimerTask) (Class.forName(taClassName).newInstance());

			if (taScheduleType.equalsIgnoreCase("fdelay"))
			{
				taTimer.schedule(taTask, firstTime, taPeriodAsLong);

			}
			else
			{
				taTimer.scheduleAtFixedRate(taTask, firstTime, taPeriodAsLong);
			}

		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in TA FTP Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"TA FTP Scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for TA FTP Scheduler"
					+ ptcfe.getMessage());
		}
		catch (SQLException e)
		{
			PaxTraxLog.logError("SQLEXception " + e.getMessage());

		}
		catch (Exception e)
		{

			e.printStackTrace();
			PaxTraxLog.logError(
				"Error in Starting the TA FTP Scheduler " + e.getMessage());

		}
		
		/* Code added as part of SR 1042 - International DF Sale Enhancement */
		/* Code added on August 28, 2006 */
		/* Scheduled Flight query changed to filter out International Flights */
		//International DF Sale, LTS Import Declaration Number Upload Scheduler 
		try
		{
			String schedulerClassName = null;
			Calendar startAsDate = null;
			Calendar currentDate = null;
			String scheduleType = null;
			String schedulerPeriod = null;
			long schedulerPeriodAsLong = 0;
			Timer importUploadTimer = new Timer();
			timers.add(importUploadTimer);

			con = null;
			DBUtil dbUtil = DBUtil.getInstance();
			con = dbUtil.getConnection();
			s = con.createStatement();
			int nHour = 0;
			int nMinute = 0;
			int nSecond = 0;
			rs = s.executeQuery(SQLConstants.INTL_IMPORT_DECL_SCHEDULER);

			if (rs != null)
			{
				if (rs.next())
				{
					nHour = rs.getInt(1);
					nMinute = rs.getInt(2);
					nSecond = rs.getInt(3);
					schedulerPeriod = rs.getString(4);
				}
			}

			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy H:mm:ss", Locale.US);
			schedulerClassName = PaxTraxConfig.getProperty("scheduler.intlImportDecl.scheduler.classname");

			PaxTraxLog.logDebug("Entered into International DF Sale - Import Declaration Scheduler "+ schedulerClassName);
			scheduleType = PaxTraxConfig.getProperty("scheduler.intlImportDecl.scheduler.type");

			PaxTraxLog.logDebug("Intl Import Decl Number Period is " + schedulerPeriod);
			schedulerPeriod = schedulerPeriod.trim();
			startAsDate = Calendar.getInstance();
			currentDate = Calendar.getInstance();
			PaxTraxLog.logDebug("Current Time is :" + currentDate.getTime());
			currentDate.set(Calendar.MINUTE, currentDate.get(Calendar.MINUTE) + 1);
			PaxTraxLog.logDebug("Current Checking Time is :" + currentDate.getTime());

			PaxTraxLog.logDebug("Intl Import Decl Number Hour from DB::" + nHour + "::Minute::" + nMinute + "::Second::" + nSecond);

			startAsDate.set(Calendar.HOUR_OF_DAY, nHour);
			startAsDate.set(Calendar.MINUTE, nMinute);
			startAsDate.set(Calendar.SECOND, nSecond);
			PaxTraxLog.logDebug("Actual Intl Import Decl Number Scheduled Time is :" + startAsDate.getTime());

			if (startAsDate.before(currentDate))
			{
				startAsDate.set(Calendar.DATE,currentDate.get(Calendar.DATE) + 1);
				PaxTraxLog.logDebug("Intl Import Decl Number ReSchedule Time is : " + startAsDate.getTime());
			}

			Date firstTime = startAsDate.getTime();

			schedulerPeriodAsLong = Long.parseLong(schedulerPeriod);

			// fdelay is the default for timer
			if (!(scheduleType.equalsIgnoreCase("frate") || scheduleType.equalsIgnoreCase("fdelay")))
			{
				scheduleType = "fdelay";
			}

			TimerTask importDeclTask = (TimerTask) (Class.forName(schedulerClassName).newInstance());

			if (scheduleType.equalsIgnoreCase("fdelay"))
			{
				importUploadTimer.schedule(importDeclTask, firstTime, schedulerPeriodAsLong);
			}
			else
			{
				importUploadTimer.scheduleAtFixedRate(importDeclTask, firstTime, schedulerPeriodAsLong);
			}
		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError("Intl Import Decl Number Scheduler time period format in  Data PaxTraxConfig.properties ",nfe);
		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError("Intl Import Decl Number Scheduler implementataion class could not be found",cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError("Error reading PaxTraxConfig.properties for Intl Import Decl Number Scheduler"+ ptcfe.getMessage());
		}
		catch (SQLException e)
		{
			PaxTraxLog.logError("SQLException " + e.getMessage());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			PaxTraxLog.logError("Error in Starting the Intl Import Decl Number Scheduler " + e.getMessage());
		}

		/* End of code added on August 28, 2006 */		
		finally
		{
			try
			{
				if (s != null)
				{
					s.close();
				}
				if (rs != null)
				{
					rs.close();
				}
				if (con != null)
				{
					con.close();
				}
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
			}
		}
// Added for CR 250 changes on July 28,2007 -- Begin
	   Connection con1 = null;
	   Statement s1 = null;
	   ResultSet rs1 = null;
		// TB_NACCS_GENERATED_FLIGHTS table Purge Scheduler
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::OverridePurge::Begin");
			DBUtil dbUtil = null;
			
			String schedulerClassName = null;
			Calendar startAsDate = null;
			Calendar currentDate = null;
			String purgeScheduleType = null;
			String purgeStartTime = null;
			
			long purgePeriod = 0;
			int nHour = 0;
			int nMinute = 0;
			int nSecond = 0;
						
			/* Connect to the databse to get the purge scheduler configuration */
			dbUtil = DBUtil.getInstance();
			con1 = dbUtil.getConnection();
			s1 = con1.createStatement();
			rs1 = s1.executeQuery(SQLConstants.SELECT_CONTROL_PARAMS);
			PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::OverridePurge::SELECTquery"+SQLConstants.SELECT_CONTROL_PARAMS);
			
			if(rs1.next())
			{
				PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::OverridePurge::Inside resultset");
				schedulerClassName = rs1.getString(1);
				purgeStartTime = rs1.getString(2);
				purgePeriod = rs1.getLong(3);
				rs1.close();
			}
			else
			{
				schedulerClassName = PaxTraxConfig.getProperty("scheduler.purge.override.scheduler.classname");
				purgeStartTime =	PaxTraxConfig.getProperty("scheduler.purge.override.schedule.time");
				purgePeriod = Long.parseLong(PaxTraxConfig.getProperty("scheduler.purge.override.scheduler.period"));
			}			
			
			Timer purgeTimer = new Timer();
			timers.add(purgeTimer);

			nHour = Integer.parseInt(purgeStartTime.substring(0,2));
			nMinute = Integer.parseInt(purgeStartTime.substring(3,5));
			nSecond = Integer.parseInt(purgeStartTime.substring(6,8));
			
			purgeScheduleType = PaxTraxConfig.getProperty("scheduler.purge.override.scheduler.type");
			PaxTraxLog.logDebug("ENTERED INTO override purge Scheduler name " + schedulerClassName);
			PaxTraxLog.logDebug("Override Purge Period is " + purgePeriod);

			currentDate = Calendar.getInstance();
			PaxTraxLog.logDebug("Current Time is ::" + currentDate.getTime());

			currentDate.set(Calendar.MINUTE,currentDate.get(Calendar.MINUTE) + 1);
			PaxTraxLog.logDebug("Current Checking Time is :" + currentDate.getTime());



			PaxTraxLog.logDebug("Override Purge Hour from property file-::"+ nHour+ "::Minute::"+ nMinute
					+ "::Second::"+ nSecond);
					
			startAsDate = Calendar.getInstance();
			startAsDate.set(Calendar.HOUR_OF_DAY, nHour);
			startAsDate.set(Calendar.MINUTE, nMinute);
			startAsDate.set(Calendar.SECOND, nSecond);
			PaxTraxLog.logDebug("Actual Override Purge Scheduled Time is :"+ startAsDate.getTime());

			if (startAsDate.before(currentDate))
			{
				startAsDate.set(Calendar.DATE,currentDate.get(Calendar.DATE) + 1);
				PaxTraxLog.logDebug("purge ReSchedule Time is      : "+ startAsDate.getTime());
			}

			Date firstTime = startAsDate.getTime();

			//     fdelay is the default for timer

			if (!(purgeScheduleType.equalsIgnoreCase("frate")
				|| purgeScheduleType.equalsIgnoreCase("fdelay")))
			{
				purgeScheduleType = "fdelay";
			}

			TimerTask purgeTask = (TimerTask) (Class.forName(schedulerClassName).newInstance());

			if (purgeScheduleType.equalsIgnoreCase("fdelay"))
			{
				purgeTimer.schedule(purgeTask, firstTime, purgePeriod);
			}
		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in Override Purge Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The Override purge scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for Override Purge Scheduler"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the Override Purge Scheduler" + e.getMessage());

		}

// Added for CR 250 changes on July 28,2007 -- End
 
		
		finally
		{
			try
			{
				if (s1 != null)
				{
					s1.close();
					s1 = null;
				}
				if (rs1 != null)
				{
					rs1.close();
					rs1 = null;
				}
				if (con1 != null)
				{
					con1.close();
					con1 = null;
				}				
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
			}
		}


// Added for CR1832 starts
		Connection con2 = null;
		 Statement s2 = null;
		 ResultSet rs2 = null;
		// TB_FLIGHT_OVERRIDE table Purge Scheduler
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::TACommChange::Begin" + PaxTraxConfig.getProperty("scheduler.purge.flight.scheduler.classname"));
			DBUtil dbUtil = null;
			String schedulerClassName = null;

			Calendar currentDate = null;

			long purgePeriod = 24 * 60 *60*1000;
			Calendar startAsDate = null;
			Timer purgeTimer = new Timer();
			startAsDate = Calendar.getInstance();
			//startAsDate.set(Calendar.MINUTE,startAsDate.get(Calendar.MINUTE) + 1);
			
			int lHour = 23,lMinute = 30,lSecond =00;
			
			startAsDate.set(Calendar.HOUR_OF_DAY, lHour);
			startAsDate.set(Calendar.MINUTE, lMinute);
			startAsDate.set(Calendar.SECOND, lSecond);
			
		
			Date firstTime = startAsDate.getTime();
			schedulerClassName = "com.dfs.paxtrax.commtracking.action.TACommissionTrackingReportGenerator";
			TimerTask purgeTask = (TimerTask) (Class.forName(schedulerClassName).newInstance());
			PaxTraxLog.logDebug("Actual TACommChange Purge Scheduled Time is :"+ startAsDate.getTime());
			PaxTraxLog.logDebug("TACommChange Purge Period in millisec is :"+ purgePeriod);
		//	if (purgeScheduleType.equalsIgnoreCase("fdelay"))
		//	{
			purgeTimer.scheduleAtFixedRate(purgeTask, firstTime, purgePeriod);
		//	}
		PaxTraxLog.logDebug("Scheduled for TACOMMCHANGE : " + schedulerClassName);
		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in TACommChange Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The TACommChange scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for TACommChange Scheduler"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the TACommChange Scheduler" + e.getMessage());

		}
		
		finally
		{
			try
			{
				if (rs2 != null)
				{
					rs1.close();
					rs1 = null;
				}				
				if (s2 != null)
				{
					s1.close();
					s1 = null;
				}

				if (con2 != null)
				{
					con1.close();
					con1 = null;
				}				
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
			}
		}

// Added for CR1832 ends
 
// Added for CR1832 starts
  /* Connection con2 = null;
	   Statement s2 = null;
	   ResultSet rs2 = null;*/
		// TB_FLIGHT_OVERRIDE table Purge Scheduler
		try
		{
			PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::VisitChange::Begin" + PaxTraxConfig.getProperty("scheduler.purge.flight.scheduler.classname"));
			DBUtil dbUtil = null;
			
			String schedulerClassName = null;
	//		Calendar startAsDate = null;
			Calendar currentDate = null;
	
			
		/*	int nHour = 0;
			int nMinute = 0;
			int nSecond = 0;*/
						
			/* Connect to the databse to get the purge scheduler configuration */
			//dbUtil = DBUtil.getInstance();
			//con1 = dbUtil.getConnection();
			//s1 = con1.createStatement();
			//rs1 = s1.executeQuery(SQLConstants.SELECT_FLIGHT_CONTROL_PARAMS);
//			PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::FlightPurge::SELECTquery"+SQLConstants.SELECT_FLIGHT_CONTROL_PARAMS);
			

			long purgePeriod = 24 * 60 * 60 * 1000;
			Calendar startAsDate = null;
			Timer purgeTimer = new Timer();
			startAsDate = Calendar.getInstance();
			//startAsDate.set(Calendar.MINUTE,startAsDate.get(Calendar.MINUTE) + 1);
				
			int lHour = 23,lMinute = 30,lSecond =00;
			
			startAsDate.set(Calendar.HOUR_OF_DAY, lHour);
			startAsDate.set(Calendar.MINUTE, lMinute);
			startAsDate.set(Calendar.SECOND, lSecond);	
			
			Date firstTime = startAsDate.getTime();
			schedulerClassName = "com.dfs.paxtrax.commtracking.action.VisitTrackingReportGenerator";
			TimerTask purgeTask = (TimerTask) (Class.forName(schedulerClassName).newInstance());
			PaxTraxLog.logDebug("Actual VisitChange Purge Scheduled Time is :"+ startAsDate.getTime());
			PaxTraxLog.logDebug("VisitChange Purge Period in millisec is :"+ purgePeriod);
		//	if (purgeScheduleType.equalsIgnoreCase("fdelay"))
		//	{
			purgeTimer.scheduleAtFixedRate(purgeTask, firstTime, purgePeriod);
		//	}
		PaxTraxLog.logDebug("Scheduled for VisitChange : " + schedulerClassName);
		}
		catch (NumberFormatException nfe)
		{
			PaxTraxLog.logError(
				"Error in VisitChange Scheduler time period format in  Data PaxTraxConfig.properties ",
				nfe);

		}
		catch (ClassNotFoundException cfe)
		{
			PaxTraxLog.logError(
				"The VisitChange scheduler implementataion class could"
					+ " not be found",
				cfe);
		}
		catch (PaxTraxConfigFileException ptcfe)
		{
			PaxTraxLog.logError(
				"Error reading PaxTraxConfig.properties for VisitChange Scheduler"
					+ ptcfe.getMessage());
		}
		catch (Exception e)
		{
			PaxTraxLog.logError(
				"Error in Starting the VisitChange Scheduler" + e.getMessage());

		}
		
		finally
		{
			try
			{
				if (rs2 != null)
				{
					rs1.close();
					rs1 = null;
				}				
				if (s2 != null)
				{
					s1.close();
					s1 = null;
				}

				if (con2 != null)
				{
					con1.close();
					con1 = null;
				}				
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
			}
		}

// Added for CR1832 ends
 
//Added for CR1832 starts -- for PAx Changes Report Scheduler logic

	try
	{
		PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::PaxChange::Begin" + PaxTraxConfig.getProperty("scheduler.purge.flight.scheduler.classname"));
		DBUtil dbUtil = null;
			
		String schedulerClassName = null;
		Calendar currentDate = null;
	
		long purgePeriod = 24 * 60* 60*1000;
		Calendar startAsDate = null;
		Timer purgeTimer = new Timer();
		startAsDate = Calendar.getInstance();
	
		int lHour = 23,lMinute = 30,lSecond =00;
		startAsDate.set(Calendar.HOUR_OF_DAY, lHour);
		startAsDate.set(Calendar.MINUTE, lMinute);
		startAsDate.set(Calendar.SECOND, lSecond);

		Date firstTime = startAsDate.getTime();
		schedulerClassName = "com.dfs.paxtrax.passenger.action.PaxTrackingReportGenerator";
		TimerTask purgeTask = (TimerTask) (Class.forName(schedulerClassName).newInstance());
		PaxTraxLog.logDebug("Actual PaxChange Purge Scheduled Time is :"+ startAsDate.getTime());
		PaxTraxLog.logDebug("PaxChange Purge Period in millisec is :"+ purgePeriod);
	//	if (purgeScheduleType.equalsIgnoreCase("fdelay"))
	//	{
		purgeTimer.scheduleAtFixedRate(purgeTask, firstTime, purgePeriod);
	//	}
	PaxTraxLog.logDebug("Scheduled for PaxChange : " + schedulerClassName);
	}
	catch (NumberFormatException nfe)
	{
		PaxTraxLog.logError(
			"Error in PaxChange Scheduler time period format in  Data PaxTraxConfig.properties ",
			nfe);

	}
	catch (ClassNotFoundException cfe)
	{
		PaxTraxLog.logError(
			"The PaxChange scheduler implementataion class could"
				+ " not be found",
			cfe);
	}
	catch (PaxTraxConfigFileException ptcfe)
	{
		PaxTraxLog.logError(
			"Error reading PaxTraxConfig.properties for PaxChange Scheduler"
				+ ptcfe.getMessage());
	}
	catch (Exception e)
	{
		PaxTraxLog.logError(
			"Error in Starting the PaxChange Scheduler" + e.getMessage());

	}
		
	finally
	{
		try
		{
			if (rs2 != null)
			{
				rs1.close();
				rs1 = null;
			}				
			if (s2 != null)
			{
				s1.close();
				s1 = null;
			}

			if (con2 != null)
			{
				con1.close();
				con1 = null;
			}				
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
		}
	}


//Added for CR 1832 ends

	// By Faheem for Flight upload to Wincor
	DBUtil dbUtil = null;	
	Connection con3 = null;	
	Statement stmt2 = null;
	ResultSet rs3 = null;	
					  
					  try
					  {
						  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::flight Upload ::Begin");
						  String flightUploadClassName = null;
						  Calendar flightUploadStartAsDate = null;
						  String flightUploadStartTime = null;
			
						  long uploadPeriod = 0;
						  int nHour = 0;
						  int nMinute = 0;
						  int nSecond = 0;
			
						  /* Connect to the database to get the flight Upload scheduler configuartion */
						  dbUtil = DBUtil.getInstance();
						  con3 = dbUtil.getConnection();
						  stmt2 = con3.createStatement();
						  rs3 = stmt2.executeQuery("SELECT PAX_SCHEDULER_CLASS_NAME, PAX_SCHEDULER_TIME, PAX_SCHEDULER_PERIOD FROM TB_WINCOR_UPLOAD_MSTR WHERE UPLOAD_TYPE = 'Flight'");
					 
						 if(rs3!=null && rs3.next())
						 {
							flightUploadClassName = rs3.getString(1);
							flightUploadStartTime = rs3.getString(2);
							 uploadPeriod = rs3.getLong(3);
				
							rs3.close();
						 }
						 else
						 {
							flightUploadClassName = PaxTraxConstants.FLIGHT_SCHE_CLASS_NAME;
							flightUploadStartTime = PaxTraxConstants.FLIGHT_SCHE_EXEC_TIME;
							 uploadPeriod = PaxTraxConstants.FLIGHT_SCHE_PERIOD;
						 }
				
						rs3 = null;
						  stmt2.close();
						  stmt2 = null;
						  con3.close();
						  con3 = null;
			
						  Timer flightUploadTimer = new Timer();
						  timers.add(flightUploadTimer);
			
						  nHour = Integer.parseInt(flightUploadStartTime.substring(0,2));
						  nMinute = Integer.parseInt(flightUploadStartTime.substring(3,5));
						  nSecond = Integer.parseInt(flightUploadStartTime.substring(6,8));

						flightUploadStartAsDate = Calendar.getInstance();
						  Calendar currentDate = Calendar.getInstance();
						  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload scheduler::Current Time is:" + currentDate.getTime());

						  currentDate.set(Calendar.MINUTE, currentDate.get(Calendar.MINUTE) + 2);
						  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload scheduler::Current Checking Time is :" + currentDate.getTime());

						  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload scheduler::Flight Upload scheduler will run at time - "+ nHour	+ "::Minute::"+ nMinute	+ "::Second::"+ nSecond);

						flightUploadStartAsDate.set(Calendar.HOUR_OF_DAY, nHour);
						flightUploadStartAsDate.set(Calendar.MINUTE, nMinute);
						flightUploadStartAsDate.set(Calendar.SECOND, nSecond);
			 
						  if (flightUploadStartAsDate.before(currentDate))
						  {
							flightUploadStartAsDate.set(Calendar.DATE, currentDate.get(Calendar.DATE) + 1);
							  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload scheduler::Flight Upload scheduler's rescheduled date time is : "+ flightUploadStartAsDate.getTime());
						  }

						  Date firstTime = flightUploadStartAsDate.getTime();
						  TimerTask flightUploadTask = (TimerTask) (Class.forName(flightUploadClassName).newInstance());
						flightUploadTimer.schedule(flightUploadTask, firstTime, uploadPeriod);

					  }
					  catch (NumberFormatException nfe)
					  {
						  PaxTraxLog.logError("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload Scheduler::Error in Excp Report Scheduler ",nfe);
					  }
					  catch (ClassNotFoundException cfe)
					  {
						  PaxTraxLog.logError("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload Scheduler::The Flight Upload Scheduler implementataion class could not be found",cfe);
					  }
					  catch (Exception e)
					  {
						  PaxTraxLog.logError("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload Scheduler::Flight Upload Scheduler in Starting the Flight Scheduler:" + e);
					  }
					  finally
					  {
						  try
						  {
							  if(rs3!=null)
							  {
								  rs3.close();
								  rs3 = null;
							  }
				
							  if(stmt2!=null)
							  {
								  stmt2.close();
								  stmt2 = null;
							  }
				
							  if(con3!=null)
							  {
								  con3.close();
								  con3 = null;
							  }
						  }
						  catch(SQLException sqle)
						  {
				
						  }
						  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::Flight Upload Scheduler::End");			
					  }	
					  
					  // By Faheem for Postal Code upload to Wincor	
		Connection con4 = null;	
		Statement stmt3 = null;
		ResultSet rs4 = null;	
					  
						  try
						  {
							  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::Postal Code Upload ::Begin");
							  String postCodeUploadClassName = null;
							  Calendar postCodeUploadStartAsDate = null;
							  String postCodeUploadStartTime = null;
			
							  long uploadPeriod = 0;
							  int nHour = 0;
							  int nMinute = 0;
							  int nSecond = 0;
			
							  /* Connect to the database to get the postcode Upload scheduler configuartion */
							  dbUtil = DBUtil.getInstance();
							  con4 = dbUtil.getConnection();
							  stmt3 = con4.createStatement();
							  rs4 = stmt3.executeQuery("SELECT PAX_SCHEDULER_CLASS_NAME, PAX_SCHEDULER_TIME, PAX_SCHEDULER_PERIOD FROM TB_WINCOR_UPLOAD_MSTR WHERE UPLOAD_TYPE = 'PostalCode'");
					 
							 if(rs4!=null && rs4.next())
							 {
								postCodeUploadClassName = rs4.getString(1);
								postCodeUploadStartTime = rs4.getString(2);
								 uploadPeriod = rs4.getLong(3);
				
								rs4.close();
							 }
							 else
							 {
								postCodeUploadClassName = PaxTraxConstants.POSTCODE_SCHE_CLASS_NAME;
								postCodeUploadStartTime = PaxTraxConstants.POSTCODE_SCHE_EXEC_TIME;
								 uploadPeriod = PaxTraxConstants.POSTCODE_SCHE_PERIOD;
							 }
				
							rs4 = null;
							  stmt3.close();
							  stmt3 = null;
							  con4.close();
							  con4 = null;
			
							  Timer postCodeUploadTimer = new Timer();
							  timers.add(postCodeUploadTimer);
			
							  nHour = Integer.parseInt(postCodeUploadStartTime.substring(0,2));
							  nMinute = Integer.parseInt(postCodeUploadStartTime.substring(3,5));
							  nSecond = Integer.parseInt(postCodeUploadStartTime.substring(6,8));

							postCodeUploadStartAsDate = Calendar.getInstance();
							  Calendar currentDate = Calendar.getInstance();
							  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload scheduler::Current Time is:" + currentDate.getTime());

							  currentDate.set(Calendar.MINUTE, currentDate.get(Calendar.MINUTE) + 2);
							  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload scheduler::Current Checking Time is :" + currentDate.getTime());

							  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload scheduler::PostalCode Upload scheduler will run at time - "+ nHour	+ "::Minute::"+ nMinute	+ "::Second::"+ nSecond);

							postCodeUploadStartAsDate.set(Calendar.HOUR_OF_DAY, nHour);
							postCodeUploadStartAsDate.set(Calendar.MINUTE, nMinute);
							postCodeUploadStartAsDate.set(Calendar.SECOND, nSecond);
			 
							  if (postCodeUploadStartAsDate.before(currentDate))
							  {
								postCodeUploadStartAsDate.set(Calendar.DATE, currentDate.get(Calendar.DATE) + 1);
								  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload scheduler::PostalCode Upload scheduler's rescheduled date time is : "+ postCodeUploadStartAsDate.getTime());
							  }

							  Date firstTime = postCodeUploadStartAsDate.getTime();
							  TimerTask postCodeUploadTask = (TimerTask) (Class.forName(postCodeUploadClassName).newInstance());
							postCodeUploadTimer.schedule(postCodeUploadTask, firstTime, uploadPeriod);

						  }
						  catch (NumberFormatException nfe)
						  {
							  PaxTraxLog.logError("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload Scheduler::Error in Excp Report Scheduler ",nfe);
						  }
						  catch (ClassNotFoundException cfe)
						  {
							  PaxTraxLog.logError("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload Scheduler::The PostalCode Upload Scheduler implementataion class could not be found",cfe);
						  }
						  catch (Exception e)
						  {
							  PaxTraxLog.logError("PaxTrax::PaxTraxStartUpServlet::init::PostalCode Upload Scheduler::PostalCode Upload Scheduler in Starting the Flight Scheduler:" + e);
						  }
						  finally
						  {
							  try
							  {
								  if(rs3!=null)
								  {
									  rs3.close();
									  rs3 = null;
								  }
				
								  if(stmt2!=null)
								  {
									  stmt2.close();
									  stmt2 = null;
								  }
				
								  if(con3!=null)
								  {
									  con3.close();
									  con3 = null;
								  }
							  }
							  catch(SQLException sqle)
							  {
				
							  }
							  PaxTraxLog.logDebug("PaxTrax::PaxTraxStartUpServlet::init::PostCode Upload Scheduler::End");			
						  }			

	}


	private FTPConfig getNACCSFTPParameters() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTraxStartUpServlet ::getNACCSFTPParameters::Begin");
		FTPConfig ftpConfig = null;
		ResultSet rs = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = null;
		Statement statement = null;

		try
		{
			connection = dbUtil.getConnection();
			statement = connection.createStatement();
			rs =
				statement.executeQuery(
					SQLConstants.SELECT_NACCS_FTP_PARAMETERS);

			if (rs != null)
			{
				ftpConfig = new FTPConfig();
				while (rs.next())
				{
					/*  ftpConfig.setRemoteHost(rs.getString(1));
						ftpConfig.setUserName(rs.getString(2));
						ftpConfig.setPassword(rs.getString(3));
						ftpConfig.setSourceDirectory(rs.getString(4));
						ftpConfig.setDestinationDirectory(rs.getString(5));
						ftpConfig.setRemoteDirectory(rs.getString(6));
						ftpConfig.setTransferMode(rs.getString(7));
						ftpConfig.setFtpPort("" + rs.getInt(8));
						ftpConfig.setPcAcknowledgeSourceDir(rs.getString(11));
						ftpConfig.setPcAcknowledgeMoveDir(rs.getString(12));
						ftpConfig.setEsAcknowledgeDestDir(rs.getString(13));
						ftpConfig.setEsAcknowledgeMoveDir(rs.getString(14));
					*/

					ftpConfig.setNaccsFTPFrequency(rs.getInt(11));
					ftpConfig.setNaccsGenerationFrequency(rs.getInt(12));
					ftpConfig.setEntryNoUploadFrequency(rs.getInt(17));

				}
			}
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			throw new PaxTraxSystemException(sqle);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new PaxTraxSystemException(e);
		}
		finally
		{
			try
			{
				if (statement != null)
				{
					statement.close();
				}
				if (rs != null)
				{
					rs.close();
				}
				if (connection != null)
				{
					connection.close();
				}
			}
			catch (SQLException sqle)
			{
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug(
			"PaxTraxStartUpServlet ::getNACCSFTPParameters::End");
		return ftpConfig;

	}

	protected void service(
		HttpServletRequest request,
		HttpServletResponse response)
		throws ServletException, IOException
	{
		throw new ServletException("Do not use.");
	}

	public void destroy()
	{
		// Terminate all scheduled tasks
		if (timers != null)
		{
			int length = timers.size();
			for (int i = 0; i < length; i++)
			{
				Timer timer = (Timer) timers.get(i);
				timer.cancel();
			}
		}
	}

}