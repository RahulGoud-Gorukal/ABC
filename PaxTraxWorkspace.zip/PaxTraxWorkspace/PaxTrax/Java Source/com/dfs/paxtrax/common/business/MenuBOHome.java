package com.dfs.paxtrax.common.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;


/**
 * Home interface for Enterprise Bean: UserBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Sundarrajan.K.	Created   
 */	


public interface MenuBOHome extends EJBHome
{
	/**
	 * Creates a default instance of Session Bean: MenuBO
	 * @return MenuBO Remote interface for this home interface
	 * @throws CreateException This exception is thrown if there is a problem
	 * in creation
	 */
	public com.dfs.paxtrax.common.business.MenuBO create()
		throws CreateException, RemoteException;
}

