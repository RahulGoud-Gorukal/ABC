package com.dfs.paxtrax.common.scheduler;

/*
 * Copyright (c) 2003 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.service.NACCSDelegate;

/**
 * This Scheduler is responsible for Naccs File copy to the
 * folder specified.
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS 
 * 10/06/2004	P.C. Sathish	Created 
 */
public class PaxTraxNaccsCopyScheduler extends TimerTask {

   	private  NACCSDelegate naccsDelegate  = null;
   	private String fileSeparator;
   	private FTPConfig ftpConfig = null;

		
    /**
     * Empty Constructor. This constructor initializes the JMS Queue and the
     * Email Session and Transport.
     * The necessary properties read from the INOConfig.properties file
     * @see com.cts.iknow.util.INOConfig
     */
    public PaxTraxNaccsCopyScheduler() { 
        init();

    }

    private void init() {
    	naccsDelegate = new NACCSDelegate();		
		PaxTraxLog.logDebug( "PaxTraxNaccsCopyScheduler: init(): Initialized NACCS Scheduler");
		fileSeparator = System.getProperty("file.separator");
    }

	public void run() {
		PaxTraxLog.logDebug("PaxTrax::PaxTraxNaccsCopyScheduler::run::Begin");
		String naccsSubmissionDirectory = null;
		String tobesentFilePath = null;
		String sentFilePath = null;
		
		try {
      	    if (ftpConfig == null) {
	        	ftpConfig = naccsDelegate.getNACCSFTPParameters();
	        	PaxTraxLog.logDebug("PaxTraxNACCSFTPScheduler: run(): ftpConfig got created ");
	        } else {
	        	naccsSubmissionDirectory = ftpConfig.getMappedNaccsDestinationDir() + "/";
	        	PaxTraxLog.logDebug("PaxTraxCopyScheduler::run()::naccsSubmissionDirectory = "+naccsSubmissionDirectory);
	        	
	        	tobesentFilePath = ftpConfig.getSourceDirectory();
	        	PaxTraxLog.logDebug("PaxTraxCopyScheduler::run()::tobesentFilePath="+tobesentFilePath);
	        	sentFilePath = ftpConfig.getDestinationDirectory() + "/";
	        	PaxTraxLog.logDebug("PaxTraxCopyScheduler::run()::sentFilePath="+sentFilePath);
	        	
	        	File file = new File(tobesentFilePath);
	        	File fileList[] = file.listFiles();
	        	boolean naccsSubmissionFlag = false;
	        	boolean sentFlag = false;
	        	for (int i = 0; i < fileList.length; i++) {
	        		PaxTraxLog.logDebug("PaxTraxCopyScheduler::run():: file name "+ fileList[i].getName() 
	        				+ " being copied to "+ naccsSubmissionDirectory);
        			String fileName = fileList[i].getName();
					int index = fileName.indexOf(".");
					if (index != -1) {
						fileName = fileName.substring(0, index);									
					}
					// check if the pax exists in the naccs file header table before 
					// updating the sale transaction.
        			boolean paxExists = naccsDelegate.checkPaxExists(fileName);
        			if (paxExists) {
		        		// Copy to the mapped naccs directory. This is the directory which is mapped by the 
		        		// customs team to a folder in windows machine.
						naccsSubmissionFlag = copyFileToNACCS(fileList[i], naccsSubmissionDirectory+fileList[i].getName());
		        		if (naccsSubmissionFlag) {
		        			// Copy from to_be_sent directory to sent directory. Once copied 
		        			// delete the file.
	        				sentFlag = copyFileToNACCS(fileList[i], sentFilePath+fileList[i].getName());
	        				if (sentFlag) {
	        					fileList[i].delete();
	        					naccsDelegate.updateStatus(fileName);
	        				}
	        			}
	        		}
	        	}
	        }
		} catch (PaxTraxSystemException e) {
			PaxTraxLog.logError("PaxTraxNaccsCopyScheduler::run()", e);
		}
		PaxTraxLog.logDebug("PaxTrax::PaxTraxNaccsCopyScheduler::run::End");
	}
	
	/**
	 * Copies files from source directory to destination directory.
	 */	
	private boolean copyFileToNACCS(File source,String destination) {
		boolean copyStatus = true;
		try {			
    		BufferedWriter out = new BufferedWriter(new FileWriter(destination), 32768);
      		BufferedReader in = new BufferedReader(new FileReader(source), 32768);
			
			int fileLength = (int) source.length();
			char charBuff[] = new char[fileLength];
			
			while (in.read(charBuff,0,fileLength) != -1) {
				out.write(charBuff,0,fileLength);
			}  
			in.close();	
	        out.close();
	        out = null;
			in = null;
		} catch (IOException e) {
			copyStatus = false;
			PaxTraxLog.logError("PaxTrax::PaxTraxNaccsCopyScheduler::copyFileToNACCS:: IOException ", e);
		}
		
		return copyStatus;
	}

}
