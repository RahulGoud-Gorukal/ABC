/*********************************************************************************
*  PROGRAM NAME		:  FTP_exception
*  NAME OF AUTHOR	:  Bipin
*  DATE OF CREATION	:  25/06/2004
*  DESCRIPTION	    :  This will get the selected files from the Report server.
*  VERSION		    :  1.0
*  CTS All rights reserved
This is the class created to download a file through the FTP from the document
Server,selected from the document list Tree

 *  FTP specific exceptions

REVISION HISTORY

| Date	 |	Programmer name   |  Ver  |  Change history
---------------------------------------------------------------------------------------------------------
|        |                    |       |
--------------------------------------------------------------------------------------------------------
*/
package com.dfs.paxtrax.common.util.ftp;
 public class FTP_exception extends Exception {

    /**
     *  Integer reply code
     */
    private int replyCode = -1;

    /**
     *   Constructor. Delegates to super.
     *
     *   @param   msg   Message that the user will be
     *                  able to retrieve
     */
    public FTP_exception(String msg) {
        super(msg);
    }
    /**
     *  Constructor. Permits setting of reply code
     *
     *   @param   msg        message that the user will be
     *                       able to retrieve
     *   @param   replyCode  string form of reply code
     */
    public FTP_exception(String msg, String replyCode) {

        super(msg);

        // extract reply code if possible
        try {
            this.replyCode = Integer.parseInt(replyCode);
        }
        catch (NumberFormatException ex) {
            this.replyCode = -1;
        }
    }
    /**
     *   Get the reply code if it exists
     *
     *   @return  reply if it exists, -1 otherwise
     */
    public int getReplyCode() {
        return replyCode;
    }
}
