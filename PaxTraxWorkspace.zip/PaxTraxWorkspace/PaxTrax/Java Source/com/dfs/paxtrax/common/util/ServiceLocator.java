package com.dfs.paxtrax.common.util;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

 
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;


/**
 * A class that gives EJB home object
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */	

public class ServiceLocator 
{
    //This contains the instance of ServiceLocator class 
    private static ServiceLocator serviceLocator = null;

    /**
     * Creates an instance of ServiceLocator only if the instance does not
     * exist.
     * 
     * @return ServiceLocator Returns the ServiceLocator instance
     */
    public static ServiceLocator getInstance() 
    {
        if (serviceLocator == null) 
        {
            initializeInstance();
        }
        return serviceLocator;
    }

	/**
	 * Sets the ServiceLocator class instance
	 */
	private static synchronized void initializeInstance() 
	{
        if (serviceLocator == null) 
        {
            serviceLocator = new ServiceLocator();
        }
	}
    
    /**
     * Constructor for this class
     */
    private ServiceLocator() 
    {

    }

	public Object getEJBHome(String jndiName) throws NamingException
	{
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, 
			PaxTraxConstants.WEBSPHERE_NAMING);
			
		InitialContext ic = new InitialContext(env);
		Object home = ic.lookup(jndiName);
		return home;		
	}
}