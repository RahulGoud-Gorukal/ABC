/*********************************************************************************************
*  PROGRAM NAME		:  FTPConnectMOde
*  NAME OF AUTHOR	:  Bipin
*  DATE OF CREATION	:  25/06/2004
*  DESCRIPTION	    :  This will get the selected files from the Report server.
*  VERSION		    :  1.0
*  CTS All rights reserved

 *  Enumerates the connect modes that are possible,
 *  active & PASV


REVISION HISTORY

| Date	 |	Programmer name   |  Ver  |  Change history
---------------------------------------------------------------------------------------------------------
|        |                    |       |
--------------------------------------------------------------------------------------------------------
*/
package com.dfs.paxtrax.common.util.ftp;
 public class FTP_connectmode {

     /**
      *  Revision control id
      */
     private static String cvsId = "$Id: FTPConnectMode.java,v 1.1 2001/10/09 20:53:46 bruceb Exp $";

     /**
      *   Represents active connect mode
      */
     public static FTP_connectmode ACTIVE = new FTP_connectmode();

     /**
      *   Represents PASV connect mode
      */
     public static FTP_connectmode PASV = new FTP_connectmode();


     /**
      *  Private so no-one else can instantiate this class
      */
     private FTP_connectmode() {
     }
}
