package com.dfs.paxtrax.common.exception;

/**
 * System application General Exception, should be used while throwing system exception
 *
 * @author    Pankaj Dubey (Cognizant)
 * @created   March 22, 2004
 */
public class PaxTraxSystemException extends PaxTraxException {


    /**
     * Constructor accepts actual exception object
     *
     * @param actualException Exception   Actual Exception
     */
    public PaxTraxSystemException( Exception actualException) {

        super(PaxTraxErrorMessages.PT_SYSEXCEPTION, actualException);
    }
    
    /**
     * Constructor accepts error code
     *
     * @param actualException Exception   Actual Exception
     */
    public PaxTraxSystemException( int errorCode) {

        super(errorCode);
    }

}
