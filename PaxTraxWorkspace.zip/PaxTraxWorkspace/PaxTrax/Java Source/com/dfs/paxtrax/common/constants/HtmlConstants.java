package com.dfs.paxtrax.common.constants;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


/**
 * This class holds all html constants 
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */

public class HtmlConstants 
{
	/**
	 * Holds anchor start
	 */
    public static final String ANCHOR_START = "<a>";

    /**
     * Holds ancor end
     */
    public static final String ANCHOR_END = "</a>";
    
	/**
	 * Holds ahref 
	 */
    public static final String AHREF_START = "<a href=\"";

    /**
     * Holds the Header line of HTML
     */
    public static final String HEADER = "<HR>";

    /**
     * Holds the table row HTML tag
     */
    public static final String TABLE_ROW = "<TR>";

	/**
	 * Holds the end of table row HTML tag
	 */
    public static final String END_TABLE_ROW = "</TR>";

    /**
     * Holds the Bold HTML tag
     */
    public static final String BOLD = "<B>";

    /**
     * Holds the table HTML tag
     */
    public static final String TABLE = "<TABLE>";

    /**
     * Holds the end of table HTML tag
     */
    public static final String END_TABLE = "</TABLE>";

    /**
     * Holds the center HTML tag
     */
    public static final String CENTER = "<CENTER>";

    /**
     * Holds the end of center HTML tag
     */
    public static final String END_CENTER = "</CENTER>";

    /**
     * Holds the tag to define width for the TD
     */
    public static final String WIDTH = "<td align=center width=";

    /**
     * Holds checked status of checkbox.
     */
    public static final String CHECKED = " CHECKED ";

   	/**
   	 * Holds the Hidden variable
   	 */
    public static final String HIDDEN_VARIABLE = "<INPUT TYPE=hidden NAME=\"";

    /**
     * Holds blank space string
     */
	public static final String HTML_SPACE = "&nbsp;";

	/**
	 * Holds Paragraph end string
	 */
	public static final String PARA_END = "</P>";

    /**
     * Holds the tag for value
     */
    public static final String VALUE = "\" value=\"";

    /**
     * Holds the escape string
     */
    public static final String ESCAPE = "\"";

    /**
     * Holds the end escape string
     */
    public static final String ESCAPE_END = "\">";

    /**
     * Holds value of Table width
     */
    public static final String TABLE_WIDTH = "<TABLE width=\"100%\">";

    /**
     * Holds the tag for align table data
     */
    public static final String TABLE_DATA_ALIGN = "<TD ALIGN=CENTER";

   	/**
     * Holds the start tag for Javascript
     */
    public static final String START_JAVASCRIPT = 
    	"<SCRIPT LANGUAGE=\"javascript1.2\" TYPE=\"text/javascript\" SRC=\"";
    /**
     * Holds the end tag for Javascript
     */
    public static final String END_JAVASCRIPT = "</SCRIPT>";


    /**
     * Constructor for this class
     */
    private HtmlConstants() 
    {

    }
}
