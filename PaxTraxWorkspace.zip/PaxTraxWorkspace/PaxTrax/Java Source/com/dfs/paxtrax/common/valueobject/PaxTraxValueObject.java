package com.dfs.paxtrax.common.valueobject;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.io.Serializable;


/**
 * Common value object class which is extended by all value objects
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */


public class PaxTraxValueObject implements Serializable
{
	public int serialNo = 0;
	
	public String user = null;

	public String clientMachine = null;
	

	/**
	 * Returns the serialNo.
	 * @return int
	 */
	public int getSerialNo()
	{
		return serialNo;
	}

	/**
	 * Sets the serialNo.
	 * @param serialNo The serialNo to set
	 */
	public void setSerialNo(int serialNo)
	{
		this.serialNo = serialNo;
	}

	

	/**
	 * Returns the user.
	 * @return String
	 */
	public String getUser()
	{
		return user;
	}

	/**
	 * Sets the user.
	 * @param user The user to set
	 */
	public void setUser(String user)
	{
		this.user = user;
	}

	/**
	 * Returns the clientMachine.
	 * @return String
	 */
	public String getClientMachine()
	{
		return clientMachine;
	}

	/**
	 * Sets the clientMachine.
	 * @param clientMachine The clientMachine to set
	 */
	public void setClientMachine(String clientMachine)
	{
		this.clientMachine = clientMachine;
	}

}
