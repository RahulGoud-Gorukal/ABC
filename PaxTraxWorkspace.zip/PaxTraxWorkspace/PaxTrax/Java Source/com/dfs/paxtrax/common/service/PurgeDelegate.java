
package com.dfs.paxtrax.common.service;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.business.PurgeBO;
import com.dfs.paxtrax.common.business.PurgeBOHome;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;

/* *
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

/**
 * This is delegate class which performs 
 * jndi lookup and it act as a point
 * of entry for business methods.
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 *          DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 *  DATE            USER            COMMENTS
 * 26/05/2004   Joseph Oommen A     Created   
 * 07/28/2007	Uma D			Modified for CR changes
 */

public class PurgeDelegate
{
    
    /*
     * Holds service locator instance
     */
    private ServiceLocator serviceLocator = null;
   
    /*
     * Holds the Home interface
     */
    private PurgeBOHome purgeBOHome = null;
    /*
     * Hold the remote interface
     */
    private PurgeBO purgeBO = null;
    /*
     *Default Construtor for LocationDelegate
     */

    public PurgeDelegate()
    {
    }

    /*
     * Jndi look up is performed here
     */
    private void jndiCall() throws PaxTraxSystemException
    {

        PaxTraxLog.logDebug("PaxTrax::PurgeDelegate::jndiCall::Begin");
        try
        {
            serviceLocator = ServiceLocator.getInstance();
            purgeBOHome =
                (PurgeBOHome) PortableRemoteObject.narrow(
                    serviceLocator.getEJBHome(
                        PaxTraxConstants.PURGE_BO_BEAN_JNDI),
                    PurgeBOHome.class);
        }
        catch (NamingException ne)
        {
            throw new PaxTraxSystemException(ne);
        }
        if (purgeBOHome == null)
        {
            throw new PaxTraxSystemException(
                PaxTraxConstants.PURGE_BO_HOME_NOT_FOUND);
        }
        try
        {
            purgeBO = purgeBOHome.create();
        }
        catch (CreateException ce)
        {
            throw new PaxTraxSystemException(ce);
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug("PaxTrax::PurgeDelegate::jndiCall::End");
    }
    /**
     * Saves location details into the database by 
     * delegating the request to  manager bean. 
     * @param locationBean LocationBean object
     * @throws PaxTraxSystemException
     */
    public void purgeData()
        throws PaxTraxSystemException
    {
        PaxTraxLog.logDebug(
            "PaxTrax::PurgeDelegate::purgeData::Begin");
        if (purgeBOHome == null)
        {
            jndiCall();
        }
        try
        {
            purgeBO.purgeData();
        }
        catch (RemoteException re)
        {
            throw new PaxTraxSystemException(re);
        }
        PaxTraxLog.logDebug(
            "PaxTrax::PurgeDelegate::purgeData::End");
    }
    
//Added for CR 250 changes on July 28,2007 --  Begin

  /**
   * Deletes the Naccs record from the database by 
   * delegating the request to  manager bean. 
   * @throws PaxTraxSystemException
   */
  public void purgeNaccsData()
	  throws PaxTraxSystemException
  {
	  PaxTraxLog.logDebug(
		  "PaxTrax::PurgeDelegate::purgeNaccsData::Begin");
	  if (purgeBOHome == null)
	  {
		  jndiCall();
	  }
	  try
	  {
		  purgeBO.purgeNaccsData();
	  }
	  catch (RemoteException re)
	  {
		  throw new PaxTraxSystemException(re);
	  }
	  PaxTraxLog.logDebug(
		  "PaxTrax::PurgeDelegate::purgeNaccsData::End");
  }    
//Added for CR 250 changes on July 28,2007 --  End

}
