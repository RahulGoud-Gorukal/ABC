package com.dfs.paxtrax.common.scheduler;

/*
 * Copyright (c) 2003 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ftp.FTP_client;


/**
 * Helper Class for  NACCSAcknowledger Scheduler to write and file difference
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/05/2004	Ramesh	Created
 */
public class PaxTraxNACCSAckHelper
{
			/**
		 * Method findFileDifference.
		 * @param naccsFileList
		 * @param essFileList
		 * @return String[]
		 */
		public String[] findFileDifference(String[] naccsFileList, String[] essFileList) 
		{
			Arrays.sort(essFileList);
			ArrayList tempFileList = new ArrayList();
			String temp[] = null;
			for (int i = 0; i < naccsFileList.length; i++ ) 
			{
				String fileName = naccsFileList[i];
				PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: fileDifference(): Searching for file "+ fileName);
				int result = Arrays.binarySearch(essFileList, fileName);	
				PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: fileDifference(): File name result  for file "+ fileName+ " result "+ result);		
				if (result < 0) 
				{
					tempFileList.add(fileName);
				}				
			}
			PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: fileDifference():  TempFile List size "+ tempFileList.size());
			temp = new String[tempFileList.size()];
			for (int j = 0; j < tempFileList.size(); j++)
			{
				temp[j] = (String) tempFileList.get(j);
			}
			PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: fileDifference(): File Array size "+ temp.length);
			return temp;
		}
		
		/**
		 * Method writeFiles.
		 * @param fileArray
		 * @param ftp
		 */
		public void writeFiles(String[] fileArray, FTP_client ftp, String essrcDir,String naccsSrcDir) 
		{
        		int fileLength = 0;
        		byte byteBuff[] = null;
        		boolean ftpSuccess = true;
        		String fullPath = null;
		        File naccsFile = null;
		        FileInputStream iStream  = null;       	          	    	
				try 
				{
        				int fileCnt = fileArray.length;       				
        				for (int k =0; k < fileCnt; k++)
        					{	        		
        						PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():The Value of K ** is "+k+": file count = "+fileArray.length);
        						String fileName = naccsSrcDir+"/"+fileArray[k];
				        		naccsFile = new File(fileName);
				        		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles() :Fiile Name is ..... "+fileName);
				        		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles() :Inside the for loop..... "+naccsFile.getName());
				        		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():The Length of the naccs File "+naccsFile.length());
				        		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():Before Reading the InputStream");
				        		// Ftp From NACCS 
				        		String source = essrcDir+"/"+fileArray[k];
				        		String destination = fileArray[k];
				        		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():ftp get source file = "+source+"Naccs File Name = "+destination);
								ftpCopyFile(ftp,source,destination);		
								ftpDeleteFile(ftp,destination);	        		
				        		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():after ftp ");			        		
        					}
      						PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():calling deleteNaccsFiles() ");			        		
        					//deleteNaccsFiles(fileArray,ftp);
							PaxTraxLog.logDebug("PaxTraxNACCSAckHelper: writeFiles():after calling deleteNaccsFiles() ");			        		
        					
			}
			catch (Exception e) 
			{
				PaxTraxLog.logError("PaxTraxNACCSAckHelper: writeFiles():Exception ",e);			
				e.printStackTrace();
			}
			
		}		
		
		/**This method will delete the files in naccsPC src directory after moving to ES Soucre Dir
		 * Method deleteNaccsFiles.
		 * @param ftp
		 * @param naccsSrcDir
		 */
		private void deleteNaccsFiles(String[] fileArray, FTP_client ftp) 
		{
			PaxTraxLog.logDebug("PaxTraxNACCSAckHelper DeleteNaccsFile"+fileArray.length)	;   				
			try
			{
					for (int i=0;i<fileArray.length;i++)
					{
						PaxTraxLog.logDebug("PaxTraxNACCSAckHelper Deleting NaccsFile "+fileArray[i])	; 		  					
		//				ftp.delete(fileArray[i]);
						ftpDeleteFile(ftp,fileArray[i]);
				
						PaxTraxLog.logDebug("PaxTraxNACCSAckHelper After DeleteNaccsFile "+fileArray[i])	;   				
					}
			}
			catch(Exception e)
			{
					PaxTraxLog.logError("Exception in PaxTraxNACCSAckHelper : DeleteNaccsFiles() while deleting the file "+e);
			}
			
		}
		
		/**
		 * Method ftpDeleteFile.
		 * @param ftp
		 * @param fileName
		 */
		private void ftpDeleteFile(FTP_client ftp,String fileName)
		{
			 	PaxTraxLog.logDebug("PaxTraxNACCSAckHelper : ftpDeleteFile() :Delete File Name is  "+fileName);
				try
				{
					PaxTraxLog.logDebug("PaxTraxNACCSAckHelper : ftpDeleteFile() :B4 Try block Delete File Name is  "+fileName);	
					ftp.delete(fileName);
					PaxTraxLog.logDebug("PaxTraxNACCSAckHelper : ftpDeleteFile() :After Try block Delete File Name is  "+fileName);	
				}
				catch(Exception e)
				{
					PaxTraxLog.logError("Exception in PaxTraxNACCSAckHelper : ftpDeleteFile() : Error occured  "+e);
				}
					
		}
		
	/**
	 * Method ftpCopyFile.
	 * @param ftp
	 * @param source
	 * @param destination
	 */
	private void ftpCopyFile(FTP_client ftp,String source,String destination)
	{
		PaxTraxLog.logDebug("PaxTraxNACCSAckHelper:ftpCopyFile()  source is "+source +" destination is "+destination);
		try
		{
			PaxTraxLog.logDebug("PaxTraxNACCSAckHelper:Inside Try Block ");
			ftp.get(source, destination);
			PaxTraxLog.logDebug("PaxTraxNACCSAckHelper:After Try Block ");
		}
		catch(Exception e)
		{
			PaxTraxLog.logError("PaxTraxNACCSAckHelper : ftpCopyFile Exception Occured while copying the file "+e);
		}
	}		
		
}
