package com.dfs.paxtrax.common.exception;

/**
 * @author 107646
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class PaxTraxConfigFileException extends PaxTraxException{

    /**
     * Constructor accepts actual exception object
     *
     * @param actualException Exception   Actual Exception
     */
    public PaxTraxConfigFileException( Exception actualException) {

        super(PaxTraxErrorMessages.PT_CONFIG_EXCEPTION, actualException);
    }
    
    /**
     * Constructor accepts error code
     *
     * @param actualException Exception   Actual Exception
     */
    public PaxTraxConfigFileException( int errorCode) {

        super(errorCode);
    }
    
}
