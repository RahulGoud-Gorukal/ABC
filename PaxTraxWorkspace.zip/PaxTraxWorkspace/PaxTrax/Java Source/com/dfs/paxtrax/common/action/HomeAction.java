package com.dfs.paxtrax.common.action;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;

public class HomeAction extends PaxTraxAction {

    /**
     * Forwards to paxtrax home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward paxtraxHomePage(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response) {
        
        HttpSession session = request.getSession();
        
        if(session.getAttribute(PaxTraxConstants.MODULE_NAME)!=null)
	       	session.removeAttribute(PaxTraxConstants.MODULE_NAME);

        return mapping.findForward("paxtraxHome");
    }


    /**
     * Forwards to passenger home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward passengerHomePage(ActionMapping mapping,
                                           ActionForm form,
                                           HttpServletRequest request,
                                           HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.PASSENGER);
        return mapping.findForward("passengerHome");
    }

    /**
     * Forwards to customs home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward customsHomePage(ActionMapping mapping,
                                         ActionForm form,
                                         HttpServletRequest request,
                                         HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.CUSTOMS);
        return mapping.findForward("customsHome");
    }

    /**
     * Forwards to bagtracking home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward bagtrackingHomePage(ActionMapping mapping,
                                             ActionForm form,
                                             HttpServletRequest request,
                                             HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.BAG_TRACKING);
        return mapping.findForward("bagtrackingHome");
    }

    /**
     * Forwards to admin home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward salesHomePage(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.SALES);
        return mapping.findForward("salesHome");
    }


 /**
     * Forwards to admin home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward adminHomePage(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.ADMIN);
        return mapping.findForward("adminHome");
    }

 /**
     * Forwards to commtrax home page
     *
     * @param mapping  Action mapping
     * @param form     Action form
     * @param request  HttpServletRequest
     * @param response HttpServletResponse
     * @return ActionForward Action forward
     */
    public ActionForward commtraxHomePage(ActionMapping mapping,
                                       ActionForm form,
                                       HttpServletRequest request,
                                       HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.setAttribute(PaxTraxConstants.MODULE_NAME,PaxTraxConstants.COMMTRAX);
        return mapping.findForward("commtraxHome");
    }

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) {
        return super.execute(mapping, form, request, response);
    }
    
	public ActionForward changeLanguage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
	{
		String forwardPage = "";
		
		String language = request.getParameter("language");
		String country = request.getParameter("country");
		String page = request.getParameter("page");
		
		if(language!=null && country!=null && page!=null)		
			super.changeLanguage(request, language, country);
		else
			forwardPage = PaxTraxConstants.SYSTEM_ERROR;					
		
		if(page.equals("adminHome"))
			forwardPage = "adminHome";
		
		if(page.equals("bagtrackingHome"))
			forwardPage = "bagtrackingHome";
			
		if(page.equals("customsHome"))
			forwardPage = "customsHome";
		
		if(page.equals("passengerHome"))
			forwardPage = "passengerHome";
			
		if(page.equals("paxtraxHome"))
			forwardPage = "paxtraxHome";
		if(page.equals("salesHome"))
			forwardPage = "salesHome";

		if(page.equals("commtraxHome"))
		forwardPage = "commtraxHome";
	
		return(mapping.findForward(forwardPage));
	}

}