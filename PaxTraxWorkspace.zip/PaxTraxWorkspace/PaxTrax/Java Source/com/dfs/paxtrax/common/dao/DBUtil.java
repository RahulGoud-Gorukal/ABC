package com.dfs.paxtrax.common.dao;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1997-2004, DFS All rights reserved.
 *
 */


import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;



/**
 * This class performs operations like getting connection and
 * invokes procedure related functionality
 * 
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */

public class DBUtil 
{
	//Holds the instance of this class
	private static DBUtil instance;
	
		
	/**
	 * Private constructor for the singleton class
	 */
	private DBUtil() 
	{
	}

	/**
	 * Returns an instance of the DBUtil
	 *
	 * @return DBUtil - Returns the DBUtil
	 */
	public static DBUtil getInstance() 
	{
		if (instance == null) 
		{
			instance = new DBUtil();
		}
		return instance;
	}
	
	/**
	 * Returns a database connection
	 *
	 * @return Connection - Returns the Connection object
	 *
	 * @exception ToxDocsException - throws the ToxDocsException
	 */
	public Connection getConnection()
		throws PaxTraxSystemException 
	{
		Hashtable params = new Hashtable();
		DataSource dataSource = null;

		try 
		{
			params.put(Context.INITIAL_CONTEXT_FACTORY,
				PaxTraxConstants.WEBSPHERE_NAMING);

			Context ctx = new InitialContext(params);

			dataSource = (DataSource) ctx.lookup(
					PaxTraxConstants.DB_SOURCE_PAXTRAX);

			Connection connection = dataSource.getConnection();
			
			return connection;
		} catch (SQLException e) 
		{
			throw new PaxTraxSystemException(e);
		} catch (NamingException e) 
		{
			throw new PaxTraxSystemException(e);
		}
	}
	/**
	 * Returns a database connection for given Data Source Name.
	 * @param dataSourceName
	 * @return Connection
	 * @throws PaxTraxSystemException
	 */
	public Connection getConnection(String dataSourceName)
		throws PaxTraxSystemException 
	{
		Hashtable params = new Hashtable();
		DataSource dataSource = null;

		try 
		{
			params.put(Context.INITIAL_CONTEXT_FACTORY,
				PaxTraxConstants.WEBSPHERE_NAMING);

			Context ctx = new InitialContext(params);

			dataSource = (DataSource) ctx.lookup(
					dataSourceName);

			Connection connection = dataSource.getConnection();
			
			return connection;
		} catch (SQLException e) 
		{
			throw new PaxTraxSystemException(e);
		} catch (NamingException e) 
		{
			throw new PaxTraxSystemException(e);
		}
	}
}	
