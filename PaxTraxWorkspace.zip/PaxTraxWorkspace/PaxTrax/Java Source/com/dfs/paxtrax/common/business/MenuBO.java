package com.dfs.paxtrax.common.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.exception.MenuException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;


/**
 * Remote interface for Enterprise Bean: UserBOManager
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Sundarrajan.k.	Created   
 */	

public interface MenuBO extends javax.ejb.EJBObject {
	
	
	/**
	 * Loads module options for the given user
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in loading menuDetails
	 */
	public ArrayList loadMenuDetails(UserBean userBean,String webProject) 
		throws RemoteException,PaxTraxSystemException,MenuException;
}

