package com.dfs.paxtrax.common.scheduler;

/*
 * Copyright (c) 2003 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ftp.FTP_client;
import com.dfs.paxtrax.common.util.ftp.FTP_connectmode;
import com.dfs.paxtrax.common.util.ftp.FTP_transfertype;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.service.NACCSDelegate;

/**
 * NACCSAcknowledger Scheduler will read the NaccFile and UPate it to Database
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 23/05/2004	Ramesh	Created
 */
public class PaxTraxNACCSAcknowledgeScheduler extends TimerTask {

	private FTPConfig ftpConfig = null;
	private NACCSDelegate naccsDelegate = null;
 	String naccsSrcDir=null;
	String naccsMvDir=null;
	String essrcDir=null;
	String esmvDir=null;
	String remotHost = null;
	String ftpUserId = null;
	String ftpPwd = null;

	public PaxTraxNACCSAcknowledgeScheduler()
    { 
			init();
    }
	public void init()
	{
		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: Inside Init() Method()");
		 naccsDelegate = new NACCSDelegate(); 
	}
		
		public void run() 
		{
			PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler:  run():");
			String[] essFileList = null;
			String[] naccsFileList = null;
	       	if(ftpConfig  == null)
	       	 {	 
	       	 	PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run(): ftpConfig initialization"); 
	       	    try
	       	       {	     		
						 ftpConfig = naccsDelegate.getNACCSFTPParameters();
			    		naccsSrcDir=ftpConfig.getPcAcknowledgeSourceDir();
			    		naccsMvDir=ftpConfig.getPcAcknowledgeMoveDir();		    		
				   		essrcDir=ftpConfig.getEsAcknowledgeDestDir();
			    		esmvDir=ftpConfig.getEsAcknowledgeMoveDir();					    
			    		remotHost =ftpConfig.getRemoteHost();
			    		ftpUserId =  ftpConfig.getUserName();
			    		ftpPwd    = ftpConfig.getPassword();
				    	PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():remotHost  "+remotHost);			 
			    		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():ftpUserId  "+ftpUserId);			 
			    		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():ftpPwd  "+ftpPwd);			 
			    		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():srcDir  "+naccsSrcDir);			 
			    		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():mvDir  "+naccsMvDir);			 
			    		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():essrcDir  "+essrcDir);			 
			    		PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler:  run():esmvDir  "+esmvDir);				    			 		    				    				    		
	       	       }
	       	       catch(Exception e)
	       	        {
	       	       	    	   PaxTraxLog.logError("***********************Unable to get FTPConfig Parameter************" ,e ); 						
	       	       } 
	       	 }
	
		else
			{
	  			PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler : run() :FTP Config Already Initialised");    	
	        	try
	        		 {      
		        		int fileLength = 0;
		        		byte byteBuff[] = null;
		        		boolean ftpSuccess = true;
		        		String fullPath = null;
				        File naccsFile = null;
				        FileInputStream iStream  = null;       	           	    	
				        FTP_client ftp = new FTP_client(remotHost);
			    		ftp.login(ftpUserId,ftpPwd);
			    		ftp.setTimeout(60*60*60);
				        PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler : run(): Successfully logged in ");		               			
						ftp.chdir(naccsSrcDir);
						PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler : run():  Changed to the Directory -- "+naccsSrcDir);
		        		ftp.setType(FTP_transfertype.BINARY);
		        		ftp.setConnectMode(FTP_connectmode.ACTIVE);
        				naccsFileList = ftp.dir("*.*");	  
						PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler : run(): EServer Dir"+essrcDir);        				      						
		        		File file = new File(essrcDir);		      
		       			if(file.isDirectory())
		        			{   
		        				File essFileArray[] = file.listFiles();
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler : run(): No of File in EServer Dir"+essFileArray.length);
		        				essFileList =  new String[essFileArray.length];		        				
		        				// Gets the Ess File list
		        				for (int i =0 ; i < essFileArray.length; i++) 
		        				{		        					
		        					essFileList[i] = essFileArray[i].getName();
		        					PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run(): Essfile Name "+ essFileList[i]);		        					
		        				}
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run(): Naccs File List "+ naccsFileList.length + " Ess File List "+ essFileList.length);
		        				PaxTraxNACCSAckHelper naccsUtil = new PaxTraxNACCSAckHelper();
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run(): Before calling findFileDifference()");
		        				String[] fileDiffList = naccsUtil.findFileDifference(naccsFileList, essFileList);		        				
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run(): After calling findFileDifference()");
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run():No of Files to be Copied"+ fileDiffList.length);
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler:  run():Before Calling WriteFiles()");
		        				naccsUtil.writeFiles(fileDiffList, ftp, essrcDir,naccsSrcDir);
		        				PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler:  run():After Calling WriteFiles()");	        					        				
		         			 }
			        		else
		       				 {
		        					PaxTraxLog.logError("PaxTraxNACCSAcknowledgeScheduler: run() :File specified is not a valid Directory");
		       		    	 }       				       		    	 	
	       		    	 	PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler:  run(): Closing ftp connection");						
							ftp.quit();   		        		
					        PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler:  run(): Closed ftp connection");
	        		} 
	        		catch(Exception e)
	        		{        	
	        				PaxTraxLog.logError("PaxTraxNACCSAcknowledgeScheduler : run () : failed", e);
	        		}
					// Calling the NaccsDelegate : naccsEntryNumberUpload()	        
			    	try 
			    	{       		
    							PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run() :B4 naccsDelegate.naccsEntryNumberUpload() ");	
								naccsDelegate.naccsEntryNumberUpload(essrcDir,esmvDir);
	   							PaxTraxLog.logDebug("PaxTraxNACCSAcknowledgeScheduler: run() : after naccsDelegate.naccsEntryNumberUpload() ");	
					}
					 catch (PaxTraxSystemException e)
					 {
						PaxTraxLog.logError("PaxTraxNACCSAcknowledgeScheduler: run() :naccsDelegate.naccsEntryNumberUpload() Exception",e);
					}
	
			}
		}
		
			
    }

