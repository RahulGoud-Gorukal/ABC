package com.dfs.paxtrax.common.actionform;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import com.dfs.paxtrax.admin.valueobject.UserBean;


/**
 * Login form class
 *
 * @author Cognizant Technology Solutions
 * @version 1.0
 *          <p/>
 *          MOD HISTORY
 *          DATE 		USER 			COMMENTS
 *          22/03/2004	Vaikundamurthy	Created
 * @contact Cognizant - Sankaranarayanan srinivasan
 * DFS - Buensalida Sheila
 */


public class LoginActionForm extends PaxTraxActionForm {
    private UserBean userBean = null;

    public UserBean getUserBean() {
        return userBean;
    }

    public void setUserBean(UserBean userBean) {
        this.userBean = userBean;
    }
}
