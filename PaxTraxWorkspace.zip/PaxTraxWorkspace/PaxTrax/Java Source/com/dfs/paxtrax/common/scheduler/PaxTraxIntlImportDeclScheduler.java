package com.dfs.paxtrax.common.scheduler;

/* *
 *  This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2006, DFS All rights reserved.
 *
 */

import java.util.TimerTask;

import com.dfs.paxtrax.customs.service.NACCSDelegate;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
* This is a scheduler class which sends the import declaration number information 
* to the AS400 in the case of International Sales
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Sankaranarayanan srinivasan
*           DFS - Buensalida Sheila
*
* @version    1.0
*
* MOD HISTORY
* DATE          USER            COMMENTS
* 07/20/2006    Anand S         Created
*/

public class PaxTraxIntlImportDeclScheduler extends TimerTask {
	
	public PaxTraxIntlImportDeclScheduler()
	{

	}
	
	public void init()
	{

	}
	public void run()
	{
		try
		{
			NACCSDelegate naccsDelegate = new NACCSDelegate();
			naccsDelegate.sendIntlImportDeclarationNumbersToAS400();
		}
		catch (PaxTraxSystemException paxtraxSystemException)
		{
			PaxTraxLog.logError("PaxTraxIntlImportDeclScheduler : run()  PaxTrax System Exception ", paxtraxSystemException);
		}
	}
}
