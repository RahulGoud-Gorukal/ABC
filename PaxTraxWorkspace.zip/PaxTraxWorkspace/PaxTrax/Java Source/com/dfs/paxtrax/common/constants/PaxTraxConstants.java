package com.dfs.paxtrax.common.constants;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import com.dfs.paxtrax.common.util.PaxTraxConfig;

/**
 * This class holds all common constants
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created
 * 06/06/2007	Vijay			Added a new variable for CR changes
 * 06/14/2007  	Uma D			Added a new variable for CR changes
 * 07/28/2007 	Uma D			Added a new variable for CR changes
 * 07/30/2007 	Uma D			Added a new variable for CR changes
 */

public class PaxTraxConstants {
	/**
	 * Constructor for this class
	 */
	public PaxTraxConstants() {

	}

	/**********************PURGE PROCEDURE CONSTANTS************************************/
	public static String PURGE_SALES_MSTR_TABLE = "TB_SALES_HEADER";
	public static String PURGE_NACCS_MSTR_TABLE = "TB_PAX_MSTR";
	public static String PURGE_PAX_MSTR_TABLE = "TB_NACCS_FILE_HEADER";
	public static String PURGE_SALES_BACKUP_TABLE = "TB_SALES_HEADER_BACKUP";
	public static String PURGE_NACCS_BACKUP_TABLE = "TB_PAX_MSTR_BACKUP";
	public static String PURGE_PAX_BACKUP_TABLE = "TB_NACCS_FILE_HEADER_BACKUP";
	public static String NACCS_FILE = "NACCS_FILE";
	public static String TA_FILE_PATH =
		"/opt/WebSphere/AppServer/paxtrax/uploadfile/pax";

	/******************************************************************
						  Schema Validator constent
	  ******************************************************************/

	public static final boolean POS_XML_SCHEMA_VALIDATION_FAILED = false;
	public static final boolean POS_XML_SCHEMA_VALIDATION_SUCCESSFUL = true;
	public static final String POS_XML_SCHEMA_NAMESPACE_FEATURE =
		"http://xml.org/sax/features/namespaces";
	public static final String POS_XML_SCHEMA_VALIDATION_FEATURE =
		"http://xml.org/sax/features/validation";
	public static final String POS_XML_SCHEMA_SC_VALIDATION_FEATURE =
		"http://apache.org/xml/features/validation/schema";
	public static final String POS_XML_SCHEMA_VALIDATION_FULLCHECK_FEATURE =
		"http://apache.org/xml/features/validation/schema-full-checking";

	public static final String SALES_XML_JAXP_PROP_SCHEMA_LANGUAGE =
		"http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	public static final String SALES_XML_W3_XMLSCHEMA =
		"http://www.w3.org/2001/XMLSchema";
	public static final String SALES_XML_JAXP_PROP_SCHEMA_SOURCE =
		"http://java.sun.com/xml/jaxp/properties/schemaSource";
	public static final String POSLOG_RETAIL_NAMESPACE_XSD =
		"POSLogIxRetailNamespace.xsd";
	public static final String POSLOG_TE_NAMESPACE_XSD =
		"POSLogTENamespace.xsd";
	public static final String PROMOTION_MAINTENANCE_TE_NAMESPACE_XSD =
		"PromotionMaintenance.xsd";

	/******************************************************************
						  xml Namespace URI declarations
	******************************************************************/

	public static String POS_XML_NS_URI_TRIVERSITY = "";
	public static String POS_XML_NS_URI_RETAIL = "";
	public static String POS_XML_NS_URI_SCHEMA = "";

	/******************************************************************
						  xml Root names [Request/Response]
	******************************************************************/

	public static String POS_XML_ROOT_NAME_REQUEST_CUSTOMER = "";
	public static String POS_XML_ROOT_NAME_RESPONSE_CUSTOMER = "";

	public static String POS_XML_ROOT_NAME_REQUEST_POST_CODE_LOOKUP = "";
	public static String POS_XML_ROOT_NAME_RESPONSE_POST_CODE_LOOKUP = "";

	public static String POS_XML_ROOT_NAME_REQUEST_REFUND_VERIFICATION = "";
	public static String POS_XML_ROOT_NAME_RESPONSE_REFUND_VERIFICATION = "";

	/****************************************************************
						  MQ Jndi
	******************************************************************/

	public static String POS_MQ_CUSTOMER_RESPONSE_QUEUE_JNDI = "";
	public static String POS_MQ_CONNECTION_FACTORY_JNDI_NAME = "";

	/****************************************************************
						 POS jndi names
	******************************************************************/

	public static String POS_EJB_MESSAGE_SENDER_HOME_JNDI = "";
	public static String POS_EJB_CUSTOMER_REQUEST_HANDLER_HOME_JNDI = "";
	public static String POS_EJB_POSTCODE_HANDLER_HOME_JNDI = "";
	public static String POS_EJB_MSG_PROCESSOR_HOME_JNDI = "";
	public static String POS_EJB_UUID_GENERATOR_HOME_JNDI = "";
	public static String POS_EJB_REFUND_VERIFIER_HOME_JNDI = "";
	public static String POS_EJB_ERROR_MSG_HANDLER_HOME_JNDI = "";

	/*******************************************************************
							SALES JNDI NAMES
	 *******************************************************************/

	public static String SALES_EJB_SALES_MESSAGE_PROCESSOR_JNDI =
		"ejb/com/dfs/paxtrax/sales/business/SalesMessageProcessorHome";
	// For Wincor sales processing
	public static String WINCOR_SALES_EJB_SALES_MESSAGE_PROCESSOR_JNDI =
			"ejb/com/dfs/paxtrax/sales/business/WincorSalesMessageProcessorHome";
	public static String SALES_EJB_SALES_DATA_HANDLER_JNDI =
		"ejb/com/dfs/paxtrax/sales/business/SalesDataHandlerHome";
	//For Wincor Sales processing
	public static String WINCOR_SALES_EJB_SALES_DATA_HANDLER_JNDI =
			"ejb/com/dfs/paxtrax/sales/business/WIncorSalesDataHandlerHome";
	public static String SALES_QUEUE_MCS_JNDI = "QUEUE.PAXTRAX.SALES.REQ";
	// For Wincor Sales processing
	public static String WINCOR_SALES_QUEUE_MCS_JNDI = "QUEUE.WINCOR.SALES.RES";
	public static String WINCOR_EJB_SALES_FACTORY_JNDI = "wincorSalesFactory";

	/*******************************************************************
							LTS JNDI NAMES
	*******************************************************************/

	public static String LTS_QUEUE_PAXTRAX_JNDI = "QUEUE.PAXTRAX.LTS.REQ";
	public static String PLU_PROMOTION_MAINTENANCE_AUTO_PROMO_DESC =
		"paxtrax.plu.promotion.maintanance.autopromo.description";
	/**
	 * Stores the no of records per page
	 */
	public static short RECORDS_PER_PAGE = 10;

	/**
	 * Stores the page numbers to show
	 */
	public static short PAGES_PER_SET = 10;

	/**
	 * Holds provider URL
	 */
	public static String PROVIDER_URL = "iiop://localhost:2809";

	/**
	 * Holds the string value
	 * "com.ibm.websphere.naming.WsnInitialContextFactory"
	 */
	public static String WEBSPHERE_NAMING =
		"com.ibm.websphere.naming.WsnInitialContextFactory";

	/**
	 * Holds the string value "jdbc/paxtrax"
	 */
	public static String DB_SOURCE_PAXTRAX = "jdbc/paxtrax";

	/**
	 * Holds the string value "jdbc/cartrax"
	 */
	public static String DB_SOURCE_CARTRAX = "jdbc/cartrax";

	public static String DB_USER_ID = "";

	public static String DB_PASSWORD = "";

	public static String DB_URL = "";

	public static String DB_PORT = "";

	public static String DB_PROVIDER_URL = "";

	public static String DB_DSN_NAME = "";

	/**
	 * Holds key for putting and retrieving locale object to/from session
	 */
	public static String LOCALE_KEY = "locale key";

	public static String TA_FILE_TA_CODE = "Travel Agent Code";
	public static String TA_FILE_UPLOADED_DATE = "Uploaded Date";
	public static String TA_FILE_BRANCH = "TA Branch";
	public static String TA_FILE_LAST_NAME = "Last Name";
	public static String TA_FILE_FIRST_NAME = "First Name";
	public static String TA_FILE_ARRIVAL_FLIGHT_NUMBER =
		"Arrival Flight Number";
	public static String TA_FILE_ARRIVAL_FLIGHT_DATE = "Arrival Flight Date";
	public static String TA_FILE_DEPARTURE_FLIGHT_NUMBER =
		"Departure Flight Number";
	public static String TA_FILE_DEPARTURE_FLIGHT_DATE =
		"Departure Flight Date";
	public static String TA_FILE_PRIMARY_PAX_LAST_NAME =
		"Primary PAX Last Name";
	public static String TA_FILE_PRIMARY_PAX_FIRST_NAME =
		"Primary PAX First Name";
	public static String TA_FILE_FOOTER_INDICATOR = "Footer Indicator";
	public static String TA_FILE_POST_CODE = "Postcode";
	public static String AIRLINE_VALUE_REFERRED_TO_NACCS = "CODE_NACCS_CODE";
	public static String AIRLINE_VALUE_REFERRED_TO_VALUE = "CODE_CODE_VALUE";

	/**
	 *
	 */
	public static String DUMMY_PASSWORD = "Usr";

	/**
	 * Holds errorcode for system exception
	 */
	public static int SYSTEM_EXCEPTION = 100;

	/**
	 * Holds false
	 */
	public static String FALSE = "false";

	/**
	 * Holds Admin module name
	 */
	public static String ADMIN = "ADMINISTRATION";
	/**
	 * Holds Passenger module name
	 */
	public static String PASSENGER = "PASSENGER";
	/**
	 * Holds Customs module name
	 */
	public static String CUSTOMS = "CUSTOMS";
	/**
	 * Holds BagTracking module name
	 */
	public static String BAG_TRACKING = "BAGTRACKING";

	/**
	 * Holds Sales module name
	 */
	public static String SALES = "SALES";

	public static String SALES_REPORTS = "SALES REPORTS";
	/**
	 * Holds Security sub module name
	 */
	public static String SECURITY = "SECURITY";
	/**
	 * Holds RAC Preassignment sub module name
	 */
	public static String RACPREASS = "RAC PREASSIGNMENT";
	/**
	 * Holds Create User transaction name
	 */
	public static String CREATE_USER = "CREATE USER";
	/**
	 * Holds Maintain User transaction name
	 */
	public static String MAINTAIN_USER = "MAINTAIN USER";
	/**
	 * Holds Emergency SKU sub module name
	 */
	public static String EMERGENCY_SKU = "EMERGENCY/SKU";
	public static String SKU_LOOKUP = "skuLookup";
	/**
	 * Holds Emergency SKU transaction name
	 */
	public static String CREATE_MAINTAIN_SKU = "MAINTAIN SKU";
	/**
	 * Holds Flight sub module name
	 */
	public static String FLIGHT = "FLIGHT";
	/**
	 * Holds Create Flight transaction name
	 */
	public static String CREATE_FLIGHT = "CREATE FLIGHT";
	/**
	 * Holds Maintain Flight transaction name
	 */
	public static String MAINTAIN_FLIGHT = "MAINTAIN FLIGHT";
	public static String MASS_FLIGHT_CHANGE = "MASS FLIGHT CHANGE";
	/**
	 * Holds Override Flight Schedule sub module name
	 */
	public static String OVERRIDE_FLIGHT_SCHEDULE =
		"OVERRIDE/CANCEL FLIGHT SCHEDULE";
	/**
	 * Holds Location sub module name
	 */
	public static String LOCATION = "LOCATION";
	/**
	 * Holds Create Location transaction name
	 */
	public static String CREATE_LOCATION = "CREATE LOCATION";
	/**
	 * Holds Maintain Location transaction name
	 */
	public static String MAINTAIN_LOCATION = "MAINTAIN LOCATION";
	/**
	 * Holds Create Logical Location transaction name
	 */
	public static String CREATE_LOGICAL_LOCATION = "CREATE LOGICAL LOCATION";
	/**
	 * Holds Maintain Logical Location transaction name
	 */
	public static String MAINTAIN_LOGICAL_LOCATION =
		"MAINTAIN LOGICAL LOCATION";
	/**
	 * Holds Reference Data sub module name
	 */
	public static String REFERENCE_DATA = "REFERENCE DATA";
	/**
	 * Holds Maintain Reference Data transaction name
	 */
	public static String MAINTAIN_REFERENCE_DATA = "MAINTAIN REFERENCE DATA";
	/**
	 * Holds Administration sub module name
	 */
	public static String ADMINISTRATION = "ADMINISTRATION";
	/**
	 * Holds Maintain Bank Account transaction name
	 */
	public static String MAINTAIN_BANK_ACCOUNT = "MAINTAIN BANK ACCOUNT";
	/**
	 * Holds Create Pax transaction name
	 */
	public static String CREATE_PAX = "CREATE PAX";
	/**
	 * Holds Maintain Pax transaction name
	 */
	public static String MAINTAIN_PAX = "MAINTAIN PAX";
	/**
	 * Holds Upload Pax File transaction name
	 */
	public static String UPLOAD_PAX_FILE = "UPLOAD PAX FILE";

	/**
	 * PAX Refine search criteria constant
	 */
	public static String REFINE_SEARCH = "REFINE_SEARCH";

	/**
	 * Holds Create TA transaction name
	 */
	public static String CREATE_TRAVEL_AGENT = "CREATE TA";
	/**
	 * Holds Maintain TA transaction name
	 */
	public static String MAINTAIN_TRAVEL_AGENT = "MAINTAIN TA";
	/**
	 * Holds Inquiries Reports sub module name
	 */
	public static String INQUIRIES_REPORTS = "ENQUIRIES/REPORTS";

	public static String BAGTRACKING_REPORTS = "BAGTRACKING REPORTS";
	/**
	 * Holds Invalid Pax Record transaction name
	 */
	public static String INVALID_PAX_RECORD = "INVALID PAX RECORD ENQUIRY";
	/**
	 * Holds Naccs Processing sub module name
	 */
	public static String NACCS_PROCESSING = "NACCS PROCESSING";

	public static String OVERRIDE_BAGTRACKING_AIRPORT =
		"OVERRIDE BAGTRACKING-AIRPORT";

	public static String OVERRIDE_BAGTRACKING_WAREHOUSE =
		"OVERRIDE BAGTRACKING-WAREHOUSE";
//	Added by selvam for CA# 294102 starts

  public static String ASSIGN_TO_SEA_BIN =
		  "ASSIGN SEA BIN";
		  
	public static String RELEASE_BAGS =
			"RELEASE BAGS";	  

	public static String BAG_RELEASED =
				"BAG_RELEASED";	  
// Added/Modified by David for CR 3659 starts
	public static String BAG_NOT_FOUND =
					"BAG_NOT_FOUND";
	public static String BAG_SEARCH_NOT_FOUND =
						"BAG_SEARCH_NOT_FOUND";
	public static String DATE_FLIGHT_VALIDATION =
								"DATE_FLIGHT_VALIDATION";	 
// Added/Modified by David for CR 3659 ends	
// Added/Modified by David for CO 6781 starts - DP Tracking
	public static String FLIGHT_NT_FOUND =
					"FLIGHT_NT_FOUND";
//	Added/Modified by David for CO 6781 ends - DP Tracking		
//	Added by selvam for CA# 294102 ends

	public static String CHANGE_SALE_TRANSACTION_STATUS =
		"CHANGE SALES TRANSACTION STATUS";

	public static String PAX_PURCHASE_APPROVE = "PAX PURCHASE APPROVE";
	public static String PARALLELING_REPORT = "PARALLELING REPORT";

	/**
	 * Holds Commtrax module name
	 */
	public static String COMMTRAX = "COMMTRAX";

	/**
	 * Holds Create TA Branch
	 */
	public static String CREATE_TA_BRANCH = "CREATE TA BRANCH";

	/**
	 * Holds Maintain TA Branch
	 */
	public static String MAINTAIN_TA_BRANCH = "MAINTAIN TA BRANCH";

	/**
	 * Holds Maintain TA Commission
	 */
	public static String MAINTAIN_TA_COMMISSION = "MAINTAIN TA COMMISSION";

	/**
	 * Holds Create visit
	 */
	public static String CREATE_VISIT = "CREATE VISIT";

	/**
	 * Holds Maintain VISIT
	 */
	public static String MAINTAIN_VISIT = "MAINTAIN VISIT";

	/**
	 * Holds VISIT LISTING START
	 */
	public static String VISIT_LISTING_START = "VISIT LISTING/START";

	/**
	 * Holds Naccs File Generation transaction name
	 */
	public static String ALL_SUMMARY_RECORDS = "allSummaryRecords";
	public static String NACCS_FILE_GENERATION = "GENERATE NACCS FILES";
	public static String ALL_SUBMISSION_RECORDS = "allSubmissionRecords";
	public static String REPORT_ERROR = "reporterror";
	/**
		 * Holds Update Lodgement Tracking Nos transaction name
		 */
	public static String UPDATE_LODGEMENT_TRACKING_NOS =
		"UPDATE LODGEMENT TRACKING NOS";
	/**
	 * Holds Naccs File Status Enquiry transaction name
	 */
	public static String NACCS_FILE_STATUS_ENQUIRY =
		"NACCS FILE STATUS ENQUIRY";
	/**
	 * Holds Naccs File Summary Enquiry transaction name
	 */
	public static String NACCS_FILE_SUMMARY_ENQUIRY =
		"NACCS FILE SUMMARY ENQUIRY";
	/**
	 * Holds Naccs Reconciliation report transaction name
	 */
	public static String NACCS_RECONCILIATION_REPORT =
		"NACCS RECONCILIATION REPORT";
	/**
	 * Holds Create Cage transaction name
	 */
	public static String CREATE_CAGE = "CREATE CAGE";
	/**
	 * Holds Maintain Cage transaction name
	 */
	public static String MAINTAIN_CAGE = "MAINTAIN CAGE";
	/**
	 * Holds Create Truck transaction name
	 */
	public static String CREATE_TRUCK = "CREATE TRUCK";
	/**
	 * Holds Maintain Truck transaction name
	 */
	public static String MAINTAIN_TRUCK = "MAINTAIN TRUCK";
	/**
	 * Holds Create Bin Location transaction name
	 */
	public static String CREATE_BIN_LOCATION = "CREATE BIN LOCATION";
	/**
	 * Holds Maintain Bin Location transaction name
	 */
	public static String MAINTAIN_BIN_LOCATION = "MAINTAIN BIN LOCATION";
	/**
	 * Holds Generate Picklist transaction name
	 */
	public static String GENERATE_PICKLIST = "PICKLIST GENERATION";
	/**
	 * Holds Pax Flight Change Notification transaction name
	 */
	public static String PAX_FLIGHT_CHANGE_NOTIFICATION =
		"PAX REFUND FLIGHT/CHANGE NOTIFICATION";
	/**
	 * Holds Bag Tracking Enquiry transaction name
	 */
	public static String BAG_TRACKING_ENQUIRY = "BAG TRACKING ENQUIRY";
	/**
	 * Holds Bag Status By Flight Enquiry transaction name
	 */
	public static String BAG_STATUS_BY_FLIGHT_ENQUIRY =
		"BAG STATUS BY FLIGHT ENQUIRY";
	/**
	 * Holds Bag Not Ready For Pickup Enquiry transaction name
	 */
	public static String BAG_NOT_READY_FOR_PICKUP_ENQUIRY =
		"BAG NOT READY FOR PICKUP ENQUIRY";
	public static String URGENT_CAGE = "Urgent Cage";

	public static String URGENT_CARTON = "Urgent Carton";

	public static String DUMMY = "D";
	public static String TRANS_STATUS = "TRANSACTION STATUS";
	/**
	 * Holds Carton Tracking Enquiry transaction name
	 */
	public static String CARTON_TRACKING_ENQUIRY = "CARTON TRACKING ENQUIRY";
	/**
	 * Holds Bin Location Tracking Enquiry transaction name
	 */
	public static String BIN_LOCATION_TRACKING_ENQUIRY =
		"BIN LOCATION TRACKING ENQUIRY";
	/**
	 * Holds Cage Tracking Enquiry transaction name
	 */
	public static String CAGE_TRACKING_ENQUIRY = "CAGE TRACKING ENQUIRY";
	/**
	 * Holds Truck Tracking Enquiry transaction name
	 */
	public static String TRUCK_TRACKING_ENQUIRY = "TRUCK_TRACKING_ENQUIRY";
	/**
	 * Holds Purchase Enquiry By Pax transaction name
	 */
	public static String PURCHASE_ENQUIRY_BY_PAX = "PURCHASE ENQUIRY BY PAX";
	/**
	 * Holds Item Enquiry transaction name
	 */
	public static String ITEM_ENQUIRY = "ITEM ENQUIRY";
	/**
	 * Holds Stock At Pickup Location Enquiry transaction name
	 */
	public static String STOCK_AT_PICKUP_LOCATION_ENQUIRY =
		"STOCK AT PICKUP LOCATION ENQUIRY";
	/**
	 * Holds Delivery Manifest transaction name
	 */
	public static String DELIVERY_MANIFEST = "DELIVERY MANIFEST";
	/**
	 * Holds Warehouse transaction name
	 */
	public static String WAREHOUSE = "WAREHOUSE";
	/**
	 * Holds Pickup transaction name
	 */
	public static String PICKUP = "PICKUP";
	/**
	 * Holds Bag Airport transaction name
	 */
	public static String BAG_AIRPORT = "AIRPORT";
	/**
	 * Holds Scanner sub module name
	 */
	public static String SCANNER = "SCANNER";
	/**
	 * Holds Menu List to hold all the list in the session
	 */
	public static String MENU_LIST = "menuList";
	/**
	 * Holds Count of module names in the session
	 */
	public static String MENU_COUNT = "menuCount";
	/**
	 * Holds Module Name for the bean
	 */
	public static String MODULE_NAME = "moduleName";
	/**
	 * Holds Sub Module Name for the bean
	 */
	public static String SUB_MODULE_NAME = "subModuleName";
	/**
	 * Holds Txn Name for the bean
	 */
	public static String TXN_NAME = "txnName";
	/**
	 * Holds Txn Id for the bean
	 */
	public static String TXN_ID = "txnId";

	//Holds create user page
	public static String CREATE_USER_PAGE = "CreateUserPage";

	//Holds view user page
	public static String VIEW_USER_PAGE = "ViewUserPage";

	//Holds search user page
	public static String SEARCH_USER_PAGE = "SearchUserPage";

	/**
	 * Holds load reason page
	 */
	public static String LOAD_REASON_PAGE = "LoadReasonPage";

	/**
	 * Holds maintain reference data page
	 */
	public static String MAINTAIN_REFERENCE_DATA_PAGE =
		"MaintainReferenceDataPage";

	/**
	 * Holds view reference data page
	 */
	public static String VIEW_REFERENCE_DATA_PAGE = "ViewReferenceDataPage";

	//Holds result
	public static String RESULT = "result";
	


	//Holds success
	public static String SUCCESS = "success";

	public static String NABCO_IN_PROGRESS = "nabcoInProgress";
	//Holds failure
	public static String UPDATE_FAILURE = "updateFailure";

	public static String SEGMENT_USED_IN_BRANCH = "Segment used in branch";
	public static int SEGMENT_IN_BRANCH_ERRCODE = 500;

	//Holds failure
	public static String FAILURE = "failure";

	//Holds value yes
	public static String YES = "Y";

	//Holds value no
	public static String NO = "N";

	//Holds value operation
	public static String OPERATION = "operation";

	//Holds value create
	public static String CREATE = "create";

	//Holds value maintain
	public static String MAINTAIN = "maintain";

	//Holds value search
	public static String SEARCH = "search";

	//Holds value update
	public static String UPDATE = "update";

	//Holds value update reload
	public static String UPDATE_RELOAD = "updateReload";

	//Holds value all records
	public static String ALL_RECORDS = "allRecords";

	//Holds value current records
	public static String CURRENT_RECORDS = "currentRecords";

	//Holds value size of all records
	public static String SIZE_OF_ALL_RECORDS = "sizeOfAllRecords";

	//Holds value page number
	public static String PAGE_NUMBER = "pageNumber";

	//Holds create location page
	public static String CREATE_LOCATION_PAGE = "CreateLocationPage";

	//Holds search location page
	public static String SEARCH_LOCATION_PAGE = "SearchLocationPage";

	//Holds search flight page
	public static String SEARCH_FLIGHT_PAGE = "searchFlightPage";

	//Holds search override flight page
	public static String SEARCH_OVERRIDE_FLIGHT_PAGE =
		"SearchOverrideFlightPage";

	//Holds view location page
	public static String VIEW_LOCATION_PAGE = "ViewLocationPage";

	//Holds Change Password Page
	public static String CHANGE_PASSWORD_PAGE = "ChangePasswordPage";

	//Holds admin home page
	public static String ADMIN_HOME_PAGE = "AdminHomePage";

	//Holds the users ID
	public static String USER = "userId";

	//Holds terminal collections
	public static String TERMINAL_LIST = "terminalList";

	//Holds terminal types
	public static String LOCATION_TYPES = "locationTypes";

	//Holds delete
	public static String DELETE = "delete";

	public static String MODIFY = "modify";

	//Holds terminal types
	public static String UPDATE_DELETE = "updateDelete";

	//Holds Update Search
	public static String UPDATE_SEARCH = "updateSearch";

	//Holds Delete Search
	public static String DELETE_SEARCH = "deleteSearch";

	//Holds Minute Array
	public static String MINUTE_ARRAY = "minuteArray";

	//Holds Hour Array
	public static String HOUR_ARRAY = "hourArray";

	//Holds value user id
	public static String USER_ID = "userId";

	//Holds value location collection
	public static String LOCATION_COLLECTION = "locationCollection";

	//Holds value language
	public static String LANGUAGE = "language";

	//Holds value country
	public static String CHANGE_LANGUAGE_COUNTRY = "country";

	//Holds value transaction
	public static String TRANSACTION = "transaction";

	//Holds value from page
	public static String FROM_PAGE = "fromPage";

	//Holds maintain user page
	public static String MAINTAIN_USER_PAGE = "maintainUserPage";

	//Holds Store house
	public static String STORE = "Store";

	//Holds All The Location Records
	public static String ALL_LOCATION_RECORDS = "allLocationRecords";

	/**
	 * Holds size of the full location records
	 */
	public static String SIZE_OF_ALL_LOCATION_RECORDS =
		"sizeOfAllLocationRecords";

	/**
	 * Holds value page number
	 */
	public static String LOCATION_PAGE_NUMBER = "locationPageNumber";

	//Holds All The Location Records
	public static String ALL_NACCS_RECORDS = "allNaccsRecords";

	/**
	 * Holds size of the full location records
	 */
	public static String SIZE_OF_ALL_NACCS_RECORDS = "sizeOfAllNaccsRecords";

	/**
	 * Holds value page number
	 */
	public static String NACCS_PAGE_NUMBER = "pageNumber";

	//Holds All The Location Records
	public static String ALL_FLIGHT_RECORDS = "allFlightRecords";

	/**
	 * Holds size of the full location records
	 */
	public static String SIZE_OF_ALL_FLIGHT_RECORDS = "sizeOfAllFlightRecords";

	/**
	 * Holds value page number
	 */
	public static String FLIGHT_PAGE_NUMBER = "flightPageNumber";

	//Vignesh code change starts here
	
	public static String VESSEL_MODE_CHECKED = "vessel_mode_checked"; 
	
	public static String VESSEL_AIRLINE_CODE_ID = "52";
	
	//	Vignesh code change ends here

	//Holds All The Location Records
	public static String ALL_FLIGHT_OVERRIDE_RECORDS =
		"allFlightOverrideRecords";

	/**
	 * Holds size of the full location records
	 */
	public static String SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS =
		"sizeOfAllFlightOverrideRecords";

	/**
	 * Holds value page number
	 */
	public static String FLIGHT_OVERRIDE_PAGE_NUMBER =
		"flightOverridePageNumber";

	/** Hold the default value for Nationality
	 */
	public static String DEFAULT_NATIONALITY = "1";

	/** Holds the default value for COUNTRY */
	public static String DEFAULT_COUNTRY = "Japan";

	/**
	 * Holds jndi name for UserBOBean
	 */
	public static String USER_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/UserBOHome";

	/**
	 * Holds jndi name for ReferenceDataBOHome
	 */
	public static String REFERENCE_DATA_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/ReferenceDataBOHome";

	/**
	 * Holds jndi name for NACCSBOBean
	 */
	public static String NACCS_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/customs/business/NACCSBOHome";

	/**
	 * Holds error code for UserBOManagerHome not find Exception
	 */
	public static int USER_BO_MANAGER_HOME_NOT_FOUND = 201;

	/**
	 * Holds error code for UserBOHome not find Exception
	 */
	public static int USER_BO_HOME_NOT_FOUND = 202;

	/**
	 * Holds jndi name for FlightBOManagerBean
	 */
	public static String FLIGHT_BO_MANAGER_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/FlightBOManagerHome";

	/**
	 * Holds jndi name for FlightBOBean
	 */
	public static String FLIGHT_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/FlightBOHome";

	/**
	 * Holds jndi name for FlightBOBean
	 */
	public static String MENU_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/common/business/MenuBOHome";

	/**
	 * Holds jndi name for PurgeBOBean
	 */
	public static String PURGE_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/common/business/PurgeBOHome";
	/**
	 * Holds error code for FlightBOManagerHome not find Exception
	 */
	public static int FLIGHT_BO_MANAGER_HOME_NOT_FOUND = 203;

	/**
	 * Holds error code for FlightBOHome not find Exception
	 */
	public static int FLIGHT_BO_HOME_NOT_FOUND = 204;

	/**
	 * Holds jndi name for LocationBOBean
	 */
	public static String LOCATION_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/LocationBOHome";

	/**
	 * Holds error code for LocationBOHome not find Exception
	 */
	public static int LOCATION_BO_HOME_NOT_FOUND = 205;

	/**
	 * Holds error code for user id already exists
	 */
	public static int USER_ALREADY_EXISTS = 206;

	/**
	 * Holds error code for no records found
	 */
	public static int NO_RECORDS_FOUND = 207;

	/**
	 * Holds error code for Location already exists
	 */
	public static int LOCATION_ALREADY_EXISTS = 208;

	/**
	 * Holds error code for Location Not Found
	 */
	public static int LOCATION_NOT_FOUND = 209;

	/**
	 * Holds error code for Location Not Found
	 */
	public static int RESULTS_NOT_FOUND = 210;

	/**
	 * Holds error code for Flight already exists
	 */
	public static int FLIGHT_ALREADY_EXISTS = 211;

	/**
	 * Holds error code for Flight Not Found
	 */
	public static int FLIGHT_NOT_FOUND = 212;

	/**
	 * Holds error code for Transaction Not Found
	 */
	public static int NO_TRANSACTIONS_FOUND = 213;

	/**
	 * Holds error code for User Id Not Found
	 */
	public static int USERID_NOT_FOUND = 214;

	/**
	 * Holds error code for Password Not Found
	 */
	public static int PASSWORD_NOT_FOUND = 215;

	/**
	 * Holds error code for reference already exists
	 */
	public static int REFERENCE_ALREADY_EXISTS = 216;

	/**
	 * Holds jndi name for RacPreAssignmentBOBean
	 */

	public static String RAC_PREASSIGNMENT_HOME_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/RacPreAssBOHome";
	/**
	 * Holds error code for harmonize code already exists
	 */
	public static int HARMONIZE_CODE_ALREADY_EXISTS = 217;

	/**
	 * Holds error code for tax type and alcohol strength combination
	 */
	public static int TAX_TYPE_ALCOHOLSTRENGTH_DOES_NOT_EXIST = 218;

	/**
	 * Holds error code for country of origin
	 */
	public static int COUNTRY_OF_ORIGIN_DOES_NOT_EXIST = 219;

	/**
	 * Holds error code for tax type
	 */
	public static int TAX_TYPE_DOES_NOT_EXIST = 220;

	/**
	 * Holds error code for Password Not Found
	 */
	public static int INVALID_PASSWORD = 221;

	/**
	 * Holds confirmation code for activate
	 */
	public static int ACTIVATE_MESSAGE = 222;

	/**
	 * Holds confirmation code for deactivate
	 */
	public static int DEACTIVATE_MESSAGE = 223;

	/**
	 * Holds confirmation code for Unlock
	 */
	public static int UNLOCK_MESSAGE = 224;

	/**
	 * Holds confirmation code for Delete
	 */
	public static int DELETE_MESSAGE = 225;

	/**
	 * Holds confirmation code for Save
	 */
	public static int SAVE_MESSAGE = 226;

	/**
	 * Holds confirmation code for Update
	 */
	public static int UPDATE_MESSAGE = 227;

	/**
	 * Holds User Locked message after invalid Tries
	 */
	public static int USER_LOCKED = 228;

	/**
	 * Holds User Locked message after invalid Tries
	 */
	public static int USER_DEACTIVATED = 229;

	/**
	 * Holds error code for user id already exists
	 */
	public static int _ = 207;

	/**
	 * Holds error code for PurgeBOHome not find Exception
	 */
	public static int PURGE_BO_HOME_NOT_FOUND = 230;
	/**
	 * Holds value userDetails
	 */
	public static String USER_DETAILS = "userDetails";

	/**
	 * Holds value true
	 */
	public static String TRUE = "true";

	/**
	 * Holds value active
	 */
	public static String ACTIVE = "active";

	/**
	 * Holds value deactive
	 */
	public static String DEACTIVE = "deactive";

	/**
	 * Holds value lock
	 */
	public static String LOCK = "lock";

	/**
	 * Holds back to search user page
	 */
	public static String BACK_TO_SEARCH_USER_PAGE = "BackToSearchUserPage";

	/**
	 * Holds password
	 */
	public static String PASSWORD = "password";

	/**
	 * Holds Old Password
	 */
	public static String OLD_PASSWORD = "oldPassword";

	/**
	 * Holds New Password
	 */
	public static String NEW_PASSWORD = "newPassword";

	/**
	 * Holds Confirm Password
	 */
	public static String CONFIRM_PASSWORD = "confirmPassword";

	/**
	 * Holds In correct Password
	 */
	public static String INCORRECT_PASSWORD = "incorrectPassword";

	/**
	 * Holds save reason
	 */
	public static String SAVE_REASON = "saveReason";

	/**
	 * Holds reference type
	 */
	public static String REFERENCE_TYPE = "0";

	/**
	 * Holds airport
	 */
	public static String AIRPORT = "1";

	/**
	 * Holds country
	 */
	public static String COUNTRY = "2";

	/**
	 * Holds location type
	 */
	public static String LOCATION_TYPE = "3";

	/**
	 * Holds nationality
	 */
	public static String NATIONALITY = "4";

	/**
	 * Holds pickup location
	 */
	public static String PICK_UP_LOCATION = "5";

	/**
	 * Holds shift
	 */
	public static String SHIFT = "6";

	/**
	 * Holds languages
	 */
	public static String LANUGAGES = "7";

	/**
	 * Holds airline code
	 */
	public static String AIRLINE_CODE = "8";

	/**
	 * Holds duty types
	 */
	public static String DUTY_TYPE = "9";

	/**
	 * Holds Currency types
	 */
	public static String CURRENCIES = "12";

//	Added for CR611 changes on Jul 30,2008 --Begin
	public static String PROMOTION_CODE = "14";
//	Added for CR611 changes on Jul 30,2008 --End

	//Holds maintain Sku page
	public static String MAINTAIN_SKU_PAGE = "maintainSkuPage";

	//Holds view Sku page
	public static String VIEW_SKU_PAGE = "viewSkuPage";

	/**
	 * Holds Index
	 */
	public static String INDEX = "index";

	/**
	 * Holds LOCATION_ID
	 */
	public static String LOCATION_ID = "LOCATION_ID";

	/**
	 * Holds LOCATION_DESC
	 */
	public static String LOCATION_DESC = "LOCATION_DESC";
	public static String VIEW_LOCATION = "viewLocation";

	/**
	 * Holds LOCATION_CUT_OFF_TIME
	 */
	public static String LOCATION_CUT_OFF_TIME = "LOCATION_CUT_OFF_TIME";

	/**
	 * Holds LOCATION_SPND_LIMIT_TR
	 */
	public static String LOCATION_SPND_LIMIT_TR = "LOCATION_SPND_LIMIT_TR";

	/**
	 * Holds LOCATION_DUTY_FREE_AMT
	 */
	public static String LOCATION_DUTY_FREE_AMT = "LOCATION_DUTY_FREE_AMT";

	/**
	 * Holds LOCATION_BAGTRACK_REQ
	 */
	public static String LOCATION_BAGTRACK_REQ = "LOCATION_BAGTRACK_REQ";

	/**
	* Holds LOCATION_OVER_REF
	*/
	public static String LOCATION_OVER_REF = "LOCATION_OVER_REF";

	/**
	 * Holds LOCATION_DELETED
	 */
	public static String LOCATION_DELETED = "LOCATION_DELETED";

	/**
	 * Holds LOCATION_TYPE_CODE_CODE_ID
	 */
	public static String LOCATION_TYPE_CODE_CODE_ID =
		"LOCATION_TYPE_CODE_CODE_ID";

	/**
	 * Holds LOCATION_TYPE_REF_ID
	 */
	public static String LOCATION_TYPE_REF_ID = "LOCATION_TYPE_REF_ID";

	/**
	 * Holds Location Deleted True
	 */
	public static String LOCATION_DELETED_TRUE = "Y";

	/**
	 * Holds Location Deleted False
	 */
	public static String LOCATION_DELETED_FALSE = "N";

	/**
	 * Holds Location Error
	 */
	public static String LOCATION_ERROR = "locationError";

	/**
	 * Holds Time hour
	 */
	public static String TIME_HR = "timeHr";

	/**
	 * Holds Time minute
	 */
	public static String TIME_MIN = "timeMin";

	/**
	 * Holds jndi name for SKUBOHome
	 */
	public static String SKU_BO_BEAN_JNDI =
		"ejb/com/dfs/paxtrax/admin/business/SKUBOHome";

	/**
	 * Holds error code for SKUBOHome not find Exception
	 */
	public static int SKU_BO_HOME_NOT_FOUND = 214;

	/**
	 * Holds error code for reference exists
	 */
	public static int REFERENCE_EXISTS = 215;

	/**
	 * Holds error code for location dependency reference exists
	 */
	public static int LOCATION_DEPENDENCY_EXISTS = 216;

	/**
	 * Holds present
	 */
	public static String PRESENT = "present";

	/**
	 * Bank screen constant definitions
	 */
	public static String SYSTEM_ERROR = "systemerror";
	public static String BANK_ACCOUNT_PAGE = "bankAccountPage";
	public static String BANK_ACCOUNT_CONF_PAGE = "bankAccountConfPage";
	public static String BANK_ACCOUNT_TYPE_SAVING = "1";
	public static String BANK_ACCOUNT_TYPE_SECURITY = "2";
	//Added by David for CA #313423 starts
	public static String BANK_ACCOUNT_TYPE_SECURITY_VESSEL = "3";
	//Added by David for CA #313423 ends
	public static String BANK_ACCOUNT_TYPE_SAVING_DESC = "Savings";
	public static String BANK_ACCOUNT_TYPE_SECURITY_DESC = "Security";
	public static String BANK_DAY_MONDAY = "2";
	public static String BANK_DAY_TUESDAY = "3";
	public static String BANK_DAY_WEDNUSDAY = "4";
	public static String BANK_DAY_THURSDAY = "5";
	public static String BANK_DAY_FRIDAY = "6";
	public static String BANK_DAY_SATURDAY = "7";
	public static String BANK_DAY_SUNDAY = "1";
	public static String BANK_NON_WORKING_FLAG = "Y";
	public static String BANK_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/customs/business/BankBOHome";

	public static String TRANSMIT_FTP_HOST = "transmit.ftp.host";
	public static String TRANSMIT_FTP_PORT = "transmit.ftp.port";
	public static String TRANSMIT_FTP_DIR = "transmit.ftp.dir";
	public static String TRANSMIT_FTP_USERNAME = "transmit.ftp.username";
	public static String TRANSMIT_FTP_PASSWORD = "transmit.ftp.password";
	public static String TRANSMIT_FTP_NAME = "transmit.ftp.name";

	public static String NACCS_TO_BE_SENT_PATH = "naccs.tobesent.path";
	public static String NACCS_SENT_PATH = "naccs.sent.path";
	public static String NACCS_AKNOWLEDGE_PATH = "naccs.aknowledge.path";

	/**
	 * Holds value for saving the flight
	 */
	public static String SAVE_FLIGHT = "saveFlight";

	/**
	 * Holds value for cancel the flight
	 */
	public static String CANCEL_FLIGHT_HOME = "cancelFlightHome";
	public static String CANCEL_FLIGHT_SEARCH = "cancelFlightSearch";

	/**
	 * Holds Create Flight transaction name
	 */
	public static String FLIGHT_CREATE = "createFlight";

	/**
	 * Holds value for saving the override flight
	 */
	public static String SAVE_OVERRIDE_FLIGHT = "saveOverrideFlight";

	/**
	 * Holds value for cancel the override flight
	 */
	public static String CANCEL_OVERRIDE_FLIGHT = "cancelOverrideFlight";

	/**
	 * Holds value for load the override flight
	 */
	public static String LOAD_OVERRIDE_FLIGHT = "loadOverrideFlight";

	/**
	 * Holds Flight Type transaction name
	 */
	public static String FLIGHT_TYPE = "flightType";

	/**
	 * Holds Scheduled Value
	 */
	public static String SCHEDULED = "Scheduled";

	/**
	 * Holds Non Scheduled Value
	 */
	public static String NON_SCHEDULED = "Non Scheduled";

	/**
	 * Holds value for create Location Page
	 */
	public static String CREATE_LOCATION_PAGE_LOAD = "createLocationPageLoad";

	/**
	* Holds value for create Location Page
	*/
	public static String SEARCH_LOCATION_PAGE_LOAD = "searchLocationPageLoad";

	/**
	 * Holds value for location type Flag
	 */
	public static String LOCATION_TYPE_FLAG = "locationTypeFlag";

	/**
	 * Holds value for the language english
	 */
	public static String EN = "en";

	/**
	 * Holds value for the language japanese
	 */
	public static String JP = "jp";

	/**
	 * Holds value for page
	 */
	public static String PAGE = "page";

	/**
	 * Holds value for item number skip
	 */
	public static String ITEM_NUMBER_SKIP = "itemNumberSkip";

	/**
	 * Holds insert
	 */
	public static String INSERT = "insert";

	/**
	 * Holds Sku Error
	 */
	public static String SKU_ERROR = "Sku Error";

	/**
	 * Holds sku append
	 */
	public static String SKU_APPEND = "skuAppend";

	/**
	 * Holds naccsfilegeneration page
	 */
	public static String NACCS_FILE_GENERATION_PAGE = "naccsFileGenerationPage";

	//Holds save pax page
	public static String SAVE_PAX_PAGE = "savePaxPage";

	//Holds create pax page
	public static String CREATE_PAX_PAGE = "createPaxPage";

	//Holds Session Attribute countrylist
	public static String COUNTRY_LIST = "countryList";

	//Holds Session Attribute nationalitylist
	public static String NATIONALITY_LIST = "nationalityList";

	//Holds Session Attribute departure airlinecodelist
	public static String AIRLINE_CODE_LIST_DEP = "airlineCodeListDep";

	//Holds Session Attribute arrival airlinecodelist
	public static String AIRLINE_CODE_LIST_ARR = "airlineCodeListArr";

	//Holds Create Passenger Page name
	public static String CREATE_PASSENGER = "createPax";

	public static String INVALID_PAX_SEARCH_PAGE = "invalidPAXSearchPage";

	// Holds  NACCS
	public static String ENQUIRY_SUMMARY_SEARCH_PAGE = "naccsSummaryPage";

	public static String ENQUIRY_SUBMISSION_SEARCH_PAGE = "naccsSubmissionPage";

	//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report.

	public static String DAILY_NACCS_GENERATION_PAGE =
		"dailyNACCSGenerationPage";

	//	Added for CR-251 on 6-Jun-2007 For DailyNACCSGeneration Report.

	public static String ENQUIRY_REPORT_PAGE = "enquiryReportPage";

	public static String NACCS_STATUS_MSG = "naccsmsg";
	//

	public static String PAX_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/passenger/business/PAXBOHome";

	public static String TA_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/passenger/business/TravelAgentBOHome";

	public static String FWD_MAINTAIN_PAX_PAGE = "gotoPAXMaintainPage";

	public static String FWD_MAINTAIN_CONFIRM_PAGE = "maintainConfirmPage";

	public static String DISP_MAINTAIN_PAGE = "displayMaintainPage";

	public static String DISABLE_PAX_SCREEN = "disablePAXScreen";

	public static String FWD_PAX_SEARCH_PAGE = "gotoPAXSearchPage";

	public static String FWD_TA_CREATE_PAGE = "createTravelAgent";

	public static String FWD_TA_CREATE_CONFIRMATION_PAGE =
		"createTravelAgentConf";

	public static String FWD_TA_MAINTAIN_PAGE = "maintainTravelAgent";

	public static String FWD_TA_MAINTAIN_CONFIRMATION_PAGE =
		"maintainTravelAgentConf";

	public static String DISABLE_TA_SCREEN = "disableTAScreen";

	public static String TA_DEACTIVATED = "deactivated";

	public static String FWD_TA_SEARCH_PAGE = "searchTravelAgent";

	public static int POSTCODE_PREFIX_SIZE = 3;
	public static int POSTCODE_SUFFIX_SIZE = 4;

	public static String ACTION_MESSAGE_PAX = "pax";

	public static String FROM_MAINTAIN_PAX_PAGE_TO_PAX_SEARCH_PAGE =
		"fromMaintainPAXPageToSearchPage";

	public static String TRAVEL_AGENT_LOOKUP_PAGE = "travelAgentLookupPage";

	public static String FILE_UPLOAD_BASE =
		"D:\\Program Files\\ibm\\WebSphere Studio\\workspace\\PaxTrax\\upload\\";

	public static String FWD_PAX_FILE_UPLOAD_PAGE = "goToUploadPAXFilePage";

	public static char PAX_FILE_DELIMITER = '~';

	public static String GROUP = "10";

	public static String UPC_RETURN = "upcReturn";

	public static String UPC_LIST = "upcList";

	public static String INITIAL_STATUS = "initialStatus";

	public static String CONFIRM_MESSAGE = "confirmMessage";

	public static String MAINTAIN_SKU_JSP = "maintainSku.jsp";

	public static String ERROR_CODE = "ErrorCode";

	public static String SKU_NUMBER = "skuNumber";

	public static String LOGIN = "login";

	public static String PAXTRAXHOME = "paxtraxHome";

	/*
	 * For TRANSACTION STATUS
	 */
	public static String SOLD = "1";
	public static String PICKED_UP = "2";
	public static String GENERATED = "3";
	public static String SUBMITTED = "4";
	public static String ENTRY_NUMBER_RECIEVED = "5";
	public static String CANCELLED = "6";

	/* New Transaction status added on August 28, 2006 as part of the
	 * International DF Sales Enhancement - SR1042  */
	public static String PICKED_UP_INTL = "7";

	/**
	 * Holds NACCS generated message code
	 */
	public static String NACCS_GENERATED_MESSAGE = "403";
	public static String HOLIDAY_EMPTY = "holidayEmpty";
	public static String POSTCODE = "postCode";
	public static String POSTCODE_LOOKUP = "PostCodeLookup";
	public static String ERRORCODE = "errorCode";
	public static String CONFIRMATION_MESSAGE = "confirmationMessage";
	public static String RECORD = "record";

	/** *********** Stamp Duty Report page    **************   */
	public static String STAMP_DUTY_REPORT_PAGE = "stampDutyReportPage";
	public static String STAMP_DUTY_PRINT_PAGE = "stampDutyPrintPage";
	public static String STAMP_DUTY_BO_JNDI =
		"ejb/com/dfs/paxtrax/customs/business/StampDutyBOHome";
	public static int STAMP_DUTY_BO_HOME_NOT_FOUND = 1000;
	public static int STAMP_DUTY__NO_RECORDS_FOUND = 1001;
	/**************************************************************

	/** *********** NACCS Duplicate Pax Report page    **************   */
	public static String NACCS_DUPLICATE_PAX_REPORT_PAGE =
		"naccsDuplicatePaxReportPage";
	public static String PRINT_NACCS_DUPLICATE_PAX_REPORT_PAGE =
		"printNaccsDuplicatePaxReportPage";
	public static String NACCS_MERGE_PAX_PAGE = "mergePaxReportPage";
	/**************************************************************

	/**
	* Holds NACCS failure message code
	*/
	public static String NACCS_FAILURE_MESSAGE = "404";

	/**
	 * Holds generatedList
	 */
	public static String GENERATED_LIST = "generatedList";

	/**
	 * Holds error code for NACCSBOHome not find Exception
	 */
	public static int NACCS_BO_HOME_NOT_FOUND = 405;

	/*
	 * Holds the PaxTrax properties for the static variables
	 */

	// PLU Constants
	public static String PLU_MESSAGE_PROCESSOR_JNDI_HOME =
		"paxtrax.plu.messageProessorHomeJndi";

	public static String PLU_TEMP_DIRECTORY = "paxtrax.plu.temp.dir";

	public static String PLU_MESSAGE_SENDER_JNDI_HOME =
		"POS_MESSAGE_SENDER_HOME_JNDI";

	public static String PLU_MESSAGE_SENDER_QUEUE_NAME = "";

	public static final String ITEM_MAINTENANCE_TE_NAMESPACE_XSD =
		"ItemMaintenance.xsd";

	/******************* Bag Tracking Reports Constants  *****************************/

	public static int INVALID_FLIGHT_NUMBER = 902;
	public static int INVALID_FLIGHT_DATE = 903;
	public static int FLIGHT_CANCELLED = 904;
	public static int PAX_NOT_FOUND = 701;
	public static int SALES_NOT_HAPPENED = 702;
	public static String BAG_STATUS_BY_FLIGHT = "bagStatusByFlight";
	public static String BT_REPORTS_BAG_ENQUIRY = "Bag Tracking Enquiry";
	public static String BT_REPORTS_BAG_STATUS_BY_FLIGHT =
		"Bag Status by Flight";
	public static String BT_REPORTS_BAG_NOT_READY_FOR_PICKUP =
		"Bag Not Ready For Pick-up";
	public static String BT_REPORTS_CARTON_TRACKING_ENQUIRY =
		"Carton Tracking Enquiry";
	public static String BT_REPORTS_BIN_LOC_TRACKING_ENQUIRY =
		"Bin Location Tracking Enquiry";
	public static String BT_REPORTS_CAGE_TRACKING_ENQUIRY =
		"Cage Tracking Enquiry";
	public static String BT_REPORTS_TRUCK_TRACKING_ENQUIRY =
		"Truck Traclking Enquiry";
	public static String BT_REPORTS_PURCHASE_ENQUIRY_BY_PAX =
		"Purchase Enquiry by PAX";
	public static String BT_REPORTS_ITEM_ENQUIRY = "Item Enquiry";
	public static String BT_REPORTS_STOCK_AT_PICKUP_LOCATION =
		"Stock at Pick-up Location Enquiry";
	public static String BT_REPORTS_DELIVERY_MANIFEST = "Delivery Manifest";

	public static String PT_JNDI_BT_REPORTS_HOME =
		"ejb/com/dfs/paxtrax/bagtracking/business/BagTrackingReportsBOHome";
	public static String BT_REPORTS_MAIN_PAGE = "bagTrackingReportsMainPage";
	public static String PT_JNDI_BT_GEN_PICKLIST =
		"ejb/com/dfs/paxtrax/bagtracking/business/GeneratePicklistBOHome";
	public static String BT_GEN_PICKLIST_PAGE = "generatePicklistPage";

	public static String ITEM_ENQUIRY_REPORT_PAGE = "itemEnquiryReportPage";
	public static String ITEM_ENQUIRY_PRINT_PAGE = "itemEnquiryPrintPage";
	public static String BT_JNDI_BO_REPORTS_HOME =
		"ejb/com/dfs/paxtrax/bagtracking/business/BagTrackingReportsBOHome";
	public static int BT_REPORTS_BO_HOME_NOT_FOUND = 900;
	public static int BT_ITEM_ENQUIRY_NO_RECORDS_FOUND = 901;
	public static String DELIVERY_MANIFEST_PAGE = "deliveryManifest";
	public static String STOCK_AT_PICKUP_LOCATION = "stockAtPickupLocation";
	public static String PRINT_DELIVERY_MANIFEST = "printDeliveryManifest";
	public static String TRUCK_TRACKING_ENQUIRY_PAGE =
		"truckTrackingEnquiryPage";
	public static String TRUCK_TRACKING_PRINT_PAGE = "truckTrackingPrintPage";
	public static String PAX_PURCHASE_INQUIRY_PAGE = "paxPurchaseInquiryPage";
	public static String PAX_PURCHASE_PRINT_PAGE = "paxPurchasePrintPage";
	public static String PRINT_STOCK_AT_PICKUP_LOCATION =
		"printStockAtPickupLocation";
	public static final String DISPLAY_CARTON_REPORT_PAGE =
		"displayCartonReportPage";
	public static final String PRINT_CARTON_REPORT_PAGE =
		"printCartonReportPage";
	public static String BAG_NUMBER = "bagNumber";
	public static String BAG_CANCELLATION = "bagCancellation";
	public static String NACBO_AMT_DISP_FORMAT = "#,###";

	/**Added on June 06, 2007 for CR 251-260 changes Begin */

	public static String BAG_BY_BAG_STATUS = "bagByBagStatusReport";
	public static String BAG_CODE = "2";
	public static String PRINT_BAG_STATUS_REPORT = "printBagByBagStatus";
	public static String ALL_BAG_RECORDS = "allBagRecords";
	public static String SIZE_OF_ALL_BAG_RECORDS = "sizeOfAllBagRecords";

	public static String BAG_STATUS_BY_LOCATION = "bagStatusByLocationReport";
	public static String BAG_LOCATION_CODE = "Bag Location";
	public static String PRINT_BAG_STATUS_LOCATION_REPORT = "printBagStatusLocationReport";
	public static String AIRPORT_CODE = "2";
	public static String ALL_CUSTOMSBAG_RECORDS = "allCustomsBagRecords";
	public static String SIZE_OF_ALL_CUSTOMSBAG_RECORDS = "sizeOfAllCustomsBagRecords";
	public static String FILTER_PAGE_NUMBER = "filPageNumber";


	/** Added on June 06, 2007 for CR 251-260 changes End **/

	/** Added on July 28, 2007 for CR 250 changes Begin **/

	public static String IN_PROGRESS = "1";
	public static String NACCS_GENERATED = "2";
	public static int NACCS_IN_PROGRESS = 245;
	public static int NACCS_FILE_GENERATED = 246;
	public static String SCHEDULER_REFERENCE = "Naccs flight purge";

	/** Added on July 28, 2007 for CR 250 changes End **/

	/** Added on July 30, 2007 for CR 261 changes Begin **/

	public static String RECEIVED_IN_GALLERIA = "Received In Galleria";
	public static String REFUNDED = "Refunded";
	public static String TRACING_REFUNDED_BAGS = "tracingRefundedBag";
	public static String STATUS_RECEIVED = "23";
	public static String ENTITY_ID = "2";
	public static String APBIN_STATUS = "Refund Report";
	public static String GALLERIA_STORE = "2";
	public static String AIRPORT_STORE = "1";
	public static String PICKUP_COUNTER = "PickUp Terminals";
	public static String REFUND_TYPE = "Refund Type";
	public static String FLIGHT_DEPARTURE_TYPE = "Flight Type";
	public static String REFUNDED_STATUS = "17";
	public static String GALLERIA_LOCATION = "1";
	public static String AIRPORT_LOCATION = "2";

	/** Added on July 30, 2007 for CR 261 changes EnD **/

	
	/******************* Bag Tracking Reports Constants  *****************************/

	/**********************BAG TRACKING CONSTANTS************************************/

	public static String BAG_NOT_READY_FOR_PICKUP = "bagNotReadyForPickup";
	public static String CREATE_BIN_LOCATION_PAGE = "createBinLocation";
	public static int HOLDING_LOCATION_ALREADY_EXISTS = 244;

	public static int PICKUP_LOCATION_BIN_LOCATION_ALREADY_EXISTS = 231;

	public static int BIN_LOCATION_DOES_NOT_EXIST = 232;

	public static int BIN_LOCATION_ALREADY_EXISTS = 233;

	public static int BIN_LOCATION_UPDATED = 234;

	public static int BIN_LOCATION_DELETED = 235;

	public static String BIN_LOCATION_CONFIRMATION = "binLocationConfirmation";

	public static String MAINTAIN_BIN_LOCATION_PAGE = "maintainBinLocation";

	public static String MAINTAIN_BIN_LOCATION_CONFIRMATION =
		"maintainBinLocationConfirmation";

	public static String SEARCH_BIN_LOCATION_PAGE = "searchBinLocation";

	public static String SIZE_OF_ALL_BIN_LOCATION_RECORDS =
		"sizeOfAllBinLocationRecords";

	public static String SIZE_OF_ALL_TRUCK_RECORDS = "sizeOfAllTruckRecords";

	public static String CREATE_TRUCK_PAGE = "createTruck";

	public static String SEARCH_TRUCK_PAGE = "searchTruck";

	public static String TRUCK_CONFIRMATION = "truckConfirmation";

	public static int TRUCK_ALREADY_EXISTS = 237;

	public static int TRUCK_DOES_NOT_EXIST = 238;

	public static String MAINTAIN_TRUCK_PAGE = "maintainTruck";

	public static String MAINTAIN_TRUCK_CONFIRMATION =
		"maintainTruckConfirmation";

	public static int TRUCK_UPDATED = 239;

	public static int TRUCK_DELETED = 240;

	public static int BIN_LOCATION_CANNOT_DELETE = 242;

	public static int TRUCK_CANNOT_DELETED = 243;

	//Holds value from page number
	public static String FROM_PAGE_NUMBER = "fromPageNumber";

	public static String SEARCH_BIN = "searchBin";

	public static String MAINTAIN_BIN = "maintainBin";

	//Holds Binlocation JNDI Name
	public static String BIN_LOCATION_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/bagtracking/business/BinLocationBOHome";

	//Holds Truck JNDI Name
	public static String TRUCK_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/bagtracking/business/TruckBOHome";

	//Holds Cage  JNDI Name

	public static String CAGE_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/bagtracking/business/CageBOHome";

	//Holds BagOverride JNDI Name
	public static String BAG_OVERRIDE_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/bagtracking/business/BagOverrideBOHome";
	public static String BAG_OVERRIDE_WARE_HOUSE_PAGE =
		"bagOverrideWareHousePage";
	public static String BAG_OVERRIDE_AIRPORT_PAGE = "bagOverrideAirportPage";
	public static String CHANGE_TRANSACTION_STATUS =
		"changeSalesTransactionStatus";
	//Added by selvam for CA# 294102 starts

		
	public static String BAG_RELEASE_PAGE =
			"createreleaseBags";
	public static String ASSIGN_SEA_BIN =
				"assignSeaBin";
	public static String BAGCHECK = "BAGCHECK";
	//Added by selvam for CA# 294102 ends
	
	//Holds Bin Location home not found
	public static int BIN_LOCATION_HOME_NOT_FOUND = 230;

	//Holds Truck home not found
	public static int TRUCK_HOME_NOT_FOUND = 236;

	public static String VIEW_CREATE_CAGE = "viewCreateCage";
	public static String CREATE_CAGE_PAGE = "createCage";
	public static String MAINTAIN_CAGE_PAGE = "maintainCage";
	public static String VIEW_MAINTAINE_CAGE = "viewMaintainCage";
	public static String ALL_CAGE_RECORDS = "allCageRecords";
	public static String CAGE_PAGE_NUMBER = "cagePageNumber";
	public static String BAGTRACKING_HOME = "bagtrackingHome";
	public static String SEARCH_CAGE_PAGE = "searchCagePage";
	public static String SIZE_OF_ALL_CAGE_RECORDS = "sizeOfAllCageRecords";
	public static String ERROR = "error";

	public static String CAGE = "Cage";
	public static String CAGE_STATUS_AVAILABLE = "AVAILABLE";
	public static String CAGE_STATUS_DELETED = "DELETED";
	public static String CAGE_NOT_DELETED = "N";
	public static String CAGE_DELETED = "Y";
	public static int CAGE_NOT_FOUND = 152;
	public static int CAGE_CANNNOT_DELETE = 153;
	public static int CAGE_ALREADY_EXISTS = 151;
	public static int NO_CAGE_RECORDS_FOUND = 154;

	public static String VIEW_CREATE_VISIT = "viewCreateVisit";
	public static String CREATE_VISIT_PAGE = "createVisit";
	public static String MAINTAIN_VISIT_DETAIL_PAGE = "maintainVisitDetail";
	public static String MAINTAIN_VISIT_PAGE = "maintainVisit";
	public static String VIEW_MAINTAIN_VISIT = "viewMaintainVisit";
	public static String MAINTAIN_VISIT_CONFIRM_PAGE =
		"maintainVisitConfirmPage";
	public static String MAINTAIN_TA_COMMISSION_PAGE =
		"maintainTaCommissionPage";
	public static String SEARCH_TA_COMMISSION_PAGE =
		"searchMaintainTaCommission";
	public static String INSERT_TA_COMMISSION_PAGE = "insertTaCommission";
	public static String CONFIRM_TA_COMMISSION_PAGE =
		"confirmMaintainTaCommission";
	public static String REF_CODE_NAMES = "RefCodeNames";

	/**************************************Scanner Menues constants********************/

	/**
	 * Holds Txn name for the bean
	 */
	public static String ASSIGN_BAGS_TO_CARTON = "ASSIGN BAGS TO CARTON";
	/**
	 * Holds Txn name for the bean
	 */
	public static String REMOVE_BAGS_FROM_CARTON = "REMOVE BAGS FROM CARTON";
	/**
	 * Holds Txn name for the bean
	 */
	public static String CLOSE_CARTON = "CLOSE CARTON";
	/**
	 * Holds Txn name for the bean
	 */
	public static String REOPEN_CARTON = "REOPEN CARTON";
	/**
	 * Holds Txn name for the bean
	 */
	public static String ASSIGN_CARTON_TO_WH_BIN_LOCATION =
		"ASSIGN CARTON TO WH BIN LOCATION";
	/**
	 * Holds Txn name for the bean
	 */
	public static String SCAN_CARTON_TO_CAGE = "SCAN CARTON TO CAGE";
	/**
	 * Holds Txn name for the bean
	 */
	public static String REMOVE_CARTONS_FROM_CAGE = "REMOVE CARTONS FROM CAGE";
	/**
	 * Holds Txn name for the bean
	 */
	public static String CLOSE_CAGE = "CLOSE CAGE";
	/**
	 * Holds Txn name for the bean
	 */
	public static String REOPEN_CAGE = "REOPEN CAGE";
	/**
	 * Holds Txn name for the bean
	 */
	public static String LOAD_CAGES_TO_TRUCK = "LOAD CAGES TO TRUCK";
	/**
	 * Holds Txn name for the bean
	 */
	public static String REMOVE_CAGE_FROM_TRUCK = "REMOVE CAGE FROM TRUCK";
	/**
	 * Holds Txn name for the bean
	 */
	public static String UNLOAD_CAGE_FROM_TRUCK = "UNLOAD CAGE FROM TRUCK";
	/**
	 * Holds Txn name for the bean
	 */
	public static String ASSIGN_CAGE_TO_AP_BIN_LOCATION =
		"ASSIGN CAGE TO AP BIN LOCATION";
	/**
	 * Holds Txn name for the bean
	 */
	public static String RELEASE_CAGE_AND_CARTONS = "RELEASE CAGE AND CARTONS";
	/**
	 * Holds Txn name for the bean
	 */
	public static String POSITIVE_PICKUP = "POSITIVE PICKUP";

	/* Holds the Created/Modified By User ID when PAX Create/Update request is received from TE POS */
	public static String TE_POS_USER = "TEPOS USER";
	
	//For Wincor migration
	public static String WINCOR_POS_USER = "WINCORPOS USER";
	public static String WINCOR_POS_SALES = "WINCORPOS SALES";

	/**************************************Scanner Menues constants End **************/

	/***************************************Commtrax Module Starts*******************/

	/**
	 * Holds CREATE VISIT PAX PAGE
	 */
	public static String CREATE_VISIT_PAX_PAGE = "createVisitPax";

	/**
	 * Holds COMMTRAX BO HOME JNDI
	 */
	public static String COMMTRAX_BO_HOME_JNDI =
		"ejb/com/dfs/paxtrax/commtracking/business/CommTraxBOHome";

	public static String CREATE_VISIT_PAGE1 = "createVisitPage";

	/**
	 * Holds SAVE VISIT PAX PAGE
	 */
	public static String SAVE_VISIT_PAX_PAGE = "createVisitPaxConfirmation";

	/**
	 * Holds SEARCH GROUP PAGE
	 */
	public static String SEARCH_GROUP_PAGE = "searchGroup";

	/**
	 * Holds ADD GROUP
	 */
	public static String ADD_GROUP = "addGroup";

	/**
	 * Holds SAVE ADD GROUP
	 */
	public static String SAVE_ADD_GROUP = "addGroupConfirmation";

	/**
	 * Holds SIZE OF START VISIT RECORDS
	 */
	public static String SIZE_OF_START_VISIT_RECORDS =
		"sizeOfAllStartVisitRecords";

	/**
	 * Holds START VISIT PAGE
	 */
	public static String START_VISIT_PAGE = "startVisit";

	/**
	 * Holds START VISIT RECORDS
	 */
	public static String START_VISIT_RECORDS = "startVisitRecords";

	/**
	 * Holds START VISIT DETAILS PAGE
	 */
	public static String START_VISIT_DETAILS_PAGE = "startVisitDetails";
	/**
	 * Holds DOWNLAOD EXCEL PAGE
	 */
	public static String SEARCH_MAINTAIN_VISIT_EXCEL =
		"searchMaintainVisitExcel";

	/**
	 * Holds VISIT BEAN
	 */
	public static String VISIT_BEAN = "visitBean";

	public static String VISIT_RECORDS = "visitRecords";

	public static String SIZE_OF_ALL_VISIT_RECORDS = "sizeOfAllVisitRecords";

	public static String START_VISIT_CONFIRM = "startVisitConfirm";

	public static String MAINTAIN_GROUP = "maintainGroup";

	public static String DELETE_FAILURE = "deleteFailed";

	public static String CREATE_SEGMENT = "createSegment";

	public static String MAINTAIN_SEGMENT = "maintainSegment";

	/*
	 *  The TFAFTPUserId is used to hard code the user id in transferFiles method in TAFileHelper
	*/
	public static String TFAFTPUserId = "9999";

	public static int VISIT_CANNOT_START = 600;

	public static String CREATE_LOGICAL_LOCATION_PAGE = "createLogicalLocation";

	public static String VIEW_LOGICAL_LOCATION_PAGE = "viewLogicalLocation";

	public static String MAINTAIN_LOGICAL_LOCATION_PAGE =
		"maintainLogicalLocation";

	public static String ALL_LOGICAL_LOCATION_RECORDS =
		"allLogicalLocationRecords";

	public static String SIZE_OF_ALL_LOGICAL_LOCATION_RECORDS =
		"sizeOfAllLogicalLocationRecords";

	public static String SEARCH_LOGICAL_LOCATION_PAGE = "searchLogicalLocation";

	public static String VIEW_MAINTAIN_LOGICAL_LOCATION_PAGE =
		"maintainLogicalLocationConfirmation";

	public static String SALES_REPORTS_BASE_PATH = "/drbd0/PaxTrax/SalesReports/";
	public static String BAGTRAX_REPORTS_BASE_PATH = "d:/sathish/";
	public static String FILE_NAME = "fileName";
	public static String FILE_TYPE = "fileType";
	public static String VISIT_REPORTS_FILE_NAME = "VisitReports";
	public static String APP_MS_EXCEL = "application/vnd.ms-excel";
	public static String APP_MS_WORD = "application/vnd.ms-word";
	public static String APP_PDF = "application/pdf";

	public static String DFS_OKINAWA = "DFS OKINAWA";
	public static String SALES_BY_HOUR_REPORT = "SALES BY HOUR REPORT";
	public static String SALES_BY_DEPARTMENT_REPORT =
		"SALES BY DEPARTMENT REPORT";
	
//CR1832 change starts
	public static String TA_COMM_CHANGE_REPORT =
			"RateMaint";
	public static String TA_COMMISSION_RATE_CHANGES_REPORT = "TA Commission Rate Changes Report";	
	public static String VISIT_CHANGE_REPORTA =	"GrpVisitMaintCS";
	public static String VISIT_CHANGE_REPORTB =	"VisitMaint";
		public static String VISIT_CHANGES_REPORT = "Pax Visit Changes Tracking";
		public static String PAX_CHANGES_REPORT = "Pax Maintenance Tracking Report";
	public static String PAX_CHANGES_REPORT_NAME = "PAXMaint";
	public static String TE_PAX_CHANGES_REPORT = "TE POS - Pax Maintenance Tracking Report";
	
//	CR1832 change ends
	
	public static String SALES_BY_ASSOCIATE_REPORT =
		"SALES BY ASSOCIATE REPORT";
	public static String SKU_TRANSFER_REPORT =
		"BagTrax Delivery Report by trip";
	public static String SKU_SUMMARY_REPORT = "BagTrax Daily Summary Report";

	public static String GENERATED_DATE = "Generated Date: ";
	public static String SALES_BY_HOUR_LOCATION = "Location: ";
	public static String SALES_BY_HOUR_FROM_DATE = "From Date: ";
	public static String SALES_BY_HOUR_TO_DATE = "To Date: ";
	public static String SALES_BY_HOUR_DEPARTMENT = "Department";
	public static String SALES_BY_HOUR_TOTAL_SALES = "Total Sales";
	public static String SALES_BY_HOUR_SALES_TOTAL = "Sales Total";
	public static String SALES_BY_HOUR_SALES_MIX = "Sales Mix";
	public static String MS_EXCEL = "excel";
	public static String MS_WORD = "word";
	public static String PDF = "pdf";

	public static String OLD_RAC_PREASSIGNMENT = "oldRacPreAssignmentData";
	public static String ALTERNATE_DOWNLOAD_PATH = "alternateDownloadPath";
	public static String BAGTRAX_FILE_PATH = "bagTraxFilePath";

	public static int PAX_ALREADY_ASSIGNED = 208;

	//Code added on 05/12/2005 .
	public static double DUTYFREE_NON_ZERO = 1.00;

	//Code added on 2006-05-02
	public static String WINE_CONSUMPTION_CODE = "L122000000";

	//Code added on 2006-05-17
	public static String WINE_ALCOHOL_STRENGTH = "000";

	/*Modified on 28th June 2006 - Starts
	 *SR 1042 International DF Sale */

	public static int FLIGHT_PICKUP_MISMATCH = 251;
	public static String INTERNATIONAL = "International";
	public static String DOMESTIC = "Domestic";
	public static String PREORDER = "Pre-Order";
	public static String NON_PREORDER = "Non Pre-Order";
	
//	FlightUpload Scheduler
	
	public static String FLIGHT_SCHE_CLASS_NAME = "com.dfs.paxtrax.common.scheduler.FlightUploadScheduler";
	public static String FLIGHT_SCHE_EXEC_TIME = "00:00:00";
	public static long FLIGHT_SCHE_PERIOD = 240000;
	
//	PostalCode Scheduler
	
		 public static String POSTCODE_SCHE_CLASS_NAME = "com.dfs.paxtrax.common.scheduler.PostCodeUploadScheduler";
		 public static String POSTCODE_SCHE_EXEC_TIME = "00:00:00";
		 public static long POSTCODE_SCHE_PERIOD = 18000000;	
	
//	For Wincor Flight Interface
	 public static String FLIGHT_UPLOAD_BO_JNDI = "ejb/com/dfs/paxtrax/common/business/FlightUploadBOHome";
	public static String POSTCODE_UPLOAD_BO_JNDI = "ejb/com/dfs/paxtrax/common/business/PostCodeUploadBOHome";
	 // For Wincor Flight Interface end
	
	/*Modified on 28th June 2006 - Ends
	 *SR 1042 International DF Sale */

	static {

		try {

			/*
			 *  Holds Database properties
			 */

			DB_DSN_NAME = PaxTraxConfig.getProperty("DB_DSN_NAME");
			DB_USER_ID = PaxTraxConfig.getProperty("DB_USER_ID");
			DB_PASSWORD = PaxTraxConfig.getProperty("DB_PASSWORD");
			DB_URL = PaxTraxConfig.getProperty("DB_URL");
			DB_PORT = PaxTraxConfig.getProperty("DB_PORT");
			DB_PROVIDER_URL = PaxTraxConfig.getProperty("DB_PROVIDER_URL");
			DB_SOURCE_PAXTRAX = PaxTraxConfig.getProperty("DB_SOURCE_PAXTRAX");
			DB_SOURCE_CARTRAX =
				PaxTraxConfig.getProperty("CONFIG_DB_SOURCE_CARTRAX");
			/*
			 *  Holds Database properties
			 */

			WEBSPHERE_NAMING = PaxTraxConfig.getProperty("WEBSPHERE_NAMING");
			MENU_BO_BEAN_JNDI = PaxTraxConfig.getProperty("MENU_BO_BEAN_JNDI");
			PURGE_BO_BEAN_JNDI =
				PaxTraxConfig.getProperty("PURGE_BO_BEAN_JNDI");
			USER_BO_BEAN_JNDI = PaxTraxConfig.getProperty("USER_BO_BEAN_JNDI");
			REFERENCE_DATA_BO_BEAN_JNDI =
				PaxTraxConfig.getProperty("REFERENCE_DATA_BO_BEAN_JNDI");
			FLIGHT_BO_BEAN_JNDI =
				PaxTraxConfig.getProperty("FLIGHT_BO_BEAN_JNDI");
			LOCATION_BO_BEAN_JNDI =
				PaxTraxConfig.getProperty("LOCATION_BO_BEAN_JNDI");
			SKU_BO_BEAN_JNDI = PaxTraxConfig.getProperty("SKU_BO_BEAN_JNDI");

			NACCS_BO_BEAN_JNDI =
				PaxTraxConfig.getProperty("NACCS_BO_BEAN_JNDI");

			/*
			 *  Holds properties for Menu
			 */
			LOGIN = PaxTraxConfig.getProperty("LOGIN");
			PAXTRAXHOME = PaxTraxConfig.getProperty("PAXTRAXHOME");
			ADMIN = PaxTraxConfig.getProperty("ADMIN");
			PASSENGER = PaxTraxConfig.getProperty("PASSENGER");
			CUSTOMS = PaxTraxConfig.getProperty("CUSTOMS");
			BAG_TRACKING = PaxTraxConfig.getProperty("BAG_TRACKING");
			SECURITY = PaxTraxConfig.getProperty("SECURITY");
			CREATE_USER = PaxTraxConfig.getProperty("CREATE_USER");
			MAINTAIN_USER = PaxTraxConfig.getProperty("MAINTAIN_USER");
			EMERGENCY_SKU = PaxTraxConfig.getProperty("EMERGENCY_SKU");
			CREATE_MAINTAIN_SKU =
				PaxTraxConfig.getProperty("CREATE_MAINTAIN_SKU");
			FLIGHT = PaxTraxConfig.getProperty("FLIGHT");
			CREATE_FLIGHT = PaxTraxConfig.getProperty("CREATE_FLIGHT");
			MAINTAIN_FLIGHT = PaxTraxConfig.getProperty("MAINTAIN_FLIGHT");
			OVERRIDE_FLIGHT_SCHEDULE =
				PaxTraxConfig.getProperty("OVERRIDE_FLIGHT_SCHEDULE");
			LOCATION = PaxTraxConfig.getProperty("LOCATION");
			CREATE_LOCATION = PaxTraxConfig.getProperty("CREATE_LOCATION");
			MAINTAIN_LOCATION = PaxTraxConfig.getProperty("MAINTAIN_LOCATION");
			REFERENCE_DATA = PaxTraxConfig.getProperty("REFERENCE_DATA");
			MAINTAIN_REFERENCE_DATA =
				PaxTraxConfig.getProperty("MAINTAIN_REFERENCE_DATA");
			ADMINISTRATION = PaxTraxConfig.getProperty("ADMINISTRATION");
			MAINTAIN_BANK_ACCOUNT =
				PaxTraxConfig.getProperty("MAINTAIN_BANK_ACCOUNT");
			CREATE_PAX = PaxTraxConfig.getProperty("CREATE_PAX");
			MAINTAIN_PAX = PaxTraxConfig.getProperty("MAINTAIN_PAX");
			UPLOAD_PAX_FILE = PaxTraxConfig.getProperty("UPLOAD_PAX_FILE");
			CREATE_TRAVEL_AGENT =
				PaxTraxConfig.getProperty("CREATE_TRAVEL_AGENT");
			MAINTAIN_TRAVEL_AGENT =
				PaxTraxConfig.getProperty("MAINTAIN_TRAVEL_AGENT");
			INQUIRIES_REPORTS = PaxTraxConfig.getProperty("INQUIRIES_REPORTS");
			INVALID_PAX_RECORD =
				PaxTraxConfig.getProperty("INVALID_PAX_RECORD");
			NACCS_PROCESSING = PaxTraxConfig.getProperty("NACCS_PROCESSING");
			NACCS_FILE_GENERATION =
				PaxTraxConfig.getProperty("NACCS_FILE_GENERATION");
			UPDATE_LODGEMENT_TRACKING_NOS =
				PaxTraxConfig.getProperty("UPDATE_LODGEMENT_TRACKING_NOS");
			NACCS_FILE_STATUS_ENQUIRY =
				PaxTraxConfig.getProperty("NACCS_FILE_STATUS_ENQUIRY");
			NACCS_FILE_SUMMARY_ENQUIRY =
				PaxTraxConfig.getProperty("NACCS_FILE_SUMMARY_ENQUIRY");
			NACCS_RECONCILIATION_REPORT =
				PaxTraxConfig.getProperty("NACCS_RECONCILIATION_REPORT");
			CREATE_CAGE = PaxTraxConfig.getProperty("CREATE_CAGE");
			MAINTAIN_CAGE = PaxTraxConfig.getProperty("MAINTAIN_CAGE");
			CREATE_TRUCK = PaxTraxConfig.getProperty("CREATE_TRUCK");
			MAINTAIN_TRUCK = PaxTraxConfig.getProperty("MAINTAIN_TRUCK");
			OVERRIDE_BAGTRACKING_AIRPORT =
				PaxTraxConfig.getProperty("OVERRIDE_BAGTRACKING_AIRPORT");
			OVERRIDE_BAGTRACKING_WAREHOUSE =
				PaxTraxConfig.getProperty("OVERRIDE_BAGTRACKING_WAREHOUSE");
			CREATE_BIN_LOCATION =
				PaxTraxConfig.getProperty("CREATE_BIN_LOCATION");
			MAINTAIN_BIN_LOCATION =
				PaxTraxConfig.getProperty("MAINTAIN_BIN_LOCATION");
			GENERATE_PICKLIST = PaxTraxConfig.getProperty("GENERATE_PICKLIST");
			PAX_FLIGHT_CHANGE_NOTIFICATION =
				PaxTraxConfig.getProperty("PAX_FLIGHT_CHANGE_NOTIFICATION");
			BAG_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("BAG_TRACKING_ENQUIRY");
			BAG_STATUS_BY_FLIGHT_ENQUIRY =
				PaxTraxConfig.getProperty("BAG_STATUS_BY_FLIGHT_ENQUIRY");
			BAG_NOT_READY_FOR_PICKUP_ENQUIRY =
				PaxTraxConfig.getProperty("BAG_NOT_READY_FOR_PICKUP_ENQUIRY");
			CARTON_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("CARTON_TRACKING_ENQUIRY");
			BIN_LOCATION_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("BIN_LOCATION_TRACKING_ENQUIRY");
			CAGE_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("CAGE_TRACKING_ENQUIRY");
			TRUCK_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("TRUCK_TRACKING_ENQUIRY");
			PURCHASE_ENQUIRY_BY_PAX =
				PaxTraxConfig.getProperty("PURCHASE_ENQUIRY_BY_PAX");
			ITEM_ENQUIRY = PaxTraxConfig.getProperty("ITEM_ENQUIRY");
			STOCK_AT_PICKUP_LOCATION_ENQUIRY =
				PaxTraxConfig.getProperty("STOCK_AT_PICKUP_LOCATION_ENQUIRY");
			DELIVERY_MANIFEST = PaxTraxConfig.getProperty("DELIVERY_MANIFEST");
			WAREHOUSE = PaxTraxConfig.getProperty("WAREHOUSE");
			PICKUP = PaxTraxConfig.getProperty("PICKUP");
			BAG_AIRPORT = PaxTraxConfig.getProperty("BAG_AIRPORT");
			SCANNER = PaxTraxConfig.getProperty("SCANNER");
			MENU_LIST = PaxTraxConfig.getProperty("MENU_LIST");
			MENU_COUNT = PaxTraxConfig.getProperty("MENU_COUNT");
			MODULE_NAME = PaxTraxConfig.getProperty("MODULE_NAME");
			SUB_MODULE_NAME = PaxTraxConfig.getProperty("SUB_MODULE_NAME");
			TXN_NAME = PaxTraxConfig.getProperty("TXN_NAME");
			TXN_ID = PaxTraxConfig.getProperty("TXN_ID");

			/*
			 *  Holds properties for admin module
			 */
			String recordsPerPage =
				PaxTraxConfig.getProperty("RECORDS_PER_PAGE");
			RECORDS_PER_PAGE = (short) Integer.parseInt(recordsPerPage);
			//PAGES_PER_SET = PaxTraxConfig.getProperty("PAGES_PER_SET");
			BANK_ACCOUNT_PAGE = PaxTraxConfig.getProperty("BANK_ACCOUNT_PAGE");
			BANK_ACCOUNT_CONF_PAGE =
				PaxTraxConfig.getProperty("BANK_ACCOUNT_CONF_PAGE");
			HOLIDAY_EMPTY = PaxTraxConfig.getProperty("HOLIDAY_EMPTY");
			POSTCODE = PaxTraxConfig.getProperty("POSTCODE");
			POSTCODE_LOOKUP = PaxTraxConfig.getProperty("POSTCODE_LOOKUP");
			ERRORCODE = PaxTraxConfig.getProperty("ERRORCODE");
			CONFIRMATION_MESSAGE =
				PaxTraxConfig.getProperty("CONFIRMATION_MESSAGE");
			VIEW_LOCATION = PaxTraxConfig.getProperty("VIEW_LOCATION");
			RECORD = PaxTraxConfig.getProperty("RECORD");

			LOCALE_KEY = PaxTraxConfig.getProperty("LOCALE_KEY");
			DUMMY_PASSWORD = PaxTraxConfig.getProperty("DUMMY_PASSWORD");
			FALSE = PaxTraxConfig.getProperty("FALSE");
			CREATE_USER_PAGE = PaxTraxConfig.getProperty("CREATE_USER_PAGE");
			VIEW_USER_PAGE = PaxTraxConfig.getProperty("VIEW_USER_PAGE");
			SEARCH_USER_PAGE = PaxTraxConfig.getProperty("SEARCH_USER_PAGE");
			LOAD_REASON_PAGE = PaxTraxConfig.getProperty("LOAD_REASON_PAGE");
			MAINTAIN_REFERENCE_DATA_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_REFERENCE_DATA_PAGE");
			VIEW_REFERENCE_DATA_PAGE =
				PaxTraxConfig.getProperty("VIEW_REFERENCE_DATA_PAGE");
			RESULT = PaxTraxConfig.getProperty("RESULT");
			SUCCESS = PaxTraxConfig.getProperty("SUCCESS");
			UPDATE_FAILURE = PaxTraxConfig.getProperty("UPDATE_FAILURE");
			FAILURE = PaxTraxConfig.getProperty("FAILURE");
			YES = PaxTraxConfig.getProperty("YES");
			NO = PaxTraxConfig.getProperty("NO");
			OPERATION = PaxTraxConfig.getProperty("OPERATION");
			CREATE = PaxTraxConfig.getProperty("CREATE");
			MAINTAIN = PaxTraxConfig.getProperty("MAINTAIN");
			SEARCH = PaxTraxConfig.getProperty("SEARCH");
			UPDATE = PaxTraxConfig.getProperty("UPDATE");
			UPDATE_RELOAD = PaxTraxConfig.getProperty("UPDATE_RELOAD");
			ALL_RECORDS = PaxTraxConfig.getProperty("ALL_RECORDS");
			CURRENT_RECORDS = PaxTraxConfig.getProperty("CURRENT_RECORDS");
			SIZE_OF_ALL_RECORDS =
				PaxTraxConfig.getProperty("SIZE_OF_ALL_RECORDS");
			PAGE_NUMBER = PaxTraxConfig.getProperty("PAGE_NUMBER");
			CREATE_LOCATION_PAGE =
				PaxTraxConfig.getProperty("CREATE_LOCATION_PAGE");
			SEARCH_LOCATION_PAGE =
				PaxTraxConfig.getProperty("SEARCH_LOCATION_PAGE");
			SEARCH_FLIGHT_PAGE =
				PaxTraxConfig.getProperty("SEARCH_FLIGHT_PAGE");
			SEARCH_OVERRIDE_FLIGHT_PAGE =
				PaxTraxConfig.getProperty("SEARCH_OVERRIDE_FLIGHT_PAGE");
			VIEW_LOCATION_PAGE =
				PaxTraxConfig.getProperty("VIEW_LOCATION_PAGE");
			CHANGE_PASSWORD_PAGE =
				PaxTraxConfig.getProperty("CHANGE_PASSWORD_PAGE");
			ADMIN_HOME_PAGE = PaxTraxConfig.getProperty("ADMIN_HOME_PAGE");
			USER = PaxTraxConfig.getProperty("USER");
			TERMINAL_LIST = PaxTraxConfig.getProperty("TERMINAL_LIST");
			LOCATION_TYPES = PaxTraxConfig.getProperty("LOCATION_TYPES");
			DELETE = PaxTraxConfig.getProperty("DELETE");
			UPDATE_DELETE = PaxTraxConfig.getProperty("UPDATE_DELETE");
			UPDATE_SEARCH = PaxTraxConfig.getProperty("UPDATE_SEARCH");
			DELETE_SEARCH = PaxTraxConfig.getProperty("DELETE_SEARCH");
			MINUTE_ARRAY = PaxTraxConfig.getProperty("MINUTE_ARRAY");
			HOUR_ARRAY = PaxTraxConfig.getProperty("HOUR_ARRAY");
			USER_ID = PaxTraxConfig.getProperty("USER_ID");
			LOCATION_COLLECTION =
				PaxTraxConfig.getProperty("LOCATION_COLLECTION");
			CHANGE_LANGUAGE_COUNTRY =
				PaxTraxConfig.getProperty("CHANGE_LANGUAGE_COUNTRY");
			LANGUAGE = PaxTraxConfig.getProperty("LANGUAGE");
			TRANSACTION = PaxTraxConfig.getProperty("TRANSACTION");
			FROM_PAGE = PaxTraxConfig.getProperty("FROM_PAGE");
			MAINTAIN_USER_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_USER_PAGE");
			STORE = PaxTraxConfig.getProperty("STORE");
			ALL_LOCATION_RECORDS =
				PaxTraxConfig.getProperty("ALL_LOCATION_RECORDS");
			SIZE_OF_ALL_LOCATION_RECORDS =
				PaxTraxConfig.getProperty("SIZE_OF_ALL_LOCATION_RECORDS");
			LOCATION_PAGE_NUMBER =
				PaxTraxConfig.getProperty("LOCATION_PAGE_NUMBER");
			ALL_NACCS_RECORDS = PaxTraxConfig.getProperty("ALL_NACCS_RECORDS");
			SIZE_OF_ALL_NACCS_RECORDS =
				PaxTraxConfig.getProperty("SIZE_OF_ALL_NACCS_RECORDS");
			NACCS_PAGE_NUMBER = PaxTraxConfig.getProperty("NACCS_PAGE_NUMBER");
			ALL_FLIGHT_RECORDS =
				PaxTraxConfig.getProperty("ALL_FLIGHT_RECORDS");
			SIZE_OF_ALL_FLIGHT_RECORDS =
				PaxTraxConfig.getProperty("SIZE_OF_ALL_FLIGHT_RECORDS");
			//added for CA#290863 by vignesh starts here
			VESSEL_MODE_CHECKED = PaxTraxConfig.getProperty("VESSEL_MODE_CHECKED");
			VESSEL_AIRLINE_CODE_ID = PaxTraxConfig.getProperty("VESSEL_AIRLINE_CODE_ID");
			//added for CA#290863 by vignesh ends here
			FLIGHT_PAGE_NUMBER =
				PaxTraxConfig.getProperty("FLIGHT_PAGE_NUMBER");
			ALL_FLIGHT_OVERRIDE_RECORDS =
				PaxTraxConfig.getProperty("ALL_FLIGHT_OVERRIDE_RECORDS");
			SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS =
				PaxTraxConfig.getProperty(
					"SIZE_OF_ALL_FLIGHT_OVERRIDE_RECORDS");
			FLIGHT_OVERRIDE_PAGE_NUMBER =
				PaxTraxConfig.getProperty("FLIGHT_OVERRIDE_PAGE_NUMBER");
			USER_DETAILS = PaxTraxConfig.getProperty("USER_DETAILS");
			TRUE = PaxTraxConfig.getProperty("TRUE");
			ACTIVE = PaxTraxConfig.getProperty("ACTIVE");
			DEACTIVE = PaxTraxConfig.getProperty("DEACTIVE");
			LOCK = PaxTraxConfig.getProperty("LOCK");
			BACK_TO_SEARCH_USER_PAGE =
				PaxTraxConfig.getProperty("BACK_TO_SEARCH_USER_PAGE");
			PASSWORD = PaxTraxConfig.getProperty("PASSWORD");
			OLD_PASSWORD = PaxTraxConfig.getProperty("OLD_PASSWORD");
			NEW_PASSWORD = PaxTraxConfig.getProperty("NEW_PASSWORD");
			CONFIRM_PASSWORD = PaxTraxConfig.getProperty("CONFIRM_PASSWORD");
			INCORRECT_PASSWORD =
				PaxTraxConfig.getProperty("INCORRECT_PASSWORD");
			SAVE_REASON = PaxTraxConfig.getProperty("SAVE_REASON");
			REFERENCE_TYPE = PaxTraxConfig.getProperty("REFERENCE_TYPE");
			AIRPORT = PaxTraxConfig.getProperty("AIRPORT");
			COUNTRY = PaxTraxConfig.getProperty("COUNTRY");
			LOCATION_TYPE = PaxTraxConfig.getProperty("LOCATION_TYPE");
			NATIONALITY = PaxTraxConfig.getProperty("NATIONALITY");
			PICK_UP_LOCATION = PaxTraxConfig.getProperty("PICK_UP_LOCATION");
			SHIFT = PaxTraxConfig.getProperty("SHIFT");
			LANUGAGES = PaxTraxConfig.getProperty("LANUGAGES");
			AIRLINE_CODE = PaxTraxConfig.getProperty("AIRLINE_CODE");
			DUTY_TYPE = PaxTraxConfig.getProperty("DUTY_TYPE");
			MAINTAIN_SKU_PAGE = PaxTraxConfig.getProperty("MAINTAIN_SKU_PAGE");
			VIEW_SKU_PAGE = PaxTraxConfig.getProperty("VIEW_SKU_PAGE");
			INDEX = PaxTraxConfig.getProperty("INDEX");
			LOCATION_ID = PaxTraxConfig.getProperty("LOCATION_ID");
			LOCATION_DESC = PaxTraxConfig.getProperty("LOCATION_DESC");
			LOCATION_CUT_OFF_TIME =
				PaxTraxConfig.getProperty("LOCATION_CUT_OFF_TIME");
			LOCATION_SPND_LIMIT_TR =
				PaxTraxConfig.getProperty("LOCATION_SPND_LIMIT_TR");
			LOCATION_DUTY_FREE_AMT =
				PaxTraxConfig.getProperty("LOCATION_DUTY_FREE_AMT");
			LOCATION_BAGTRACK_REQ =
				PaxTraxConfig.getProperty("LOCATION_BAGTRACK_REQ");
			LOCATION_OVER_REF = PaxTraxConfig.getProperty("LOCATION_OVER_REF");
			LOCATION_DELETED = PaxTraxConfig.getProperty("LOCATION_DELETED");
			LOCATION_TYPE_CODE_CODE_ID =
				PaxTraxConfig.getProperty("LOCATION_TYPE_CODE_CODE_ID");
			LOCATION_TYPE_REF_ID =
				PaxTraxConfig.getProperty("LOCATION_TYPE_REF_ID");
			LOCATION_DELETED_TRUE =
				PaxTraxConfig.getProperty("LOCATION_DELETED_TRUE");
			LOCATION_DELETED_FALSE =
				PaxTraxConfig.getProperty("LOCATION_DELETED_FALSE");
			LOCATION_ERROR = PaxTraxConfig.getProperty("LOCATION_ERROR");
			TIME_HR = PaxTraxConfig.getProperty("TIME_HR");
			TIME_MIN = PaxTraxConfig.getProperty("TIME_MIN");
			SAVE_FLIGHT = PaxTraxConfig.getProperty("SAVE_FLIGHT");
			CANCEL_FLIGHT_HOME =
				PaxTraxConfig.getProperty("CANCEL_FLIGHT_HOME");
			CANCEL_FLIGHT_SEARCH =
				PaxTraxConfig.getProperty("CANCEL_FLIGHT_SEARCH");
			FLIGHT_CREATE = PaxTraxConfig.getProperty("FLIGHT_CREATE");
			SAVE_OVERRIDE_FLIGHT =
				PaxTraxConfig.getProperty("SAVE_OVERRIDE_FLIGHT");
			LOAD_OVERRIDE_FLIGHT =
				PaxTraxConfig.getProperty("LOAD_OVERRIDE_FLIGHT");
			CANCEL_OVERRIDE_FLIGHT =
				PaxTraxConfig.getProperty("CANCEL_OVERRIDE_FLIGHT");
			FLIGHT_TYPE = PaxTraxConfig.getProperty("FLIGHT_TYPE");
			SCHEDULED = PaxTraxConfig.getProperty("SCHEDULED");
			NON_SCHEDULED = PaxTraxConfig.getProperty("NON_SCHEDULED");
			CREATE_LOCATION_PAGE_LOAD =
				PaxTraxConfig.getProperty("CREATE_LOCATION_PAGE_LOAD");
			SEARCH_LOCATION_PAGE_LOAD =
				PaxTraxConfig.getProperty("SEARCH_LOCATION_PAGE_LOAD");
			LOCATION_TYPE_FLAG =
				PaxTraxConfig.getProperty("LOCATION_TYPE_FLAG");
			EN = PaxTraxConfig.getProperty("EN");
			JP = PaxTraxConfig.getProperty("JP");
			PAGE = PaxTraxConfig.getProperty("PAGE");
			ITEM_NUMBER_SKIP = PaxTraxConfig.getProperty("ITEM_NUMBER_SKIP");
			INSERT = PaxTraxConfig.getProperty("INSERT");
			SKU_ERROR = PaxTraxConfig.getProperty("SKU_ERROR");
			SKU_APPEND = PaxTraxConfig.getProperty("SKU_APPEND");
			PRESENT = PaxTraxConfig.getProperty("PRESENT");
			NACCS_FILE_GENERATION_PAGE =
				PaxTraxConfig.getProperty("NACCS_FILE_GENERATION_PAGE");
			UPC_RETURN = PaxTraxConfig.getProperty("UPC_RETURN");
			UPC_LIST = PaxTraxConfig.getProperty("UPC_LIST");
			INITIAL_STATUS = PaxTraxConfig.getProperty("INITIAL_STATUS");
			CONFIRM_MESSAGE = PaxTraxConfig.getProperty("CONFIRM_MESSAGE");

			SAVE_PAX_PAGE = PaxTraxConfig.getProperty("SAVE_PAX_PAGE");
			CREATE_PAX_PAGE = PaxTraxConfig.getProperty("CREATE_PAX_PAGE");
			COUNTRY_LIST = PaxTraxConfig.getProperty("COUNTRY_LIST");
			NATIONALITY_LIST = PaxTraxConfig.getProperty("NATIONALITY_LIST");
			AIRLINE_CODE_LIST_DEP =
				PaxTraxConfig.getProperty("AIRLINE_CODE_LIST_DEP");
			AIRLINE_CODE_LIST_ARR =
				PaxTraxConfig.getProperty("AIRLINE_CODE_LIST_ARR");
			CREATE_PASSENGER = PaxTraxConfig.getProperty("CREATE_PASSENGER");
			INVALID_PAX_SEARCH_PAGE =
				PaxTraxConfig.getProperty("INVALID_PAX_SEARCH_PAGE");

			ENQUIRY_SUMMARY_SEARCH_PAGE =
				PaxTraxConfig.getProperty("ENQUIRY_SUMMARY_SEARCH_PAGE");
			ENQUIRY_SUBMISSION_SEARCH_PAGE =
				PaxTraxConfig.getProperty("ENQUIRY_SUBMISSION_SEARCH_PAGE");
			ENQUIRY_REPORT_PAGE =
				PaxTraxConfig.getProperty("ENQUIRY_REPORT_PAGE");

			PAX_BO_HOME_JNDI = PaxTraxConfig.getProperty("PAX_BO_HOME_JNDI");
			TA_BO_HOME_JNDI = PaxTraxConfig.getProperty("TA_BO_HOME_JNDI");
			FWD_MAINTAIN_PAX_PAGE =
				PaxTraxConfig.getProperty("FWD_MAINTAIN_PAX_PAGE");
			FWD_MAINTAIN_CONFIRM_PAGE =
				PaxTraxConfig.getProperty("FWD_MAINTAIN_CONFIRM_PAGE");
			DISABLE_PAX_SCREEN =
				PaxTraxConfig.getProperty("DISABLE_PAX_SCREEN");
			FWD_PAX_SEARCH_PAGE =
				PaxTraxConfig.getProperty("FWD_PAX_SEARCH_PAGE");
			FWD_TA_CREATE_PAGE =
				PaxTraxConfig.getProperty("FWD_TA_CREATE_PAGE");
			FWD_TA_CREATE_CONFIRMATION_PAGE =
				PaxTraxConfig.getProperty("FWD_TA_CREATE_CONFIRMATION_PAGE");
			FWD_TA_MAINTAIN_PAGE =
				PaxTraxConfig.getProperty("FWD_TA_MAINTAIN_PAGE");
			FWD_TA_MAINTAIN_CONFIRMATION_PAGE =
				PaxTraxConfig.getProperty("FWD_TA_MAINTAIN_CONFIRMATION_PAGE");
			DISABLE_TA_SCREEN = PaxTraxConfig.getProperty("DISABLE_TA_SCREEN");
			TA_DEACTIVATED = PaxTraxConfig.getProperty("TA_DEACTIVATED");
			FWD_TA_SEARCH_PAGE =
				PaxTraxConfig.getProperty("FWD_TA_SEARCH_PAGE");
			POSTCODE_PREFIX_SIZE =
				Integer.parseInt(
					PaxTraxConfig.getProperty("POSTCODE_PREFIX_SIZE"));
			POSTCODE_SUFFIX_SIZE =
				Integer.parseInt(
					PaxTraxConfig.getProperty("POSTCODE_SUFFIX_SIZE"));
			ACTION_MESSAGE_PAX =
				PaxTraxConfig.getProperty("ACTION_MESSAGE_PAX");
			FROM_MAINTAIN_PAX_PAGE_TO_PAX_SEARCH_PAGE =
				PaxTraxConfig.getProperty(
					"FROM_MAINTAIN_PAX_PAGE_TO_PAX_SEARCH_PAGE");
			TRAVEL_AGENT_LOOKUP_PAGE =
				PaxTraxConfig.getProperty("TRAVEL_AGENT_LOOKUP_PAGE");
			FILE_UPLOAD_BASE = PaxTraxConfig.getProperty("FILE_UPLOAD_BASE");
			FWD_PAX_FILE_UPLOAD_PAGE =
				PaxTraxConfig.getProperty("FWD_PAX_FILE_UPLOAD_PAGE");
			PAX_FILE_DELIMITER =
				PaxTraxConfig.getProperty("PAX_FILE_DELIMITER").charAt(0);
			GROUP = PaxTraxConfig.getProperty("GROUP");
			MAINTAIN_SKU_JSP = PaxTraxConfig.getProperty("MAINTAIN_SKU_JSP");
			ERROR_CODE = PaxTraxConfig.getProperty("ERROR_CODE");
			SKU_NUMBER = PaxTraxConfig.getProperty("SKU_NUMBER");
			SOLD = PaxTraxConfig.getProperty("SOLD");
			PICKED_UP = PaxTraxConfig.getProperty("PICKED_UP");
			GENERATED = PaxTraxConfig.getProperty("GENERATED");
			SUBMITTED = PaxTraxConfig.getProperty("SUBMITTED");
			ENTRY_NUMBER_RECIEVED =
				PaxTraxConfig.getProperty("ENTRY_NUMBER_RECIEVED");
			CANCELLED = PaxTraxConfig.getProperty("CANCELLED");
			NACCS_GENERATED_MESSAGE =
				PaxTraxConfig.getProperty("NACCS_GENERATED_MESSAGE");
			NACCS_FAILURE_MESSAGE =
				PaxTraxConfig.getProperty("NACCS_FAILURE_MESSAGE");
			GENERATED_LIST = PaxTraxConfig.getProperty("GENERATED_LIST");

			ALL_SUMMARY_RECORDS =
				PaxTraxConfig.getProperty("ALL_SUMMARY_RECORDS");
			ALL_SUBMISSION_RECORDS =
				PaxTraxConfig.getProperty("ALL_SUBMISSION_RECORDS");
			REPORT_ERROR = PaxTraxConfig.getProperty("REPORT_ERROR");

			/***
			*
			* POS constants
			*
			****/

			POS_XML_NS_URI_TRIVERSITY =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.namespace.uri.triversity");
			POS_XML_NS_URI_RETAIL =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.namespace.uri.retail");
			POS_XML_NS_URI_SCHEMA =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.namespace.uri.schema");

			POS_XML_ROOT_NAME_REQUEST_CUSTOMER =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.root.request.customer");
			POS_XML_ROOT_NAME_RESPONSE_CUSTOMER =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.root.response.customer");

			POS_XML_ROOT_NAME_REQUEST_POST_CODE_LOOKUP =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.root.request.postcode");
			POS_XML_ROOT_NAME_RESPONSE_POST_CODE_LOOKUP =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.root.response.postcode");

			POS_XML_ROOT_NAME_REQUEST_REFUND_VERIFICATION =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.root.request.refund");
			POS_XML_ROOT_NAME_RESPONSE_REFUND_VERIFICATION =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.xml.root.response.refund");

			POS_MQ_CUSTOMER_RESPONSE_QUEUE_JNDI =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.mq.response.queue.customer.jndi");
			POS_MQ_CONNECTION_FACTORY_JNDI_NAME =
				PaxTraxConfig.getProperty(
					"paxtrax.pos.mq.connection.factory.jndi");

			POS_EJB_MESSAGE_SENDER_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.common.business.MessageSenderHome");
			POS_EJB_CUSTOMER_REQUEST_HANDLER_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.pos.business.CustomerRequestHandlerHome");
			POS_EJB_POSTCODE_HANDLER_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.pos.business.PostCodeHandlerHome");
			POS_EJB_MSG_PROCESSOR_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.pos.business.MessageProcessorHome");
			POS_EJB_UUID_GENERATOR_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.common.business.UUIDGeneratorHome");
			POS_EJB_REFUND_VERIFIER_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.pos.business.RefundVerifierHome");
			POS_EJB_ERROR_MSG_HANDLER_HOME_JNDI =
				PaxTraxConfig.getProperty(
					"ejb.com.dfs.paxtrax.pos.business.ErrorMessageHandlerHome");

			/***
			*
			* SALES constants
			*
			****/
			SALES_EJB_SALES_MESSAGE_PROCESSOR_JNDI =
				PaxTraxConfig.getProperty(
					"SALES_EJB_SALES_MESSAGE_PROCESSOR_JNDI");
			SALES_EJB_SALES_DATA_HANDLER_JNDI =
				PaxTraxConfig.getProperty("SALES_EJB_SALES_DATA_HANDLER_JNDI");
			//For Wincor sales processing
			WINCOR_SALES_EJB_SALES_DATA_HANDLER_JNDI =
				PaxTraxConfig.getProperty("WINCOR_SALES_EJB_SALES_DATA_HANDLER_JNDI");
			SALES_QUEUE_MCS_JNDI =
				PaxTraxConfig.getProperty("SALES_QUEUE_MCS_JNDI");

			/* Properties for LTS */
			LTS_QUEUE_PAXTRAX_JNDI =
				PaxTraxConfig.getProperty("LTS_QUEUE_PAXTRAX_JNDI");
			/* Properties for PLU */

			PLU_MESSAGE_PROCESSOR_JNDI_HOME =
				PaxTraxConfig.getProperty(
					"paxtrax.plu.messageProessorHomeJndi");

			PLU_TEMP_DIRECTORY =
				PaxTraxConfig.getProperty("paxtrax.plu.temp.dir");

			PLU_MESSAGE_SENDER_JNDI_HOME =
				PaxTraxConfig.getProperty("paxtrax.plu.messageSenderHomeJndi");

			PLU_MESSAGE_SENDER_QUEUE_NAME =
				PaxTraxConfig.getProperty("paxtrax.plu_response_queue_JNDI");

			BT_REPORTS_BAG_ENQUIRY =
				PaxTraxConfig.getProperty("BT_REPORTS_BAG_ENQUIRY");
			BT_REPORTS_BAG_STATUS_BY_FLIGHT =
				PaxTraxConfig.getProperty("BT_REPORTS_BAG_STATUS_BY_FLIGHT");
			BT_REPORTS_BAG_NOT_READY_FOR_PICKUP =
				PaxTraxConfig.getProperty(
					"BT_REPORTS_BAG_NOT_READY_FOR_PICKUP");
			BT_REPORTS_CARTON_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("BT_REPORTS_CARTON_TRACKING_ENQUIRY");
			BT_REPORTS_BIN_LOC_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty(
					"BT_REPORTS_BIN_LOC_TRACKING_ENQUIRY");
			BT_REPORTS_CAGE_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("BT_REPORTS_CAGE_TRACKING_ENQUIRY");
			BT_REPORTS_TRUCK_TRACKING_ENQUIRY =
				PaxTraxConfig.getProperty("BT_REPORTS_TRUCK_TRACKING_ENQUIRY");
			BT_REPORTS_PURCHASE_ENQUIRY_BY_PAX =
				PaxTraxConfig.getProperty("BT_REPORTS_PURCHASE_ENQUIRY_BY_PAX");
			BT_REPORTS_ITEM_ENQUIRY =
				PaxTraxConfig.getProperty("BT_REPORTS_ITEM_ENQUIRY");
			BT_REPORTS_STOCK_AT_PICKUP_LOCATION =
				PaxTraxConfig.getProperty(
					"BT_REPORTS_STOCK_AT_PICKUP_LOCATION");
			BT_REPORTS_DELIVERY_MANIFEST =
				PaxTraxConfig.getProperty("BT_REPORTS_DELIVERY_MANIFEST");

			PT_JNDI_BT_REPORTS_HOME =
				PaxTraxConfig.getProperty("PT_JNDI_BT_REPORTS_HOME");
			BT_REPORTS_MAIN_PAGE =
				PaxTraxConfig.getProperty("BT_REPORTS_MAIN_PAGE");
			PT_JNDI_BT_GEN_PICKLIST =
				PaxTraxConfig.getProperty("PT_JNDI_BT_GEN_PICKLIST");
			BT_GEN_PICKLIST_PAGE =
				PaxTraxConfig.getProperty("BT_GEN_PICKLIST_PAGE");

			PURGE_SALES_MSTR_TABLE =
				PaxTraxConfig.getProperty("PURGE_SALES_MSTR_TABLE");
			PURGE_NACCS_MSTR_TABLE =
				PaxTraxConfig.getProperty("PURGE_NACCS_MSTR_TABLE");
			PURGE_PAX_MSTR_TABLE =
				PaxTraxConfig.getProperty("PURGE_PAX_MSTR_TABLE");
			PURGE_SALES_BACKUP_TABLE =
				PaxTraxConfig.getProperty("PURGE_SALES_BACKUP_TABLE");
			PURGE_NACCS_BACKUP_TABLE =
				PaxTraxConfig.getProperty("PURGE_NACCS_BACKUP_TABLE");
			PURGE_PAX_BACKUP_TABLE =
				PaxTraxConfig.getProperty("PURGE_PAX_BACKUP_TABLE");
			TA_FILE_PATH = PaxTraxConfig.getProperty("TA_FILE_PATH");
			NACCS_FILE = PaxTraxConfig.getProperty("NACCS_FILE");

			/* Bag Tracking Constants*/

			NACBO_AMT_DISP_FORMAT =
				PaxTraxConfig.getProperty("NACBO_AMT_DISP_FORMAT");
			BAG_NOT_READY_FOR_PICKUP =
				PaxTraxConfig.getProperty("BAG_NOT_READY_FOR_PICKUP");
			BT_JNDI_BO_REPORTS_HOME =
				PaxTraxConfig.getProperty("BT_JNDI_BO_REPORTS_HOME");
			ITEM_ENQUIRY_PRINT_PAGE =
				PaxTraxConfig.getProperty("ITEM_ENQUIRY_PRINT_PAGE");
			ITEM_ENQUIRY_REPORT_PAGE =
				PaxTraxConfig.getProperty("ITEM_ENQUIRY_REPORT_PAGE");
			CREATE_BIN_LOCATION_PAGE =
				PaxTraxConfig.getProperty("CREATE_BIN_LOCATION_PAGE");

			MAINTAIN_BIN_LOCATION_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_BIN_LOCATION_PAGE");

			BIN_LOCATION_BO_HOME_JNDI =
				PaxTraxConfig.getProperty("BIN_LOCATION_BO_HOME_JNDI");

			BIN_LOCATION_CONFIRMATION =
				PaxTraxConfig.getProperty("BIN_LOCATION_CONFIRMATION");

			MAINTAIN_BIN_LOCATION_CONFIRMATION =
				PaxTraxConfig.getProperty("MAINTAIN_BIN_LOCATION_CONFIRMATION");

			SEARCH_BIN_LOCATION_PAGE =
				PaxTraxConfig.getProperty("SEARCH_BIN_LOCATION_PAGE");

			SIZE_OF_ALL_BIN_LOCATION_RECORDS =
				PaxTraxConfig.getProperty("SIZE_OF_ALL_BIN_LOCATION_RECORDS");

			CREATE_TRUCK_PAGE = PaxTraxConfig.getProperty("CREATE_TRUCK_PAGE");

			SEARCH_TRUCK_PAGE = PaxTraxConfig.getProperty("SEARCH_TRUCK_PAGE");

			TRUCK_CONFIRMATION =
				PaxTraxConfig.getProperty("TRUCK_CONFIRMATION");

			TRUCK_BO_HOME_JNDI =
				PaxTraxConfig.getProperty("TRUCK_BO_HOME_JNDI");
			CAGE_BO_HOME_JNDI = PaxTraxConfig.getProperty("CAGE_BO_HOME_JNDI");

			BAG_OVERRIDE_BO_HOME_JNDI =
				PaxTraxConfig.getProperty("BAG_OVERRIDE_BO_HOME_JNDI");

			MAINTAIN_TRUCK_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_TRUCK_PAGE");

			MAINTAIN_TRUCK_CONFIRMATION =
				PaxTraxConfig.getProperty("MAINTAIN_TRUCK_CONFIRMATION");

			SIZE_OF_ALL_TRUCK_RECORDS =
				PaxTraxConfig.getProperty("SIZE_OF_ALL_TRUCK_RECORDS");

			FROM_PAGE_NUMBER = PaxTraxConfig.getProperty("FROM_PAGE_NUMBER");

			SEARCH_BIN = PaxTraxConfig.getProperty("SEARCH_BIN");

			MAINTAIN_BIN = PaxTraxConfig.getProperty("MAINTAIN_BIN");

			CAGE_DELETED = PaxTraxConfig.getProperty("CAGE_DELETED");
			CAGE_NOT_DELETED = PaxTraxConfig.getProperty("CAGE_NOT_DELETED");
			CAGE_STATUS_DELETED =
				PaxTraxConfig.getProperty("CAGE_STATUS_DELETED");
			CAGE_STATUS_AVAILABLE =
				PaxTraxConfig.getProperty("CAGE_STATUS_AVAILABLE");
			CAGE = PaxTraxConfig.getProperty("CAGE");
			ERROR = PaxTraxConfig.getProperty("ERROR");
			SEARCH_CAGE_PAGE = PaxTraxConfig.getProperty("SEARCH_CAGE_PAGE");
			BAGTRACKING_HOME = PaxTraxConfig.getProperty("BAGTRACKING_HOME");
			CAGE_PAGE_NUMBER = PaxTraxConfig.getProperty("CAGE_PAGE_NUMBER");
			ALL_CAGE_RECORDS = PaxTraxConfig.getProperty("ALL_CAGE_RECORDS");
			VIEW_MAINTAINE_CAGE =
				PaxTraxConfig.getProperty("VIEW_MAINTAINE_CAGE");
			MAINTAIN_CAGE_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_CAGE_PAGE");
			CREATE_CAGE_PAGE = PaxTraxConfig.getProperty("CREATE_CAGE_PAGE");
			VIEW_CREATE_CAGE = PaxTraxConfig.getProperty("VIEW_CREATE_CAGE");

			CREATE_VISIT_PAGE = PaxTraxConfig.getProperty("CREATE_VISIT_PAGE");
			MAINTAIN_VISIT_DETAIL_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_VISIT_DETAIL_PAGE");
			MAINTAIN_VISIT_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_VISIT_PAGE");
			VIEW_CREATE_VISIT = PaxTraxConfig.getProperty("VIEW_CREATE_VISIT");
			VIEW_MAINTAIN_VISIT =
				PaxTraxConfig.getProperty("VIEW_MAINTAIN_VISIT");
			MAINTAIN_VISIT_CONFIRM_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_VISIT_CONFIRM_PAGE");
			MAINTAIN_TA_COMMISSION_PAGE =
				PaxTraxConfig.getProperty("MAINTAIN_TA_COMMISSION_PAGE");
			SEARCH_TA_COMMISSION_PAGE =
				PaxTraxConfig.getProperty("SEARCH_TA_COMMISSION_PAGE");
			INSERT_TA_COMMISSION_PAGE =
				PaxTraxConfig.getProperty("INSERT_TA_COMMISSION_PAGE");
			CONFIRM_TA_COMMISSION_PAGE =
				PaxTraxConfig.getProperty("CONFIRM_TA_COMMISSION_PAGE");
			REF_CODE_NAMES = PaxTraxConfig.getProperty("REF_CODE_NAMES");

			ASSIGN_BAGS_TO_CARTON =
				PaxTraxConfig.getProperty("ASSIGN_BAGS_TO_CARTON");
			REMOVE_BAGS_FROM_CARTON =
				PaxTraxConfig.getProperty("REMOVE_BAGS_FROM_CARTON");
			CLOSE_CARTON = PaxTraxConfig.getProperty("CLOSE_CARTON");
			REOPEN_CARTON = PaxTraxConfig.getProperty("REOPEN_CARTON");
			ASSIGN_CARTON_TO_WH_BIN_LOCATION =
				PaxTraxConfig.getProperty("ASSIGN_CARTON_TO_WH_BIN_LOCATION");
			SCAN_CARTON_TO_CAGE =
				PaxTraxConfig.getProperty("SCAN_CARTON_TO_CAGE");
			REMOVE_CARTONS_FROM_CAGE =
				PaxTraxConfig.getProperty("REMOVE_CARTONS_FROM_CAGE");
			CLOSE_CAGE = PaxTraxConfig.getProperty("CLOSE_CAGE");
			REOPEN_CAGE = PaxTraxConfig.getProperty("REOPEN_CAGE");
			LOAD_CAGES_TO_TRUCK =
				PaxTraxConfig.getProperty("LOAD_CAGES_TO_TRUCK");
			REMOVE_CAGE_FROM_TRUCK =
				PaxTraxConfig.getProperty("REMOVE_CAGE_FROM_TRUCK");
			UNLOAD_CAGE_FROM_TRUCK =
				PaxTraxConfig.getProperty("UNLOAD_CAGE_FROM_TRUCK");
			ASSIGN_CAGE_TO_AP_BIN_LOCATION =
				PaxTraxConfig.getProperty("ASSIGN_CAGE_TO_AP_BIN_LOCATION");
			RELEASE_CAGE_AND_CARTONS =
				PaxTraxConfig.getProperty("RELEASE_CAGE_AND_CARTONS");
			POSITIVE_PICKUP = PaxTraxConfig.getProperty("POSITIVE_PICKUP");
			SKU_LOOKUP = PaxTraxConfig.getProperty("SKU_LOOKUP");

			STAMP_DUTY_REPORT_PAGE =
				PaxTraxConfig.getProperty("STAMP_DUTY_REPORT_PAGE");
			STAMP_DUTY_PRINT_PAGE =
				PaxTraxConfig.getProperty("STAMP_DUTY_PRINT_PAGE");
			STAMP_DUTY_BO_JNDI =
				PaxTraxConfig.getProperty("STAMP_DUTY_BO_JNDI");

			DELIVERY_MANIFEST_PAGE =
				PaxTraxConfig.getProperty("DELIVERY_MANIFEST_PAGE");
			STOCK_AT_PICKUP_LOCATION =
				PaxTraxConfig.getProperty("STOCK_AT_PICKUP_LOCATION");
			PRINT_DELIVERY_MANIFEST =
				PaxTraxConfig.getProperty("PRINT_DELIVERY_MANIFEST");
			TRUCK_TRACKING_ENQUIRY_PAGE =
				PaxTraxConfig.getProperty("TRUCK_TRACKING_ENQUIRY_PAGE");
			TRUCK_TRACKING_PRINT_PAGE =
				PaxTraxConfig.getProperty("TRUCK_TRACKING_PRINT_PAGE");
			PAX_PURCHASE_INQUIRY_PAGE =
				PaxTraxConfig.getProperty("PAX_PURCHASE_INQUIRY_PAGE");
			PAX_PURCHASE_PRINT_PAGE =
				PaxTraxConfig.getProperty("PAX_PURCHASE_PRINT_PAGE");
			PRINT_STOCK_AT_PICKUP_LOCATION =
				PaxTraxConfig.getProperty("PRINT_STOCK_AT_PICKUP_LOCATION");
			BAG_STATUS_BY_FLIGHT =
				PaxTraxConfig.getProperty("BAG_STATUS_BY_FLIGHT");
			BAG_NUMBER = PaxTraxConfig.getProperty("BAG_NUMBER");
			BAG_CANCELLATION = PaxTraxConfig.getProperty("BAG_CANCELLATION");
			DEFAULT_NATIONALITY =
				PaxTraxConfig.getProperty("DEFAULT_NATIONALITY");
			TE_POS_USER = PaxTraxConfig.getProperty("TE_POS_USER");
			COMMTRAX = PaxTraxConfig.getProperty("COMMTRAX");
			CREATE_TA_BRANCH = PaxTraxConfig.getProperty("CREATE_TA_BRANCH");
			MAINTAIN_TA_BRANCH =
				PaxTraxConfig.getProperty("MAINTAIN_TA_BRANCH");
			MAINTAIN_TA_COMMISSION =
				PaxTraxConfig.getProperty("MAINTAIN_TA_COMMISSION");
			CREATE_VISIT = PaxTraxConfig.getProperty("CREATE_VISIT");
			MAINTAIN_VISIT = PaxTraxConfig.getProperty("MAINTAIN_VISIT");
			CREATE_VISIT_PAX_PAGE =
				PaxTraxConfig.getProperty("CREATE_VISIT_PAX_PAGE");
			SAVE_VISIT_PAX_PAGE =
				PaxTraxConfig.getProperty("SAVE_VISIT_PAX_PAGE");
			CREATE_SEGMENT = PaxTraxConfig.getProperty("CREATE_SEGMENT");
			MAINTAIN_SEGMENT = PaxTraxConfig.getProperty("MAINTAIN_SEGMENT");

			SALES_REPORTS_BASE_PATH =
				PaxTraxConfig.getProperty("SALES_REPORTS_BASE_PATH");
			RAC_PREASSIGNMENT_HOME_JNDI =
				PaxTraxConfig.getProperty("RAC_PREASSIGNMENT_HOME_JNDI");
			BAGTRAX_REPORTS_BASE_PATH =
				PaxTraxConfig.getProperty("BAGTRAX_REPORTS_BASE_PATH");
			WINE_CONSUMPTION_CODE =
				PaxTraxConfig.getProperty("paxtrax.naccs.wineconsumptioncode");
			WINE_ALCOHOL_STRENGTH =
				PaxTraxConfig.getProperty("paxtrax.naccs.winealcoholstrength");
			//Added by selvam for CA# 294102 starts

			BAGCHECK = PaxTraxConfig.getProperty("BAGCHECK");
			ASSIGN_TO_SEA_BIN			=PaxTraxConfig.getProperty("ASSIGN_TO_SEA_BIN");	
			RELEASE_BAGS				=PaxTraxConfig.getProperty("RELEASE_BAGS");	
			BAG_RELEASED				=PaxTraxConfig.getProperty("BAG_RELEASED");
// Added/Modified by David for CR 3659 starts
			BAG_NOT_FOUND               =PaxTraxConfig.getProperty("BAG_NOT_FOUND");
			BAG_SEARCH_NOT_FOUND		=PaxTraxConfig.getProperty("BAG_SEARCH_NOT_FOUND");
			DATE_FLIGHT_VALIDATION      =PaxTraxConfig.getProperty("DATE_FLIGHT_VALIDATION");
// Added/Modified by David for CR 3659 ends
// Added/Modified by David for CO 6781 starts -- DP Tracking
			FLIGHT_NT_FOUND               =PaxTraxConfig.getProperty("FLIGHT_NT_FOUND");
//			Added/Modified by David for CO 6781 ends -- DP Tracking
//			Added by selvam for CA# 294102 ends
		} catch (Exception e) {

		}

	}
}