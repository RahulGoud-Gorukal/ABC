package com.dfs.paxtrax.common.service;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1997-2014, DFS All rights reserved.
 *
 */

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Calendar;

import javax.ejb.CreateException;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.common.business.FlightUploadBO;
import com.dfs.paxtrax.common.business.FlightUploadBOHome;

/**
* Delegate that calls the appropriate method on the FlightUploadBO
*
* @author Cognizant Technology Solutions
* @contact Cognizant - Mohammed Faheem
*
* @version    1.0
*
*/

public class FlightUploadDelegate{
	
	/*
	 * Holds service locator instance
	 */
	private ServiceLocator serviceLocator = null;
	
	/*
	 * Holds the Home interface
	 */
	private FlightUploadBOHome flightBOHome = null;
	
	/*
	 * Hold the remote interface
	 */
	private FlightUploadBO flightBO = null;
	
	/*
	 * Jndi look up is performed here
	 */
	private void jndiCall() throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::FlightUploadDelegate::jndiCall::Begin");
		try
		{
			serviceLocator = ServiceLocator.getInstance();
			flightBOHome =
				(FlightUploadBOHome) PortableRemoteObject.narrow(serviceLocator.getEJBHome(PaxTraxConstants.FLIGHT_UPLOAD_BO_JNDI), FlightUploadBOHome.class);
		}
		catch (NamingException ne)
		{
			throw new PaxTraxSystemException(ne);
		}
		if (flightBOHome == null)
		{
			throw new PaxTraxSystemException(50000);
		}
		try
		{
			flightBO = flightBOHome.create();
		}
		catch (CreateException ce)
		{
			throw new PaxTraxSystemException(ce);
		}
		catch (RemoteException re)
		{
			throw new PaxTraxSystemException(re);
		}
		PaxTraxLog.logDebug("PaxTrax::FlightUploadDelegate::jndiCall::End");
	}
	
	/* Method that generate the flight data and sends it to the Wincor */
	public void flightData() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightUploadDelegate::flightData::Begin");

		if (flightBOHome == null) 
		{
			jndiCall();
		}

		try 
		{
			// Get the last processed Time
			boolean flightSuccess = false;
			String lastProcessedTime = flightBO.getLastProcessedDateTime();
			//String lastProcessedTime = "2014-02-19 00:00:00";
			Calendar cal = Calendar.getInstance();
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int date = cal.get(Calendar.DATE);
			int hour = cal.get(Calendar.HOUR_OF_DAY);
			int minute = cal.get(Calendar.MINUTE);
			int second = cal.get(Calendar.SECOND);
			
			String currentDate = "" + year + "-";
			currentDate = currentDate + (month >= 10 ? ("" + month): ("0" + month));
			currentDate = currentDate + "-";
			currentDate = currentDate + (date >= 10 ? ("" + date): ("0" + date));
			
			String currentTime = "";
			currentTime = (hour >= 10 ? ("" + hour): ("0" + hour));
			currentTime = currentTime + ":";
			currentTime = currentTime + (minute >= 10 ? ("" + minute) : ("0" + minute));
			currentTime = currentTime + ":";
			currentTime = currentTime + (second >= 10 ? ("" + second) : ("0" + second));
			
			//paxSuccess = flightBO.getFlightData(currentDate, currentTime, lastProcessedTime);
			flightSuccess = flightBO.getFlightData(currentDate, currentTime, lastProcessedTime);
			
			// Update the last processed to the current date-time
			if(flightSuccess){
				flightBO.updateLastProcessedDate(currentDate, currentTime);
			}
			
		} 
		catch(RemoteException re) 
		{
			throw new PaxTraxSystemException(re);
		}

		PaxTraxLog.logDebug("PaxTrax::FlightUploadDelegate::flightData::End");

	}
}
