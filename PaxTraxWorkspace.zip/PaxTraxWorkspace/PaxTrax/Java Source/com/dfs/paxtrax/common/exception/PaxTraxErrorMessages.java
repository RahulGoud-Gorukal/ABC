package com.dfs.paxtrax.common.exception;



/**
 * All application Error meessages are here. The error code is unique to give unique messages
 *
 * @author    Pankaj Dubey (Cognizant)
 * @created   March 22, 2004
 */
public class PaxTraxErrorMessages {

	// This section defines all the error codes and messages. The number range is given
	// for each category. The messages should be added for each error code within static block


	/**********************************************************
	 *
	 * Respective error codes assigned to each layers is given below. Please use
	 * this chart while defining new error messags for your layers.
	 *
	 * Use all upper cases while defining the error variables.
	 * For eg. INVALID_PASSWORD
	 *
	 **********************************************************/
	public static final int PT_SYSEXCEPTION      =  101;
	public static final int PT_CONFIG_EXCEPTION  =  102;
	public static final int USER_ALREADY_EXISTS  =  206;
	public static final int REFERENCE_EXISTS  =  207;
	public static final int LOCATION_ALREADY_EXISTS  =  208;
	public static final int LOCATION_NOT_FOUND  =  209;
	public static final int NO_RECORDS_FOUND  =  210;
	public static final int LOCATION_DEPENDENCY_EXISTS  =  216;
	public static final int HARMONIZE_CODE_ALREADY_EXISTS  =  217;
	public static final int TAX_TYPE_ALCOHOLSTRENGTH_DOES_NOT_EXIST  =  218;
	public static final int TAX_TYPE_DOES_NOT_EXIST  =  220;
	public static final int COUNTRY_OF_ORIGIN_DOES_NOT_EXIST  =  219;
	public static final int INVALID_PASSWORD  =  221;

	// Passenger Exception Codes
	public static final int PT_PASSENGER_TA_ALREADY_EXISTS = 2011;
	public static final int PT_PASSENGER_TA_DOES_NOT_EXIST = 2012;
	public static final int PT_PASSENGER_PAX_DOES_NOT_EXIST = 306;
	public static final int PT_PASSENGER_PAX_NUMBER_NOT_FOUND = 307;

	public static final int PT_PASSENGER_PAX_ALREADY_EXISTS = 2001;
	public static final int PT_PASSENGER_PAX_NO_RECORD_TO_UPDATE = 2002;
	public static final int PT_PASSENGER_PAX_DEPARTURE_FLIGHT_NO_INVALID = 2003;
	public static final int PT_PASSENGER_PAX_DEPARTURE_DATE_INVALID = 2004;
	public static final int PT_PASSENGER_PAX_ARRIVAL_FLIGHT_NO_INVALID = 2005;
	public static final int PT_PASSENGER_PAX_ARRIVAL_FLIGHT_DATE_INVALID = 2006;
	public static final int PT_PASSENGER_PAX_INVALID_TA_CODE = 2007;
	public static final int PT_PASSENGER_PAX_MANADATORY_PARAMETERS_MISSSING = 2008;
	public static final int PT_PRIMARY_PAX_NUMBER_INVALID = 2010;
	public static final int PT_INVALID_NATIONALITY_VALUE = 2014;
	public static final int PT_INVALID_COUNTRY_VALUE = 2015;
	public static final int PT_INVALID_DEPARTURE_AIRLINE_CODE_VALUE = 2016;
	public static final int PT_INVALID_ARRIVAL_AIRLINE_CODE_VALUE = 2017;
	public static final int PT_INVALID_PAX_SEQ_ID = 2018;
	public static final int PT_PAX_NUMBER_CANNOT_BE_CHANGED = 2019;
	public static final int PT_PAX_SEQUENCE_ID_IS_NULL = 2020;
	public static final int PT_PAX_FLIGHT_INVALID_OR_DELETED = 2021;
	public static final int PT_PAX_FLIGHT_CANCELLED = 2022;
	public static final int PT_PAX_INVALID_LOCATION = 2023;
	public static final int PT_PAX_DEPARTURE_FLIGHT_CANCELLED = 2024;
	public static final int PT_PAX_ARRIVAL_FLIGHT_CANCELLED = 2025;
	public static final int PT_PAX_NO_FILES_FOR_UPLAOD = 2026;
	public static final int PT_PAX_NO_OUT_OF_RANGE = 2027;
	public static final int PT_PAX_SYSTEM_SETUP_PROBLEM = 2028;
	public static final int PT_DEPT_FLIGHT_HAS_DEPARTED = 2029;
	public static final int PT_LOOKUP_EXCEEDS_MAX_LIMIT = 2040;
	public static final int PT_REPORT_GROUP_NOT_FOUND = 2041;
	public static final int PT_AUTO_PAX_NOT_GENERATED = 2042;
	public static final int PT_PAX_INFO_INVALID = 2043;

	//Code Added on 05/12/2005.
	public static final int PT_ADDRESS1_REQ = 2150;
	public static final int PT_CITY_REQ = 2151;
	public static final int PT_NATIONALITY_REQ = 2152;
	public static final int PT_DEPT_AIRLINE_REQ = 2153;

//Sales Replication Error Messages
	public static final int PT_SALES_PAX_NOT_INS_UPD = 9000;
	public static final int PT_SALES_HEADER_NOT_INSERTED = 9001;
	public static final int PT_SALES_TRANS_NOT_INSERTED = 9002;
	public static final int PT_SALES_PAYMENT_NOT_INSERTED = 9003;
	public static final int PT_SALES_DISCOUNT_NOT_INSERTED = 9004;

//	code for Refund

	public static final int SAL_TRANSACTION_RECORD_NOT_FOUND = 401;
	public static final int SUBMITTED_RECORD_TO_NACCS = 403;
	public static final int PAXTRAX_SYSTEM_ERROR = 402;

	// Code for PLU
	public static final int PLU_HEADER_NOT_FOUND = 601;
	public static final int PLU_HARMONIZE_MASTER_DATA_INVALID = 602;
	public static final int PLU_TAX_MASTER_DATA_INVALID = 603;
	public static final int PLU_COO_MASTER_DATA_INVALID= 604;
	public static final int PLU_INVALID_RECORD = 605;
	public static final int PLU_PROMOTION_NOT_FOUND = 606;

	// Code for NACCS
	public static final int INVALID_SELLING_LOCATION = 3500;
	public static final int INVALID_PAX_NO_LENGTH = 3501;
	public static final int INVALID_FILE_NAME_LENGTH = 3502;
	public static final int NABCO_PROCEDURE_FAILURE = 3503;

	// Code for BagTrackingExceptions
	public static final int NULL_DEPARTURE_DATE = 4000;
	public static final int INVALID_DEPARTURE_DATE = 4001;

	//Error Codes for BagOverride
	public static final int BAG_INVALID_BAG_NUMBER = 700;
	// Added/Modified by David for CR 3659 starts
	public static final int BAG_NOTFOUND = 799;
	// Added/Modified by David for CR 3659 ends
	// Added/Modified by David for CO 6781 starts - DP Tracking
	public static final int FLIGHT_NOTFOUND = 800;
	// Added/Modified by David for CO 6781 ends - DP Tracking
	public static final int BAG_ON_TRUCK_IN_TRANSIT = 726;
	public static final int BAG_IN_AIRPORT = 727;
	public static final int BAG_IN_AIRPORT_BINLOCATION = 703;
	public static final int BAG_PICKED_UP_BY_CUSTOMER = 704;
	public static final int BAG_TRANSFERRED_TO_HOLDING_LOCATION = 705;
	public static final int BAG_MISSING_AT_CAGE_RELEASE = 706;
	public static final int BAG_MISSING_AT_POSITIVE_PICKUP = 707;
	public static final int BAG_RETURNED = 708;
	public static final int BAG_RETURNED_IN_CARTON = 709;
	public static final int BAG_CANCELLED = 710;
	public static final int BAG_REFUNDED = 711;
	public static final int BAG_URGENT_ON_TRUCK = 712;
	public static final int BAG_URGENT_IN_TRANSIT = 713;
	public static final int BAG_INVALID_TRUCK_NUMBER = 714;
	public static final int BAG_TRUCK_IN_TRANSIT = 715;
	public static final int BAG_TRUCK_UNLOADING_IN_AIRPORT = 716;
	public static final int BAG_TRUCK_DELETED = 717;
	public static final int BAG_NORMAL_BAGS_PRESENT_PRINT_DELIVERY_MANIFEST = 718;
	public static final int BAG_SOLD = 719;
	public static final int BAG_IN_CARTON = 720;
	public static final int BAG_IN_WH_BIN = 721;
	public static final int BAG_ON_PICK_LIST = 722;
	public static final int BAG_LOADED_TO_CAGE = 723;
	public static final int BAG_ON_TRUCK = 724;
	public static final int BAG_INVALID_BIN_LOCATION = 725;

	// Error Codes for Merge PAX
	public static final int NACCS_FILE_ALREADY_GENERATED = 5000;
	public static final int DUPLICATE_PAX_NOT_FOUND = 5001;
	public static final int NABCO_MONTHLY_SUMMARY_MONTH_INVALID = 5100;
	public static final int NABCO_MONTHLY_SUMMARY_YEAR_INVALID = 5101;

	//Error code for commtrax
	public static final int VISIT_CANNOT_START = 600;
	public static final int TA_CODE_ALREADY_EXISTS = 670;
	public static final int TA_BRANCH_ALREADY_EXISTS = 671;
	public static final int INVALID_SEGMENT_CODE = 672;
	public static final int INVALID_PAX_RANGE = 673;

//	Added by selvam for CA# 294102 starts
			
	public static final int TRUCK_SEA_AVAILABLE = 801;
	public static final int TRUCK_SEA_LOADING = 802;
	public static final int INVALID_CAGE_NUMBER=891;
	public static final int INVALID_BIN_NUMBER=892;
	public static final int HOLDING_LOCATION =897;
	public static final int CAGE_SAME_BIN=896;
	public static final int BIN_MAX_COUNT=898;
	public static final int TRUCK_INVALID=500;
	public static final int CAGE_INVALID=506;
	public static final int BAG_RELEASED=900;
		
//	Added by selvam for CA# 294102 ends
			
			
	/**
	 * Gives the error message for the given error code
	 *
	 * @param errorCode Error code to get error message
	 * @return message  Error message
	 */
	public static String getErrorMessage(int errorCode) {

	 switch (errorCode) {

			case PT_SYSEXCEPTION									: return "System Exception";
			case USER_ALREADY_EXISTS 								: return "User already exists";
			case REFERENCE_EXISTS 									: return "Unable to delete, Reference exists";
			case LOCATION_ALREADY_EXISTS							: return "Location Already Exists";
			case LOCATION_NOT_FOUND								: return "Location Not Found";
			case NO_RECORDS_FOUND									: return "No Records Found";
			case LOCATION_DEPENDENCY_EXISTS						: return "Unable to Delete, Dependency Exists";
			case HARMONIZE_CODE_ALREADY_EXISTS						: return "Harmonized Code already exists";
			case TAX_TYPE_ALCOHOLSTRENGTH_DOES_NOT_EXIST			: return "TaxType and Alcohol Strength Combination Does Not Exist";
			case TAX_TYPE_DOES_NOT_EXIST							: return "Tax Type Does Not Exist";
			case COUNTRY_OF_ORIGIN_DOES_NOT_EXIST					: return "Country Of Origin Does Not Exist";
			case INVALID_PASSWORD 									: return "Incorrect Password";
			case PT_PASSENGER_TA_ALREADY_EXISTS					: return "The Travel Agent already exists.";
			case PT_PASSENGER_TA_DOES_NOT_EXIST           			: return "Travel Agent with specified TA Code does not exist";
			case PT_PASSENGER_PAX_DOES_NOT_EXIST           		: return "No PAX Record found for the specified PAX Number";
			case PT_PASSENGER_PAX_NUMBER_NOT_FOUND          		: return "No PAX Number found in the lookup request";
			case PT_PASSENGER_PAX_ALREADY_EXISTS 	 				: return "PAX Number already exists.";
			case PT_PASSENGER_PAX_NO_RECORD_TO_UPDATE				: return "No PAX Record to update";
			case PT_PASSENGER_PAX_DEPARTURE_FLIGHT_NO_INVALID  	: return "Invalid Departure Flight Number";
			case PT_PASSENGER_PAX_DEPARTURE_DATE_INVALID			: return "Departure Flight Date is invalid.";
			case PT_PASSENGER_PAX_ARRIVAL_FLIGHT_NO_INVALID		: return "Arrival Flight Number is invalid.";
			case PT_PASSENGER_PAX_ARRIVAL_FLIGHT_DATE_INVALID		: return "Arrival Flight Date is invalid.";
			case PT_PASSENGER_PAX_INVALID_TA_CODE 					: return "TA Code is invalid.";
			case PT_PASSENGER_PAX_MANADATORY_PARAMETERS_MISSSING	: return "Mandatory Parameters are missing.";
			case PT_PRIMARY_PAX_NUMBER_INVALID    					: return "Primary Pax Number is invalid";
			case PT_PAX_DEPARTURE_FLIGHT_CANCELLED					: return "Departure Flight on this date is cancelled";
			case PT_PAX_ARRIVAL_FLIGHT_CANCELLED					: return "Arrival Flight on this date was cancelled";
			case PT_INVALID_NATIONALITY_VALUE	 					: return "Invalid Nationality Value";
			case PT_INVALID_COUNTRY_VALUE							: return "Invalid Country Value";
			case PT_INVALID_DEPARTURE_AIRLINE_CODE_VALUE			: return "Invalid Departure Airline Code Value";
			case PT_INVALID_ARRIVAL_AIRLINE_CODE_VALUE				: return "Invalid Arrival Airline Code Value";
			case PT_INVALID_PAX_SEQ_ID								: return "Invalid PAX Sequence ID";
			case PT_PAX_NUMBER_CANNOT_BE_CHANGED					: return "PAX Number cannot be changed";
			case PT_PAX_SEQUENCE_ID_IS_NULL						: return "PAX Sequence ID cannot be NULL while updating";
			case PT_PAX_FLIGHT_INVALID_OR_DELETED					: return "Departure Flight is invalid or has been deleted.";
			case PT_PAX_FLIGHT_CANCELLED							: return "Departure Flight has been cancelled.";
			case PT_PAX_INVALID_LOCATION							: return "Invalid Location";
			case PT_PAX_NO_OUT_OF_RANGE							: return "PAX Number is not in the valid range.";
			case PT_PAX_SYSTEM_SETUP_PROBLEM						: return "System Set up problem";
			case PT_REPORT_GROUP_NOT_FOUND							: return "Report group not found";
			case PT_AUTO_PAX_NOT_GENERATED							: return "Auto pax number could not be generated as given location does not indicate airport location";
			case SAL_TRANSACTION_RECORD_NOT_FOUND					: return "Original Transaction not found";
			case SUBMITTED_RECORD_TO_NACCS							: return "The Original transaction was already submitted to NACCS";
			case PT_PAX_NO_FILES_FOR_UPLAOD						: return "No valid files selected for upload";
			case PLU_HEADER_NOT_FOUND								: return "PLU Header is not available as PLUListener was removed abruptly during message processing";
			case PLU_HARMONIZE_MASTER_DATA_INVALID					: return "PLU Hamonize Master Data is invalid";
			case PLU_TAX_MASTER_DATA_INVALID						: return "PLU Tax Master Data is invalid";
			case PLU_COO_MASTER_DATA_INVALID						: return "PLU Countyr Of Origin Data is invalid";
			case PLU_INVALID_RECORD								: return "Invalid PLU Record. Data Format of PLU record was errorneous";
			case PLU_PROMOTION_NOT_FOUND							: return "No Promotion record found";
			case PT_SALES_PAX_NOT_INS_UPD							: return "Sales PAX Record could not be inserted or updated.";
			case PT_SALES_HEADER_NOT_INSERTED						: return "Sales header record could not be inserted.";
			case PT_SALES_TRANS_NOT_INSERTED						: return "Sales transaction record could not be inserted";
			case PT_SALES_PAYMENT_NOT_INSERTED						: return "Sales payment record could not be inserted";
			case PT_SALES_DISCOUNT_NOT_INSERTED					: return "Sales discount record could not be inserted";
			case INVALID_SELLING_LOCATION							: return "Invalid Selling location";
			case INVALID_PAX_NO_LENGTH								: return "Invalid Pax No length";
			case INVALID_FILE_NAME_LENGTH							: return "Invalid File name length";
			case NULL_DEPARTURE_DATE								: return "Departure date is null";
			case INVALID_DEPARTURE_DATE							: return "Departure date is invalid";
			case PT_DEPT_FLIGHT_HAS_DEPARTED						: return "Departure flight has already departed";
			case PT_LOOKUP_EXCEEDS_MAX_LIMIT						: return "Search Results beyond the maximum limit. Please refine your search.";
			case NABCO_PROCEDURE_FAILURE							: return "Nabco Procedure failed. See SQL ERROR CODE for more description";
			case BAG_INVALID_BAG_NUMBER							: return "Invalid BagNumber";
			case BAG_ON_TRUCK_IN_TRANSIT							: return "Current status of the bag is 'On Truck. In Transit'";
			case BAG_IN_AIRPORT									: return "Current status of the bag is 'In Airport'";
			case BAG_IN_AIRPORT_BINLOCATION						: return "Current status of the bag is in 'In Airport Bin Location'";
			case BAG_PICKED_UP_BY_CUSTOMER							: return "Current status of the bag is 'Picked up by Customer'";
			case BAG_TRANSFERRED_TO_HOLDING_LOCATION				: return "Current status of the bag is 'Transferred to holding location'";
			case BAG_MISSING_AT_CAGE_RELEASE						: return "Current status of the bag is 'Missing at Cage Release'";
			case BAG_MISSING_AT_POSITIVE_PICKUP					: return "Current status of the bag is 'Missing at positive pickup'";
			case BAG_RETURNED										: return "Current status of the bag is 'Returned.'";
			case BAG_RETURNED_IN_CARTON							: return "Current status of the bag is 'Returned. In Carton'";
			case BAG_CANCELLED										: return "The bag has been cancelled";
			case BAG_REFUNDED										: return "The bag has been refunded";
			case BAG_URGENT_ON_TRUCK								: return "Current status of the bag is 'Urgent-On Truck'";
			case BAG_URGENT_IN_TRANSIT								: return "Current status of the bag is 'Urgent-In Transit'";
			case BAG_INVALID_TRUCK_NUMBER							: return "Invalid Truck Number";
			case BAG_TRUCK_IN_TRANSIT								: return "Bag Cannot be scanned to truck. The current status of the truck is 'In Transit'";
			case BAG_TRUCK_UNLOADING_IN_AIRPORT					: return "Bag Cannot be scanned to truck. The current status of the truck is 'Unloading in Airport'";
			case BAG_TRUCK_DELETED									: return "Bag Cannot be scanned to truck. The truck has been deleted";
			case BAG_NORMAL_BAGS_PRESENT_PRINT_DELIVERY_MANIFEST	: return "Truck contains normal bags also, Delivery manifest should be printed before departure";
			case BAG_SOLD											: return "Current status of the bag is 'Sold'";
			case BAG_IN_CARTON										: return "Current status of the bag is 'In Carton'.";
			case BAG_IN_WH_BIN										: return "Current status of the bag is 'In WH Bin'.";
			case BAG_ON_PICK_LIST									: return "Current status of the bag is 'On Picklist'";
			case BAG_LOADED_TO_CAGE								: return "Current status of the bag is 'Loaded to cage'";
			case BAG_ON_TRUCK										: return "Current status of the bag is 'On Truck'";
			case NACCS_FILE_ALREADY_GENERATED						: return "Merge cannot be done as naccs files are already generated";
			case DUPLICATE_PAX_NOT_FOUND							: return "Duplicate pax not found";
			case NABCO_MONTHLY_SUMMARY_MONTH_INVALID				: return "Nabco monthly summary month is invalid";
			case NABCO_MONTHLY_SUMMARY_YEAR_INVALID				: return "Nabco monthly summary year is invalid";
			case VISIT_CANNOT_START  								: return "Visit cannot be started";
			case TA_CODE_ALREADY_EXISTS							: return "TA Code already exists";
			case TA_BRANCH_ALREADY_EXISTS							: return "TA Branch already exists";
			case INVALID_SEGMENT_CODE								: return "Invalid Segment code";
			case INVALID_PAX_RANGE									: return "Invalid Pax Range";

			case PT_ADDRESS1_REQ									: return "Address1 Required";
			case PT_CITY_REQ										: return "City Required";
			case PT_NATIONALITY_REQ								    : return "Nationality Required";
			case PT_DEPT_AIRLINE_REQ								: return "Departure Airline Code Required";

//		Added by selvam for CA# 294102 starts
		case TRUCK_SEA_AVAILABLE								: return "Cannot assign the truck to Sea Bin. Truck is in available status";
		case TRUCK_SEA_LOADING								: return "Cannot assign the truck to Sea Bin. Truck is in loading status";
		   
		case INVALID_CAGE_NUMBER								: return "Cage Number is invalid.";
		case INVALID_BIN_NUMBER								: return "Bin Number is invalid.";
		case HOLDING_LOCATION								: return "Cage cannot be assigned to an Holding Location";
		case CAGE_SAME_BIN								: return "Cage cannot be assigned to same Bin Location";
		case BIN_MAX_COUNT								: return "Bin Count has reached maximum. Cannot assign any more cages.";
		case TRUCK_INVALID                               : return "Truck Number is invalid. Please enter a valid truck number";		   
		case CAGE_INVALID                               : return "Cage must be in 'Intransit' status to be assigned to Sea bin";
		case BAG_RELEASED 								: return "Bag cannot be changed to 'Picked by Customer'";	
// Added/Modified by David for CR 3659 starts
		case BAG_NOTFOUND								: return "Bag details not found ";
		
// Added/Modified by David for CR 3659 ends		
// Added/Modified by David for CO 6781 starts - DP Tracking
		case FLIGHT_NOTFOUND								: return "Flight details not found ";
		
//		Added/Modified by David for CO 6781 ends - DP Tracking	
				
//		Added by selvam for CA# 294102 ends


			default                								: return "Internal Server Error";

		}

	}

}
