package com.dfs.paxtrax.common.scheduler;

/*
 * Copyright (c) 2003 Cognizant technology Solutions India Ltd.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Cognizant technology Solutions India Ltd ("Confidential Information").
 * You shall  not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with CTS.
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.TimerTask;

import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.valueobject.FTPConfig;
import com.dfs.paxtrax.customs.service.NACCSDelegate;

/**
 * This Scheduler is responsible for copying Naccs Acknowledgement files
 * to the folder specified.
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 * DATE 		USER 			COMMENTS 
 * 10/06/2004	P.C. Sathish	Created 
 */
public class PaxTraxNaccsAckCopyScheduler extends TimerTask {

   	private  NACCSDelegate naccsDelegate  = null;
   	private String fileSeparator;
   	private FTPConfig ftpConfig = null;
   	
   	public PaxTraxNaccsAckCopyScheduler() {
   		init();
   	}
   	
    private void init() {
    	naccsDelegate = new NACCSDelegate();		
		PaxTraxLog.logDebug( "PaxTraxNaccsAckCopyScheduler: init(): Initialized");
		fileSeparator = System.getProperty("file.separator");
    }
   	
   	public void run() {
   		PaxTraxLog.logDebug("PaxTrax::PaxTraxNaccsAckCopyScheduler::run::Begin");
   		String essrcDir = null;
   		String esmvDir = null;
   		String mappedAckSrcDir = null;
   		String mappedAckMovDir = null;
   		try {
      	    if (ftpConfig == null) {
	        	ftpConfig = naccsDelegate.getNACCSFTPParameters();
	        	PaxTraxLog.logDebug("PaxTraxNaccsAckCopyScheduler: run(): ftpConfig got created ");
	        } else {
				essrcDir = ftpConfig.getEsAcknowledgeDestDir();
	    		esmvDir = ftpConfig.getEsAcknowledgeMoveDir();
	    		mappedAckSrcDir = ftpConfig.getMappedAckSourceDir();
	    		mappedAckMovDir = ftpConfig.getMappedAckMovDir();
	        	File mappedAckSrcFileFolder = new File(mappedAckSrcDir);
	        	File mappedAckMovFileFolder = new File(mappedAckMovDir);
	        	File mappedAckSrcFiles[] = mappedAckSrcFileFolder.listFiles();
	        	// copy the files from naccs mapped src dir to enterprise server src dir
	        	copyFiles(mappedAckSrcFiles, essrcDir, mappedAckMovDir);
	        	// once copied process the files
	        	naccsDelegate.naccsEntryNumberUpload(essrcDir,esmvDir);
	        }
   		} catch(PaxTraxSystemException e) {
   			PaxTraxLog.logDebug("PaxTraxNaccsAckCopyScheduler::run()", e);
   		}
   	}

	/**
	 * Copies a file from source directory to destination directory.
	 */	
	private boolean copyFile(File source,String destination) {
		boolean copyStatus = true;
		try {			
    		BufferedWriter out = new BufferedWriter(new FileWriter(destination), 32768);
      		BufferedReader in = new BufferedReader(new FileReader(source), 32768);
			
			int fileLength = (int) source.length();
			char charBuff[] = new char[fileLength];
				//Modified on 2006-12-28
			if(fileLength==0){
			in.close();	
	        out.close();
	        out = null;
			in = null;
			}	
			else{
				while (in.read(charBuff,0,fileLength) != -1) {
				out.write(charBuff,0,fileLength);
				}
			in.close();	
	        out.close();
	        out = null;
			in = null;
			}  
		
		} catch (IOException e) {
			PaxTraxLog.logDebug("PaxTraxNaccsAckCopyScheduler::copyFile():: IOException happened", e);
			copyStatus = false;
		}
		
		return copyStatus;
	}

	/**
	 * Copies list of files to the enterprise server folder. If copying is 
	 * successful, deletes the file.
	 */
	private void copyFiles(File[] mappedAckSrcDir, String essDir, String mappedAckMovDir) {
		boolean fileCopySuccess = false;		
    	for (int i = 0; i < mappedAckSrcDir.length; i++) {
			fileCopySuccess = copyFile(
									mappedAckSrcDir[i], essDir + "/" + mappedAckSrcDir[i].getName());
			if (fileCopySuccess) {
				copyFile(mappedAckSrcDir[i], mappedAckMovDir + "/" + mappedAckSrcDir[i].getName());
				mappedAckSrcDir[i].delete();
			}
    	}
	}

}
