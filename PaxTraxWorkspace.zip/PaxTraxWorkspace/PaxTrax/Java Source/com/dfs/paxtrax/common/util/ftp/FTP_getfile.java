/**************************************************************************************
*  PROGRAM NAME		:  ftp_get_file
*  NAME OF AUTHOR	:  Bipin
*  DATE OF CREATION	:  25/06/2004
*  DESCRIPTION	    :  This will get the selected files from the Report server.
*  VERSION		    :  1.0
*  CTS All rights reserved
*************************************************************************************/
/*
	Calling Program:getFileDownload.jsp.
	Called Programs:FTPTransferType,FTPControlSocket,FTPClient,FTPConnectMode,FTPDataSocket
					and FTPException.All these are helper classes which are used to transfer
					files from report server to the client machine.

	The function get_file will take Hashtabe as parameter and gets the related information
	to to make FTP connection to Report server.After obtaining the connection it retrives the
	required file.If file transfer is success it returns true else returns false to the calling
	program.

	| Date	 |	Programmer name   |  Ver  |  Change history
---------------------------------------------------------------------------------------------------------
|        |                    |       |
--------------------------------------------------------------------------------------------------------
*/
package com.dfs.paxtrax.common.util.ftp;
import java.util.Hashtable;
public class  FTP_getfile
{

	public boolean get_file(Hashtable param){
	boolean flag=false;
	String ftp_host=(String)param.get("ftp_host");
	String ftp_port=(String)param.get("ftp_port");
	String ftp_login=(String)param.get("ftp_login");
	String ftp_password=(String)param.get("ftp_password");
	String dir_name=(String)param.get("dir_name");
	String file_name=(String)param.get("file_name");
	String ftp_report_folder=(String)param.get("ftp_report_folder");
	try{

	FTP_client ft = new FTP_client(ftp_host,new Integer(ftp_port).intValue());
	ft.login(ftp_login,ftp_password);
	//ft.chdir(ftp_report_folder);
	ft.setType(FTP_transfertype.BINARY);

	ft.setConnectMode(FTP_connectmode.ACTIVE);

	ft.get(dir_name+file_name,file_name);


	flag=true;
	}catch(Exception e)
	{
	flag=false;
	}
	finally{
	return flag;
	}
	}
}
