/*
Copyright (c) 2002-2004, Dennis M. Sosnoski.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 * Neither the name of JiBX nor the names of its contributors may be used
   to endorse or promote products derived from this software without specific
   prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package org.jibx.runtime;

import java.util.*;

/**
 * Utility class supplying static methods. Date serialization is based on the
 * algorithms published by Peter Baum (http://www.capecod.net/~pbaum). All date
 * handling is done according to the W3C Schema specification, which uses a
 * proleptic Gregorian calendar with no year 0. Note that this differs from the
 * Java date handling, which uses a discontinuous Gregorian calendar.
 *
 * @author Dennis M. Sosnoski
 * @version 1.0
 */

public abstract class Utility
{
    /** Number of milliseconds in a minute. */
    private static final int MSPERMINUTE = 60000;
    
    /** Number of milliseconds in an hour. */
    private static final int MSPERHOUR = MSPERMINUTE*60;
    
    /** Number of milliseconds in a day. */
    private static final int MSPERDAY = MSPERHOUR*24;
    
    /** Number of milliseconds in a day as a long. */
    private static final long LMSPERDAY = (long)MSPERDAY;
    
    /** Number of milliseconds in a (non-leap) year. */
    private static final long MSPERYEAR = LMSPERDAY*365;
    
    /** Average number of milliseconds in a year within century. */
    private static final long MSPERAVGYEAR = (long)(MSPERDAY*365.25);
    
    /** Number of milliseconds in a normal century. */
    private static final long MSPERCENTURY = (long)(MSPERDAY*36524.25);
    
    /** Millisecond value of base time for internal representation. This gives
     the bias relative to January 1 of the year 1 C.E. */
    private static final long TIME_BASE = 1969*MSPERYEAR +
        (1969/4 - 19 + 4)*LMSPERDAY;
    
    /** Day number for start of month in non-leap year. */
    private static final int[] MONTHS_NONLEAP =
    {
        0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365
    };

    /** Day number for start of month in non-leap year. */
    private static final int[] MONTHS_LEAP =
    {
        0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366
    };

    /** Millisecond count prior to start of month in March 1-biased year. */
    private static final long[] BIAS_MONTHMS =
    {
        0*LMSPERDAY, 0*LMSPERDAY, 0*LMSPERDAY, 0*LMSPERDAY,
        31*LMSPERDAY, 61*LMSPERDAY, 92*LMSPERDAY, 122*LMSPERDAY,
        153*LMSPERDAY, 184*LMSPERDAY, 214*LMSPERDAY, 245*LMSPERDAY,
        275*LMSPERDAY, 306*LMSPERDAY, 337*LMSPERDAY
    };

    /**
     * Parse digits in text as integer value. This internal method is used
     * for number values embedded within lexical structures. Only decimal
     * digits can be included in the text range parsed.
     *
     * @param text text to be parsed
     * @param offset starting offset in text
     * @param length number of digits to be parsed
     * @return converted positive integer value
     * @throws JiBXException on parse error
     */

    private static int parseDigits(String text, int offset, int length)
        throws JiBXException {

        // check if overflow a potential problem
        int value = 0;
        if (length > 9) {

            // use library parse code for potential overflow
            try {
                value = Integer.parseInt(text.substring(offset, offset+length));
            } catch (NumberFormatException ex) {
                throw new JiBXException(ex.getMessage());
            }

        } else {

            // parse with no overflow worries
            int limit = offset + length;
            while (offset < limit) {
                char chr = text.charAt(offset++);
                if (chr >= '0' && chr <= '9') {
                    value = value * 10 + (chr - '0');
                } else {
                    throw new JiBXException("Non-digit in number value");
                }
            }

        }
        return value;
    }

    /**
     * Parse integer value from text. Integer values are parsed with optional
     * leading sign flag, followed by any number of digits.
     *
     * @param text text to be parsed
     * @return converted integer value
     * @throws JiBXException on parse error
     */

    public static int parseInt(String text) throws JiBXException {

        // make sure there's text to be processed
        text = text.trim();
        int offset = 0;
        int limit = text.length();
        if (limit == 0) {
            throw new JiBXException("Empty number value");
        }

        // check leading sign present in text
        boolean negate = false;
        char chr = text.charAt(0);
        if (chr == '-') {
            if (limit > 9) {

                // special case to make sure maximum negative value handled
                try {
                    return Integer.parseInt(text);
                } catch (NumberFormatException ex) {
                    throw new JiBXException(ex.getMessage());
                }

            } else {
                negate = true;
                offset++;
            }
        } else if (chr == '+') {
            offset++;
        }
        if (offset >= limit) {
            throw new JiBXException("Invalid number format");
        }

        // handle actual value conversion
        int value = parseDigits(text, offset, limit-offset);
        if (negate) {
            return -value;
        } else {
            return value;
        }
    }

    /**
     * Serialize int value to text.
     *
     * @param value int value to be serialized
     * @return text representation of value
     */

    public static String serializeInt(int value) {
        return Integer.toString(value);
    }

    /**
     * Parse long value from text. Long values are parsed with optional
     * leading sign flag, followed by any number of digits.
     *
     * @param text text to be parsed
     * @return converted long value
     * @throws JiBXException on parse error
     */

    public static long parseLong(String text) throws JiBXException {

        // make sure there's text to be processed
        text = text.trim();
        int offset = 0;
        int limit = text.length();
        if (limit == 0) {
            throw new JiBXException("Empty number value");
        }

        // check leading sign present in text
        boolean negate = false;
        char chr = text.charAt(0);
        if (chr == '-') {
            negate = true;
            offset++;
        } else if (chr == '+') {
            offset++;
        }
        if (offset >= limit) {
            throw new JiBXException("Invalid number format");
        }

        // check if overflow a potential problem
        long value = 0;
        if (limit-offset > 18) {

            // pass text to library parse code (less leading +)
            if (chr == '+') {
                text = text.substring(1);
            }
            try {
                value = Long.parseLong(text);
            } catch (NumberFormatException ex) {
                throw new JiBXException(ex.getMessage());
            }

        } else {

            // parse with no overflow worries
            while (offset < limit) {
                chr = text.charAt(offset++);
                if (chr >= '0' && chr <= '9') {
                    value = value * 10 + (chr - '0');
                } else {
                    throw new JiBXException("Non-digit in number value");
                }
            }
            if (negate) {
                value = -value;
            }

        }
        return value;
    }

    /**
     * Serialize long value to text.
     *
     * @param value long value to be serialized
     * @return text representation of value
     */

    public static String serializeLong(long value) {
        return Long.toString(value);
    }

    /**
     * Parse short value from text. Short values are parsed with optional
     * leading sign flag, followed by any number of digits.
     *
     * @param text text to be parsed
     * @return converted short value
     * @throws JiBXException on parse error
     */

    public static short parseShort(String text) throws JiBXException {
        int value = parseInt(text);
        if (value < Short.MIN_VALUE || value > Short.MAX_VALUE) {
            throw new JiBXException("Value out of range");
        }
        return (short)value;
    }

    /**
     * Serialize short value to text.
     *
     * @param value short value to be serialized
     * @return text representation of value
     */

    public static String serializeShort(short value) {
        return Short.toString(value);
    }

    /**
     * Parse byte value from text. Byte values are parsed with optional
     * leading sign flag, followed by any number of digits.
     *
     * @param text text to be parsed
     * @return converted byte value
     * @throws JiBXException on parse error
     */

    public static byte parseByte(String text) throws JiBXException {
        int value = parseInt(text);
        if (value < Byte.MIN_VALUE || value > Byte.MAX_VALUE) {
            throw new JiBXException("Value out of range");
        }
        return (byte)value;
    }

    /**
     * Serialize byte value to text.
     *
     * @param value byte value to be serialized
     * @return text representation of value
     */

    public static String serializeByte(byte value) {
        return Byte.toString(value);
    }

    /**
     * Parse boolean value from text. Boolean values are parsed as either text
     * "true" and "false", or "1" and "0" numeric equivalents.
     *
     * @param text text to be parsed
     * @return converted boolean value
     * @throws JiBXException on parse error
     */

    public static boolean parseBoolean(String text) throws JiBXException {
        text = text.trim();
        if ("true".equals(text) || "1".equals(text)) {
            return true;
        } else if ("false".equals(text) || "0".equals(text)) {
            return false;
        } else {
            throw new JiBXException("Invalid boolean value");
        }
    }

    /**
     * Serialize boolean value to text. This serializes the value using the
     * text representation as "true" or "false".
     *
     * @param value boolean value to be serialized
     * @return text representation of value
     */

    public static String serializeBoolean(boolean value) {
        return value ? "true" : "false";
    }

    /**
     * Parse char value from text. Char values are parsed with optional
     * leading sign flag, followed by any number of digits.
     *
     * @param text text to be parsed
     * @return converted char value
     * @throws JiBXException on parse error
     */

    public static char parseChar(String text) throws JiBXException {
        int value = parseInt(text);
        if (value < Character.MIN_VALUE || value > Character.MAX_VALUE) {
            throw new JiBXException("Value out of range");
        }
        return (char)value;
    }

    /**
     * Serialize char value to text.
     *
     * @param value char value to be serialized
     * @return text representation of value
     */

    public static String serializeChar(char value) {
        return Integer.toString(value);
    }

    /**
     * Parse float value from text. This uses the W3C XML Schema format for
     * floats, with the exception that it will accept "+NaN" and "-NaN" as
     * valid formats. This is not in strict compliance with the specification,
     * but is included for interoperability with other Java XML processing.
     *
     * @param text text to be parsed
     * @return converted float value
     * @throws JiBXException on parse error
     */

    public static float parseFloat(String text) throws JiBXException {
        text = text.trim();
        if ("-INF".equals(text)) {
            return Float.NEGATIVE_INFINITY;
        } else if ("INF".equals(text)) {
            return Float.POSITIVE_INFINITY;
        } else {
            try {
                return Float.parseFloat(text);
            } catch (NumberFormatException ex) {
                throw new JiBXException(ex.getMessage());
            }
        }
    }

    /**
     * Serialize float value to text.
     *
     * @param value float value to be serialized
     * @return text representation of value
     */

    public static String serializeFloat(float value) {
        if (Float.isInfinite(value)) {
            return (value < 0.0f) ? "-INF" : "INF";
        } else {
            return Float.toString(value);
        }
    }

    /**
     * Parse double value from text. This uses the W3C XML Schema format for
     * doubles, with the exception that it will accept "+NaN" and "-NaN" as
     * valid formats. This is not in strict compliance with the specification,
     * but is included for interoperability with other Java XML processing.
     *
     * @param text text to be parsed
     * @return converted double value
     * @throws JiBXException on parse error
     */

    public static double parseDouble(String text) throws JiBXException {
        text = text.trim();
        if ("-INF".equals(text)) {
            return Double.NEGATIVE_INFINITY;
        } else if ("INF".equals(text)) {
            return Double.POSITIVE_INFINITY;
        } else {
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException ex) {
                throw new JiBXException(ex.getMessage());
            }
        }
    }

    /**
     * Serialize double value to text.
     *
     * @param value double value to be serialized
     * @return text representation of value
     */

    public static String serializeDouble(double value) {
        if (Double.isInfinite(value)) {
            return (value < 0.0f) ? "-INF" : "INF";
        } else {
            return Double.toString(value);
        }
    }

    /**
     * Convert gYear text to Java date. Date values are expected to be in
     * W3C XML Schema standard format as CCYY, with optional leading sign.
     *
     * @param text text to be parsed
     * @return start of year date as millisecond value from 1 C.E.
     * @throws JiBXException on parse error
     */

    public static long parseYear(String text) throws JiBXException {

        // start by validating the length
        text = text.trim();
        boolean valid = true;
        int minc = 4;
        char chr = text.charAt(0);
        if (chr == '-') {
            minc = 5;
        } else if (chr == '+') {
            valid = false;
        }
        if (text.length() < minc) {
            valid = false;
        }
        if (!valid) {
            throw new JiBXException("Invalid year format");
        }

        // handle year conversion
        int year = parseInt(text);
        if (year == 0) {
            throw new JiBXException("Year value 0 is not allowed");
        }
        if (year > 0) {
            year--;
        }
        long day = ((long)year)*365 + year/4 - year/100 + year/400;
        return day*MSPERDAY - TIME_BASE;
    }

    /**
     * Convert gYearMonth text to Java date. Date values are expected to be in
     * W3C XML Schema standard format as CCYY-MM, with optional
     * leading sign.
     *
     * @param text text to be parsed
     * @return start of month in year date as millisecond value
     * @throws JiBXException on parse error
     */

    public static long parseYearMonth(String text) throws JiBXException {

        // start by validating the length and basic format
        text = text.trim();
        boolean valid = true;
        int minc = 7;
        char chr = text.charAt(0);
        if (chr == '-') {
            minc = 8;
        } else if (chr == '+') {
            valid = false;
        }
        int split = text.length() - 3;
        if (text.length() < minc) {
            valid = false;
        } else {
            if (text.charAt(split) != '-') {
                valid = false;
            }
        }
        if (!valid) {
            throw new JiBXException("Invalid date format");
        }

        // handle year and month conversion
        int year = parseInt(text.substring(0, split));
        if (year == 0) {
            throw new JiBXException("Year value 0 is not allowed");
        }
        int month = parseDigits(text, split+1, 2) - 1;
        if (month < 0 || month > 11) {
            throw new JiBXException("Month value out of range");
        }
        boolean leap = (year%4 == 0) && !((year%100 == 0) && (year%400 != 0));
        if (year > 0) {
            year--;
        }
        long day = ((long)year)*365 + year/4 - year/100 + year/400 +
            (leap ? MONTHS_LEAP : MONTHS_NONLEAP)[month];
        return  day*MSPERDAY - TIME_BASE;
    }

    /**
     * Convert date text to Java date. Date values are expected to be in
     * W3C XML Schema standard format as CCYY-MM-DD, with optional
     * leading sign and trailing time zone (though the time zone is ignored
     * in this case).
     *
     * @param text text to be parsed
     * @return start of day in month and year date as millisecond value
     * @throws JiBXException on parse error
     */

    public static long parseDate(String text) throws JiBXException {

        // start by validating the length and basic format
        boolean valid = true;
        int minc = 10;
        char chr = text.charAt(0);
        if (chr == '-') {
            minc = 11;
        } else if (chr == '+') {
            valid = false;
        }
        int split = text.length() - 6;
        if (text.length() < minc) {
            valid = false;
        } else {
            if (text.charAt(split) != '-' || text.charAt(split+3) != '-') {
                valid = false;
            }
        }
        if (!valid) {
            throw new JiBXException("Invalid date format");
        }

        // handle year, month, and day conversion
        int year = parseInt(text.substring(0, split));
        if (year == 0) {
            throw new JiBXException("Year value 0 is not allowed");
        }
        int month = parseDigits(text, split+1, 2) - 1;
        if (month < 0 || month > 11) {
            throw new JiBXException("Month value out of range");
        }
        long day = parseDigits(text, split+4, 2) - 1;
        boolean leap = (year%4 == 0) && !((year%100 == 0) && (year%400 != 0));
        int[] starts = leap ? MONTHS_LEAP : MONTHS_NONLEAP;
        if (day < 0 || day >= (starts[month+1]-starts[month])) {
            throw new JiBXException("Day value out of range");
        }
        if (year > 0) {
            year--;
        }
        day += ((long)year)*365 + year/4 - year/100 + year/400 + starts[month];
        return day*MSPERDAY - TIME_BASE;
    }

    /**
     * Deserialize date from text. Date values are expected to match W3C XML
     * Schema standard format as CCYY-MM-DD, with optional leading minus sign
     * if necessary. This method follows standard JiBX deserializer usage
     * requirements by accepting a <code>null</code> input.
     *
     * @param text text to be parsed (may be <code>null</code>)
     * @return converted date, or <code>null</code> if passed <code>null</code>
     * input
     * @throws JiBXException on parse error
     */

    public static Date deserializeDate(String text) throws JiBXException {
        if (text == null) {
            return null;
        } else {
            return new Date(parseDate(text));
        }
    }

    /**
     * Parse general dateTime value from text. Date values are expected to be in
     * W3C XML Schema standard format as CCYY-MM-DDThh:mm:ss.fff, with optional
     * leading sign and trailing time zone.
     *
     * @param text text to be parsed
     * @return converted date as millisecond value
     * @throws JiBXException on parse error
     */

    public static long parseDateTime(String text) throws JiBXException {

        // split text to first convert date alone
        int split = text.indexOf('T');
        if (split < 0) {
            throw new JiBXException("Missing 'T' separator in dateTime");
        }
        long result = parseDate(text.substring(0, split));

        // validate time value following date
        int limit = text.length();
        boolean valid = limit > (split+8) &&
            (text.charAt(split+3) == ':') &&
            (text.charAt(split+6) == ':');
        if (valid) {
            int hour = parseDigits(text, split+1, 2);
            int minute = parseDigits(text, split+4, 2);
            int second = parseDigits(text, split+7, 2);
            if (hour > 23 || minute > 59 || second > 60) {
                valid = false;
            } else {

                // convert to base millisecond in day
                int milli = (((hour*60)+minute)*60+second)*1000;
                split += 9;
                if (limit > split) {

                    // adjust for time zone
                    if (text.charAt(limit-1) == 'Z') {
                        limit--;
                    } else {
                        char chr = text.charAt(limit-6);
                        if (chr == '-' || chr == '+') {
                            hour = parseDigits(text, limit-5, 2);
                            minute = parseDigits(text, limit-2, 2);
                            if (hour > 23 || minute > 59) {
                                valid = false;
                            } else {
                                int offset = ((hour*60)+minute)*60*1000;
                                if (chr == '-') {
                                    milli += offset;
                                } else {
                                    milli -= offset;
                                }
                            }
                            limit -= 6;
                        }
                    }

                    // check for trailing fractional second
                    if (text.charAt(split) == '.') {
                        double fraction = Double.parseDouble
                            (text.substring(split, limit));
                        milli += fraction*1000.0;
                    } else if (limit > split) {
                        valid = false;
                    }
                }

                // adjust the date value for return
                result += milli;
            }
        }

        // check for valid result
        if (valid) {
            return result;
        } else {
            throw new JiBXException("Invalid dateTime format");
        }
    }

    /**
     * Deserialize date from general dateTime text. Date values are expected to
     * match W3C XML Schema standard format as CCYY-MM-DDThh:mm:ss, with
     * optional leading minus sign and trailing seconds decimal, as necessary.
     * This method follows standard JiBX deserializer usage requirements by
     * accepting a <code>null</code> input.
     *
     * @param text text to be parsed (may be <code>null</code>)
     * @return converted date, or <code>null</code> if passed <code>null</code>
     * input
     * @throws JiBXException on parse error
     */

    public static Date deserializeDateTime(String text) throws JiBXException {
        if (text == null) {
            return null;
        } else {
            return new Date(parseDateTime(text));
        }
    }

    /**
     * Format year number consistent with W3C XML Schema definitions, using a
     * minimum of four digits padded with zeros if necessary. A leading minus
     * sign is included for years prior to 1 C.E.
     *
     * @param year number to be formatted
     * @param buff text formatting buffer
     */

    protected static void formatYearNumber(long year, StringBuffer buff) {
        
        // start with minus sign for dates prior to 1 C.E.
        if (year <= 0) {
            buff.append('-');
            year = -(year-1);
        }
        
        // add padding if needed to bring to length of four
        if (year < 1000) {
            buff.append('0');
            if (year < 100) {
                buff.append('0');
                if (year < 10) {
                    buff.append('0');
                }
            }
        }
        
        // finish by converting the actual year number
        buff.append(year);
    }

    /**
     * Format a positive number as two digits. This uses an optional leading
     * zero digit for values less than ten.
     *
     * @param value number to be formatted (<code>0</code> to <code>99</code>)
     * @param buff text formatting buffer
     */
    
    protected static void formatTwoDigits(int value, StringBuffer buff) {
        if (value < 10) {
            buff.append('0');
        }
        buff.append(value);
    }

    /**
     * Format time in milliseconds to year number. The resulting year number
     * format is consistent with W3C XML Schema definitions, using a minimum
     * of four digits padded with zeros if necessary. A leading minus sign is
     * included for years prior to 1 C.E.
     *
     * @param value time in milliseconds to be converted (from 1 C.E.)
     * @param buff text formatting buffer
     * @return milliseconds within year (remainder from formatting)
     */

    protected static void formatYear(long value, StringBuffer buff) {
        
        // find the actual year and month number; this uses a integer arithmetic
        //  conversion based on Baum, first making the millisecond count
        //  relative to March 1 of the year 0 C.E., then using simple arithmetic
        //  operations to compute century, year, and month; it's slightly
        //  different for pre-C.E. values because of Java's handling of divisions.
        long time = value + 306*LMSPERDAY + LMSPERDAY*3/4;
        long century = time / MSPERCENTURY;             // count of centuries
        long adjusted = time + (century - (century/4)) * MSPERDAY;
        int year = (int)(adjusted / MSPERAVGYEAR);      // year in March 1 terms
        if (adjusted < 0) {
            year--;
        }
        long yms = adjusted + LMSPERDAY/4 - (year * 365 + year/4) * LMSPERDAY;
        int yday = (int)(yms / LMSPERDAY);              // day number in year
        int month = (5*yday + 456) / 153;               // (biased) month number
        if (month > 12) {                               // convert start of year
            year++;
        }
        
        // format year to text
        formatYearNumber(year, buff);
    }

    /**
     * Format time in milliseconds to year number and month number. The 
     * resulting year number format is consistent with W3C XML Schema
     * definitions, using a minimum of four digits for the year and exactly
     * two digits for the month.
     *
     * @param value time in milliseconds to be converted (from 1 C.E.)
     * @param buff text formatting buffer
     * @return number of milliseconds into month
     */

    protected static long formatYearMonth(long value, StringBuffer buff) {
        
        // find the actual year and month number; this uses a integer arithmetic
        //  conversion based on Baum, first making the millisecond count
        //  relative to March 1 of the year 0 C.E., then using simple arithmetic
        //  operations to compute century, year, and month; it's slightly
        //  different for pre-C.E. values because of Java's handling of divisions.
        long time = value + 306*LMSPERDAY + LMSPERDAY*3/4;
        long century = time / MSPERCENTURY;             // count of centuries
        long adjusted = time + (century - (century/4)) * MSPERDAY;
        int year = (int)(adjusted / MSPERAVGYEAR);      // year in March 1 terms
        if (adjusted < 0) {
            year--;
        }
        long yms = adjusted + LMSPERDAY/4 - (year * 365 + year/4) * LMSPERDAY;
        int yday = (int)(yms / LMSPERDAY);              // day number in year
        if (yday == 0) {                                // special for negative
            boolean bce = year < 0;
            if (bce) {
                year--;
            }
            int dcnt = year % 4 == 0 ? 366 : 365;
            if (!bce) {
                year--;
            }
            yms += dcnt * LMSPERDAY;
            yday += dcnt;
        }
        int month = (5*yday + 456) / 153;               // (biased) month number
        long rem = yms - BIAS_MONTHMS[month] - LMSPERDAY;   // ms into month
        if (month > 12) {                               // convert start of year
            year++;
            month -= 12;
        }
        
        // format year and month as text
        formatYearNumber(year, buff);
        buff.append('-');
        formatTwoDigits(month, buff);
        
        // return extra milliseconds into month
        return rem;
    }

    /**
     * Format time in milliseconds to year number, month number, and day
     * number. The resulting year number format is consistent with W3C XML
     * Schema definitions, using a minimum of four digits for the year and
     * exactly two digits each for the month and day.
     *
     * @param value time in milliseconds to be converted (from 1 C.E.)
     * @param buff text formatting buffer
     * @return number of milliseconds into day
     */

    protected static int formatYearMonthDay(long value, StringBuffer buff) {
        
        // convert year and month
        long extra = formatYearMonth(value, buff);
        
        // append the day of month
        int day = (int)(extra / MSPERDAY) + 1;
        buff.append('-');
        formatTwoDigits(day, buff);
        
        // return excess of milliseconds into day
        return (int)(extra % MSPERDAY);
    }

    /**
     * Serialize time to general gYear text. Date values are formatted in
     * W3C XML Schema standard format as CCYY, with optional
     * leading sign included if necessary.
     *
     * @param time time to be converted, as milliseconds from January 1, 1970
     * @return converted gYear text
     * @throws JiBXException on conversion error
     */

    public static String serializeYear(long time) throws JiBXException {
        StringBuffer buff = new StringBuffer(6);
        formatYear(time + TIME_BASE, buff);
        return buff.toString();
    }

    /**
     * Serialize date to general gYear text. Date values are formatted in
     * W3C XML Schema standard format as CCYY, with optional
     * leading sign included if necessary.
     *
     * @param date date to be converted
     * @return converted gYear text
     * @throws JiBXException on conversion error
     */

    public static String serializeYear(Date date) throws JiBXException {
        return serializeYear(date.getTime());
    }

    /**
     * Serialize time to general gYearMonth text. Date values are formatted in
     * W3C XML Schema standard format as CCYY-MM, with optional
     * leading sign included if necessary.
     *
     * @param time time to be converted, as milliseconds from January 1, 1970
     * @return converted gYearMonth text
     * @throws JiBXException on conversion error
     */

    public static String serializeYearMonth(long time) throws JiBXException {
        StringBuffer buff = new StringBuffer(12);
        formatYearMonth(time + TIME_BASE, buff);
        return buff.toString();
    }

    /**
     * Serialize date to general gYearMonth text. Date values are formatted in
     * W3C XML Schema standard format as CCYY-MM, with optional
     * leading sign included if necessary.
     *
     * @param date date to be converted
     * @return converted gYearMonth text
     * @throws JiBXException on conversion error
     */

    public static String serializeYearMonth(Date date) throws JiBXException {
        return serializeYearMonth(date.getTime());
    }

    /**
     * Serialize time to general date text. Date values are formatted in
     * W3C XML Schema standard format as CCYY-MM-DD, with optional
     * leading sign included if necessary.
     *
     * @param time time to be converted, as milliseconds from January 1, 1970
     * @return converted date text
     * @throws JiBXException on conversion error
     */

    public static String serializeDate(long time) throws JiBXException {
        StringBuffer buff = new StringBuffer(12);
        formatYearMonthDay(time + TIME_BASE, buff);
        return buff.toString();
    }

    /**
     * Serialize date to general date text. Date values are formatted in
     * W3C XML Schema standard format as CCYY-MM-DD, with optional
     * leading sign included if necessary.
     *
     * @param date date to be converted
     * @return converted date text
     * @throws JiBXException on conversion error
     */

    public static String serializeDate(Date date) throws JiBXException {
        return serializeDate(date.getTime());
    }

    /**
     * Serialize time to general dateTime text. Date values are formatted in
     * W3C XML Schema standard format as CCYY-MM-DDThh:mm:ss, with optional
     * leading sign and trailing seconds decimal, as necessary.
     *
     * @param time time to be converted, as milliseconds from January 1, 1970
     * @return converted dateTime text
     * @throws JiBXException on conversion error
     */

    public static String serializeDateTime(long time) throws JiBXException {
        
        // start with the year, month, and day
        StringBuffer buff = new StringBuffer(24);
        int extra = formatYearMonthDay(time + TIME_BASE, buff);
        
        // append the hour, minute, and second
        buff.append('T');
        formatTwoDigits(extra/MSPERHOUR, buff);
        extra = extra % MSPERHOUR;
        buff.append(':');
        formatTwoDigits(extra/MSPERMINUTE, buff);
        extra = extra % MSPERMINUTE;
        buff.append(':');
        formatTwoDigits(extra/1000, buff);
        extra = extra % 1000;
        
        // check if decimals needed on second
        if (extra > 0) {
            buff.append('.');
            buff.append(extra / 100);
            extra = extra % 100;
            if (extra > 0) {
                buff.append(extra / 10);
                extra = extra % 10;
                if (extra > 0) {
                    buff.append(extra);
                }
            }
        }
        
        // return full text
        return buff.toString();
    }

    /**
     * Serialize date to general dateTime text. Date values are formatted in
     * W3C XML Schema standard format as CCYY-MM-DDThh:mm:ss, with optional
     * leading sign and trailing seconds decimal, as necessary.
     *
     * @param date date to be converted
     * @return converted dateTime text
     * @throws JiBXException on conversion error
     */

    public static String serializeDateTime(Date date) throws JiBXException {
        return serializeDateTime(date.getTime());
    }
    
    /**
     * General object comparison method. Don't know why Sun hasn't seen fit to
     * include this somewhere, but at least it's easy to write (over and over
     * again).
     * 
     * @param a first object to be compared
     * @param b second object to be compared
     * @return <code>true</code> if both objects are <code>null</code>, or if
     * <code>a.equals(b)</code>; <code>false</code> otherwise
     */
    
    public static boolean isEqual(Object a, Object b) {
        return (a == null) ? b == null : a.equals(b);
    }

    /**
     * Find text value in enumeration. This first does a binary search through
     * an array of allowed text matches. If a separate array of corresponding
     * values is supplied, the value at the matched position is returned;
     * otherwise the match index is returned directly.
     *
     * @param target text to be found in enumeration
     * @param enums ordered array of texts included in enumeration
     * @param vals array of values to be returned for corresponding text match
     * positions (position returned directly if this is <code>null</code>)
     * @return enumeration value for target text
     * @throws JiBXException if target text not found in enumeration
     */

    public static int enumValue(String target, String[] enums, int[] vals)
        throws JiBXException {
        int base = 0;
        int limit = enums.length - 1;
        while (base <= limit) {
            int cur = (base + limit) >> 1;
            int diff = target.compareTo(enums[cur]);
            if (diff < 0) {
                limit = cur - 1;
            } else if (diff > 0) {
                base = cur + 1;
            } else if (vals != null) {
                return vals[cur];
            } else {
                return cur;
            }
        }
        throw new JiBXException("Target value \"" + target +
            "\" not found in enumeration");
    }
}
