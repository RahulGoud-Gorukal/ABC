package com.dfs.paxtrax.admin.dao;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.exception.SkuException;
import com.dfs.paxtrax.admin.valueobject.SKUBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This is DAO class which perform insert, select and modify SkU in database
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 21/04/2004	Yuvarani    	Created      
 */

public class SKUDAO
{

	/**
	 * Constructor for this class
	 */
	public SKUDAO()
	{
	}

	/**
	 * Inserts/Updates SKU details into the database.
	 * @param SKUBean skuBean
	 * @throws PaxTraxSystemException if there is any problem in inserting 
	 * SKU details
	 */
	public String[] saveSKUDetails(SKUBean skuBean, String userId) throws PaxTraxSystemException, SkuException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDAO::saveSKUDetails::Begin");
		DBUtil util = DBUtil.getInstance();
		Connection connection = null;
		Statement statement = null;
		Statement deletion = null;
		CallableStatement callStatement = null;
		boolean checkStatus = true;
		String[] upcReturn = new String[3];
		ResultSet harmonizeCode = null, taxType = null, countryOfOrigin = null, division = null;
		try
		{
			int errorcode = 0;
			String promotionStartDate = skuBean.getPromotionStartDate();
			promotionStartDate = promotionStartDate.replace('/', '-');
			String promotionEndDate = skuBean.getPromotionEndDate();
			promotionEndDate = promotionEndDate.replace('/', '-');
			String newPriceEffectiveDate = skuBean.getNewPriceEffectiveDate();
			newPriceEffectiveDate = newPriceEffectiveDate.replace('/', '-');
			connection = util.getConnection();
			statement = connection.createStatement();
			if (!skuBean.getHarmonizedCode().equals(""))
			{
				harmonizeCode =
					statement.executeQuery(
						"select HARMONIZE_CODE from TB_HARMONIZE_MSTR where " + "HARMONIZE_CODE=" + Long.parseLong(skuBean.getHarmonizedCode()));

				if (!harmonizeCode.next())
				{
					throw new SkuException(PaxTraxConstants.HARMONIZE_CODE_ALREADY_EXISTS);
				}
				harmonizeCode.close();
			}

			if ((!skuBean.getTaxType().equals("")) && (skuBean.getAlcoholStrength() != 0))
			{
				taxType =
					statement.executeQuery(
						"select TAX_TYPE,TAX_ALCOHOL_STRENGTH from TB_TAX_MSTR "
							+ "where TAX_TYPE='"
							+ skuBean.getTaxType()
							+ "' and "
							+ "TAX_ALCOHOL_STRENGTH="
							+ skuBean.getAlcoholStrength());
				if (!taxType.next())
				{
					throw new SkuException(PaxTraxConstants.TAX_TYPE_ALCOHOLSTRENGTH_DOES_NOT_EXIST);
				}
				taxType.close();
			}

			if ((!skuBean.getTaxType().equals("")) && (skuBean.getAlcoholStrength() == 0))
			{
				taxType = statement.executeQuery("select TAX_TYPE from " + "TB_TAX_MSTR where TAX_TYPE='" + skuBean.getTaxType() + "'");
				if (!taxType.next())
				{
					throw new SkuException(PaxTraxConstants.TAX_TYPE_DOES_NOT_EXIST);
				}
				taxType.close();
			}
			countryOfOrigin =
				statement.executeQuery(
					"select COUNTRY_OF_ORIGIN from TB_COUNTRY_OF_ORIGIN_MSTR " + "where COUNTRY_OF_ORIGIN=" + Integer.parseInt(skuBean.getCountryOfOrigin()));

			if (!countryOfOrigin.next())
			{
				throw new SkuException(PaxTraxConstants.COUNTRY_OF_ORIGIN_DOES_NOT_EXIST);
			}
			countryOfOrigin.close();

			String[] upcCode = skuBean.getUpcCodeList();
			int upclength = upcCode.length;
			ResultSet upcCheck = null;
			for (int j = 0; j < upclength; j++)
			{
				upcCheck =
					statement.executeQuery(
						"select UPC_EAN,SKU_NUMBER "
							+ "from TB_UPCXREF where UPC_EAN = "
							+ Long.parseLong(upcCode[j])
							+ " and SKU_NUMBER != "
							+ Long.parseLong(skuBean.getItemNumber()));
				if (upcCheck.next())
				{
					upcReturn[0] = upcCheck.getString(1);
					upcReturn[1] = upcCheck.getString(2);
					checkStatus = false;
					break;
				}
				upcCheck.close();
			}
			if (checkStatus)
			{
				division = statement.executeQuery("select DIVISION_NUMBER from TB_DIVISION");
				int divisionNumber = 0;
				if (division.next())
				{
					divisionNumber = division.getInt(1);
				}
				division.close();
				ResultSet updateDate = statement.executeQuery("select current date " + "FROM sysibm.sysdummy1");
				String updateDate1 = null;
				if (updateDate.next())
				{
					updateDate1 = updateDate.getString(1);
				}

				deletion = connection.createStatement();
				deletion.executeUpdate("delete from TB_UPCXREF where " + "SKU_NUMBER = " + Long.parseLong(skuBean.getItemNumber()));
				deletion.close();
				String call = "CALL ADM_INSERT_SKU(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				callStatement = connection.prepareCall(call);
				callStatement.setInt(1, divisionNumber);
				callStatement.setLong(2, Long.parseLong(skuBean.getItemNumber()));
				if (skuBean.getHarmonizedCode().equals("") || skuBean.getHarmonizedCode() == null)
				{
					callStatement.setNull(3, Types.BIGINT);
				}
				else
				{
					callStatement.setLong(3, Long.parseLong(skuBean.getHarmonizedCode()));
				}
				if (skuBean.getTaxType().equals("") || skuBean.getTaxType() == null)
				{
					callStatement.setNull(4, Types.VARCHAR);
				}
				else
				{
					callStatement.setString(4, skuBean.getTaxType());
				}
				callStatement.setInt(5, Integer.parseInt(skuBean.getCountryOfOrigin()));
				callStatement.setInt(6, Integer.parseInt(skuBean.getDepartment()));
				callStatement.setString(7, skuBean.getDutyType());
				callStatement.setInt(8, Integer.parseInt(skuBean.getSellingLocation()));
				callStatement.setFloat(9, skuBean.getUnitPrice());
				callStatement.setFloat(10, skuBean.getPromotionPrice());
				if (promotionStartDate == null || promotionStartDate.equals(""))
				{
					callStatement.setNull(11, Types.DATE);
				}
				else
				{
					callStatement.setString(11, promotionStartDate);
				}

				if (promotionEndDate == null || promotionEndDate.equals(""))
				{
					callStatement.setNull(12, Types.DATE);
				}
				else
				{
					callStatement.setString(12, promotionEndDate);
				}

				callStatement.setInt(13, skuBean.getSize());

				if (skuBean.getAlcoholStrength() == 0)
					callStatement.setNull(14, Types.INTEGER);
				else
					callStatement.setInt(14, skuBean.getAlcoholStrength());

				callStatement.setFloat(15, skuBean.getNewPrice());

				if (newPriceEffectiveDate == null || newPriceEffectiveDate.equals(""))
				{
					callStatement.setNull(16, Types.DATE);
				}
				else
				{
					callStatement.setString(16, newPriceEffectiveDate);
				}
				callStatement.setString(17, skuBean.getItemDescription());
				callStatement.registerOutParameter(18, Types.INTEGER);
				callStatement.setString(19, skuBean.getGiftWithPurchase());
				callStatement.setString(20, userId);
				callStatement.setString(21, updateDate1);
				if (skuBean.getNewPrice() == 0.0)
				{
					callStatement.setNull(22, Types.INTEGER);
				}
				else
				{
					callStatement.setInt(22, 1);
				}
				if (skuBean.getPromotionPrice() == 0.0)
				{
					callStatement.setNull(23, Types.INTEGER);
				}
				else
				{
					callStatement.setInt(23, 1);
				}
				callStatement.execute();
				errorcode = callStatement.getInt(18);

				if (errorcode != 0)
				{
					PaxTraxLog.logError("PaxTrax::SKUDAO::saveSKUDetails" + errorcode);
					throw new PaxTraxSystemException(errorcode);
				}
				callStatement.close();
				for (int i = 0; i < upclength; i++)
				{
					String call1 = "CALL ADM_INSERT_UPC(?,?,?,?,?,?)";
					callStatement = connection.prepareCall(call1);
					callStatement.setInt(1, divisionNumber);
					callStatement.setLong(2, Long.parseLong(skuBean.getItemNumber()));
					callStatement.setLong(3, Long.parseLong(upcCode[i]));
					callStatement.registerOutParameter(4, Types.INTEGER);
					callStatement.setString(5, userId);
					callStatement.setString(6, updateDate1);
					callStatement.execute();

					errorcode = callStatement.getInt(4);
					if (errorcode != 0)
					{
						PaxTraxLog.logError("PaxTrax::SKUDAO::saveSKUDetails" + errorcode);
						throw new PaxTraxSystemException(errorcode);
					}

				}
			}
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("PaxTrax::SKUDAO::saveSKUDetails", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (harmonizeCode != null)
				{
					harmonizeCode.close();
					harmonizeCode = null;
				}
				if (taxType != null)
				{
					taxType.close();
					taxType = null;
				}
				if (countryOfOrigin != null)
				{
					countryOfOrigin.close();
					countryOfOrigin = null;
				}
				if (division != null)
				{
					division.close();
					division = null;
				}
				if (callStatement != null)
				{
					callStatement.close();
					callStatement = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::SKUDAO::saveSKUDetails", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::SKUDAO::saveSKUDetails::End");
		return upcReturn;
	}

	/**
	 * Loads Sku Location Details
	 * @return ArrayList locationList
	 * @throws PaxTraxSystemException if there is any problem in loading 
	 * Sku details
	 */

	public ArrayList loadSkuPage() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDAO::loadSkuPage::Begin");
		DBUtil util = DBUtil.getInstance();
		ArrayList locationList = new ArrayList();
		Connection connection = null;
		CallableStatement statement = null;
		ResultSet resultset = null;
		try
		{
			connection = util.getConnection();
			String call = "CALL getlocation";
			statement = connection.prepareCall(call);
			statement.execute();
			resultset = statement.getResultSet();
			while (resultset.next())
			{
				locationList.add(resultset.getString(1));
			}
		}
		catch (SQLException sqlexception)
		{
			PaxTraxLog.logError("PaxTrax::SKUDAO::loadSkuPage", sqlexception);
			throw new PaxTraxSystemException(sqlexception);

		}
		finally
		{
			try
			{
				if (resultset != null)
				{
					resultset.close();
					resultset = null;
				}
				if (statement != null)
				{
					statement = null;
					statement.close();
				}
				if (connection != null)
				{
					connection = null;
					connection.close();
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::SKUDAO::loadSkuPage", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::SKUDAO::loadSkuPage::End");
		return locationList;
	}

	/**
	 * Gets LocationDetails.
	 * @param skubean
	 */
	public SKUBean getLocationDetails(SKUBean skubean) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUDAO::getLocationDetails::Begin");
		DBUtil util = DBUtil.getInstance();
		Connection connection = null;
		CallableStatement callStatement = null;
		ResultSet resultset = null;
		ArrayList skuDetails = new ArrayList();
		SKUBean skuBean = null;
		try
		{
			connection = util.getConnection();
			String call = "CALL ADM_GET_LOCATIONDETAILS(?,?,?,?)";
			callStatement = connection.prepareCall(call);
			callStatement.setInt(1, Integer.parseInt(skubean.getSellingLocation()));
			callStatement.setLong(2, Long.parseLong(skubean.getItemNumber()));
			callStatement.registerOutParameter(3, Types.INTEGER);
			callStatement.registerOutParameter(4, Types.INTEGER);
			callStatement.execute();
			int errorCode = callStatement.getInt(3);
			if (errorCode != 0)
			{
				PaxTraxLog.logError("PaxTrax::SKUDAO::getLocationDetails" + errorCode);
				throw new PaxTraxSystemException(errorCode);
			}
			int output = callStatement.getInt(4);

			if (output == 1)
			{
				resultset = callStatement.getResultSet();
				if (resultset.next())
				{
					skubean.setUnitPrice(resultset.getFloat(1));
					skubean.setNewPrice(resultset.getFloat(2));
					String newPriceEffectiveDate = resultset.getString(3);
					if (newPriceEffectiveDate != null)
					{
						newPriceEffectiveDate = newPriceEffectiveDate.replace('-', '/');
					}
					skubean.setNewPriceEffectiveDate(newPriceEffectiveDate);
					skubean.setPromotionPrice(resultset.getFloat(4));
					String promotionStartDate = resultset.getString(5);
					if (promotionStartDate != null)
					{
						promotionStartDate = promotionStartDate.replace('-', '/');
					}
					String promotionEndDate = resultset.getString(6);
					if (promotionEndDate != null)
					{
						promotionEndDate = promotionEndDate.replace('-', '/');
					}
					skubean.setPromotionStartDate(promotionStartDate);
					skubean.setPromotionEndDate(promotionEndDate);
				}
				skubean.setSkuLocationList(null);
				resultset.close();

				if (callStatement.getMoreResults())
				{
					resultset = callStatement.getResultSet();
					if (resultset.next())
					{
						skubean.setItemDescription(resultset.getString(1));
						skubean.setDepartment(resultset.getString(2));
						skubean.setDutyType(resultset.getString(3));
						skubean.setHarmonizedCode(resultset.getString(4));
						skubean.setCountryOfOrigin(resultset.getString(5));
						skubean.setTaxType(resultset.getString(6));
						skubean.setSize(resultset.getInt(7));
						skubean.setAlcoholStrength(resultset.getInt(8));
						skubean.setGiftWithPurchase(resultset.getString(9));
						resultset.close();
						if (callStatement.getMoreResults())
						{
							resultset = callStatement.getResultSet();
							ArrayList upccodelist = new ArrayList();
							while (resultset.next())
							{
								upccodelist.add(resultset.getString(1));
							}
							int upcCodeLength = upccodelist.size();
							String[] upccode = new String[upcCodeLength];
							for (int i = 0; i < upcCodeLength; i++)
							{
								upccode[i] = (String) upccodelist.get(i);
							}
							skubean.setUpcCodeList(upccode);
							skubean.setDeletedUpc(upccodelist);
							resultset.close();
						}
					}

				}

			}
			else
			{
				resultset = callStatement.getResultSet();
				String newPriceEffectiveDateArray = null;
				String promotionStartDateArray = null;
				String promotionEndDateArray = null;
				while (resultset.next())
				{
					skuBean = new SKUBean();
					skuBean.setUnitPrice(resultset.getFloat(1));
					skuBean.setNewPrice(resultset.getFloat(2));
					newPriceEffectiveDateArray = resultset.getString(3);
					if (newPriceEffectiveDateArray != null)
					{
						newPriceEffectiveDateArray = newPriceEffectiveDateArray.replace('-', '/');
					}
					skuBean.setNewPriceEffectiveDate(newPriceEffectiveDateArray);
					skuBean.setPromotionPrice(resultset.getFloat(4));
					promotionStartDateArray = resultset.getString(5);
					if (promotionStartDateArray != null)
					{
						promotionStartDateArray = promotionStartDateArray.replace('-', '/');
					}
					promotionEndDateArray = resultset.getString(6);
					if (promotionEndDateArray != null)
					{
						promotionEndDateArray = promotionEndDateArray.replace('-', '/');
					}
					skuBean.setPromotionStartDate(promotionStartDateArray);
					skuBean.setPromotionEndDate(promotionEndDateArray);
					skuBean.setSellingLocation(resultset.getString(7));
					skuDetails.add(skuBean);
				}
				skubean.setSkuLocationList(skuDetails);
				resultset.close();

				if (callStatement.getMoreResults())
				{
					resultset = callStatement.getResultSet();
					if (resultset.next())
					{
						skubean.setItemDescription(resultset.getString(1));
						skubean.setDepartment(resultset.getString(2));
						skubean.setDutyType(resultset.getString(3));
						skubean.setHarmonizedCode(resultset.getString(4));
						skubean.setCountryOfOrigin(resultset.getString(5));
						skubean.setTaxType(resultset.getString(6));
						skubean.setSize(resultset.getInt(7));
						skubean.setAlcoholStrength(resultset.getInt(8));
						skubean.setGiftWithPurchase(resultset.getString(9));
						resultset.close();
						if (callStatement.getMoreResults())
						{
							resultset = callStatement.getResultSet();
							ArrayList upccodelist = new ArrayList();
							while (resultset.next())
							{
								upccodelist.add(resultset.getString(1));
							}
							int upcCodeLength = upccodelist.size();
							String[] upccode = new String[upcCodeLength];
							for (int i = 0; i < upcCodeLength; i++)
							{
								upccode[i] = (String) upccodelist.get(i);
							}
							skubean.setUpcCodeList(upccode);
							skubean.setDeletedUpc(upccodelist);
							resultset.close();
						}
					}
				}
				else
				{
					skubean.setItemDescription("");
					skubean.setDepartment("");
					skubean.setDutyType("-1");
					skubean.setUnitPrice(0);
					skubean.setNewPrice(0);
					skubean.setNewPriceEffectiveDate("");
					skubean.setPromotionPrice(0);
					skubean.setPromotionStartDate("");
					skubean.setPromotionEndDate("");
					skubean.setHarmonizedCode("");
					skubean.setCountryOfOrigin("");
					skubean.setTaxType("");
					skubean.setSize(0);
					skubean.setAlcoholStrength(0);
					skubean.setGiftWithPurchase("N");
					skubean.setUpcCodeList(null);
					skubean.setDeletedUpc(null);
					skubean.setSkuLocationList(null);
				}
			}
		}

		catch (SQLException sqlexception)
		{
			PaxTraxLog.logError("PaxTrax::SKUDAO::getLocationDetails", sqlexception);
			throw new PaxTraxSystemException(sqlexception);
		}
		finally
		{
			try
			{
				if (resultset != null)
				{

					resultset.close();
					resultset = null;
				}
				if (callStatement != null)
				{
					callStatement.close();
					callStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::SKUDAO::getLocationDetails", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::SKUDAO::getLocationDetails::End");
		return skubean;
	}

}
