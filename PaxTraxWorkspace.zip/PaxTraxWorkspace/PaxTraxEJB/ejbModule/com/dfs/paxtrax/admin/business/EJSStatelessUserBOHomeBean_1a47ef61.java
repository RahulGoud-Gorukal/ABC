package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessUserBOHomeBean_1a47ef61
 */
public class EJSStatelessUserBOHomeBean_1a47ef61 extends EJSHome {
	/**
	 * EJSStatelessUserBOHomeBean_1a47ef61
	 */
	public EJSStatelessUserBOHomeBean_1a47ef61() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public com.dfs.paxtrax.admin.business.UserBO create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
com.dfs.paxtrax.admin.business.UserBO result = null;
boolean createFailed = false;
try {
	result = (com.dfs.paxtrax.admin.business.UserBO) super.createWrapper(new BeanId(this, null));
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
