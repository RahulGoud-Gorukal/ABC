package com.dfs.paxtrax.admin.business;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.util.ArrayList;

import javax.ejb.SessionBean;

import com.dfs.paxtrax.admin.dao.LocationDAO;
import com.dfs.paxtrax.admin.exception.LocationException;
import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.common.business.PaxTraxSessionWrapper;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
/**
* Bean implementation class for Enterprise Bean: LocationBOBean
*
* @author Cognizant Technology Solutions
* contact Cognizant - Sankaranarayanan srinivasan
* 			DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE 		USER 			COMMENTS
* 12/04/2004	Joseph Oommen A	Created   
*/
public class LocationBOBean
	extends PaxTraxSessionWrapper
	implements SessionBean
{
	ArrayList locationBeanCollection = null;
	LocationDAO locationDAO = null;
	/**
	 * Saves location details by invoking BO method.
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving location details
	 */
	public void saveLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::saveLocationDetails::Begin");
		locationDAO = locationDAO.getInstance();
		locationDAO.insertLocationDetails(locationBean);
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::saveLocationDetails::End");
	}
	/**
	 * Removes location details by invoking BO method.
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in removing location details
	 */
	public void removeLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::removeLocationDetails::Begin");
		locationDAO = locationDAO.getInstance();
		locationDAO.deleteLocationDetails(locationBean);
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::removeLocationDetails::End");
	}
	/**
	 * Updates location details by invoking BO method.
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in updating location details
	 */
	public void updateLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::updateLocationDetails::Begin");
		locationDAO = locationDAO.getInstance();
		locationDAO.updateLocationDetails(locationBean);
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::updateLocationDetails::End");
	}
	/**
	 * Returns location list for the given search criteria by invoking BO method.
	 * @param locationBean LocationBean object
	 * @return ArrayList List of location details
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in updating location details
	 */
	public ArrayList searchLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::searchLocationDetails::Begin");
		locationDAO = locationDAO.getInstance();
		locationBeanCollection =
			locationDAO.selectLocationDetails(locationBean);
		PaxTraxLog.logDebug(
			"PaxTrax::LocationBOBean::searchLocationDetails::End");
		return locationBeanCollection;
	}
	/**
	 * Returns location Bean for the given search criteria by invoking BO method.
	 * @param location int
	 * @return locationBean LocationBean Object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in search
	 */
	public LocationBean loadLocationDetails(String location)
		throws PaxTraxSystemException, LocationException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::loadLocationDetails::Begin");
		LocationBean locationBean = null;
		locationDAO = locationDAO.getInstance();
		locationBean = locationDAO.loadLocationDetails(location);
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::loadLocationDetails::End");
		return locationBean;
	}

	/**
	 * Method getAvailableLocations.
	 * @return String[]
	 */
	public String[] getAvailableLocations() throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::getAvailableLocations::Begin");
		locationDAO = locationDAO.getInstance();
		String[] locationList = locationDAO.getAvailableLocations();
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::getAvailableLocations::End");
        return locationList;
	}

	/**
	 * Method saveLogicalLocation.
	 * @param locationBean
	 */
	public void saveLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException,LocationException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::saveLogicalLocation::Begin");
		locationDAO = locationDAO.getInstance();
		locationDAO.saveLogicalLocation(locationBean);
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::saveLogicalLocation::End");
	}

	/**
	 * Method getLogicalLocation.
	 * @param locationBean
	 * @return LocationBean
	 */
	public LocationBean getLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException,LocationException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::getLogicalLocation::Begin");
		locationDAO = locationDAO.getInstance();
		locationBean = locationDAO.getLogicalLocation(locationBean);
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::getLogicalLocation::End");
        return locationBean;
	}

	/**
	 * Method searchLogicalLocationDetails.
	 * @return ArrayList
	 */
	public ArrayList searchLogicalLocationDetails() throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::searchLogicalLocationDetails::Begin");
		locationDAO = locationDAO.getInstance();
		ArrayList locationList = locationDAO.searchLogicalLocationDetails();
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::searchLogicalLocationDetails::End");
        return locationList;
	}

	/**
	 * Method updateLogicalLocation.
	 * @param locationBean
	 */
	public void updateLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::updateLogicalLocation::Begin");
		locationDAO = locationDAO.getInstance();
		locationDAO.updateLogicalLocation(locationBean);
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::updateLogicalLocation::End");
	}

	/**
	 * Method removeLogicalLocationDetails.
	 * @param locationBean
	 */
	public void removeLogicalLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException
	{
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::removeLogicalLocationDetails::Begin");
		locationDAO = locationDAO.getInstance();
		locationDAO.removeLogicalLocationDetails(locationBean);
        PaxTraxLog.logDebug(
            "PaxTrax::LocationBOBean::removeLogicalLocationDetails::End");
	}

}
