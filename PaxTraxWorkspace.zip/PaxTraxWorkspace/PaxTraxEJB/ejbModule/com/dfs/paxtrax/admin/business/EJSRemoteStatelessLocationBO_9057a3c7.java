package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessLocationBO_9057a3c7
 */
public class EJSRemoteStatelessLocationBO_9057a3c7 extends EJSWrapper implements LocationBO {
	/**
	 * EJSRemoteStatelessLocationBO_9057a3c7
	 */
	public EJSRemoteStatelessLocationBO_9057a3c7() throws java.rmi.RemoteException {
		super();	}
	/**
	 * getLogicalLocation
	 */
	public com.dfs.paxtrax.admin.valueobject.LocationBean getLogicalLocation(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.LocationException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		com.dfs.paxtrax.admin.valueobject.LocationBean _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 0, _EJS_s);
			_EJS_result = _EJS_beanRef.getLogicalLocation(locationBean);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.LocationException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * loadLocationDetails
	 */
	public com.dfs.paxtrax.admin.valueobject.LocationBean loadLocationDetails(java.lang.String location) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.LocationException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		com.dfs.paxtrax.admin.valueobject.LocationBean _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 1, _EJS_s);
			_EJS_result = _EJS_beanRef.loadLocationDetails(location);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.LocationException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 1, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * getAvailableLocations
	 */
	public java.lang.String[] getAvailableLocations() throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.lang.String[] _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 2, _EJS_s);
			_EJS_result = _EJS_beanRef.getAvailableLocations();
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 2, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * searchLocationDetails
	 */
	public java.util.ArrayList searchLocationDetails(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 3, _EJS_s);
			_EJS_result = _EJS_beanRef.searchLocationDetails(locationBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 3, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * searchLogicalLocationDetails
	 */
	public java.util.ArrayList searchLogicalLocationDetails() throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 4, _EJS_s);
			_EJS_result = _EJS_beanRef.searchLogicalLocationDetails();
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 4, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * removeLocationDetails
	 */
	public void removeLocationDetails(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.LocationException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 5, _EJS_s);
			_EJS_beanRef.removeLocationDetails(locationBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.LocationException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 5, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * removeLogicalLocationDetails
	 */
	public void removeLogicalLocationDetails(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 6, _EJS_s);
			_EJS_beanRef.removeLogicalLocationDetails(locationBean);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 6, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * saveLocationDetails
	 */
	public void saveLocationDetails(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.LocationException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 7, _EJS_s);
			_EJS_beanRef.saveLocationDetails(locationBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.LocationException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 7, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * saveLogicalLocation
	 */
	public void saveLogicalLocation(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.LocationException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 8, _EJS_s);
			_EJS_beanRef.saveLogicalLocation(locationBean);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.LocationException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 8, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * updateLocationDetails
	 */
	public void updateLocationDetails(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.LocationException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 9, _EJS_s);
			_EJS_beanRef.updateLocationDetails(locationBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.LocationException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 9, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * updateLogicalLocation
	 */
	public void updateLogicalLocation(com.dfs.paxtrax.admin.valueobject.LocationBean locationBean) throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.LocationBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.LocationBOBean)container.preInvoke(this, 10, _EJS_s);
			_EJS_beanRef.updateLogicalLocation(locationBean);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 10, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
}
