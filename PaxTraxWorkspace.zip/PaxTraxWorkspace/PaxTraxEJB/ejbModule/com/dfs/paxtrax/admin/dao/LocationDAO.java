package com.dfs.paxtrax.admin.dao;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.exception.LocationException;
import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This is the DAO class which performs database
 * operations for Location
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 *
 * @version    1.0
 *
 * MOD HISTORY
 *  DATE 			USER 			COMMENTS
 * 22/03/2004	Joseph Oommen A	    Created
*/
public class LocationDAO
{
	//ArrayList locationBeans
	private ArrayList locationBeans = null;
	//LocationDAO locationDAO
	private static LocationDAO locationDAO = null;
	//DBUtil dBUtil
	private DBUtil dBUtil = null;
	/**
	* Creates an instance of LocationDAO only if the instance does not
	* exist.
	*
	* @return LocationDAO Returns the LocationDAO instance
	*/
	public static LocationDAO getInstance()
	{

		PaxTraxLog.logDebug("PaxTrax::LocationDAO::getInstance::Begin");
		if (locationDAO == null)
		{
			initializeInstance();
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::getInstance::End");
		return locationDAO;
	}
	/**
	 * Sets the LocationDAO class instance
	 */
	private static synchronized void initializeInstance()
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::initializeInstance::Begin");
		if (locationDAO == null)
		{
			locationDAO = new LocationDAO();
		}

		PaxTraxLog.logDebug("PaxTrax::LocationDAO::initializeInstance::End");
	}
	/**
	 * Default Construtor for LocationDAO
	 */
	LocationDAO()
	{
	}
	/**
	 * Inserts selling location details into the database.
	 * @param SellingLocationBean - sellingLocationBean
	 * @throws PaxTraxException This exception is thrown
	 * if there is any problem in insert
	*/
	public void insertLocationDetails(LocationBean locationBean) throws PaxTraxSystemException, LocationException
	{

		PaxTraxLog.logDebug("PaxTrax::LocationDAO::insertLocationDetails::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();

		String location = locationBean.getLocation();
		location = location.trim();

		String description = locationBean.getDescription();
		if (description != null)
			description = description.trim();

		String hrCutOffTime = locationBean.getHrCutOffTime();
		if (hrCutOffTime != null)
			hrCutOffTime = hrCutOffTime.trim();
		else
			hrCutOffTime = "00";

		String minCutOffTime = locationBean.getMinCutOffTime();
		if (minCutOffTime != null)
			minCutOffTime = minCutOffTime.trim();
		else
			minCutOffTime = "00";

		String cutOffTime = hrCutOffTime + ":" + minCutOffTime + ":00";
		if ("00:00:00".equals(cutOffTime))
			cutOffTime = null;
		String isSpendLimitTrackingRequired = locationBean.getIsSpendLimitTrackingRequired();
		if (isSpendLimitTrackingRequired != null)
			isSpendLimitTrackingRequired = isSpendLimitTrackingRequired.trim();

		String locationTypeCodeId = locationBean.getLocationType();
		if (locationTypeCodeId != null)
			locationTypeCodeId = locationTypeCodeId.trim();

		String locationTypeReferenceId = locationBean.getLocationTypeReferenceId();
		if (locationTypeReferenceId != null)
			locationTypeReferenceId = locationTypeReferenceId.trim();

		int dutyFreeSpendingLimit = locationBean.getDutyFreeSpendingLimit();

		String isBagTrackingRequired = locationBean.getIsBagTrackingRequired();
		if (isBagTrackingRequired != null)
			isBagTrackingRequired = isBagTrackingRequired.trim();

		String isAutoPaXRequired = locationBean.getIsAutoPAXRequired();
		if (isAutoPaXRequired != null)
			isAutoPaXRequired = isAutoPaXRequired.trim();

		String bondedWareHouse = locationBean.getBondedWarehouseCode();
		if (bondedWareHouse != null)
			bondedWareHouse = bondedWareHouse.trim();

		/*	String isOverrideRefundRequired =
				locationBean.getIsOverideRefundRequired();
			if (isOverrideRefundRequired != null)
				isOverrideRefundRequired = isOverrideRefundRequired.trim();
			*/
		String user = locationBean.getUser();
		if (user != null)
			user = user.trim();

		String insertLocationProcedure = " {call ADM_LOCATION_SAVE(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		CallableStatement callableStatement = null;
		try
		{
			callableStatement = connection.prepareCall(insertLocationProcedure);
			callableStatement.setInt(1, Integer.parseInt(location));
			callableStatement.setString(2, description);
			callableStatement.setString(3, locationTypeReferenceId);
			callableStatement.setString(4, locationTypeCodeId);
			callableStatement.setString(5, cutOffTime);
			callableStatement.setString(6, isSpendLimitTrackingRequired);
			if (dutyFreeSpendingLimit == 0)
				callableStatement.setNull(7, Types.INTEGER);
			else
				callableStatement.setInt(7, dutyFreeSpendingLimit);
			callableStatement.setString(8, isBagTrackingRequired);
			/*callableStatement.setString(9, isOverrideRefundRequired);*/
			callableStatement.setString(9, PaxTraxConstants.LOCATION_DELETED_FALSE);
			callableStatement.setString(10, user);
			callableStatement.setString(11, isAutoPaXRequired);
			callableStatement.setString(12, bondedWareHouse);
			callableStatement.registerOutParameter(13, Types.INTEGER);
			callableStatement.registerOutParameter(14, Types.INTEGER);
			callableStatement.execute();

			int result = callableStatement.getInt(13);

			// PaxTraxLog.logDebug("result " + result);
			if (result == 1)
			{
				throw new LocationException(PaxTraxConstants.LOCATION_ALREADY_EXISTS);
			}
			int errorCode = callableStatement.getInt(14);
			if (errorCode != 0)
			{
				throw new PaxTraxSystemException(PaxTraxConstants.SYSTEM_EXCEPTION);
			}
		}
		catch (SQLException sqlException)
		{
			sqlException.printStackTrace();

			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::insertLocationDetails::End");

	}
	/**
	 * Deletes selling location details in database.
	 * @param SellingLocationBean - sellingLocationBean
	 * @throws PaxTraxException This exception is thrown
	 * if there is any problem in delete
	 */
	public void deleteLocationDetails(LocationBean locationBean) throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::deleteLocationDetails::Begin");

		/*String deleteLocationQuery =
			"update TB_LOCATION set LOCATION_DELETED =? where LOCATION_ID =? ";*/
		String location = locationBean.getLocation();
		location = location.trim();

		String user = locationBean.getUser();
		if (user != null)
			user = user.trim();

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		CallableStatement callableStatement = null;
		String deleteLocationProcedure = "{call ADM_LOCATION_DELETE(?,?,?,?,?)}";
		try
		{
			callableStatement = connection.prepareCall(deleteLocationProcedure);
			callableStatement.setInt(1, Integer.parseInt(location));
			callableStatement.setString(2, PaxTraxConstants.LOCATION_DELETED_TRUE);

			callableStatement.setString(3, user);

			callableStatement.registerOutParameter(4, Types.INTEGER);
			callableStatement.registerOutParameter(5, Types.INTEGER);

			callableStatement.execute();

			int result = callableStatement.getInt(4);

			if (result == 1)
				throw new LocationException(PaxTraxConstants.LOCATION_DEPENDENCY_EXISTS);
			int errorCode = callableStatement.getInt(5);

			if (errorCode != 0)
			{
				throw new PaxTraxSystemException(PaxTraxConstants.SYSTEM_EXCEPTION);
			}
		}
		catch (SQLException sqlException)
		{
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{

			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PaxTraxSystemException(sqlException);
			}
		}
		/*PreparedStatement preparedStatement = null;
		try
		{
			preparedStatement =
				connection.prepareStatement(deleteLocationQuery);
			preparedStatement.setString(
				1,
				PaxTraxConstants.LOCATION_DELETED_TRUE);
			preparedStatement.setInt(2, Integer.parseInt(location));
			preparedStatement.executeUpdate();
		
		}
		catch (SQLException sqlException)
		{
			sqlException.printStackTrace();
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PaxTraxSystemException(sqlException);
			}
		}*/
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::deleteLocationDetails::End");
	}
	/**
	 * updates selling location details in database.
	 * @param SellingLocationBean - sellingLocationBean
	 * @throws PaxTraxException This exception is thrown if there is any problem in update
	 */
	public void updateLocationDetails(LocationBean locationBean) throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::updateLocationDetails::Begin");
		String updateLocationQuery =
			"update TB_LOCATION set LOCATION_DESC=?,LOCATION_TYPE_REF_ID=?,"
				+ "LOCATION_TYPE_CODE_CODE_ID =?,LOCATION_CUT_OFF_TIME=?,"
				+ "LOCATION_SPND_LIMIT_TR=?,LOCATION_DUTY_FREE_AMT=?,"
				+ "LOCATION_BAGTRACK_REQ=? ,LOCATION_DELETED=?,"
				+ "MODIFIED_BY = ?,MODIFIED_DATE=CURRENT DATE , LOC_AUTO_PAX_REQ = ?,LOC_BONDED_WH_CODE = ? where LOCATION_ID= ?";
		/*String updateLocationQuery =
			"update TB_LOCATION set LOCATION_DESC=?,LOCATION_TYPE_REF_ID=?,LOCATION_TYPE_CODE_CODE_ID = ?,LOCATION_SPND_LIMIT_TR=?,LOCATION_DUTY_FREE_AMT=?,LOCATION_BAGTRACK_REQ=?,LOCATION_OVER_REF=?,LOCATION_DELETED=?,LOCATION_CUT_OFF_TIME=? where LOCATION_ID= ?";*/
		String location = locationBean.getLocation();
		location = location.trim();

		String description = locationBean.getDescription();
		if (description != null)
			description = description.trim();

		String hrCutOffTime = locationBean.getHrCutOffTime();
		if (hrCutOffTime != null)
			hrCutOffTime = hrCutOffTime.trim();
		else
			hrCutOffTime = "00";

		String minCutOffTime = locationBean.getMinCutOffTime();
		if (minCutOffTime != null)
			minCutOffTime = minCutOffTime.trim();
		else
			minCutOffTime = "00";

		String cutOffTime = hrCutOffTime + ":" + minCutOffTime + ":00";
		if ("00:00:00".equals(cutOffTime))
			cutOffTime = null;

		String isSpendLimitTrackingRequired = locationBean.getIsSpendLimitTrackingRequired();
		if (isSpendLimitTrackingRequired != null)
			isSpendLimitTrackingRequired = isSpendLimitTrackingRequired.trim();

		String locationTypeCodeId = locationBean.getLocationType();
		if (locationTypeCodeId != null)
			locationTypeCodeId = locationTypeCodeId.trim();

		String locationTypeReferenceId = locationBean.getLocationTypeReferenceId();
		if (locationTypeReferenceId != null)
			locationTypeReferenceId = locationTypeReferenceId.trim();

		int dutyFreeSpendingLimit = locationBean.getDutyFreeSpendingLimit();

		String isBagTrackingRequired = locationBean.getIsBagTrackingRequired();
		if (isBagTrackingRequired != null)
			isBagTrackingRequired = isBagTrackingRequired.trim();

		String isAutoPaXRequired = locationBean.getIsAutoPAXRequired();
		if (isAutoPaXRequired != null)
			isAutoPaXRequired = isAutoPaXRequired.trim();

		String bondedWareHouse = locationBean.getBondedWarehouseCode();
		if (bondedWareHouse != null)
			bondedWareHouse = bondedWareHouse.trim();

		/*String isOverrideRefundRequired =
			locationBean.getIsOverideRefundRequired();
		if (isOverrideRefundRequired != null)
			isOverrideRefundRequired = isOverrideRefundRequired.trim();
		*/
		String user = locationBean.getUser();
		if (user != null)
			user = user.trim();

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try
		{
			dBUtil = DBUtil.getInstance();
			connection = dBUtil.getConnection();
			preparedStatement = connection.prepareStatement(updateLocationQuery);
			preparedStatement.setString(1, description);
			preparedStatement.setString(2, locationTypeReferenceId);
			preparedStatement.setString(3, locationTypeCodeId);

			preparedStatement.setString(4, cutOffTime);
			preparedStatement.setString(5, isSpendLimitTrackingRequired);
			if (dutyFreeSpendingLimit == 0)
				preparedStatement.setNull(6, Types.INTEGER);
			else
				preparedStatement.setInt(6, dutyFreeSpendingLimit);

			preparedStatement.setString(7, isBagTrackingRequired);
			/*preparedStatement.setString(8, isOverrideRefundRequired);*/
			preparedStatement.setString(8, PaxTraxConstants.LOCATION_DELETED_FALSE);
			preparedStatement.setString(9, user);
			preparedStatement.setString(10, isAutoPaXRequired);
			preparedStatement.setString(11, bondedWareHouse);

			preparedStatement.setInt(12, Integer.parseInt(location));

			preparedStatement.executeUpdate();

		}
		catch (SQLException sqlException)
		{
			sqlException.printStackTrace();
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::updateLocationDetails::End");
	}
	/**
	 * Returns list of selling location beans for the given search criteria.
	 * @param ArrayList - sellingLocationBean
	 * @return ArrayList
	 * @throws PaxTraxException This exception is thrown if
	 * there is any problem in search
	 */
	public ArrayList selectLocationDetails(LocationBean locationBean) throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::LocationDAO::selectLocationDetails::Begin");
		String searchLocationQuery =
			"select DISTINCT l.LOCATION_ID,l.LOCATION_DESC,l.LOCATION_TYPE_REF_ID,"
				+ "l.LOCATION_TYPE_CODE_CODE_ID,HOUR(l.LOCATION_CUT_OFF_TIME),"
				+ "MINUTE(l.LOCATION_CUT_OFF_TIME),l.LOCATION_SPND_LIMIT_TR,"
				+ "l.LOCATION_DUTY_FREE_AMT,l.LOCATION_BAGTRACK_REQ,"
				+ "c.CODE_TO_FLAG,l.LOC_AUTO_PAX_REQ, l.LOC_BONDED_WH_CODE from TB_LOCATION l,"
				+ "TB_CODE_REF c  where l.LOCATION_TYPE_REF_ID ="
				+ "c.REF_ID and l.LOCATION_TYPE_CODE_CODE_ID ="
				+ "c.CODE_CODE_ID and";
		ArrayList locationBeanCollection = new ArrayList();
		StringBuffer searchQuery = new StringBuffer(searchLocationQuery);
		searchQuery.append(" ");
		searchQuery.append("l.LOCATION_DELETED = '");
		searchQuery.append(PaxTraxConstants.LOCATION_DELETED_FALSE);
		searchQuery.append("'");
		searchQuery.append(" ");
		String location = locationBean.getLocation();

		if (location != null)
		{

			location = location.trim();
			if (location.length() > 0)
			{
				int loc = Integer.parseInt(location);

				searchQuery.append("and l.LOCATION_ID  = ");
				searchQuery.append(location);
				//searchQuery.append("%'");
				searchQuery.append(" ");
			}

		}
		String locationRefId = locationBean.getLocationTypeReferenceId();

		if (locationRefId != null)
		{
			locationRefId = locationRefId.trim();
			searchQuery.append("and l.LOCATION_TYPE_REF_ID = '");
			searchQuery.append(locationRefId);
			searchQuery.append("'");
			searchQuery.append(" ");
		}
		String locationCodeId = locationBean.getLocationType();
		if (locationCodeId != null)
		{
			locationCodeId = locationCodeId.trim();
			searchQuery.append("and l.LOCATION_TYPE_CODE_CODE_ID = '");
			searchQuery.append(locationCodeId);
			searchQuery.append("'");
			searchQuery.append(" ");
		}
		String hrCutOffTime = locationBean.getHrCutOffTime();

		if (hrCutOffTime != null && !("00".equals(hrCutOffTime)))
		{
			hrCutOffTime = hrCutOffTime.trim();
			int hour = Integer.parseInt(hrCutOffTime);
			searchQuery.append("and HOUR(l.LOCATION_CUT_OFF_TIME) = ");
			searchQuery.append(hour);
			searchQuery.append(" ");
		}
		String minCutOffTime = locationBean.getMinCutOffTime();

		if (minCutOffTime != null && !("00".equals(minCutOffTime)))
		{
			minCutOffTime = minCutOffTime.trim();
			int minute = Integer.parseInt(minCutOffTime);
			searchQuery.append("and MINUTE(l.LOCATION_CUT_OFF_TIME) = ");
			searchQuery.append(minute);
			searchQuery.append(" ");
		}

		/*int dutyFreeSpendingLimit = locationBean.getDutyFreeSpendingLimit();
		
		if (dutyFreeSpendingLimit > 0)
		{
			searchQuery.append(
				"and CHAR(INTEGER(LOCATION_DUTY_FREE_AMT))like'");
			searchQuery.append(dutyFreeSpendingLimit);
			searchQuery.append("%'");
		}*/
		searchQuery.append("order by l.LOCATION_ID");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			preparedStatement = connection.prepareStatement(searchQuery.toString());
			resultSet = preparedStatement.executeQuery();
			if (resultSet != null)
			{
				LocationBean resultBean = null;

				while (resultSet.next())
				{
					resultBean = new LocationBean();
					resultBean.setLocation(resultSet.getInt(1)+"");
					resultBean.setDescription(resultSet.getString(2));
					resultBean.setLocationTypeReferenceId(resultSet.getString(3));
					resultBean.setLocationType(resultSet.getString(4));

					StringBuffer hrTime = new StringBuffer();

					String hours = resultSet.getString(5);
					if (hours != null)
					{
						int hour = Integer.parseInt(hours);
						if (hour < 10)
							hrTime.append(0);
						hrTime.append(hour);
						resultBean.setHrCutOffTime(hrTime.toString());
					}

					StringBuffer minTime = new StringBuffer();

					String minutes = resultSet.getString(6);
					if (minutes != null)
					{
						int minute = Integer.parseInt(minutes);

						if (minute < 10)
							minTime.append(0);
						minTime.append(minute);
						resultBean.setMinCutOffTime(minTime.toString());
					}

					/*  int hour = resultSet.getInt(5);
					
						if (hour < 10)
							hrTime.append(0);
						hrTime.append(hour);
						StringBuffer minTime = new StringBuffer();
						int minute = resultSet.getInt(6);
					
						if (minute < 10)
							minTime.append(0);
						minTime.append(minute);
					
					resultBean.setHrCutOffTime(hrTime.toString());
					resultBean.setMinCutOffTime(minTime.toString());*/
					resultBean.setIsSpendLimitTrackingRequired(resultSet.getString(7));

					String dutyFreeLimit = resultSet.getString(8);

					if (dutyFreeLimit != null)
					{
						dutyFreeLimit = dutyFreeLimit.trim();
						resultBean.setDutyFreeSpendingLimit((new Double(dutyFreeLimit)).intValue());
					}

					resultBean.setIsBagTrackingRequired(resultSet.getString(9));

					resultBean.setLocationTypeFlag(resultSet.getString(10));
					resultBean.setIsAutoPAXRequired(resultSet.getString(11));
					resultBean.setBondedWarehouseCode(resultSet.getString(12));
					locationBeanCollection.add(resultBean);
				}
			}

		}
		catch (SQLException sqlException)
		{
			sqlException.printStackTrace();
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::selectLocationDetails::End");
		return locationBeanCollection;
	}
	/**
	 * Returns location Bean for the given search criteria by invoking BO method.
	 * @param location int
	 * @return locationBean LocationBean Object
	 * @throws PaxTraxSystemException This exception is thrown if there is
	 * any problem in search
	 */
	public LocationBean loadLocationDetails(String location) throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::loadLocationDetails::Begin");

		LocationBean locationBean = new LocationBean();
		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		boolean locationNotFound = true;
		String loadLocationProcedure = " {call ADM_LOCATION_LOAD(?,?)}";
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
		try
		{
			callableStatement = connection.prepareCall(loadLocationProcedure);
			callableStatement.setInt(1, Integer.parseInt(location));
			callableStatement.setString(2, PaxTraxConstants.LOCATION_DELETED_FALSE);
			resultSet = callableStatement.executeQuery();
			if (resultSet != null)
			{
				while (resultSet.next())
				{
					locationNotFound = false;
					locationBean.setDescription(resultSet.getString(1));
					locationBean.setLocationTypeReferenceId(resultSet.getString(2));
					locationBean.setLocationType(resultSet.getString(3));
					/*StringBuffer hrCuttOffTime = new StringBuffer();
					int hour = resultSet.getInt(4);
					if (hour < 10)
						hrCuttOffTime.append(0);
					hrCuttOffTime.append(hour);
					StringBuffer minCuttOffTime = new StringBuffer();
					int minute = resultSet.getInt(5);
					if (minute < 10)
						minCuttOffTime.append(0);
					minCuttOffTime.append(minute);
					
					locationBean.setHrCutOffTime(hrCuttOffTime.toString());
					locationBean.setMinCutOffTime(minCuttOffTime.toString());*/

					StringBuffer hrTime = new StringBuffer();

					String hours = resultSet.getString(4);
					if (hours != null)
					{
						int hour = Integer.parseInt(hours);
						if (hour < 10)
							hrTime.append(0);
						hrTime.append(hour);
						locationBean.setHrCutOffTime(hrTime.toString());
					}

					StringBuffer minTime = new StringBuffer();

					String minutes = resultSet.getString(5);
					if (minutes != null)
					{
						int minute = Integer.parseInt(minutes);

						if (minute < 10)
							minTime.append(0);
						minTime.append(minute);
						locationBean.setMinCutOffTime(minTime.toString());
					}
					locationBean.setIsSpendLimitTrackingRequired(resultSet.getString(6));

					String dutyFreeLimit = resultSet.getString(7);

					if (dutyFreeLimit != null)
					{
						dutyFreeLimit = dutyFreeLimit.trim();
						locationBean.setDutyFreeSpendingLimit((new Double(dutyFreeLimit)).intValue());
					}

					locationBean.setIsBagTrackingRequired(resultSet.getString(8));

					locationBean.setLocationTypeFlag(resultSet.getString(9));
					locationBean.setIsAutoPAXRequired(resultSet.getString(10));
					locationBean.setBondedWarehouseCode(resultSet.getString(11));
				}
			}
			if (locationNotFound)
			{

				throw new LocationException(PaxTraxConstants.NO_RECORDS_FOUND);

			}
		}
		catch (SQLException sqlException)
		{

			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::loadLocationDetails::End");
		return locationBean;
	}

	public String[] getAvailableLocations() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::getAvailableLocations::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		Statement statement = null;
		ArrayList locationList = new ArrayList();
		ResultSet resultSet = null;
		String[] location = null;
		try
		{
			statement = connection.createStatement();
			resultSet = statement.executeQuery("SELECT LOCATION_ID FROM TB_LOCATION " + "WHERE LOCATION_DELETED = 'N' ORDER BY LOCATION_ID");
			while (resultSet.next())
			{
				locationList.add(resultSet.getString(1));
			}
			resultSet.close();
			int size = 0;
			if (locationList != null)
				size = locationList.size();
			location = new String[size];
			for (int i = 0; i < size; i++)
			{
				location[i] = (String) locationList.get(i);
			}
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::LocationDAO::getAvailableLocations::" + "sql exception", sqlException);
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::LocationDAO::getAvailableLocations::" + "sql exception", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::getAvailableLocations::End");
		return location;
	}
	/**
	 * Method saveLogicalLocation.
	 * @param locationBean
	 */
	public void saveLogicalLocation(LocationBean locationBean) throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::saveLogicalLocation::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		CallableStatement callStatement = null;
		PreparedStatement preparedStatement = null;
		try
		{
			callStatement = connection.prepareCall("{call ADM_LOGICALLOCATION_SAVE(?,?)}");
			String location = locationBean.getLocation();
			if (location != null)
				callStatement.setInt(1, Integer.parseInt(location));
			callStatement.registerOutParameter(2, Types.INTEGER);
			callStatement.execute();
			int errorCode = callStatement.getInt(2);
			switch (errorCode)
			{
				case 0 :
					break;
				case 1 :
					PaxTraxLog.logError("Location already exists" + PaxTraxConstants.LOCATION_ALREADY_EXISTS);
					throw new LocationException(PaxTraxConstants.LOCATION_ALREADY_EXISTS);
				default :
					PaxTraxLog.logError("Error in saveLogicalLocation" + errorCode);
					throw new PaxTraxSystemException(errorCode);
			}
			callStatement.close();

			preparedStatement = connection.prepareStatement(SQLConstants.INSERT_LOG_LOC);
			String[] locationList = locationBean.getAddedLocations();
			if (locationList != null)
			{
				for (int i = 0; i < locationList.length; i++)
				{
					if (location != null)
						preparedStatement.setInt(1, Integer.parseInt(location));
					preparedStatement.setInt(2, Integer.parseInt(locationList[i]));
					preparedStatement.setString(3, locationBean.getDescription());
					preparedStatement.execute();
					preparedStatement.clearParameters();
				}
			}
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::LocationDAO::saveLogicalLocation::" + "sql exception", sqlException);
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (callStatement != null)
				{
					callStatement.close();
					callStatement = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::LocationDAO::saveLogicalLocation::" + "sql exception", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::saveLogicalLocation::End");
	}

	/**
	 * Method getLogicalLocation.
	 * @param locationBean
	 * @return LocationBean
	 */
	public LocationBean getLogicalLocation(LocationBean locationBean) throws PaxTraxSystemException, LocationException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::getLogicalLocation::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		try
		{
			StringBuffer sql = new StringBuffer();
			sql.append(SQLConstants.GET_LOGICAL_LOCATION);

			if (locationBean.getLocation() != null && !SQLConstants.BLANK.equals(locationBean.getLocation()))
			{
				sql.append(" AND LOGICAL_LOCATION_ID = " + locationBean.getLocation());
			}

			sql.append(" ORDER BY LOGICAL_LOCATION_ID");

			PaxTraxLog.logDebug("Query " + sql);
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			ArrayList addLocation = new ArrayList();
			while (resultSet.next())
			{
				locationBean.setLocation(resultSet.getString(1));
				addLocation.add(resultSet.getString(2));
				locationBean.setDescription(resultSet.getString(3));
			}
			resultSet.close();

			String[] addedLocations = new String[addLocation.size()];
			if (addLocation != null)
			{
				if (addLocation.size() == 0)
				{
					PaxTraxLog.logError("Location Not Found " + PaxTraxConstants.LOCATION_NOT_FOUND);
					throw new LocationException(PaxTraxConstants.LOCATION_NOT_FOUND);
				}
				else
				{
					int addLocationSize = addLocation.size();
					for (int i = 0; i < addLocationSize; i++)
					{
						addedLocations[i] = (String) addLocation.get(i);
					}
				}
			}
			locationBean.setAddedLocations(addedLocations);
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::LocationDAO::getLogicalLocation::" + "sql exception", sqlException);
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::LocationDAO::getLogicalLocation::" + "sql exception", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::getLogicalLocation::End");
		return locationBean;
	}

	/**
	 * Method searchLogicalLocationDetails.
	 * @return ArrayList
	 */
	public ArrayList searchLogicalLocationDetails() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::searchLogicalLocationDetails::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		Statement statement = null;
		ResultSet resultSet = null;
		ArrayList locationList = new ArrayList();
		LocationBean locationBean = null;
		try
		{
			String prevLocation = null;
			String location = null;
			StringBuffer sql = new StringBuffer();
			sql.append(SQLConstants.GET_LOGICAL_LOCATION);

			sql.append(" ORDER BY LOGICAL_LOCATION_ID");

			PaxTraxLog.logDebug("Query " + sql);
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			ArrayList addLocation = new ArrayList();
			String[] addedLocations = null;
			while (resultSet.next())
			{
				location = resultSet.getString(1);

				if (prevLocation != null && !location.equals(prevLocation))
				{
					addedLocations = new String[addLocation.size()];
					for (int i = 0; i < addLocation.size(); i++)
					{
						addedLocations[i] = (String) addLocation.get(i);
					}
					locationBean.setAddedLocations(addedLocations);
					addLocation = null;
					addLocation = new ArrayList();
					locationList.add(locationBean);
				}
				if (!location.equals(prevLocation))
				{
					locationBean = new LocationBean();
					locationBean.setLocation(location);
					locationBean.setDescription(resultSet.getString(3));
				}
				addLocation.add(resultSet.getString(2));
				prevLocation = location;
			}
			if (prevLocation != null)
			{
				addedLocations = new String[addLocation.size()];
				for (int i = 0; i < addLocation.size(); i++)
				{
					addedLocations[i] = (String) addLocation.get(i);
				}
				locationBean.setAddedLocations(addedLocations);
				locationList.add(locationBean);
			}
			resultSet.close();
			statement.close();
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::LocationDAO::searchLogicalLocationDetails::" + "sql exception", sqlException);
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::LocationDAO::searchLogicalLocationDetails::" + "sql exception", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::searchLogicalLocationDetails::End");
		return locationList;
	}

	/**
	 * Method updateLogicalLocation.
	 * @param locationBean
	 */
	public void updateLogicalLocation(LocationBean locationBean) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::updateLogicalLocation::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try
		{
			String location = locationBean.getLocation();
			preparedStatement = connection.prepareStatement(SQLConstants.DELETE_LOG_LOC);
			preparedStatement.setString(1, location);
			preparedStatement.execute();
			preparedStatement.close();
			preparedStatement = null;

			preparedStatement = connection.prepareStatement(SQLConstants.INSERT_LOG_LOC);
			String[] locationList = locationBean.getAddedLocations();
			if (locationList != null)
			{
				for (int i = 0; i < locationList.length; i++)
				{
					if (location != null)
						preparedStatement.setInt(1, Integer.parseInt(location));
					preparedStatement.setInt(2, Integer.parseInt(locationList[i]));
					preparedStatement.setString(3, locationBean.getDescription());
					preparedStatement.execute();
					preparedStatement.clearParameters();
				}
			}
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::LocationDAO::updateLogicalLocation::" + "sql exception", sqlException);
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}

			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::LocationDAO::updateLogicalLocation::" + "sql exception", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::updateLogicalLocation::End");
	}

	/**
	 * Method removeLogicalLocationDetails.
	 * @param locationBean
	 */
	public void removeLogicalLocationDetails(LocationBean locationBean) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::removeLogicalLocationDetails::Begin");

		dBUtil = DBUtil.getInstance();
		Connection connection = dBUtil.getConnection();
		PreparedStatement preparedStatement = null;
		try
		{
			String location = locationBean.getLocation();
			preparedStatement = connection.prepareStatement(SQLConstants.DELETE_LOG_LOC);
			preparedStatement.setString(1, location);
			preparedStatement.execute();
			preparedStatement.close();
			preparedStatement = null;
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::LocationDAO::removeLogicalLocationDetails::" + "sql exception", sqlException);
			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("PaxTrax::LocationDAO::removeLogicalLocationDetails::" + "sql exception", sqlException);
				throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::LocationDAO::removeLogicalLocationDetails::End");
	}

}