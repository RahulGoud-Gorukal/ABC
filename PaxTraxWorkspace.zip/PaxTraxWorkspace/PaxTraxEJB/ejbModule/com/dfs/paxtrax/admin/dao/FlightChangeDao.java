package com.dfs.paxtrax.admin.dao;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

 
/**
 * Class changes flight details for mass flight change
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 14/12/2004	P.C.Sathish		Created   
 */	
public class FlightChangeDao {
	public static FlightChangeDao massFlightChangeDao = null;
	
	private FlightChangeDao() {
	}
	
	public static FlightChangeDao getInstance() {
        if (massFlightChangeDao == null) 
        {
            massFlightChangeDao = new FlightChangeDao();
        }
        return massFlightChangeDao;
	}
	
	public void massFlightChange(ArrayList flightChangeList) {
		
	}

}
