package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.ejb.SessionBean;

import com.dfs.paxtrax.admin.dao.UserDAO;
import com.dfs.paxtrax.admin.exception.SecurityException;
import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.business.PaxTraxSessionWrapper;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
 * Bean implementation class for Enterprise Bean: UserBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 7/04/2004	Vaikundamurthy	Created   
 */	


public class UserBOBean extends PaxTraxSessionWrapper
	implements SessionBean
{
	UserDAO userDAO = null;
	/**
	 * Saves user details by invoking BO method.
	 * @param userBean UserBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving user details
	 */
	public void saveUserDetails(UserBean userBean) 
		throws SecurityException, PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::saveUserDetails::Begin");
		userDAO = UserDAO.getInstance();
		userDAO.insertUserDetails(userBean);
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::saveUserDetails::End");
	}
	
	/**
	 * Updates user details by invoking BO method.
	 * @param userBean UserBean 
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating user details
	 */
	public void updateUserDetails(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::updateUserDetails::Begin");
		userDAO = UserDAO.getInstance();
		userDAO.updateUserDetails(userBean);
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::updateUserDetails::End");
	}
	
	/**
	 * Updates activate status by invoking BO method.
	 * @param userBean UserBean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating activate status
	 */
	public void updateActivateStatus(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::updateActivateStatus::Begin");
		userDAO = UserDAO.getInstance();
		userDAO.updateActivateStatus(userBean);	
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::updateActivateStatus::End");
	}
	
	/**
	 * Updates lock status by invoking BO method.
	 * @param userBean UserBean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in updating lock status
	 */
	public void updateLockStatus(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::updateLockStatus::Begin");
		userDAO = UserDAO.getInstance();
		userDAO.updateLockStatus(userBean);
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::updateLockStatus::End");
	}
	
	/**
	 * Removes user details by invoking BO method.
	 * @param userBean UserBean
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in removing user details
	 */
	public void removeUserDetails(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::removeUserDetails::Begin");
		userDAO = UserDAO.getInstance();
		userDAO.deleteUserDetails(userBean);
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::removeUserDetails::End");
	}
	
	/**
	 * Return user list for the given search criteria by invoking BO method.
	 * @param userBean UserBean
	 * @return ArrayList List of user details
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in search
	 */
	public ArrayList searchUserDetails(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::searchUserDetails::Begin");
		UserDAO userDAO =  UserDAO.getInstance();
		ArrayList userList = userDAO.selectUserDetails(userBean);
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::searchUserDetails::End");
		return userList;
	}	
	
	/**
	 * Returns list of transactions
	 * @return ArrayList List of transactions
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in searching transactions
	 */
	public ArrayList searchTransactions() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::searchTransactions::Begin");
		UserDAO userDAO =  UserDAO.getInstance();
		ArrayList transactions = userDAO.selectTransactions();
		PaxTraxLog.logDebug("PaxTrax::UserBOBean::searchTransactions::End");
		return transactions;	
	}
    
    /**
     * Changes the Password in the database
     * @param userBean UserBean
     * @throws PaxTraxSystemException This exception is thrown if there is 
     * any problem in updating the User Table
     */
    public void changePassword(UserBean userBean) throws PaxTraxSystemException
    {
        PaxTraxLog.logDebug("PaxTrax::UserBOBean::changePassword::Begin");
        UserDAO userDAO =  UserDAO.getInstance();
        userDAO.changePassword(userBean);
        PaxTraxLog.logDebug("PaxTrax::UserBOBean::changePassword::End");
    }   	
}
