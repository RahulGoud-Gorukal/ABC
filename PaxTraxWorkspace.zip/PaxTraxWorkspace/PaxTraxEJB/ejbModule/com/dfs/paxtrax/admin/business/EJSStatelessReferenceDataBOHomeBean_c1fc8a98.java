package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessReferenceDataBOHomeBean_c1fc8a98
 */
public class EJSStatelessReferenceDataBOHomeBean_c1fc8a98 extends EJSHome {
	/**
	 * EJSStatelessReferenceDataBOHomeBean_c1fc8a98
	 */
	public EJSStatelessReferenceDataBOHomeBean_c1fc8a98() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public com.dfs.paxtrax.admin.business.ReferenceDataBO create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
com.dfs.paxtrax.admin.business.ReferenceDataBO result = null;
boolean createFailed = false;
try {
	result = (com.dfs.paxtrax.admin.business.ReferenceDataBO) super.createWrapper(new BeanId(this, null));
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
