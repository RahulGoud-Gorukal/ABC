package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.EJBObject;

import com.dfs.paxtrax.admin.exception.SkuException;
import com.dfs.paxtrax.admin.valueobject.SKUBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;


/**
 * Remote interface for Enterprise Bean: SKUBO
 * 
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 20/04/2004	Yuvarani    	Created   
 */

public interface SKUBO extends EJBObject
{
	
	/**
	 * loads Sku details by invoking BO method.
	 * @returns ArrayList locationList
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in loading Sku details
	 */
	public ArrayList loadSkuPage()
		throws PaxTraxSystemException, RemoteException;

	/**
	 * Saves Sku details by invoking BO method.
	 * @param SKUBean skubean
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving Sku details
	 */
	public String[] saveSKUDetails(SKUBean skubean,String userId)
		throws PaxTraxSystemException, RemoteException,SkuException;

	/**
	 * Method getLocationDetails.
	 * @param skubean
	 * @throws PaxTraxSystemException.This Exception is thrown if there is
	 * any problem in getting location details
	 * @throws RemoteException
	 */
	public SKUBean getLocationDetails(SKUBean skubean)
		throws PaxTraxSystemException, RemoteException;
	
	/**
	 * Sends the Sku details to Triversity
	 * @param SKUBean skuBean
	 * @throws PaxTraxSystemException.This exception is thrown when there is 
	 * any problem in sending the details
	 */
	public void sendEmergencySku(SKUBean skuBean)
		throws PaxTraxSystemException, RemoteException;
}
