package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessFlightBOHomeBean_72d6adf6
 */
public class EJSStatelessFlightBOHomeBean_72d6adf6 extends EJSHome {
	/**
	 * EJSStatelessFlightBOHomeBean_72d6adf6
	 */
	public EJSStatelessFlightBOHomeBean_72d6adf6() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public com.dfs.paxtrax.admin.business.FlightBO create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
com.dfs.paxtrax.admin.business.FlightBO result = null;
boolean createFailed = false;
try {
	result = (com.dfs.paxtrax.admin.business.FlightBO) super.createWrapper(new BeanId(this, null));
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
