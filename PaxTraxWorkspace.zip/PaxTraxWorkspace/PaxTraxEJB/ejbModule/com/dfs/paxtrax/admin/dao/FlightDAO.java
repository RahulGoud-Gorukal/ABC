package com.dfs.paxtrax.admin.dao;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 * Copyright (C) 1998-2003, DFS All rights reserved.
 * 
 */
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * This class has all the insert/select/update methods which communicates 
 * with the database
 * * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * DFS - Buensalida Sheila
 * @version    1.0
 * * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Sundarrajan.K.	Created 
 * 07/28/2007	Uma D			Added a method for CR 250 changes    
 */

public class FlightDAO
{
	//This contains the instance of UserDAO class 
	private static FlightDAO flightDAO = null;
	private static boolean success = false;
	/**
	 * Creates an instance of FlightDAO only if the instance does not
	 * exist.
	 * 
	 * @return FlightDAO Returns the FlightDAO instance
	 */
	public static FlightDAO getInstance()
	{
		if (flightDAO == null)
		{
			initializeInstance();
		}
		return flightDAO;
	}

	/**
	 * Sets the FlightDAO class instance
	 */
	private static synchronized void initializeInstance()
	{
		if (flightDAO == null)
		{
			flightDAO = new FlightDAO();
		}
	}

	/**
	 * Constructor for this class
	 */
	private FlightDAO()
	{

	}

	/**
	 * Insert flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting flight details
	 */
	public void saveFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::saveFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		CallableStatement callableStatement = null;
		Connection connection = dbUtil.getConnection();
		ReferenceDataBean referenceDataBean = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		boolean status = false;
		boolean success = false;
		StringBuffer sql = new StringBuffer();
		String date = null;
		String userId = null;
		try
		{
			//added for CA#290863 by vignesh starts here
			sql.append("call ADM_INSERT_FLIGHT(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,");//15
			/*Modified on 28th June 2006 -Starts 
			*SR 1042 International DF Sale */
			sql.append("?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");//17
			//added for CA#290863 by vignesh ends here
			/*Modified on 28th June 2006 - Ends 
			*SR 1042 International DF Sale */

			callableStatement = connection.prepareCall(sql.toString());
			referenceDataBean = flightBean.getAirlineBean();
			callableStatement.setString(1, referenceDataBean.getReferenceId());
			callableStatement.setString(2, referenceDataBean.getCodeId());
			callableStatement.setString(3, flightBean.getFlightNumber());
			if (flightBean.getIsDeparture())
				callableStatement.setString(4, "D");
			else
				callableStatement.setString(4, "A");
			referenceDataBean = flightBean.getOriginAirportBean();
			callableStatement.setString(5, referenceDataBean.getReferenceId());
			callableStatement.setString(6, referenceDataBean.getCodeId());
			referenceDataBean = flightBean.getDestinationAirportBean();
			callableStatement.setString(7, referenceDataBean.getReferenceId());
			callableStatement.setString(8, referenceDataBean.getCodeId());
			callableStatement.setString(9, flightBean.getFlightType());
			callableStatement.setString(10, flightBean.getHrFlightCutOffTime() + "." + flightBean.getMinFlightCutOffTime());
			referenceDataBean = flightBean.getPickupLocationBean();
			callableStatement.setString(11, referenceDataBean.getReferenceId());
			callableStatement.setString(12, referenceDataBean.getCodeId());
			if (flightBean.getIsDailyCheckBox())
				callableStatement.setString(13, flightBean.getDailyTimeInHr() + "." + flightBean.getDailyTimeInMin());
			else
				callableStatement.setString(13, null);
			if (flightBean.getIsSunCheckBox())
				callableStatement.setString(14, flightBean.getSunTimeInHr() + "." + flightBean.getSunTimeInMin());
			else
				callableStatement.setString(14, null);
			if (flightBean.getIsMonCheckBox())
				callableStatement.setString(15, flightBean.getMonTimeInHr() + "." + flightBean.getMonTimeInMin());
			else
				callableStatement.setString(15, null);
			if (flightBean.getIsTueCheckBox())
				callableStatement.setString(16, flightBean.getTueTimeInHr() + "." + flightBean.getTueTimeInMin());
			else
				callableStatement.setString(16, null);
			if (flightBean.getIsWedCheckBox())
				callableStatement.setString(17, flightBean.getWedTimeInHr() + "." + flightBean.getWedTimeInMin());
			else
				callableStatement.setString(17, null);
			if (flightBean.getIsThuCheckBox())
				callableStatement.setString(18, flightBean.getThuTimeInHr() + "." + flightBean.getThuTimeInMin());
			else
				callableStatement.setString(18, null);
			if (flightBean.getIsFriCheckBox())
				callableStatement.setString(19, flightBean.getFriTimeInHr() + "." + flightBean.getFriTimeInMin());
			else
				callableStatement.setString(19, null);
			if (flightBean.getIsSatCheckBox())
				callableStatement.setString(20, flightBean.getSatTimeInHr() + "." + flightBean.getSatTimeInMin());
			else
				callableStatement.setString(20, null);
			callableStatement.setString(21, "N");
			if (flightBean.getFlightDate() != null)
				date = (flightBean.getFlightDate()).replace('/', '-');
			if (date == null)
			{
				callableStatement.setString(22, null);
				callableStatement.setString(23, null);
				callableStatement.setString(24, null);
				callableStatement.setString(25, null);
				callableStatement.setString(26, null);
			}
			else
			{
				callableStatement.setString(22, "N");
				callableStatement.setString(23, null);
				callableStatement.setString(24, null);
				callableStatement.setString(25, date);
				callableStatement.setString(26, flightBean.getDateTimeInHr() + "." + flightBean.getDateTimeInMin());
			}
			callableStatement.setString(27, flightBean.getUser());
			/*Modified on 28th June 2006 -Starts 
			*SR 1042 International DF Sale */
			if (flightBean.getIsInternational())
				callableStatement.setString(28, "Y");
			else
				callableStatement.setString(28, "N");
			
			//added for CA#290863 by vignesh starts here
			if(flightBean.getisVesselMode())
				callableStatement.setString(29,"Y");
			else
				callableStatement.setString(29,"N");
			callableStatement.setString(30, flightBean.getVesselName());
			callableStatement.registerOutParameter(31, Types.INTEGER);
			callableStatement.registerOutParameter(32, Types.INTEGER);
			/*Modified on 28th June 2006 -Ends 
						*SR 1042 International DF Sale */
			callableStatement.execute();
			int result = callableStatement.getInt(31);
			
			//added for CA#290863 by vignesh ends here
			if (result == 1)
			{

				throw new FlightException(PaxTraxConstants.FLIGHT_ALREADY_EXISTS);
			}
			/*Modified on 28th June 2006 -Starts 
			SR 1042 International DF Sale */ 
			else if (result == 2)
			{

				throw new FlightException(PaxTraxConstants.FLIGHT_PICKUP_MISMATCH);
			}
			/*Modified on 28th June 2006 -Ends 
			*SR 1042 International DF Sale */		
		}
		catch (SQLException sqle)
		{
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{

			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::saveFlightDetails::End");
	}

	/**
	 * Updates the flight details after modification. 
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in updating flight details
	 */
	public void updateFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::updateFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		CallableStatement callableStatement = null;
		Connection connection = dbUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ReferenceDataBean referenceDataBean = null;
		ResultSet rs = null;
		boolean status = false;
		boolean success = false;
		String date = null,oldDate=null;
		StringBuffer sql = new StringBuffer();
		try
		{
			//added for CA#290863 by vignesh starts here
			sql.append("call ADM_UPDATE_FLIGHT(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,");
			sql.append("?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			//added for CA#290863 by vignesh starts here
			callableStatement = connection.prepareCall(sql.toString());
			referenceDataBean = flightBean.getAirlineBean();
			
			callableStatement.setString(1, referenceDataBean.getReferenceId());
			callableStatement.setString(2, referenceDataBean.getCodeId());
			callableStatement.setString(3, flightBean.getFlightNumber());
			if (flightBean.getIsDeparture())
				callableStatement.setString(4, "D");
			else
				callableStatement.setString(4, "A");
			
			//added for CA#290863 by vignesh starts here
			if(flightBean.getisVesselMode())
				callableStatement.setString(5,"Y");
			else
				callableStatement.setString(5,"N");
				
			callableStatement.setString(6, flightBean.getVesselName());
			referenceDataBean = flightBean.getOriginAirportBean();
			callableStatement.setString(7, referenceDataBean.getReferenceId());
			callableStatement.setString(8, referenceDataBean.getCodeId());
			referenceDataBean = flightBean.getDestinationAirportBean();
			callableStatement.setString(9, referenceDataBean.getReferenceId());
			callableStatement.setString(10, referenceDataBean.getCodeId());
			callableStatement.setString(11, flightBean.getFlightType());
			callableStatement.setString(12, flightBean.getHrFlightCutOffTime() + "." + flightBean.getMinFlightCutOffTime());
			referenceDataBean = flightBean.getPickupLocationBean();
			callableStatement.setString(13, referenceDataBean.getReferenceId());
			callableStatement.setString(14, referenceDataBean.getCodeId());
			if (flightBean.getIsDailyCheckBox())
				callableStatement.setString(15, flightBean.getDailyTimeInHr() + "." + flightBean.getDailyTimeInMin());
			else
				callableStatement.setString(15, null);
			if (flightBean.getIsSunCheckBox())
				callableStatement.setString(16, flightBean.getSunTimeInHr() + "." + flightBean.getSunTimeInMin());
			else
				callableStatement.setString(16, null);
			if (flightBean.getIsMonCheckBox())
				callableStatement.setString(17, flightBean.getMonTimeInHr() + "." + flightBean.getMonTimeInMin());
			else
				callableStatement.setString(17, null);
			if (flightBean.getIsTueCheckBox())
				callableStatement.setString(18, flightBean.getTueTimeInHr() + "." + flightBean.getTueTimeInMin());
			else
				callableStatement.setString(18, null);
			if (flightBean.getIsWedCheckBox())
				callableStatement.setString(19, flightBean.getWedTimeInHr() + "." + flightBean.getWedTimeInMin());
			else
				callableStatement.setString(19, null);
			if (flightBean.getIsThuCheckBox())
				callableStatement.setString(20, flightBean.getThuTimeInHr() + "." + flightBean.getThuTimeInMin());
			else
				callableStatement.setString(20, null);
			if (flightBean.getIsFriCheckBox())
				callableStatement.setString(21, flightBean.getFriTimeInHr() + "." + flightBean.getFriTimeInMin());
			else
				callableStatement.setString(21, null);
			if (flightBean.getIsSatCheckBox())
				callableStatement.setString(22, flightBean.getSatTimeInHr() + "." + flightBean.getSatTimeInMin());
			else
				callableStatement.setString(22, null);
			callableStatement.setString(23, "N");
			if (flightBean.getFlightDate() != null && !flightBean.getFlightDate().equals(""))
				date = (flightBean.getFlightDate()).replace('/', '-');
			else
				date = null;
				if (flightBean.getOldFlightDate() != null && !flightBean.getOldFlightDate().equals(""))
				oldDate = (flightBean.getOldFlightDate()).replace('/', '-');
			else
				oldDate = null;


			if (date == null)
			{
				callableStatement.setString(24, "N");
				callableStatement.setString(25, null);
				callableStatement.setString(26, null);
				callableStatement.setString(27, null);
				callableStatement.setString(28, null);
				callableStatement.setString(29, null);
			}
			else
			{
				callableStatement.setString(24, "N");
				callableStatement.setString(25, null);
				callableStatement.setString(26, null);
				callableStatement.setString(27, date);
				callableStatement.setString(28, oldDate);
				callableStatement.setString(29, flightBean.getDateTimeInHr() + "." + flightBean.getDateTimeInMin());
			}
			callableStatement.setString(30, flightBean.getUser());
			
			callableStatement.registerOutParameter(31, Types.INTEGER);
			callableStatement.registerOutParameter(32, Types.INTEGER);
			callableStatement.execute();
			
			int result = callableStatement.getInt(31);
			//added for CA#290863 by vignesh ends here
			if (result == 1)
				throw new FlightException(PaxTraxConstants.FLIGHT_ALREADY_EXISTS);
			/*Modified on 28th June 2006 -Starts 
			*SR 1042 International DF Sale */	
			else if (result == 2 )
				throw new FlightException(PaxTraxConstants.FLIGHT_PICKUP_MISMATCH);
			/*Modified on 28th June 2006 -Ends
			*SR 1042 International DF Sale */
		}
		catch (SQLException sqle)
		{
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{

			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::updateFlightDetails::End");
	}

	/**
	 * Deletes the flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in deleting flight details
	 */
	public void deleteFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::deleteFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		ReferenceDataBean referenceDataBean = null;
		PreparedStatement preparedStatement = null;

		ResultSet resultSet = null;
		boolean status = false;
		boolean success = false;
		StringBuffer sql = new StringBuffer();
		sql.append("update tb_flight_mstr set FLIGHT_FLIGHT_DELETED = 'Y', ");
		sql.append(" MODIFIED_BY = '");
		sql.append(flightBean.getUser());
		sql.append("', MODIFIED_DATE = CURRENT DATE");
		// For Wincor Flight FTP Interface
		sql.append(", MODIFIED_TIME = CURRENT TIME");
		sql.append(" where FLIGHT_AIRLINE_REF_ID = ? and ");
		sql.append(" FLIGHT_AIRLINE_CODE_ID = ? and FLIGHT_FLIGHT_NUMBER = ? ");
		sql.append("and FLIGHT_TYPE = ?");

		try
		{
			preparedStatement = connection.prepareStatement(sql.toString());
			referenceDataBean = flightBean.getAirlineBean();
			preparedStatement.setString(1, referenceDataBean.getReferenceId());
			preparedStatement.setString(2, referenceDataBean.getCodeId());
			preparedStatement.setString(3, flightBean.getFlightNumber());
			if (flightBean.getIsDeparture())
				preparedStatement.setString(4, "D");
			else
				preparedStatement.setString(4, "A");
			status = preparedStatement.execute();
		}
		catch (SQLException sqle)
		{
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::deleteFlightDetails::End");
	}

	/**
	 * Insert override flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting override flight details
	 */
	public void insertOverrideFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{

		PaxTraxLog.logDebug("PaxTrax::FlightDAO::insertOverrideFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		CallableStatement callableStatement = null;
		ReferenceDataBean referenceDataBean = null;
		boolean status = false;
		boolean success = false;
		String sql = null;
		referenceDataBean = flightBean.getAirlineBean();
		String overridedate = null;
		String originaldate = null;

		if (flightBean.getFlightOverrideDate() != null && !flightBean.getFlightOverrideDate().equals(""))
			overridedate = flightBean.getFlightOverrideDate().replace('/', '-');

		if (flightBean.getFlightDate() != null && !flightBean.getFlightDate().equals(""))
			originaldate = flightBean.getFlightDate().replace('/', '-');
		try
		{
			callableStatement = connection.prepareCall("call ADM_INSERT_OVERRIDE_FLIGHT(?,?,?,?,?,?,?,?,?,?,?,?)");
			callableStatement.setString(1, referenceDataBean.getReferenceId());
			callableStatement.setString(2, referenceDataBean.getCodeId());
			callableStatement.setString(3, flightBean.getFlightNumber());
			if (flightBean.getIsDeparture())
				callableStatement.setString(4, "D");
			else
				callableStatement.setString(4, "A");

			if (flightBean.getIsFlightCancelled())
				callableStatement.setString(5, "Y");
			else
				callableStatement.setString(5, "N");

			if (overridedate != null)
			{
				callableStatement.setString(6, overridedate);
				callableStatement.setString(7, flightBean.getOverrideDateTimeInHr() + ":" + flightBean.getOverrideDateTimeInMin() + ":00");
			}
			else
			{
				callableStatement.setString(6, null);
				callableStatement.setString(7, null);
			}

			if (originaldate != null)
			{
				callableStatement.setString(8, originaldate);
				callableStatement.setString(9, flightBean.getDateTimeInHr() + ":" + flightBean.getDateTimeInMin() + ":00");
			}
			else
			{
				callableStatement.setString(8, null);
				callableStatement.setString(9, null);
			}
			callableStatement.setString(10, flightBean.getUser());
			PaxTraxLog.logDebug("PaxTrax::FlightDAO::insertOverrideFlightDetails::userId"+flightBean.getUser());
			callableStatement.registerOutParameter(11, Types.INTEGER);
			callableStatement.registerOutParameter(12, Types.INTEGER);
			status = callableStatement.execute();
		}
		catch (SQLException sqle)
		{

		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{

			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::insertOverrideFlightDetails::End");
	}

	/**
	 * Removes the override flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in removing override flight details
	 */
	public void removeOverrideFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::removeOverrideFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		CallableStatement callableStatement = null;
		ReferenceDataBean referenceDataBean = null;
		boolean status = false;
		boolean success = false;
		String sql = null;
		String originaldate = null;
		referenceDataBean = flightBean.getAirlineBean();
		String flightType = flightBean.getFlightType();

		if (flightType != null && flightType.equals(PaxTraxConstants.SCHEDULED))
		{
			flightType = "1";
		}
		else
		{
			flightType = "2";
		}

		if (flightBean.getFlightDate() != null && !flightBean.getFlightDate().equals(""))
			originaldate = flightBean.getFlightDate().replace('/', '-');

		try
		{

			callableStatement = connection.prepareCall("call ADM_REMOVE_OVERRIDE_FLIGHT(?,?,?,?,?,?,?,?,?,?,?)");
			callableStatement.setString(1, referenceDataBean.getReferenceId());
			callableStatement.setString(2, referenceDataBean.getCodeId());
			callableStatement.setString(3, flightBean.getFlightNumber());
			if (flightBean.getIsDeparture())
				callableStatement.setString(4, "D");
			else
				callableStatement.setString(4, "A");
			callableStatement.setString(5, originaldate);
			callableStatement.setString(6, flightBean.getDateTimeInHr() + ":" + flightBean.getDateTimeInMin() + ":00");

			callableStatement.setString(7, flightType.trim());
			if (flightBean.getIsFlightCancelled())
				callableStatement.setString(8, "Y");
			else
				callableStatement.setString(8, "N");
//Added on July 28, 2007 for CR 250 changes -- Begin				
			callableStatement.setString(9,flightBean.getUser());
//Added on July 28, 2007 for CR 250 changes -- End			
			callableStatement.registerOutParameter(10, Types.INTEGER);
			callableStatement.registerOutParameter(11, Types.INTEGER);
			status = callableStatement.execute();
			int result = callableStatement.getInt(11);
			if(result!=0)
			{
				
			PaxTraxLog.logError("Error in removeOverrideFlightDetails" + result);
			throw new PaxTraxSystemException(result);
			}
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			PaxTraxLog.logError("PaxTrax::FlightDAO::removeOverrideFlightDetails::exception::"+sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::removeOverrideFlightDetails::End");
	}

	/**
	 * Searches Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::selectFlightDetails::Begin");
		ArrayList flightList = getFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::selectFlightDetails::End");
		return flightList;
	}

	/**
	 * Searches Override Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectOverrideFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::selectOverrideFlightDetails::Begin");
		ArrayList flightList = getOverrideFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::selectOverrideFlightDetails::End");
		return flightList;
	}

	/**
	 * Searches Flight details based on the tab pressed in the maintain page and returns the 
	 * result. 
	 * @param flightBean
	 * @return FlightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public FlightBean selectMaintainFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::selectMaintainFlightDetails::Begin");
		flightBean = getMaintainFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::selectMaintainFlightDetails::End");
		return flightBean;
	}

	private FlightBean getMaintainFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::getMaintainFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		ReferenceDataBean referenceDataBean = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean dateFound = false;
		ArrayList scheduleFlights = null;
		StringBuffer maintainSelectQuery = new StringBuffer();
		maintainSelectQuery.append("select flight_flight_status from ");
		maintainSelectQuery.append("tb_flight_mstr where ");
		maintainSelectQuery.append("FLIGHT_FLIGHT_DELETED = 'N' and ");
		maintainSelectQuery.append("FLIGHT_AIRLINE_REF_ID = ? and ");
		maintainSelectQuery.append("FLIGHT_AIRLINE_CODE_ID = ? and ");
		maintainSelectQuery.append("FLIGHT_FLIGHT_NUMBER = ? and FLIGHT_TYPE = ?");
		try
		{
			preparedStatement = connection.prepareStatement(maintainSelectQuery.toString());
			referenceDataBean = flightBean.getAirlineBean();
			preparedStatement.setString(1, referenceDataBean.getReferenceId());
			preparedStatement.setString(2, referenceDataBean.getCodeId());
			preparedStatement.setString(3, flightBean.getFlightNumber());
			if (flightBean.getIsDeparture())
				preparedStatement.setString(4, "D");
			else
				preparedStatement.setString(4, "A");
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next())
			{
				if (resultSet.getString(1).equals("1"))
				{
					maintainSelectQuery = new StringBuffer();
					maintainSelectQuery.append("select flight_airline_ref_id,");
					maintainSelectQuery.append("flight_airline_code_id,");
					maintainSelectQuery.append("flight_flight_number,flight_type,");
					maintainSelectQuery.append("FLIGHT_ORIGIN_AIRPORT_REF_ID,");
					maintainSelectQuery.append("flight_code_origin_code_id,");
					maintainSelectQuery.append("FLIGHT_DEST_AIRPORT_REF_ID,");
					maintainSelectQuery.append("flight_code_dest_code_id,");
					maintainSelectQuery.append("flight_flight_status,");
					maintainSelectQuery.append("hour(flight_cutoff_time),");
					maintainSelectQuery.append("minute(flight_cutoff_time),");
					maintainSelectQuery.append("FLIGHT_PICKUP_LOC_REF_ID,");
					maintainSelectQuery.append("flight_pickup_loc_code_code_id,");
					maintainSelectQuery.append("hour(flight_daily),");
					maintainSelectQuery.append("minute(flight_daily),");
					maintainSelectQuery.append("hour(flight_sun),");
					maintainSelectQuery.append("minute(flight_sun),");
					maintainSelectQuery.append("hour(flight_mon),");
					maintainSelectQuery.append("minute(flight_mon),");
					maintainSelectQuery.append("hour(flight_tue),");
					maintainSelectQuery.append("minute(flight_tue),");
					maintainSelectQuery.append("hour(flight_wed),");
					maintainSelectQuery.append("minute(flight_wed),");
					maintainSelectQuery.append("hour(flight_thu),");
					maintainSelectQuery.append("minute(flight_thu),");
					maintainSelectQuery.append("hour(flight_fri),");
					maintainSelectQuery.append("minute(flight_fri),");
					maintainSelectQuery.append("hour(flight_sat),");
					maintainSelectQuery.append("minute(flight_sat),  ");
					/*Modified on 28th June 2006 -Starts 
					*SR 1042 International DF Sale */	
					maintainSelectQuery.append("INTERNATIONAL_FLAG, ");
					/*Modified on 28th June 2006 - Ends
					*SR 1042 International DF Sale */
					
					//added for CA#290863 by vignesh starts here
					maintainSelectQuery.append(" VESSEL_FLAG, ");
					maintainSelectQuery.append(" VESSEL_NAME FROM ");
					//added for CA#290863 by vignesh ends here
					maintainSelectQuery.append(" tb_flight_mstr where ");
					maintainSelectQuery.append("FLIGHT_FLIGHT_DELETED = 'N' and ");
					maintainSelectQuery.append("FLIGHT_AIRLINE_REF_ID = ? and ");
					maintainSelectQuery.append("FLIGHT_AIRLINE_CODE_ID = ? and ");
					maintainSelectQuery.append("FLIGHT_FLIGHT_NUMBER = ? ");
					maintainSelectQuery.append("and FLIGHT_TYPE = ?");

					try
					{
						preparedStatement = connection.prepareStatement(maintainSelectQuery.toString());
						referenceDataBean = flightBean.getAirlineBean();
						preparedStatement.setString(1, referenceDataBean.getReferenceId());
						preparedStatement.setString(2, referenceDataBean.getCodeId());
						preparedStatement.setString(3, flightBean.getFlightNumber());
						if (flightBean.getIsDeparture())
							preparedStatement.setString(4, "D");
						else
							preparedStatement.setString(4, "A");
						resultSet = preparedStatement.executeQuery();
						while (resultSet.next())
						{
							referenceDataBean.setReferenceId(resultSet.getString(1));
							referenceDataBean.setCodeId(resultSet.getString(2));
							flightBean.setAirlineBean(referenceDataBean);

							flightBean.setFlightNumber(resultSet.getString(3));
							if (resultSet.getString(4).equals("D"))
							{
								flightBean.setIsDeparture(true);
							}
							else
							{
								flightBean.setIsDeparture(false);
							}

							referenceDataBean = flightBean.getOriginAirportBean();
							referenceDataBean.setReferenceId(resultSet.getString(5));
							referenceDataBean.setCodeId(resultSet.getString(6));
							flightBean.setOriginAirportBean(referenceDataBean);

							referenceDataBean = flightBean.getDestinationAirportBean();
							referenceDataBean.setReferenceId(resultSet.getString(7));
							referenceDataBean.setCodeId(resultSet.getString(8));
							flightBean.setDestinationAirportBean(referenceDataBean);

							flightBean.setFlightType(resultSet.getString(9));

							flightBean.setHrFlightCutOffTime(checkTimeList(resultSet.getString(10)));
							flightBean.setMinFlightCutOffTime(checkTimeList(resultSet.getString(11)));

							referenceDataBean = flightBean.getPickupLocationBean();
							referenceDataBean.setReferenceId(resultSet.getString(12));
							referenceDataBean.setCodeId(resultSet.getString(13));
							flightBean.setPickupLocationBean(referenceDataBean);

							if (resultSet.getString(14) != null)
							{
								flightBean.setIsDailyCheckBox(true);
								flightBean.setDailyTimeInHr(checkTimeList(resultSet.getString(14)));
								flightBean.setDailyTimeInMin(checkTimeList(resultSet.getString(15)));
							}
							else
							{
								flightBean.setIsDailyCheckBox(false);
								flightBean.setDailyTimeInHr(null);
								flightBean.setDailyTimeInMin(null);
							}
							if (resultSet.getString(16) != null)
							{
								flightBean.setIsSunCheckBox(true);
								flightBean.setSunTimeInHr(checkTimeList(resultSet.getString(16)));
								flightBean.setSunTimeInMin(checkTimeList(resultSet.getString(17)));
							}
							else
							{
								flightBean.setIsSunCheckBox(false);
								flightBean.setSunTimeInHr(null);
								flightBean.setSunTimeInMin(null);
							}
							if (resultSet.getString(18) != null)
							{
								flightBean.setIsMonCheckBox(true);
								flightBean.setMonTimeInHr(checkTimeList(resultSet.getString(18)));
								flightBean.setMonTimeInMin(checkTimeList(resultSet.getString(19)));
							}
							else
							{
								flightBean.setIsMonCheckBox(false);
								flightBean.setMonTimeInHr(null);
								flightBean.setMonTimeInMin(null);
							}
							if (resultSet.getString(20) != null)
							{
								flightBean.setIsTueCheckBox(true);
								flightBean.setTueTimeInHr(checkTimeList(resultSet.getString(20)));
								flightBean.setTueTimeInMin(checkTimeList(resultSet.getString(21)));
							}
							else
							{
								flightBean.setIsTueCheckBox(false);
								flightBean.setTueTimeInHr(null);
								flightBean.setTueTimeInMin(null);
							}
							if (resultSet.getString(22) != null)
							{
								flightBean.setIsWedCheckBox(true);
								flightBean.setWedTimeInHr(checkTimeList(resultSet.getString(22)));
								flightBean.setWedTimeInMin(checkTimeList(resultSet.getString(23)));
							}
							else
							{
								flightBean.setIsWedCheckBox(false);
								flightBean.setWedTimeInHr(null);
								flightBean.setWedTimeInMin(null);
							}
							if (resultSet.getString(24) != null)
							{
								flightBean.setIsThuCheckBox(true);
								flightBean.setThuTimeInHr(checkTimeList(resultSet.getString(24)));
								flightBean.setThuTimeInMin(checkTimeList(resultSet.getString(25)));
							}
							else
							{
								flightBean.setIsThuCheckBox(false);
								flightBean.setThuTimeInHr(null);
								flightBean.setThuTimeInMin(null);
							}
							if (resultSet.getString(26) != null)
							{
								flightBean.setIsFriCheckBox(true);
								flightBean.setFriTimeInHr(checkTimeList(resultSet.getString(26)));
								flightBean.setFriTimeInMin(checkTimeList(resultSet.getString(27)));
							}
							else
							{
								flightBean.setIsFriCheckBox(false);
								flightBean.setFriTimeInHr(null);
								flightBean.setFriTimeInMin(null);
							}
							if (resultSet.getString(28) != null)
							{
								flightBean.setIsSatCheckBox(true);
								flightBean.setSatTimeInHr(checkTimeList(resultSet.getString(28)));
								flightBean.setSatTimeInMin(checkTimeList(resultSet.getString(29)));
							}
							else
							{
								flightBean.setIsSatCheckBox(false);
								flightBean.setSatTimeInHr(null);
								flightBean.setSatTimeInMin(null);
							}
							/*Modified on 28th June 2006 -Starts 
							*SR 1042 International DF Sale */
							if("Y".equals(resultSet.getString("international_flag")))
								flightBean.setIsInternational(true);
							else	
								flightBean.setIsInternational(false);
							/*Modified on 28th June 2006 -Ends 
							*SR 1042 International DF Sale */	
							
							//added for CA#290863 by vignesh starts here
							String vessel_mode = resultSet.getString("VESSEL_FLAG");
							if("Y".equals((vessel_mode)))
								flightBean.setIsVesselMode(true);
							else
								flightBean.setIsVesselMode(false);

							if(resultSet.getString("VESSEL_NAME") !=null)
							{
								flightBean.setVesselName(resultSet.getString("VESSEL_NAME"));
							}
							else
								flightBean.setVesselName(null);		
							//added for CA#290863 by vignesh ends here
							flightBean.setFlightDate(null);
							flightBean.setDateTimeInHr(null);
							flightBean.setDateTimeInMin(null);
						}
					}
					catch (SQLException sq)
					{
					}
					finally
					{
						try
						{
							if (resultSet != null)
							{
								resultSet.close();
								resultSet = null;
							}
							if (preparedStatement != null)
							{
								preparedStatement.close();
								preparedStatement = null;
							}
							if (connection != null)
							{
								connection.close();
								connection = null;
							}
						}
						catch (SQLException sqle)
						{

						}
					}

				}
				else if (resultSet.getString(1).equals("2"))
				{
					maintainSelectQuery = new StringBuffer();
					maintainSelectQuery.append("select ");
					maintainSelectQuery.append("tfm.flight_airline_ref_id,");
					maintainSelectQuery.append("tfm.flight_airline_code_id,");
					maintainSelectQuery.append("tfm.flight_flight_number,");
					maintainSelectQuery.append("tfm.flight_type,");
					maintainSelectQuery.append("FLIGHT_ORIGIN_AIRPORT_REF_ID,");
					maintainSelectQuery.append("flight_code_origin_code_id,");
					maintainSelectQuery.append("FLIGHT_DEST_AIRPORT_REF_ID,");
					maintainSelectQuery.append("flight_code_dest_code_id,");
					maintainSelectQuery.append("flight_flight_status,");
					maintainSelectQuery.append("hour(flight_cutoff_time),");
					maintainSelectQuery.append("minute(flight_cutoff_time),");
					maintainSelectQuery.append("FLIGHT_PICKUP_LOC_REF_ID,");
					maintainSelectQuery.append("flight_pickup_loc_code_code_id,");
					maintainSelectQuery.append("flight_original_date,");
					maintainSelectQuery.append("hour(flight_original_time),");
					maintainSelectQuery.append("minute(flight_original_time),");
					maintainSelectQuery.append("flight_over_date,");
					maintainSelectQuery.append("hour(flight_over_time),");
					maintainSelectQuery.append("minute(flight_over_time),");
					/*Modified on 28th June 2006 -Starts 
					*SR 1042 International DF Sale */
					maintainSelectQuery.append(" INTERNATIONAL_FLAG, ");
					/*Modified on 28th June 2006 -Starts 
					*SR 1042 International DF Sale */
					//added for CA#290863 by vignesh starts here
					maintainSelectQuery.append(" VESSEL_FLAG, ");
					maintainSelectQuery.append(" VESSEL_NAME ");
					//added for CA#290863 by vignesh ends here
					maintainSelectQuery.append(" from tb_flight_mstr tfm,");
					maintainSelectQuery.append("tb_flight_override tfo ");
					maintainSelectQuery.append("where ");
					maintainSelectQuery.append("tfm.FLIGHT_FLIGHT_DELETED = 'N'");
					maintainSelectQuery.append(" and ");
					maintainSelectQuery.append("tfm.FLIGHT_AIRLINE_REF_ID = ? ");
					maintainSelectQuery.append("and tfm.FLIGHT_AIRLINE_CODE_ID = ? ");
					maintainSelectQuery.append("and tfm.FLIGHT_FLIGHT_NUMBER = ? ");
					maintainSelectQuery.append("and tfm.FLIGHT_TYPE = ? and");
					maintainSelectQuery.append(" tfm.FLIGHT_AIRLINE_REF_ID =");
					maintainSelectQuery.append(" tfo.FLIGHT_AIRLINE_REF_ID ");
					maintainSelectQuery.append("and ");
					maintainSelectQuery.append("tfm.FLIGHT_AIRLINE_CODE_ID = ");
					maintainSelectQuery.append("tfo.FLIGHT_AIRLINE_CODE_CODE_ID ");
					maintainSelectQuery.append("and tfm.FLIGHT_FLIGHT_NUMBER =");
					maintainSelectQuery.append(" tfo.FLIGHT_FLIGHT_NUMBER and");
					maintainSelectQuery.append(" tfm.FLIGHT_TYPE = tfo.FLIGHT_TYPE");
					try
					{
						preparedStatement = connection.prepareStatement(maintainSelectQuery.toString());
						referenceDataBean = flightBean.getAirlineBean();
						preparedStatement.setString(1, referenceDataBean.getReferenceId());
						preparedStatement.setString(2, referenceDataBean.getCodeId());
						preparedStatement.setString(3, flightBean.getFlightNumber());
						if (flightBean.getIsDeparture())
							preparedStatement.setString(4, "D");
						else
							preparedStatement.setString(4, "A");
						resultSet = preparedStatement.executeQuery();
						while (resultSet.next())
						{
							referenceDataBean = flightBean.getAirlineBean();
							referenceDataBean.setReferenceId(resultSet.getString(1));
							referenceDataBean.setCodeId(resultSet.getString(2));
							flightBean.setAirlineBean(referenceDataBean);

							flightBean.setFlightNumber(resultSet.getString(3));

							if (resultSet.getString(4).equals("D"))
								flightBean.setIsDeparture(true);
							else
								flightBean.setIsDeparture(false);

							referenceDataBean = flightBean.getOriginAirportBean();
							referenceDataBean.setReferenceId(resultSet.getString(5));
							referenceDataBean.setCodeId(resultSet.getString(6));
							flightBean.setOriginAirportBean(referenceDataBean);

							referenceDataBean = flightBean.getDestinationAirportBean();
							referenceDataBean.setReferenceId(resultSet.getString(7));
							referenceDataBean.setCodeId(resultSet.getString(8));
							flightBean.setDestinationAirportBean(referenceDataBean);

							flightBean.setFlightType(resultSet.getString(9));

							flightBean.setHrFlightCutOffTime(checkTimeList(resultSet.getString(10)));
							flightBean.setMinFlightCutOffTime(checkTimeList(resultSet.getString(11)));

							referenceDataBean = flightBean.getPickupLocationBean();
							referenceDataBean.setReferenceId(resultSet.getString(12));
							referenceDataBean.setCodeId(resultSet.getString(13));
							flightBean.setPickupLocationBean(referenceDataBean);
							if (resultSet.getString(17) != null)
							{
								flightBean.setFlightDate(resultSet.getString(17).replace('-', '/'));
								flightBean.setOldFlightDate(resultSet.getString(17).replace('-', '/'));
								dateFound = true;
							}
							if (resultSet.getString(18) != null)
							{
								flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(18)));
								flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(19)));
								dateFound = true;
							}

							if (resultSet.getString(14) != null && !dateFound)
							{
								flightBean.setFlightDate(resultSet.getString(14).replace('-', '/'));
								flightBean.setOldFlightDate(resultSet.getString(14).replace('-', '/'));
							}

							if (resultSet.getString(15) != null && !dateFound)
							{
								flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(15)));
								flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(16)));
							}
							/*Modified on 28th June 2006 -Starts 
										*SR 1042 International DF Sale */
							if("Y".equals(resultSet.getString("international_flag")))
								flightBean.setIsInternational(true);
							else	
								flightBean.setIsInternational(false);
							/*Modified on 28th June 2006 -Starts 
										*SR 1042 International DF Sale */
										
							//added for CA#290863 by vignesh starts here
							  String vessel_mode = resultSet.getString("VESSEL_FLAG");
							  if("Y".equals((vessel_mode)))
								  flightBean.setIsVesselMode(true);
							  else
								  flightBean.setIsVesselMode(false);
	
							  if(resultSet.getString("VESSEL_NAME") !=null)
							  {
							  	  flightBean.setVesselName(resultSet.getString("VESSEL_NAME"));
							  }
							  else
								  flightBean.setVesselName(null);							
							//added for CA#290863 by vignesh ends here
							flightBean.setIsDailyCheckBox(false);
							flightBean.setDailyTimeInHr(null);
							flightBean.setDailyTimeInMin(null);
							flightBean.setIsSunCheckBox(false);
							flightBean.setSunTimeInHr(null);
							flightBean.setSunTimeInMin(null);
							flightBean.setIsMonCheckBox(false);
							flightBean.setMonTimeInHr(null);
							flightBean.setMonTimeInMin(null);
							flightBean.setIsTueCheckBox(false);
							flightBean.setTueTimeInHr(null);
							flightBean.setTueTimeInMin(null);
							flightBean.setIsWedCheckBox(false);
							flightBean.setWedTimeInHr(null);
							flightBean.setWedTimeInMin(null);
							flightBean.setIsThuCheckBox(false);
							flightBean.setThuTimeInHr(null);
							flightBean.setThuTimeInMin(null);
							flightBean.setIsFriCheckBox(false);
							flightBean.setFriTimeInHr(null);
							flightBean.setFriTimeInMin(null);
							flightBean.setIsSatCheckBox(false);
							flightBean.setSatTimeInHr(null);
							flightBean.setSatTimeInMin(null);
						}

					}
					catch (SQLException sq)
					{

					}
					finally
					{
						try
						{
							if (resultSet != null)
							{
								resultSet.close();
								resultSet = null;
							}
							if (preparedStatement != null)
							{
								preparedStatement.close();
								preparedStatement = null;
							}
						}
						catch (SQLException sqle)
						{

						}
					}

				}

			}
			else
			{
				throw new FlightException(PaxTraxConstants.FLIGHT_NOT_FOUND);
			}
		}
		catch (SQLException sqle)
		{

		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{

			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::getMaintainFlightDetails::End");
		return flightBean;
	}

	private ArrayList getFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::getFlightDetails::Begin");
		ArrayList flightDetails = new ArrayList();
		ArrayList scheduleFlights = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		PreparedStatement preparedStatement = null;
		ReferenceDataBean referenceDataBean = null;
		ResultSet resultSet = null;
		StringBuffer searchSql = new StringBuffer();
		boolean success = false;
		boolean dateFound = false;
		
		if (flightBean.getFlightType() != null && flightBean.getFlightType().equals("1"))
		{
			searchSql.append("select fm.FLIGHT_AIRLINE_REF_ID, ");
			searchSql.append("fm.FLIGHT_AIRLINE_CODE_ID,(select  ");
			searchSql.append(" a.code_code_value from tb_code_ref a where ");
			searchSql.append(" fm.flight_airline_ref_id = a.ref_id and ");
			searchSql.append(" fm.flight_airline_code_id = a.code_code_id), ");
			searchSql.append("fm.FLIGHT_FLIGHT_NUMBER,fm.FLIGHT_TYPE, ");
			searchSql.append("fm.FLIGHT_ORIGIN_AIRPORT_REF_ID,");
			searchSql.append("fm.FLIGHT_CODE_ORIGIN_CODE_ID,(select ");
			searchSql.append("b.code_code_value from tb_code_ref b where ");
			searchSql.append("fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and ");
			searchSql.append("fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id),");
			searchSql.append("fm.FLIGHT_DEST_AIRPORT_REF_ID,");
			searchSql.append("fm.FLIGHT_CODE_DEST_CODE_ID,(select ");
			searchSql.append("c.code_code_value from tb_code_ref c where ");
			searchSql.append("fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and ");
			searchSql.append("fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id),");
			searchSql.append("fm.FLIGHT_FLIGHT_STATUS,hour(fm.FLIGHT_CUTOFF_TIME),");
			searchSql.append("minute(fm.FLIGHT_CUTOFF_TIME),");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_REF_ID,");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID,(select ");
			searchSql.append("d.code_code_value from tb_code_ref d where ");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and ");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = ");
			searchSql.append("d.code_code_id),");
			searchSql.append("hour(fm.FLIGHT_DAILY),minute(fm.FLIGHT_DAILY),");
			searchSql.append("hour(fm.FLIGHT_SUN),minute(fm.FLIGHT_SUN),");
			searchSql.append("hour(fm.FLIGHT_MON),minute(fm.FLIGHT_MON),");
			searchSql.append("hour(fm.FLIGHT_TUE),minute(fm.FLIGHT_TUE),");
			searchSql.append("hour(fm.FLIGHT_WED),minute(fm.FLIGHT_WED),");
			searchSql.append("hour(fm.FLIGHT_THU),minute(fm.FLIGHT_THU),");
			searchSql.append("hour(fm.FLIGHT_FRI),minute(fm.FLIGHT_FRI),");
			searchSql.append("hour(fm.FLIGHT_SAT),minute(fm.FLIGHT_SAT), ");
			/*Modified on 28th June 2006 -Starts 
						*SR 1042 International DF Sale */
			
			//added for CA#290863 by vignesh starts here						
			searchSql.append("fm.FLIGHT_FLIGHT_DELETED,fm.INTERNATIONAL_FLAG,fm.VESSEL_FLAG,fm.VESSEL_NAME from tb_flight_mstr fm ");
			//added for CA#290863 by vignesh ends here
			
			/*Modified on 28th June 2006 -Ends 
						*SR 1042 International DF Sale */
			searchSql.append("where fm.FLIGHT_FLIGHT_DELETED = 'N' and ");
			searchSql.append("fm.FLIGHT_FLIGHT_STATUS = '");
			searchSql.append(flightBean.getFlightType());
			searchSql.append("'");
		}
		else
		{
			searchSql.append("select fm.FLIGHT_AIRLINE_REF_ID, ");
			searchSql.append("fm.FLIGHT_AIRLINE_CODE_ID,(select  ");
			searchSql.append(" a.code_code_value from tb_code_ref a where ");
			searchSql.append(" fm.flight_airline_ref_id = a.ref_id and ");
			searchSql.append(" fm.flight_airline_code_id = a.code_code_id), ");
			searchSql.append("fm.FLIGHT_FLIGHT_NUMBER,fm.FLIGHT_TYPE, ");
			searchSql.append("fm.FLIGHT_ORIGIN_AIRPORT_REF_ID,");
			searchSql.append("fm.FLIGHT_CODE_ORIGIN_CODE_ID,(select ");
			searchSql.append("b.code_code_value from tb_code_ref b where ");
			searchSql.append("fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id and ");
			searchSql.append("fm.FLIGHT_CODE_ORIGIN_CODE_ID = b.code_code_id),");
			searchSql.append("fm.FLIGHT_DEST_AIRPORT_REF_ID,");
			searchSql.append("fm.FLIGHT_CODE_DEST_CODE_ID,(select ");
			searchSql.append("c.code_code_value from tb_code_ref c where ");
			searchSql.append("fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and ");
			searchSql.append("fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id),");
			searchSql.append("fm.FLIGHT_FLIGHT_STATUS,hour(fm.FLIGHT_CUTOFF_TIME),");
			searchSql.append("minute(fm.FLIGHT_CUTOFF_TIME),");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_REF_ID,");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID,(select ");
			searchSql.append("d.code_code_value from tb_code_ref d where ");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and ");
			searchSql.append("fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = ");
			searchSql.append("d.code_code_id),");
			searchSql.append("fs.flight_original_date,");
			searchSql.append("hour(fs.flight_original_time),");
			searchSql.append("minute(fs.flight_original_time), ");
			searchSql.append("fs.flight_over_date,");
			searchSql.append("hour(fs.flight_over_time),");
			searchSql.append("minute(fs.flight_over_time),  ");
			/*Modified on 28th June 2006 -Starts 
			*SR 1042 International DF Sale */
			searchSql.append("fm.INTERNATIONAL_FLAG,  ");
			//added for CA#290863 by vignesh starts here
			searchSql.append("fm.VESSEL_FLAG, fm.VESSEL_NAME from ");
			//added for CA#290863 by vignesh ends here
			/*Modified on 28th June 2006 -Ends 
			*SR 1042 International DF Sale */
			searchSql.append("tb_flight_mstr fm,tb_flight_override fs where ");
			searchSql.append("fs.flight_cancelled = 'N' and ");
			searchSql.append("fm.FLIGHT_FLIGHT_DELETED = 'N' and ");
			searchSql.append("fm.FLIGHT_FLIGHT_STATUS = '");
			searchSql.append(flightBean.getFlightType());
			searchSql.append("' and fm.flight_airline_ref_id = ");
			searchSql.append("fs.flight_airline_ref_id and ");
			searchSql.append("fm.flight_airline_code_id = ");
			searchSql.append("fs.flight_airline_code_code_id and ");
			searchSql.append("fm.flight_flight_number = fs.flight_flight_number ");
			searchSql.append("and fm.flight_type = fs.flight_type");
		}

		if (flightBean.getIsDeparture())
		{
			searchSql.append(" and fm.flight_type = 'D' ");
		}
		else
		{
			searchSql.append(" and fm.flight_type = 'A' ");
		}

		referenceDataBean = flightBean.getAirlineBean();

		if (referenceDataBean.getCodeId() != null && !referenceDataBean.getCodeId().equals("-1"))
		{
			searchSql.append(" and fm.FLIGHT_AIRLINE_REF_ID = '");
			searchSql.append(referenceDataBean.getReferenceId());
			searchSql.append("' and fm.FLIGHT_AIRLINE_CODE_ID = '");
			searchSql.append(referenceDataBean.getCodeId());
			searchSql.append("'");
		}
		if (flightBean.getFlightNumber() != null)
		{
			if (!flightBean.getFlightNumber().trim().equals(""))
			{
				searchSql.append(" and fm.FLIGHT_FLIGHT_NUMBER like '%");
				searchSql.append(flightBean.getFlightNumber());
				searchSql.append("%' ");
			}
		}
		referenceDataBean = flightBean.getOriginAirportBean();

		if (referenceDataBean.getCodeId() != null && !referenceDataBean.getCodeId().equals("-1"))
		{
			searchSql.append(" and fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = '");
			searchSql.append(referenceDataBean.getReferenceId());
			searchSql.append("' and fm.FLIGHT_CODE_ORIGIN_CODE_ID = '");
			searchSql.append(referenceDataBean.getCodeId());
			searchSql.append("'");
		}

		referenceDataBean = flightBean.getDestinationAirportBean();

		if (referenceDataBean.getCodeId() != null && !referenceDataBean.getCodeId().equals("-1"))
		{
			searchSql.append(" and fm.FLIGHT_DEST_AIRPORT_REF_ID = '");
			searchSql.append(referenceDataBean.getReferenceId());
			searchSql.append("' and fm.FLIGHT_CODE_DEST_CODE_ID = '");
			searchSql.append(referenceDataBean.getCodeId());
			searchSql.append("'");
		}

		referenceDataBean = flightBean.getPickupLocationBean();

		if (referenceDataBean.getCodeId() != null && !referenceDataBean.getCodeId().equals("-1"))
		{
			searchSql.append(" and fm.FLIGHT_PICKUP_LOC_REF_ID = '");
			searchSql.append(referenceDataBean.getReferenceId());
			searchSql.append("' and fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = '");
			searchSql.append(referenceDataBean.getCodeId());
			searchSql.append("'");
		}
		/*Modified on 28th June 2006 -Starts 
					*SR 1042 International DF Sale */
		if("Dom".equals(flightBean.getTravelType()))
			searchSql.append(" and fm.international_flag = 'N' ");
		else if("Intl".equals(flightBean.getTravelType()))
			searchSql.append(" and fm.international_flag = 'Y' ");
		/*Modified on 28th June 2006 -Ends 
					*SR 1042 International DF Sale */
		searchSql.append(" order by fm.FLIGHT_AIRLINE_REF_ID,");
		searchSql.append(" fm.flight_airline_code_id, ");
		searchSql.append(" fm.flight_flight_number, ");
		searchSql.append(" fm.FLIGHT_ORIGIN_AIRPORT_REF_ID ,");
		searchSql.append(" fm.FLIGHT_CODE_ORIGIN_CODE_ID ,");
		searchSql.append(" fm.FLIGHT_DEST_AIRPORT_REF_ID ,");
		searchSql.append(" fm.FLIGHT_CODE_DEST_CODE_ID ");
		try
		{
			preparedStatement = connection.prepareStatement(searchSql.toString());
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next())
			{
				dateFound = false;
				success = true;
				scheduleFlights = new ArrayList();
				flightBean = new FlightBean();

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(1));
				referenceDataBean.setCodeId(resultSet.getString(2));
				referenceDataBean.setCodeValue(resultSet.getString(3));
				flightBean.setAirlineBean(referenceDataBean);

				flightBean.setFlightNumber(resultSet.getString(4));

				if (resultSet.getString(5).equals("D"))
					flightBean.setIsDeparture(true);
				else
					flightBean.setIsDeparture(false);

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(6));
				referenceDataBean.setCodeId(resultSet.getString(7));
				referenceDataBean.setCodeValue(resultSet.getString(8));
				flightBean.setOriginAirportBean(referenceDataBean);

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(9));
				referenceDataBean.setCodeId(resultSet.getString(10));
				referenceDataBean.setCodeValue(resultSet.getString(11));
				flightBean.setDestinationAirportBean(referenceDataBean);

				if (resultSet.getString(12).equals("1"))
				{
					flightBean.setFlightType(PaxTraxConstants.SCHEDULED);
				}
				else
				{
					flightBean.setFlightType(PaxTraxConstants.NON_SCHEDULED);
				}

				flightBean.setHrFlightCutOffTime(checkTimeList(resultSet.getString(13)));
				flightBean.setMinFlightCutOffTime(checkTimeList(resultSet.getString(14)));

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(15));
				referenceDataBean.setCodeId(resultSet.getString(16));
				referenceDataBean.setCodeValue(resultSet.getString(17));
				flightBean.setPickupLocationBean(referenceDataBean);
				/*Modified on 28th June 2006 -Starts 
							*SR 1042 International DF Sale */
				String international = resultSet.getString("INTERNATIONAL_FLAG");
				if("Y".equals(international))
					flightBean.setIsInternational(true);
				else
					flightBean.setIsInternational(false);
				/*Modified on 28th June 2006 -Ends 
							*SR 1042 International DF Sale */
							
				//added for CA#290863 by vignesh starts here
				String vessel_mode = resultSet.getString("VESSEL_FLAG");		
				if("Y".equals((vessel_mode)))
					flightBean.setIsVesselMode(true);
				else
					flightBean.setIsVesselMode(false);
				
				if(resultSet.getString("VESSEL_NAME") !=null)
				{
					flightBean.setVesselName(resultSet.getString("VESSEL_NAME"));
				}
				else
					flightBean.setVesselName(null);
				//added for CA#290863 by vignesh ends here		
																	
				if (resultSet.getString(12).equals("1"))
				{
					if (resultSet.getString(18) != null)
					{
						flightBean.setIsDailyCheckBox(true);
						flightBean.setDailyTimeInHr(checkTimeList(resultSet.getString(18)));
						flightBean.setDailyTimeInMin(checkTimeList(resultSet.getString(19)));
						scheduleFlights.add("daily");
					}
					else
					{
						flightBean.setIsDailyCheckBox(false);
						flightBean.setDailyTimeInHr(null);
						flightBean.setDailyTimeInMin(null);
					}
					if (resultSet.getString(20) != null)
					{
						flightBean.setIsSunCheckBox(true);
						flightBean.setSunTimeInHr(checkTimeList(resultSet.getString(20)));
						flightBean.setSunTimeInMin(checkTimeList(resultSet.getString(21)));
						scheduleFlights.add("sun");
					}
					else
					{
						flightBean.setIsSunCheckBox(false);
						flightBean.setSunTimeInHr(null);
						flightBean.setSunTimeInMin(null);
					}
					if (resultSet.getString(22) != null)
					{
						flightBean.setIsMonCheckBox(true);
						flightBean.setMonTimeInHr(checkTimeList(resultSet.getString(22)));
						flightBean.setMonTimeInMin(checkTimeList(resultSet.getString(23)));
						scheduleFlights.add("mon");
					}
					else
					{
						flightBean.setIsMonCheckBox(false);
						flightBean.setMonTimeInHr(null);
						flightBean.setMonTimeInMin(null);
					}
					if (resultSet.getString(24) != null)
					{
						flightBean.setIsTueCheckBox(true);
						flightBean.setTueTimeInHr(checkTimeList(resultSet.getString(24)));
						flightBean.setTueTimeInMin(checkTimeList(resultSet.getString(25)));
						scheduleFlights.add("tue");
					}
					else
					{
						flightBean.setIsTueCheckBox(false);
						flightBean.setTueTimeInHr(null);
						flightBean.setTueTimeInMin(null);
					}
					if (resultSet.getString(26) != null)
					{
						flightBean.setIsWedCheckBox(true);
						flightBean.setWedTimeInHr(checkTimeList(resultSet.getString(26)));
						flightBean.setWedTimeInMin(checkTimeList(resultSet.getString(27)));
						scheduleFlights.add("wed");
					}
					else
					{
						flightBean.setIsWedCheckBox(false);
						flightBean.setWedTimeInHr(null);
						flightBean.setWedTimeInMin(null);
					}
					if (resultSet.getString(28) != null)
					{
						flightBean.setIsThuCheckBox(true);
						flightBean.setThuTimeInHr(checkTimeList(resultSet.getString(28)));
						flightBean.setThuTimeInMin(checkTimeList(resultSet.getString(29)));
						scheduleFlights.add("thu");
					}
					else
					{
						flightBean.setIsThuCheckBox(false);
						flightBean.setThuTimeInHr(null);
						flightBean.setThuTimeInMin(null);
					}
					if (resultSet.getString(30) != null)
					{
						flightBean.setIsFriCheckBox(true);
						flightBean.setFriTimeInHr(checkTimeList(resultSet.getString(30)));
						flightBean.setFriTimeInMin(checkTimeList(resultSet.getString(31)));
						scheduleFlights.add("fri");
					}
					else
					{
						flightBean.setIsFriCheckBox(false);
						flightBean.setFriTimeInHr(null);
						flightBean.setFriTimeInMin(null);
					}
					if (resultSet.getString(32) != null)
					{
						flightBean.setIsSatCheckBox(true);
						flightBean.setSatTimeInHr(checkTimeList(resultSet.getString(32)));
						flightBean.setSatTimeInMin(checkTimeList(resultSet.getString(33)));
						scheduleFlights.add("sat");
					}
					else
					{
						flightBean.setIsSatCheckBox(false);
						flightBean.setSatTimeInHr(null);
						flightBean.setSatTimeInMin(null);
					}
					flightBean.setScheduleDetails(scheduleFlights);
					flightBean.setFlightDate(null);
					flightBean.setDateTimeInHr(null);
					flightBean.setDateTimeInMin(null);
					flightDetails.add(flightBean);
				}
				else
				{

					if (resultSet.getString(21) != null)
					{
						flightBean.setFlightDate(resultSet.getString(21).replace('-', '/'));
						flightBean.setOldFlightDate(resultSet.getString(21).replace('-', '/'));
						dateFound = true;
					}

					if (resultSet.getString(22) != null)
					{
						flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(22)));
						flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(23)));
						scheduleFlights.add(resultSet.getString(21).replace('-', '/'));
						dateFound = true;
					}

					if (resultSet.getString(18) != null && !dateFound)
					{
						flightBean.setFlightDate(resultSet.getString(18).replace('-', '/'));
						flightBean.setOldFlightDate(resultSet.getString(18).replace('-', '/'));
					}

					if (resultSet.getString(19) != null && !dateFound)
					{
						flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(19)));
						flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(20)));
						scheduleFlights.add(resultSet.getString(18).replace('-', '/'));
					}
					flightBean.setScheduleDetails(scheduleFlights);
					flightDetails.add(flightBean);
				}

			}
			if (!success)
			{
				throw new FlightException(PaxTraxConstants.NO_RECORDS_FOUND);
			}
		}
		catch (SQLException sq)
		{
			throw new PaxTraxSystemException(sq);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{

			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::getFlightDetails::End");
		return flightDetails;
	}

	private ArrayList getOverrideFlightDetails(FlightBean flightBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::getOverrideFlightDetails::Begin");
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		boolean dateEquals = false;
		ArrayList flightDetails = new ArrayList();
		String flightDate = flightBean.getFlightDate();
		Calendar dateCal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/mm/dd");
		dateFormat.setCalendar(dateCal);
		String systemDate = dateFormat.format(dateCal.getTime());
		String fdate = flightDate.replace('/', '-');
		StringTokenizer sdate = new StringTokenizer(flightDate, "/");
		if (flightDate.equals(systemDate))
			dateEquals = true;
		int year = Integer.parseInt((String) sdate.nextToken());
		int month = Integer.parseInt((String) sdate.nextToken());
		int date = Integer.parseInt((String) sdate.nextToken());

		dateCal.set(Calendar.MONTH, month - 1);
		dateCal.set(Calendar.DATE, date);
		dateCal.set(Calendar.YEAR, year);
		flightDetails = nonScheduledSearch(flightDetails, fdate, flightBean, connection);
		flightDetails = scheduledSearch(flightDetails, fdate, dateEquals, dateCal, flightBean, connection);
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::getOverrideFlightDetails::End");
		return flightDetails;

	}

	private ArrayList scheduledSearch(
		ArrayList flightDetails,
		String fdate,
		boolean dateEquals,
		Calendar dateCal,
		FlightBean flightBean,
		Connection connection)
		throws PaxTraxSystemException, FlightException
	{

		PaxTraxLog.logDebug("PaxTrax::FlightDAO::scheduledSearch::Begin");
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		boolean returnValue = false;
		boolean success = false;
		ArrayList scheduleFlights = null;
		ArrayList flightDetails1 = null;
		PreparedStatement preparedStatement = null;
		Statement statement = null;
		ReferenceDataBean referenceDataBean = null;
		boolean alreadyFound = false;
		referenceDataBean = flightBean.getAirlineBean();
		String airlineRefId = referenceDataBean.getReferenceId();
		String airlineCodeId = referenceDataBean.getCodeId();
		String flightNumber = flightBean.getFlightNumber();
		String flightType = null;
		boolean sundayTime = false;
		boolean mondayTime = false;
		boolean tuesdayTime = false;
		boolean wednesdayTime = false;
		boolean thursdayTime = false;
		boolean fridayTime = false;
		boolean saturdayTime = false;

		StringBuffer sqlCondition = new StringBuffer();
		sqlCondition.append("select fm.FLIGHT_AIRLINE_REF_ID,");
		sqlCondition.append(" fm.FLIGHT_AIRLINE_CODE_ID,");
		sqlCondition.append(" (select a.code_code_value from ");
		sqlCondition.append(" tb_code_ref a where fm.flight_airline_ref_id = ");
		sqlCondition.append(" a.ref_id and fm.flight_airline_code_id = ");
		sqlCondition.append(" a.code_code_id), fm.FLIGHT_FLIGHT_NUMBER,");
		sqlCondition.append(" fm.FLIGHT_TYPE,fm.FLIGHT_ORIGIN_AIRPORT_REF_ID,");
		sqlCondition.append(" fm.FLIGHT_CODE_ORIGIN_CODE_ID,");
		sqlCondition.append(" (select b.code_code_value from tb_code_ref b ");
		sqlCondition.append(" where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id");
		sqlCondition.append(" and fm.FLIGHT_CODE_ORIGIN_CODE_ID = ");
		sqlCondition.append(" b.code_code_id),fm.FLIGHT_DEST_AIRPORT_REF_ID, ");
		sqlCondition.append(" fm.FLIGHT_CODE_DEST_CODE_ID,(select ");
		sqlCondition.append(" c.code_code_value from tb_code_ref c where ");
		sqlCondition.append(" fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and ");
		sqlCondition.append(" fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id), ");
		sqlCondition.append(" fm.FLIGHT_FLIGHT_STATUS,hour(fm.FLIGHT_CUTOFF_TIME),");
		sqlCondition.append(" minute(fm.FLIGHT_CUTOFF_TIME), ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_REF_ID, ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID,(select ");
		sqlCondition.append(" d.code_code_value from tb_code_ref d where ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id),");
		sqlCondition.append(" hour(fm.FLIGHT_DAILY),minute(fm.FLIGHT_DAILY), ");
		sqlCondition.append(" hour(fm.FLIGHT_SUN),minute(fm.FLIGHT_SUN), ");
		sqlCondition.append(" hour(fm.FLIGHT_MON),minute(fm.FLIGHT_MON), ");
		sqlCondition.append(" hour(fm.FLIGHT_TUE),minute(fm.FLIGHT_TUE), ");
		sqlCondition.append(" hour(fm.FLIGHT_WED),minute(fm.FLIGHT_WED), ");
		sqlCondition.append(" hour(fm.FLIGHT_THU),minute(fm.FLIGHT_THU), ");
		sqlCondition.append(" hour(fm.FLIGHT_FRI),minute(fm.FLIGHT_FRI), ");
		sqlCondition.append(" hour(fm.FLIGHT_SAT),minute(fm.FLIGHT_SAT), ");
		sqlCondition.append(" (select fo.flight_cancelled from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("'),");
		sqlCondition.append(" (select fo.flight_original_date from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("'),");
		sqlCondition.append(" (select hour(fo.flight_original_time) from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("'),");
		sqlCondition.append(" (select minute(fo.flight_original_time) from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("'),");
		sqlCondition.append(" (select fo.flight_over_date from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("'),");
		sqlCondition.append(" (select hour(fo.flight_over_time) from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("'),");
		sqlCondition.append(" (select minute(fo.flight_over_time) from tb_flight_override fo");
		sqlCondition.append("  where fm.flight_airline_ref_id =");
		sqlCondition.append(" fo.flight_airline_ref_id and ");
		sqlCondition.append(" fm.flight_airline_code_id = fo.flight_airline_code_code_id");
		sqlCondition.append(" and fm.flight_flight_number = fo.flight_flight_number");
		sqlCondition.append(" and fm.flight_type = fo.flight_type ");
		sqlCondition.append(" and fo.flight_original_date = '");
		sqlCondition.append(fdate);
		sqlCondition.append("')");
		sqlCondition.append(" from tb_flight_mstr fm  where  ");
		sqlCondition.append(" fm.FLIGHT_FLIGHT_DELETED = 'N' and");
		sqlCondition.append(" fm.flight_flight_status = '1' and ");

		int day = dateCal.get(Calendar.DAY_OF_WEEK);
		if (day != 0)
			day = day - 1;
		switch (day)
		{
			case 0 :
				sundayTime = true;
				sqlCondition.append(" (fm.flight_sun is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_sun >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
			case 1 :
				mondayTime = true;
				sqlCondition.append(" (fm.flight_mon is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_mon >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
			case 2 :
				tuesdayTime = true;
				sqlCondition.append(" (fm.flight_tue is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_tue >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
			case 3 :
				wednesdayTime = true;
				sqlCondition.append(" (fm.flight_wed is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_wed >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
			case 4 :
				thursdayTime = true;
				sqlCondition.append(" (fm.flight_thu is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_thu >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
			case 5 :
				fridayTime = true;
				sqlCondition.append(" (fm.flight_fri is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_fri >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
			case 6 :
				saturdayTime = true;
				sqlCondition.append(" (fm.flight_sat is not null or fm.flight_daily is not null) ");
				if (dateEquals)
				{
					sqlCondition.append(" and (fm.flight_sat >= CURRENT TIME or fm.flight_daily >= CURRENT_TIME)");
				}
				break;
		}
		if (airlineCodeId != null && !airlineCodeId.equals("-1"))
		{
			sqlCondition.append(" and fm.FLIGHT_AIRLINE_REF_ID = '");
			sqlCondition.append(airlineRefId);
			sqlCondition.append("' and fm.FLIGHT_AIRLINE_CODE_ID = '");
			sqlCondition.append(airlineCodeId + "'");
		}
		if (flightNumber != null)
		{
			if (!flightNumber.trim().equals(""))
			{
				sqlCondition.append(" and fm.flight_flight_number like '%");
				sqlCondition.append(flightNumber);
				sqlCondition.append("%'");
			}
		}
		sqlCondition.append(" order by fm.FLIGHT_AIRLINE_REF_ID,");
		sqlCondition.append(" fm.flight_airline_code_id, ");
		sqlCondition.append(" fm.flight_flight_number, ");
		sqlCondition.append(" fm.FLIGHT_ORIGIN_AIRPORT_REF_ID ,");
		sqlCondition.append(" fm.FLIGHT_CODE_ORIGIN_CODE_ID ,");
		sqlCondition.append(" fm.FLIGHT_DEST_AIRPORT_REF_ID ,");
		sqlCondition.append(" fm.FLIGHT_CODE_DEST_CODE_ID ");

		try
		{
			preparedStatement = connection.prepareStatement(sqlCondition.toString());
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next())
			{

				flightBean = new FlightBean();

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(1));
				referenceDataBean.setCodeId(resultSet.getString(2));
				referenceDataBean.setCodeValue(resultSet.getString(3));
				flightBean.setAirlineBean(referenceDataBean);

				flightBean.setFlightNumber(resultSet.getString(4));

				if (resultSet.getString(5).equals("D"))
					flightBean.setIsDeparture(true);
				else
					flightBean.setIsDeparture(false);

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(6));
				referenceDataBean.setCodeId(resultSet.getString(7));
				referenceDataBean.setCodeValue(resultSet.getString(8));
				flightBean.setOriginAirportBean(referenceDataBean);

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(9));
				referenceDataBean.setCodeId(resultSet.getString(10));
				referenceDataBean.setCodeValue(resultSet.getString(11));
				flightBean.setDestinationAirportBean(referenceDataBean);

				if (resultSet.getString(12).equals("1"))
					flightBean.setFlightType(PaxTraxConstants.SCHEDULED);
				else
					flightBean.setFlightType(PaxTraxConstants.NON_SCHEDULED);

				flightBean.setHrFlightCutOffTime(checkTimeList(resultSet.getString(13)));
				flightBean.setMinFlightCutOffTime(checkTimeList(resultSet.getString(14)));

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(15));
				referenceDataBean.setCodeId(resultSet.getString(16));
				referenceDataBean.setCodeValue(resultSet.getString(17));
				flightBean.setPickupLocationBean(referenceDataBean);

				if (resultSet.getString(18) != null)
				{
					flightBean.setIsDailyCheckBox(true);
					flightBean.setDailyTimeInHr(checkTimeList(resultSet.getString(18)));
					flightBean.setDailyTimeInMin(checkTimeList(resultSet.getString(19)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(18)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(19)));
				}
				else
				{
					flightBean.setIsDailyCheckBox(false);
					flightBean.setDailyTimeInHr(null);
					flightBean.setDailyTimeInMin(null);
				}
				if (resultSet.getString(20) != null && sundayTime)
				{
					flightBean.setIsSunCheckBox(true);
					flightBean.setSunTimeInHr(checkTimeList(resultSet.getString(20)));
					flightBean.setSunTimeInMin(checkTimeList(resultSet.getString(21)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(20)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(21)));
				}
				else
				{
					flightBean.setIsSunCheckBox(false);
					flightBean.setSunTimeInHr(null);
					flightBean.setSunTimeInMin(null);
				}
				if (resultSet.getString(22) != null && mondayTime)
				{
					flightBean.setIsMonCheckBox(true);
					flightBean.setMonTimeInHr(checkTimeList(resultSet.getString(22)));
					flightBean.setMonTimeInMin(checkTimeList(resultSet.getString(23)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(22)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(23)));
				}
				else
				{
					flightBean.setIsMonCheckBox(false);
					flightBean.setMonTimeInHr(null);
					flightBean.setMonTimeInMin(null);
				}
				if (resultSet.getString(24) != null && tuesdayTime)
				{
					flightBean.setIsTueCheckBox(true);
					flightBean.setTueTimeInHr(checkTimeList(resultSet.getString(24)));
					flightBean.setTueTimeInMin(checkTimeList(resultSet.getString(25)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(24)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(25)));
				}
				else
				{
					flightBean.setIsTueCheckBox(false);
					flightBean.setTueTimeInHr(null);
					flightBean.setTueTimeInMin(null);
				}
				if (resultSet.getString(26) != null && wednesdayTime)
				{
					flightBean.setIsWedCheckBox(true);
					flightBean.setWedTimeInHr(checkTimeList(resultSet.getString(26)));
					flightBean.setWedTimeInMin(checkTimeList(resultSet.getString(27)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(26)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(27)));
				}
				else
				{
					flightBean.setIsWedCheckBox(false);
					flightBean.setWedTimeInHr(null);
					flightBean.setWedTimeInMin(null);
				}
				if (resultSet.getString(28) != null && thursdayTime)
				{
					flightBean.setIsThuCheckBox(true);
					flightBean.setThuTimeInHr(checkTimeList(resultSet.getString(28)));
					flightBean.setThuTimeInMin(checkTimeList(resultSet.getString(29)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(28)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(29)));
				}
				else
				{
					flightBean.setIsThuCheckBox(false);
					flightBean.setThuTimeInHr(null);
					flightBean.setThuTimeInMin(null);
				}
				if (resultSet.getString(30) != null && fridayTime)
				{
					flightBean.setIsFriCheckBox(true);
					flightBean.setFriTimeInHr(checkTimeList(resultSet.getString(30)));
					flightBean.setFriTimeInMin(checkTimeList(resultSet.getString(31)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(30)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(31)));
				}
				else
				{
					flightBean.setIsFriCheckBox(false);
					flightBean.setFriTimeInHr(null);
					flightBean.setFriTimeInMin(null);
				}
				if (resultSet.getString(32) != null && saturdayTime)
				{
					flightBean.setIsSatCheckBox(true);
					flightBean.setSatTimeInHr(checkTimeList(resultSet.getString(32)));
					flightBean.setSatTimeInMin(checkTimeList(resultSet.getString(33)));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(32)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(33)));
				}
				else
				{
					flightBean.setIsSatCheckBox(false);
					flightBean.setSatTimeInHr(null);
					flightBean.setSatTimeInMin(null);
				}
				if (resultSet.getString(34) != null)
				{
					if (resultSet.getString(34).equals("Y"))
					{
						flightBean.setIsFlightCancelled(true);
					}
					else
					{
						flightBean.setIsFlightCancelled(false);
					}
				}
				else
				{
					flightBean.setIsFlightCancelled(false);
				}
				if (resultSet.getString(35) != null)
				{
					flightBean.setFlightDate(resultSet.getString(35).replace('-', '/'));
					flightBean.setOldFlightDate(resultSet.getString(35).replace('-', '/'));
				}
				else
				{
					flightBean.setFlightDate(fdate.replace('-', '/'));
					flightBean.setOldFlightDate(fdate.replace('-', '/'));
				}
				if (resultSet.getString(36) != null)
				{
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(36)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(37)));
				}
				if (resultSet.getString(38) != null)
				{
					flightBean.setFlightOverrideDate(resultSet.getString(38).replace('-', '/'));
				}
				else
				{
					flightBean.setFlightOverrideDate(PaxTraxConstants.FALSE);
				}
				if (resultSet.getString(39) != null)
				{
					flightBean.setOverrideDateTimeInHr(checkTimeList(resultSet.getString(39)));
					flightBean.setOverrideDateTimeInMin(checkTimeList(resultSet.getString(40)));
				}
				else
				{
					flightBean.setOverrideDateTimeInHr(PaxTraxConstants.FALSE);
					flightBean.setOverrideDateTimeInMin(PaxTraxConstants.FALSE);
				}
				flightDetails.add(flightBean);
			}
			flightDetails1 = flightDetails;
			String flightType1 = "";
			if (flightDetails != null && !flightDetails.isEmpty())
			{
				statement = connection.createStatement();
				sqlCondition = new StringBuffer();
				sqlCondition.append("select distinct(flight_airline_code_id),");
				sqlCondition.append(" flight_airline_ref_id,flight_flight_number ");
				sqlCondition.append(" from tb_naccs_file_hdr where ");
				sqlCondition.append(" naccs_departure_date = '");
				sqlCondition.append(fdate);
				sqlCondition.append("'");
				resultSet1 = statement.executeQuery(sqlCondition.toString());
				while (resultSet1.next())
				{
					//Commented on July 16, 2005 to avoid the "Index Out Of Bounds" exception
					//int flightDetailsSize1 = flightDetails.size();
					for (int i = 0; i < flightDetails.size(); i++)
					{
						flightBean = (FlightBean) flightDetails.get(i);
						String codeId = flightBean.getAirlineBean().getCodeId();
						String refId = flightBean.getAirlineBean().getReferenceId();
						String flightNumber1 = flightBean.getFlightNumber();
						if (flightBean.getIsDeparture())
							flightType1 = "D";
						if (codeId.equals(resultSet1.getString(1))
							&& refId.equals(resultSet1.getString(2))
							&& flightNumber1.equals(resultSet1.getString(3))
							&& flightType1.equals("D"))
						{
							flightDetails1.remove(i);
							i--;
						}
					}

				}
			}
			if (flightDetails != null && flightDetails.isEmpty())
			{
				throw new FlightException(PaxTraxConstants.NO_RECORDS_FOUND);
			}

		}
		catch (SQLException sqle)
		{
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (resultSet1 != null)
				{
					resultSet1.close();
					resultSet1 = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::scheduledSearch::End");
		return flightDetails1;
	}

	private ArrayList nonScheduledSearch(ArrayList flightDetails, String sDate, FlightBean flightBean, Connection connection)
		throws PaxTraxSystemException, FlightException
	{

		PaxTraxLog.logDebug("PaxTrax::FlightDAO::nonScheduledSearch::Begin");
		ResultSet resultSet = null;
		ArrayList flightDetails1 = null;
		boolean returnValue = false;
		boolean success = false;
		boolean timeSelected = false;
		PreparedStatement preparedStatement = null;
		Statement statement = null;
		ResultSet resultSet1 = null;
		ReferenceDataBean referenceDataBean = null;
		referenceDataBean = flightBean.getAirlineBean();
		String airlineRefId = referenceDataBean.getReferenceId();
		String airlineCodeId = referenceDataBean.getCodeId();
		String flightNumber = flightBean.getFlightNumber();
		StringBuffer sqlCondition = new StringBuffer();

		sqlCondition.append("select fm.FLIGHT_AIRLINE_REF_ID,");
		sqlCondition.append(" fm.FLIGHT_AIRLINE_CODE_ID,");
		sqlCondition.append(" (select a.code_code_value from ");
		sqlCondition.append(" tb_code_ref a where fm.flight_airline_ref_id = ");
		sqlCondition.append(" a.ref_id and fm.flight_airline_code_id = ");
		sqlCondition.append(" a.code_code_id), fm.FLIGHT_FLIGHT_NUMBER,");
		sqlCondition.append(" fm.FLIGHT_TYPE,fm.FLIGHT_ORIGIN_AIRPORT_REF_ID,");
		sqlCondition.append(" fm.FLIGHT_CODE_ORIGIN_CODE_ID,");
		sqlCondition.append(" (select b.code_code_value from tb_code_ref b ");
		sqlCondition.append(" where fm.FLIGHT_ORIGIN_AIRPORT_REF_ID = b.ref_id");
		sqlCondition.append(" and fm.FLIGHT_CODE_ORIGIN_CODE_ID = ");
		sqlCondition.append(" b.code_code_id),fm.FLIGHT_DEST_AIRPORT_REF_ID, ");
		sqlCondition.append(" fm.FLIGHT_CODE_DEST_CODE_ID,(select ");
		sqlCondition.append(" c.code_code_value from tb_code_ref c where ");
		sqlCondition.append(" fm.FLIGHT_DEST_AIRPORT_REF_ID = c.ref_id and ");
		sqlCondition.append(" fm.FLIGHT_CODE_DEST_CODE_ID = c.code_code_id), ");
		sqlCondition.append(" fm.FLIGHT_FLIGHT_STATUS,hour(fm.FLIGHT_CUTOFF_TIME),");
		sqlCondition.append(" minute(fm.FLIGHT_CUTOFF_TIME), ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_REF_ID, ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID,(select ");
		sqlCondition.append(" d.code_code_value from tb_code_ref d where ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_REF_ID = d.ref_id and ");
		sqlCondition.append(" fm.FLIGHT_PICKUP_LOC_CODE_CODE_ID = d.code_code_id),");
		sqlCondition.append(" fo.flight_OVER_DATE,hour(fo.flight_OVER_TIME), ");
		sqlCondition.append(" minute(fo.flight_over_time), ");
		sqlCondition.append(" fo.flight_ORIGINAL_DATE, hour(fo.flight_ORIGINAL_TIME),");
		sqlCondition.append(" minute(fo.flight_original_time), ");
		sqlCondition.append(" fo.flight_cancelled from ");
		sqlCondition.append(" tb_flight_mstr fm,tb_flight_override fo  ");
		sqlCondition.append(" where  fm.FLIGHT_FLIGHT_DELETED = 'N' and ");
		sqlCondition.append(" fo.flight_original_date = '");
		sqlCondition.append(sDate);
		sqlCondition.append("' and fm.flight_flight_status = '2' ");
		sqlCondition.append(" and fo.flight_airline_ref_id = ");
		sqlCondition.append(" fm.flight_airline_ref_id and ");
		sqlCondition.append(" fo.flight_airline_code_code_id = ");
		sqlCondition.append(" fm.flight_airline_code_id  and  ");
		sqlCondition.append(" fo.flight_flight_number = ");
		sqlCondition.append(" fm.flight_flight_number and  ");
		sqlCondition.append(" fo.flight_type = fm.flight_type ");

		if (airlineCodeId != null && !airlineCodeId.equals("-1"))
		{
			sqlCondition.append(" and fo.FLIGHT_AIRLINE_REF_ID = '");
			sqlCondition.append(airlineRefId);
			sqlCondition.append("' and fo.FLIGHT_AIRLINE_CODE_CODE_ID = '");
			sqlCondition.append(airlineCodeId);
			sqlCondition.append("'");
		}

		if (flightNumber != null)
		{
			if (!flightNumber.trim().equals(""))
			{
				sqlCondition.append(" and fo.flight_flight_number like '%");
				sqlCondition.append(flightNumber.trim());
				sqlCondition.append("%' and fm.flight_flight_number like '%");
				sqlCondition.append(flightNumber.trim());
				sqlCondition.append("%'");
			}
		}
		sqlCondition.append(" order by fm.FLIGHT_AIRLINE_REF_ID,");
		sqlCondition.append(" fm.flight_airline_code_id, ");
		sqlCondition.append(" fm.flight_flight_number, ");
		sqlCondition.append(" fm.FLIGHT_ORIGIN_AIRPORT_REF_ID ,");
		sqlCondition.append(" fm.FLIGHT_CODE_ORIGIN_CODE_ID ,");
		sqlCondition.append(" fm.FLIGHT_DEST_AIRPORT_REF_ID ,");
		sqlCondition.append(" fm.FLIGHT_CODE_DEST_CODE_ID ");

		try
		{

			preparedStatement = connection.prepareStatement(sqlCondition.toString());
			PaxTraxLog.logDebug("PaxTrax::FlightDAO::nonScheduledSearch::query::"+sqlCondition.toString());
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next())
			{
				timeSelected = false;
				flightBean = new FlightBean();

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(1));
				referenceDataBean.setCodeId(resultSet.getString(2));
				referenceDataBean.setCodeValue(resultSet.getString(3));
				flightBean.setAirlineBean(referenceDataBean);

				flightBean.setFlightNumber(resultSet.getString(4));

				if (resultSet.getString(5).equals("D"))
					flightBean.setIsDeparture(true);
				else
					flightBean.setIsDeparture(false);

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(6));
				referenceDataBean.setCodeId(resultSet.getString(7));
				referenceDataBean.setCodeValue(resultSet.getString(8));
				flightBean.setOriginAirportBean(referenceDataBean);

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(9));
				referenceDataBean.setCodeId(resultSet.getString(10));
				referenceDataBean.setCodeValue(resultSet.getString(11));
				flightBean.setDestinationAirportBean(referenceDataBean);

				if (resultSet.getString(12).equals("1"))
					flightBean.setFlightType(PaxTraxConstants.SCHEDULED);
				else
					flightBean.setFlightType(PaxTraxConstants.NON_SCHEDULED);

				flightBean.setHrFlightCutOffTime(checkTimeList(resultSet.getString(13)));
				flightBean.setMinFlightCutOffTime(checkTimeList(resultSet.getString(14)));

				referenceDataBean = new ReferenceDataBean();
				referenceDataBean.setReferenceId(resultSet.getString(15));
				referenceDataBean.setCodeId(resultSet.getString(16));
				referenceDataBean.setCodeValue(resultSet.getString(17));
				flightBean.setPickupLocationBean(referenceDataBean);

				if (resultSet.getString(18) != null)
				{
					flightBean.setFlightOverrideDate(resultSet.getString(18).replace('-', '/'));
					flightBean.setOverrideDateTimeInHr(checkTimeList(resultSet.getString(19)));
					flightBean.setOverrideDateTimeInMin(checkTimeList(resultSet.getString(20)));
				}
				else
				{

					flightBean.setFlightOverrideDate(PaxTraxConstants.FALSE);
					flightBean.setOverrideDateTimeInHr(PaxTraxConstants.FALSE);
					flightBean.setOverrideDateTimeInMin(PaxTraxConstants.FALSE);
				}

				if (resultSet.getString(21) != null)
				{
					flightBean.setFlightDate(resultSet.getString(21).replace('-', '/'));
					flightBean.setOldFlightDate(resultSet.getString(21).replace('-', '/'));
					flightBean.setDateTimeInHr(checkTimeList(resultSet.getString(22)));
					flightBean.setDateTimeInMin(checkTimeList(resultSet.getString(23)));
				}
				else
				{
					flightBean.setFlightDate(PaxTraxConstants.FALSE);
					flightBean.setDateTimeInHr(PaxTraxConstants.FALSE);
					flightBean.setDateTimeInMin(PaxTraxConstants.FALSE);
				}
				if (resultSet.getString(24) != null && resultSet.getString(24).equals("Y"))
					flightBean.setIsFlightCancelled(true);
				else
					flightBean.setIsFlightCancelled(false);

				flightDetails.add(flightBean);
			}
			flightDetails1 = flightDetails;
			String flightType1 = "";
			if (flightDetails != null && !flightDetails.isEmpty())
			{
				statement = connection.createStatement();
				sqlCondition = new StringBuffer();
				sqlCondition.append("select distinct(flight_airline_code_id),");
				sqlCondition.append(" flight_airline_ref_id,flight_flight_number ");
				sqlCondition.append(" from tb_naccs_file_hdr where ");
				sqlCondition.append(" naccs_departure_date = '");
				sqlCondition.append(sDate);
				sqlCondition.append("'");
				resultSet1 = statement.executeQuery(sqlCondition.toString());
				while (resultSet1.next())
				{
					//Commented on July 16, 2005 to correct the "Index Out Of Bounds" exception
					//int flightDetailsSize = flightDetails.size();
					for (int i = 0; i < flightDetails.size(); i++)
					{
						flightBean = (FlightBean) flightDetails.get(i);
						String codeId = flightBean.getAirlineBean().getCodeId();
						String refId = flightBean.getAirlineBean().getReferenceId();
						String flightNumber1 = flightBean.getFlightNumber();
						if (flightBean.getIsDeparture())
							flightType1 = "D";
						if (codeId.equals(resultSet1.getString(1))
							&& refId.equals(resultSet1.getString(2))
							&& flightNumber1.equals(resultSet1.getString(3))
							&& flightType1.equals("D"))
						{
							flightDetails1.remove(i);
							i--;
						}
					}

				}
			}

		}
		catch (SQLException sq)
		{
			throw new PaxTraxSystemException(sq);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (resultSet1 != null)
				{
					resultSet1.close();
					resultSet1 = null;
				}
			}
			catch (SQLException sqle)
			{

			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::nonScheduledSearch::End");
		return flightDetails1;
	}

	/**
	 * This method gets the time parameters and checks for length of the time and appends zero
	 */
	private String checkTimeList(String value)
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkTimeList::Begin");
		String temp = null;
		if (value != null)
		{
			if (Integer.parseInt(value) < 10)
			{
				temp = "0" + value;
			}
			else
			{
				temp = value;
			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkTimeList::End");
		return temp;
	}
	
/**
 * This method is used to whether Naccs is generated for the flight
 * @param flightBean
 * @throws PaxTraxSystemException
 * @throws FlightException
 */
// Added on July 28, 2007 for CR 250 changes -- Begin	

	public void checkNaccsStatus(FlightBean flightBean) throws PaxTraxSystemException,FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::Begin");
		Connection con = null;
		DBUtil dBUtil = DBUtil.getInstance();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSet resultSet = null;
		String status = null;
		int count = 0;
		StringBuffer sbuffer = null;
		
		try
		{
			con = dBUtil.getConnection();

			ReferenceDataBean referenceBean = (ReferenceDataBean) flightBean.getAirlineBean();
			String codeId = referenceBean.getCodeId();
			String refId = referenceBean.getReferenceId();
			flightBean.setFlightDate(flightBean.getFlightDate().replace('/','-'));
			PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::flightDate::"+flightBean.getFlightDate());			
			sbuffer = new StringBuffer(SQLConstants.GET_FLIGHT_NACCS_STATUS);
			sbuffer.append(" AND FLIGHT_DEPARTURE_DATE= '"+flightBean.getFlightDate()+"'");
			
			pstmt = con.prepareStatement(sbuffer.toString());

			PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::flightRefId::"+refId);
			pstmt.setString(1,refId);
			PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::flightCodeId::"+codeId);
			pstmt.setString(2,codeId);
			PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::flightNumber::"+flightBean.getFlightNumber());
			pstmt.setString(3,flightBean.getFlightNumber());			

			PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::query::"+sbuffer.toString());
			rs = pstmt.executeQuery();
			if(rs.next()) 
			{
				status = rs.getString(1);
			}
			rs.close();
			PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::Naccs file status::"+status);
			if(status!=null && status.equals(PaxTraxConstants.IN_PROGRESS))
			{
				throw new FlightException(PaxTraxConstants.NACCS_IN_PROGRESS);
			}
			else
			{
				pstmt.clearParameters();
				PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::inside second loop");
				sbuffer = new StringBuffer(SQLConstants.CHECK_NACCS_GENERATED);
				sbuffer.append(" and naccs_departure_date = '"+flightBean.getFlightDate()+"' ");				
				pstmt = con.prepareStatement(sbuffer.toString());
				pstmt.setString(1,refId);
				pstmt.setString(2,codeId);
				pstmt.setString(3,flightBean.getFlightNumber());
				PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::checkquery::"+sbuffer.toString());				
				resultSet = pstmt.executeQuery();				
				
				if(resultSet.next())
				{
					count = resultSet.getInt(1);
				}
				PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::count"+count);
				if(count>0)
				{
					throw new FlightException(PaxTraxConstants.NACCS_FILE_GENERATED);
				}
			}
		}
		catch(SQLException sqle)
		{
			PaxTraxLog.logError("PaxTrax::FlightDAO::checkNaccsStatus::sqlexception"+sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if(rs != null)
				{
					rs.close();
					rs = null;
				}
				if(resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}	
							
				if(pstmt != null)
				{
					pstmt.close();
					pstmt = null;
				}
				if(con != null)
				{
					con.close();
					con = null;
				}				
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("PaxTrax::FlightDAO::checkNaccsStatus::Error closing connection"+sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::FlightDAO::checkNaccsStatus::End");
	}
	
//	Added on July 28, 2007 for CR 250 changes -- End	
}
