package com.dfs.paxtrax.admin.business;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.rmi.RemoteException;
import java.util.ArrayList;
import javax.ejb.EJBObject;
import com.dfs.paxtrax.admin.exception.LocationException;
import com.dfs.paxtrax.admin.valueobject.LocationBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
/**
*Remote interface for Enterprise Bean: LocationBO
*
* @author Cognizant Technology Solutions
* contact Cognizant - Sankaranarayanan srinivasan
* 			DFS - Buensalida Sheila
* 
* @version    1.0
* 
* MOD HISTORY
* DATE 		USER 			COMMENTS
* 12/04/2004	Joseph Oommen A	Created   
*/
public interface LocationBO extends EJBObject
{
	/**
	 * Saves location details by invoking BO method.
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving location details
	 */
	public void saveLocationDetails(LocationBean locationBean)
		throws RemoteException, PaxTraxSystemException, LocationException;
	/**
	 * Removes location details by invoking BO method.
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in removing location details
	 */
	public void removeLocationDetails(LocationBean locationBean)
		throws RemoteException, PaxTraxSystemException, LocationException;
	/**
	 * Updates location details by invoking BO method.
	 * @param locationBean LocationBean object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in updating location details
	 */
	public void updateLocationDetails(LocationBean locationBean)
		throws RemoteException, PaxTraxSystemException, LocationException;
	/**
	 * Returns location list for the given search criteria by invoking BO method.
	 * @param locationBean LocationBean object
	 * @return ArrayList List of location details
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in updating location details
	 */
	public ArrayList searchLocationDetails(LocationBean locationBean)
		throws RemoteException, PaxTraxSystemException;
	/**
	 * Returns location Bean for the given search criteria by invoking BO method.
	 * @param location int
	 * @return locationBean LocationBean Object
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in search
	 */
	public LocationBean loadLocationDetails(String location)
		throws RemoteException, PaxTraxSystemException, LocationException;

	/**
	 * Method getAvailableLocations.
	 * @return ArrayList
	 */
	public String[] getAvailableLocations() 
		throws PaxTraxSystemException,RemoteException;

	/**
	 * Method saveLogicalLocation.
	 * @param locationBean
	 */
	public void saveLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException,LocationException,RemoteException;

	/**
	 * Method getLogicalLocation.
	 * @param locationBean
	 * @return LocationBean
	 */
	public LocationBean getLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException,LocationException,RemoteException;

	/**
	 * Method searchLogicalLocationDetails.
	 * @return ArrayList
	 */
	public ArrayList searchLogicalLocationDetails() 
		throws PaxTraxSystemException,RemoteException;

	/**
	 * Method updateLogicalLocation.
	 * @param locationBean
	 */
	public void updateLogicalLocation(LocationBean locationBean)
		throws PaxTraxSystemException,RemoteException;

	/**
	 * Method removeLogicalLocationDetails.
	 * @param locationBean
	 */
	public void removeLogicalLocationDetails(LocationBean locationBean)
		throws PaxTraxSystemException,RemoteException;

}
