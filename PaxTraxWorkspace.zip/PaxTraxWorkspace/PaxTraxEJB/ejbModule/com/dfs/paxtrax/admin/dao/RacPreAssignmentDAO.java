package com.dfs.paxtrax.admin.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.exception.RacPreAssignmentException;
import com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxErrorMessages;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

public class RacPreAssignmentDAO {
	
	//This contains the instance of UserDAO class 
	private static RacPreAssignmentDAO racPreAssignmentDAO = null;

	//Holds dbUtil
	DBUtil dbUtil = null;

	/**
	 * Creates an instance of RacPreAssignmentDAO only if the instance does not
	 * exist.
	 * 
	 * @return RacPreAssignmentDAO Returns the RacPreAssignmentDAO instance
	 */
	public static RacPreAssignmentDAO getInstance()
	{
		if (racPreAssignmentDAO == null)
		{
			initializeInstance();
		}
		return racPreAssignmentDAO;
	}

	/**
	 * Sets the RacPreAssignmentDAO class instance
	 */
	private static synchronized void initializeInstance()
	{
		if (racPreAssignmentDAO == null)
		{
			racPreAssignmentDAO = new RacPreAssignmentDAO();
		}
	}
	
	/**
	 * Loads the RacCode List.
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList loadRacCodes() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::racPreAssignmentDAO::loadReferenceType::Begin");
		ArrayList racCodes = null;
		ReferenceDataBean referenceDataBean = null;

		dbUtil = DBUtil.getInstance();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try
		{
			connection = dbUtil.getConnection(PaxTraxConstants.DB_SOURCE_CARTRAX);
			
			
			String sql = "select PATR_COMPANY_CODE,PATR_COMPANY_DESC from TB_PATR_COMPANY_MSTR where"+
						  " PATR_TYPE_ENTITY_ID = 9 AND PATR_TYPE_STATUS_ID = 1"+
						  " AND PATR_ENTITY_ID = 4 AND PATR_STATUS_ID = 1 "+
						  " ORDER BY PATR_COMPANY_DESC,PATR_COMPANY_CODE";
			
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs != null)
			{
				racCodes = new ArrayList();
				while (rs.next())
				{
					String racCode = rs.getString(1);
					String racName = rs.getString(2);
					referenceDataBean = new ReferenceDataBean();
					referenceDataBean.setCodeId(racCode);
					referenceDataBean.setCodeValue(racName);
					referenceDataBean.setDisplayLabel(racName+"-"+racCode);
					racCodes.add(referenceDataBean);
				}
			}
			
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				throw new PaxTraxSystemException(sqle);
			}
		}

		PaxTraxLog.logDebug("PaxTrax::racPreAssignmentDAO::loadReferenceType::End");
		return racCodes;

	}


	//Added for CR1859
	/**
	 * Populates remarks
	 * @return Srtring
	 * @throws PaxTraxSystemException
	 */
	public String getRemarksFromDB(String racCode, String startPaxNo, String endPaxNo)  throws PaxTraxSystemException
	{
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		String remarks = null;
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::getRemarksFromDB::Start");
		try {
				connection = DBUtil.getInstance().getConnection();
				statement = connection.createStatement();
				sql.append("select remarks from tb_rac_preassignment_mstr where rac_active='Y'");
				if (racCode != null && racCode.length() > 0 && startPaxNo != null && startPaxNo.length() > 0 && endPaxNo != null && endPaxNo.length() > 0 ) {
					sql.append(" and rac_company_code like '");
					sql.append(racCode);
					sql.append("%'");
					sql.append(" and start_pax_no like '");
					sql.append(startPaxNo);
					sql.append("'");
					sql.append(" and end_pax_no like '");
					sql.append(endPaxNo);
					sql.append("'");
				}
								
				rs = statement.executeQuery(sql.toString());
				if (rs != null) {
					rs.next();
					remarks=rs.getString(1);
				} 
				else 
				{
					remarks="";
				}				
			} 
		catch (SQLException sqle) {
				PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::getRemarksFromDB::SQL Exception ", sqle);
				throw new PaxTraxSystemException(sqle);
		} 
		finally {
				try {
					if (rs != null) {
						rs.close();
						rs = null;
					}
					if (statement != null) {
						statement.close();
						statement = null;
					}
					if (connection != null) {
						connection.close();
						connection = null;
					}
				} catch (SQLException sqle) {
					PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::getRemarksFromDB::Error releasing database resources ", sqle);
				}
		}
		return remarks;

	}
/**
 * Creates a RacPreAssignment.
 * @param racPreAssignmentBean
 * @throws RacPreAssignmentException
 * @throws PaxTraxSystemException
 */
public void createRacPreAssignment(RacPreAssignmentBean racPreAssignmentBean) 
throws RacPreAssignmentException,PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::racPreAssignmentDAO::loadReferenceType::Begin");
			Connection connection = null;
		CallableStatement createCall = null;
		//Modified the parameters passed to the procedure for CR1859
		String CALL_RAC_PRE_ASSIGNMENT_PROC = "{ CALL ADM_RAC_PRE_ASSIGNMENT(?,?,?,?,?,?,?,?,?,?,?,?,?) }";		
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::createRacPreAssignment::Start");
		
		
		try {
			connection = DBUtil.getInstance().getConnection();
			createCall = connection.prepareCall(CALL_RAC_PRE_ASSIGNMENT_PROC);
			createCall.setInt(1,1);
			createCall.setString(2, racPreAssignmentBean.getRacCode());
			createCall.setString(3,racPreAssignmentBean.getRemarks());
			createCall.setLong(4, 0);
			createCall.setLong(5, 0);
			createCall.setLong(6, Long.parseLong(racPreAssignmentBean.getStartPaxNumber()));
			createCall.setLong(7, Long.parseLong(racPreAssignmentBean.getEndPaxNumber()));
			createCall.setString(8, null);//start pax LAST VALUE
			createCall.setString(9, null);//end pax LAST VALUE
			createCall.setString(10, racPreAssignmentBean.getStartPaxNumber());//start pax  value
			createCall.setString(11, racPreAssignmentBean.getEndPaxNumber());//end pax  value
			createCall.setString(12, racPreAssignmentBean.getUser());
			createCall.registerOutParameter(13, java.sql.Types.INTEGER);
			createCall.execute();
			int errorCode = createCall.getInt(13);
			if (errorCode != 0) {
				throw new RacPreAssignmentException(errorCode);
			}
		} catch (SQLException sqle) {
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::createRacPreAssignment::SQL Exception ", sqle);
			throw new PaxTraxSystemException(sqle);
		} finally {
			try {
				if (createCall != null) {
					createCall.close();
					createCall = null;
				}
				if (connection != null) {
					connection.close();
					connection = null;
				}
			} catch (SQLException sqle) {
				PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::createRacPreAssignment::Error releasing database resources", sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::createRacPreAssignment::End");
		
	

	}
	
	/**
	 * Returns a list of rac preassignment beans containing rac preassignment
	 * information
	 * @param racPreAssignmentBean rac preassignment bean containing rac code as
	 * 		   search criteria
	 * @return ArrayList list of rac preassignment beans
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList searchRacPreAssignment(String racCode) 
	throws PaxTraxSystemException {
		Connection connection = null;
		Statement statement = null;
		ResultSet rs = null;
		ArrayList racPreAssignmentList = null;
		StringBuffer sql = new StringBuffer();
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::searchRacPreAssignment::Start");
		try {
			connection = DBUtil.getInstance().getConnection();
			statement = connection.createStatement();
			racPreAssignmentList = new ArrayList();
			sql.append(SQLConstants.SELECT_RAC_PREASSIGNMENT);
			if (racCode != null && racCode.length() > 0) {
				sql.append(" and rac_company_code like '");
				sql.append(racCode);
				sql.append("%'");
			}
			sql.append(" order by rac_company_code");
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::searchRacPreAssignment::sql is "+sql);
			rs = statement.executeQuery(sql.toString());
			while (rs.next()) {
				RacPreAssignmentBean preAssignmentBean = new RacPreAssignmentBean();
				preAssignmentBean.setRacCode(rs.getString(1));
				preAssignmentBean.setStartPaxNumber(rs.getString(2));
				preAssignmentBean.setEndPaxNumber(rs.getString(3));
				//Added Remarks for CR1859
				preAssignmentBean.setRemarks(rs.getString(4));
				racPreAssignmentList.add(preAssignmentBean);
			}

		} catch (SQLException sqle) {
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::searchRacPreAssignment::SQL Exception ", sqle);
			throw new PaxTraxSystemException(sqle);
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (statement != null) {
					statement.close();
					statement = null;
				}
				if (connection != null) {
					connection.close();
					connection = null;
				}
			} catch (SQLException sqle) {
				PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::searchRacPreAssignment::Error releasing database resources ", sqle);
			}
		}
		return racPreAssignmentList;
	}
	
	/**
	 * Modifies a Rac Pre-assignment given a existing Rac Pre-assignment.
	 * @param racBean existing Rac Pre-assignment bean
	 * @param updateRacBean new Rac Pre-assignment bean
	 * @throws RacPreAssignmentException thrown on invalid Rac Pre-assignments
	 * @throws PaxTraxSystemException thrown on error
	 */
	public void modifyRacPreAssignment(RacPreAssignmentBean racBean, RacPreAssignmentBean updateRacBean) 
	throws RacPreAssignmentException, PaxTraxSystemException {
		Connection connection = null;
		CallableStatement modifyCall = null;
		//Modified the parameters passed to the procedure for CR1859
		String CALL_RAC_PRE_ASSIGNMENT_PROC = "{ CALL ADM_RAC_PRE_ASSIGNMENT(?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::modifyRacPreAssignment::Start");
		try {
			connection = DBUtil.getInstance().getConnection();
			modifyCall = connection.prepareCall(CALL_RAC_PRE_ASSIGNMENT_PROC);
			modifyCall.setInt(1, 2);
			modifyCall.setString(2, updateRacBean.getRacCode());
			modifyCall.setString(3, updateRacBean.getRemarks());
			modifyCall.setLong(4, Long.parseLong(racBean.getStartPaxNumber()));//start pax LAST VALUE
			modifyCall.setLong(5, Long.parseLong(racBean.getEndPaxNumber()));//end pax LAST VALUE
			modifyCall.setLong(6, Long.parseLong(updateRacBean.getStartPaxNumber()));//start pax new value
			modifyCall.setLong(7, Long.parseLong(updateRacBean.getEndPaxNumber()));//end pax new value
			modifyCall.setString(8, racBean.getStartPaxNumber());//start pax LAST VALUE
			modifyCall.setString(9, racBean.getEndPaxNumber());//end pax LAST VALUE
			modifyCall.setString(10, updateRacBean.getStartPaxNumber());//start pax new value
			modifyCall.setString(11, updateRacBean.getEndPaxNumber());//end pax new value
			modifyCall.setString(12, updateRacBean.getUser());
			modifyCall.registerOutParameter(13, java.sql.Types.INTEGER);
			modifyCall.execute();
			int errorCode = modifyCall.getInt(13);
			if (errorCode != 0) {
				throw new RacPreAssignmentException(PaxTraxErrorMessages.INVALID_PAX_RANGE);
			}
		} catch (SQLException sqle) {
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::modifyRacPreAssignment::SQL Exception ", sqle);
			throw new PaxTraxSystemException(sqle);
		} finally {
			try {
				if (modifyCall != null) {
					modifyCall.close();
					modifyCall = null;
				}
				if (connection != null) {
					connection.close();
					connection = null;
				}
			} catch (SQLException sqle) {
				PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::modifyRacPreAssignment::Error releasing database resources", sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::modifyRacPreAssignment::End");
	}
	
	/**
	 * Modifies a Rac Pre-assignment given a existing Rac Pre-assignment.
	 * @param racBean existing Rac Pre-assignment bean
	 * @param updateRacBean new Rac Pre-assignment bean
	 * @throws RacPreAssignmentException thrown on invalid Rac Pre-assignments
	 * @throws PaxTraxSystemException thrown on error
	 */
	public void deleteRacPreAssignment(RacPreAssignmentBean racBean) 
	throws RacPreAssignmentException, PaxTraxSystemException {
		Connection connection = null;
		CallableStatement modifyCall = null;
		//Modified the parameters passed to the procedure for CR1859
		String CALL_RAC_PRE_ASSIGNMENT_PROC = "{ CALL ADM_RAC_PRE_ASSIGNMENT(?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::deleteRacPreAssignment::Start");
		try {
			connection = DBUtil.getInstance().getConnection();
			modifyCall = connection.prepareCall(CALL_RAC_PRE_ASSIGNMENT_PROC);
			modifyCall.setInt(1, 3);
			modifyCall.setString(2, racBean.getRacCode());
			modifyCall.setString(3, racBean.getRemarks());
			modifyCall.setLong(4, 0);
			modifyCall.setLong(5, 0);
			modifyCall.setLong(6, 0);
			modifyCall.setLong(7, 0);
			modifyCall.setString(8, null);//start pax LAST VALUE
			modifyCall.setString(9, null);//end pax LAST VALUE
			modifyCall.setString(10, racBean.getStartPaxNumber());//start pax  value
			modifyCall.setString(11, racBean.getEndPaxNumber());//end pax  value
			modifyCall.setString(12, racBean.getUser());
			modifyCall.registerOutParameter(13, java.sql.Types.INTEGER);
			modifyCall.execute();
			int errorCode = modifyCall.getInt(13);
			if (errorCode != 0) {
				throw new RacPreAssignmentException(errorCode);
			}
		} catch (SQLException sqle) {
			PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::deleteRacPreAssignment::SQL Exception ", sqle);
			throw new PaxTraxSystemException(sqle);
		} finally {
			try {
				if (modifyCall != null) {
					modifyCall.close();
					modifyCall = null;
				}
				if (connection != null) {
					connection.close();
					connection = null;
				}
			} catch (SQLException sqle) {
				PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::deleteRacPreAssignment::Error releasing database resources", sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::RacPreAssignmentDAO::deleteRacPreAssignment::End");
	}

}
