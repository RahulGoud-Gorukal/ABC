package com.dfs.paxtrax.admin.business;

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean;
import com.dfs.paxtrax.admin.exception.RacPreAssignmentException;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;

/**
 * Remote interface for Enterprise Bean: RacPreAssignmentBO
 */
public interface RacPreAssignmentBO extends javax.ejb.EJBObject {
	
	/**
	 * Loads the list of RacCodes.
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList loadRacCodes()
		throws RemoteException, PaxTraxSystemException;
		
	//Added for CR1859
	/**
	 * Returns remarks
	 * @return String
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public String getRemarksFromDB(String racCode, String startPaxNo, String endPaxNo)
		throws RemoteException, PaxTraxSystemException;
		
	/**
	 * Creates a RacPreAssignment
	 * @param racPreAssignmentBean
	 * @throws RemoteException
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void createRacPreAssignment(RacPreAssignmentBean racPreAssignmentBean)
	throws RemoteException,RacPreAssignmentException,PaxTraxSystemException;

	/**
	 * Searches for Rac Pre-Assignments given a rac code
	 * @param racCode
	 * @return ArrayList
	 * @throws RemoteException
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchRacPreAssignment(String racCode)
	throws RemoteException, PaxTraxSystemException;
	
	/**
	 * Modifies a RacPreAssignment.
	 * @param racBean
	 * @param updateRacBean
	 * @throws RemoteException
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void modifyRacPreAssignment(RacPreAssignmentBean racBean,
										RacPreAssignmentBean updateRacBean)
		throws RemoteException, RacPreAssignmentException, PaxTraxSystemException;
	
	/**
	 * Deletes a RacPreAssignment.
	 * @param racBean
	 * @throws RemoteException
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void deleteRacPreAssignment(RacPreAssignmentBean racBean) 
		throws RemoteException, RacPreAssignmentException, PaxTraxSystemException;
}
