package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessFlightBO_72d6adf6
 */
public class EJSRemoteStatelessFlightBO_72d6adf6 extends EJSWrapper implements FlightBO {
	/**
	 * EJSRemoteStatelessFlightBO_72d6adf6
	 */
	public EJSRemoteStatelessFlightBO_72d6adf6() throws java.rmi.RemoteException {
		super();	}
	/**
	 * selectMaintainFlightDetails
	 */
	public com.dfs.paxtrax.admin.valueobject.FlightBean selectMaintainFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		com.dfs.paxtrax.admin.valueobject.FlightBean _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 0, _EJS_s);
			_EJS_result = _EJS_beanRef.selectMaintainFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * massFlightChange
	 */
	public java.util.ArrayList massFlightChange(com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean flightDetailsBean) throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 1, _EJS_s);
			_EJS_result = _EJS_beanRef.massFlightChange(flightDetailsBean);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 1, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * saveFlightDetails
	 */
	public java.util.ArrayList saveFlightDetails(java.util.ArrayList flightpaxList) throws com.dfs.paxtrax.common.exception.PaxTraxSystemException, java.rmi.RemoteException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 2, _EJS_s);
			_EJS_result = _EJS_beanRef.saveFlightDetails(flightpaxList);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 2, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * selectFlightDetails
	 */
	public java.util.ArrayList selectFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 3, _EJS_s);
			_EJS_result = _EJS_beanRef.selectFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 3, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * selectOverrideFlightDetails
	 */
	public java.util.ArrayList selectOverrideFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 4, _EJS_s);
			_EJS_result = _EJS_beanRef.selectOverrideFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 4, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * checkNaccsStatus
	 */
	public void checkNaccsStatus(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 5, _EJS_s);
			_EJS_beanRef.checkNaccsStatus(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 5, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * deleteFlightDetails
	 */
	public void deleteFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 6, _EJS_s);
			_EJS_beanRef.deleteFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 6, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * insertOverrideFlightDetails
	 */
	public void insertOverrideFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 7, _EJS_s);
			_EJS_beanRef.insertOverrideFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 7, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * removeOverrideFlightDetails
	 */
	public void removeOverrideFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 8, _EJS_s);
			_EJS_beanRef.removeOverrideFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 8, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * saveFlightDetails
	 */
	public void saveFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 9, _EJS_s);
			_EJS_beanRef.saveFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 9, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * updateFlightDetails
	 */
	public void updateFlightDetails(com.dfs.paxtrax.admin.valueobject.FlightBean flightBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException, com.dfs.paxtrax.admin.exception.FlightException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.FlightBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.FlightBOBean)container.preInvoke(this, 10, _EJS_s);
			_EJS_beanRef.updateFlightDetails(flightBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.admin.exception.FlightException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 10, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
}
