package com.dfs.paxtrax.admin.business;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.util.ArrayList;

import javax.ejb.SessionBean;

import com.dfs.paxtrax.admin.dao.FlightDAO;
import com.dfs.paxtrax.admin.dao.MassFlightChangeDAO;
import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.admin.valueobject.FlightBean;
import com.dfs.paxtrax.common.business.PaxTraxSessionWrapper;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;

/**
 * Bean implementation class for Enterprise Bean: FlightBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Sundarrajan.K.	Created
 * 07/28/2007	Uma D			Added a method for CR 250 changes   
 */

public class FlightBOBean extends PaxTraxSessionWrapper implements SessionBean
{
	FlightDAO flightDAO = null;

	/**
	 * Saves flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting flight details
	 */
	public void saveFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::saveFlightDetails::Begin");
		flightDAO = FlightDAO.getInstance();
		flightDAO.saveFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::saveFlightDetails::End");
	}

	/**
	 * Updates the flight details after modification. 
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in updating flight details
	 */
	public void updateFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::updateFlightDetails::Begin");
		flightDAO = FlightDAO.getInstance();
		flightDAO.updateFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::updateFlightDetails::End");
	}

	/**
	 * Deletes the flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in deleting flight details
	 */
	public void deleteFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::deleteFlightDetails::Begin");
		flightDAO = FlightDAO.getInstance();
		flightDAO.deleteFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::deleteFlightDetails::End");
	}

	/**
	 * Insert override flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting override flight details
	 */
	public void insertOverrideFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::insertOverrideFlightDetails::Begin");
		flightDAO = FlightDAO.getInstance();
		flightDAO.insertOverrideFlightDetails(flightBean);
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::insertOverrideFlightDetails::End");
	}

	/**
	 * Removes the override flight details
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in removing override flight details
	 */
	public void removeOverrideFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::removeOverrideFlightDetails::Begin");
		flightDAO = FlightDAO.getInstance();
		flightDAO.removeOverrideFlightDetails(flightBean);
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::removeOverrideFlightDetails::End");
	}

	/**
	 * Searches Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::selectFlightDetails::Begin");
		FlightDAO flightDAO = FlightDAO.getInstance();
		ArrayList flightList = flightDAO.selectFlightDetails(flightBean);
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::selectFlightDetails::End");
		return flightList;
	}

	/**
	 * Searches Override Flight details based on the search criteria and returns the 
	 * result. 
	 * @param flightBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public ArrayList selectOverrideFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::selectOverrideFlightDetails::Begin");
		FlightDAO flightDAO = FlightDAO.getInstance();
		ArrayList flightList =
			flightDAO.selectOverrideFlightDetails(flightBean);
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::selectOverrideFlightDetails::End");
		return flightList;
	}

	/**
	 * Searches Flight details based on the tab values and returns the 
	 * result. 
	 * @param flightBean
	 * @return FlightBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting flight details
	 */
	public FlightBean selectMaintainFlightDetails(FlightBean flightBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::selectMaintainFlightDetails::Begin");
		FlightDAO flightDAO = FlightDAO.getInstance();
		flightBean = flightDAO.selectMaintainFlightDetails(flightBean);
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::selectMaintainFlightDetails::End");
		return flightBean;
	}

	/**
	 * Changes flight details given a list of pax
	 * @param flightChangeList the list of pax for which flight 
	 * 							details need change
	 * @throws RemoteException thrown on error
	 * @throws PaxTraxSystemException thrown on error if there is problem
	 * 									fetching flight details data
	 */
	public ArrayList massFlightChange(FlightDetailsBean flightDetailsBean)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::massFlightChange()::Begin");
		MassFlightChangeDAO massFlightChangeDAO =
			MassFlightChangeDAO.getInstance();
		ArrayList resultList =
			massFlightChangeDAO.getPaxDetails(flightDetailsBean);
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::massFlightChange()::End");
		return resultList;

	}

	public ArrayList saveFlightDetails(ArrayList flightpaxList)
		throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::saveFlightDetails()::Begin");
		MassFlightChangeDAO massFlightChangeDAO =
			MassFlightChangeDAO.getInstance();
		ArrayList resultList =
			massFlightChangeDAO.saveFlightDetails(flightpaxList);
		PaxTraxLog.logDebug("PaxTrax::FlightBOBean::saveFlightDetails()::End");
		return resultList;

	}

//	Added on July 28, 2007  for CR 250 changes -- Begin		
	/**
	 * Checks whether Naccs is generated for the flight  
	 * @param flightBean
	 * @throws PaxTraxSystemException PaxTraxException is thrown if there is 
	 * any problem
	 * @throws FlightException
	 */		
	public void checkNaccsStatus(FlightBean flightBean)
		throws PaxTraxSystemException,FlightException
	{
		PaxTraxLog.logDebug(
			"PaxTrax::FlightBOBean::checkNaccsStatus()::Begin");
		FlightDAO flightDAO = FlightDAO.getInstance();
		flightDAO.checkNaccsStatus(flightBean);
		PaxTraxLog.logDebug("PaxTrax::checkNaccsStatus::saveFlightDetails()::End");
	}

//	Added on July 28, 2007 for CR 250 changes-- End
}
