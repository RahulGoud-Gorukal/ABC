package com.dfs.paxtrax.admin.dao;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.exception.FlightException;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.passenger.valueobject.FlightDetailsBean;
import com.dfs.paxtrax.passenger.valueobject.PAXBean;

/**
 * This class has all the insert/select/update methods which communicates 
 * with the database
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Sundarrajan.K.	Created   
 */

public class MassFlightChangeDAO
{
	//This contains the instance of UserDAO class 
	private static MassFlightChangeDAO massFlightChangeDAO = null;
	private static boolean success = false;
	/**
	 * Creates an instance of FlightDAO only if the instance does not
	 * exist.
	 * 
	 * @return FlightDAO Returns the FlightDAO instance
	 */
	public static MassFlightChangeDAO getInstance()
	{
		if (massFlightChangeDAO == null)
		{
			initializeInstance();
		}
		return massFlightChangeDAO;
	}

	/**
	 * Sets the FlightDAO class instance
	 */
	private static synchronized void initializeInstance()
	{
		if (massFlightChangeDAO == null)
		{
			massFlightChangeDAO = new MassFlightChangeDAO();
		}
	}

	/**
	 * Constructor for this class
	 */
	private MassFlightChangeDAO()
	{

	}

	/**
	 * Insert flight details into database. 
	 * @param flightBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting flight details
	 */
	public ArrayList getPaxDetails(FlightDetailsBean flightDetailsBean) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::MassFlightChangeDAO::getPaxDetails::Begin");
		ArrayList resultList = new ArrayList();
		
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try
		{
			connection = dbUtil.getConnection();
			preparedStatement = connection.prepareStatement(SQLConstants.SELECT_PAX_BY_FLIGHT);
			preparedStatement.setString(1, flightDetailsBean.getAirlineCode());
			preparedStatement.setString(2, flightDetailsBean.getFlightNumber());
			String date = flightDetailsBean.getDate();
			if (date != null)
			{
				date = date.replace('/', '-');
			}
			preparedStatement.setString(3, date);
			resultSet = preparedStatement.executeQuery();
			if (resultSet != null)
			{
				while (resultSet.next())
				{
					String paxSeqId = resultSet.getLong(1)+"";
					String paxNumber = resultSet.getString(2);
					String lastName = resultSet.getString(3);
					String firstName = resultSet.getString(4);
					PAXBean paxBean = new PAXBean();
					paxBean.setPaxSequenceId(paxSeqId);
					paxBean.setPaxNumber(paxNumber);
					paxBean.setFirstName(firstName);
					paxBean.setLastName(lastName);
					FlightDetailsBean newBean = new FlightDetailsBean();
					newBean.setAirlineCode(flightDetailsBean.getAirlineCode());
					newBean.setFlightNumber(flightDetailsBean.getFlightNumber());
					newBean.setDate(flightDetailsBean.getDate());
					newBean.setFlightChange("T");
					paxBean.setDepartureFlightDetails(newBean);
					resultList.add(paxBean);

				}
			}

		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::getPaxDetails::getPaxDetails " + sqlException);

			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (resultSet != null)
				{
					resultSet.close();
					resultSet = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{

				PaxTraxLog.logError("PaxTrax::getPaxDetails::getPaxDetails " + sqlException);

				throw new PaxTraxSystemException(sqlException);
			}
		}

		PaxTraxLog.logDebug("PaxTrax::MassFlightChangeDAO::getPaxDetails::End");
		return resultList;
	}

	public ArrayList saveFlightDetails(ArrayList paxList) throws PaxTraxSystemException, FlightException
	{
		PaxTraxLog.logDebug("PaxTrax::MassFlightChangeDAO::saveFlightDetails::Begin");
		ArrayList resultList = new ArrayList();
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = null;
		CallableStatement callableStatement = null;
		try
		{
			connection = dbUtil.getConnection();
			callableStatement = connection.prepareCall(SQLConstants.MASS_FLIGHT_CHANGE);
			if (paxList != null)
			{
				int paxListSize = paxList.size();
				for (int i = 0; i < paxListSize; i++)
				{

					callableStatement.clearParameters();
					PAXBean paxBean = (PAXBean) paxList.get(i);

					if (("T").equals(paxBean.getDepartureFlightDetails().getFlightChange()))
					{
						callableStatement.setLong(1, Long.parseLong(paxBean.getPaxSequenceId()));
						callableStatement.setString(2, "8");
						callableStatement.setString(3, paxBean.getDepartureFlightDetails().getAirlineCode());
						callableStatement.setString(4, paxBean.getDepartureFlightDetails().getFlightNumber());
						String date = paxBean.getDepartureFlightDetails().getDate();
						if (date != null)
						{
							date = date.replace('/', '-');
						}
						callableStatement.setString(5, date);
						callableStatement.setString(6, paxBean.getUser());
						callableStatement.registerOutParameter(7, Types.INTEGER);
						callableStatement.execute();
						int errorCode = callableStatement.getInt(7);


						if (errorCode != 0)
						{

							resultList.add(paxBean);
						}

					}
				}
			}
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("PaxTrax::getPaxDetails::saveFlightDetails " + sqlException);

			throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{

				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{	connection.close();
					connection=null;
				}
			}
			catch (SQLException sqlException)
			{

				PaxTraxLog.logError("PaxTrax::getPaxDetails::saveFlightDetails " + sqlException);

				throw new PaxTraxSystemException(sqlException);
			}
		}

		PaxTraxLog.logDebug("PaxTrax::MassFlightChangeDAO::saveFlightDetails::End");
		return resultList;
	}
}
