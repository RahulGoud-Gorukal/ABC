package com.dfs.paxtrax.admin.business;

import java.util.ArrayList;

import com.dfs.paxtrax.admin.dao.RacPreAssignmentDAO;
import com.dfs.paxtrax.admin.exception.RacPreAssignmentException;
import com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;

/**
 * Bean implementation class for Enterprise Bean: RacPreAssignmentBO
 */
public class RacPreAssignmentBOBean implements javax.ejb.SessionBean {
	private javax.ejb.SessionContext mySessionCtx;
	/**
	 * getSessionContext
	 */
	public javax.ejb.SessionContext getSessionContext() {
		return mySessionCtx;
	}
	/**
	 * setSessionContext
	 */
	public void setSessionContext(javax.ejb.SessionContext ctx) {
		mySessionCtx = ctx;
	}
	/**
	 * ejbCreate
	 */
	public void ejbCreate() throws javax.ejb.CreateException {
	}
	/**
	 * ejbActivate
	 */
	public void ejbActivate() {
	}
	/**
	 * ejbPassivate
	 */
	public void ejbPassivate() {
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
	}
	
	/**
	 * Loads the list of RacCodes.
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList loadRacCodes() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax:: RacPreAssignmentBOBean::loadRacCodes::Begin");
		RacPreAssignmentDAO racPreAssignmentDAO =  RacPreAssignmentDAO.getInstance();
		ArrayList racCodes = racPreAssignmentDAO.loadRacCodes();
		PaxTraxLog.logDebug("PaxTrax:: RacPreAssignmentBOBean::loadRacCodes::End");
		return racCodes;
	}
	
	//Added for CR1859
	/**
	* Populates remarks
	* @return String
	* @throws PaxTraxSystemException
	*/
	public String getRemarksFromDB(String racCode, String startPaxNo, String endPaxNo) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax:: RacPreAssignmentBOBean::getRemarksFromDB::Begin");
		RacPreAssignmentDAO racPreAssignmentDAO =  RacPreAssignmentDAO.getInstance();
		String remarks = racPreAssignmentDAO.getRemarksFromDB(racCode, startPaxNo, endPaxNo);
		PaxTraxLog.logDebug("PaxTrax:: RacPreAssignmentBOBean::getRemarksFromDB::End");
		return remarks;
	}
	
	/**
	 * Creates a RacPreAssignment.
	 * @param racPreAssignmentBean
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void createRacPreAssignment(RacPreAssignmentBean racPreAssignmentBean) 
		throws RacPreAssignmentException,PaxTraxSystemException
		{
		
		PaxTraxLog.logDebug("PaxTrax:: RacPreAssignmentBOBean::createRacPreAssignment::Begin");
		RacPreAssignmentDAO racPreAssignmentDAO =  RacPreAssignmentDAO.getInstance();
		racPreAssignmentDAO.createRacPreAssignment(racPreAssignmentBean);
		PaxTraxLog.logDebug("PaxTrax:: RacPreAssignmentBOBean::createRacPreAssignment::End");
		
		}

	/**
	 * Searches for Rac Pre-Assignments given a rac code
	 * @param racCode
	 * @return ArrayList
	 * @throws PaxTraxSystemException
	 */
	public ArrayList searchRacPreAssignment(String racCode)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax:: RacPreAssignmentBOBean::searchRacPreAssignment::Start");
		RacPreAssignmentDAO racPreAssignmentDAO =
			RacPreAssignmentDAO.getInstance();
		PaxTraxLog.logDebug(
			"PaxTrax:: RacPreAssignmentBOBean::searchRacPreAssignment::End");
		return racPreAssignmentDAO.searchRacPreAssignment(racCode);
	}

	/**
	 * Modifies a RacPreAssignment
	 * @param racBean
	 * @param updateRacBean
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void modifyRacPreAssignment(
		RacPreAssignmentBean racBean,
		RacPreAssignmentBean updateRacBean)
		throws RacPreAssignmentException, PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax:: RacPreAssignmentBOBean::modifyRacPreAssignment::Start");
		RacPreAssignmentDAO racPreAssignmentDAO =
							RacPreAssignmentDAO.getInstance();
		racPreAssignmentDAO.modifyRacPreAssignment(racBean, updateRacBean);
		PaxTraxLog.logDebug(
			"PaxTrax:: RacPreAssignmentBOBean::modifyRacPreAssignment::End");
	}
	
	/**
	 * Deletes a RacPreAssignment.
	 * @param racBean
	 * @throws RacPreAssignmentException
	 * @throws PaxTraxSystemException
	 */
	public void deleteRacPreAssignment(RacPreAssignmentBean racBean) 
	throws RacPreAssignmentException, PaxTraxSystemException {
		PaxTraxLog.logDebug(
			"PaxTrax:: RacPreAssignmentBOBean::deleteRacPreAssignment::Start");
		RacPreAssignmentDAO racPreAssignmentDAO =
							RacPreAssignmentDAO.getInstance();
		racPreAssignmentDAO.deleteRacPreAssignment(racBean);
		PaxTraxLog.logDebug(
			"PaxTrax:: RacPreAssignmentBOBean::deleteRacPreAssignment::End");
	}
}
