package com.dfs.paxtrax.admin.dao;

/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.commtracking.valueobject.TravelAgentBranch;
import com.dfs.paxtrax.commtracking.valueobject.TravelAgentInfoBean;

/**
 * This class has all the insert/select/update methods which communicates 
 * with the database
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */

public class ReferenceDataDAO
{
	//This contains the instance of UserDAO class 
	private static ReferenceDataDAO referenceDataDAO = null;

	//Holds dbUtil
	DBUtil dbUtil = null;

	/**
	 * Creates an instance of ReferenceDataDAO only if the instance does not
	 * exist.
	 * 
	 * @return ReferenceDataDAO Returns the ReferenceDataDAO instance
	 */
	public static ReferenceDataDAO getInstance()
	{
		if (referenceDataDAO == null)
		{
			initializeInstance();
		}
		return referenceDataDAO;
	}

	/**
	 * Sets the ReferenceDataDAO class instance
	 */
	private static synchronized void initializeInstance()
	{
		if (referenceDataDAO == null)
		{
			referenceDataDAO = new ReferenceDataDAO();
		}
	}

	/**
	 * Constructor for this class
	 */
	private ReferenceDataDAO()
	{

	}

	/**
	 * Insert reference data details into database. 
	 * @param referenceDataBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting referenceData details
	 */
	public ArrayList insertReferenceData(ReferenceDataListBean referenceDataListBean) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::insertReferenceData::Begin");
		int size = 0;
		ArrayList referenceData = null;
		ArrayList deleteList = null;
		ArrayList referenceList = null;
		//ArrayList removeList = null;
		boolean exists = false;
		//boolean error = false;
		String from = null;
		String to = null;
		String flag = null;
		String naccsCode = null;
		CallableStatement callableStatement = null;
		ReferenceDataBean referenceDataBean = null;
		dbUtil = DBUtil.getInstance();
		Connection connection = null;

		try
		{
			connection = dbUtil.getConnection();
			if (referenceDataListBean != null)
			{
				String refId = referenceDataListBean.getRefId();
				String[] codeIds = referenceDataListBean.getCodeIds();
				String[] codeValues = referenceDataListBean.getCodeValues();

				referenceData = loadReferenceData(refId);
				if (referenceData != null)
				{
					int length = 0;
					deleteList = new ArrayList();
					size = referenceData.size();

					if ((codeIds != null) && (codeIds.length != 0))
					{
						length = codeIds.length;
						for (int i = 0; i < size; i++)
						{
							referenceDataBean = (ReferenceDataBean) referenceData.get(i);
							String id = referenceDataBean.getCodeId();

							for (int k = 0; k < length; k++)
							{

								if (id.equals(codeIds[k]))
								{
									exists = true;
									break;
								}
								else
								{
									exists = false;
								}
							}
							if (!exists)
							{
								deleteList.add(referenceDataBean);
							}
						}
					}
					else
					{
						deleteList = referenceData;
					}

					if (deleteList != null)
					{

						referenceList = new ArrayList();
						size = deleteList.size();

						for (int j = 0; j < size; j++)
						{
							referenceDataBean = (ReferenceDataBean) deleteList.get(j);
							String id = referenceDataBean.getCodeId();
							callableStatement = connection.prepareCall(SQLConstants.PROC_DELETE_REF_DATA);
							callableStatement.setString(1, refId);
							callableStatement.setString(2, id);
							callableStatement.registerOutParameter(3, Types.INTEGER);
							callableStatement.execute();
							int errorCode = callableStatement.getInt(3);
							if (errorCode != 0)
							{

								referenceList.add(referenceDataBean);
							}
						}
					}
					callableStatement = connection.prepareCall(SQLConstants.PROC_INSERT_REF_DATA);

					if ((codeIds != null) && (codeValues != null))
					{
						String[] fromTime = referenceDataListBean.getFromTime();
						String[] toTime = referenceDataListBean.getToTime();
						String[] flags = referenceDataListBean.getFlags();
						String[] naccsCodes = referenceDataListBean.getNaccsCodes();

						for (int i = 0; i < length; i++)
						{

							callableStatement.setString(1, refId);
							callableStatement.setString(2, codeIds[i]);
							callableStatement.setString(3, codeValues[i]);

							if ((fromTime != null) && (toTime != null))
							{
								if ((fromTime.length != 0) && (toTime.length != 0))
								{
									from = fromTime[i];
									to = toTime[i];
								}
							}
							callableStatement.setString(4, from);
							callableStatement.setString(5, to);
							if ((flags != null) && (flags.length != 0))
							{
								flag = flags[i];
							}
							if ((naccsCodes != null) && (naccsCodes.length != 0))
							{
								naccsCode = naccsCodes[i];
							}
							callableStatement.setString(6, flag);
							callableStatement.setString(7, naccsCode);
							callableStatement.registerOutParameter(8, Types.INTEGER);
							callableStatement.execute();
						}
					}
				}
			}
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{

			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				throw new PaxTraxSystemException(sqle);
			}
		}

		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::insertReferenceData::End");
		return referenceList;
	}

	/**
	 * Loads reference data for the given type
	 * @param referenceType 
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in loading ReferenceData 
	 */
	public ArrayList loadReferenceData(String referenceType) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::loadReferenceData::Begin");
		int pos1 = 0;
		int pos2 = 0;
		String fromTime = null;
		String toTime = null;
		ArrayList referenceData = null;
		ReferenceDataBean referenceDataBean = null;

		dbUtil = DBUtil.getInstance();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try
		{
			connection = dbUtil.getConnection();
			preparedStatement =
				connection.prepareStatement(
					"select CRM.REF_NAME,CR.CODE_CODE_ID,CR.CODE_CODE_VALUE,"
						+ "CR.CODE_FROM_TIME,CR.CODE_TO_TIME, CR.CODE_TO_FLAG, "
						+ "CR.CODE_NACCS_CODE FROM TB_CODE_REF CR,TB_CODE_REF_MSTR CRM "
						+ "WHERE CR.REF_ID = CRM.REF_ID AND CR.REF_ID = ?  ORDER BY CR.CODE_CODE_VALUE");
			preparedStatement.setString(1, referenceType);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs != null)
			{
				referenceData = new ArrayList();
				while (rs.next())
				{
					referenceDataBean = new ReferenceDataBean();
					referenceDataBean.setReferenceId(referenceType);
					referenceDataBean.setReferenceName(rs.getString(1));
					referenceDataBean.setCodeId(rs.getString(2));
					referenceDataBean.setCodeValue(rs.getString(3));
//					Added for CR611 changes on Jul 31,2008 --Begin					
					referenceDataBean.setDisplayLabel(referenceDataBean.getCodeId() + " - " 
						+ referenceDataBean.getCodeValue());
//					Added for CR611 changes on Jul 31,2008 --End
					fromTime = rs.getString(4);
					if (fromTime != null)
					{
						pos1 = fromTime.indexOf(":");
						referenceDataBean.setFromHr(fromTime.substring(0, pos1));
						pos2 = fromTime.lastIndexOf(":");

						referenceDataBean.setFromMin(fromTime.substring(pos1 + 1, pos2));
					}
					toTime = rs.getString(5);
					if (toTime != null)
					{
						pos1 = toTime.indexOf(":");
						referenceDataBean.setToHr(toTime.substring(0, pos1));
						pos2 = toTime.lastIndexOf(":");

						referenceDataBean.setToMin(toTime.substring(pos1 + 1, pos2));
					}
					referenceDataBean.setCodeToFlag(rs.getString(6));
					referenceDataBean.setNaccsCode(rs.getString(7));
					referenceData.add(referenceDataBean);
				}
			}
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::loadReferenceData::End");
		return referenceData;
	}

	/**
	 * Loads all reference types
	 * @return ArrayList List of reference types
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in loading reference types
	 */
	public ArrayList loadReferenceType() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::loadReferenceType::Begin");
		ArrayList referenceType = null;
		ReferenceDataBean referenceDataBean = null;

		dbUtil = DBUtil.getInstance();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try
		{
			connection = dbUtil.getConnection();
			String sql = "select REF_ID, REF_NAME from TB_CODE_REF_MSTR ORDER BY REF_NAME";
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs != null)
			{
				referenceType = new ArrayList();
				while (rs.next())
				{
					referenceDataBean = new ReferenceDataBean();
					referenceDataBean.setCodeId(rs.getString(1));
					referenceDataBean.setCodeValue(rs.getString(2));
					referenceType.add(referenceDataBean);
				}
			}
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				throw new PaxTraxSystemException(sqle);
			}
		}

		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::loadReferenceType::End");
		return referenceType;

	}

	/**
	 * Return the list of travel agent codes
	 * @return ArrayList list of travel agent codes
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList getTravelAgentCodes() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::getTravelAgentCodes():: Begin");
		Connection con = null;
		Statement statement = null;
		ResultSet tavelAgentResults = null;
		ArrayList travelAgentCodesList = new ArrayList();
		try
		{
			con = DBUtil.getInstance().getConnection();
			statement = con.createStatement();
			tavelAgentResults = statement.executeQuery(SQLConstants.SELECT_TRAVEL_AGENT_CODE);

			while (tavelAgentResults.next())
			{
				TravelAgentInfoBean travelAgentInfoBean = new TravelAgentInfoBean();
				String taCode = tavelAgentResults.getString(1);
				travelAgentInfoBean.setTaCode(taCode);
				String agencyName = tavelAgentResults.getString(2);
				travelAgentInfoBean.setTaAgencyName(agencyName);
				travelAgentInfoBean.setTaDisplay(agencyName + "-" + taCode);
				travelAgentCodesList.add(travelAgentInfoBean);
			}

		}
		catch (SQLException e)
		{
			PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::getTravelAgentCodes()::SQLException error Occured", e);
			throw new PaxTraxSystemException(e);
		}
		finally
		{
			try
			{
				if (con != null)
					con.close();
				if (tavelAgentResults != null)
					tavelAgentResults.close();
				if (statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
				PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::getTravelAgentCodes()::Error while closing connection", e);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::getTravelAgentCodes():: End");
		return travelAgentCodesList;
	}

	/**
	 * Return the list of travel agent branches given a travelAgentCode
	 * @param travelAgentCode the travel agent code to get the list of branches
	 * @return ArrayList the list of all travel agent branches
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList getTravelAgentBranches(String travelAgentCode) throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::getTravelAgentBranches()::Begin");
		TravelAgentBranch taBranch = null;
		Connection con = null;
		ArrayList taBranchList = new ArrayList();
		ResultSet branchResults = null;
		PreparedStatement pstatement = null;
		try
		{
			con = DBUtil.getInstance().getConnection();
			pstatement = con.prepareStatement(SQLConstants.SELECT_TRAVEL_AGENT_BRANCH);
			pstatement.setString(1, travelAgentCode);
			pstatement.execute();
			branchResults = pstatement.getResultSet();
			while (branchResults.next())
			{
				taBranch = new TravelAgentBranch();
				String taBranchCode = branchResults.getString(1);
				String taBranchName = branchResults.getString(2);
				taBranch.setTaBranchCode(taBranchCode);
				taBranch.setTaBranchName(taBranchName);
				taBranch.setDisplayLabel(taBranchName + "-" + taBranchCode);
				taBranchList.add(taBranch);
			}
		}
		catch (SQLException e)
		{
			PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO:: SQL Error", e);
			throw new PaxTraxSystemException(e);
		}
		finally
		{
			try
			{
				if (con != null)
					con.close();
				if (branchResults != null)
					branchResults.close();
				if (pstatement != null)
					pstatement.close();
			}
			catch (SQLException e)
			{
				PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO:: Error closing connection", e);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataDAO::getTravelAgentBranches()::End");
		return taBranchList;
	}

}
