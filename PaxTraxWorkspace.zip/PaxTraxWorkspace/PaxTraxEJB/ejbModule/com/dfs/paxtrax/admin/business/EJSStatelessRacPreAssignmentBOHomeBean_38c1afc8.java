package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessRacPreAssignmentBOHomeBean_38c1afc8
 */
public class EJSStatelessRacPreAssignmentBOHomeBean_38c1afc8 extends EJSHome {
	/**
	 * EJSStatelessRacPreAssignmentBOHomeBean_38c1afc8
	 */
	public EJSStatelessRacPreAssignmentBOHomeBean_38c1afc8() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public com.dfs.paxtrax.admin.business.RacPreAssignmentBO create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
com.dfs.paxtrax.admin.business.RacPreAssignmentBO result = null;
boolean createFailed = false;
try {
	result = (com.dfs.paxtrax.admin.business.RacPreAssignmentBO) super.createWrapper(new BeanId(this, null));
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
