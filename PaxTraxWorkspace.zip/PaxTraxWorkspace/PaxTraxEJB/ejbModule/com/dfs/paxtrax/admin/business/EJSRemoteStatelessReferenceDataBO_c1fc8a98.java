package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessReferenceDataBO_c1fc8a98
 */
public class EJSRemoteStatelessReferenceDataBO_c1fc8a98 extends EJSWrapper implements ReferenceDataBO {
	/**
	 * EJSRemoteStatelessReferenceDataBO_c1fc8a98
	 */
	public EJSRemoteStatelessReferenceDataBO_c1fc8a98() throws java.rmi.RemoteException {
		super();	}
	/**
	 * getTravelAgentBranches
	 */
	public java.util.ArrayList getTravelAgentBranches(java.lang.String travelAgentCode) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.ReferenceDataBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.ReferenceDataBOBean)container.preInvoke(this, 0, _EJS_s);
			_EJS_result = _EJS_beanRef.getTravelAgentBranches(travelAgentCode);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * getTravelAgentCodes
	 */
	public java.util.ArrayList getTravelAgentCodes() throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.ReferenceDataBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.ReferenceDataBOBean)container.preInvoke(this, 1, _EJS_s);
			_EJS_result = _EJS_beanRef.getTravelAgentCodes();
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 1, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * loadReferenceData
	 */
	public java.util.ArrayList loadReferenceData(java.lang.String referenceType) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.ReferenceDataBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.ReferenceDataBOBean)container.preInvoke(this, 2, _EJS_s);
			_EJS_result = _EJS_beanRef.loadReferenceData(referenceType);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 2, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * loadReferenceType
	 */
	public java.util.ArrayList loadReferenceType() throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.ReferenceDataBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.ReferenceDataBOBean)container.preInvoke(this, 3, _EJS_s);
			_EJS_result = _EJS_beanRef.loadReferenceType();
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 3, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * saveReferenceData
	 */
	public java.util.ArrayList saveReferenceData(com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean referenceDataListBean) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.ReferenceDataBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.ReferenceDataBOBean)container.preInvoke(this, 4, _EJS_s);
			_EJS_result = _EJS_beanRef.saveReferenceData(referenceDataListBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 4, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
}
