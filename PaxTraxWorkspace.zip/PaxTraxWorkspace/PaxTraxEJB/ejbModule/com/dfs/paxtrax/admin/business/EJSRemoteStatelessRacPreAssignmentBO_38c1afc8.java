package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSRemoteStatelessRacPreAssignmentBO_38c1afc8
 */
public class EJSRemoteStatelessRacPreAssignmentBO_38c1afc8 extends EJSWrapper implements RacPreAssignmentBO {
	/**
	 * EJSRemoteStatelessRacPreAssignmentBO_38c1afc8
	 */
	public EJSRemoteStatelessRacPreAssignmentBO_38c1afc8() throws java.rmi.RemoteException {
		super();	}
	/**
	 * getRemarksFromDB
	 */
	public java.lang.String getRemarksFromDB(java.lang.String racCode, java.lang.String startPaxNo, java.lang.String endPaxNo) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.lang.String _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean)container.preInvoke(this, 0, _EJS_s);
			_EJS_result = _EJS_beanRef.getRemarksFromDB(racCode, startPaxNo, endPaxNo);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 0, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * loadRacCodes
	 */
	public java.util.ArrayList loadRacCodes() throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean)container.preInvoke(this, 1, _EJS_s);
			_EJS_result = _EJS_beanRef.loadRacCodes();
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 1, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * searchRacPreAssignment
	 */
	public java.util.ArrayList searchRacPreAssignment(java.lang.String racCode) throws java.rmi.RemoteException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		java.util.ArrayList _EJS_result = null;
		try {
			com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean)container.preInvoke(this, 2, _EJS_s);
			_EJS_result = _EJS_beanRef.searchRacPreAssignment(racCode);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 2, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return _EJS_result;
	}
	/**
	 * createRacPreAssignment
	 */
	public void createRacPreAssignment(com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean racPreAssignmentBean) throws java.rmi.RemoteException, com.dfs.paxtrax.admin.exception.RacPreAssignmentException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean)container.preInvoke(this, 3, _EJS_s);
			_EJS_beanRef.createRacPreAssignment(racPreAssignmentBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.admin.exception.RacPreAssignmentException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 3, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * deleteRacPreAssignment
	 */
	public void deleteRacPreAssignment(com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean racBean) throws java.rmi.RemoteException, com.dfs.paxtrax.admin.exception.RacPreAssignmentException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean)container.preInvoke(this, 4, _EJS_s);
			_EJS_beanRef.deleteRacPreAssignment(racBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.admin.exception.RacPreAssignmentException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 4, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
	/**
	 * modifyRacPreAssignment
	 */
	public void modifyRacPreAssignment(com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean racBean, com.dfs.paxtrax.admin.valueobject.RacPreAssignmentBean updateRacBean) throws java.rmi.RemoteException, com.dfs.paxtrax.admin.exception.RacPreAssignmentException, com.dfs.paxtrax.common.exception.PaxTraxSystemException {
		EJSDeployedSupport _EJS_s = container.getEJSDeployedSupport(this);
		
		try {
			com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean _EJS_beanRef = (com.dfs.paxtrax.admin.business.RacPreAssignmentBOBean)container.preInvoke(this, 5, _EJS_s);
			_EJS_beanRef.modifyRacPreAssignment(racBean, updateRacBean);
		}
		catch (java.rmi.RemoteException ex) {
			_EJS_s.setUncheckedException(ex);
		}
		catch (com.dfs.paxtrax.admin.exception.RacPreAssignmentException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (com.dfs.paxtrax.common.exception.PaxTraxSystemException ex) {
			_EJS_s.setCheckedException(ex);
			throw ex;
		}
		catch (Throwable ex) {
			_EJS_s.setUncheckedException(ex);
			throw new java.rmi.RemoteException("bean method raised unchecked exception", ex);
		}

		finally {
			try {
				container.postInvoke(this, 5, _EJS_s);
			} finally {
				container.putEJSDeployedSupport(_EJS_s);
			}
		}
		return ;
	}
}
