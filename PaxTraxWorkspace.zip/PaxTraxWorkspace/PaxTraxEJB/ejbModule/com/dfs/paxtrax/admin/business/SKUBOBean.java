package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.naming.NamingException;

import com.dfs.paxtrax.admin.dao.SKUDAO;
import com.dfs.paxtrax.admin.exception.SkuException;
import com.dfs.paxtrax.admin.valueobject.SKUBean;
import com.dfs.paxtrax.common.business.PaxTraxSessionWrapper;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
import com.dfs.paxtrax.common.util.ServiceLocator;
import com.dfs.paxtrax.plu.business.PLUMessageProcessor;
import com.dfs.paxtrax.plu.business.PLUMessageProcessorHome;


/**
 * Bean implementation class for Enterprise Bean: SKUBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 20/04/2004	Yuvarani     	Created   
 */

public class SKUBOBean extends PaxTraxSessionWrapper implements SessionBean
{

	/**
	 * Loads Sku details by invoking BO method.
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in loading Sku details
	 */
	public ArrayList loadSkuPage() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::loadSkuPage::Begin");
		ArrayList locationList = null;
		SKUDAO skudao = new SKUDAO();
		locationList = skudao.loadSkuPage();
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::loadSkuPage::End");
		return locationList;
	}

	/**
	 * Saves Sku details by invoking BO method.
	 * @param SKUBean skubean
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving Sku details
	 */
	public String[] saveSKUDetails(SKUBean skubean,String userId) 
		throws PaxTraxSystemException,SkuException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::saveSKUDetails::Begin");
		String[] upcReturn = null;
		SKUDAO skudao = new SKUDAO();
		upcReturn = skudao.saveSKUDetails(skubean,userId);
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::saveSKUDetails::End");
		return upcReturn;
	}
	
	/**
	 * Gets LocationDetails.
	 * @param skubean
	 * @throws PaxTraxSystemException
	 */
	public SKUBean getLocationDetails(SKUBean skubean) 
			throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::getLocationDetails::Begin");
		SKUDAO skudao = new SKUDAO();
		SKUBean skuBean = skudao.getLocationDetails(skubean);
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::getLocationDetails::End");
		return skuBean;
	}
	
	public void sendEmergencySku(SKUBean skuBean)
			throws PaxTraxSystemException	
	{
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::sendEmergencySku::Begin"
												+skuBean.getItemNumber());
    try {
        
            PLUMessageProcessorHome processorHome = (PLUMessageProcessorHome)
                            ServiceLocator.getInstance().getEJBHome(
                                    PaxTraxConstants.PLU_MESSAGE_PROCESSOR_JNDI_HOME);
             PLUMessageProcessor messageProcessor = processorHome.create();
             messageProcessor.processEmergencySKU(skuBean);
            PaxTraxLog.log(
                PaxTraxLog.DEBUG,
                "SKUBOBean:sendEmergencySku() - Successfully cerate MessageProcessorBean......Created MessageProcessorHome"
                );
        

    } catch(NamingException e)  {

        PaxTraxLog.log(
                PaxTraxLog.DEBUG,
                "SKUBOBean:sendEmergencySku() - Error finding MessageProcessorHome jndi lookuop problems",
                e);

    } catch(RemoteException e){

        PaxTraxLog.log(
                PaxTraxLog.DEBUG,
                "SKUBOBean:sendEmergencySku() - Error creating MessageProcessorBean [ RMI create() failed ]",
                e);

    } catch(CreateException e){

        PaxTraxLog.log(
                PaxTraxLog.DEBUG,
                "SKUBOBean:sendEmergencySku() - Error creating MessageProcessorBean [ PLUListener create() failed ]",
                e);
    }
		PaxTraxLog.logDebug("PaxTrax::SKUBOBean::sendEmergencySku::End");
	}
	
}
