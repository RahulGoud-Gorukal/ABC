package com.dfs.paxtrax.admin.dao;
/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

import com.dfs.paxtrax.admin.exception.SecurityException;
import com.dfs.paxtrax.admin.util.Convertor;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataBean;
import com.dfs.paxtrax.admin.valueobject.UserBean;
import com.dfs.paxtrax.common.constants.PaxTraxConstants;
import com.dfs.paxtrax.common.constants.SQLConstants;
import com.dfs.paxtrax.common.dao.DBUtil;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;
/**
 * This class has all the insert/select/update methods which communicates 
 * with the database
 *
 * @author Cognizant Technology Solutions
 * @contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 22/03/2004	Vaikundamurthy	Created   
 */
public class UserDAO
{
	//This contains the instance of UserDAO class 
	private static UserDAO userDAO = null;
	/**
	 * Creates an instance of UserDAO only if the instance does not
	 * exist.
	 * 
	 * @return UserDAO Returns the UserDAO instance
	 */
	public static UserDAO getInstance()
	{
		if (userDAO == null)
		{
			userDAO = new UserDAO();
		}
		return userDAO;
	}
	/**
	 * Constructor for this class
	 */
	private UserDAO()
	{
	}
	/**
	 * Insert user details into database. 
	 * @param userBean
	 * @throws PaxTraxSystemException  PaxTraxExcepiton is thrown if there 
	 * is any problem in inserting user details
	 */
	public void insertUserDetails(UserBean userBean)
		throws SecurityException, PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::insertUserDetails::Begin");
		ResultSet rs = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		CallableStatement callableStatement = null;
		try
		{
			
		callableStatement	 =
				connection.prepareCall(SQLConstants.PROC_INSERT_USER_DETAILS);

			String userId = userBean.getUserId();
			callableStatement.setString(1, userId);
			String password = userBean.getPassword();
			
			if (password != null)
			{
				Convertor convertor = new Convertor();
				callableStatement.setString(2, convertor.encode(password));
			}
			else
			{
				callableStatement.setString(2, password);	
			}
			callableStatement.setString(3, userBean.getEmployeeId());
			callableStatement.setString(4, userBean.getLastName());
			callableStatement.setString(5, userBean.getFirstName());
			callableStatement.setDate(6, getDate(userBean.getDateOfBirth()));
			/*ReferenceDataBean languageBean = userBean.getLanguageBean();
			callableStatement.setString(7, languageBean.getReferenceId());
			callableStatement.setString(8, languageBean.getCodeId());*/
			callableStatement.setString(7, userBean.getIsNeverLock());
			callableStatement.setInt(8, userBean.getInvalidTries());
			callableStatement.setString(9, userBean.getActiveStatus());
			callableStatement.setString(10, userBean.getReason());
			callableStatement.setString(11, userBean.getLockStatus());
			callableStatement.setString(12, PaxTraxConstants.INSERT);
			callableStatement.setString(13, userBean.getUser());
			callableStatement.registerOutParameter(14, Types.INTEGER);
			callableStatement.registerOutParameter(15, Types.INTEGER);
			callableStatement.execute();

			int result = callableStatement.getInt(14);
			if (result == 1)
			{
				throw new SecurityException(
					PaxTraxConstants.USER_ALREADY_EXISTS);
			}
			int errorCode = callableStatement.getInt(15);

			if (errorCode != 0)
			{
				PaxTraxLog.logError("UserDAO::insertUserDetails():: Error Occured in procedure "
								+ SQLConstants.PROC_INSERT_USER_DETAILS + ", SQL Error code is "+ errorCode);
				throw new PaxTraxSystemException(
					PaxTraxConstants.SYSTEM_EXCEPTION);
			}

			String[] assingedTransactions =
				userBean.getAssignedTransactionIds();

			if (assingedTransactions != null)
			{
				int size = assingedTransactions.length;

				for (int i = 0; i < size; i++)
				{
					int transactionId =
						Integer.parseInt(assingedTransactions[i]);

					callableStatement =
						connection.prepareCall(
							SQLConstants.PROC_INSERT_TRANSACTIONS);
					callableStatement.setString(1, userId);
					callableStatement.setInt(2, transactionId);
					callableStatement.registerOutParameter(3, Types.INTEGER);

					callableStatement.execute();
					rs = callableStatement.getResultSet();

					if (rs != null)
					{
						int error = rs.getInt(3);
						if (error != 0)
						{
							PaxTraxLog.logError("UserDAO::insertUserDetails():: Error Occured in procedure "
												+ SQLConstants.PROC_INSERT_TRANSACTIONS + ", SQL Error code is "+ error);
							throw new PaxTraxSystemException(
								PaxTraxConstants.SYSTEM_EXCEPTION);
						}

					}
				}
			}
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::insertUserDetails():: SQL Exception Occured ", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::insertUserDetails():: Error occured while closing connection ", sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::insertUserDetails::End");
	}
	/**
	 * Updates the activate status in database. 
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in updating user status
	 */
	public void updateActivateStatus(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::updateActivateStatus::Begin");
		PreparedStatement preparedStatement = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		try
		{
			preparedStatement =
				connection.prepareStatement(SQLConstants.UPDATE_ACTIVE_STATUS);
			preparedStatement.setString(1, userBean.getActiveStatus());
			preparedStatement.setString(2, userBean.getReason());
			preparedStatement.setString(3, userBean.getUserId());
			preparedStatement.execute();
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::updateActivateStatus()::SQL Error occured in procedure "
								+ SQLConstants.UPDATE_ACTIVE_STATUS , sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::updateActivateStatus():: Error while closing connection", sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::updateActivateStatus::End");	
	}
	/**
	 * Updates the lock status in database. 
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there 
	 * is any problem in updating user status
	 */
	public void updateLockStatus(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::updateLockStatus::Begin");
		PreparedStatement preparedStatement = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		try
		{
			preparedStatement =
				connection.prepareStatement(SQLConstants.UPDATE_LOCK_STATUS);
			preparedStatement.setString(1, userBean.getLockStatus());
			preparedStatement.setString(2, userBean.getUserId());
			preparedStatement.execute();
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::updateLockStatus()::SQL Error occured", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::updateLockStatus()::Error occured while closing connection", sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::updateLockStatus::End");
	}
	
	/**
	 * Returns transactions
	 * @return ArrayList List of transactions
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in getting transactions
	 */
	public ArrayList selectTransactions() throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::selectTransactions::Begin");
		ArrayList transactions = null;
		Statement statement = null;
		ResultSet rs = null;
		ReferenceDataBean referenceDataBean = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		try
		{
			statement = connection.createStatement();
			rs = statement.executeQuery(SQLConstants.SELECT_TRANSACTIONS);
			if (rs != null)
			{
				transactions = new ArrayList();
				while (rs.next())
				{
					referenceDataBean = new ReferenceDataBean();
					referenceDataBean.setCodeId(
						SQLConstants.BLANK + rs.getInt(1));
					referenceDataBean.setCodeValue(rs.getString(2));
					transactions.add(referenceDataBean);
				}
			}
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::updateLockStatus()::SQL Error occured ", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (statement != null)
				{
					statement.close();
					statement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::updateLockStatus()::Error closing connection", sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::selectTransactions::End");
		
		return transactions;
	}
	/**
	 * Searches user details based on the search criteria and returns the 
	 * result. 
	 * @param userBean
	 * @return ArrayList
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in selecting user details
	 */
	public ArrayList selectUserDetails(UserBean searchUserBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::selectUserDetails::Begin");
		ArrayList userList = null;
		UserBean userBean = null;
		ArrayList transactions = null;
		ReferenceDataBean referenceDataBean = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		try
		{
			String sql =
				"SELECT UM.USER_USER_ID, UM.USER_USER_PASSWORD, UM.USER_EMP_ID,"
					+ "UM.USER_L_NAME, UM.USER_F_NAME, UM.USER_DOB, "					
					+ "UM.USER_NEVER_LOCK, UM.USER_INVALID_TRY, "
					+ "UM.USER_ACTIVE, UM.USER_REASON, UM.USER_LOCKED FROM "
					+ "TB_USER_MSTR UM LEFT OUTER JOIN TB_CODE_REF CR ON "
					+ "UM.USER_LANGUAGE_ID = CR.CODE_CODE_ID AND UM.USER_REF_ID"
					+ " = CR.REF_ID WHERE UM.USER_DELETED = 'N'AND "
					+ "UM.USER_USER_ID != '9999'";
			StringBuffer where = new StringBuffer();
			String userId = searchUserBean.getUserId();
			if ((userId != null) || (SQLConstants.BLANK.equals(userId)))
			{
				where.append(" AND USER_USER_ID = '" + userId	+ "'");
			}
			String lastName = searchUserBean.getLastName();
			if ((lastName != null) && (!SQLConstants.BLANK.equals(lastName)))
			{
				where.append(" AND UPPER(USER_L_NAME) like '" + lastName.toUpperCase() 
					+ "%'");
			}
			String firstName = searchUserBean.getFirstName();
			if ((firstName != null) && (!SQLConstants.BLANK.equals(firstName)))
			{
				where.append(" AND UPPER(USER_F_NAME) like '" + firstName.toUpperCase() 
					+ "%'");
			}
			String empId = searchUserBean.getEmployeeId();
			if ((empId != null) && (!SQLConstants.BLANK.equals(empId)))
			{
				where.append(" AND UPPER(USER_EMP_ID) like '" + empId.toUpperCase() 
					+ "%'");
			}
			where.append(" ORDER BY UM.USER_USER_ID ");
			preparedStatement =
				connection.prepareStatement(sql + where.toString());
			rs = preparedStatement.executeQuery();

			if (rs != null)
			{

				userList = new ArrayList();
				while (rs.next())
				{
					userBean = new UserBean();
					userId = rs.getString(1);
					userBean.setUserId(userId);
					String password = rs.getString(2);
					if(password != null)
					{
						Convertor convertor = new Convertor();
						userBean.setPassword(convertor.deCode(password));	
					}
					else
					{
						userBean.setPassword(password);
					}
					
					userBean.setEmployeeId(rs.getString(3));
					userBean.setLastName(rs.getString(4));
					userBean.setFirstName(rs.getString(5));
					String date = rs.getString(6);
					if (date != null)
					{
						userBean.setDateOfBirth(date.replace('-', '/'));
					}
					userBean.setIsNeverLock(rs.getString(7));
					userBean.setInvalidTries(rs.getInt(8));
					userBean.setActiveStatus(rs.getString(9));
					userBean.setReason(rs.getString(10));
					userBean.setLockStatus(rs.getString(11));
					userList.add(userBean);
				}
			}
			if (userList != null)
			{
				int size = userList.size();
				for (int i = 0; i < size; i++)
				{
					userBean = (UserBean) userList.get(i);
					userId = userBean.getUserId();
					sql =
						"SELECT MTTU.TRANS_TRANS_ID, TM.TRANS_TRANS_NAME "
							+ "FROM TB_MAP_TR_TO_USER MTTU, TB_TRANS_MSTR TM WHERE "
							+ "MTTU.TRANS_TRANS_ID = TM.TRANS_TRANS_ID AND "
							+ " MTTU.USER_USER_ID = ? ORDER BY TM.MODULE_ID";
					preparedStatement = connection.prepareStatement(sql);
					preparedStatement.setString(1, userId);
					rs = preparedStatement.executeQuery();
					if (rs != null)
					{
						transactions = new ArrayList();
						while (rs.next())
						{
							referenceDataBean = new ReferenceDataBean();
							referenceDataBean.setCodeId(rs.getString(1));
							referenceDataBean.setCodeValue(rs.getString(2));
							transactions.add(referenceDataBean);
						}
					}
					userBean.setAssignedTransactions(transactions);
				}
			}
		}	
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::selectUserDetails()::SQL Error occured", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::selectUserDetails()::Error while closing connection", sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::selectUserDetails::End");
		return userList;
	}
	
	/**
	 * Marks this user details as deleted. 
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in deleting user details
	 */
	public void deleteUserDetails(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::deleteUserDetails::Begin");
		PreparedStatement preparedStatement = null;
		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		try
		{
			preparedStatement =
				connection.prepareStatement(SQLConstants.DELETE_USER);
			preparedStatement.setString(1, userBean.getUserId());
			preparedStatement.execute();
			preparedStatement =
				connection.prepareStatement(SQLConstants
					.DELETE_TRANSACTIONS_FOR_USER);
			preparedStatement.setString(1, userBean.getUserId());
			preparedStatement.execute();	
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::deleteUserDetails()::SQL Error occured ", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::deleteUserDetails()::Error closing connection", sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::deleteUserDetails::End");
	}
	
	/**
	 * Updates user details in the database. 
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in updating user details
	 */
	public void updateUserDetails(UserBean userBean)
		throws PaxTraxSystemException
	{

		PaxTraxLog.logDebug("PaxTrax::UserDAO::updateUserDetails::Begin");
		CallableStatement callableStatement = null;

		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		try
		{
			String userId = userBean.getUserId();
			callableStatement =
				connection.prepareCall(SQLConstants.PROC_INSERT_USER_DETAILS);
			callableStatement.setString(1, userId);
			String password = userBean.getPassword();
			
			if (password != null)
			{
				Convertor convertor = new Convertor();
				callableStatement.setString(2, convertor.encode(password));
			}
			else
			{
				callableStatement.setString(2, password);	
			}
			callableStatement.setString(3, userBean.getEmployeeId());
			callableStatement.setString(4, userBean.getLastName());
			callableStatement.setString(5, userBean.getFirstName());
			callableStatement.setDate(6, getDate(userBean.getDateOfBirth()));
/*			ReferenceDataBean languageBean = userBean.getLanguageBean();
			callableStatement.setString(7, languageBean.getReferenceId());
			callableStatement.setString(8, languageBean.getCodeId());*/
			callableStatement.setString(7, userBean.getIsNeverLock());
			callableStatement.setInt(8, userBean.getInvalidTries());
			callableStatement.setString(9, userBean.getActiveStatus());
			callableStatement.setString(10, userBean.getReason());
			callableStatement.setString(11, userBean.getLockStatus());
			callableStatement.setString(12, PaxTraxConstants.UPDATE);
			callableStatement.setString(13, userBean.getUser());
			callableStatement.registerOutParameter(14, Types.INTEGER);
			callableStatement.registerOutParameter(15, Types.INTEGER);
			callableStatement.execute();
			int error = callableStatement.getInt(15);
			
			if (error != 0)
			{
				throw new PaxTraxSystemException(
					PaxTraxConstants.SYSTEM_EXCEPTION);
			}

			String[] assingedTransactions =
				userBean.getAssignedTransactionIds();

			if (assingedTransactions != null)
			{
				int size = assingedTransactions.length;
				callableStatement =
					connection.prepareCall(
						SQLConstants.PROC_INSERT_TRANSACTIONS);
				for (int i = 0; i < size; i++)
				{
					int transactionId =
						Integer.parseInt(assingedTransactions[i]);
					callableStatement.setString(1, userId);
					callableStatement.setInt(2, transactionId);
					callableStatement.registerOutParameter(3, Types.INTEGER);

					callableStatement.execute();
					error = callableStatement.getInt(3);

					if (error != 0)
					{
						throw new PaxTraxSystemException(
							PaxTraxConstants.SYSTEM_EXCEPTION);
					}

				}
			}
		}
		catch (SQLException sqle)
		{
			PaxTraxLog.logError("UserDAO::updateUserDetails()::SQL Error occured", sqle);
			throw new PaxTraxSystemException(sqle);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
				{
					callableStatement.close();
					callableStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqle)
			{
				PaxTraxLog.logError("UserDAO::updateUserDetails()::Error closing connection", sqle);
				throw new PaxTraxSystemException(sqle);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::updateUserDetails::End");
	}
	
	/**
	 * Changes user password in the database. 
	 * @param userBean
	 * @throws PaxTraxSystemException PaxTraxExcepiton is thrown if there is 
	 * any problem in updating user details
	 */
	public void changePassword(UserBean userBean)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::changePassword::Begin");
		String userId = userBean.getUserId();
		String newPassword = userBean.getPassword();
		
		String changePasswordQuery =
			"update TB_USER_MSTR set USER_USER_PASSWORD = ?, MODIFIED_BY = ?, MODIFIED_DATE=CURRENT DATE where USER_USER_ID = ?";
/*		String changePasswordProcedure =
			" {call ADM_CHANGE_PASSWORD(?,?,?,?,?)}";*/

		DBUtil dbUtil = DBUtil.getInstance();
		Connection connection = dbUtil.getConnection();
		CallableStatement callableStatement = null;
	/*	try
		{
			callableStatement = connection.prepareCall(changePasswordProcedure);
			callableStatement.setString(1, userId);
			Convertor convertor = new Convertor();
            
            
			callableStatement.setString(2, convertor.encode(oldPassword));
			callableStatement.setString(3, convertor.deCode(newPassword));
			callableStatement.registerOutParameter(4, Types.INTEGER);
			callableStatement.registerOutParameter(5, Types.INTEGER);
			callableStatement.execute();
			int result = callableStatement.getInt(4);
			if (result == 1)
			{
				throw new SecurityException(PaxTraxConstants.INVALID_PASSWORD);
			}
            int error = callableStatement.getInt(5);
			if (error != 0)
			{
				throw new PaxTraxSystemException(
					PaxTraxConstants.SYSTEM_EXCEPTION);
			}

		}
		catch (SQLException sqlException)
		{
           throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (callableStatement != null)
					callableStatement.close();
				if (connection != null)
					connection.close();
			}
			catch (SQLException sqlException)
			{
				sqlException.printStackTrace();
                throw new PaxTraxSystemException(sqlException);
			}
		}*/
		PreparedStatement preparedStatement = null;
		try
		{
                Convertor convertor = new Convertor();
			preparedStatement =
				connection.prepareStatement(changePasswordQuery);
			preparedStatement.setString(1, convertor.encode(newPassword));
            preparedStatement.setString(2, userId);
			preparedStatement.setString(3, userId);
			preparedStatement.executeUpdate();
		}
		catch (SQLException sqlException)
		{
			PaxTraxLog.logError("UserDAO::changePassword()::SQL Error occured", sqlException);
            throw new PaxTraxSystemException(sqlException);
		}
		finally
		{
			try
			{
				if (preparedStatement != null)
				{
					preparedStatement.close();
					preparedStatement = null;
				}
				if (connection != null)
				{
					connection.close();
					connection = null;
				}
			}
			catch (SQLException sqlException)
			{
				PaxTraxLog.logError("UserDAO::changePassword()::Error closing connection", sqlException);
                throw new PaxTraxSystemException(sqlException);
			}
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::changePassword::End");
	}
	private Date getDate(String strDate)
	{
		PaxTraxLog.logDebug("PaxTrax::UserDAO::getDate::Begin");
		Date resultDate = null;
		if (strDate != null)
		{
			String date = strDate.replace('/', '-');
			resultDate = Date.valueOf(date);
		}
		PaxTraxLog.logDebug("PaxTrax::UserDAO::getDate::End");
		return resultDate;
	}
}
