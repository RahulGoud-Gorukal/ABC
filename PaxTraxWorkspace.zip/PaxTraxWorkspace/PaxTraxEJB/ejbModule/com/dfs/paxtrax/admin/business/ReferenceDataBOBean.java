package com.dfs.paxtrax.admin.business;


/*
 * This is an unpublished work containing DFS confidential and proprietary
 * information.  Disclosure, use or reproduction without the written
 * authorization of DFS is prohibited.  If publication occurs, the following
 * notice applies:
 *
 * Copyright (C) 1998-2003, DFS All rights reserved.
 *
 */


import java.util.ArrayList;

import javax.ejb.SessionBean;

import com.dfs.paxtrax.admin.dao.ReferenceDataDAO;
import com.dfs.paxtrax.admin.valueobject.ReferenceDataListBean;
import com.dfs.paxtrax.common.business.PaxTraxSessionWrapper;
import com.dfs.paxtrax.common.exception.PaxTraxSystemException;
import com.dfs.paxtrax.common.util.PaxTraxLog;


/**
 * Bean implementation class for Enterprise Bean: ReferenceDataBO
 *
 * @author Cognizant Technology Solutions
 * contact Cognizant - Sankaranarayanan srinivasan
 * 			DFS - Buensalida Sheila
 * 
 * @version    1.0
 * 
 * MOD HISTORY
 * DATE 		USER 			COMMENTS
 * 12/04/2004	Vaikundamurthy	Created   
 * 06/12/04		P.C. Sathish	Added (getTravelAgentCodes(), getTravelAgentBranches())
 */	

public class ReferenceDataBOBean extends PaxTraxSessionWrapper
	implements SessionBean
{
	/**
	 * Saves ReferenceData details by invoking BO method.
	 * @param referenceDataBO ReferenceDataBO object
	 * @return ArrayList Returns list if reference exists for particular data
	 * @throws PaxTraxSystemException This exception is thrown if there is 
	 * any problem in saving ReferenceData details
	 */
	public ArrayList saveReferenceData(ReferenceDataListBean referenceDataListBean) 
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::saveReferenceData::Begin");
		ReferenceDataDAO referenceDataDAO =  ReferenceDataDAO.getInstance();
		
		ArrayList list 
			= referenceDataDAO.insertReferenceData(referenceDataListBean);
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::saveReferenceData::End");	
		return list;
	}
	
	/**
	 * Loads reference data for the given reference type
	 * @param referenceType Reference type for which data is loaded
	 * @return ArrayList List of reference data
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in loading reference data
	 */
	public ArrayList loadReferenceData(String referenceType)
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadReferenceData::Begin");
		ReferenceDataDAO referenceDataDAO =  ReferenceDataDAO.getInstance();
		ArrayList userList = referenceDataDAO.loadReferenceData(referenceType);
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadReferenceData::End");
		return userList;
	}
	
	/**
	 * Loads reference types
	 * @return ArrayList List of reference type
	 * @throws PaxTraxSystemException This exception is thrown if there is any
	 * problem in loading reference type
	 */
	public ArrayList loadReferenceType()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadReferenceType::Begin");
		ReferenceDataDAO referenceDataDAO =  ReferenceDataDAO.getInstance();
		ArrayList userList = referenceDataDAO.loadReferenceType();
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadReferenceType::End");
		return userList;
	}
	
	/**
	 * Return the list of travel agent codes
	 * @return ArrayList list of travel agent codes
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList getTravelAgentCodes()
		throws PaxTraxSystemException
	{
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadTravelAgentInfo::Begin");
		ReferenceDataDAO referenceDataDAO =  ReferenceDataDAO.getInstance();
		ArrayList travelAgentCodes = referenceDataDAO.getTravelAgentCodes();
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadTravelAgentInfo::End");
		return travelAgentCodes;
	}
	
	/**
	 * Return the list of travel agent branches given a travelAgentCode
	 * @param travelAgentCode the travel agent code to get the list of branches
	 * @return ArrayList the list of all travel agent branches
	 * @throws PaxTraxSystemException thrown on error
	 */
	public ArrayList getTravelAgentBranches(String travelAgentCode)
		throws PaxTraxSystemException {
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadTravelAgentInfo::Begin");
		ReferenceDataDAO referenceDataDAO =  ReferenceDataDAO.getInstance();
		ArrayList travelAgentBranches = referenceDataDAO.getTravelAgentBranches(travelAgentCode);
		PaxTraxLog.logDebug("PaxTrax::ReferenceDataBOBean::loadTravelAgentInfo::End");
		return travelAgentBranches;	
	}

}
