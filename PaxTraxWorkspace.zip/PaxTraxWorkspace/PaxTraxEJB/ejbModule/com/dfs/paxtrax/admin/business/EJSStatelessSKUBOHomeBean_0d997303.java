package com.dfs.paxtrax.admin.business;

import com.ibm.ejs.container.*;

/**
 * EJSStatelessSKUBOHomeBean_0d997303
 */
public class EJSStatelessSKUBOHomeBean_0d997303 extends EJSHome {
	/**
	 * EJSStatelessSKUBOHomeBean_0d997303
	 */
	public EJSStatelessSKUBOHomeBean_0d997303() throws java.rmi.RemoteException {
		super();	}
	/**
	 * create
	 */
	public com.dfs.paxtrax.admin.business.SKUBO create() throws javax.ejb.CreateException, java.rmi.RemoteException {
BeanO beanO = null;
com.dfs.paxtrax.admin.business.SKUBO result = null;
boolean createFailed = false;
try {
	result = (com.dfs.paxtrax.admin.business.SKUBO) super.createWrapper(new BeanId(this, null));
}
catch (javax.ejb.CreateException ex) {
	createFailed = true;
	throw ex;
} catch (java.rmi.RemoteException ex) {
	createFailed = true;
	throw ex;
} catch (Throwable ex) {
	createFailed = true;
	throw new CreateFailureException(ex);
} finally {
	if (createFailed) {
		super.createFailure(beanO);
	}
}
return result;	}
}
